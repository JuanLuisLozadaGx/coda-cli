from fastapi import APIRouter, Depends, status
from fastapi.exceptions import HTTPException
from fastapi.responses import JSONResponse

from coda_api.core.dependencies import credentials_set
from coda_api.core.agents.service import AgentsService
from coda_api.core.agents.schemas import (
    AgentsList,
    CreateAgentRequest,
    CreateAgentResponse,
    RemoteAgentsList,
    ToggleRemoteAgentRequest
)


agents_router = APIRouter(
    prefix="/agents",
    tags=["agents"],
    dependencies=[Depends(credentials_set)]
)


@agents_router.get("/", response_model=AgentsList)
def get_agents():
    """
    Get the list of available local agents.

    Returns:
        AgentsList: List of the available agents. This schema includes:
            - agents (List[Agent]): List of agents. Where each `Agent` includes:
                - name (str): Name of the agent.
                - description (str, optional): Description of the agent.
    """
    try:
        return AgentsList(agents=AgentsService.get_agents())
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "Failed to retrieve available agents"}
        )


@agents_router.get("/remote", response_model=RemoteAgentsList)
def get_remote_agents():
    """
    Get the list of available remote agents from GEAI.

    Returns:
        RemoteAgentsList: List of remote agents. This schema includes:
            - agents (List[RemoteAgent]): List of remote agents. Where each `RemoteAgent` includes:
                - id (str): Unique identifier for the remote agent.
                - name (str): Name of the remote agent.
                - description (str): Description of what the agent does.
                - enabled (bool): Whether the agent is enabled for use.
                - source (str): Source system managing the agent (e.g., "GEAI").
    """
    try:
        remote_agents = AgentsService.get_remote_agents()
        return RemoteAgentsList(agents=remote_agents)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "Failed to retrieve remote agents", "message": str(e)}
        )


@agents_router.post("/", response_model=CreateAgentResponse, status_code=status.HTTP_201_CREATED)
def create_agent(request: CreateAgentRequest):
    """
    Create a new local custom agent by delegating to the built-in 'agent-manager' subagent.

    Args:
        request (CreateAgentRequest): Request body. This schema includes:
            - name (str): Name for the new agent.
            - description (str): Description of what the agent should do (used as the creation prompt).

    Returns:
        CreateAgentResponse: Result of the agent creation. This schema includes:
            - success (bool): Whether the operation succeeded.
            - agent_name (str): Name of the agent that was requested.
            - file_path (str, optional): Absolute path to the created agent file, if found.
            - message (str): Response content from the agent-manager subagent.
    """
    try:
        return AgentsService.create_agent(request)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": str(e)}
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "Failed to create agent", "message": str(e)}
        )


@agents_router.delete("/{agent_name}")
def delete_agent(agent_name: str):
    """
    Delete a local custom agent.

    Args:
        agent_name (str): The name of the agent to delete.

    Returns:
        JSONResponse: Confirmation message with:
            - success (bool): Whether the operation was successful.
            - agent_name (str): The name of the deleted agent.
    """
    try:
        success = AgentsService.delete_agent(agent_name)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": str(e)}
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "Failed to delete agent", "message": str(e)}
        )

    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": f"Agent '{agent_name}' not found or could not be deleted"}
        )

    return JSONResponse(
        content={
            "success": True,
            "agent_name": agent_name,
            "message": "Agent deleted successfully"
        }
    )


@agents_router.patch("/remote/{agent_name}")
def toggle_remote_agent(agent_name: str, request: ToggleRemoteAgentRequest):
    """
    Enable or disable a remote agent by updating the CODA_REMOTE_MENTIONS_ALLOWLIST env var.

    Args:
        agent_name (str): The name of the remote agent to enable or disable.
        request (ToggleRemoteAgentRequest): Request body. This schema includes:
            - enabled (bool): Whether to enable or disable the agent.

    Returns:
        JSONResponse: Confirmation message with:
            - success (bool): Whether the operation was successful.
            - agent_name (str): The name of the toggled agent.
            - enabled (bool): The new enabled state.
    """
    try:
        success = AgentsService.toggle_remote_agent(agent_name, request.enabled)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "Failed to toggle remote agent", "message": str(e)}
        )

    if not success:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "Failed to toggle remote agent"}
        )

    return JSONResponse(
        content={
            "success": True,
            "agent_name": agent_name,
            "enabled": request.enabled
        }
    )
