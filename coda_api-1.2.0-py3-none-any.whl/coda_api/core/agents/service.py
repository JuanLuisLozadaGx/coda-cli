from typing import List

from loguru import logger
from coda_core.core.agents.manager import AgentManager
from coda_core.core.session.states.shared_state import SharedState
from coda_core.config.constants import AGENT_MANAGER, CODEFIXER_AGENTS
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig

from coda_api.core.agents.schemas import Agent, CreateAgentRequest, CreateAgentResponse, RemoteAgent


class AgentsService:

    AGENT_MANAGER = AgentManager(SharedState())

    @staticmethod
    def get_agents() -> List[Agent]:
        agents = []
        for agent_name in AgentsService.AGENT_MANAGER.list_agents():
            if agent_name == AGENT_MANAGER:
                continue

            agent_def = AgentsService.AGENT_MANAGER.load_agent_metadata(agent_name)
            is_builtin = agent_name in CODEFIXER_AGENTS

            agents.append(Agent(
                name=agent_name,
                description=agent_def.metadata.description if agent_def else None,
                is_builtin=is_builtin,
                file_path=agent_def.file_path if agent_def else None
            ))

        return agents

    @staticmethod
    def create_agent(request: CreateAgentRequest) -> CreateAgentResponse:
        """
        Create a new local agent by delegating to the built-in 'agent-manager' subagent.

        Creates an ephemeral SharedState and AgentManager to instantiate the
        'agent-manager' subagent and calls get_response() with the creation prompt
        so the LLM writes the agent file. Follows the same pattern as the CLI.

        Args:
            request: CreateAgentRequest with name and description.

        Returns:
            CreateAgentResponse with the result of the operation.
        """
        shared_state = SharedState()
        agent_manager = AgentManager(shared_state)
        agent_manager.initialize_default_agents()

        agents_dir_path = SETTINGS.get_env_var(EnvConfig.CODA_AGENTS_DIR_PATH)
        agent_input = (
            f"Create a new agent with name '{request.name}', "
            f"description '{request.description}', "
            f"in directory '{agents_dir_path}'"
        )

        subagent = agent_manager.create_agent(agent_name=AGENT_MANAGER)

        response = subagent.get_response(user_message=agent_input)

        success = response.get("success", False)
        logger.info(f"agent-manager response for '{request.name}': success={success}")

        # Attempt to resolve the file_path of the newly created agent
        file_path = None
        agent_def = agent_manager.load_agent_metadata(request.name)
        if agent_def:
            file_path = agent_def.file_path

        return CreateAgentResponse(
            success=success,
            agent_name=request.name,
            file_path=file_path,
            message=response.get("content", "Agent creation completed")
        )

    @staticmethod
    def delete_agent(agent_name: str) -> bool:
        if agent_name in CODEFIXER_AGENTS or agent_name == AGENT_MANAGER:
            raise ValueError(f"Cannot delete built-in agent: {agent_name}")

        return AgentsService.AGENT_MANAGER.delete_agent(agent_name)

    @staticmethod
    def _get_allowlist() -> set:
        """Read the current remote mentions allowlist from env config."""
        raw = SETTINGS.get_env_var(EnvConfig.CODA_REMOTE_MENTIONS_ALLOWLIST) or ""
        return {name.strip() for name in raw.split(",") if name.strip()}

    @staticmethod
    def _set_allowlist(allowlist: set) -> None:
        """Persist the remote mentions allowlist to env config."""
        SETTINGS.set_env_var(EnvConfig.CODA_REMOTE_MENTIONS_ALLOWLIST, ",".join(sorted(allowlist)))

    @staticmethod
    def get_remote_agents() -> List[RemoteAgent]:
        """
        List all active remote GEAI agents, marking each as enabled or disabled
        based on the CODA_REMOTE_MENTIONS_ALLOWLIST env var.
        """
        allowlist = AgentsService._get_allowlist()
        return [
            RemoteAgent(
                id=agent.id,
                name=agent.name,
                description=agent.description or "",
                enabled=agent.name in allowlist,
                source="GEAI"
            )
            for agent in AgentsService.AGENT_MANAGER.list_remote_agents_cached()
        ]

    @staticmethod
    def toggle_remote_agent(agent_name: str, enabled: bool) -> bool:
        """
        Enable or disable a remote agent by updating CODA_REMOTE_MENTIONS_ALLOWLIST.
        Also sets CODA_REMOTE_MENTIONS_MODE to 'favorites' if not already set.
        """
        # Ensure mode is 'favorites' so the allowlist is respected
        mode = (SETTINGS.get_env_var(EnvConfig.CODA_REMOTE_MENTIONS_MODE) or "").strip().lower()
        if mode != "favorites":
            SETTINGS.set_env_var(EnvConfig.CODA_REMOTE_MENTIONS_MODE, "favorites")

        allowlist = AgentsService._get_allowlist()
        if enabled:
            allowlist.add(agent_name)
        else:
            allowlist.discard(agent_name)

        AgentsService._set_allowlist(allowlist)
        return True

    @staticmethod
    def get_enabled_remote_agents() -> List[str]:
        """Return the list of enabled remote agent names from the allowlist."""
        return list(AgentsService._get_allowlist())
