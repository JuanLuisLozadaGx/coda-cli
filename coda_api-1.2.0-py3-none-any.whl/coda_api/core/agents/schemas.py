from typing import List, Optional, Literal

from pydantic import BaseModel, Field


class Agent(BaseModel):
    name: str
    description: Optional[str] = None
    is_builtin: bool = False
    file_path: Optional[str] = None


class CreateAgentRequest(BaseModel):
    name: str = Field(..., description="Name for the new agent")
    description: str = Field(..., description="Description of what the agent should do (used as the creation prompt)")


class CreateAgentResponse(BaseModel):
    success: bool
    agent_name: str
    file_path: Optional[str] = None
    message: str


class RemoteAgent(BaseModel):
    id: str = Field(..., description="Unique identifier for the remote agent")
    name: str = Field(..., description="Name of the remote agent")
    description: str = Field(..., description="Description of what the agent does")
    enabled: bool = Field(default=False, description="Whether the agent is enabled for use")
    source: str = Field(default="GEAI", description="Source system managing the agent")


class AgentsList(BaseModel):
    agents: List[Agent]


class RemoteAgentsList(BaseModel):
    agents: List[RemoteAgent]


class ToggleRemoteAgentRequest(BaseModel):
    enabled: bool = Field(..., description="Enable or disable the remote agent")
