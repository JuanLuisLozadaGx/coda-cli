"""
Thread interruptor for injecting KeyboardInterrupt into running agent threads.

This module provides a mechanism to interrupt agent execution from the API layer
by injecting KeyboardInterrupt exceptions into the thread running the agent.
This reuses the existing KeyboardInterrupt handling in SingleAgent without
requiring modifications to coda-core.
"""

import ctypes
import threading
from typing import Dict, Optional
from uuid import UUID

from loguru import logger


class ThreadInterruptor:
    """
    Utility to inject KeyboardInterrupt into a running thread.
    
    This class tracks a thread ID and provides a method to asynchronously
    raise a KeyboardInterrupt in that thread using Python's C API.
    
    Usage:
        interruptor = ThreadInterruptor()
        
        # In the worker thread:
        interruptor.register_thread()
        try:
            # ... long running work ...
        finally:
            interruptor.unregister_thread()
        
        # From another thread to interrupt:
        interruptor.interrupt()
    """
    
    def __init__(self):
        self._thread_id: Optional[int] = None
        self._lock = threading.Lock()
        self._interrupted = False
    
    def register_thread(self) -> None:
        """
        Register the current thread for potential interruption.
        
        Call this at the start of the agent execution thread.
        """
        with self._lock:
            self._thread_id = threading.current_thread().ident
            self._interrupted = False
            logger.debug(f"Registered thread {self._thread_id} for interruption")
    
    def unregister_thread(self) -> None:
        """
        Unregister the thread after execution completes.
        
        Call this when agent execution completes (in a finally block).
        """
        with self._lock:
            thread_id = self._thread_id
            self._thread_id = None
            self._interrupted = False
            logger.debug(f"Unregistered thread {thread_id} from interruption")
    
    def interrupt(self) -> bool:
        """
        Inject KeyboardInterrupt into the registered thread.
        
        This uses Python's C API (PyThreadState_SetAsyncExc) to asynchronously
        raise an exception in the target thread. The exception will be raised
        at the next opportunity when Python bytecode is executing.
        
        Note: This may not immediately interrupt blocking C extensions or
        system calls, but will interrupt once Python code resumes execution.
        
        Returns:
            bool: True if the interrupt was successfully injected, False otherwise.
        """
        with self._lock:
            if self._thread_id is None:
                logger.debug("No thread registered for interruption")
                return False
            
            if self._interrupted:
                logger.debug("Thread already interrupted")
                return True
            
            thread_id = self._thread_id
        
        try:
            # Use ctypes to call Python's C API for async exception injection
            res = ctypes.pythonapi.PyThreadState_SetAsyncExc(
                ctypes.c_ulong(thread_id),
                ctypes.py_object(KeyboardInterrupt)
            )
            
            if res == 0:
                logger.warning(f"Thread {thread_id} not found for interruption")
                return False
            elif res > 1:
                # If more than one thread was affected, reset to clean up
                # This shouldn't happen in normal circumstances
                ctypes.pythonapi.PyThreadState_SetAsyncExc(
                    ctypes.c_ulong(thread_id), 
                    None
                )
                logger.error(f"PyThreadState_SetAsyncExc affected multiple threads, reset performed")
                return False
            
            with self._lock:
                self._interrupted = True
            
            logger.info(f"Successfully injected KeyboardInterrupt into thread {thread_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to inject KeyboardInterrupt: {e}")
            return False
    
    @property
    def is_registered(self) -> bool:
        """Check if a thread is currently registered."""
        with self._lock:
            return self._thread_id is not None
    
    @property
    def was_interrupted(self) -> bool:
        """Check if the thread was interrupted."""
        with self._lock:
            return self._interrupted


class SessionInterruptors:
    """
    Manager for tracking interruptors per session.
    
    This singleton-like class maintains a mapping of session IDs to their
    respective ThreadInterruptor instances, allowing interruption of
    agent execution by session ID.
    
    Usage:
        # When starting chat processing:
        interruptor = SessionInterruptors.create(session_id)
        
        # When stop is requested:
        success = SessionInterruptors.interrupt(session_id)
        
        # When processing completes:
        SessionInterruptors.remove(session_id)
    """
    
    _interruptors: Dict[UUID, ThreadInterruptor] = {}
    _lock = threading.Lock()
    
    @classmethod
    def create(cls, session_id: UUID) -> ThreadInterruptor:
        """
        Create and register an interruptor for a session.
        
        If an interruptor already exists for this session, it will be replaced.
        
        Args:
            session_id: The UUID of the session.
            
        Returns:
            ThreadInterruptor: The interruptor instance for this session.
        """
        interruptor = ThreadInterruptor()
        with cls._lock:
            cls._interruptors[session_id] = interruptor
        logger.debug(f"Created interruptor for session {session_id}")
        return interruptor
    
    @classmethod
    def get(cls, session_id: UUID) -> Optional[ThreadInterruptor]:
        """
        Get the interruptor for a session.
        
        Args:
            session_id: The UUID of the session.
            
        Returns:
            Optional[ThreadInterruptor]: The interruptor if it exists, None otherwise.
        """
        with cls._lock:
            return cls._interruptors.get(session_id)
    
    @classmethod
    def interrupt(cls, session_id: UUID) -> bool:
        """
        Interrupt the agent execution for a session.
        
        This injects a KeyboardInterrupt into the thread running the agent
        for the specified session.
        
        Args:
            session_id: The UUID of the session to interrupt.
            
        Returns:
            bool: True if the interrupt was successfully injected, False otherwise.
        """
        interruptor = cls.get(session_id)
        if interruptor is None:
            logger.warning(f"No interruptor found for session {session_id}")
            return False
        
        return interruptor.interrupt()
    
    @classmethod
    def remove(cls, session_id: UUID) -> bool:
        """
        Remove the interruptor for a session.
        
        Call this when chat processing completes (successfully or not).
        
        Args:
            session_id: The UUID of the session.
            
        Returns:
            bool: True if an interruptor was removed, False if none existed.
        """
        with cls._lock:
            if session_id in cls._interruptors:
                del cls._interruptors[session_id]
                logger.debug(f"Removed interruptor for session {session_id}")
                return True
            return False
    
    @classmethod
    def is_processing(cls, session_id: UUID) -> bool:
        """
        Check if a session is currently processing (has an active interruptor with registered thread).
        
        Args:
            session_id: The UUID of the session.
            
        Returns:
            bool: True if the session has an active processing thread, False otherwise.
        """
        interruptor = cls.get(session_id)
        return interruptor is not None and interruptor.is_registered
    
    @classmethod
    def clear_all(cls) -> int:
        """
        Clear all interruptors.
        
        Useful for cleanup during shutdown.
        
        Returns:
            int: Number of interruptors that were cleared.
        """
        with cls._lock:
            count = len(cls._interruptors)
            cls._interruptors.clear()
            logger.info(f"Cleared {count} session interruptors")
            return count

