from typing import Dict, List, Optional
from uuid import UUID

from loguru import logger
from coda_core.core.session.session_manager import SessionManager
from coda_core.core.session.session import Session

from coda_api.core.sessions.repository.models import APISession
from coda_api.core.sessions.repository.mapper import SessionsMapper
from coda_api.core.sessions.schemas import UpdateSession


class SessionsDatabaseManager:
    """
    Singleton class SessionsDatabaseManager that handles all operations related to the persistence
    of sessions in a database through the `SessionManager` class provided in `coda-core`.

    This database manager receives and returns APISession model objects. Internally it handles the Session model used in `coda-core`.
    """

    _initialized = False
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(SessionsDatabaseManager, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self.session_manager = SessionManager()
            self.session_manager.initialize()
            self._initialized = True

    def create_session(self, session: APISession) -> None:
        """
        Create a new session in the database.

        Args:
            session (APISession): The session to create. Based on the model used in
            the `coda-api`.

        Raises:
            Exception: If there is an error creating or saving the session.
        """
        # This session is based on the coda-core SessionManager model.
        new_session = self.session_manager.create_session(
            name=session.name,
            id=str(session.id)
        )

        # We re-pass the new_session so we avoid using .current_session in SessionManager.
        self.session_manager.save_session(
            shared_state=session.shared_state,
            client_type=session.client_state.CLIENT_TYPE,
            client_state=session.client_state,
            session=new_session
        )

    def update_session(self, session: APISession, session_update_data: UpdateSession) -> bool:
        """
        Update an existing session's fields. For now this only updates the session name.

        Args:
            session (APISession): The session to update.
            session_update_data (UpdateSession): The session update data. This schema includes:
                - name (str): The new name for the session.
                - rename_method (str): The method used for renaming the session.

        Returns:
            bool: True if the session was updated, False otherwise.
        """
        return self.session_manager.rename_session(
            str(session.id),
            session_update_data.name,
            rename_method=session_update_data.rename_method
        )

    def _get_core_session(self, session_id: UUID) -> Optional[Session]:
        """
        Get a core session by its ID.

        Args:
            session_id (UUID): The ID of the session to get.

        Returns:
            Optional[Session]: The core session if found, None otherwise.
        """
        try:
            return self.session_manager.load_session(str(session_id))
        except ValueError as e:
            logger.error(f"Session with ID {session_id} not found: {e}")
            return None

    def get_session(self, session_id: UUID) -> Optional[APISession]:
        """
        Get a session by its ID.

        Args:
            session_id (UUID): The ID of the session to get.

        Returns:
            Optional[APISession]: The session if found, None otherwise.
        """
        try:
            core_session = self._get_core_session(session_id)
            if not core_session:
                return None
            # Map the coda-core session model to a coda-api session model.
            return SessionsMapper.map_core_to_api(core_session)
        except Exception as e:
            logger.error(f"Error loading session {session_id}: {e}")
            return None

    def list_sessions(self) -> List[Dict]:
        """
        List all available sessions. Sessions are returned as the dict representation
        of the `coda-core` Session models

        Returns:
            List[Dict]: A list of session data dictionaries.
        """
        return self.session_manager.list_sessions()

    def delete_session(self, session_id: UUID) -> bool:
        """
        Delete a session.

        Args:
            session_id (UUID): The ID of the session to delete.

        Returns:
            bool: True if the session was deleted, False otherwise.
        """
        try:
            return self.session_manager.delete_session(str(session_id))
        except Exception as e:
            logger.error(f"Error deleting session {session_id}: {e}")
            return False

    def save_session(self, session: APISession) -> None:
        """
        Save a session.

        Args:
            session (APISession): The session to save.

        Raises:
            ValueError: If the session does not exist in the database.
            Exception: If there is an error saving the session.
        """
        try:
            db_session = self._get_core_session(session.id)
            if not db_session:
                raise ValueError(f"Session with ID {session.id} does not exist in the database.")

            self.session_manager.save_session(
                shared_state=session.shared_state,
                client_state=session.client_state,
                client_type=session.client_state.CLIENT_TYPE,
                session=db_session
            )
        except Exception as e:
            logger.error(f"Error saving session: {e}")
            raise e


# Singleton instance of the sessions database manager
SESSIONS_DB_MANAGER = SessionsDatabaseManager()
