from typing import Any, Dict, Optional, Union
from uuid import UUID

from loguru import logger
from coda_core.config.settings import EnvConfig, SETTINGS
from coda_core.core.memories.condenser import MemoryCondenser
from coda_core.core.session.states.shared_state import SharedState
from coda_core.core.session.session import Session
from coda_core.core.agents.manager import AgentManager

from coda_api.config.constants import CLIENT_NAME
from coda_api.core.sessions.repository.utils import get_shared_state_messages
from coda_api.core.sessions.states.api_client_state import APIClientState
from coda_api.core.sessions.repository.models import APISession


class SessionsMapper:
    """
    The SessionsMapper is an utility class responsible for mapping sessions data between the different
    layers of the backend:

    - database layer (coda-core Session model or coda-core Session as a dictionary)
    - application layer (coda-api APISession model)
    - data transfer layer (DTO representation as a dictionary)
    """

    # The default name to assign to nameless sessions from the `coda-core` dependency.
    DEFAULT_NAME = "Unnamed Session"

    @staticmethod
    def map_core_to_api(core_session: Union[Dict[Any, Any], Session]) -> Optional[APISession]:
        """
        Utility function to map a `coda-core` Session model to a coda-api APISession model.

        Args:
            core_session (Union[Dict[Any, Any], Session]): The coda-core session model or its dictionary representation.

        Returns:
            Optional[APISession]: The mapped APISession model, or None if not mappable (e.g., client state different than `API`).

        Raises:
            ValueError: If there are issues during the mapping process.
        """
        if isinstance(core_session, Dict):
            try:
                core_session = Session.from_dict(core_session)
            except Exception as e:
                logger.error(f"Couldn't convert dict-like data to core Session model: {e}")
                return None

        try:
            session_shared_state = SharedState.from_dict(core_session.shared_state)
        except Exception as e:
            logger.error(f"Failed to initialize SharedState for session {core_session.id}: {e}")
            raise ValueError(f"Failed to initialize SharedState for session {core_session.id}: {e}")

        # FIX: Re-attach memory condenser if enabled in env vars. Guards against: https://github.com/5G-AGE009-HZ/coda-core/issues/586
        if SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_ENABLED).lower() == "true":
            try:
                global_threshold = float(SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_THRESHOLD))
                for memory in session_shared_state.memories.values():
                    if memory.condenser is None:
                        memory.condenser = MemoryCondenser(threshold=global_threshold)
                    else:
                        memory.condenser.threshold = global_threshold
            except Exception as e:
                logger.error(f"Failed to attach memory condenser for session {core_session.id}: {e}")

        # If no API client state is found, we're looking at a different client type Session, so we ignore it.
        if not (api_client_state := core_session.client_states.get(CLIENT_NAME, None)):
            logger.warning(f"Session: {core_session.id} has no {CLIENT_NAME} client state")
            return None

        try:
            session_client_state = APIClientState.from_dict(api_client_state)
        except Exception as e:
            logger.error(f"Failed to initialize APIClientState for session {core_session.id}: {e}")
            raise ValueError(f"Failed to initialize APIClientState for session {core_session.id}: {e}")

        try:
            return APISession(
                id=UUID(core_session.id), # Core session IDs are str. The API follows a UUID type
                # current_name -> original_name -> default_name
                name=core_session.name_info.get("current", core_session.name_info.get("original", SessionsMapper.DEFAULT_NAME)),
                shared_state=session_shared_state,
                agent_manager=AgentManager(shared_state=session_shared_state),
                client_state=session_client_state,
                # map extra fields for renaming logic
                last_changed=core_session.name_info.get("last_changed", None),
                rename_method=core_session.name_info.get("rename_method", None)
            )
        except Exception as e:
            logger.error(f"Error mapping core session to API session for session {core_session.id}: {e}")
            raise ValueError(f"Error mapping core session to API session for session {core_session.id}: {e}")

    @staticmethod
    def map_api_to_dto(api_session: APISession) -> Dict[str, Any]:
        """
        Convert the APISession instance to a DTO representation.

        Args:
            api_session (APISession): The APISession instance to be converted.

        Returns:
            (Dict[str, Any]): A dictionary containing session details. Keys include:
            - id (str): The unique identifier of the session.
            - name (str): The name of the session.
            - workspace_id (str): The unique identifier of the workspace associated with the session.
            - model_name (str): The name of the model used in the session.
            - model_provider (str): The name of the model provider used in the session.
            - messages (List[Dict[str, Any]]): A list of messages exchanged in the session.
        """
        api_session_as_dto = {
            "id": str(api_session.id),
            "name": api_session.name,
            "workspace_id": api_session.client_state.workspace_id,
            "model_name": api_session.shared_state.single_agent_model_name,
            "model_provider": api_session.shared_state.single_agent_provider_name,
            "messages": []
        }

        try:
            api_session_as_dto["messages"] = get_shared_state_messages(api_session.shared_state.to_dict())
        except Exception as e:
            logger.error(f"Error parsing session {api_session.id} messages: {e}")

        return api_session_as_dto

    @staticmethod
    def map_core_dict_to_dto(core_session_dict: Dict[str, Any]) -> Dict[str, Any]:
        """
        Convert a core session represented as a dictionary to a DTO representation.

        Args:
            core_session_dict (Dict[str, Any]): The core session represented as a dictionary.

        Returns:
            (Dict[str, Any]): A dictionary containing session details. Keys include:
            - id (str): The unique identifier of the session.
            - name (str): The name of the session.
            - workspace_id (str): The unique identifier of the workspace associated with the session.
            - model_name (str): The name of the model used in the session.
            - model_provider (str): The name of the model provider used in the session.
            - messages (List[Dict[str, Any]]): A list of messages exchanged in the session.

        Raises:
            ValueError: If required fields are missing in the core session dictionary.
            KeyError: If expected keys are not found in the core session dictionary.
        """
        # Retrieve the session ID
        if not (session_id := core_session_dict.get("id", None)):
            raise ValueError("Core session dictionary must contain 'id' field")

        # Retrieve the current name from the `name_info` property.
        if not (name_info := core_session_dict.get("name_info", None)) or not (session_name := name_info.get("current", None)):
            raise ValueError("Core session dictionary must contain 'name_info' with a 'current' field.")

        # Retrieve the client-state dictionary.
        if not (clients_states := core_session_dict.get("client_states", None)) \
            or not (CLIENT_NAME in clients_states and (api_state := clients_states[CLIENT_NAME])):
                raise ValueError(f"Core session dictionary must contain client state for '{CLIENT_NAME}'.")

        # Retrieve the dictionary representation of the shared state.
        if not (shared_state_dict := core_session_dict.get("shared_state", None)):
            raise ValueError("Core session dictionary must contain 'shared_state' field.")

        api_session_as_dto = {
            "id": str(session_id),
            "name": session_name,
            "workspace_id": api_state["workspace_id"],
            "model_name": shared_state_dict.get("single_agent_model_name", ""),
            "model_provider": shared_state_dict.get("single_agent_provider_name", ""),
            "messages": []
        }

        try:
            api_session_as_dto["messages"] = get_shared_state_messages(shared_state_dict)
        except Exception as e:
            logger.error(f"Error parsing session {session_id} messages: {e}")

        return api_session_as_dto
