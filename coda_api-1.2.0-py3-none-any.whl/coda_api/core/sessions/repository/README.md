# Repository

This module provides an abstraction layer for the storage-related operations of Sessions in the CODA API.

## Module Components
- [database.py](/coda_api/core/sessions/repository/database.py): Database layer for Sessions. This component handles all database-related operations through the `SessionManager` class provided by the `coda-core` dependency.
- [mapper.py](/coda_api/core/sessions/repository/mapper.py): This component exposes mapping functions to map objects from the database layer to the application layer and then to the client-facing layer.
- [models.py](/coda_api/core/sessions/repository/models.py): This component defines our models used in the CODA API. For now it only holds a representation of a Session with the APISession class. This class is tightly related to the application layer but could be later extended to be a database model.
- [utils.py](/coda_api/core/sessions/repository/utils.py): Utility functions used across the repository submodule.
