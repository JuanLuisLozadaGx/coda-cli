from typing import Any, Dict, List
import json

from loguru import logger
from coda_core.core.session.constants import MEMORY_KEY_MAIN
from coda_core.core.agents.constants import CODA_SYSTEM_MESSAGE_PREFIX


def _extract_text_from_content_list(content: List[Dict[str, Any]]) -> str:
    """Extract plain text from a Responses API content list (e.g. [{"type": "input_text", "text": "..."}])."""
    return "".join(
        part.get("text", "")
        for part in content
        if isinstance(part, dict) and "text" in part
    )


def get_shared_state_messages(shared_state_as_dict: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Retrieve the messages from the shared state dictionary. Particularly, it looks for messages stored
    in the `main` memory excluding `system` role messages.

    Handles both the standard Chat Completions format and the OpenAI Responses API format, including
    sessions where the model was switched mid-session and both formats coexist in the same message list.

    Each message is evaluated individually:
    - Items with ``type: "function_call"`` or ``type: "function_call_output"`` are Responses API tool calls.
    - Items with ``type: "message"`` are Responses API chat turns.
    - Items with a ``role`` field but no recognised ``type`` are Chat Completions messages.

    For Chat Completions ``assistant`` messages with ``tool_calls``, it keeps track of the latest tool
    calls and associates them with subsequent ``tool`` role messages based on the ``tool_call_id``.

    For ``tool`` role messages, it attempts to parse the tool arguments and content from JSON strings
    into dictionaries, recreating the ``OnToolCall`` and ``OnToolResult`` callback format.

    Args:
        shared_state_as_dict (Dict[str, Any]): The shared state represented as a dictionary.

    Returns:
        List[Dict[str, str]]: A list of messages from the shared state.
    """
    if (
        (memories_dict := shared_state_as_dict.get("memories", None)) and
        (main_memory := memories_dict.get(MEMORY_KEY_MAIN, None))
    ):
        messages = main_memory.get("messages", [])
        bash_risk_history = shared_state_as_dict.get("preferences", {}).get("_bash_risk_history", {})

        # Trackers for each format's pending tool calls
        latest_tool_calls: List[Dict[str, Any]] = []       # Chat Completions: list of tool call dicts
        pending_tool_calls: Dict[str, Dict[str, Any]] = {} # Responses API: call_id -> function_call item
        parsed_messages: List[Dict[str, Any]] = []

        for item in messages:
            item_type = item.get("type")
            role = item.get("role")

            # --- Responses API: function call (tool invocation) ---
            if item_type == "function_call":
                call_id = item.get("call_id")
                if call_id:
                    pending_tool_calls[call_id] = item
                continue

            # --- Responses API: function call output (tool result) ---
            if item_type == "function_call_output":
                call_id = item.get("call_id")
                tool_call = pending_tool_calls.pop(call_id, None)
                if not tool_call:
                    continue

                tool_name = tool_call.get("name")
                raw_args = tool_call.get("arguments", "{}")
                tool_args = raw_args  # fallback: keep raw value if JSON parsing fails
                try:
                    if isinstance(raw_args, str):
                        tool_args = json.loads(raw_args)
                except (json.JSONDecodeError, ValueError, TypeError) as e:
                    logger.warning(f"Failed to parse Responses API tool arguments: {e}")

                raw_output = item.get("output", "{}")
                tool_content = raw_output  # fallback: keep raw value if JSON parsing fails
                try:
                    if isinstance(raw_output, str):
                        tool_content = json.loads(raw_output)
                except (json.JSONDecodeError, ValueError, TypeError) as e:
                    logger.warning(f"Failed to parse Responses API tool output: {e}")

                tool_message: Dict[str, Any] = {
                    "role": "tool",
                    "tool_name": tool_name,
                    "tool_args": tool_args,
                    "content": tool_content,
                }
                if tool_name == "bash" and isinstance(tool_args, dict):
                    command = tool_args.get("command", "")
                    tool_message["risk_level"] = bash_risk_history.get(command, "low")

                parsed_messages.append(tool_message)
                continue

            # --- Filter out system messages (both formats) ---
            if role in (None, "system"):
                continue

            is_responses_api_message = item_type == "message"

            # --- User message ---
            if role == "user":
                content = item.get("content")
                if is_responses_api_message:
                    text = _extract_text_from_content_list(content) if isinstance(content, list) else (content or "")
                else:
                    text = content if isinstance(content, str) else ""

                if not text or text.startswith(CODA_SYSTEM_MESSAGE_PREFIX) or text.startswith("[SYSTEM MESSAGE]"):
                    continue
                parsed_messages.append({**item, "content": text})

            # --- Assistant message ---
            elif role == "assistant":
                if is_responses_api_message:
                    content = item.get("content", "")
                    text = _extract_text_from_content_list(content) if isinstance(content, list) else (content or "")
                    parsed_messages.append({**item, "content": text})
                else:
                    # Chat Completions format: track tool_calls for subsequent tool messages
                    if not (tool_calls := item.get("tool_calls")):
                        parsed_messages.append(item)
                    else:
                        latest_tool_calls.extend(tool_calls)

            # --- Chat Completions tool result ---
            elif role == "tool":
                tool_call_metadata = None
                for i, tool_call in enumerate(latest_tool_calls):
                    if tool_call.get("id") == item.get("tool_call_id"):
                        tool_call_metadata = tool_call
                        latest_tool_calls.pop(i)  # Remove matched tool call to prevent reuse
                        break

                # Generate the tool message only if we found matching tool call metadata
                if tool_call_metadata:
                    tool_args = None
                    try:
                        # Try to parse the tool arguments
                        tool_args = tool_call_metadata.get("function", {}).get("arguments", {})
                        if tool_args:
                            # If we found tool_args we need to parse them to a dictionary since they're stored as a string.
                            tool_args = json.loads(tool_args)
                    except (json.JSONDecodeError, ValueError, TypeError) as e:
                        logger.warning(f"Failed to parse tool arguments: {e}")

                    tool_content = None
                    try:
                        # Try to parse the tool content
                        tool_content = item.get("content", {})
                        if tool_content and isinstance(tool_content, str):
                            tool_content = json.loads(tool_content)
                    except (json.JSONDecodeError, ValueError, TypeError) as e:
                        logger.warning(f"Failed to parse tool content: {e}. Tool content type: {type(tool_content)}")

                    tool_name = item.get("name") or tool_call_metadata.get("function", {}).get("name")
                    chat_tool_message: Dict[str, Any] = {
                        "role": "tool",
                        "tool_name": tool_name,
                        "tool_args": tool_args,
                        "content": tool_content,
                    }

                    if tool_name == "bash" and tool_args:
                        command = tool_args.get("command", "")
                        chat_tool_message["risk_level"] = bash_risk_history.get(command, "low")

                    parsed_messages.append(chat_tool_message)

        return parsed_messages

    return []
