from typing import Optional
from uuid import UUID
from dataclasses import dataclass

from coda_core.core.session.states.shared_state import SharedState
from coda_core.core.agents.manager import AgentManager

from coda_api.core.sessions.states.api_client_state import APIClientState


@dataclass
class APISession:
    """
    APISession dataclass representing a user session.

    Attributes:
        id (UUID): Unique identifier for the session.
        name (str): Name of the session.
        shared_state (SharedState): State shared across the session.
        agent_manager (AgentManager): Manager for agents within the session.
        client_state (APIClientState): State specific to the API client.
        last_changed (Optional[str]): Timestamp of the last change to the session name.
        rename_method (Optional[str]): Method used for renaming the session.
    """
    id: UUID
    name: str
    shared_state: SharedState
    agent_manager: AgentManager
    client_state: APIClientState
    last_changed: Optional[str] = None
    rename_method: Optional[str] = None
