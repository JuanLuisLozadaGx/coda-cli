# Sessions

This module defines all the operations related to the management of sessions.

## Module Components
- **repository**: This submodule contains all data-layer utilities of sessions. For more info check its [README.md](/coda_api/core/sessions/repository/README.md)
- **states**: This submodule contains all client-states implementations. For more info check its [README.md](/coda_api/core/sessions/states/README.md)
- **schemas**: This file contains all dataclasses or Pydantic models used to represent complex types related to Sessions.
- **router**: Endpoints related to sessions are defined in this file.
- **service**: This file contains the business logic related to sessions. Any operation related to sessions should interact with this service.

## Module Endpoints

### `POST /sessions/create-session`

**Description:**  
Create a new session.

**Request Body:**
```json
{
  "workspace_id": "string",
  "workspace_context": {
    "environment_context": {
      "workspace_path": "string",
      "current_date": "string",
      "os_name": "string",
      "os_release": "string",
    },
    "codebase_context": {
      "workspace_tree": "string",
    },
    "vcs_context": { // Optional.
      "repo_name": "string", // Optional.
      "repo_branch": "string" // Optional.
    }
  },
  "model_provider_name": "string (default: vertex_ai)", // Optional. It defaults.
  "model_name": "string (default: claude-3-7-sonnet-20250219)" // Optional. It defaults.
}
```

**Response:**
- **201 Created**
  ```json
  {
    "session_id": "string (uuid)",
    "session_name": "string",
    "workspace_id": "string (workspace_id provided in body)",
    "workspace": "string (workspace path provided in body)",
    "message": "Session created successfully"
  }
  ```
- **400 Bad Request**
  ```json
  {
    "detail": {
      "error": "Failed to create session due to invalid parameters",
      "detail": "Detailed message of the error"
    }
  }
  ```
- **500 Internal Server Error**
  ```json
  {
    "detail": {
      "error": "An unexpected error occurred while creating the session"
    }
  }
  ```

### `POST /sessions/session-chat/{session_id}`

**Description:**  
Process a chat message within a session.

**Path Parameter:**
- `session_id` (string, uuid): The unique identifier of the session.

**Request Body:**
```json
{
  "message": "string",
  "context": null,   // Optional. This properties will be further developed in next versions of the API.
  "metadata": null   // Optional. This properties will be further developed in next versions of the API.
}
```

**Response:**
- **200 OK**
  ```json
  {
    "success": "bool",
    "response": {
      "success": "bool",
      "content": "string", // The agent response message
      "metadata": {} // Dictionary containing all the metadata from the agent response.
    },
    "session_usage": {
        "total_cost": 0.010301,
        "total_tokens": 8094,
        "completion_tokens": 21,
        "prompt_tokens": 8073,
        "currency": "USD",
        "context_window": 272000,
        "total_usage_percentage": 0.0151
    }
  }
  ```

- **404 Not Found**
  ```json
  {
    "detail": {
      "error": "Session not found",
      "detail": "No session found with ID ${SESSION_ID}$"
    }
  }
  ```
- **500 Internal Server Error**
  ```json
  {
    "detail": {
      "error": "An unexpected error occurred while processing the message"
    }
  }
  ```

### `GET /sessions/{session_id}`

**Description:**  
Retrieve a specific session by its id.

**Path Parameter:**
- `session_id` (string, uuid): The unique identifier of the session.

**Response:**
- **200 OK**
  ```json
  {
    "id": "26994bf5-746a-4a64-b83b-ab2970db02cc",
    "name": "Session_20251230_155237",
    "workspace_id": "hash-number-one",
    "model_name": "gpt-5.1",
    "model_provider": "openai",
    "messages": [
        {"role": "system", "content": "system message"},
        {"role": "user", "content": "user message"}
    ]
  }
  ```

- **404 Not Found**
  ```json
  {
    "detail": {
      "error": "Session not found",
      "detail": "No session found with ID ${SESSION_ID}$"
    }
  }
  ```

### `GET /sessions/workspace/{workspace_id}`

**Description:**  
Retrieve all sessions associated to a `workspace_id`.

**Path Parameter:**
- `workspace_id` (string): The unique identifier of the workspace.

**Response:**
- **200 OK**
  ```json
  {
    "success": true,
    "workspace_id": "provided workspace_id",
    "sessions": [
        {
            "id": "26994bf5-746a-4a64-b83b-ab2970db02cc",
            "name": "Session_20251230_155237",
            "workspace_id": "provided workspace_id",
            "model_name": "gpt-5.1",
            "model_provider": "openai",
            "messages": [
                {"role": "system", "content": "system message"},
                {"role": "user", "content": "user message"}
            ]
        },
        ... // More session objects
    ]
  }
  ```

- **500 Internal Server Error**
  ```json
  {
    "detail": {
      "error": "An unexpected error occurred while listing sessions for workspace",
      "detail": "Error detail"
    }
  }
  ```

### `DELETE /sessions/{session_id}`

**Description:**  
Delete a specific session by its id.

**Path Parameter:**
- `session_id` (string, uuid): The unique identifier of the session.

**Response:**
- **200 OK**
  ```json
  {
    "success": True,
    "message": "Session {session_id} deleted successfully"
  }
  ```

- **404 Not Found**
  ```json
  {
    "detail": {
      "error": "Session not found",
      "detail": "No session found with ${session_id} or it could not be deleted"
    }
  }
  ```

- **500 Internal Server Error**
  ```json
  {
    "detail": {
      "error": "An unexpected error occurred while deleting the session",
      "detail": "Error detail"
    }
  }
  ```
