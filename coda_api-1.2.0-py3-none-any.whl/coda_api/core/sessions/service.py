from typing import Any, Dict, List, Union, Optional
from uuid import UUID, uuid4
from datetime import datetime
import copy

from loguru import logger
from coda_core.config.settings import SETTINGS, EnvConfig
from coda_core.core.session.utils import generate_session_name
from coda_core.core.session.states.shared_state import SharedState
from coda_core.core.agents.manager import AgentManager
from coda_core.core.memories.condenser import MemoryCondenser
from coda_core.core.utils.skill_loader import SkillLoader
from coda_core.core.metadata.metadata import extract_metadata
from coda_core.core.metadata.schemas import SessionMetadata

from coda_api.config.constants import CLIENT_NAME
from coda_api.config.service import ConfigService
from coda_api.core.providers.schemas import ProviderModel
from coda_api.core.providers.service import ProvidersService
from coda_api.core.sessions.repository.mapper import SessionsMapper
from coda_api.core.sessions.repository.models import APISession
from coda_api.core.callbacks.utils import create_callbacks_for_session
from coda_api.core.sessions.schemas import CreateSession, SessionChat, UpdateSession
from coda_api.core.sessions.repository.database import SESSIONS_DB_MANAGER
from coda_api.core.tools.service import tool_manager
from coda_api.core.sessions.states.api_client_state import APIClientState
from coda_api.core.mcp.service import MCPServerService


class SessionsService:
    """
    Sessions service. All operations related to session management should be handled here.
    """
    
    @staticmethod
    def _initialize_default_skills() -> None:
        """
        Initialize default skills for newly created sessions.
        Failures are intentionally swallowed so session creation can continue even
        if the one-off default skill copy step cannot be completed.
        """
        # Initialize default skills in the system-wide skills directory (~/.coda/skills).
        # The session_id is only used by SkillLoader for per-session disabled/removed
        # state tracking, which is not relevant for the one-off copy operation.
        try:
            SkillLoader().initialize_default_skills()
        except Exception as exc:
            logger.warning(f"Unable to initialize default skills during session creation: {exc}")

    @staticmethod
    def _normalize_optional_selection_value(value: Optional[str]) -> Optional[str]:
        """
        Normalize an optional provider/model value coming from the API payload.

        Blank strings should behave the same as omitted fields so existing clients
        can keep relying on the global model configuration.

        Args:
            value (Optional[str]): Raw selection value from the request.

        Returns:
            Optional[str]: Stripped string, or None when the input is blank/unset.
        """
        if not isinstance(value, str):
            return None

        normalized = value.strip()
        return normalized or None

    @staticmethod
    def _resolve_session_model_selection(
        session_data: CreateSession,
    ) -> tuple[str, str, bool]:
        """
        Resolve the provider/model pair to store on a new session.

        Sessions created without an explicit provider/model continue to follow the
        global configuration. Sessions created with an explicit provider/model are
        pinned to that selection.

        Args:
            session_data (CreateSession): The incoming session payload.

        Returns:
            tuple[str, str, bool]: Canonical provider name, model name, and whether
            the session should follow the global model configuration.

        Raises:
            ValueError: If the requested provider/model combination is invalid.
        """
        explicit_provider = SessionsService._normalize_optional_selection_value(
            session_data.model_provider_name
        )
        explicit_model = SessionsService._normalize_optional_selection_value(
            session_data.model_name
        )
        use_global_model_config = not (explicit_provider or explicit_model)

        if use_global_model_config:
            config_values = ConfigService.get_config_values()
            requested_provider = config_values.provider
            requested_model = config_values.model
        else:
            requested_provider = explicit_provider or SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_PROVIDER_NAME)
            requested_model = explicit_model or SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_MODEL_NAME)

        provider_model = ProviderModel(provider=requested_provider, model=requested_model)
        model = ProvidersService.get_model(provider_model)
        if model is None:
            raise ValueError(
                "Invalid provider/model combination for session creation: "
                f"{requested_provider}/{requested_model}"
            )

        canonical_provider = ProvidersService.get_canonical_provider_name(
            model=model,
            fallback=requested_provider,
        )
        return canonical_provider, model.name, use_global_model_config

    @staticmethod
    def create_session(session_data: CreateSession) -> APISession:
        """
        Create a new session and store it in the persistent database.

        Args:
            session_data (CreateSession): The data required to create the session.

        Returns:
            APISession: The newly created session object.

        Raises:
            ValueError: If the session creation fails due to invalid parameters.
            Exception: Generic exception if an error occurs during session saving in the database.
        """
        try:
            provider_name, model_name, use_global_model_config = SessionsService._resolve_session_model_selection(session_data)

            # Initialize a SharedState instance to keep track of the session's state: tools, agents, memory, etc.
            session_shared_state = SharedState()
            # Would be useful to allow this to be passed in the constructor of SharedState
            session_shared_state.provider_name = provider_name
            session_shared_state.model_name = model_name
            session_shared_state.single_agent_provider_name = provider_name
            session_shared_state.single_agent_model_name = model_name

            context = session_data.workspace_context.to_core_context()
            path = context.environment_context.workspace_path
            session_shared_state.load_user_defined_rules(cwd=path)

            # Initialize an AgentManager instance to manage subagents.
            session_agent_manager = AgentManager(session_shared_state)
            session_agent_manager.initialize_default_agents()

            SessionsService._initialize_default_skills()

            # Initialize APIClientState to store client-specific data
            api_client_state = APIClientState(
                workspace_id=session_data.workspace_id,
                workspace_context=session_data.workspace_context,
                use_global_model_config=use_global_model_config,
            )

            # Create the session with both SharedState and APIClientState
            session = APISession(
                id=uuid4(),
                name=f"Session_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                shared_state=session_shared_state,
                agent_manager=session_agent_manager,
                client_state=api_client_state  # Include the API client state
            )
        except Exception as e:
            logger.error(f"Error creating session components: {e}")
            raise ValueError(f"Failed to initialize session components: {e}")

        try:
            SESSIONS_DB_MANAGER.create_session(session)
        except Exception as e:
            logger.error(f"Error saving session: {session.id} to database: {e}")
            raise Exception("Failed to save session to the database.")

        try:
            MCPServerService.set_session_config_from_global_config(str(session.id))
        except Exception as e:
            logger.warning(f"Failed to initialize session-specific MCP config for {session.id}: {e}")

        logger.info(f"Created session '{session.name}' with ID {session.id}")
        return session

    @staticmethod
    def update_session(session: APISession, session_update: UpdateSession):
        """
        Update an existing session's fields.

        Args:
            session (APISession): The session to update.
            session_update (UpdateSession): The session update data. This schema includes:
                - name (str): The new name for the session.

        Raises:
            Exception: If there is an error updating the session.
        """
        try:
            success = SESSIONS_DB_MANAGER.update_session(session, session_update)
            if not success:
                raise ValueError(f"Session: {session.id} update failed.")
            # Apply the in-memory operation for the later DTO mapping.
            session.name = session_update.name
        except Exception as e:
            logger.error(f"Error updating session {session.id}: {e}")
            raise e

    @staticmethod
    def session_exists(session_id: UUID) -> Optional[APISession]:
        """
        Check if a session exists by its ID and return it.

        Args:
            session_id (UUID): The ID of the session to check.

        Returns:
            Optional[APISession]: The session if it exists, None otherwise.
        """
        return SESSIONS_DB_MANAGER.get_session(session_id)

    @staticmethod
    def _extract_session_metadata(session: APISession) -> Optional[Dict[str, Any]]:
        """
        Extract metadata from an API session for passing to coda-core agents.
        
        This method creates a SessionMetadata Pydantic object from the session
        information and converts it to a dictionary format expected by coda-core.
        
        Args:
            session (APISession): The session from which to extract metadata.
        
        Returns:
            Optional[Dict[str, Any]]: Dictionary containing session metadata,
            or None if extraction fails.
        
        """
        try:
            # Create Pydantic input object with required fields
            metadata_input = SessionMetadata(
                client=CLIENT_NAME,               # "API"
                session_id=str(session.id),       # Convert UUID to string
                task_id=session.name              # Use session name as task_id
            )
            
            # Extract metadata (returns a dictionary with transformations applied)
            metadata = extract_metadata(metadata_input)
            logger.debug(f"Extracted metadata for session {session.id}: {metadata}")
            
            return metadata
            
        except Exception as e:
            logger.warning(
                f"Failed to extract metadata for session {session.id}: {e}. "
                "Continuing without metadata."
            )
            return None

    @staticmethod
    def process_chat(session: APISession, session_chat: SessionChat) -> Dict[str, Union[str, Dict[str, Any]]]:
        """
        Process a chat message within a session.

        Args:
            session (APISession): The session in which the chat is taking place.
            session_chat (SessionChat): The chat message and associated data.

        Returns:
            (Dict[str, Union[str, Dict[str, Any]]]): A dictionary containing all the metadata related to the
                agent processing of the message.

        Raises:
            ValueError: If the chat message processing fails or the session cannot be saved.
        """
        # Before initializing the agent update the Session model settings and memory condensing if needed
        SessionsService.update_model_settings_if_needed(session)

        if session.shared_state.main_agent is None:
            # Initialize the main agent for the session if not already done
            session.shared_state.main_agent = session.shared_state.create_configured_single_agent(
                workspace_context=session.client_state.workspace_context.to_core_context()
            )

        # Once the agent has been initialized we update tools and MCPs if needed.
        SessionsService.update_model_transitions_if_needed(session)

        session_callbacks = create_callbacks_for_session(session)
        
        # Extract metadata once for the entire session interaction
        metadata = SessionsService._extract_session_metadata(session)
        
        # This parses user messages based on the @ syntax
        agent_calls = session.agent_manager.parse_user_message(session_chat.message)

        # Process the chat message with guaranteed session persistence
        response = None
        try:
            if not agent_calls: # No agent calls, we use the main agent
                response = session.shared_state.main_agent.get_response(
                    user_message=session_chat.message,
                    callbacks=session_callbacks,
                    metadata_param=metadata
                )
            else:
                # Initialize the subagent_response with a default value
                subagent_response: Dict[str, Any] = {"success": False, "content": "No subagent was called successfully."}
                # Process subagent calls (since they can be chained in one line like this: `@diagnose X @fix`)
                for agent_call in agent_calls:
                    agent_name = agent_call.get("agent_name")
                    if not agent_name:
                        continue
                    agent_args = agent_call.get("user_input")

                    # Get context from main agent memory for subagent
                    messages_for_subagent = SessionsService._format_context_for_subagent(session, agent_args)

                    agent_definition = session.agent_manager.load_agent_metadata(agent_name)

                    if agent_definition:
                        # Local agent — standard flow
                        subagent = session.agent_manager.create_agent(
                            agent_name=agent_name,
                            agent_definition=agent_definition,
                            workspace_context=session.client_state.workspace_context.to_core_context()
                        )
                    else:
                        # Check if it's a visible remote agent
                        remote_agent_names = {
                            a.name for a in session.agent_manager.list_visible_remote_agents()
                        }
                        if agent_name not in remote_agent_names:
                            logger.warning(f"Agent '{agent_name}' not found locally or as a visible remote agent. Skipping.")
                            continue

                        # Remote agent — use GEAI proxy
                        logger.info(f"Invoking remote GEAI agent '{agent_name}'")
                        subagent = session.agent_manager.create_remote_geai_agent(name_or_id=agent_name)

                    # Inform the main agent that a subagent is being called
                    main_agent_user_message = f"Subagent called {agent_name} processed this input: {agent_args}"
                    session.shared_state.main_agent.memory.add_user_message(main_agent_user_message)

                    # Process message with subagent and inform the main agent based on the result
                    is_remote = agent_definition is None
                    subagent_response = subagent.get_response(
                        user_message=messages_for_subagent,
                        callbacks=session_callbacks,
                        metadata_param=metadata
                    )

                    if is_remote:
                        try:
                            session.shared_state.record_agent_interaction(
                                agent_name=agent_name,
                                user_input=agent_args,
                                result=subagent_response,
                                remote=True,
                            )
                        except Exception as exc:
                            logger.debug(f"Failed to record remote agent interaction: {exc}")

                    if subagent_response.get("success", False):
                        # Subagent managed to process the input
                        main_agent_assistant_message = f"Subagent called {agent_name} returned this result: {subagent_response['content']}"
                        session.shared_state.main_agent.memory.add_assistant_message(main_agent_assistant_message)
                    else:
                        # Subagent failed to process the input
                        session.shared_state.main_agent.memory.add_assistant_message(f"Subagent called {agent_name} failed to process the input.")

                # Set the latest subagent response, for chain cases if we do @diagnose X issue @fix we'll return only the @fix response.
                response = subagent_response

            # Try to automatically rename the session after processing but before saving
            try:
                SessionsService.try_automatic_rename(session)
            except Exception as e:
                logger.error(f"Failed to automatically rename session {session.id}: {e}")
        finally:
            # Always save the session state, even on interruptions or exceptions
            # This ensures session persistence and correct state regardless of how processing ends
            SESSIONS_DB_MANAGER.save_session(session)

        return response

    @staticmethod
    def get_user_messages(session: APISession) -> List[Dict[str, str]]:
        """
        Retrieve the user messages of a session chat history.

        Args:
            session (APISession): The session from which to retrieve user messages.

        Returns:
            List[Dict[str, str]]: A list of user messages in the session.
        """
        user_messages = []
        if session.shared_state.main_agent and session.shared_state.main_agent.memory:
            for message in session.shared_state.main_agent.memory.retrieve():
                if message.get("role") == "user" and (message_content := message.get("content")):
                        if isinstance(message_content, str):
                            user_messages.append(message)
                        elif isinstance(message_content, list):
                            # Compatibility with Responses API formats
                            parsed_content = ""
                            for message_item in message_content:
                                if (
                                    isinstance(message_item, dict) and
                                    message_item.get("type") == "input_text" and
                                    "text" in message_item
                                ):
                                    parsed_content += message_item["text"] + " "

                            if parsed_content:
                                modified_message: Dict[str, Any] = copy.deepcopy(message) # message is a dict
                                modified_message["content"] = parsed_content.strip()
                                user_messages.append(modified_message)

        return user_messages

    @staticmethod
    def can_rename_session(session: APISession, user_messages: List) -> bool:
        """
        Check if a session can be automatically renamed. A session can be automatically renamed
        if it has not been renamed before by any sort of method and has at least 1 user message.

        Args:
            session (APISession): The session to check.
            user_messages (List): The list of user messages in the session.

        Returns:
            bool: True if the session can be renamed, False otherwise.
        """
        return not session.rename_method and not session.last_changed and len(user_messages) >= 1

    @staticmethod
    def try_automatic_rename(session: APISession):
        """
        Attempt to automatically rename a session.

        Args:
            session (APISession): The session to potentially rename.

        Raises:
            Exception: If automatic renaming fails.
        """
        user_messages = SessionsService.get_user_messages(session)
        if SessionsService.can_rename_session(session, user_messages):
            result = generate_session_name(
                user_messages=user_messages,
                geai_client=session.shared_state.geai_client,
                model_name=SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SMALL_MODEL_NAME),
                provider_name=SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SMALL_PROVIDER_NAME)
            )

            # Add usage statistics to shared state
            if (llm_usage := result.get("usage", None)):
                session.shared_state.add_usage(llm_usage)
                logger.info(f"Added LLM usage from session name generation to usage statistics: {llm_usage}")

            if result.get("status") == "success":
                update_session = UpdateSession(name=result["name"])
                update_session.rename_method = "auto"
                SessionsService.update_session(session, update_session)
            else:
                result_error = result.get("error", None)
                raise Exception(f"Automatic renaming failed: {result_error or 'Unknown error'}")

    @staticmethod
    def list_workspace_sessions(workspace_id: str) -> List[Dict[Any, Any]]:
        """
        List sessions filtered by workspace.

        Args:
            workspace_id (str): The ID of the workspace to filter sessions by.

        Returns:
            List[Dict[Any, Any]]: A list of session data dictionaries that belong to the specified workspace.
        """
        workspace_sessions = []
        for session_data in SESSIONS_DB_MANAGER.list_sessions():
            try:
                if (clients_states := session_data.get("client_states", None)):
                    if CLIENT_NAME in clients_states and (api_state := clients_states[CLIENT_NAME]):
                        api_state = APIClientState.from_dict(api_state)
                        if api_state.workspace_id == workspace_id:
                            # Map the dict-like data to a DTO model.
                            session_dto = SessionsMapper.map_core_dict_to_dto(session_data)
                            if api_state.use_global_model_config:
                                session_dto["model_name"] = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_MODEL_NAME)
                                session_dto["model_provider"] = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_PROVIDER_NAME)
                            workspace_sessions.append(session_dto)
            except Exception as e:
                logger.warning(f"Error processing session data for workspace filtering: {e}")
                continue

        return workspace_sessions

    @staticmethod
    def delete_session(session_id: UUID) -> bool:
        """
        Delete a session.

        Args:
            session_id (UUID): The ID of the session to delete.

        Returns:
            bool: True if the session was deleted, False otherwise.
        """
        return SESSIONS_DB_MANAGER.delete_session(session_id)

    @staticmethod
    def update_model_settings_if_needed(session: APISession):
        """
        Perform a pre-flight update of a session's model settings based on the current global configuration.

        The updates performed are:
            - Model and provider if they differ from the global config
            - Memory condensing settings if they differ from the global config

        Args:
            session (APISession): The session to update.
        """
        config_values = ConfigService.get_config_values()

        session_provider_name = ProvidersService.normalize_provider_name(
            session.shared_state.single_agent_provider_name
        )
        config_provider_name = ProvidersService.normalize_provider_name(config_values.provider)

        if session.client_state.use_global_model_config and (
            session.shared_state.single_agent_model_name != config_values.model or
            session_provider_name != config_provider_name
        ):
            model = ProvidersService.get_model(
                ProviderModel(provider=config_values.provider, model=config_values.model)
            )
            if model is None:
                logger.warning(
                    "Skipping model update for session {} because the configured "
                    "provider/model could not be resolved: {}/{}",
                    session.id,
                    config_values.provider,
                    config_values.model,
                )
            else:
                canonical_provider = ProvidersService.get_canonical_provider_name(
                    model=model,
                    fallback=config_values.provider,
                )
                session.shared_state.update_model_settings(
                    provider_name=canonical_provider,
                    model_name=model.name,
                    context_window=model.context_window,
                    max_output_tokens=model.max_output_tokens,
                    single_agent=session.shared_state.main_agent
                )
                logger.info(
                    f"Updated session {session.id} model settings to provider: "
                    f"{canonical_provider}, model: {model.name}"
                )

        # Compare against memory condensing
        if session.shared_state.main_agent is not None:
            if config_values.memory_condensing_enabled:
                if session.shared_state.main_agent.memory.condenser is None:
                    session.shared_state.main_agent.memory.condenser = MemoryCondenser(threshold=config_values.memory_condensing_threshold)
                else:
                    session.shared_state.main_agent.memory.condenser.threshold = config_values.memory_condensing_threshold
                logger.info(f"Enabled memory condensing for session {session.id} with threshold: {config_values.memory_condensing_threshold}")
            else:
                logger.info(f"Disabling memory condensing for session {session.id}")
                session.shared_state.main_agent.memory.condenser = None

    @staticmethod
    def update_model_transitions_if_needed(session: APISession):
        """
        Perform a pre-flight update of a session's agent tools and MCP tools based on the current global state.

        The transitions performed are:
            - Agent tools if they differ from the global tool manager's enabled tools. These tools are tied to the
                SharedState's tool manager. So the comparison is done against that.
            - MCP tools if they differ from the global MCP configuration tools. These tools are tied to a session ID.
                So the comparison is done against that.

        Once updates are made, the session is saved to the database in order to reflect the correct
        agent memory message history.

        Args:
            session (APISession): The session to update.
        """
        if session.shared_state.main_agent is not None:
            had_changes = False

            # Compare tools
            enabled_tools = tool_manager.get_enabled_tools() # Enabled tools will always be compared against global config.
            current_enabled_names = set(t.name for t in enabled_tools)
            # Retrieve the current configuration for the session's tool manager.
            agent_current_names = set(t.name for t in session.shared_state.tool_manager.get_enabled_tools())

            if current_enabled_names != agent_current_names:
                logger.info(f"Updating session {session.id} agent with enabled tools: {current_enabled_names}")
                session.shared_state.main_agent.update_agent_with_tool_changes(
                    updated_tools=enabled_tools
                )

                tools_to_enable = current_enabled_names - agent_current_names  # In global but not in agent
                tools_to_disable = agent_current_names - current_enabled_names  # In agent but not in global

                # Reflect the changes in the sessions' tool manager with the updates generated from the global config.
                for tool_name in tools_to_enable:
                    session.shared_state.tool_manager.enable_tool(tool_name)
                    logger.info(f"Enabled tool '{tool_name}' in session {session.id}")

                for tool_name in tools_to_disable:
                    session.shared_state.tool_manager.disable_tool(tool_name)
                    logger.info(f"Disabled tool '{tool_name}' in session {session.id}")

                had_changes = True

            # Compare MCPs
            try:
                added_servers, removed_servers = MCPServerService.compare_session_config_against_global(str(session.id))
                if added_servers or removed_servers:
                    logger.info(f"Updating session {session.id} agent with enabled MCPs - Added: {added_servers}, Removed: {removed_servers}")
                    session.shared_state.main_agent.handle_mcp_transition(added_servers, removed_servers)
                    # Save session-specific MCP config to match with global.
                    MCPServerService.set_session_config_from_global_config(str(session.id))
                    had_changes = True
            except Exception as e:
                logger.error(f"Error updating MCP tools for session {session.id}: {e}")

            # Compare skills
            try:
                from coda_api.core.skills.service import SkillsService
                skills_changed = SkillsService.detect_skill_changes(session)
                if skills_changed:
                    session.shared_state.main_agent.update_system_prompt()
                    had_changes = True
            except Exception as e:
                logger.error(f"Error updating skills for session {session.id}: {e}")

            # Only save to the database if we actually had changes.
            if had_changes:
                try:
                    SESSIONS_DB_MANAGER.save_session(session)
                except Exception as e:
                    logger.error(f"Error saving session {session.id} after tool/MCP update: {e}")

    @staticmethod
    def get_session_usage_summary(session: APISession) -> Dict[str, Any]:
        """
        Get the usage summary for a session.

        Args:
            session (APISession): The session for which to get the usage summary.

        Returns:
            (Dict[str, Any]): A dictionary containing the usage summary with the following keys:
                - total_cost (float): Total cost in USD of the session so far.
                - total_tokens (int): Total number of tokens used in the session.
                - completion_tokens (int): Number of tokens used for completions.
                - prompt_tokens (int): Number of tokens used for prompts.
                - currency (str): Currency used for cost calculation. Defaults to "USD"
                - context_window (int): Size of the context window.
                - total_usage_percentage (float): Percentage of the context window used. Rounded to 4 decimals.
        """
        try:
            usage_summary = session.shared_state.get_usage_summary()
            usage_summary.update(session.shared_state.get_context_window_usage())
            if total_usage_percentage := usage_summary.get("total_usage_percentage"):
                usage_summary["total_usage_percentage"] = round(total_usage_percentage, 4)

            return usage_summary
        except Exception as e:
            logger.error(f"Error getting summary for session: {session.id}: {e}")
            # Return an empty dictionary in case of error
            return {}
    
    @staticmethod
    def _format_context_for_subagent(session: APISession, agent_args: str) -> str:
        """
        Format recent conversation context for subagent processing.
        
        Args:
            session (APISession): The session containing the main agent memory.
            agent_args (str): The current user input for the subagent.
            
        Returns:
            str: Formatted context string for the subagent.
        """
        # Get the most recent messages from memory
        messages = session.shared_state.main_agent.memory.retrieve()

        # Get the last 3 message pairs (user + assistant)
        message_pairs = [
            (msg, next_msg) 
            for msg, next_msg in zip(messages, messages[1:])
            if msg["role"] == "user" and next_msg["role"] == "assistant"
        ]
        recent_pairs = message_pairs[-3:] if len(message_pairs) >= 3 else message_pairs

        # Format the messages
        messages_for_subagent = ""
        for i, (user_msg, assistant_msg) in enumerate(recent_pairs, 1):
            messages_for_subagent += f"<message{i}>\n"
            messages_for_subagent += f"User: {user_msg['content']}\n"
            messages_for_subagent += f"Assistant: {assistant_msg['content']}\n"
            messages_for_subagent += f"</message{i}>\n\n"

        return f"Previous conversation for context:\n{messages_for_subagent}\n\nCurrent User: {agent_args}"
