from uuid import UUID

import time
from fastapi import APIRouter, Depends, status
from fastapi.requests import Request
from fastapi.exceptions import HTTPException
from fastapi.responses import JSONResponse
from loguru import logger

from coda_api.core.dependencies import credentials_set
from coda_api.core.sessions.repository.mapper import SessionsMapper
from coda_api.core.sessions.service import SessionsService
from coda_api.core.sessions.schemas import CreateSession, SessionChat, UpdateSession
from coda_api.core.sessions.utils import process_chat_with_cancellation


sessions_router = APIRouter(
    prefix="/sessions",
    tags=["sessions"],
    dependencies=[
        Depends(credentials_set) # All the sessions endpoints require the GEAI credentials to be set.
    ]
)


@sessions_router.post("/create-session")
async def create_session(request: Request, session: CreateSession):
    """
    Create a new session.

    Args:
        request (Request): The FastAPI request object.
        session (CreateSession): The session data required to create a new session. This schema includes:
            - workspace_id (str): The unique identifier of the workspace.
            - workspace_context (WorkspaceContextDTO): The context information for the workspace associated with the session.
            - model_provider_name (str): The name of the model provider. Defaults to the `coda-core` default provider.
            - model_name (str): The name of the model to be used in the session. Defaults to the `coda-core` default model.

    Returns:
        JSONResponse: A response containing the following keys:
            - session_id (str): The unique identifier of the created session.
            - session_name (str): The name of the created session.
            - workspace (str): The workspace path associated with the session.
            - message (str): A success message.

    Raises:
        HTTPException:
            - status.HTTP_400_BAD_REQUEST: If the session creation fails due to invalid parameters.
            - status.HTTP_403_FORBIDDEN: If the credentials are not set.
            - status.HTTP_500_INTERNAL_SERVER_ERROR: If the session creation fails due to an unexpected error.
    """
    try:
        new_session = SessionsService.create_session(session)
        return JSONResponse(
            content={
                "session_id": str(new_session.id),
                "session_name": new_session.name,
                "workspace_id": new_session.client_state.workspace_id,
                "workspace": new_session.client_state.workspace_context.environment_context.workspace_path,
                "message": "Session created successfully"
            },
            status_code=status.HTTP_201_CREATED
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "Failed to create session due to invalid parameters",
                "detail": str(e)
            }
        )
    except Exception as e:
        logger.exception(f"Unexpected error creating session: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "An unexpected error occurred while creating the session"}
        )


@sessions_router.put("/{session_id:uuid}")
def update_session(request: Request, session_id: UUID, session_update: UpdateSession):
    """
    Update an existing session's fields.

    Args:
        request (Request): The FastAPI request object.
        session_id (UUID): The unique identifier of the session to be updated.
        session_update (UpdateSession): The session update data. This schema includes:
            - name (str): The new name for the session.

    Returns:
        JSONResponse: A response containing the updated session data. This data includes:
            - id (str): The unique identifier of the session.
            - name (str): The name of the session.
            - workspace_id (str): The unique identifier of the workspace associated with the session.
            - model_name (str): The name of the model used in the session.
            - model_provider (str): The name of the model provider used in the session.
            - messages (List[Dict[str, Any]]): A list of messages exchanged in the session.
    """
    session = SessionsService.session_exists(session_id)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "Session not found",
                "detail": f"No session found with ID {session_id}"
            }
        )

    try:
        SessionsService.update_model_settings_if_needed(session)
        SessionsService.update_session(session, session_update)
        return SessionsMapper.map_api_to_dto(session)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "An unexpected error occurred while updating the session",
                "detail": str(e)
            }
        )

@sessions_router.post("/session-chat/{session_id:uuid}")  
async def session_chat(request: Request, session_id: UUID, session_chat: SessionChat):
    """
    Process a chat message within a session.

    Args:
        request (Request): The FastAPI request object.
        session_id (UUID): The unique identifier of the session.
        session_chat (SessionChat): The chat message and associated data.

    Returns:
        JSONResponse: A response containing the complete agent answer. The response will include:
            - success (bool): Indicates whether the message processing was successful.
            - response (Dict[str, Union[str, Dict[str, Any]]]): The complete response from the agent.
            - session (Dict[str, Any]): Session details including:
                - id (str): The unique identifier of the session.
                - name (str): The name of the session.
                - workspace_id (str): The unique identifier of the workspace associated with the session.
                - model_name (str): The name of the model used in the session.
                - model_provider (str): The name of the model provider used in the session.
                - messages (List[Dict[str, Any]]): A list of messages exchanged in the session. 
            - session_usage (Dict[str, Any]): A summary of the session's usage statistics. This includes:
                - total_cost (float): Total cost in USD of the session so far.
                - total_tokens (int): Total number of tokens used in the session.
                - completion_tokens (int): Number of tokens used for completions.
                - prompt_tokens (int): Number of tokens used for prompts.
                - currency (str): Currency used for cost calculation. Defaults to "USD".
                - context_window (int): Size of the context window.
                - total_usage_percentage (float): Percentage of the context window used. Rounded to 4 decimals.

    Raises:
        HTTPException:
            - status.HTTP_403_FORBIDDEN: If the credentials are not set.
            - status.HTTP_404_NOT_FOUND: If the session with the provided ID does not exist.
            - status.HTTP_500_INTERNAL_SERVER_ERROR: If an unexpected error occurs.
    """
    if not (session := SessionsService.session_exists(session_id)):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "Session not found",
                "detail": f"No session found with ID {session_id}"
            }
        )

    try:
        # Use utility function to handle async cancellation
        agent_response = await process_chat_with_cancellation(
            request=request,
            session=session,
            session_chat=session_chat,
            session_id=session_id
        )
        
        return {
            "success": agent_response.get("success", False),
            "response": agent_response,
            "session": SessionsMapper.map_api_to_dto(session),
            "session_usage": SessionsService.get_session_usage_summary(session)
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "An unexpected error occurred while processing the message",
                "detail": str(e)
            }
        )


@sessions_router.get("/{session_id:uuid}")
async def get_session(request: Request, session_id: UUID):
    """
    Get a specific session by ID.

    Args:
        request (Request): The FastAPI request object.
        session_id (UUID): The unique identifier of the session.

    Returns:
        JSONResponse: A response containing the session data. This data includes:
            - id (str): The unique identifier of the session.
            - name (str): The name of the session.
            - workspace_id (str): The unique identifier of the workspace associated with the session.
            - model_name (str): The name of the model used in the session.
            - model_provider (str): The name of the model provider used in the session.
            - messages (List[Dict[str, Any]]): A list of messages exchanged in the session.
            - session_usage (Dict[str, Any]): A summary of the session's usage statistics. This includes:
                - total_cost (float): Total cost in USD of the session so far.
                - total_tokens (int): Total number of tokens used in the session.
                - completion_tokens (int): Number of tokens used for completions.
                - prompt_tokens (int): Number of tokens used for prompts.
                - currency (str): Currency used for cost calculation. Defaults to "USD".
                - context_window (int): Size of the context window.
                - total_usage_percentage (float): Percentage of the context window used. Rounded to 4 decimals.

    Raises:
        HTTPException:
            - status.HTTP_404_NOT_FOUND: If the session with the provided ID does not exist.
            - status.HTTP_500_INTERNAL_SERVER_ERROR: If an unexpected error occurs during retrieval.
    """
    session = SessionsService.session_exists(session_id)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "Session not found",
                "detail": f"No session found with ID {session_id}"
            }
        )

    try:
        SessionsService.update_model_settings_if_needed(session)
        session_data = SessionsMapper.map_api_to_dto(session)
        # For specific session-id retrieval include the session usage statistics
        session_data["session_usage"] = SessionsService.get_session_usage_summary(session)
        return session_data
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "An unexpected error occurred while retrieving the session",
                "detail": str(e)
            }
        )


@sessions_router.get("/workspace/{workspace_id}")
async def list_workspace_sessions(request: Request, workspace_id: str):
    """
    List sessions filtered by a specific workspace ID.

    Args:
        request (Request): The FastAPI request object.
        workspace_id (str): The unique identifier of the workspace.

    Returns:
        JSONResponse: A response containing the list of sessions for the specified workspace id. This data includes:
        - success (bool): Indicates whether the listing was successful.
        - workspace_id (str): The unique identifier of the workspace.
        - sessions (List[Dict[str, Any]]): A list of session data. Each entry contains:
            - id (str): The unique identifier of the session.
            - name (str): The name of the session.
            - workspace_id (str): The unique identifier of the workspace associated with the session.
            - model_name (str): The name of the model used in the session.
            - model_provider (str): The name of the model provider used in the session.
            - messages (List[Dict[str, Any]]): A list of messages exchanged in the session.
    """
    try:
        sessions = SessionsService.list_workspace_sessions(workspace_id)
        return {
            "success": True,
            "workspace_id": workspace_id,
            "sessions": sessions
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "An unexpected error occurred while listing sessions for workspace",
                "detail": str(e)
            }
        )


@sessions_router.delete("/{session_id}")
def delete_session(request: Request, session_id: UUID):
    """
    Delete a session.

    Args:
        request (Request): The FastAPI request object.
        session_id (UUID): The ID of the session to delete.

    Returns:
        JSONResponse: A response indicating whether the session was deleted.
    """
    try:
        if SessionsService.delete_session(session_id):
            return {
                "success": True,
                "message": f"Session {session_id} deleted successfully"
            }
        else:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "error": "Session not found",
                    "detail": f"No session found with ID {session_id} or it could not be deleted"
                }
            )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "An unexpected error occurred while deleting the session",
                "detail": str(e)
            }
        )
