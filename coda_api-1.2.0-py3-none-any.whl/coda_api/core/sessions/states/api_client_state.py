from typing import Any, Dict


from pydantic import ValidationError
from loguru import logger
from coda_core.core.session.states.client_state import ClientState

from coda_api.config.constants import CLIENT_NAME
from coda_api.core.context.schemas import WorkspaceContextDTO


class APIClientState(ClientState):
    """
    APIClientState class representing the state of an API client session.
    """

    CLIENT_TYPE = CLIENT_NAME

    def __init__(
        self,
        workspace_id: str,
        workspace_context: WorkspaceContextDTO,
        use_global_model_config: bool = True,
    ):
        """
        Initialize an `APIClientState` instance.

        Args:
            workspace_id (str): The unique identifier of the workspace.
            workspace_context (WorkspaceContextDTO): The context of the workspace needed for a session in CODA API.
            use_global_model_config (bool): Whether this session should keep following
                the current global provider/model configuration.

        Raises:
            ValueError: If any of the data provided is invalid.
        """
        if not isinstance(workspace_id, str) or not workspace_id:
            raise ValueError("`workspace_id` must be a non-empty string")

        if not isinstance(workspace_context, WorkspaceContextDTO):
            raise ValueError("`workspace_context` must be an instance of WorkspaceContextDTO")

        if not isinstance(use_global_model_config, bool):
            raise ValueError("`use_global_model_config` must be a boolean")

        self.workspace_id = workspace_id
        self.workspace_context = workspace_context
        self.use_global_model_config = use_global_model_config

    def to_dict(self) -> Dict[str, Any]:
        """
        Generate a dictionary representation of the `APIClientState` instance.

        Returns:
            (Dict[str, Any]) containing all the `APIClientState` data. This includes the keys:
            - `workspace_id` containing the unique identifier of the workspace.
            - `workspace_context` containing the json representation of the `WorkspaceContextDTO` schema.
            - `use_global_model_config` indicating whether the session should follow
              the current global provider/model configuration.
        """
        return {
            "workspace_id": self.workspace_id,
            "workspace_context": self.workspace_context.model_dump(),
            "use_global_model_config": self.use_global_model_config,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "APIClientState":
        """
        Initialize an `APIClientState` instance from a dictionary.

        Args:
            data (Dict[str, Any]): Dictionary containing the data to initialize the `APIClientState`. The required keys are:
            - `workspace_id` key is required and must be a non-empty string.
            - `workspace_context` key is required and the data will be validated through the `WorkspaceContextDTO` schema.

        Raises:
            KeyError: If any of the required keys are missing in the provided data.
            ValidationError: If the provided data fails validation through the `WorkspaceContextDTO` schema.
            ValueError: If any of the data provided is invalid during the initialization of the `APIClientState`.
        """
        try:
            workspace_context = WorkspaceContextDTO(**data["workspace_context"]) 
            return cls(
                workspace_id=data["workspace_id"],
                workspace_context=workspace_context,
                use_global_model_config=data.get("use_global_model_config", True),
            )
        except KeyError as e:
            logger.error(f"Missing required key for APIClientState: {e}")
            raise
        except ValueError as e:
            logger.error(f"Invalid value provided for APIClientState: {e}")
            raise
        except ValidationError as e:
            logger.error(f"Validation error for APIClientState: {e}")
            raise
