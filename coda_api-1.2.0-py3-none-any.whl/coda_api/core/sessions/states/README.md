# States

This module provides an entry point to define client-specific states associated to sessions.

## What are States?
States are useful to store relevant data strictly coupled to the client utilizing a session. In the case of the CODA API metadata related to the workspace is stored in the state.

## Components
[api_client_state](/coda_api/core/sessions/states/api_client_state.py): This component defines the `APIClientState` class, used to represent an specific state associated to a session in the context of the CODA API.

## APIClientState
The `APIClientState` class is used to centralize information related to a session in the CODA API. For now it holds information such as:
- `workspace_id`: ID of the workspace associated to the session. This data is usually provided by the CODA API clients.
- `WorkspaceContextDTO`: Workspace context information. This data is key for sessions and agents to work in an specific workspace context.

For more details check the docstrings of the class.