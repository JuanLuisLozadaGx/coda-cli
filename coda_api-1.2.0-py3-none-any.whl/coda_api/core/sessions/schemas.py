from typing import Any, Optional
from enum import StrEnum

from pydantic import BaseModel

from coda_api.core.context.schemas import WorkspaceContextDTO


class SessionRenameMethod(StrEnum):
    """
    Enum representing the available renaming methods of a Session.
    """
    MANUAL = "manual"
    AUTO = "auto"


class CreateSession(BaseModel):
    """
    CreateSession schema for creating a new session.

    Attributes:
        workspace_id (str): The unique identifier of the workspace.
        workspace_context (WorkspaceContextDTO): The context of the workspace associated with the session.
        model_provider_name (Optional[str]): Optional provider name. When omitted,
            the session follows the current global provider/model configuration.
        model_name (Optional[str]): Optional model name. When omitted, the session
            follows the current global provider/model configuration.
    """
    workspace_id: str
    workspace_context: WorkspaceContextDTO
    model_provider_name: Optional[str] = None
    model_name: Optional[str] = None


class UpdateSession(BaseModel):
    """
    UpdateSession schema for updating existing session fields.

    Attributes:
        name (str): The new name for the session.
    """
    name: str
    _rename_method: str = "manual"

    @property
    def rename_method(self) -> str:
        """
        The _rename_method is a private property of the `UpdateSession` schema used only internally in the coda-api.

        Returns:
            str: The rename method. Value is based on the `SessionRenameMethod` enum.
        """
        return self._rename_method

    @rename_method.setter
    def rename_method(self, method: str) -> None:
        """
        Set the rename method for the session update.

        Args:
            method (str): The rename method. Value should be one of the `SessionRenameMethod` enum values.

        Raises:
            ValueError: If the method is not a valid `SessionRenameMethod` value.
        """
        self._rename_method = SessionRenameMethod(method).value


class SessionChat(BaseModel):
    """
    SessionChat schema for sending messages in a session.

    Attributes:
        message (str): The message to be sent in the session.
        context (Any): Optional context for the message, such as files or additional data.
        metadata (Any): Optional metadata for the message, such as images or other relevant information.
    """
    message: str
    context: Any = None     # TODO: leave for the future. Context (files) can be here.
    metadata: Any = None    # TODO: leave for the future. Images can be here.
