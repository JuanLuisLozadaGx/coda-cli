"""
Utility functions for session management and cancellation handling.
"""

import asyncio
import time
from uuid import UUID
from typing import Dict, Any, Union
from fastapi import Request, HTTPException

from loguru import logger

from coda_api.core.sessions.service import SessionsService
from coda_api.core.sessions.repository.models import APISession
from coda_api.core.sessions.schemas import SessionChat
from coda_api.core.sessions.interruptor import SessionInterruptors

INTERRUPTION_TIMEOUT = 30.0


async def process_chat_with_cancellation(
    request: Request,
    session: APISession, 
    session_chat: SessionChat,
    session_id: UUID
) -> Dict[str, Union[str, Dict[str, Any]]]:
    """
    Process a chat message with async cancellation support.
    
    This function handles:
    - Concurrent execution of chat processing and disconnection monitoring
    - Thread interruption via KeyboardInterrupt injection when client disconnects
    - HTTP 499 responses for client disconnection
    
    The interruption mechanism works by:
    1. Creating a ThreadInterruptor for the session
    2. Registering the worker thread when it starts
    3. Injecting KeyboardInterrupt into the thread when disconnect is detected
    4. SingleAgent's existing KeyboardInterrupt handling does the cleanup (including orphaned tool calls)
    
    Args:
        request (Request): FastAPI request object for disconnect monitoring
        session (APISession): Session object for processing
        session_chat (SessionChat): Chat message data
        session_id (UUID): Session ID for logging
        
    Returns:
        Dict[str, Union[str, Dict[str, Any]]]: Chat processing response
        
    Raises:
        HTTPException: HTTP 499 if client disconnects or cancellation occurs
    """
    
    # Create an interruptor for this session to enable thread interruption
    interruptor = SessionInterruptors.create(session_id)
    
    # Function to execute process_chat in thread with interruption support
    def run_process_chat():
        # Register this thread for potential interruption
        interruptor.register_thread()
        try:
            return SessionsService.process_chat(session, session_chat)
        except KeyboardInterrupt:
            # This is the expected path when interrupt() is called
            # Note: SingleAgent automatically handles orphaned tool calls cleanup
            logger.info(f"Session {session_id} agent execution interrupted via KeyboardInterrupt")
            return {"success": False, "content": "Process interrupted by user", "cancelled": True}
        except Exception as e:
            if interruptor.was_interrupted:
                logger.info(f"Session {session_id} processing cancelled via interruptor")
                return {"success": False, "content": "Request was cancelled by client", "cancelled": True}
            raise e
        finally:
            # Always unregister the thread when done
            interruptor.unregister_thread()
    
    # Execute process_chat with client disconnection monitoring
    try:
        process_task = asyncio.create_task(asyncio.to_thread(run_process_chat))
        interruption_start_time = None
        
        # Monitor for client disconnection while process_chat runs
        while not process_task.done():
            if await request.is_disconnected():
                if interruption_start_time is None:
                    logger.info(f"Client disconnected for session {session_id}, triggering interruption")
                    SessionInterruptors.interrupt(session_id)
                    interruption_start_time = time.time()
                else:
                    elapsed = time.time() - interruption_start_time
                    if elapsed > INTERRUPTION_TIMEOUT:
                        logger.error(
                            f"Session {session_id} failed to interrupt after {INTERRUPTION_TIMEOUT}s. "
                            f"Thread may be blocked in non-interruptible operation (e.g., HTTP call without timeout)."
                        )
                        raise HTTPException(
                            status_code=499,
                            detail={
                                "error": "Request aborted by client", 
                                "detail": f"Interruption timeout after {INTERRUPTION_TIMEOUT}s for session {session_id}"
                            }
                        )
            await asyncio.sleep(0.05)
        
        # Get the result from process_chat
        agent_response = process_task.result()
        if agent_response.get("cancelled", False):
            raise HTTPException(
                status_code=499,
                detail={"error": "Request cancelled by client", "detail": "Chat processing was cancelled"}
            )
        return agent_response
            
    except asyncio.CancelledError:
        raise HTTPException(
            status_code=499,
            detail={"error": "Request cancelled by client"}
        )
    finally:
        # Always clean up the interruptor for this session
        SessionInterruptors.remove(session_id)


