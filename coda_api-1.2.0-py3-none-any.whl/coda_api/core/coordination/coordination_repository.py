from typing import Optional
from threading import Event, Lock
from uuid import UUID

from coda_api.core.coordination.coordination_action import CoordinationAction
from coda_api.core.callbacks.constants import ON_ASK_USER, ON_BASH_RISK_ASSESSMENT


class CoordinationRepository:
    """
    Repository class used to handle the creation, retrieval and deletion of `CoordinationAction`
    instances in-memory and in a thread-safe manner.

    This repository manages coordination actions for WebSocket communication patterns where the
    server needs to wait for client responses. It provides thread-safe operations for:
    
    - Creating coordination actions with specific callback types
    - Retrieving active coordination actions by correlation ID
    - Deleting completed coordination actions
    - Interrupting all actions for a session (e.g., on client disconnect)
    
    The repository handles type-safe interruption by setting appropriate result values based
    on the callback_type of each coordination action:
    - ON_ASK_USER: Sets result to "interrupted" (string)
    - ON_BASH_RISK_ASSESSMENT: Sets result to False (boolean)  
    - Unknown/None types: Sets result to None

    This class serves as a singleton and interface for future implementations that may involve
    persistent storage solutions.
    """
    _initialized = False
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(CoordinationRepository, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self._coordination_actions = {}
            self._lock: Lock = Lock()
            self._initialized = True

    def create(self, session_id: UUID, correlation_id: str, callback_type: str = None) -> CoordinationAction:
        """
        Create a new `CoordinationAction` and store it in the repository.

        The `session_id` and `correlation_id` are used to compose a unique key to store the action.

        Args:
            session_id (UUID): The session identifier.
            correlation_id (str): The correlation identifier.
            callback_type (str, optional): The type of callback this action is associated with.

        Returns:
            CoordinationAction: The newly created coordination action.
        """
        ca = CoordinationAction(event=Event(), result=None, callback_type=callback_type)
        with self._lock:
            self._coordination_actions[(session_id, correlation_id)] = ca
        return ca

    def get(self, session_id: UUID, correlation_id: str) -> Optional[CoordinationAction]:
        """
        Retrieve a `CoordinationAction` from the repository based on the provided identifiers.

        Args:
            session_id (UUID): The session identifier.
            correlation_id (str): The correlation identifier.

        Returns:
            Optional[CoordinationAction]: The coordination action if found, else None.
        """
        with self._lock:
            return self._coordination_actions.get((session_id, correlation_id))

    def delete(self, session_id: UUID, correlation_id: str) -> None:
        """
        Delete a `CoordinationAction` from the repository based on the provided identifiers.

        Args:
            session_id (UUID): The session identifier.
            correlation_id (str): The correlation identifier.
        """
        with self._lock:
            if (session_id, correlation_id) in self._coordination_actions:
                self._coordination_actions.pop((session_id, correlation_id))

    def interrupt_session_actions(self, session_id: UUID) -> int:
        """
        Interrupt all coordination actions for a given session.

        This method finds all coordination actions associated with the provided session_id,
        marks them as interrupted, and triggers their events to unblock any waiting threads.
        The result value is set based on the callback type to maintain type consistency.

        Args:
            session_id (UUID): The session identifier for which to interrupt all actions.

        Returns:
            int: The number of coordination actions that were interrupted.
        """
        interrupted_count = 0
        
        with self._lock:
            for key, action in list(self._coordination_actions.items()):
                action_session_id, correlation_id = key
                if action_session_id == session_id and not action.event.is_set():
                    # Only interrupt pending actions (event not set yet)
                    # Set result based on callback type to maintain type consistency
                    if action.callback_type == ON_ASK_USER:
                        # on_ask_user expects a string result
                        action.result = "interrupted"
                    elif action.callback_type == ON_BASH_RISK_ASSESSMENT:
                        # on_bash_risk_assessment expects a boolean result
                        action.result = False
                    else:
                        # Fallback for other/unknown action types
                        action.result = None
                    
                    action.event.set()
                    interrupted_count += 1
        
        return interrupted_count
