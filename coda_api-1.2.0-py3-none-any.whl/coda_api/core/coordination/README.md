# Coordination

This module provides primitives to coordinate external actions between the CODA API and its Clients. It enables request/response synchronization across threads by pairing a result container with an Event.

## Module Components
- [coordination_action.py](/coda_api/core/coordination/coordination_action.py): Dataclass holding an Event and an optional result. Used to block until an external signal arrives.
- [coordination_repository.py](/coda_api/core/coordination/coordination_repository.py): Thread-safe, in-memory singleton repository that creates and retrieves CoordinationAction instances keyed by (`session_id`, `correlation_id`).
