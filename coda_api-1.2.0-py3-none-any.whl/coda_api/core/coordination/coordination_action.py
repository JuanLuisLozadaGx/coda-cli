from typing import Any, Optional
from threading import Event
from dataclasses import dataclass


@dataclass
class CoordinationAction:
    """
    Represents an action that requires coordination, achieved with the use of an event.

    For now this actions are used in the context of our callbacks system, where certain
    callbacks require waiting for an external event to complete before proceeding. The
    signaling of said event is done with the event in the `CoordinationAction`.

    Attributes:
        event (Event): An event object used for synchronization.
        result (Optional[Any]): The result of the action, if applicable.
        callback_type (Optional[str]): The type of callback this action is associated with.
    """
    event: Event
    result: Optional[Any]
    callback_type: Optional[str] = None
