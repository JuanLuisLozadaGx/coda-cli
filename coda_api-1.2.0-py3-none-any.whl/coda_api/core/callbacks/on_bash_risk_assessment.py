from typing import Any, Dict
from uuid import uuid4

from pydantic import ValidationError
from loguru import logger

from coda_api.core.coordination.coordination_repository import CoordinationRepository
from coda_api.core.callbacks.constants import ON_BASH_RISK_ASSESSMENT
from coda_api.core.callbacks.schemas import OnBashRiskAssessmentMessage
from coda_api.core.sessions.repository.models import APISession
from coda_api.core.ws.service import WebSocketService


def on_bash_risk_assessment_callback(command: str, risk_assessment: Dict[str, Any], session: APISession) -> bool:
    """
    This callback sends a message to the client and then waits for a response (user input)
    indicating whether to proceed with executing a potentially risky bash command or not.

    Args:
        command (str): The command to be executed.
        risk_assessment (Dict[str, Any]): A dictionary containing the risk assessment details. The dictionary
            is generated in the `coda-core` repository and contains the following keys:
            - command (str): The command to be executed.
            - risk_level (str): The risk level of the command. Possible values are "high", "medium", "low".
            - reasons (List[str]): A list of reasons why the command is considered risky.
            - warnings (List[str]): A list of warnings associated with the command.
            - recommendation (Optional[str]): A recommendation related to the command.
        session (APISession): The session associated with the tool call.

    Returns:
        bool: True if the user approves executing the command, False otherwise.
    """
    coordination_repository = None
    try:
        # Create a correlation_id to match callbacks with sessions and consumers functions.
        correlation_id = str(uuid4())

        bash_risk_history = session.shared_state.preferences.get("_bash_risk_history", {})
        bash_risk_history[command] = risk_assessment.get("risk_level", "low")
        # Reassignment is required: if "_bash_risk_history" did not exist yet, `.get()` returns
        # a new empty dict not linked to preferences, so we must explicitly store it back.
        session.shared_state.preferences["_bash_risk_history"] = bash_risk_history

        message = OnBashRiskAssessmentMessage(
            callback_type=ON_BASH_RISK_ASSESSMENT,
            session_id=str(session.id), # UUIDs are parsed to str for serialization purposes.
            correlation_id=correlation_id,
            command=command,
            risk_assessment=risk_assessment # Let the consumer of the message parse this for their own needs.
        )

        # Create the coordination action with callback type for proper interrupt handling  
        # ON_BASH_RISK_ASSESSMENT ensures that if interrupted, the result will be False (boolean)
        coordination_repository = CoordinationRepository()
        coordination_action = coordination_repository.create(session.id, correlation_id, ON_BASH_RISK_ASSESSMENT)

        service = WebSocketService()
        service.queue_message(session.id, message.model_dump())

        # From this step-on we're waiting on the user approval of the bash risk assessment.
        if not coordination_action.event.wait():
            logger.warning(f"Timeout for {ON_BASH_RISK_ASSESSMENT} callback waiting for user response. Rejecting command execution.")
            return False

        if coordination_action.result is None:
            logger.warning(f"{ON_BASH_RISK_ASSESSMENT} callback coordination action received no result. Rejecting command execution.")
            return False

        # This CoordinationAction.result should match the OnBashRiskAssessmentConsumerMessage.approve value
        if not isinstance(coordination_action.result, bool):
            logger.error(f"Invalid result type for {ON_BASH_RISK_ASSESSMENT} callback coordination action. Expected bool but got {type(coordination_action.result)}. Rejecting command execution.")
            return False

        return coordination_action.result
    except ValidationError as e:
        # If we can't send the message, we default to not executing the command.
        logger.warning(f"Invalid data for '{ON_BASH_RISK_ASSESSMENT}' callback. Error: {e}")
        return False
    except Exception as e:
        # Manage any other unexpected error.
        logger.error(f"Error in '{ON_BASH_RISK_ASSESSMENT}' callback: {e}")
        return False
    finally:
        # Guarantee we delete the associated CoordinationAction.
        if coordination_repository is not None:
            try:
                coordination_repository.delete(session.id, correlation_id)
            except Exception as e:
                logger.error(f"Error deleting coordination action for session {session.id} and correlation_id {correlation_id}: {e}")
