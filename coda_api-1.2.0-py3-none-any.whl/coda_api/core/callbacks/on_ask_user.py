from typing import List
from uuid import uuid4

from pydantic import ValidationError
from loguru import logger

from coda_api.core.coordination.coordination_repository import CoordinationRepository
from coda_api.core.callbacks.constants import ON_ASK_USER
from coda_api.core.callbacks.schemas import OnAskUserMessage
from coda_api.core.sessions.repository.models import APISession
from coda_api.core.ws.service import WebSocketService


def on_ask_user_callback(question: str, suggestions: List[str], session: APISession) -> str:
    """
    This callback sends a message to the client and then waits for a response (user input)
    indicating the user's answer to the question asked.

    Args:
        question (str): The question being asked to the user.
        suggestions (List[str]): A list of suggested answers provided to the user.
        session (APISession): The session associated with the tool call.

    Returns:
        str: The user's response to the question. Default messages are returned in case of errors or timeouts.
        
    Raises:
        KeyboardInterrupt: When the session is disconnected/interrupted before user provides an answer.
    """
    coordination_repository = None
    try:
        # Create a correlation_id to match callbacks with sessions and consumers functions.
        correlation_id = str(uuid4())

        message = OnAskUserMessage(
            callback_type=ON_ASK_USER,
            session_id=str(session.id), # UUIDs are parsed to str for serialization purposes.
            correlation_id=correlation_id,
            question=question,
            suggestions=suggestions
        )

        # Create the coordination action with callback type for proper interrupt handling
        # ON_ASK_USER ensures that if interrupted, the result will be "interrupted" (string)
        coordination_repository = CoordinationRepository()
        coordination_action = coordination_repository.create(session.id, correlation_id, ON_ASK_USER)

        service = WebSocketService()
        service.queue_message(session.id, message.model_dump())

        # From this step-on we're waiting on the user response to the question asked.
        if not coordination_action.event.wait():
            logger.warning(f"Timeout for {OnAskUserMessage} callback waiting for user response.")
            return "User did not provide an answer in time."

        if coordination_action.result is None:
            logger.warning(f"{ON_ASK_USER} callback coordination action received no result.")
            return "User did not provide an answer."

        # This CoordinationAction.result should match the OnAskUserConsumerMessage.answer value
        if not isinstance(coordination_action.result, str):
            logger.error(f"Invalid result type for {ON_ASK_USER} callback coordination action. Expected str but got {type(coordination_action.result)}. Returning empty response.")
            return "User provided an invalid answer."

        # Handle interruption case - when session is disconnected, the result is set to "interrupted"
        # This should not be treated as a valid user answer, but as a cancellation signal
        if coordination_action.result == "interrupted":
            logger.info(f"{ON_ASK_USER} callback was interrupted due to session disconnect.")
            raise KeyboardInterrupt("User session was interrupted")

        return coordination_action.result
    except KeyboardInterrupt:
        # Re-raise KeyboardInterrupt to properly handle session interruption
        # This ensures that interruption signals propagate correctly through the call stack
        raise
    except ValidationError as e:
        # If we can't send the message, we return a default error message.
        logger.warning(f"Invalid data for '{ON_ASK_USER}' callback. Error: {e}")
        return "Invalid data provided."
    except Exception as e:
        # Manage any other unexpected error.
        logger.error(f"Error in '{ON_ASK_USER}' callback: {e}")
        return "An unexpected error occurred."
    finally:
        # Guarantee we delete the associated CoordinationAction.
        if coordination_repository is not None:
            try:
                coordination_repository.delete(session.id, correlation_id)
            except Exception as e:
                logger.error(f"Error deleting coordination action for session {session.id} and correlation_id {correlation_id}: {e}")
