from typing import Any, Dict

from loguru import logger
import pydantic

from coda_api.core.callbacks.constants import ON_MEMORY_CONDENSING_END, ON_MEMORY_CONDENSING_START
from coda_api.core.callbacks.schemas import OnMemoryCondensingStartMessage, OnMemoryCondensingEndMessage
from coda_api.core.sessions.repository.database import SESSIONS_DB_MANAGER
from coda_api.core.sessions.repository.models import APISession
from coda_api.core.ws.service import WebSocketService


def on_memory_condensing_start_callback(message: str, session: APISession):
    """Callback for `on_memory_condensing_start` events. This callback queues a message to be sent over a WebSocket.

    Args:
        message (str): The message indicating the start of memory condensing.
        session (APISession): The session associated with the memory condensing event.
    """
    try:
        callback_message = OnMemoryCondensingStartMessage(
            callback_type=ON_MEMORY_CONDENSING_START,
            session_id=str(session.id), # UUIDs are parsed to str for serialization purposes.
            message=message
        )

        service = WebSocketService()
        service.queue_message(session.id, callback_message.model_dump())
    except pydantic.ValidationError as e:
        logger.warning(f"Invalid data for 'on_memory_condensing_start' callback. Error: {e}")


def on_memory_condensing_end_callback(result: Dict[str, Any], session: APISession):
    """Callback for `on_memory_condensing_end` events. This callback queues a message to be sent over a WebSocket.

    Args:
        result (Dict[str, Any]): The result of the memory condensing operation. The result generated is
            in the `coda-core` repository and contains the following keys:
            - result (Dict[str, Any]): A dictionary with the result of the operation. Contains:
                - error (bool): Whether there was an error during the operation.
                - error_dsc (Optional[str]): A description of the error, if any.
            - metadata (Dict[str, Any]): A dictionary with metadata about the token usage and condensing details. Contains:
                - messages_condensed (int): The number of messages that were condensed.
                - tokens_removed (int): The number of tokens that were removed.
                - tokens_added (int): The number of tokens that were added.
                - net_token_change (int): The net change in tokens.
                - skipped (bool): Whether the condensing operation was skipped.
                - reason (Optional[str]): The reason for skipping, if applicable.
                - usage (Optional[Dict[str, Any]]): The LLM usage data associated with the operation.
        session (APISession): The session associated with the memory condensing event.
    """
    try:
        if (metadata := result.get("metadata", None)) and (llm_usage := metadata.get("usage", None)):
            session.shared_state.add_usage(usage=llm_usage)
            SESSIONS_DB_MANAGER.save_session(session=session)

        message = OnMemoryCondensingEndMessage(
            callback_type=ON_MEMORY_CONDENSING_END,
            session_id=str(session.id), # UUIDs are parsed to str for serialization purposes.
            result=result
        )

        service = WebSocketService()
        service.queue_message(session.id, message.model_dump())
    except (pydantic.ValidationError, Exception) as e:
        logger.warning(f"Error in '{ON_MEMORY_CONDENSING_END}' callback. Error: {e}")
