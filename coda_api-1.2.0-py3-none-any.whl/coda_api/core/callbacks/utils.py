from typing import Callable, Dict

from coda_api.core.sessions.repository.models import APISession
from coda_api.core.callbacks.constants import (
    ON_TOOL_CALL, ON_TOOL_RESULT,
    ON_MEMORY_CONDENSING_START, ON_MEMORY_CONDENSING_END,
    ON_BASH_RISK_ASSESSMENT,
    ON_ASK_USER, ON_LLM_PARSED
)
from coda_api.core.callbacks.on_tool_call import on_tool_call_callback
from coda_api.core.callbacks.on_tool_result import on_tool_result_callback
from coda_api.core.callbacks.on_memory_condensing import (
    on_memory_condensing_start_callback,
    on_memory_condensing_end_callback
)
from coda_api.core.callbacks.on_bash_risk_assessment import on_bash_risk_assessment_callback
from coda_api.core.callbacks.on_ask_user import on_ask_user_callback
from coda_api.core.callbacks.on_llm_parsed import on_llm_parsed_callback


def create_callbacks_for_session(session: APISession) -> Dict[str, Callable]:
    """
    Initialize a set of callbacks to be used within the context of a specific Session.

    Args:
        session (APISession): The session for which the callbacks are being created.

    Returns:
        (Dict[str, Callable]): A dictionary mapping callback names to their corresponding functions.
    """
    return {
        ON_TOOL_CALL: lambda tool_name, tool_args: on_tool_call_callback(tool_name, tool_args, session),
        ON_TOOL_RESULT: lambda tool_name, success, result: on_tool_result_callback(tool_name, success, result, session),
        ON_MEMORY_CONDENSING_START: lambda message: on_memory_condensing_start_callback(message, session),
        ON_MEMORY_CONDENSING_END: lambda result: on_memory_condensing_end_callback(result, session),
        ON_BASH_RISK_ASSESSMENT: lambda command, risk_assessment: on_bash_risk_assessment_callback(command, risk_assessment, session),
        ON_ASK_USER: lambda question, suggestions: on_ask_user_callback(question, suggestions, session),
        ON_LLM_PARSED: lambda content, tool_calls, metadata: on_llm_parsed_callback(content, tool_calls, metadata, session),
    }
