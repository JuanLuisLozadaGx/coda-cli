from typing import Any, Dict, List

from loguru import logger
import pydantic

from coda_api.core.callbacks.constants import ON_LLM_PARSED
from coda_api.core.callbacks.schemas import OnLLMParsedMessage
from coda_api.core.sessions.repository.database import SESSIONS_DB_MANAGER
from coda_api.core.sessions.repository.models import APISession
from coda_api.core.ws.service import WebSocketService


def on_llm_parsed_callback(content: str, tool_calls: List[Dict[Any, Any]], metadata: Dict[str, Any], session: APISession):
    """Callback for `on_llm_parsed` events. This callback updates the session shared state to reflect
    the token and costs usage of the LLM and queues a message to be sent over a WebSocket.

    Args:
        content (str): The content parsed from the LLM, including meta-intermediate messages.
        tool_calls (List[Dict[Any, Any]]): The tool calls parsed from the LLM.
        metadata (Dict[str, Any]): Additional metadata associated with the LLM parsing.
        session (APISession): The session associated with the LLM parsing.
    """
    try:
        # Update session state with LLM usage tracking
        if metadata and (llm_usage := metadata.get("usage")):
            session.shared_state.add_usage(usage=llm_usage)
            SESSIONS_DB_MANAGER.save_session(session=session)
        
        # Queue message for WebSocket communication only if both content and tool_calls are truthy
        if content and tool_calls:
            message = OnLLMParsedMessage(
                callback_type=ON_LLM_PARSED,
                session_id=str(session.id),  # UUIDs are parsed to str for serialization purposes.
                content=content
            )

            service = WebSocketService()
            service.queue_message(session.id, message.model_dump())
    except pydantic.ValidationError as e:
        logger.warning(f"Invalid data for '{ON_LLM_PARSED}' callback. Error: {e}")
    except Exception as e:
        logger.warning(f"Error in '{ON_LLM_PARSED}' callback. Error: {e}")
