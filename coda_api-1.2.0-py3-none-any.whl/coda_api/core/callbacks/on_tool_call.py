from typing import Any, Dict

from loguru import logger
import pydantic

from coda_api.core.callbacks.constants import ON_TOOL_CALL
from coda_api.core.callbacks.schemas import OnToolCallMessage
from coda_api.core.sessions.repository.models import APISession
from coda_api.core.ws.service import WebSocketService


def on_tool_call_callback(tool_name: str, tool_args: Dict[str, Any], session: APISession):
    """Callback for `on_tool_call` events. This callback queues a message to be sent over a WebSocket.

    Args:
        tool_name (str): The name of the tool being called.
        tool_args (Dict[str, Any]): The arguments being passed to the tool.
        session (APISession): The session associated with the tool call.
    """
    try:
        if tool_name == "run_skill" and "skill_name" in tool_args:
            skill_name = tool_args["skill_name"]
            session.shared_state.preferences["_last_skill_name"] = skill_name
            _store_skill_path(skill_name, session)

        message = OnToolCallMessage(
            callback_type=ON_TOOL_CALL,
            session_id=str(session.id), # UUIDs are parsed to str for serialization purposes.
            tool_name=tool_name,
            tool_args=tool_args
        )

        service = WebSocketService()
        service.queue_message(session.id, message.model_dump())
    except pydantic.ValidationError as e:
        logger.warning(f"Invalid data for 'on_tool_call' callback. Error: {e}")


def _store_skill_path(skill_name: str, session: APISession) -> None:
    """Look up the skill by name and store its file system path in the session state.

    Args:
        skill_name (str): The name of the skill to look up.
        session (APISession): The session to store the path in.
    """
    try:
        from coda_api.core.skills.service import SkillsService, SKILLS_AVAILABLE
        if not SKILLS_AVAILABLE:
            return

        workspace_path = session.client_state.workspace_context.environment_context.workspace_path
        session_id = str(session.id)

        loader = SkillsService._get_skill_loader(session_id, workspace_path)
        skill = loader.find_skill_by_name(skill_name)

        if skill is not None:
            session.shared_state.preferences["_last_skill_path"] = str(skill.path)
            logger.debug(f"Stored skill path '{skill.path}' for skill '{skill_name}'")
        else:
            session.shared_state.preferences["_last_skill_path"] = None
    except Exception as e:
        logger.warning(f"Could not resolve path for skill '{skill_name}': {e}")
        session.shared_state.preferences["_last_skill_path"] = None
