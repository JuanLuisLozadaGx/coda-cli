from typing import Any, Dict, List, Union, Optional

from pydantic import BaseModel


class CallbackMessage(BaseModel):
    """
    Base schema for callback messages.

    Attributes:
        callback_type (str): The type of the callback event.
        session_id (str): The ID of the session associated with the callback. The ID is converted to a string for serialization purposes.
        correlation_id (Optional[str]): An optional correlation ID to link requests and responses.
    """
    callback_type: str
    session_id: str
    correlation_id: Optional[str] = None


class OnToolCallMessage(CallbackMessage):
    """
    Schema for the `on_tool_call` callback messages.

    Attributes:
        tool_name (str): The name of the tool being called.
        tool_args (Dict[str, Any]): The arguments being passed to the tool.
    """
    tool_name: str
    tool_args: Dict[str, Any]


class OnToolResultMessage(CallbackMessage):
    """
    Schema for the `on_tool_result` callback messages.

    Attributes:
        tool_name (str): The name of the tool that produced the result.
        success (bool): Whether the tool call was successful.
        result (Union[str, Dict]): The result produced by the tool. Can be a string with a message or a dictionary with detailed information.
        skill_name (Optional[str]): The name of the skill that was executed (only present for run_skill tool).
        skill_path (Optional[str]): The file system path of the skill that was executed (only present for run_skill tool).
    """
    tool_name: str
    success: bool
    result: Union[str, Dict]
    skill_name: Optional[str] = None
    skill_path: Optional[str] = None


class OnMemoryCondensingStartMessage(CallbackMessage):
    """
    Schema for the `on_memory_condensing_start` callback messages.

    Attributes:
        message (str): The message indicating the start of memory condensing.
    """
    message: str


class OnMemoryCondensingEndMessage(CallbackMessage):
    """
    Schema for the `on_memory_condensing_end` callback messages.

    Attributes:
        result (Dict[str, Any]): The result of the memory condensing operation. The result generated is
            in the `coda-core` repository and contains the following keys:
            - result (Dict[str, Any]): A dictionary with the result of the operation. Contains:
                - error (bool): Whether there was an error during the operation.
                - error_dsc (Optional[str]): A description of the error, if any.
            - metadata (Dict[str, Any]): A dictionary with metadata about the token usage and condensing details. Contains:
                - messages_condensed (int): The number of messages that were condensed.
                - tokens_removed (int): The number of tokens that were removed.
                - tokens_added (int): The number of tokens that were added.
                - net_token_change (int): The net change in tokens.
                - skipped (bool): Whether the condensing operation was skipped.
                - reason (Optional[str]): The reason for skipping, if applicable.
                - usage (Optional[Dict[str, Any]]): The LLM usage data associated with the operation.
    """
    result: Dict[str, Any]


class OnBashRiskAssessmentMessage(CallbackMessage):
    """
    Schema for the `on_bash_risk_assessment` callback messages.

    Attributes:
        command (str): The bash command to be executed.
        risk_assessment (Dict[str, Any]): A dictionary containing the risk assessment details. The dictionary
            is generated in the `coda-core` repository and contains the following keys:
            - command (str): The command to be executed.
            - risk_level (str): The risk level of the command. Possible values are "high", "medium", "low".
            - reasons (List[str]): A list of reasons why the command is considered risky.
            - warnings (List[str]): A list of warnings associated with the command.
            - recommendation (Optional[str]): A recommendation related to the command.
    """
    command: str
    risk_assessment: Dict[str, Any]


class OnAskUserMessage(CallbackMessage):
    """
    Schema for the `on_ask_user` callback messages.

    Attributes:
        question (str): The question being asked to the user.
        suggestions (List[str]): A list of suggestions provided to the user.
    """
    question: str
    suggestions: List[str]


class OnLLMParsedMessage(CallbackMessage):
    """
    Schema for the `on_llm_parsed` callback messages.

    Attributes:
        content (str): The content parsed from the LLM, including meta-intermediate messages.
    """
    content: str
