from typing import Dict, Union

from loguru import logger
import pydantic

from coda_api.core.callbacks.constants import ON_TOOL_RESULT
from coda_api.core.callbacks.schemas import OnToolResultMessage
from coda_api.core.sessions.repository.database import SESSIONS_DB_MANAGER
from coda_api.core.sessions.repository.models import APISession
from coda_api.core.ws.service import WebSocketService


def on_tool_result_callback(tool_name: str, success: bool, result: Union[str, Dict], session: APISession):
    """Callback for `on_tool_result` events. This callback queues a message to be sent over a WebSocket.

    Args:
        tool_name (str): The name of the tool that produced the result.
        success (bool): Whether the tool call was successful.
        result (Union[str, Dict]): The result produced by the tool. Can be a string or a dictionary.
        session (APISession): The session associated with the tool call.
    """
    try:
        skill_name = None
        if isinstance(result, Dict):
            if llm_usage := result.pop("_usage", None):
                if success is True:
                    session.shared_state.add_usage(usage=llm_usage)
                    SESSIONS_DB_MANAGER.save_session(session=session)
            
            # Extract skill_name if present (for run_skill tool)
            if tool_name == "run_skill":
                skill_name = result.get("skill_name")
        
        # Fallback: get skill_name from session state (saved in on_tool_call)
        if tool_name == "run_skill" and skill_name is None:
            skill_name = session.shared_state.preferences.get("_last_skill_name")

        skill_path = None
        if tool_name == "run_skill":
            skill_path = session.shared_state.preferences.get("_last_skill_path")

        message = OnToolResultMessage(
            callback_type=ON_TOOL_RESULT,
            session_id=str(session.id), # UUIDs are parsed to str for serialization purposes.
            tool_name=tool_name,
            success=success,
            result=result,
            skill_name=skill_name,
            skill_path=skill_path
        )

        service = WebSocketService()
        service.queue_message(session.id, message.model_dump())
    except (pydantic.ValidationError, Exception) as e:
        logger.warning(f"Error in '{ON_TOOL_RESULT}' callback. Error: {e}")
