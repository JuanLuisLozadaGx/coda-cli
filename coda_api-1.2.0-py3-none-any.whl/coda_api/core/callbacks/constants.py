"""Callbacks related constants."""


ON_TOOL_CALL = "on_tool_call"
ON_TOOL_RESULT = "on_tool_result"
ON_MEMORY_CONDENSING_START = "on_memory_condensing_start"
ON_MEMORY_CONDENSING_END = "on_memory_condensing_end"
ON_BASH_RISK_ASSESSMENT = "on_bash_risk_assessment"
ON_ASK_USER = "on_ask_user"
ON_LLM_PARSED = "on_llm_parsed"


CALLBACKS = [
    ON_TOOL_CALL,
    ON_TOOL_RESULT,
    ON_MEMORY_CONDENSING_START,
    ON_MEMORY_CONDENSING_END,
    ON_BASH_RISK_ASSESSMENT,
    ON_ASK_USER,
    ON_LLM_PARSED
]
