# Context

This module defines all schemas and logic related to the management of the Context needed for the CODA agents.

## Module Components
- **schemas**: This file contains all schemas used to represent different types of Contexts.

## Module Logic
This module is vital for the CODA agents to work properly.

The idea behind this module is to receive the Context data from the different clients of the CODA API, let the API serialize, validate it, and forward it to the `coda-core` package.

## Key Entities
The principal entity here is the `Context` itself, which is just an object containing information for the agents to use. 

Based on what type of information is provided, a different type of Context is generated.

## Context DTO's
Each Context has its own DTO defined as a Pydantic model to encapsulate all the properties and data it contains. To further read on what data they contain check their definition in the [schemas file](/coda_api/core/context/schemas.py).

### EnvironmentContextDTO
The `EnvironmentContextDTO` contains all data related to environment information of the place where the client is working. This DTO ensures all environment related data is validated. To see what properties can or should be validated check the `EnvironmentContext` schema in the `coda-core` repository.

### CodebaseContextDTO
The `CodebaseContextDTO` contains all data related to the codebase of the place where the client is working. This DTO ensures all codebase related data is validated. To see what properties can or should be validated check the `CodebaseContext` schema in the `coda-core` repository.

### VCSContextDTO
The `VCSContextDTO` contains all data related to version control systems of the place where the client is working. This DTO ensures all version control systems related data is validated. To see what properties can or should be validated check the `VCSContext` schema in the `coda-core` repository.

### WorkspaceContextDTO
The `WorkspaceContextDTO` is used to encapsulate all Context data. This DTO will serialize and forward the DTO's Contexts to the `coda-core` package Context. The forward is done with the `to_core_context()` method of the class.