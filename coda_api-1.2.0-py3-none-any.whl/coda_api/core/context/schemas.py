
from pydantic import model_validator

from coda_core.config.context.schemas import CodebaseContext, EnvironmentContext, VCSContext, WorkspaceContext


class EnvironmentContextDTO(EnvironmentContext):
    """
    EnvironmentContextDTO schema to receive environment-related information used to generate context for agents.

    **Note**: The role of the DTO is to perform any serialization or validation logic needed before
    forwarding the data to the coda-core. Feel free to rely on Pydantic's features to achieve this.
    """


class CodebaseContextDTO(CodebaseContext):
    """
    CodebaseContextDTO schema to receive codebase-related information used to generate context for agents.

    **Note**: The role of the DTO is to perform any serialization or validation logic needed before
    forwarding the data to the coda-core. Feel free to rely on Pydantic's features to achieve this.
    """


class VCSContextDTO(VCSContext):
    """
    VCSContextDTO schema to receive version control system-related information used to generate context for agents.

    **Note**: The role of the DTO is to perform any serialization or validation logic needed before
    forwarding the data to the coda-core. Feel free to rely on Pydantic's features to achieve this.
    """

    @model_validator(mode="after")
    def check_branch_only_if_repo(self):
        """
        Validate that repo_branch is only provided if repo_name is also provided.

        Raises:
            ValueError: If repo_branch is provided but repo_name is missing.
        """
        if self.repo_branch and not self.repo_name:
            raise ValueError("repo_branch provided but repo_name is missing")
        return self


class WorkspaceContextDTO(WorkspaceContext):
    """
    WorkspaceContextDTO schema used to encapsulate all the context information required by the CODA agents.
    """

    def to_core_context(self) -> WorkspaceContext:
        """
        Map the WorkspaceContextDTO to the `WorkspaceContext` used by `coda-core`.

        Returns:
            WorkspaceContext: The mapped core workspace context.
        """
        return WorkspaceContext(**self.model_dump())
