# Dependencies

This module defines dependencies used in different endpoints of the Coda REST API.

## Adding new dependencies
Each file should contain a function defining the dependency. For example:

**credentials_set.py** contains a function called `credentials_set` in it.

## Exporting Dependencies
Import each dependency function in the module's `__init__.py` file and add its name to the `__all__` list.

## Current Dependencies

### credentials_set
This dependency validates that the GEAI credentials are set before processing the request. If they're not, it raises a 403 status with a message indicating the error.