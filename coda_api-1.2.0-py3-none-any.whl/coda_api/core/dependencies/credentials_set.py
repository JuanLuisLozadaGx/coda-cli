from fastapi import status
from fastapi.requests import Request
from fastapi.exceptions import HTTPException

from coda_api.config.service import ConfigService

async def credentials_set(request: Request):
    """
    Dependency to check if the credentials are set in the application before
    processing the request.

    Args:
        request (Request): The FastAPI request object.
    
    Raises:
        HTTPException: If credentials are not set, raises a 403 Forbidden error
                        with a message indicating that credentials need to be set.
    """
    if not ConfigService.are_geai_credentials_set():
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "Credentials are not set",
                "message": "Please set the credentials with the `POST /config/credentials` endpoint to use the API."
            }
        )
