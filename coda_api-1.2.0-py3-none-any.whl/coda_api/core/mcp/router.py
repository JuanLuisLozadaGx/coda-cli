from typing import Dict, Any

from fastapi import APIRouter, HTTPException, status

from coda_api.core.mcp.schemas import (
    ServerInfo, ServerList, ServerState, ServerStateResponse, DeleteServerResponse
)
from coda_api.core.mcp.service import MCPServerService


mcp_router = APIRouter(prefix="/mcp", tags=["mcp"])


@mcp_router.get("/servers", response_model=ServerList, summary="List all MCP servers")
async def list_servers():
    """
    List all available MCP servers with their current state.

    Returns:
        ServerList: A list of all configured MCP servers
    """
    try:    
        servers = MCPServerService.list_servers()
        if servers is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No servers found"
            )
        return ServerList(servers=[ServerInfo(**srv) for srv in servers])
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving servers: {str(e)}"
        )


@mcp_router.get("/servers/{server_name:str}", response_model=ServerInfo, summary="Get server details")
async def get_server(server_name: str):
    """
    Get details for a specific MCP server.

    Args:
        server_name (str): Name of the MCP server

    Returns:
        ServerInfo: Server details

    Raises:
        HTTPException: If server not found
    """
    try:    
        server = MCPServerService.get_server(server_name)
        if server is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Server '{server_name}' not found"
            )
        return server
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving server '{server_name}': {str(e)}"
        )


@mcp_router.get("/list_tools", summary="List all available MCP tools")
async def list_mcp_tools():
    """
    List all available MCP tools from all servers.

    Returns:
        Dict[str, Any]: A response containing the list of tools
    """
    try:
        tools = MCPServerService.list_mcp_tools()
        if not tools:
            return {"success": False, "message": "Failed to retrieve tools"}
        return {"success": True, "tools": tools}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving MCP tools: {str(e)}"
        )


@mcp_router.post("/servers/import", summary="Import a server from a JSON object")
async def import_server_from_json(payload: Dict[str, Any]):
    """
    Imports one server from a JSON object.

    Args:
        payload (Dict[str, Any]): The raw JSON object from the request body.

    Returns:
        Dict[str, Any]: A response indicating whether the import was successful.
    Raises:
        HTTPException: If the import fails.
    """
    try:
        success = MCPServerService.add_server(payload)
        if not success:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to import server"
            )
        return {"success": True, "message": "Server imported successfully"}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error importing server: {str(e)}"
        )


@mcp_router.patch("/servers/{server_name:str}", response_model=ServerStateResponse, summary="Update server state")
async def update_server_state(server_name: str, state: ServerState):
    """
    Enable or disable a specific MCP server.

    Args:
        server_name (str): Name of the MCP server
        state (ServerState): Desired server state

    Returns:
        ServerStateResponse: Result of the update operation

    Raises:
        HTTPException: If server not found or operation fails
    """
    server = MCPServerService.get_server(server_name)
    if server is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Server '{server_name}' not found"
        )

    success = MCPServerService.update_server_state(server_name, state.enabled)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update state for server '{server_name}'"
        )

    return {
        "success": True,
        "server_name": server_name,
        "enabled": state.enabled
    }


@mcp_router.delete("/servers/{server_name:str}", response_model=DeleteServerResponse, summary="Delete MCP server")
async def delete_server(server_name: str):
    """
    Delete a specific MCP server configuration.

    Args:
        server_name (str): Name of the MCP server to delete

    Returns:
        DeleteServerResponse: Result of the delete operation

    Raises:
        HTTPException: If server not found or operation fails
    """
    server = MCPServerService.get_server(server_name)
    if server is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Server '{server_name}' not found"
        )

    success = MCPServerService.remove_server(server_name)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete server '{server_name}'"
        )

    return DeleteServerResponse(
        success=True,
        message=f"Server '{server_name}' deleted successfully"
    )
