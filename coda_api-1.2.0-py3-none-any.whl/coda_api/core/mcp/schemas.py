from typing import List, Optional

from pydantic import BaseModel, Field


class ServerInfo(BaseModel):
    """
    Schema for MCP server information.
    
    Attributes:
        name (str): Unique identifier for the server
        enabled (bool): Whether the server is enabled
        url (Optional[str]): Server URL (for HTTP transport)
        command (Optional[str]): Server command (for STDIO transport)
    """
    name: str = Field(..., description="Unique server identifier")
    enabled: bool = Field(..., description="Whether the server is enabled")
    url: Optional[str] = Field(None, description="Server URL (for HTTP transport)")
    command: Optional[str] = Field(None, description="Server command (for STDIO transport)")


class ServerList(BaseModel):
    """
    Schema for a list of MCP servers.
    
    Attributes:
        servers (List[ServerInfo]): List of server information
    """
    servers: List[ServerInfo] = Field(..., description="List of MCP servers")


class ServerState(BaseModel):
    """
    Schema for updating server state.
    
    Attributes:
        enabled (bool): Whether the server should be enabled
        session_id (Optional[str]): Optional session ID for session-specific state
    """
    enabled: bool = Field(..., description="Desired server state (enabled/disabled)")


class ServerStateResponse(BaseModel):
    """
    Schema for server state update response.
    
    Attributes:
        success (bool): Whether the operation succeeded
        server_name (str): Name of the server that was updated
        enabled (bool): New state of the server
    """
    success: bool = Field(..., description="Whether the operation succeeded")
    server_name: str = Field(..., description="Name of the server that was updated")
    enabled: bool = Field(..., description="New state of the server")


class DeleteServerResponse(BaseModel):
    """
    Schema for server delete response.
    
    Attributes:
        success (bool): Whether the operation succeeded
        message (str): Message describing the result of the operation
    """
    success: bool = Field(..., description="Whether the operation succeeded")
    message: str = Field(..., description="Message describing the result of the operation")
