# MCP Server Management API

This module provides a REST API for managing MCP (Model Context Protocol) servers. It allows listing, enabling, and disabling MCP servers either globally or for specific sessions.

## Features

- List all available MCP servers
- Get details for specific MCP servers
- Enable/disable MCP servers (globally or per session)

## API Endpoints

### List all MCP servers

```
GET /mcp/servers
```

Returns a list of all configured MCP servers with their current state.

### Get server details

```
GET /mcp/servers/{server_name}
```

Returns details for a specific MCP server.

### Update server state

```
PATCH /mcp/servers/{server_name}
```

Enable or disable a specific MCP server.

Request body:
```json
{
  "enabled": true|false,
  "session_id": "optional-session-id"
}
```

## Implementation

The implementation follows a similar structure to other Coda API modules:

- `schemas.py`: Defines Pydantic models for request/response validation
- `service.py`: Contains business logic for interacting with MCP services
- `router.py`: Defines FastAPI routes and handlers

## Dependencies

- coda_core: For accessing the underlying MCP implementation
- FastAPI: For API routing and endpoint definitions
- Pydantic: For request/response validation