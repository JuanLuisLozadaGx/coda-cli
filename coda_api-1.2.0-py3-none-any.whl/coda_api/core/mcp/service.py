from typing import Dict, List, Optional, Any, Tuple

from loguru import logger
from coda_core.core.mcp.service import MCPService


class MCPServerService:
    """
    Service for managing MCP servers.

    This service provides operations for managing MCP servers, such as listing servers,
    getting server information, and updating server state.
    """

    @staticmethod
    def _get_mcp_service() -> MCPService:
        """
        Get the MCP service instance and ensure it's initialized with latest configuration.

        Returns:
            MCPService: The initialized MCP service instance
        """
        service = MCPService.get()
        service.initialize()
        return service

    @staticmethod
    def set_session_config_from_global_config(session_id: str) -> None:
        """
        Initialize session-specific MCP configuration from global defaults.

        Args:
            session_id (str): The session ID to initialize MCP configuration for.

        Raises:
            Exception: If there is an error during initialization.
        """
        try:
            service = MCPServerService._get_mcp_service()
            session_mcps = service.load_global_mcp_defaults()

            # Save session with current global MCP config snapshot
            service.save_session_mcp_config(session_id, session_mcps)
            logger.info(f"Session-specific MCP configuration for session {session_id} created/updated from global defaults")
        except Exception as e:
            logger.error(f"Error initializing session MCP config for {session_id}: {e}")
            raise

    @staticmethod
    def compare_session_config_against_global(session_id: str) -> Tuple[List[str], List[str]]:
        """
        Compare session-specific MCP configuration against global defaults.

        Args:
            session_id (str): The session ID to compare MCP configuration for.

        Returns:
            Tuple[List[str], List[str]]: Lists of added and removed servers. If no changes, both lists are empty.
        """
        service = MCPServerService._get_mcp_service()
        # Retrieve session-specific enabled MCPs
        session_config = service.load_session_mcp_config(session_id)
        session_enabled_mcps = set(name for name, enabled in session_config.items() if enabled)

        # Retrieve global enabled MCPs
        global_config = service.load_global_mcp_defaults()
        global_enabled_mcps = set(name for name, enabled in global_config.items() if enabled)

        # Compare session-specific MCPs against global MCPs
        if session_enabled_mcps != global_enabled_mcps:
            # Calculate which servers were added or removed
            return MCPServerService.calculate_server_changes(
                servers_before=session_enabled_mcps, servers_after=global_enabled_mcps
            )

        return [], []

    @staticmethod
    def calculate_server_changes(servers_before: set, servers_after: set) -> tuple[List[str], List[str]]:
        """
        Calculate which servers were added or removed by comparing before and after states.

        Args:
            servers_before: Set of enabled servers before the operation
            servers_after: Set of enabled servers after the operation

        Returns:
            tuple: (added_servers, removed_servers) lists
        """
        added_servers = list(servers_after - servers_before)
        removed_servers = list(servers_before - servers_after)
        return added_servers, removed_servers

    @staticmethod
    def add_server(config: Dict[str, Any]) -> bool:
        """
        Add an MCP server configuration.

        Args:
            config (Dict[str, Any]): The JSON configuration to add

        Returns:
            bool: True if successful the server was added, False otherwise
        """
        service = MCPServerService._get_mcp_service()
        try:
            success_count, errors = service.import_servers(config)

            if success_count > 0 and not errors:
                return True
            else:
                logger.warning(
                    f"Import finished but had issues. "
                    f"Success count: {success_count}, Errors: {errors}"
                )
                return False
        except Exception as e:
            logger.error(f"Error adding server '{config.name}': {str(e)}")
            return False

    @staticmethod
    def list_servers() -> List[Dict[str, Any]]:
        """
        List all available MCP servers with their global default status.

        Returns:
            List[Dict[str, Any]]: List of dictionaries containing server information.
        """
        service = MCPServerService._get_mcp_service()
        servers = []
        configs = service.load_configurations()
        global_defaults = service.load_global_mcp_defaults()

        for name, config in configs.items():
            servers.append({
                "name": name,
                "enabled": global_defaults.get(name, config.enabled),
                "url": config.url if hasattr(config, "url") else None,
                "command": config.command if hasattr(config, "command") else None
            })

        return servers
    
    @staticmethod
    def get_server(server_name: str) -> Optional[Dict[str, Any]]:
        """
        Get information for a specific MCP server with its global default status.

        Args:
            server_name (str): Name of the server

        Returns:
            Optional[Dict[str, Any]]: Server information or None if not found
        """
        service = MCPServerService._get_mcp_service()
        config = service.get_server_config(server_name)
        global_defaults = service.load_global_mcp_defaults()

        if config:
            return {
                "name": config.name,
                "enabled": global_defaults.get(server_name, config.enabled),
                "url": config.url if hasattr(config, "url") else None,
                "command": config.command if hasattr(config, "command") else None
            }

        return None
    
    @staticmethod
    def update_server_state(server_name: str, enabled: bool) -> bool:
        """
        Update the state of an MCP server. Reflecting the change in the global MCP defaults.

        Args:
            server_name (str): Name of the server.
            enabled (bool): Whether to enable or disable the server.

        Returns:
            bool: True if the update was successful, False otherwise.
        """
        service = MCPServerService._get_mcp_service()

        try:
            current_config = service.load_global_mcp_defaults()

            config = service.get_server_config(server_name)
            if config:
                # If global_config state is the same as the updatable state and the current config, no change is needed
                if current_config.get(server_name, False) == enabled == config.enabled: 
                    return True  # No change needed

                # TODO: i don't like nested try/except. Refactor later once general logic is validated.
                try:
                    # Update configs and update the global MCPs. Session tools updates are left for preflight checks.
                    config.enabled = enabled
                    service.add_server(config)
                    service.save_global_mcp_defaults(service.get_server_states())
                    service.reload()
                except Exception as e:
                    logger.error(f"Failed to save global MCP defaults after updating server state for '{server_name}': {str(e)}")
                    return False

                return True
            else:
                logger.warning(f"Server '{server_name}' not found in configuration.")
                return False
        except Exception as e:
            logger.error(f"Error updating server state for '{server_name}': {str(e)}")
            return False

    @staticmethod
    def list_mcp_tools():
        """
        Get list of all available tools from all servers.

        Returns:
            List[Tuple]: List of MCP tools where each entry contains (server name, tool name, tool description)
        """
        try:
            service = MCPServerService._get_mcp_service()
            tools = service.list_tools()
            return tools
        except Exception as e:
            logger.error(f"Error listing MCP tools: {str(e)}")
            return []

    @staticmethod
    def remove_server(server_name: str) -> bool:
        """
        Remove an MCP server configuration and update the global MCP configuration.

        Args:
            server_name (str): Name of the server to remove

        Returns:
            bool: True if successful, False otherwise
        """
        service = MCPServerService._get_mcp_service()

        try:
            if service.remove_server(server_name):
                logger.info(f"Server '{server_name}' removed successfully.")
                # TODO: not a fan of this nested try/except
                try:
                    service.save_global_mcp_defaults(service.get_server_states())
                    return True
                except Exception as global_error:
                    logger.warning(f"Could not set configuration as global default: {str(global_error)}")
            else:
                logger.warning(f"Failed to remove server '{server_name}'.")
                return False
        except Exception as e:
            logger.error(f"Error removing server '{server_name}': {str(e)}")
            return False
