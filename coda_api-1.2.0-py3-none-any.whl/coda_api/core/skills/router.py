from uuid import UUID
from typing import Optional
from fastapi import APIRouter, HTTPException
from loguru import logger

from coda_api.core.skills.schemas import (
    SkillList,
    SkillGroupedList,
    SkillDetail,
    SkillStateChange,
    SkillStateBatchRequest,
    SkillStateBatchResponse,
    InstallSkillFromGitHub,
)
from coda_api.core.skills.service import SkillsService
from coda_api.core.sessions.service import SessionsService


skills_router = APIRouter(prefix="/skills", tags=["skills"])


@skills_router.get("/{session_id:uuid}", response_model=SkillGroupedList)
async def list_skills(session_id: UUID, include_disabled: bool = False):
    session = SessionsService.session_exists(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")

    try:
        workspace_path = (
            session.client_state.workspace_context.environment_context.workspace_path
        )
        skills = SkillsService.list_grouped_skills(
            session_id=str(session_id),
            workspace_path=workspace_path,
            include_disabled=include_disabled,
        )
        return skills
    except Exception as e:
        logger.error(f"Error listing skills: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing skills: {str(e)}")


@skills_router.get("/{session_id:uuid}/{skill_name}", response_model=SkillDetail)
async def get_skill(session_id: UUID, skill_name: str):
    session = SessionsService.session_exists(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")

    try:
        workspace_path = (
            session.client_state.workspace_context.environment_context.workspace_path
        )
        skill = SkillsService.get_skill(
            session_id=str(session_id),
            workspace_path=workspace_path,
            skill_name=skill_name,
        )

        if skill is None:
            raise HTTPException(
                status_code=404, detail=f"Skill '{skill_name}' not found"
            )

        return skill
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting skill {skill_name}: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting skill: {str(e)}")


@skills_router.patch(
    "/{session_id:uuid}/{skill_name}/enable", response_model=SkillStateChange
)
async def enable_skill(session_id: UUID, skill_name: str):
    session = SessionsService.session_exists(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")

    try:
        workspace_path = (
            session.client_state.workspace_context.environment_context.workspace_path
        )
        result = SkillsService.enable_skill(
            session_id=str(session_id),
            workspace_path=workspace_path,
            skill_name=skill_name,
            session=session,
        )

        if not result.success:
            raise HTTPException(status_code=500, detail=result.message)

        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error enabling skill {skill_name}: {e}")
        raise HTTPException(status_code=500, detail=f"Error enabling skill: {str(e)}")


@skills_router.patch(
    "/{session_id:uuid}/{skill_name}/disable", response_model=SkillStateChange
)
async def disable_skill(session_id: UUID, skill_name: str):
    session = SessionsService.session_exists(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")

    try:
        workspace_path = (
            session.client_state.workspace_context.environment_context.workspace_path
        )
        result = SkillsService.disable_skill(
            session_id=str(session_id),
            workspace_path=workspace_path,
            skill_name=skill_name,
            session=session,
        )

        if not result.success:
            raise HTTPException(status_code=500, detail=result.message)

        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error disabling skill {skill_name}: {e}")
        raise HTTPException(status_code=500, detail=f"Error disabling skill: {str(e)}")


@skills_router.patch("/{session_id:uuid}/state", response_model=SkillStateBatchResponse)
async def change_skills_state(session_id: UUID, request: SkillStateBatchRequest):
    session = SessionsService.session_exists(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")

    try:
        workspace_path = (
            session.client_state.workspace_context.environment_context.workspace_path
        )
        result = SkillsService.change_skills_state_batch(
            workspace_path=workspace_path,
            operations=request.operations,
            session=session,
        )
        return result
    except Exception as e:
        logger.error(f"Error changing skills state for session {session_id}: {e}")
        raise HTTPException(
            status_code=500, detail=f"Error changing skills state: {str(e)}"
        )


@skills_router.delete(
    "/{session_id:uuid}/{skill_name}", response_model=SkillStateChange
)
async def remove_skill(session_id: UUID, skill_name: str):
    session = SessionsService.session_exists(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")

    try:
        workspace_path = (
            session.client_state.workspace_context.environment_context.workspace_path
        )
        result = SkillsService.remove_skill(
            session_id=str(session_id),
            workspace_path=workspace_path,
            skill_name=skill_name,
            session=session,
        )

        if not result.success:
            raise HTTPException(status_code=500, detail=result.message)

        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error removing skill {skill_name}: {e}")
        raise HTTPException(status_code=500, detail=f"Error removing skill: {str(e)}")


@skills_router.post("/{session_id:uuid}/install", response_model=SkillList)
async def install_from_github(session_id: UUID, request: InstallSkillFromGitHub):
    session = SessionsService.session_exists(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")

    try:
        workspace_path = (
            session.client_state.workspace_context.environment_context.workspace_path
        )
        skills = SkillsService.install_from_github(
            workspace_path=workspace_path,
            repo=request.repo,
            skills=request.skills
        )
        return SkillList(skills=skills)
    except Exception as e:
        logger.error(f"Error installing skills from GitHub: {e}")
        raise HTTPException(
            status_code=500, detail=f"Error installing skills: {str(e)}"
        )


@skills_router.post("/{session_id:uuid}/refresh", response_model=SkillList)
async def refresh_skills(session_id: UUID):
    session = SessionsService.session_exists(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")

    try:
        workspace_path = (
            session.client_state.workspace_context.environment_context.workspace_path
        )
        skills = SkillsService.refresh_skills(
            session_id=str(session_id), workspace_path=workspace_path
        )
        return SkillList(skills=skills)
    except Exception as e:
        logger.error(f"Error refreshing skills: {e}")
        raise HTTPException(
            status_code=500, detail=f"Error refreshing skills: {str(e)}"
        )
