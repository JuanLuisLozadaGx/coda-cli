from enum import StrEnum
from typing import List, Optional, Dict, Any, Literal

from pydantic import BaseModel, Field, StrictBool, field_validator


class SkillSummary(BaseModel):
    """
    Summary information about a skill.

    Attributes:
        name (str): The name of the skill.
        description (str): A brief description of the skill.
        enabled (bool): Whether the skill is currently enabled.
        source (str): The source of the skill (e.g., "builtin", "custom", "github").
    """
    name: str
    description: str
    enabled: bool
    source: str


class SkillDetail(SkillSummary):
    """
    Detailed information about a skill, extending the summary with additional attributes.

    Attributes:
        license (Optional[str]): The license of the skill, if applicable.
        metadata (Dict[str, Any]): Additional metadata about the skill.
        full_content (str): The full content of the skill.
        is_default (bool): Whether the skill is a default skill.
        path (str): The file path to the skill.
    """
    license: Optional[str] = None
    metadata: Dict[str, Any]
    full_content: str
    is_default: bool
    path: str


class SkillList(BaseModel):
    """
    A list of skills.

    Attributes:
        skills (List[SkillSummary]): The list of skill summaries.
    """
    skills: List[SkillSummary]


class SkillGroupedList(BaseModel):
    project_skills: List[SkillSummary]
    global_skills: List[SkillSummary]


class SkillStateChange(BaseModel):
    """
    Represents a change in the state of a skill.

    Attributes:
        success (bool): Whether the state change was successful.
        skill_name (str): The name of the skill.
        action (str): The action performed on the skill (e.g., "enabled", "disabled").
        message (Optional[str]): An optional message providing additional information about the state change.
    """
    success: bool
    skill_name: str
    action: str
    message: Optional[str] = None


SkillItemStatus = Literal["applied", "unchanged", "failed"]
"""Statuses for individual skill state change operations in a batch request."""


class SkillStateCode(StrEnum):
    """Codes representing the result of a skill state change operation."""

    APPLIED = "SKILL_STATE_APPLIED"
    UNCHANGED = "SKILL_STATE_UNCHANGED"
    NOT_FOUND = "SKILL_NOT_FOUND"
    CHANGE_FAILED = "SKILL_STATE_CHANGE_FAILED"


SkillItemCode = Literal[
    "SKILL_STATE_APPLIED",
    "SKILL_STATE_UNCHANGED",
    "SKILL_NOT_FOUND",
    "SKILL_STATE_CHANGE_FAILED",
]


class SkillStateBatchOperation(BaseModel):
    """
    Represents a batch operation to change the state of a skill.

    Attributes:
        skill_name (str): The name of the skill.
        enabled (bool): The desired state of the skill.
    """
    skill_name: str = Field(min_length=1)
    enabled: StrictBool

    @field_validator("skill_name")
    @classmethod
    def validate_skill_name(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("skill_name cannot be empty")
        return normalized


class SkillStateBatchRequest(BaseModel):
    """
    Represents a request to change the state of multiple skills in a batch.

    Attributes:
        operations (List[SkillStateBatchOperation]): The list of batch operations to be performed.
    """
    operations: List[SkillStateBatchOperation] = Field(min_length=1)


class SkillStateBatchResultItem(BaseModel):
    """
    Represents the result of an individual skill state change operation in a batch request.

    Attributes:
        skill_name (str): The name of the skill.
        desired_enabled (bool): The desired state of the skill as specified in the request.
        status (SkillItemStatus): The status of the operation (e.g., "applied", "unchanged", "failed").
        applied (bool): Whether the desired state was successfully applied.
        code (SkillItemCode): A code representing the result of the operation.
        message (Optional[str]): An optional message providing additional information about the result.
    """
    skill_name: str
    desired_enabled: bool
    status: SkillItemStatus
    applied: bool
    code: SkillItemCode
    message: Optional[str] = None


class SkillStateBatchSummary(BaseModel):
    """
    Represents a summary of the results of a batch operation to change the state of multiple skills.

    Attributes:
        total (int): The total number of operations attempted.
        applied (int): The number of operations that were successfully applied.
        unchanged (int): The number of operations that were already in the desired state and thus unchanged.
        failed (int): The number of operations that failed to apply the desired state.
    """
    total: int
    applied: int
    unchanged: int
    failed: int


class SkillStateBatchResponse(BaseModel):
    """
    Represents the response of a batch operation to change the state of multiple skills.

    Attributes:
        success (bool): Whether the batch operation was successful overall.
        results (List[SkillStateBatchResultItem]): The list of results for each individual operation in the batch.
        summary (SkillStateBatchSummary): A summary of the results of the batch operation.
    """
    success: bool
    results: List[SkillStateBatchResultItem]
    summary: SkillStateBatchSummary


class InstallSkillFromGitHub(BaseModel):
    """
    Represents a request to install a skill from a GitHub repository.

    Attributes:
        repo (str): The URL of the GitHub repository containing the skill.
        skills (Optional[List[str]]): An optional list of specific skills to install from the repository.
            If not provided, all skills in the repository will be installed.
        use_npx (bool): Whether to use npx for installation. Defaults to True.
    """
    repo: str
    skills: Optional[List[str]] = None
