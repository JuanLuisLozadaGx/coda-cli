from pathlib import Path
from typing import Any, List, Optional
from collections import Counter

from loguru import logger
from coda_core.core.utils.skill_loader import SkillLoader
from coda_core.core.utils.skill_formatters import (
    generate_skill_list_for_prompt,
    generate_skill_change_notification
)
from coda_core.core.utils.github_skill_installer import GitHubSkillInstaller
from coda_core.config.settings import SETTINGS

from coda_api.core.skills.schemas import (
    SkillSummary,
    SkillDetail,
    SkillGroupedList,
    SkillStateChange,
    SkillStateBatchOperation,
    SkillStateBatchResponse,
    SkillStateBatchResultItem,
    SkillStateBatchSummary,
    SkillStateCode,
)
from coda_api.core.sessions.repository.models import APISession
from coda_api.core.sessions.repository.database import SESSIONS_DB_MANAGER


class SkillsService:

    @staticmethod
    def _map_error_to_code(error: Exception) -> str:
        """Map exception to appropriate skill state code.

        Args:
            error (Exception): The exception to map.

        Returns:
            SkillStateCode appropriate for the error type.
        """
        message = str(error).lower()
        if "not found" in message or "unknown skill" in message:
            return SkillStateCode.NOT_FOUND

        return SkillStateCode.CHANGE_FAILED

    @staticmethod
    def _apply_single_skill_state(
        loader: SkillLoader,
        skill_name: str,
        desired_enabled: bool
    ) -> SkillStateBatchResultItem:
        """Apply a single skill state change operation.

        Args:
            loader (SkillLoader): SkillLoader instance for managing skills
            skill_name (str): Name of the skill to modify
            desired_enabled (bool): Target enabled state

        Returns:
            SkillStateBatchResultItem with operation result
        """
        try:
            all_skills = loader.discover_skills(
                include_disabled=True, force_refresh=True
            )
            skill = next((item for item in all_skills if item.name == skill_name), None)
            if skill is None:
                return SkillStateBatchResultItem(
                    skill_name=skill_name,
                    desired_enabled=desired_enabled,
                    status="failed",
                    applied=False,
                    code=SkillStateCode.NOT_FOUND,
                    message=f"Skill '{skill_name}' not found",
                )

            if bool(skill.enabled) == desired_enabled:
                return SkillStateBatchResultItem(
                    skill_name=skill_name,
                    desired_enabled=desired_enabled,
                    status="unchanged",
                    applied=False,
                    code=SkillStateCode.UNCHANGED,
                    message=f"Skill '{skill_name}' is already {'enabled' if desired_enabled else 'disabled'}",
                )

            if desired_enabled:
                loader.enable_skill(skill_name)
            else:
                loader.disable_skill(skill_name)

            return SkillStateBatchResultItem(
                skill_name=skill_name,
                desired_enabled=desired_enabled,
                status="applied",
                applied=True,
                code=SkillStateCode.APPLIED,
                message=f"Skill '{skill_name}' has been {'enabled' if desired_enabled else 'disabled'} for this session",
            )
        except Exception as error:
            error_code = SkillsService._map_error_to_code(error)
            return SkillStateBatchResultItem(
                skill_name=skill_name,
                desired_enabled=desired_enabled,
                status="failed",
                applied=False,
                code=error_code,
                message=str(error),
            )

    @staticmethod
    def _build_batch_summary(results: List[SkillStateBatchResultItem]) -> SkillStateBatchSummary:
        """
        Build summary statistics from batch operation results.

        Args:
            results (List[SkillStateBatchResultItem]): List of individual operation results

        Returns:
            SkillStateBatchSummary: Summary with aggregated counts
        """
        counts = Counter(item.status for item in results)
        return SkillStateBatchSummary(
            total=len(results),
            applied=counts.get("applied", 0),
            unchanged=counts.get("unchanged", 0),
            failed=counts.get("failed", 0),
        )

    @staticmethod
    def _notify_agent_of_batch_changes(
        session: APISession,
        results: List[SkillStateBatchResultItem]
    ) -> None:
        """
        Notify agent of skill state changes and update system prompt.

        Updates the agent's system prompt once for all applied changes, then adds
        individual notification messages to the agent's memory for each change.

        Args:
            session (APISession): API session containing the agent to notify
            results (List[SkillStateBatchResultItem]): List of batch operation results
        """
        if session.shared_state.main_agent is None:
            return

        applied_changes = [r for r in results if r.status == "applied"]
        if not applied_changes:
            return

        # TODO: we might lost AGENTS.md stuff here if not re-provided?
        session.shared_state.main_agent.update_system_prompt()

        for result in applied_changes:
            action = "enabled" if result.desired_enabled else "disabled"
            notification = generate_skill_change_notification(result.skill_name, action)
            if notification:
                session.shared_state.main_agent.memory.add_assistant_message(notification)

    @staticmethod
    def _get_skill_loader(session_id: str, workspace_path: str) -> SkillLoader:
        """
        Generate a SkillLoader instance for the given session and workspace.

        Args:
            session_id (str): The ID of the session for which to load skills.
            workspace_path (str): The path to the workspace containing the skills.
        """
        project_skills_dir = Path(workspace_path) / ".coda" / "skills"
        system_skills_dir = Path(SETTINGS.private_skills_dir)

        skill_directories = [project_skills_dir, system_skills_dir]

        return SkillLoader(skill_directories=skill_directories, session_id=session_id)

    @staticmethod
    def list_skills(
        session_id: str, workspace_path: str, include_disabled: bool = False
    ) -> List[SkillSummary]:
        """
        List skills available for the given session.

        Args:
            session_id (str): The ID of the session for which to list skills.
            workspace_path (str): The path to the workspace containing the skills.
            include_disabled (bool): Whether to include disabled skills in the list.

        Returns:
            List[SkillSummary]: A list of skill summaries available to the session.
        """
        loader = SkillsService._get_skill_loader(session_id, workspace_path)
        discovered_skills = loader.discover_skills(include_disabled=True)

        skills_list = []
        for skill in discovered_skills:
            if not include_disabled and not skill.enabled:
                continue

            skills_list.append(
                SkillSummary(
                    name=skill.name,
                    description=skill.description,
                    enabled=skill.enabled,
                    source=skill.source,
                )
            )

        return skills_list

    @staticmethod
    def list_grouped_skills(
        session_id: str,
        workspace_path: str,
        include_disabled: bool = False
    ) -> SkillGroupedList:
        """
        Retrieve a list of skills grouped by their source (project vs global) for the given session.

        Args:
            session_id (str): The ID of the session for which to list skills.
            workspace_path (str): The path to the workspace containing the skills.
            include_disabled (bool): Whether to include disabled skills in the list.

        Returns:
            SkillGroupedList: An object containing lists of project and global skill summaries.
        """
        loader = SkillsService._get_skill_loader(session_id, workspace_path)
        discovered_skills = loader.discover_skills(include_disabled=True)

        project_skills_dir = Path(workspace_path) / ".coda" / "skills"
        global_skills_dir = Path(SETTINGS.private_skills_dir)

        project_skills: List[SkillSummary] = []
        global_skills: List[SkillSummary] = []

        for skill in discovered_skills:
            if not include_disabled and not skill.enabled:
                continue

            resolved_source = SkillsService._resolve_grouped_skill_source(
                skill=skill,
                project_skills_dir=project_skills_dir,
                global_skills_dir=global_skills_dir,
            )

            skill_summary = SkillSummary(
                name=skill.name,
                description=skill.description,
                enabled=skill.enabled,
                source=resolved_source,
            )

            if resolved_source == "global":
                global_skills.append(skill_summary)
            else:
                project_skills.append(skill_summary)

        return SkillGroupedList(
            project_skills=project_skills,
            global_skills=global_skills,
        )

    @staticmethod
    def _is_path_within(base_path: Path, target_path: Path) -> bool:
        try:
            target_path.resolve().relative_to(base_path.resolve())
            return True
        except (ValueError, OSError, RuntimeError):
            return False

    @staticmethod
    def _resolve_grouped_skill_source(
        skill: Any, project_skills_dir: Path, global_skills_dir: Path
    ) -> str:
        skill_path = getattr(skill, "path", None)
        if skill_path is not None:
            skill_path_obj = Path(skill_path)
            if SkillsService._is_path_within(global_skills_dir, skill_path_obj):
                return "global"
            if SkillsService._is_path_within(project_skills_dir, skill_path_obj):
                return "project"

        normalized_source = str(getattr(skill, "source", "")).strip().lower()
        if normalized_source in {"global", "system"}:
            return "global"

        return "project"

    @staticmethod
    def list_grouped_skills(
        session_id: str, workspace_path: str, include_disabled: bool = False
    ) -> SkillGroupedList:
        loader = SkillsService._get_skill_loader(session_id, workspace_path)
        discovered_skills = loader.discover_skills(include_disabled=True)

        project_skills_dir = Path(workspace_path) / ".coda" / "skills"
        global_skills_dir = Path(SETTINGS.private_skills_dir)

        project_skills: List[SkillSummary] = []
        global_skills: List[SkillSummary] = []

        for skill in discovered_skills:
            if not include_disabled and not skill.enabled:
                continue

            resolved_source = SkillsService._resolve_grouped_skill_source(
                skill=skill,
                project_skills_dir=project_skills_dir,
                global_skills_dir=global_skills_dir,
            )

            skill_summary = SkillSummary(
                name=skill.name,
                description=skill.description,
                enabled=skill.enabled,
                source=resolved_source,
            )

            if resolved_source == "global":
                global_skills.append(skill_summary)
            else:
                project_skills.append(skill_summary)

        return SkillGroupedList(
            project_skills=project_skills,
            global_skills=global_skills,
        )

    @staticmethod
    def get_skill(session_id: str, workspace_path: str, skill_name: str) -> Optional[SkillDetail]:
        """
        Get the details of a sessions specific skill by name.

        Args:
            session_id (str): The ID of the session for which to get the skill.
            workspace_path (str): The path to the workspace containing the skill.
            skill_name (str): The name of the skill to retrieve.

        Returns:
            Optional[SkillDetail]: The skill details if found, otherwise None.
        """
        loader = SkillsService._get_skill_loader(session_id, workspace_path)
        skill = loader.find_skill_by_name(skill_name)

        if skill is None:
            return None

        return SkillDetail(
            name=skill.name,
            description=skill.description,
            enabled=skill.enabled,
            source=skill.source,
            license=skill.license,
            metadata=skill.metadata,
            full_content=skill.full_content,
            is_default=skill.is_default,
            path=str(skill.path),
        )

    @staticmethod
    def enable_skill(
        session_id: str,
        workspace_path: str,
        skill_name: str,
        session: APISession
    ) -> SkillStateChange:
        """
        Enable a skill for the given session.

        Args:
            session_id (str): The ID of the session for which to enable the skill.
            workspace_path (str): The path to the workspace containing the skill.
            skill_name (str): The name of the skill to enable.
            session (APISession): The session object to update after enabling the skill.

        Returns:
            SkillStateChange: An object indicating the result of the operation.
        """
        result = SkillsService.change_skills_state_batch(
            workspace_path=workspace_path,
            operations=[SkillStateBatchOperation(skill_name=skill_name, enabled=True)],
            session=session,
        )

        SESSIONS_DB_MANAGER.save_session(session)

        item = result.results[0]
        success = item.status != "failed"
        if not success:
            logger.error(f"Error enabling skill {skill_name}: {item.message}")

        return SkillStateChange(
            success=success,
            skill_name=skill_name,
            action="enabled",
            message=item.message,
        )

    @staticmethod
    def disable_skill(
        session_id: str,
        workspace_path: str,
        skill_name: str,
        session: APISession,
    ) -> SkillStateChange:
        """
        Disable a skill for the given session.

        Args:
            session_id (str): The ID of the session for which to disable the skill.
            workspace_path (str): The path to the workspace containing the skill.
            skill_name (str): The name of the skill to disable.
            session (APISession): The session object to update after disabling the skill.

        Returns:
            SkillStateChange: An object indicating the result of the operation.
        """
        result = SkillsService.change_skills_state_batch(
            workspace_path=workspace_path,
            operations=[SkillStateBatchOperation(skill_name=skill_name, enabled=False)],
            session=session,
        )

        SESSIONS_DB_MANAGER.save_session(session)

        item = result.results[0]
        success = item.status != "failed"
        if not success:
            logger.error(f"Error disabling skill {skill_name}: {item.message}")

        return SkillStateChange(
            success=success,
            skill_name=skill_name,
            action="disabled",
            message=item.message,
        )

    @staticmethod
    def change_skills_state_batch(
        workspace_path: str,
        operations: List[SkillStateBatchOperation],
        session: APISession,
        session_id: Optional[str] = None,
    ) -> SkillStateBatchResponse:
        """Process multiple skill state changes in a single request.

        Batch semantics:
        - Last-write-wins for repeated ``skill_name`` entries in the same payload.
        - Request-level success/failure is derived from item-level ``results``.
        - Per-item status/code carries domain outcomes without raising request-level
          errors for mixed batches.
        """
        effective_operations: dict[str, SkillStateBatchOperation] = {
            operation.skill_name: operation for operation in operations
        }

        resolved_session_id = str(session.id)

        if resolved_session_id is None:
            failed_results = [
                SkillStateBatchResultItem(
                    skill_name=operation.skill_name,
                    desired_enabled=operation.enabled,
                    status="failed",
                    applied=False,
                    code=SkillStateCode.CHANGE_FAILED,
                    message="Session with valid id is required",
                )
                for operation in operations
            ]
            summary = SkillsService._build_batch_summary(failed_results)
            return SkillStateBatchResponse(
                success=False,
                results=failed_results,
                summary=summary,
            )

        session_id = str(session.id)

        try:
            loader = SkillsService._get_skill_loader(session_id, workspace_path)
        except Exception as error:
            logger.error(f"Error processing batch state change: {error}")
            failure_code = SkillsService._map_error_to_code(error)
            effective_results = [
                SkillStateBatchResultItem(
                    skill_name=operation.skill_name,
                    desired_enabled=operation.enabled,
                    status="failed",
                    applied=False,
                    code=failure_code,
                    message=str(error),
                )
                for operation in effective_operations.values()
            ]
            summary = SkillsService._build_batch_summary(effective_results)
            return SkillStateBatchResponse(
                success=False,
                results=effective_results,
                summary=summary,
            )

        effective_results: List[SkillStateBatchResultItem] = []
        for operation in effective_operations.values():
            result = SkillsService._apply_single_skill_state(
                loader=loader,
                skill_name=operation.skill_name,
                desired_enabled=operation.enabled,
            )
            effective_results.append(result)

        summary = SkillsService._build_batch_summary(effective_results)
        SkillsService._notify_agent_of_batch_changes(session, effective_results)

        SESSIONS_DB_MANAGER.save_session(session)

        return SkillStateBatchResponse(
            success=summary.failed == 0,
            results=effective_results,
            summary=summary,
        )

    @staticmethod
    def remove_skill(
        session_id: str,
        workspace_path: str,
        skill_name: str,
        session: APISession
    ) -> SkillStateChange:
        """
        Remove a skill for the given session.

        Args:
            session_id (str): The ID of the session for which to remove the skill.
            workspace_path (str): The path to the workspace containing the skill.
            skill_name (str): The name of the skill to remove.
            session (APISession): The session object to update after removing the skill.

        Returns:
            SkillStateChange: An object indicating the result of the operation.
        """
        try:
            loader = SkillsService._get_skill_loader(session_id, workspace_path)
            loader.remove_skill(skill_name)

            SkillsService._notify_agent_of_skill_change(session, skill_name, "removed")

            return SkillStateChange(
                success=True,
                skill_name=skill_name,
                action="removed",
                message=f"Skill '{skill_name}' has been removed",
            )
        except Exception as e:
            logger.error(f"Error removing skill {skill_name}: {e}")
            return SkillStateChange(
                success=False, skill_name=skill_name, action="removed", message=str(e)
            )

    @staticmethod
    def install_from_github(
        workspace_path: str,
        repo: str,
        skills: Optional[List[str]] = None
    ) -> List[SkillSummary]:
        """
        Install a skill or set of skills from a GitHub repository.

        Args:
            workspace_path (str): The path to the workspace where skills should be installed.
            repo (str): The GitHub repository URL or identifier to install from.
            skills (Optional[List[str]]): An optional list of specific skill names to install from the repository.
                If not provided, all skills in the repository will be installed.

        Returns:
            List[SkillSummary]: A list of summaries for the installed skills.

        Raises:
            Exception: If there is an error during installation, an exception will be raised with details about the failure.
        """
        try:
            project_skills_dir = Path(workspace_path) / ".coda" / "skills"
            installer = GitHubSkillInstaller(destination_dir=project_skills_dir)
            installed_paths = installer.install_from_github(repo_input=repo, skill_names=skills)

            result = []
            for skill_path in installed_paths:
                skill_name = skill_path.name
                result.append(
                    SkillSummary(
                        name=skill_name,
                        description="",
                        enabled=True,
                        source="project",
                    )
                )
            return result
        except Exception as e:
            logger.error(f"Error installing skills from {repo}: {e}")
            raise

    @staticmethod
    def refresh_skills(session_id: str, workspace_path: str) -> List[SkillSummary]:
        """
        Refresh the list of skills for the given session.

        Args:
            session_id (str): The ID of the session for which to refresh skills.
            workspace_path (str): The path to the workspace containing the skills.

        Returns:
            List[SkillSummary]: A list of summaries for the refreshed skills.
        """
        loader = SkillsService._get_skill_loader(session_id, workspace_path)
        discovered_skills = loader.discover_skills(force_refresh=True)

        return [
            SkillSummary(
                name=skill.name,
                description=skill.description,
                enabled=skill.enabled,
                source=skill.source,
            )
            for skill in discovered_skills
        ]

    @staticmethod
    def _notify_agent_of_skill_change(session: APISession, skill_name: str, action: str) -> None:
        """
        Notify the main agent of a skill change.

        Args:
            session (APISession): The API session.
            skill_name (str): The name of the skill that changed.
            action (str): The action performed on the skill (e.g., "added", "removed").
        """
        if session.shared_state.main_agent is None:
            return

        # TODO: validate agents.md stuff is kept here
        session.shared_state.main_agent.update_system_prompt()

        notification = generate_skill_change_notification(skill_name, action)
        if notification:
            session.shared_state.main_agent.memory.add_assistant_message(notification)

    @staticmethod
    def detect_skill_changes(session: APISession) -> bool:
        """
        Detect if there have been any changes to the skills since the last check.

        Args:
            session (APISession): The API session for which to detect skill changes.

        Returns:
            bool: True if there have been changes to the skills, False otherwise.
        """
        try:
            workspace_path = session.client_state.workspace_context.environment_context.workspace_path
            session_id = str(session.id)

            loader = SkillsService._get_skill_loader(session_id, workspace_path)
            current_skills = loader.discover_skills(force_refresh=True)

            cached_skills = getattr(session, "_cached_skills", None)
            if cached_skills is None:
                session._cached_skills = current_skills
                return False

            current_set = {(s.name, s.enabled) for s in current_skills}
            cached_set = {(s.name, s.enabled) for s in cached_skills}

            if current_set != cached_set:
                session._cached_skills = current_skills
                return True

            return False
        except Exception as e:
            logger.error(f"Error detecting skill changes: {e}")
            return False
