# Skills Module

This module exposes skill discovery, management (enable/disable/remove), installation, and session-level state through REST endpoints in `coda-api`.

## Architecture

The skills module follows the same conventions as other `coda-api` modules (MCP, tools):

- **Router** (`router.py`): FastAPI endpoints for skill operations
- **Service** (`service.py`): Business logic bridging coda-core's `SkillLoader`
- **Schemas** (`schemas.py`): Pydantic request/response models

All core logic is reused from `coda-core` - no duplication needed.

## Key Design Decisions

### Session-Scoped Endpoints

All skill endpoints require a `session_id` because:
- Skills are session-scoped (enable/disable/remove states are per-session)
- Workspace path comes from the session (needed for project-local skills)
- Aligns with MCP's session-scoped pattern

### SkillLoader Factory Pattern

Unlike global singletons, `SkillLoader` is created per-request because:
- It's scoped to a specific `session_id` and `workspace_path`
- Different sessions may have different workspace contexts
- Internal caching makes repeated calls lightweight

### Agent Notification

After skill state changes, the service:
1. Updates the agent's system prompt (re-renders with updated skills list)
2. Injects a notification into agent memory

This is best-effort - if the agent isn't initialized yet, changes persist and the agent picks them up on next initialization.

## Endpoints

| Route | Method | Summary |
|-------|--------|---------|
| `/skills/{session_id}` | GET | List all skills |
| `/skills/{session_id}/{skill_name}` | GET | Get skill details |
| `/skills/{session_id}/{skill_name}/enable` | PATCH | Enable a skill |
| `/skills/{session_id}/{skill_name}/disable` | PATCH | Disable a skill |
| `/skills/{session_id}/{skill_name}` | DELETE | Remove a skill |
| `/skills/{session_id}/install` | POST | Install from GitHub |
| `/skills/{session_id}/refresh` | POST | Force re-discovery |

## Pre-Flight Skill Transitions

Skills are included in `SessionsService.update_model_transitions_if_needed()` to detect filesystem changes between chat messages and update the agent's prompt automatically.

## Dependencies

All core logic comes from `coda-core`:

- `SkillLoader` - skill discovery and management
- `GitHubSkillInstaller` / `NPXSkillInstaller` - installation
- `generate_skill_change_notification` - notification formatting
- `disabled_skills.json` - session state persistence
