from typing import Dict, List, Optional

from loguru import logger
from coda_core.config.env_config import EnvConfig
from coda_core.config.settings import SETTINGS
from coda_core.core.models.providers.geai_config import GEAIConfig
from coda_core.core.models.providers.geai_client import GEAIClient
from coda_core.core.models.schemas import Model
from coda_core.core.models.utils import is_model_supported

from coda_api.core.providers.schemas import ModelResponse, ProviderModel, ProviderResponse, ProviderWithModelsResponse


class ProvidersService:
    """Providers service. All operations related to LLM providers and models management should be handled here.
    
    Attributes:
        geai_client (GEAIClient): A shared GEAI client instance for interacting with the GEAI service.
        providers (Optional[List[ProviderWithModelsResponse]]): Cached list of providers with their models.
        full_name_to_model (Dict[str, Model]): A mapping from model full names to coda-core Model instances.
    """

    # Share the geai client across different providers service instances.
    _geai_client: Optional[GEAIClient] = None

    # Share the providers list to cache them. Share it across different providers service instances.
    providers: Optional[List[ProviderWithModelsResponse]] = None

    # Map the full_name of a model to it's coda-core Model instance.
    full_name_to_model: Dict[str, Model] = {}

    @classmethod
    def get_geai_client(cls) -> Optional[GEAIClient]:
        """
        Get the shared GEAI client instance.

        Returns:
            Optional[GEAIClient]: The GEAI client instance, or None if initialization failed.
        """
        if cls._geai_client is None:
            try:
                cls._geai_client = GEAIClient(
                    config=GEAIConfig.from_api_key(
                        base_url=SETTINGS.get_env_var(EnvConfig.CODA_GEAI_BASE_URL),
                        api_key=SETTINGS.get_env_var(EnvConfig.CODA_GEAI_API_KEY)
                    )
                )
            except Exception as e:
                logger.error(f"Failed to initialize GEAIClient: {e}")

        return cls._geai_client

    @staticmethod
    def normalize_provider_name(provider_name: Optional[str]) -> str:
        """
        Normalize a provider identifier for comparisons.

        Args:
            provider_name (Optional[str]): Raw provider name.

        Returns:
            str: Lowercase normalized provider name, or an empty string.
        """
        if not isinstance(provider_name, str):
            return ""
        return provider_name.strip().lower()

    @staticmethod
    def get_canonical_provider_name(model: Optional[Model], fallback: Optional[str] = None) -> str:
        """
        Resolve the canonical provider identifier for a model.

        Args:
            model (Optional[Model]): Model metadata instance.
            fallback (Optional[str]): Fallback provider name when the model metadata
                does not expose a provider prefix.

        Returns:
            str: Canonical provider identifier.
        """
        full_name = getattr(model, "full_name", None)
        if isinstance(full_name, str) and "/" in full_name:
            provider_name, _ = full_name.split("/", maxsplit=1)
            normalized = ProvidersService.normalize_provider_name(provider_name)
            if normalized:
                return normalized

        return ProvidersService.normalize_provider_name(fallback)

    @staticmethod
    def get_providers_and_models() -> List[ProviderWithModelsResponse]:
        """
        Return GEAI providers with their available models.

        Returns:
            List[ProviderWithModelsResponse]: A list of GEAI providers with their available models.
        """
        if ProvidersService.providers is not None:
            return ProvidersService.providers

        geai_client = ProvidersService.get_geai_client()
        if geai_client is None:
            logger.error("GEAI client is not available. Cannot fetch providers and models.")
            return []

        providers = []
        for provider_info in geai_client.get_full_info().providers_with_models:
            provider_models = []

            for m in provider_info.models:
                if is_model_supported(m):
                    provider_models.append(ModelResponse.from_model(m))
                    # Keep track of coda-core Model instances, full_names are unique across all providers.
                    ProvidersService.full_name_to_model[m.full_name] = m

            if provider_models:
                providers.append(ProviderWithModelsResponse(
                    provider=ProviderResponse.from_provider(provider_info.provider),
                    models=provider_models
                ))

        # Update the providers across all the instances of ProvidersService
        ProvidersService.providers = providers

        return providers

    @staticmethod
    def get_model(provider_model: ProviderModel) -> Optional[Model]:
        """
        Get the coda-core Model instance for the given provider and model names.

        Args:
            provider_model (ProviderModel): Schema containing the provider and model names.

        Returns:
            Model: The coda-core Model instance if found, None otherwise.
        """
        if not ProvidersService.providers:
            ProvidersService.providers = ProvidersService.get_providers_and_models()

        requested_provider = ProvidersService.normalize_provider_name(provider_model.provider)

        for provider_with_models in ProvidersService.providers:
            provider_name = ProvidersService.normalize_provider_name(provider_with_models.provider.name)
            for m in provider_with_models.models:
                model_provider = ProvidersService.get_canonical_provider_name(
                    ProvidersService.full_name_to_model.get(m.full_name),
                    fallback=provider_with_models.provider.name,
                )
                if requested_provider not in {provider_name, model_provider}:
                    continue

                if m.name == provider_model.model:
                    return ProvidersService.full_name_to_model[m.full_name]

        return None
