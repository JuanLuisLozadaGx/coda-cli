from typing import List, Optional

from pydantic import BaseModel


class ProviderResponse(BaseModel):
    """Simplified schema of the Provider schema from the coda-core.

    Attributes:
        name (str): Name of the provider.
        description (str): Brief description of the provider.
    """
    name: str
    description: str

    @classmethod
    def from_provider(cls, provider) -> 'ProviderResponse':
        """Initialize a ProviderResponse schema from a Provider schema of the coda-core"""
        return cls(
            name=provider.name,
            description=provider.description
        )


class ModelResponse(BaseModel):
    """Simplified schema of the Model schema from the coda-core.

    Attributes:
        name (str): Name of the model.
        full_name (str): Fullname of the model.
        description (Optional[str]): Optional description of the model.
        context_window (int): Context window size of the model.
        max_output_tokens (int): Maximum output tokens supported by the model.
    """
    name: str
    full_name: str
    description: Optional[str]
    context_window: int
    max_output_tokens: int

    @classmethod
    def from_model(cls, model) -> 'ModelResponse':
        """Initialize a ModelResponse schema from a Model schema of the coda-core"""
        return cls(
            name=model.name,
            full_name=model.full_name,
            description=model.description,
            context_window=model.context_window,
            max_output_tokens=model.max_output_tokens
        )


class ProviderWithModelsResponse(BaseModel):
    """Schema representing a provider along with its available models.

    Attributes:
        provider (ProviderResponse): The provider information.
        models (List[ModelResponse]): The list of models available under the provider.
    """
    provider: ProviderResponse
    models: List[ModelResponse]


class ProviderModel(BaseModel):
    """Schema for specifying a provider and model.

    Attributes:
        provider (str): The name of the provider.
        model (str): The name of the model.
    """
    provider: str
    model: str
