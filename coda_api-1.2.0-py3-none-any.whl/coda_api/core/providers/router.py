from typing import List

from fastapi import APIRouter, Depends, status
from fastapi.exceptions import HTTPException
from loguru import logger

from coda_api.core.dependencies import credentials_set
from coda_api.core.providers.schemas import ProviderWithModelsResponse
from coda_api.core.providers.service import ProvidersService


providers_router = APIRouter(
    prefix="/providers",
    tags=["providers"],
    dependencies=[
        Depends(credentials_set) # All the providers endpoints require the GEAI credentials to be set.
    ]
)


@providers_router.get("", response_model=List[ProviderWithModelsResponse])
async def get_providers():
    """Return GEAI providers with their available models.

    Returns:
        List[ProviderWithModelsResponse]: A list of GEAI providers with their available models.

            The ProviderWithModelsResponse schema has the following properties:
                - provider (ProviderResponse): Information about the GEAI provider. This schema contains:
                    - name (str): Name of the provider.
                    - description (str): Brief description of the provider.

                - models (List[ModelResponse]): A list of models available for the provider. The model schema contains:
                    - name (str): Name of the model.
                    - full_name (str): Fullname of the model.
                    - description (Optional[str]): Optional description of the model.
                    - context_window (int): Context window size of the model.
                    - max_output_tokens (int): Maximum output tokens supported by the model.

    Raises:
        HTTPException:
            - status.HTTP_500_INTERNAL_SERVER_ERROR: If there's an unexpected error retrieving providers and models.
    """
    try:
        return ProvidersService.get_providers_and_models()
    except Exception as e:
        logger.exception(f"Error getting providers and models: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "Failed to retrieve providers and models",
                "detail": str(e)
            }
        )
