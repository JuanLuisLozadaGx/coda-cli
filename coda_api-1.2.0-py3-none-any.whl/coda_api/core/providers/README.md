# Providers

This module exposes information about available LLM providers and their models (retrieved from the GEAI service).


## Module Components

- **router.py**: Endpoints related to GEAI providers are defined in this file.
- **schemas.py**: This file contains all dataclasses or Pydantic models used to represent complex types related to Providers and Models.
- **service.py**: This file contains all business logic related to providers. Any operation that involves providers or models should interact with this service.

## Module Endpoints

### `GET /providers`

**Description**
Returns all providers with their supported models. Requires credentials (validated by the `credentials_set` dependency).

**Response:**
- **200 OK**
```json
[
  {
    "provider": {
      "name": "vertex_ai",
      "description": "Vertex AI Models"
    },
    "models": [
      {
        "name": "claude-3-7-sonnet-20250219",
        "full_name": "vertex_ai:claude-3-7-sonnet-20250219",
        "description": "High quality Claude model",
        "context_window": 200000,
        "max_output_tokens": 8000
      }
    ]
  },
  // ...
]
```
- **500 Internal Server Error**
```json
{
  "detail": {
    "error": "Failed to retrieve providers and models",
    "detail": "Detailed error message"
  }
}
```
