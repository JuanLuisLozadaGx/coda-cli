import asyncio
from uuid import UUID

from fastapi import APIRouter, status
from fastapi.exceptions import WebSocketException
from fastapi.websockets import WebSocket, WebSocketDisconnect
from loguru import logger

from coda_api.core.ws.service import WebSocketService
from coda_api.core.sessions.service import SessionsService


ws_router = APIRouter(prefix="/ws", tags=["WebSockets"])

# Initialize the singleton WebSocket service
WEBSOCKET_SERVICE = WebSocketService()


async def _producer(session_id: UUID):
    """
    The producer continuously produces and sends messages to the WebSocket connection.

    It uses the WEBSOCKET_SERVICE to access the WebSocket message queue and forward messages
    to the connected client.

    This function runs indefinitely, sending messages until the WebSocket connection is closed or it fails.

    Args:
        session_id (UUID): The session ID associated with the WebSocket connection.
    """
    while True:
        await WEBSOCKET_SERVICE.send_message(session_id)
    

async def _consumer(websocket: WebSocket, session_id: UUID):
    """
    The consumer continuously receives messages from the WebSocket connection.

    It uses the WEBSOCKET_SERVICE to consume the message sent by the client and forward it to the
    appropriate backend service or process.

    - This function runs indefinitely, consuming messages until the WebSocket connection is closed or it fails.
    - `iter_json()` is used, so client-generated messages have be json-serializable.

    Args:
        websocket (WebSocket): The WebSocket instance to consume messages from.
        session_id (UUID): The session ID associated with the WebSocket connection.
    """
    async for message in websocket.iter_json():
        await WEBSOCKET_SERVICE.consume_message(session_id, message)


@ws_router.websocket("/sessions/{session_id}")
async def connect_session_to_websocket(websocket: WebSocket, session_id: UUID):
    """
    WebSocket endpoint for connecting a client to a session.

    This endpoint establishes a WebSocket connection for the given session ID, enabling
    real-time, bidirectional communication between the client and the backend service.

    It ensures that the session exists and is not already connected, performs the WebSocket
    handshake, and sets up asynchronous producer and consumer tasks to handle message
    exchange.

    The function will:
        - Reject the connection if the session does not exist or is already connected.
        - Perform the WebSocket handshake and register the connection.
        - Start a producer task to send messages to the client.
        - Start a consumer task to receive messages from the client.
        - Clean up and disconnect on error or disconnect.

    Args:
        websocket (WebSocket): The WebSocket connection instance from the client.
        session_id (UUID): The unique identifier for the session to connect.

    Raises:
        WebSocketException: If the session does not exist, is already connected, or if the
            WebSocket connection fails.
    """
    if not SessionsService.session_exists(session_id) or WEBSOCKET_SERVICE.already_connected(session_id):
        logger.info(f"WebSocket connection already exists for session {session_id}.")
        raise WebSocketException(code=status.WS_1008_POLICY_VIOLATION, reason="Connection already exists or session does not exist.")
    
    # Handshake
    try:
        await WEBSOCKET_SERVICE.connect(websocket, session_id)
    except (RuntimeError, WebSocketDisconnect) as e:
        logger.exception(f"WebSocket connection failed for session {session_id}: {str(e)}")
        raise WebSocketException(code=status.WS_1011_INTERNAL_ERROR, reason="WebSocket connection failed")

    # Setup producer-consumer tasks for the WebSocket
    try:
        consumer = asyncio.create_task(_consumer(websocket, session_id))
        producer = asyncio.create_task(_producer(session_id))
        # Run producer-consumer until one completes or fails. Both are non-blocking.
        _, pending = await asyncio.wait(
            [consumer, producer], return_when=asyncio.FIRST_COMPLETED
        )
        # After any task is done, we cancel the remaining tasks
        for task in pending:
            task.cancel()
    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected for session {session_id}. Client likely closed the connection.")
    except Exception as e:
        logger.error(f"Error in WebSocket connection for session {session_id}: {e}")
    finally:
        # Cleanup WebSocket connection and interrupt any pending coordination actions
        await WEBSOCKET_SERVICE.disconnect(session_id)
