from uuid import UUID
from typing import Any, Callable, Dict, Tuple
from asyncio import Queue
import asyncio

from fastapi.websockets import WebSocket
from loguru import logger

from coda_api.core.callbacks.constants import ON_ASK_USER, ON_BASH_RISK_ASSESSMENT
from coda_api.core.consumers import on_ask_user_consumer, on_bash_risk_assessment_consumer
from coda_api.core.coordination.coordination_repository import CoordinationRepository


class WebSocketService:
    """
    Singleton class for managing WebSocket connections and operations.

    Attributes:
        _connections (Dict[UUID, Tuple[WebSocket, Queue]]):
            Dictionary mapping session IDs to WebSocket connections and their message queues.
        _message_consumers (Dict[str, Callable]):
            Dictionary mapping received message types to their respective consumer functions.
    """

    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(WebSocketService, cls).__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        if not self._initialized:
            self._connections: Dict[UUID, Tuple[WebSocket, Queue]] = {}
            self._message_consumers: Dict[str, Callable] = {
                ON_ASK_USER: on_ask_user_consumer,
                ON_BASH_RISK_ASSESSMENT: on_bash_risk_assessment_consumer
            }
            self._initialized = True

    def already_connected(self, session_id: UUID) -> bool:
        """
        Check if a WebSocket connection already exists for the given session ID.

        Args:
            session_id (UUID): The session ID to check.

        Returns:
            bool: True if a connection exists, False otherwise.
        """
        return session_id in self._connections

    async def connect(self, websocket: WebSocket, session_id: UUID) -> None:
        """
        Establish a WebSocket connection for the given session ID.
        Save the connection and initialize a message queue for it.

        Args:
            websocket (WebSocket): The WebSocket instance to connect.
            session_id (UUID): The session ID for which to establish the connection.

        Returns:
            None

        Raises:
            (Union[RunTimeError, WebSocketDisconnect]): If an error occurs during connection.
        """
        await websocket.accept()
        self._connections[session_id] = (websocket, Queue())
        logger.info(f"WebSocket connection established for session {session_id}.")

    async def disconnect(self, session_id: UUID) -> None:
        """
        Disconnect the WebSocket for the given session ID and interrupt any pending coordination actions.

        This method handles both the WebSocket disconnection and interruption of any ongoing 
        coordination actions (such as user prompts or bash risk assessments) with type-safe 
        default values:
        - ON_ASK_USER actions receive "interrupted" (string)
        - ON_BASH_RISK_ASSESSMENT actions receive False (boolean)  
        - Other/unknown action types receive None

        This prevents hanging threads and provides graceful degradation when the client
        is no longer available to provide responses.

        Args:
            session_id (UUID): The session ID for which to disconnect the WebSocket.

        Returns:
            None
        """
        # First interrupt any pending coordination actions
        coordination_repo = CoordinationRepository()
        interrupted_count = coordination_repo.interrupt_session_actions(session_id)
        
        if interrupted_count > 0:
            logger.info(f"Interruption triggered for {interrupted_count} coordination actions in session {session_id} due to client disconnect")
        
        # Then handle the WebSocket disconnection
        try:
            ws, _ = self._connections.get(session_id, (None, None))
            if ws:
                try:
                    await ws.close()
                except RuntimeError as e:
                    logger.debug(f"WebSocket for session {session_id} already closed: {str(e)}")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.error(f"Error during WebSocket disconnection for session {session_id}: {str(e)}")
        finally:
            self._connections.pop(session_id, (None, None))
            logger.info(f"WebSocket connection for session {session_id} has been disconnected.")

    async def send_message(self, session_id: UUID) -> None:
        """
        Retrieve a message from the session ID queue and send it through the WebSocket.

        Args:
            session_id (UUID): The session ID for which to send the message.

        Returns:
            None

        Raises:
            RuntimeError: If an error occurs while sending the message.
        """
        ws, queue = self._connections.get(session_id, (None, None))
        if ws and queue:
            message = await queue.get() # Block until we receive a message
            try:
                await ws.send_json(message)
                logger.info(f"A message has been sent through WebSocket for session {session_id}")
            except Exception as e:
                logger.error(f"Error sending message through WebSocket for session {session_id}: {str(e)}")
                # Propagate error to finish the connection loop
                raise RuntimeError("Error occurred while sending message") from e

    def queue_message(self, session_id: UUID, message: Dict) -> None:
        """
        Queue a message for the given session ID.

        Args:
            session_id (UUID): The session ID for which to queue the message.
            message (Dict): The message to queue. Messages should be JSON serializable.

        Returns:
            None
        """
        ws, queue = self._connections.get(session_id, (None, None))
        if ws and queue:
            queue.put_nowait(message) # WebSocketService Queues are unbounded by default, QueueFull won't be an issue here
            logger.info(f"Placed message for session {session_id}: {message}")
        else:
            logger.warning(f"No WebSocket or Queue found for session {session_id}. Message: {message} lost.")

    async def consume_message(self, session_id: UUID, message: Dict[Any, Any]) -> None:
        """
        Consume a message received from a WebSocket and forward it to the appropriate backend consumer
        function.

        For now messages are forwarded to specific consumers based on their `callback_type`. Messages with no
        `callback_type` or unknown types are ignored. Each consumer is responsible for validating the message content.

        Args:
            session_id (UUID): The session ID associated with the WebSocket connection that received the message.
            message (Dict[Any, Any]): The message received from the WebSocket.
        """
        if session_id not in self._connections:
            logger.warning(f"Received message for non-existing session {session_id}: {message}. Message will be lost.")
            return

        # For now we only consume messages with a callback_type specified
        callback_type = message.get("callback_type", None)
        if not callback_type:
            logger.warning(f"Received message without 'callback_type' for session {session_id}: {message}. Message will be lost.")
            return

        # Ignore types that do not match a registered consumer
        if callback_type not in self._message_consumers:
            logger.warning(f"Received message with unknown 'callback_type': {callback_type} for session {session_id}: {message}. Message will be lost.")
            return

        # Forward the message to its specific consumer
        await self._message_consumers[callback_type](session_id, message)
        

