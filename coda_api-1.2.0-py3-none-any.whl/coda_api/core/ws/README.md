# WS

This module defines all operations related to the management and usage of WebSockets.

## Module Components:
- **router**: Endpoints related to WebSockets are defined in this file. The router follows a [Consumer/Producer pattern](https://websockets.readthedocs.io/en/14.0/howto/patterns.html) defining an asynchronous function for each role.
    - **Consumer** will consume messages originating from clients connected to the WebSockets.
    - **Producer** will produce messages for the clients connected to the WebSockets.
- **service**: This file contains the business logic related to WebSockets. This includes connection pooling, disconnections, and message handling.


## Module Endpoints:
This module defines one endpoint that's based on the [WebSocket Protocol](https://datatracker.ietf.org/doc/html/rfc6455).


### `WS /ws/sessions/{session_id}`
**Description**
Establish a WebSocket connection for a given `session_id`.


**Path Parameter:**
- `session_id` (string, uuid): The unique identifier of the session.

**Response:**
- **Successful Connection**: If the handshake succeeds, the WebSocket connection is established and communication can begin.

- **1008 POLICY_VIOLATION**: This status code is returned if the session does not exist or already has a WebSocket connection.
  ```json
  {
    "1008": "Connection already exists or session does not exist."
  }
  ```

- **1011 INTERNAL_ERROR**: This status code is returned if an error occurs during the WebSocket handshake.
  ```json
  {
    "1011": "WebSocket connection failed"
  }
  ```
