from typing import List, Dict, Any
from loguru import logger

from coda_core.core.tools.manager import ToolManager
from coda_core.core.tools.schemas import SYSTEM_DEFAULT_TOOL_CONFIGS
from coda_core.core.utils.configuration import update_default_bash_security_level
from coda_core.core.session.states.shared_state import SharedState

from coda_api.core.tools.schemas import BashToolPreferences, AutoApproveLevel
from coda_api.core.tools.schemas import ToolInformation


tool_manager = ToolManager("global_default")


class ToolService:
    """
    Provides service methods for managing and retrieving tool information.
    
    Includes static methods to list modifiable (non-basic) tools, returning their name, description, and enabled status as ToolInformation objects.
    """
    @staticmethod
    def list_tools():
        """
        Retrieves a list of non-basic tools registered in the global tool manager.
        Iterates through all tools in the registry, and for each tool that is 
        not of type "basic", constructs a ToolInformation object containing its name, 
        short description, enabled status and read_only status. Returns the collection of these 
        tool metadata objects.
        Returns:
            List[ToolInformation]: A list of tools with their information, including:
                - name (str): The name of the tool.
                - description (str): The description of the tool.
                - enabled (bool): Whether the tool is enabled or not.
                - read_only (bool): Whether the tool is read-only or not.
        """
        tools = tool_manager.registry.list_tools()
        all_tools: List[ToolInformation] = []

        tool_to_category_map = {}
        for category_name, category_tools in SYSTEM_DEFAULT_TOOL_CONFIGS.items():
            for tool_name in category_tools.keys():
                tool_to_category_map[tool_name] = category_name

        for tool_name in tools:
            tool_info = tool_manager.get_tool_info(tool_name)
            tool_category = tool_to_category_map.get(tool_name, "Uncategorized")
            
            # Determine if the tool is a basic tool and set default read_only accordingly
            is_basic_tool = tool_name in SYSTEM_DEFAULT_TOOL_CONFIGS.get("basic", {})
            default_read_only = True if is_basic_tool else False
            
            tool_config = ToolInformation(
                name=tool_name,
                description=tool_info.get("short_description", ""),
                enabled=tool_info.get("enabled", False),
                read_only=tool_info.get("read_only", default_read_only),
                category=tool_category,
            )
            all_tools.append(tool_config)
        return all_tools


    @staticmethod
    def list_modifiable_tools():
        """
        List all tools that can be modified (i.e., not basic tools).
        Returns:
            List[ToolInformation]: A list of tools with their information, including:
                - name (str): The name of the tool.
                - description (str): The description of the tool.
                - enabled (bool): Whether the tool is enabled or not.
                - read_only (bool): Whether the tool is read-only or not.
                - category (str): The category of the tool.
        """
        tools = tool_manager.registry.list_tools()
        modifiable_tools: List[ToolInformation] = []

        # Create a map of tool names to their categories, similar to list_tools method
        tool_to_category_map = {}
        for category_name, category_tools in SYSTEM_DEFAULT_TOOL_CONFIGS.items():
            for tool_name in category_tools.keys():
                tool_to_category_map[tool_name] = category_name

        for tool_name in tools:
            # Skip basic tools
            if tool_name in SYSTEM_DEFAULT_TOOL_CONFIGS.get("basic", {}):
                continue
                
            tool_info = tool_manager.get_tool_info(tool_name)
            # Get the tool category from the map, or use "Uncategorized" as fallback
            tool_category = tool_to_category_map.get(tool_name, "Uncategorized")
            
            tool_config = ToolInformation(
                name=tool_name,
                description=tool_info.get("short_description", ""),
                enabled=tool_info.get("enabled", False),
                read_only=tool_info.get("read_only", False),
                category=tool_category,
            )
            modifiable_tools.append(tool_config)
        return modifiable_tools


    @staticmethod
    def get_bash_tool_preferences() -> BashToolPreferences:
        """
        Get the current bash tool preferences from SharedState.
        
        Returns:
            BashToolPreferences: The current bash tool preferences.
        """
        shared_state = SharedState()
        
        max_auto_approve_level = shared_state.preferences.get("bash_security", {}).get(
            "max_auto_approve_level", "medium"
        )
        
        return BashToolPreferences(max_auto_approve_level=AutoApproveLevel(max_auto_approve_level))


    @staticmethod
    def update_bash_tool_preferences(max_auto_approve_level: AutoApproveLevel) -> Dict[str, Any]:
        """
        Update the bash tool preferences using coda_core's update_default_bash_security_level function.
        
        Args:
            max_auto_approve_level (AutoApproveLevel): The new auto-approve level for bash tool preferences. Should be one of the values defined in AutoApproveLevel enum.
            
        Returns:
            Dict[str, Any]: A response indicating whether the update was successful.
        """
        try:            
            update_result = update_default_bash_security_level(max_auto_approve_level)
            
            if not update_result:
                return False
            
            logger.info(f"Updated bash tool preferences to: {max_auto_approve_level}")
            
            return True
        except Exception as e:
            logger.error(f"Failed to update bash tool preferences: {str(e)}")
            return False