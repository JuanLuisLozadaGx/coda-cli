from typing import List
from fastapi import APIRouter, HTTPException
from loguru import logger

from coda_api.core.tools.schemas import ToolInformation, BashToolPreferences
from coda_api.core.tools.service import ToolService 


tools_router = APIRouter(prefix="/tools", tags=["tools"])


@tools_router.get("/", response_model=List[ToolInformation])
def list_tools():
    """
    List only tools that can be modified (i.e., not basic tools).
    Args:
        None
    Returns:
        List[ToolInformation]: A list of tools with their information, including:
            - name (str): The name of the tool.
            - description (str): The description of the tool.
            - enabled (bool): Whether the tool is enabled or not.
            - read_only (bool): Whether the tool is read-only or not.
            - category (str): The category of the tool.
    Raises:
        HTTPException: If there is an error listing the tools.
    """
    try:
        return ToolService.list_tools()
    except Exception as e:
        logger.error(f"Error listing tools: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to list tools")


@tools_router.get("/bash/preferences", response_model=BashToolPreferences)
def get_bash_tool_preferences():
    """
    Get the current bash tool preferences.
    
    Returns:
        BashToolPreferences: The current bash tool preferences.
    Raises:
        HTTPException: If there is an error retrieving the bash tool preferences.
    """
    try:
        return ToolService.get_bash_tool_preferences()
    except Exception as e:
        logger.error(f"Error retrieving bash tool preferences: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retrieve bash tool preferences")
