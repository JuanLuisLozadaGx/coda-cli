from pydantic import BaseModel
from enum import Enum


class AutoApproveLevel(str, Enum):
    """Enum for Bash Tool auto-approve levels.
    
    Matches the levels used in coda_core for bash security.
    
    Attributes:
        LOW: Low auto-approve level, requiring more confirmations for commands.
        MEDIUM: Medium auto-approve level, requiring moderate confirmations for commands.
        HIGH: High auto-approve level, requiring fewer confirmations for commands.
    """
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ToolInformation(BaseModel):
    """Schema for tool information.

    Attributes:
        name (str): The name of the tool.
        description (str): The description of the tool.
        enabled (bool): Whether the tool is enabled or not.
        read_only (bool): Whether the tool is read-only or not.
        category (str): The category of the tool.
    """
    name: str
    description: str
    enabled: bool
    read_only: bool
    category: str


class BashToolPreferences(BaseModel):
    """Schema for Bash Tool preferences.
    
    Matches the preferences structure used in coda_core's SharedState.preferences["bash_security"].
    
    Attributes:
        max_auto_approve_level (AutoApproveLevel): The maximum level at which bash commands
            are automatically approved without user confirmation.
    """
    max_auto_approve_level: AutoApproveLevel
