from pydantic import BaseModel


class ConsumerMessage(BaseModel):
    """
    Base schema for consumer messages.

    Attributes:
        correlation_id (str): A correlation ID to link requests and responses.
    """
    correlation_id: str


class OnBashRiskAssessmentConsumerMessage(ConsumerMessage):
    """
    Schema for the `on_bash_risk_assessment_consumer` consumer messages.

    Attributes:
        approve (bool): Whether to approve the bash command execution or not.
    """
    approve: bool


class OnAskUserConsumerMessage(ConsumerMessage):
    """
    Schema for the `on_ask_user_consumer` consumer messages.

    Attributes:
        answer (str): The user's answer to the question asked.
    """
    answer: str
