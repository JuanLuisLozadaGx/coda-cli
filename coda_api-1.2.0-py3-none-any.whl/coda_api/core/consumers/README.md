# Consumers

This module defines all Consumer functions used to process messages provided by different clients of the CODA API through WebSockets.

## What are Consumers?
Consumers are async functions invoked by `WebSocketService` to handle client messages. They are registered in `WebSocketService.__message_consumers` and used by `WebSocketService.consume_message`.

## Module Components
- **consumer functions**: Each consumer function is defined in its own file. If the logic is too complex, a module can be defined.
- **schemas**: This file contains all dataclasses or Pydantic models used to represent complex types related to Consumers.

## Adding new Consumers
The consumers are tied to the messages provided by the CODA API clients and the desired logic behind the message.

### Steps to add a Consumer:
- Coordinate with the client on the message schema and desired behavior.
- Assign a callback type to the message.
- Implement an `async` consumer function.
- Register the consumer in `WebSocketService`. See the [WebSocket module documentation](/coda_api/core/ws/README.md).

## Exporting Consumers
For now, import each consumer function in the module's `__init__.py` file and add its name to the `__all__` list.

If the number of consumers grows too large, the previous approach will be undone and each consumer should be imported separately.

## Current Consumers

### [on_bash_risk_assessment_consumer](/coda_api/core/consumers/on_bash_risk_assessment.py)

The `on_bash_risk_assessment_consumer` consumes a client message containing information about whether a bash risk assessment was approved or not by the user.

Based on the parsed input from the user, the consumer updates the corresponding `CoordinationAction` to unblock the `on_bash_risk_assessment_callback`.

This consumer function is associated with the `ON_BASH_RISK_ASSESSMENT` callback type.

#### Schema Message
The message received by this consumer is the `OnBashRiskAssessmentConsumerMessage`. The serialized structure of this message looks like this:

```json
{
  "correlation_id": "e3b0c442-98fc-1fc4-9b32-8d6e4e6e8e8e",
  "approve": true
}
```

### [on_ask_user_consumer](/coda_api/core/consumers/on_ask_user.py)

The `on_ask_user_consumer` consumes a client message containing the user answer to a question asked by the CODA Agent.

Based on the parsed input from the user, the consumer updates the corresponding `CoordinationAction` to unblock the `on_ask_user_callback`.

This consumer function is associated with the `ON_ASK_USER` callback type.

#### Schema Message
The message received by this consumer is the `OnAskUserConsumerMessage`. The serialized structure of this message looks like this:

```json
{
  "correlation_id": "e3b0c442-98fc-1fc4-9b32-8d6e4e6e8e8e",
  "answer": "User answer to the CODA Agent question."
}
```
