from typing import Any, Dict
from uuid import UUID

from pydantic import ValidationError
from loguru import logger

from coda_api.core.coordination.coordination_repository import CoordinationRepository
from coda_api.core.consumers.schemas import OnBashRiskAssessmentConsumerMessage


async def on_bash_risk_assessment_consumer(session_id: UUID, message: Dict[Any, Any]):
    """
    Consumer function for the `on_bash_risk_assessment_consumer` messages. This function parses the
    message received from the client and updates the corresponding `CoordinationAction` based on the
    user's decision.

    The message should follow the `OnBashRiskAssessmentConsumerMessage` schema. If the message contains
    additional information not defined in the schema, it will be ignored.

    Args:
        session_id (UUID): The session ID associated with the message.
        message (Dict[Any, Any]): The message received from the client.

    Returns:
        None
    """
    try:
        consumer_message = OnBashRiskAssessmentConsumerMessage.model_validate(message)
    except (TypeError, ValidationError) as e:
        logger.error(f"Session: {session_id}. Failed to validate message in 'on_bash_risk_assessment_consumer': {e}")
        return

    coordination_action = CoordinationRepository().get(session_id=session_id, correlation_id=consumer_message.correlation_id)
    if not coordination_action:
        logger.warning(f"No coordination action found for session {session_id} and correlation ID {consumer_message.correlation_id}.")
        return

    # Update the coordination_action result based on the message content.
    coordination_action.result = consumer_message.approve
    coordination_action.event.set()
