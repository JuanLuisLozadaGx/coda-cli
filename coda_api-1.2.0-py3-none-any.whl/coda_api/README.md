# Coda API

This is the main module of the Coda REST API. All endpoints, business logic and configuration settings are defined within this folder.

## Key Module Descriptions
Each module has its own README with their respective documentation. Here's a high level description of each module of the API:

### Core
The core module contains all business logic related to the Coda REST API. Here's each submodule that belongs to the core:
- **agents**: Contains all logic related to Agents and Subagents. [Module docs](core/agents/README.md)
- **callbacks**: Contains all logic related to Callbacks. [Module docs](core/callbacks/README.md)
- **consumers**: Contains all logic related to Consumers. [Module docs](core/consumers/README.md)
- **context**: Contains all logic related to the Context of the CODA Agent. [Module docs](core/context/README.md)
- **coordination**: Contains all logic related to coordination of events between callbacks and consumers. [Module docs](core/coordination/README.md)
- **dependencies**: Contains all endpoint related dependencies, as in [FastAPI docs](https://fastapi.tiangolo.com/tutorial/dependencies/). Dependencies might look similar to **middleware**, but the main difference is dependencies can be injected into a specific endpoint whereas middleware applies to all the endpoints in the API. [Module docs](core/dependencies/README.md)
- **mcp**: Contains all logic related with MCP Servers used by the CODA Agent. [Module docs](core/mcp/README.md)
- **providers**: Contains all logic related to Providers. [Module docs](core/providers/README.md)
- **sessions**: Contains all logic related to Sessions. [Module docs](core/sessions/README.md)
- **tools**: Contains all logic related to Tools used by the CODA Agent. [Module docs](core/tools/README.md)
- **ws**: Contains all WebSocket protocol logic, this includes endpoints and connections management. [Module docs](core/ws/README.md)

### Config
The config module contains all configuration, settings, or cross-application properties in one place. [Module docs](config/README.md)

### Modules Components
Each module can define the components they need, but there are some standardized components for specific operations:
- **router**: The router component is used to define all endpoints related to the module.
- **service**: The service component is used to define all business logic related to the module.
- **schemas**: The schemas service is used to define dataclasses, Pydantic models, or complex types related to the module.
- **models**: The models service is used to define database-storage models related to the module.

Anything that does not fit into this standardized components, should be made in a new component. For example:
- **utils**: General purpose utility functions related to the module.
- **constants**: Constants related to the module.

## Shared Logic
- Any logic shared across different modules, should be added in the **Core Module**.
- Any configuration shared across different modules, should be added in the **Config Module**.

## Session Metadata

The Coda API automatically captures and sends contextual metadata to coda-core agents during session interactions. This metadata enriches agent responses with information about the execution environment, enabling better tracking, analytics, and debugging.

The metadata includes session identifiers, client type, and user information. It leverages coda-core's metadata module (`SessionMetadata` schema and `extract_metadata` function) to ensure consistency across all Coda clients. The process is fully automatic, transparent to users, and resilient to failures.

## Modules Endpoints

Each module defines its own endpoints, documented in their respective README files. For details on available endpoints and usage, refer to:

- [Config Module Endpoints](config/README.md)
- [Agents Module Endpoints](core/agents/README.md)
- [MCP Module Endpoints](core/mcp/README.md)
- [Sessions Module Endpoints](core/sessions/README.md)
- [Tools Module Endpoints](core/tools/README.md)
- [Providers Module Endpoints](core/providers/README.md)
- [WebSocket Module Endpoints](core/ws/README.md)

See each module's README for request/response formats and their requirements.
