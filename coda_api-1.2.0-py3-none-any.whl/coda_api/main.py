"""
    Entry point for the Coda REST API.
"""
import argparse
import uvicorn


def main():
    """
    Main entry point for the Coda REST API server.
    """
    parser = argparse.ArgumentParser(description="Run the Coda REST API server.")
    parser.add_argument("port", type=int, help="Port to bind to")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to (default: 127.0.0.1)")
    args = parser.parse_args()

    # Start the FastAPI application.
    uvicorn.run(
        "coda_api.app:app",
        host=args.host,
        port=args.port
    )

if __name__ == "__main__":
    main()
