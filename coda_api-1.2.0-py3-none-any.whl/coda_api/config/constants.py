"""Constants for the Coda API configuration"""


GEAI_VALIDATION_URL = "/v1/accessControl/apitoken/validate"
CLIENT_NAME = "API"