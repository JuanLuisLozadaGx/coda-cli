from typing import Optional

from pydantic import BaseModel, field_validator, model_validator



class ConfigMemoryCondensing(BaseModel):
    """Schema for the application configuration of memory condensing.

        Attributes:
            enabled (bool): Indicates if memory condensing should be enabled.
            threshold (Optional[float]): The threshold for memory condensing. Must be a value between 0.3 and 0.9.
    """
    enabled: bool
    threshold: Optional[float] = None

    @field_validator('threshold')
    @classmethod
    def validate_threshold_range(cls, v: float) -> float:
        if v is not None and not (0.3 <= v <= 0.9):
            raise ValueError('Threshold must be between 0.3 and 0.9')
        return v

    @model_validator(mode="after")
    def check_enabled_and_threshold(self):
        if not self.enabled and self.threshold is not None:
            raise ValueError("Cannot set 'threshold' when 'enabled' is False.")
        return self


class ConfigCredentials(BaseModel):
    """Schema for the application configuration credentials.

        Attributes:
            url (str): The base URL for the service.
            api_key (str): The API key for authenticating with the service.
            azure_token (str, optional): The Azure token for additional authentication.
    """
    url: str
    api_key: str
    azure_token: Optional[str] = None


class ConfigStatus(BaseModel):
    """Schema for the application configuration status.

        Attributes:
            geai_credentials_set (bool): Indicates if GEAI credentials are set.
            geai_credentials_valid (bool): Indicates if the GEAI credentials are valid.
            azure_token_set (bool): Indicates if the Azure token is set.
    """
    geai_credentials_set: bool
    geai_credentials_valid: bool
    azure_token_set: bool


class ConfigValues(BaseModel):
    """Schema for the application configuration values.

        Attributes:
            url (Optional[str]): The base URL for the service.
            api_key (Optional[str]): The API key for authenticating with the service. Trimmed to half its length.
            azure_token (Optional[str]): The Azure token for additional authentication. Trimmed to half its length.
            memory_condensing_enabled (bool): Indicates if memory condensing is enabled.
            memory_condensing_threshold (float): The threshold for memory condensing.
            provider (str): The name of the globally configured provider.
            model (str): The name of the globally configured model.
    """
    url: Optional[str] = None
    api_key: Optional[str] = None
    azure_token: Optional[str] = None
    memory_condensing_enabled: bool
    memory_condensing_threshold: float
    provider: str
    model: str

    @field_validator('api_key', 'azure_token')
    @classmethod
    def trim_sensitive_fields(cls, v: Optional[str]) -> Optional[str]:
        if v:
            v_half = len(v) // 2
            return v[:v_half]
        return v
