# Config

This module handles all the configuration, settings, and cross-application properties.

## Modules Components
- **router**: Endpoints related to configuration operations are defined in this file.
- **service**: This file contains all business logic related to the application configuration.
- **schemas**: This file contains all dataclasses or Pydantic models used to represent complex types related to the application configuration.
- **constants**: Constants related to application configuration or shared across modules in the application are defined in this file.

## Module Endpoints

### `POST /config/credentials`

**Description:**
Setup the application credentials. This endpoint validates the credentials before saving them.

**Request Body:**
```json
{
  "url": "string",
  "api_key": "string",
  "azure_token":  "string" // This parameter is optional.
}
```

**Response:**
- **200 OK**

  ```json
  {
    "success": "bool",
    "message": "Credentials posted successfully"
  }
  ```

- **400 Bad Request**

  ```json
  {
    "detail": {
        "success": "bool",
        "message": "Invalid credentials provided. Please verify your API Key and URL."
    }
  }
  ```

### `GET /config/status`

**Description:**
This endpoint retrieves the current configuration status of the application.

**Response:**
- **200 OK**

  ```json
  {
    "geai_credentials_set": true,
    "geai_credentials_valid": true,
    "azure_token_set": true
  }
  ```

### `GET /config/values`

**Description:**
This endpoint retrieves the current configuration values set for the application.

Sensitive values are trimmed to half for security reasons. For now the sensitive values are:
  - **api_key**
  - **azure_token**

**Response:**
- **200 OK**

  ```json
  {
    "url": "string (optional)",
    "api_key": "string (optional)", // Trimmed to half it's length
    "azure_token": "string (optional)", // Trimmed to half it's length
    "provider": "string",
    "model": "string"
  }
  ```

### `POST /config/set-default-provider-model`

**Description:**
Setup the global provider and model for the API. Requires credentials (validated by the `credentials_set` dependency).

**Request Body:**
```json
{
  "provider": "string",
  "model": "string"
}
```

**Response:**
- **200 OK**
  ```json
  {
    "message": "Default provider and model set successfully"
  }
  ```

- **400 Bad Request**
  ```json
  {
    "error": "Invalid provider or model",
    "detail": "The specified provider: $provider_name or model: $model_name is not valid."
  }
  ```

- **500 Internal Server Error**
  ```json
  {
    "detail": {
      "error": "Failed to set default provider and model",
      "detail": "string" // Detailed error message
    }
  }
  ```

### `PATCH /config/memory-condensing`


**Description**
Update the global memory condensing settings for the API. Requires credentials (validated by the `credentials_set` dependency).

**Request Body:** The request body is validated by the `ConfigMemoryCondensing` schema. For more documentation regarding validation, read the schema docstrings.

```json
{
  "enabled": true, // Optional
  "threshold": 0.7 // Optional
}
```

**Response:**
- **200 OK**
  ```json
  {
    "message": "Memory condensing configuration updated successfully.",
    "success": true
  }
  ```

- **422 Unprocessable Entity**: This status will be returned if any validation by the `ConfigMemoryCondensing` schema fails.
  ```json
  {
    "detail": [
      {
        "type": "value_error",
        "loc": [
          "body"
        ],
        "msg": "Value error, Cannot set 'threshold' when 'enabled' is False.",
        "input": {
          "enabled": false,
          "threshold": 0.5
        },
        "ctx": {
          "error": {}
        }
      }
    ]
  }
  ```

- **500 Internal Server Error**
  ```json
  {
    "detail": {
      "message": "An error occurred while updating memory condensing configuration.",
      "success": false
    }
  }
  ```
