from loguru import logger
from fastapi import APIRouter, Depends, Depends, status
from fastapi.exceptions import HTTPException
from fastapi.responses import JSONResponse
from loguru import logger

from coda_api.config.schemas import (
    ConfigCredentials, ConfigMemoryCondensing, ConfigStatus, ConfigValues
)
from coda_api.config.service import ConfigService
from coda_api.core.dependencies import credentials_set
from coda_api.core.providers.schemas import ProviderModel
from coda_api.core.providers.service import ProvidersService
from coda_api.core.tools.service import ToolService


config_router = APIRouter(prefix="/config", tags=["config"])


@config_router.post("/credentials")
async def post_config_credentials(credentials: ConfigCredentials):
    """
    Endpoint to post configuration credentials.
    
    Args:
        credentials (ConfigCredentials): The configuration credentials to be posted. This schema includes:
            - url (str): The base URL for the service.
            - api_key (str): The API key for authenticating with the service.
            - azure_token (str, optional): The Azure token for additional authentication.
    
    Returns:
        JSONResponse: A response indicating whether the credentials were posted successfully or not. The response contains:
            - success (bool): True if the credentials are valid and posted successfully, False otherwise.
            - message (str): A message indicating the result of the operation.
    
    Raises:
        HTTPException: If the credentials are invalid. The exception contains:
            - status_code (int): 400 Bad Request if the credentials are invalid.
            - detail (dict): A dictionary with success status and an error message.
    """
    success = ConfigService.validate_and_post_credentials(credentials)
    if success:
        return JSONResponse(
            content={
                "success": success,
                "message": "Credentials posted successfully"
            }
        )
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail={
            "success": success,
            "message": "Invalid credentials provided. Please verify your API Key and URL."
        }
    )


@config_router.get("/status", response_model=ConfigStatus)
async def get_config_status():
    """Endpoint to get the configuration status of the application.

    Returns:
        ConfigStatus: The current configuration status. This schema includes:
            - geai_credentials_set (bool): Indicates if GEAI credentials are set.
            - geai_credentials_valid (bool): Indicates if the GEAI credentials are valid.
            - azure_token_set (bool): Indicates if the Azure token is set.
    """
    return ConfigService.get_config_status()


@config_router.get("/values", response_model=ConfigValues)
async def get_config_values():
    """Endpoint to get the configuration values of the application.

    Sensitive values are trimmed for security.

    Returns:
        ConfigValues: The current configuration values. This schema includes:
            - url (str, optional): The base URL for the service.
            - api_key (str, optional): The API key for authenticating with the service. Trimmed to half its length.
            - azure_token (str, optional): The Azure token for additional authentication. Trimmed to half its length.
            - provider (str): The name of the globally configured provider.
            - model (str): The name of the globally configured model.
    """
    return ConfigService.get_config_values()


@config_router.post("/set-default-provider-model", dependencies=[Depends(credentials_set)])
async def set_provider_and_model(provider_model: ProviderModel):
    """
    Set the global provider and model configuration for the application.

    This endpoint updates the global provider and model settings, and also updates all existing sessions.

    Args:
        provider_model (ProviderModel): The provider and model to set as default. This schema includes:
            - provider (str): The name of the provider to set as default.
            - model (str): The name of the model to set as default.

    Returns:
        JSONResponse:
            - status.HTTP_200_OK: If the provider and model were set successfully.
            - status.HTTP_400_BAD_REQUEST: If the provider/model combination is invalid.

    Raises:
        HTTPException:
            - status.HTTP_500_INTERNAL_SERVER_ERROR: If an unexpected error occurs while setting the provider and model.
    """
    try:
        new_model = ProvidersService.get_model(provider_model)

        if not new_model:
            # Failed to update, meaning we received an invalid provider/model combination.
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content={
                    "error": "Invalid provider or model",
                    "detail": f"The specified provider: {provider_model.provider} or model: {provider_model.model} is not valid."
                }
            )

        ConfigService.set_provider_and_model(provider_name=provider_model.provider, model=new_model)

        return {
            "message": "Default provider and model set successfully"
        }
    except Exception as e:
        logger.exception(f"Unexpected error setting default provider and model: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "Failed to set default provider and model",
                "detail": str(e)
            }
        )


@config_router.patch("/memory-condensing", dependencies=[Depends(credentials_set)])
async def update_memory_condensing(memory_condensing_config: ConfigMemoryCondensing):
    """Endpoint to update the memory condensing configuration of the application.

    The memory condensing configuration validation is handled by the ConfigMemoryCondensing schema. For any
    invalid configuration, a 422 Unprocessable Entity error will be returned.

    Args:
        memory_condensing_config (ConfigMemoryCondensing): The memory condensing configuration to be set. This schema includes:
            - enabled (bool): Enables or disables memory condensing.
            - threshold (Optional[float]): The threshold for memory condensing.

    Returns:
        JSONResponse: A response indicating whether the memory condensing configuration was updated successfully. The response contains:
            - message (str): A message indicating the result of the operation.
            - success (bool): True if the configuration was updated successfully.

    Raises:
        HTTPException: If an error occurs while setting the memory condensing configuration.
            - status.HTTP_500_INTERNAL_SERVER_ERROR: If the update fails due to an unexpected error.

        ValueError: For any validation errors in the received configuration.
            - status.HTTP_422_UNPROCESSABLE_ENTITY: If the memory condensing configuration is invalid.
    """
    try:
        ConfigService.update_memory_condensing(memory_condensing_config)
        return JSONResponse(
            content={
                "message": "Memory condensing configuration updated successfully.",
                "success": True
            },
            status_code=status.HTTP_200_OK
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "message": "An error occurred while updating memory condensing configuration.",
                "success": False
            }
        )


@config_router.patch("/tools/{tool_name}")
async def toggle_tool(tool_name: str, enabled: bool):
    """
    Endpoint to activate or deactivate a tool.

    Args:
        tool_name (str): The name of the tool to be toggled.
        enabled (bool): A boolean indicating whether to enable (True) or disable (False) the tool.

     Returns:
        JSONResponse: On success, returns a JSON object with:
            - success (bool): True if the tool was toggled successfully.
            - tool (str): The name of the tool.
            - enabled (bool): The new enabled status of the tool.

    Raises:
        HTTPException: If the tool cannot be toggled due to an internal error, raises with:
            - status_code (int): 500 Internal Server Error.
            - detail (dict): A dictionary containing:
                - success (bool): False.
                - message (str): "Failed to toggle tool".
    """
    success = ConfigService.toggle_tool(tool_name, enabled)
    if success:
        return JSONResponse(
            content={
                "success": success,
                "tool": tool_name,
                "enabled": enabled
            }
        )
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail={
            "success": success,
            "message": "Failed to toggle tool"
        }
    )


@config_router.post("/bash/preferences/{auto_approve_level}")
async def update_bash_tool_preferences(auto_approve_level: str):
    """
    Update the bash tool preferences.
    
    Args:
        auto_approve_level (str): The new auto-approve level for bash tool preferences. Should be one of the values defined in AutoApproveLevel enum.
        
    Returns:
        JSONResponse: A response indicating whether the update was successful.
    """
    result = ToolService.update_bash_tool_preferences(auto_approve_level)
    if result:
        return JSONResponse(
            content={
                "success": True,
                "message": "Bash tool preferences updated successfully"
            }
        )
    else:
        return JSONResponse(
            status_code=400,
            content={
                "success": False,
                "message": result.get("message", "Failed to update bash tool preferences")
            }
        )
    