from typing import Dict, Tuple

import requests
from loguru import logger
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.core.models.schemas import Model
from coda_core.core.utils.configuration import update_default_model

from coda_api.config.schemas import ConfigCredentials, ConfigMemoryCondensing, ConfigStatus, ConfigValues
from coda_api.config.constants import GEAI_VALIDATION_URL
from coda_api.core.providers.service import ProvidersService
from coda_api.core.tools.service import tool_manager


class ConfigService:
    """
    Configuration service. All operations related to configuration management
    should be handled here.
    """

    _VALIDATED_GEAI_CREDENTIALS: Dict[Tuple[str, str], bool] = {} # Cache of validated GEAI credentials

    @staticmethod
    def _validate_geai(url: str, api_key: str):
        """
        Validate GEAI credentials.

        Args:
            url (str): The base URL for the GEAI Service.
            api_key (str): The API key for authenticating with the GEAI Service.

        Raises:
            HTTPError: If the validation request fails.
            Exception: If any other error occurs during the validation request.
        """
        url = f"{url}{GEAI_VALIDATION_URL}"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Accept": "application/json"
        }
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
        except requests.exceptions.HTTPError as http_err:
            logger.exception(f"HTTP error occurred: {http_err}")
            raise http_err
        except Exception as err:
            logger.exception(f"An error occurred: {err}")
            raise err

    @staticmethod
    def validate_and_post_credentials(credentials: ConfigCredentials) -> bool:
        """
        Validate and post the configuration credentials. A validation to the credentials
        service is performed before posting them.

        Returns:
            bool: True if the credentials are valid and posted successfully, False otherwise.
        """
        try:
            ConfigService._validate_geai(credentials.url, credentials.api_key)
            # Post credentials
            SETTINGS.set_env_var(EnvConfig.CODA_GEAI_BASE_URL, credentials.url)
            SETTINGS.set_env_var(EnvConfig.CODA_GEAI_API_KEY, credentials.api_key)
            if credentials.azure_token:
                # Azure token is not required for the functionality of the application
                SETTINGS.set_env_var(EnvConfig.CODA_PYPI_REPO_TOKEN, credentials.azure_token)
            return True
        except Exception:
            return False

    @staticmethod
    def are_geai_credentials_set() -> bool:
        """
        Verify if the GEAI credentials are set in the configuration settings.

        Returns:
            bool: True if GEAI credentials are set, False otherwise.
        """
        return bool(SETTINGS.get_env_var(EnvConfig.CODA_GEAI_API_KEY)) and \
               bool(SETTINGS.get_env_var(EnvConfig.CODA_GEAI_BASE_URL))

    @staticmethod
    def get_config_status() -> ConfigStatus:
        """
        Get the current configuration status based on environment variables.

        Returns:
            ConfigStatus: The current configuration status.
        """
        geai_credentials_set = ConfigService.are_geai_credentials_set()
        geai_credentials_valid = False

        if geai_credentials_set:
            credentials_pair = (
                SETTINGS.get_env_var(EnvConfig.CODA_GEAI_BASE_URL),
                SETTINGS.get_env_var(EnvConfig.CODA_GEAI_API_KEY)
            )

            if credentials_pair in ConfigService._VALIDATED_GEAI_CREDENTIALS:
                geai_credentials_valid = ConfigService._VALIDATED_GEAI_CREDENTIALS[credentials_pair]
            else:
                try:
                    ConfigService._validate_geai(url=credentials_pair[0], api_key=credentials_pair[1])
                    geai_credentials_valid = True
                except Exception:
                    geai_credentials_valid = False
                finally:
                    ConfigService._VALIDATED_GEAI_CREDENTIALS[credentials_pair] = geai_credentials_valid

        return ConfigStatus(
            geai_credentials_set=geai_credentials_set,
            geai_credentials_valid=geai_credentials_valid,
            azure_token_set=bool(SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_TOKEN))
        )

    @staticmethod
    def get_config_values() -> ConfigValues:
        """
        Get the current configuration values based on environment variables.

        Returns:
            ConfigValues: The current configuration values.
        """
        return ConfigValues(
            url=SETTINGS.get_env_var(EnvConfig.CODA_GEAI_BASE_URL),
            api_key=SETTINGS.get_env_var(EnvConfig.CODA_GEAI_API_KEY),
            azure_token=SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_TOKEN),
            memory_condensing_enabled=SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_ENABLED).lower() == "true",
            memory_condensing_threshold=float(SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_THRESHOLD)),
            provider=SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_PROVIDER_NAME),
            model=SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_MODEL_NAME)
        )

    @staticmethod
    def update_memory_condensing(memory_condensing_config: ConfigMemoryCondensing):
        """
        Update the memory condensing settings.

        Args:
            memory_condensing_config (ConfigMemoryCondensing): The memory condensing configuration to update.
        """
        if memory_condensing_config.enabled:
            SETTINGS.set_env_var(EnvConfig.CODA_MEMORY_CONDENSING_ENABLED, "true")
            if memory_condensing_config.threshold is not None:
                SETTINGS.set_env_var(EnvConfig.CODA_MEMORY_CONDENSING_THRESHOLD, str(memory_condensing_config.threshold))
        else:
            SETTINGS.set_env_var(EnvConfig.CODA_MEMORY_CONDENSING_ENABLED, "false")

    @staticmethod
    def set_provider_and_model(provider_name: str, model: Model):
        """
        Set a given provider and model as the global default for the application.

        Args:
            provider_name (str): The name of the provider to set as default.
            model (Model): The model to set as default. The model type is a coda-core Model instance.

        Raises:
            Exception: If updating the sessions or setting the environment variables fails.
        """
        canonical_provider_name = ProvidersService.get_canonical_provider_name(
            model=model,
            fallback=provider_name,
        )

        if not update_default_model(provider_name=canonical_provider_name, model_name=model.name):
            raise Exception("Failed to update the default provider and model in environment variables.")

    @staticmethod
    def toggle_tool(tool_name: str, enabled: bool) -> dict:
        """
        Activate or deactivate a tool.

        Args:
            tool_name (str): The name of the tool to be toggled.
            enabled (bool): A boolean indicating whether to enable (True) or disable (False) the tool.

        Returns:
            bool: True if the tool was successfully toggled, False otherwise.
        """
        try:
            if enabled:
                success = tool_manager.enable_tool(tool_name)
                # Handle tool reinitialization for any tool that's been enabled
                if success:
                    ConfigService.reinitialize_tool_dependencies(tool_name)
            else:
                success = tool_manager.disable_tool(tool_name)

            return success
        except Exception as e:
            logger.error(f"Error toggling tool '{tool_name}': {str(e)}")
            return False

    @staticmethod
    def reinitialize_tool_dependencies(tool_name: str) -> None:
        """
        Reinitialize a tool with all necessary dependencies after it's been enabled.
        This handles cases where a tool loses its dependencies when disabled/re-enabled.

        Args:
            tool_name (str): Name of the tool to reinitialize
        """
        try:
            tool = tool_manager.registry.get_tool(tool_name)
            if not tool:
                logger.warning(f"Cannot reinitialize dependencies for tool '{tool_name}' - tool not found in registry")
                return

            if hasattr(tool, 'client') and tool.client is None:
                logger.info(f"Reinitializing GEAIClient dependency for tool '{tool_name}'")
                tool.client = ProvidersService.geai_client

            logger.info(f"Successfully reinitialized dependencies for tool '{tool_name}'")
        except Exception as e:
            logger.error(f"Error reinitializing dependencies for tool '{tool_name}': {str(e)}")
