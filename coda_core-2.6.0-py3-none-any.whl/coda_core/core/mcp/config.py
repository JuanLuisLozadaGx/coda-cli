from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any

from loguru import logger

from coda_core.core.mcp.enums import TransportType


@dataclass
class MCPServerConfig:
    """
    Server configuration for official MCP transports (STDIO and HTTP Streamable).
    
    This class represents the configuration for an MCP server, supporting both
    traditional STDIO-based servers (Claude Desktop format) and modern HTTP
    Streamable servers for remote connectivity.
    
    Attributes:
        name (str): Unique identifier for the MCP server
        transport_type (TransportType): Communication protocol (STDIO or HTTP)
        enabled (bool): Whether this server is active (default: True)
        stateful (Optional[bool]): Server state persistence behavior
            - True: Server maintains state between tool calls
            - False: Server is stateless
            - None: Auto-detect based on server capabilities
        
        # STDIO Transport Fields:
        command (Optional[str]): Executable command to start the server
        args (List[str]): Command-line arguments for the server process
        env (Dict[str, str]): Environment variables for the server process
        
        # HTTP Transport Fields:
        url (Optional[str]): HTTP endpoint URL for the MCP server
        headers (Dict[str, str]): HTTP headers to include in requests
        timeout (int): Request timeout in seconds (default: 30)
        authorization_token (Optional[str]): Bearer token for authentication
            (stored separately for Claude Desktop compatibility)
    """
    
    name: str
    transport_type: TransportType
    enabled: bool = True
    stateful: Optional[bool] = None  # Whether server maintains state across tool calls (None = auto-detect)
    
    # STDIO transport fields
    command: Optional[str] = None
    args: List[str] = field(default_factory=list)
    env: Dict[str, str] = field(default_factory=dict)
    
    # HTTP Streamable transport fields
    url: Optional[str] = None
    headers: Dict[str, str] = field(default_factory=dict)
    timeout: int = 30
    authorization_token: Optional[str] = None  # Store original authorization_token for Claude Desktop compatibility
    
    @classmethod
    def from_config_dict(cls, name: str, config: Dict[str, Any]) -> 'MCPServerConfig':
        """
        Create MCPServerConfig instance from dictionary configuration.
        
        Automatically detects transport type based on configuration keys and creates
        appropriate server configuration. Maintains full Claude Desktop compatibility
        while extending support for HTTP Streamable transport.
        
        Args:
            name (str): Unique identifier for the MCP server
            config (Dict[str, Any]): Configuration dictionary containing:
                For STDIO transport:
                    - command (str): Executable command
                    - args (List[str], optional): Command arguments
                    - env (Dict[str, str], optional): Environment variables
                For HTTP transport:
                    - url (str): Server endpoint URL
                    - headers (Dict[str, str], optional): HTTP headers
                    - timeout (int, optional): Request timeout (default: 30)
                    - authorization_token (str, optional): Bearer token
                Common options:
                    - enabled (bool, optional): Server enabled state (default: True)
                    - stateful (bool, optional): State persistence behavior
        
        Returns:
            MCPServerConfig: Configured server instance
        """
        
        # Auto-detect transport type based on presence of URL
        if 'url' in config:
            # HTTP Streamable transport (standard for remote MCP servers)
            headers = config.get('headers', {}).copy()
            original_auth_token = None
            
            # Handle authorization_token field by converting to Authorization header
            if 'authorization_token' in config:
                original_auth_token = config['authorization_token']
                headers['Authorization'] = original_auth_token
                logger.debug(f"Added Authorization header for MCP server '{name}'")
            
            return cls(
                name=name,
                transport_type=TransportType.HTTP,
                url=config['url'],
                headers=headers,
                timeout=config.get('timeout', 30),
                enabled=config.get('enabled', True),
                stateful=config.get('stateful', None),
                authorization_token=original_auth_token
            )
        else:
            # STDIO transport (existing Claude Desktop format)
            return cls(
                name=name,
                transport_type=TransportType.STDIO,
                command=config.get('command'),
                args=config.get('args', []),
                env=config.get('env', {}),
                enabled=config.get('enabled', True),
                stateful=config.get('stateful', None)
            )
    
    def to_config_dict(self) -> Dict[str, Any]:
        """
        Export configuration to Claude Desktop compatible dictionary format.
        
        Converts the MCPServerConfig instance back to a dictionary that can be
        saved to configuration files or used with Claude Desktop. Maintains
        compatibility with both STDIO and HTTP transport formats.
        
        Returns:
            Dict[str, Any]: Configuration dictionary compatible with Claude Desktop:
                For STDIO transport:
                    - command (str): Executable command
                    - args (List[str]): Command arguments  
                    - env (Dict[str, str], optional): Environment variables (if any)
                For HTTP transport:
                    - url (str): Server endpoint URL
                    - authorization_token (str, optional): Bearer token (if originally provided)
                    - headers (Dict[str, str], optional): Additional HTTP headers
                    - timeout (int, optional): Request timeout (if not default 30s)
                Common fields:
                    - enabled (bool, optional): False if server is disabled
        """
        if self.transport_type == TransportType.HTTP:
            # HTTP Streamable transport
            result = {'url': self.url}
            
            # If we have an original authorization_token, export it instead of headers
            if self.authorization_token:
                result['authorization_token'] = self.authorization_token
                # Export other headers (excluding Authorization if it was from authorization_token)
                other_headers = {k: v for k, v in self.headers.items() if k != 'Authorization'}
                if other_headers:
                    result['headers'] = other_headers
            else:
                # No original authorization_token, export all headers as-is
                if self.headers:
                    result['headers'] = self.headers
            
            if self.timeout != 30:
                result['timeout'] = self.timeout
        else:
            # STDIO transport (standard Claude Desktop format)
            result = {
                'command': self.command,
                'args': self.args
            }
            if self.env:
                result['env'] = self.env
        
        if not self.enabled:
            result['enabled'] = False
        
        return result

