import asyncio
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
import concurrent.futures

from loguru import logger

from coda_core.core.mcp.client import MCPClient
from coda_core.core.mcp.config import MCPServerConfig
from coda_core.core.mcp.enums import TransportType
from coda_core.core.mcp.types import ServerValidationResult
from coda_core.core.mcp.utils.loop import LoopThread
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.core.mcp.utils import server_connections, tool_execution, config_operations, format_utils


class MCPService:
    """
    Singleton service for managing all MCP interactions.
    
    Acts as a thin coordinator that delegates operations to specialized modules
    while maintaining state, caching, and providing a unified public API.
    """
    
    _instance: Optional['MCPService'] = None
    _initialized: bool = False
    DEFAULT_VALIDATION_TIMEOUT_SECONDS: int = 60
    
    def __init__(self):
        """Private constructor. Use get() to obtain the singleton instance."""
        if MCPService._instance is not None:
            raise RuntimeError("MCPService is a singleton. Use MCPService.get() instead.")
        
        self.servers_dir: Optional[Path] = None
        self.clients: Dict[str, MCPClient] = {}
        self.configs: Dict[str, MCPServerConfig] = {}
        self._last_errors: Dict[str, Any] = {}
        
        # Session management
        self.current_session_id: Optional[str] = None
        
        # Tool caching
        self._tools_cache: Optional[List[Tuple[str, Any]]] = None
        self._cache_valid: bool = False
    
    def _run_async(self, coro):
        """Simple async executor that always uses LoopThread."""
        loop_thread = LoopThread.get()
        return loop_thread.submit(coro).result()
    
    def _invalidate_cache(self):
        """Invalidate tool cache."""
        self._tools_cache = None
        self._cache_valid = False
        
    @classmethod
    def get(cls) -> 'MCPService':
        """Get the singleton instance of MCPService."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def set_current_session_id(self, session_id: str) -> None:
        """Update the current session context for MCP operations."""
        self.current_session_id = session_id
        logger.debug(f"MCPService session context updated to: {session_id}")
    
    def initialize(self) -> bool:
        """Initialize the MCP service with server configurations."""
        if self._initialized:
            return True
            
        try:
            # Set up configuration paths
            self.servers_dir = Path(SETTINGS.get_env_var(EnvConfig.CODA_MCP_SERVERS_DIR))
            self.servers_dir.mkdir(parents=True, exist_ok=True)
            
            # Load configurations
            if self.servers_dir.exists():
                self.configs = config_operations.load_all_configurations(self.servers_dir)
                logger.info("MCPService initialized successfully")
                self._initialized = True
                return True
            else:
                logger.debug("MCP servers directory does not exist, MCP service initialized but inactive")
                self._initialized = True
                return True
                
        except Exception as e:
            logger.error(f"Failed to initialize MCPService: {e}")
            return False
    
    def is_available(self) -> bool:
        """Check if MCP functionality is available."""
        if not self._initialized:
            self.initialize()
            
        return (self._initialized and 
                self.servers_dir is not None and 
                self.servers_dir.exists() and 
                any(self.servers_dir.glob("*.json")))
    
    # ============================================================================
    # Core Public API
    # ============================================================================
    
    def list_servers(self) -> List[str]:
        """Get list of configured server names."""
        if not self.is_available():
            return []
        return list(self.configs.keys())
    
    def list_tools(self) -> List[Tuple[str, str, str]]:
        """Get list of all available tools from all servers."""
        if not self.is_available():
            return []
            
        try:
            self._ensure_connected()
            all_tools = self._get_cached_tools()
            
            return [
                (server_name, tool_def.name, getattr(tool_def, 'description', f'Tool {tool_def.name} from {server_name}'))
                for server_name, tool_def in all_tools
            ]
        except Exception as e:
            logger.error(f"Error listing MCP tools: {e}")
            return []
    
    def execute(self, server_name: str, tool_name: str, arguments: Dict[str, Any] = None, session_id: str = "default") -> Dict[str, Any]:
        """Execute a tool on the specified MCP server."""
        if not self.is_available():
            return format_utils.create_error_response("MCP service not available", server_name, tool_name)
            
        try:
            # Ensure connection and resolve server name using session context
            self._ensure_connected()
            resolved_server_name = server_connections.resolve_server_name(server_name, self.clients)
            if not resolved_server_name:
                return format_utils.create_error_response(f"Server '{server_name}' not connected", server_name, tool_name)
            
            # Execute tool with session-specific states
            enabled_states = self.get_effective_server_states(session_id)
            return self._run_async(
                tool_execution.execute_tool_async(
                    resolved_server_name, 
                    tool_name, 
                    arguments or {}, 
                    self.clients, 
                    self.configs,
                    self._invalidate_cache,
                    enabled_states
                )
            )
            
        except KeyboardInterrupt:
            raise
        except Exception as e:
            error_msg = f"Error executing tool '{tool_name}' on server '{server_name}': {e}"
            logger.error(error_msg)
            return format_utils.create_error_response(error_msg, server_name, tool_name)

    def get_detailed_tool_info(self) -> str:
        """Generate comprehensive tool information with full descriptions and schemas."""
        if not self.is_available():
            return "No MCP tools available."
            
        try:
            self._ensure_connected()
            all_tools = self._get_cached_tools()
            
            # Group tools by server
            server_tools = {}
            for server_name, tool_def in all_tools:
                if server_name not in server_tools:
                    server_tools[server_name] = []
                server_tools[server_name].append(tool_def)
            
            if not server_tools:
                return "No MCP tools available."
            
            return format_utils.format_detailed_tool_info(server_tools)
            
        except Exception as e:
            logger.error(f"Error generating detailed tool info: {e}")
            return f"Error generating tool information: {e}"

    def prompt_snippet(self) -> str:
        """Generate a markdown snippet describing available MCP tools for system prompt."""
        if not self.is_available():
            return ""
            
        try:
            # Ensure we have connected clients and cached tool definitions
            self._ensure_connected()
            all_tools = self._get_cached_tools()
            if not all_tools:
                return ""

            server_tools: Dict[str, List[Dict[str, Any]]] = {}
            for server_name, tool_def in all_tools:
                tool_name = getattr(tool_def, 'name', 'unknown')
                schema = getattr(tool_def, 'inputSchema', None) or getattr(tool_def, 'schema', None)

                required_params: List[str] = []
                optional_params: List[str] = []

                if isinstance(schema, dict):
                    required_params = list(schema.get('required', []) or [])
                    properties = schema.get('properties', {})
                    if isinstance(properties, dict):
                        optional_params = [
                            key for key in properties.keys()
                            if key not in required_params
                        ]

                tool_info = {
                    'name': tool_name,
                    'required': sorted(required_params),
                    'optional': sorted(optional_params),
                }

                server_tools.setdefault(server_name, []).append(tool_info)

            return format_utils.format_prompt_snippet(server_tools)
            
        except Exception as e:
            logger.error(f"Error generating MCP prompt snippet: {e}")
            return ""
    
    def get_server_status(self) -> Dict[str, Dict[str, Any]]:
        """Get status information for all configured servers."""
        if not self.is_available():
            return {}
            
        try:
            status = {}
            for name, config in self.configs.items():
                client = self.clients.get(name)
                is_connected = client.is_connected if client else False
                tool_count = len(client._tools_cache) if client and client.is_connected else 0
                status[name] = {
                    'connected': is_connected,
                    'tool_count': tool_count,
                    'transport': config.transport_type.value,
                    'last_error': self._serialize_error(self._last_errors.get(name))
                }
            return status
        except Exception as e:
            logger.error(f"Error getting server status: {e}")
            return {}
    
    def reload(self) -> bool:
        """Reload all MCP server connections and tool definitions."""
        try:
            logger.info("Reloading MCP service...")
            
            # Disconnect and reset
            if self.clients:
                self._run_async(server_connections.disconnect_all_clients(self.clients, self._invalidate_cache))
            
            self._initialized = False
            self.configs.clear()
            self._last_errors.clear()
            self._invalidate_cache()
            
            # Re-initialize
            success = self.initialize()
            if success:
                self._ensure_connected()
                logger.info("MCP service reloaded successfully")
            
            return success
            
        except Exception as e:
            logger.error(f"Error reloading MCP service: {e}")
            return False

    def _serialize_error(self, error: Any) -> Any:
        """Convert ErrorInfo to a serializable dict; pass through other types unchanged."""
        if hasattr(error, "kind") and hasattr(error, "message"):
            return {
                "kind": getattr(error, "kind", None),
                "message": getattr(error, "message", None),
                "retryable": getattr(error, "retryable", None),
            }
        return error
    
    # ============================================================================
    # Configuration Management
    # ============================================================================
    
    def load_configurations(self) -> Dict[str, MCPServerConfig]:
        """Load all server configurations."""
        if not self.is_available():
            return {}
        return self.configs.copy()
    
    def add_server(self, config: MCPServerConfig) -> ServerValidationResult:
        """Add a single server configuration."""
        if not self.servers_dir:
            raise RuntimeError("MCPService not initialized")

        validation = self.validate_server(config)
        if not validation.success:
            raise ValueError(f"MCP server '{config.name}' failed validation: {validation.message}")

        config_operations.save_server_config(self.servers_dir, config)
        # Update in-memory configs and invalidate cache
        self.configs[config.name] = config
        self._last_errors.pop(config.name, None)
        self._invalidate_cache()
        return validation
    
    def remove_server(self, server_name: str) -> bool:
        """Remove a server configuration and disconnect if active.
    
        Safely disconnects the MCP client and removes the server configuration.
        Client cleanup is always performed to prevent resource leaks, regardless
        of whether the config file removal succeeds.
            
        Args:
            server_name (str): Name of the MCP server to remove.
                
        Returns:
            bool: True if config file was successfully removed, False otherwise.
                Client is always cleaned up regardless of return value.
                    
        Raises:
            RuntimeError: If MCPService is not initialized.
        """
        if server_name in self.clients:
            client = self.clients[server_name]
            
            if client.is_connected:
                try:
                    logger.debug(f"Disconnecting active MCP client '{server_name}'")
                    self._run_async(client.disconnect())
                    logger.debug(f"MCP client '{server_name}' disconnected successfully")
                except Exception as e:
                    logger.warning(f"Error disconnecting server '{server_name}' during removal: {e}")
            else:
                logger.debug(f"MCP client '{server_name}' already disconnected, skipping disconnect")
            
            # remove from dictionary
            self.clients.pop(server_name, None)
        else:
            logger.debug(f"No active client found for '{server_name}'")

        success = config_operations.remove_server_config(self.servers_dir, server_name)
        if success:
            # Remove from in-memory configs and invalidate cache
            self.configs.pop(server_name, None)
            self._last_errors.pop(server_name, None)
            self._invalidate_cache()
        else:
            logger.warning(f"Failed to remove configuration for '{server_name}'")

        return success
    
    def get_server_config(self, server_name: str) -> Optional[MCPServerConfig]:
        """Get a specific server configuration."""
        return self.configs.get(server_name) or config_operations.load_server_config(self.servers_dir, server_name)
    
    def import_servers(self, json_data: Dict[str, Any]) -> Tuple[int, List[str]]:
        """Import servers from JSON data."""
        if not self.servers_dir:
            raise RuntimeError("MCPService not initialized")
        
        errors = []
        success_count = 0
        
        # Determine JSON format
        servers_data = json_data.get("mcpServers", json_data)
        
        for server_name, server_config in servers_data.items():
            try:
                config = MCPServerConfig.from_config_dict(server_name, server_config)
                validation = self.validate_server(config)
                if not validation.success:
                    error_msg = f"Server '{server_name}': {validation.message}"
                    errors.append(error_msg)
                    logger.warning(f"Failed to import {error_msg}")
                    continue

                config_operations.save_server_config(self.servers_dir, config)
                self.configs[config.name] = config
                self._last_errors.pop(config.name, None)
                success_count += 1
            except Exception as e:
                error_msg = f"Server '{server_name}': {str(e)}"
                errors.append(error_msg)
                logger.warning(f"Failed to import {error_msg}")
        
        if success_count > 0:
            self._invalidate_cache()
        
        return success_count, errors
    
    def export_servers(self) -> Dict[str, Any]:
        """Export all servers in Claude Desktop compatible format."""
        return {
            "mcpServers": {
                name: config.to_config_dict()
                for name, config in self.configs.items()
            }
        }
    
    def is_server_enabled(self, server_name: str) -> bool:
        """Check if a server is enabled."""
        if server_name not in self.configs:
            return False
        return self.configs[server_name].enabled
    
    def get_enabled_server_names(self) -> List[str]:
        """Get names of all enabled servers."""
        return [name for name, config in self.configs.items() if config.enabled]
    
    def get_server_states(self) -> Dict[str, bool]:
        """Get enabled/disabled state of all servers."""
        return {name: config.enabled for name, config in self.configs.items()}
    
    # ============================================================================
    # Session/Global Configuration Management
    # ============================================================================
    
    def load_global_mcp_defaults(self) -> Dict[str, bool]:
        """Load global MCP server default states."""
        global_file = Path(SETTINGS.get_env_var(EnvConfig.CODA_MCP_GLOBAL_DEFAULTS_FILE))
        return config_operations.load_global_mcp_defaults(global_file)
    
    def save_global_mcp_defaults(self, states: Dict[str, bool]) -> bool:
        """Save global MCP server default states."""
        global_file = Path(SETTINGS.get_env_var(EnvConfig.CODA_MCP_GLOBAL_DEFAULTS_FILE))
        return config_operations.save_global_mcp_defaults(global_file, states)
    
    def load_session_mcp_config(self, session_id: str) -> Dict[str, bool]:
        """Load session-specific MCP server state overrides."""
        if session_id is None:
            return {}
        session_config_dir = Path(SETTINGS.get_env_var(EnvConfig.CODA_MCP_SESSION_CONFIG_DIR))
        session_file = session_config_dir / session_id / "mcp_config.json"
        return config_operations.load_session_mcp_config(session_file)
    
    def save_session_mcp_config(self, session_id: str, overrides: Dict[str, bool]) -> bool:
        """Save session-specific MCP server state overrides."""
        if session_id is None:
            return False
        session_config_dir = Path(SETTINGS.get_env_var(EnvConfig.CODA_MCP_SESSION_CONFIG_DIR))
        session_file = session_config_dir / session_id / "mcp_config.json"
        return config_operations.save_session_mcp_config(session_file, overrides, session_id)
    
    def get_effective_server_states(self, session_id: str) -> Dict[str, bool]:
        """Get effective server states (global defaults + session overrides) filtered to only currently configured servers."""
        global_states = self.load_global_mcp_defaults()
        session_overrides = self.load_session_mcp_config(session_id)
        
        # If no global defaults exist, use current server states as defaults
        if not global_states:
            global_states = self.get_server_states()
            # Save these as the initial global defaults
            self.save_global_mcp_defaults(global_states)
        
        # Get merged states
        merged_states = config_operations.merge_mcp_configs(global_states, session_overrides)
        
        # Filter to only include currently configured servers
        current_server_names = set(self.configs.keys())
        filtered_states = {
            name: enabled for name, enabled in merged_states.items() 
            if name in current_server_names
        }
        
        # Add any configured servers that weren't in the merged states
        for server_name in current_server_names:
            if server_name not in filtered_states:
                # Use the configuration enabled state as default
                filtered_states[server_name] = self.configs[server_name].enabled
        
        return filtered_states
    
    def cleanup_stale_session_overrides(self, session_id: str) -> bool:
        """Clean up session overrides for servers that no longer exist in configuration."""
        if session_id is None:
            return True
        try:
            session_overrides = self.load_session_mcp_config(session_id)
            current_server_names = set(self.configs.keys())
            
            # Find overrides for servers that no longer exist
            stale_servers = [name for name in session_overrides.keys() if name not in current_server_names]
            
            if stale_servers:
                # Remove stale overrides
                for stale_server in stale_servers:
                    session_overrides.pop(stale_server, None)
                
                # Save cleaned overrides
                success = self.save_session_mcp_config(session_id, session_overrides)
                if success:
                    logger.info(f"Cleaned up {len(stale_servers)} stale session overrides: {stale_servers}")
                return success
            
            return True  # No cleanup needed
            
        except Exception as e:
            logger.error(f"Failed to cleanup stale session overrides: {e}")
            return False
    
    def set_session_server_state(self, session_id: str, server_name: str, enabled: bool) -> bool:
        """Set session-specific server state override."""
        if session_id is None:
            return False
        try:
            # Load current session overrides
            session_overrides = self.load_session_mcp_config(session_id)
            
            # Load global defaults to check if this is an override
            global_states = self.load_global_mcp_defaults()
            
            # If global defaults don't exist, use current server states
            if not global_states:
                global_states = self.get_server_states()
                self.save_global_mcp_defaults(global_states)
            
            # Check if this is different from global default
            global_enabled = global_states.get(server_name, True)
            
            if enabled == global_enabled:
                # Remove override since it matches global default
                session_overrides.pop(server_name, None)
            else:
                # Add/update override
                session_overrides[server_name] = enabled
            
            # Save session config
            success = self.save_session_mcp_config(session_id, session_overrides)
            
            if success:
                connection_changed = False
                # Update the actual server configuration for this session
                if server_name in self.configs:
                    self.configs[server_name].enabled = enabled
                    
                    # Handle server connection changes
                    if not enabled and server_name in self.clients:
                        # Disconnect if disabled
                        try:
                            client = self.clients[server_name]
                            self._run_async(client.disconnect())
                            self.clients.pop(server_name, None)
                            self._last_errors[server_name] = "Server is disabled"
                            connection_changed = True
                        except Exception as e:
                            logger.warning(f"Error disconnecting server '{server_name}': {e}")
                    elif enabled:
                        # Ensure connection if enabled

                        try:
                            enabled_states = self.get_effective_server_states(self.current_session_id)
                            connect_result = self._run_async(
                                server_connections.ensure_server_connected(
                                    server_name, self.clients, self.configs, self._invalidate_cache, enabled_states
                                )
                            )
                            if connect_result.ok:
                                self._last_errors.pop(server_name, None)
                                connection_changed = True
                            elif connect_result.error:
                                self._last_errors[server_name] = connect_result.error

                        except Exception as e:
                            logger.warning(f"Error connecting server '{server_name}': {e}")
                            self._last_errors[server_name] = str(e)
                    
                    # Invalidate cache only when connection state changed
                    if (not enabled and server_name not in self.clients) or connection_changed:
                        self._invalidate_cache()
                    logger.info(f"Set session state for '{server_name}': {enabled}")
            
            return success
            
        except Exception as e:
            logger.error(f"Failed to set session server state for '{server_name}': {e}")
            return False
    
    def reset_session_to_global(self, session_id: str) -> bool:
        """Reset session to global defaults (clear all overrides)."""
        if session_id is None:
            return False
        try:
            session_config_dir = Path(SETTINGS.get_env_var(EnvConfig.CODA_MCP_SESSION_CONFIG_DIR))
            session_file = session_config_dir / session_id / "mcp_config.json"
            
            # Remove session config file
            if session_file.exists():
                session_file.unlink()
            
            # Load global defaults and apply them
            global_states = self.load_global_mcp_defaults()
            if not global_states:
                global_states = self.get_server_states()
                self.save_global_mcp_defaults(global_states)
            
            # Apply global states to current configurations
            for server_name, enabled in global_states.items():
                if server_name in self.configs:
                    self.configs[server_name].enabled = enabled
            
            # Disconnect disabled servers
            for server_name, config in self.configs.items():
                if not config.enabled and server_name in self.clients:
                    try:
                        client = self.clients[server_name]
                        self._run_async(client.disconnect())
                        self.clients.pop(server_name, None)
                    except Exception as e:
                        logger.warning(f"Error disconnecting server '{server_name}': {e}")
            
            self._invalidate_cache()
            logger.info(f"Reset session {session_id} to global defaults")
            return True
            
        except Exception as e:
            logger.error(f"Failed to reset session to global defaults: {e}")
            return False
    
    def make_session_global_default(self, session_id: str) -> bool:
        """Make current session state the new global default."""
        if session_id is None:
            return False
        try:
            # Get current effective session states
            effective_states = self.get_effective_server_states(session_id)
            
            # Save as new global defaults
            success = self.save_global_mcp_defaults(effective_states)
            
            if success:
                # Clear session overrides since they're now the global default
                session_config_dir = Path(SETTINGS.get_env_var(EnvConfig.CODA_MCP_SESSION_CONFIG_DIR))
                session_file = session_config_dir / session_id / "mcp_config.json"
                if session_file.exists():
                    session_file.unlink()
                
                logger.info(f"Made session {session_id} state the new global default")
            
            return success
            
        except Exception as e:
            logger.error(f"Failed to make session global default: {e}")
            return False

    # ============================================================================
    # Validation
    # ============================================================================

    def validate_server(self, config: MCPServerConfig, timeout_seconds: int = DEFAULT_VALIDATION_TIMEOUT_SECONDS) -> ServerValidationResult:
        """
        Validate an MCP server configuration by attempting a real connection.

        This performs lightweight static checks and then tries to connect using
        the same client logic used at runtime. The connection is immediately
        torn down after validation and is not persisted in the service state.

        Args:
            config: The server configuration to validate.
            timeout_seconds: Max seconds to wait for the connection attempt.
                Defaults to 60s to tolerate cold starts from package runners
                such as `npx`, which may need to download/install dependencies
                before the server can answer MCP initialization.

        Returns:
            ServerValidationResult indicating success, message, and discovered tool count.
        """
        if config is None:
            return ServerValidationResult(False, "No configuration provided")

        # Basic static checks before attempting a connection
        if config.transport_type == TransportType.HTTP:
            if not config.url:
                return ServerValidationResult(False, "HTTP server is missing a URL")
            if not str(config.url).lower().startswith(("http://", "https://")):
                return ServerValidationResult(False, "HTTP server URL must start with http:// or https://")
        elif config.transport_type == TransportType.STDIO:
            if not config.command:
                return ServerValidationResult(False, "STDIO server is missing a command")

        client = MCPClient(config)
        tool_count = 0

        try:
            connected = self._run_async(asyncio.wait_for(client.connect(), timeout=timeout_seconds))
            if not connected:
                return ServerValidationResult(False, "Unable to establish connection to server")

            tool_count = len(client._tools_cache)
            return ServerValidationResult(True, f"Validation succeeded ({tool_count} tools discovered)", tool_count)
        except asyncio.TimeoutError:
            logger.error(f"Validation for '{config.name}' timed out after {timeout_seconds}s")
            return ServerValidationResult(False, f"Validation timed out after {timeout_seconds}s")
        except Exception as e:
            logger.error(f"Validation failed for '{config.name}': {e}")
            return ServerValidationResult(False, str(e))
        finally:
            try:
                # Ensure temporary connection is cleaned up
                self._run_async(asyncio.wait_for(client.disconnect(), timeout=2))
            except Exception as cleanup_error:
                logger.warning(f"Validation cleanup failed for '{config.name}': {cleanup_error}")
    
    # ============================================================================
    # Internal Implementation
    # ============================================================================
    
    def _get_cached_tools(self) -> List[Tuple[str, Any]]:
        """Get cached tools, refreshing if necessary."""
        if not self._cache_valid or self._tools_cache is None:
            self._tools_cache = tool_execution.get_cached_tools(self.clients)
            self._cache_valid = True
        
        return self._tools_cache
    
    def _ensure_connected(self) -> None:
        """Ensure MCP servers are connected using session-specific enabled states."""
        if not self.configs:
            return
            
        try:
            # Get effective server states for the session
            enabled_states = self.get_effective_server_states(self.current_session_id)
            
            results = self._run_async(
                server_connections.ensure_connected(self.clients, self.configs, self._invalidate_cache, enabled_states)
            )
            if isinstance(results, dict):
                for name, result in results.items():
                    if result.ok:
                        self._last_errors.pop(name, None)
                    elif result.error:
                        self._last_errors[name] = result.error
        except Exception as e:
            logger.error(f"Error ensuring MCP connections: {e}")
    
    def shutdown(self) -> None:
        """Gracefully shutdown the MCP service."""
        try:
            if self.clients:
                logger.info("Shutting down MCP service - disconnecting all clients...")
                
                try:
                    if LoopThread.exists():
                        loop_thread = LoopThread.get()
                        future = loop_thread.submit(
                            server_connections.disconnect_all_clients(self.clients, self._invalidate_cache)
                        )
                        future.result(timeout=5.0)
                        logger.info("MCP clients disconnected successfully")
                    else:
                        logger.info("No MCP loop thread exists, skipping client disconnection")
                except concurrent.futures.TimeoutError:
                    logger.warning("MCP client disconnection timed out after 5 seconds")
                except Exception as e:
                    logger.warning(f"Error during MCP client disconnection: {e}")
        except Exception as e:
            logger.warning(f"Error while disconnecting MCP clients during shutdown: {e}")
        
        try:
            if LoopThread.exists():
                logger.info("Stopping MCP LoopThread...")
                LoopThread.get().stop()
                logger.info("MCP LoopThread stopped successfully")
        except Exception as e:
            logger.error(f"Error stopping MCP LoopThread during shutdown: {e}")
