from typing import Coroutine, Any
import threading
import concurrent.futures
import asyncio

from coda_core.config.logging.context import capture_session_context, restore_session_context


class LoopThread:
    """Singleton event‑loop running in its own daemon thread."""
    _instance = None

    def __init__(self) -> None:
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(
            target=self._loop.run_forever, daemon=True, name="MCP-Loop")
        self._thread.start()

    @classmethod
    def get(cls) -> "LoopThread":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def exists(cls) -> bool:
        """Check if the LoopThread instance exists without creating it."""
        return cls._instance is not None

    # ---------- helper API ----------
    def submit(self, coro: Coroutine[Any, Any, Any]) -> concurrent.futures.Future:
        """Schedule coroutine in the background loop with session context preservation."""
        # Capture session context from the current thread
        session_context = capture_session_context()
        
        # Create a wrapper coroutine that restores context before execution
        async def _context_wrapper():
            # Restore the session context in the background thread
            restore_session_context(session_context)
            # Execute the original coroutine
            return await coro
        
        return asyncio.run_coroutine_threadsafe(_context_wrapper(), self._loop)

    def stop(self) -> None:        
        async def _graceful_shutdown():
            # cancel all remaining tasks *except* ourselves
            tasks = [t for t in asyncio.all_tasks(self._loop)
                     if t is not asyncio.current_task(self._loop)]
            for t in tasks:
                t.cancel()
            # Give tasks a moment to respond to cancellation, then stop the loop
            await asyncio.gather(*tasks, return_exceptions=True)
            self._loop.stop()

        try:
            # run the shutdown coroutine inside the loop and wait for it with timeout
            future = asyncio.run_coroutine_threadsafe(_graceful_shutdown(), self._loop)
            future.result(timeout=3.0)  # Max 3 seconds for graceful shutdown
        except concurrent.futures.TimeoutError:
            # If graceful shutdown times out, force stop the loop
            self._loop.call_soon_threadsafe(self._loop.stop)
        except Exception as e:
            # If shutdown fails, force stop the loop
            self._loop.call_soon_threadsafe(self._loop.stop)
        
        # Wait for thread to finish, but not forever
        self._thread.join(timeout=2.0)
