import asyncio
from typing import Callable, Dict, Optional

from loguru import logger

from coda_core.core.mcp.client import MCPClient
from coda_core.core.mcp.config import MCPServerConfig
from coda_core.core.mcp.types import ConnectResult, ErrorInfo


async def ensure_connected(
    clients: Dict[str, MCPClient], 
    configs: Dict[str, MCPServerConfig],
    cache_invalidator: Callable[[], None],
    enabled_states: Optional[Dict[str, bool]] = None,
) -> Dict[str, ConnectResult]:
    """
    Ensure all configured MCP servers have active connections.
    
    Attempts to connect or reconnect any configured servers that are not
    currently connected. Cache invalidation is delegated to connect_all_servers
    and only occurs when a new connection/reconnection succeeds.
    
    Args:
        clients (Dict[str, MCPClient]): Dictionary of active MCP client connections
            indexed by server name. Will be updated with new connections.
        configs (Dict[str, MCPServerConfig]): Dictionary of server configurations
            indexed by server name. Only enabled servers will be connected.
        cache_invalidator (Callable[[], None]): Function to call when connections
            change to invalidate cached tool information.
        enabled_states (Optional[Dict[str, bool]]): Optional session-specific enabled 
            states. If provided, these override config.enabled values.
    """
    if not configs:
        return {}
        
    try:
        return await connect_all_servers(clients, configs, cache_invalidator, enabled_states)
    except Exception as e:
        logger.error(f"Error ensuring MCP connections: {e}")
        return {}


async def ensure_server_connected(
    server_name: str, 
    clients: Dict[str, MCPClient], 
    configs: Dict[str, MCPServerConfig],
    cache_invalidator: Callable[[], None],
    enabled_states: Optional[Dict[str, bool]] = None,
) -> ConnectResult:
    """
    Ensure a specific MCP server has an active connection.
    
    Checks if the specified server is connected, and if not, attempts to
    establish a connection. Handles reconnection logic for existing but
    disconnected clients, and creates new clients as needed.
    
    Args:
        server_name (str): Name of the server to ensure connection for.
        clients (Dict[str, MCPClient]): Dictionary of active MCP client connections
            indexed by server name. May be updated with new connections.
        configs (Dict[str, MCPServerConfig]): Dictionary of server configurations
            indexed by server name. Must contain configuration for server_name.
        cache_invalidator (Callable[[], None]): Function to call when connections
            change to invalidate cached tool information.
        enabled_states (Optional[Dict[str, bool]]): Optional session-specific enabled 
            states. If provided, these override config.enabled values.
            
    Returns:
        ConnectResult: Success or failure details for the server connection attempt.
    """
    if server_name not in configs:
        logger.error(f"Server '{server_name}' not found in configurations")
        return ConnectResult.failure(
            server_name,
            ErrorInfo(kind="not_found", message="Server configuration not found", retryable=False),
        )
        
    config = configs[server_name]
    # Use effective enabled state if provided, otherwise fall back to config.enabled
    is_enabled = enabled_states.get(server_name, config.enabled) if enabled_states else config.enabled
    if not is_enabled:
        logger.debug(f"Server '{server_name}' is disabled")
        return ConnectResult.failure(
            server_name,
            ErrorInfo(kind="disabled", message="Server is disabled", retryable=False),
        )
        
    # Check existing connection
    if server_name in clients:
        client = clients[server_name]
        if client.is_connected:
            return ConnectResult.success(server_name, client)
        # Try reconnect
        reconnect_result = await _connect_client(server_name, client, reuse=True)
        if reconnect_result.ok:
            clients[server_name] = reconnect_result.client  # ensure reference updated
            cache_invalidator()
            return reconnect_result
        await client.disconnect()
        clients.pop(server_name, None)
        return reconnect_result
    
    # Create new connection
    client = MCPClient(config)
    connect_result = await _connect_client(server_name, client, reuse=False)
    if connect_result.ok:
        clients[server_name] = client
        cache_invalidator()
    return connect_result


async def connect_all_servers(
    clients: Dict[str, MCPClient], 
    configs: Dict[str, MCPServerConfig],
    cache_invalidator: Optional[Callable[[], None]] = None,
    enabled_states: Optional[Dict[str, bool]] = None,
) -> Dict[str, ConnectResult]:
    """
    Connect to all configured and enabled MCP servers concurrently.
    
    Attempts to reuse existing clients when possible, reconnecting if needed,
    and only creates new clients for servers without an entry. Returns a
    per-server result for callers to aggregate or inspect.
    
    Args:
        clients (Dict[str, MCPClient]): Dictionary to store successful client
            connections indexed by server name. Will be updated with new connections.
        configs (Dict[str, MCPServerConfig]): Dictionary of server configurations
            indexed by server name. Only enabled servers will be connected.
        cache_invalidator (Optional[Callable[[], None]]): Function to call when connections
            change to invalidate cached tool information. Called once if any success.
        enabled_states (Optional[Dict[str, bool]]): Optional session-specific enabled 
            states. If provided, these override config.enabled values.
    """
    if not configs:
        logger.info("No MCP servers configured")
        return {}
    
    logger.info(f"Ensuring connections for {len(configs)} MCP servers...")
    
    results: Dict[str, ConnectResult] = {}
    connection_tasks = []
    task_meta = []
    for name, config in configs.items():
        # Use effective enabled state if provided, otherwise fall back to config.enabled
        is_enabled = enabled_states.get(name, config.enabled) if enabled_states else config.enabled
        if is_enabled:
            client = clients.get(name)
            if client and client.is_connected:
                results[name] = ConnectResult.success(name, client)
                continue
            connection_tasks.append(_connect_client(name, client or MCPClient(config), reuse=client is not None))
            task_meta.append((name, client))
        else:
            results[name] = ConnectResult.failure(
                name,
                ErrorInfo(kind="disabled", message="Server is disabled", retryable=False),
            )
    
    attempted = len(connection_tasks)
    gathered = await asyncio.gather(*connection_tasks, return_exceptions=True)
    for idx, result in enumerate(gathered):
        name, existing_client = task_meta[idx]
        had_existing = existing_client is not None
        if isinstance(result, ConnectResult):
            results[name] = result
        else:
            error_kind = "reconnect_failed" if had_existing else "connect_failed"
            results[name] = ConnectResult.failure(name, ErrorInfo.from_exception(result, kind=error_kind))
            logger.error(f"Error connecting to '{name}': {result}")

        if results[name].ok:
            clients[name] = results[name].client  # register/reuse successful client
        elif had_existing:
            clients.pop(name, None)
            try:
                await existing_client.disconnect()
            except Exception:
                pass

    successful = sum(1 for name in [meta[0] for meta in task_meta] if results[name].ok)
    logger.info(f"Connected to {successful}/{attempted} servers")

    if cache_invalidator and any(results[name].ok for name in [meta[0] for meta in task_meta]):
        cache_invalidator()

    return results


async def _connect_client(server_name: str, client: MCPClient, reuse: bool) -> ConnectResult:
    """
    Attempt to connect or reconnect a client, returning a structured result.

    Args:
        server_name (str): The server name for logging and result mapping.
        client (MCPClient): Client instance to connect.
        reuse (bool): True if this is a reconnect attempt for an existing client.
    """
    error_kind = "reconnect_failed" if reuse else "connect_failed"
    try:
        success = await client.connect()
    except Exception as exc:
        return ConnectResult.failure(server_name, ErrorInfo.from_exception(exc, kind=error_kind))

    if success:
        return ConnectResult.success(server_name, client)

    message = getattr(client, "last_error", None) or (
        "Unable to reconnect to server" if reuse else "Unable to connect to server"
    )
    return ConnectResult.failure(server_name, ErrorInfo(kind=error_kind, message=message, retryable=True))


async def connect_single_client(
    name: str, 
    client: MCPClient, 
    clients: Dict[str, MCPClient]
) -> ConnectResult:
    """
    Connect a single MCP client and register it if successful.
    
    Attempts to connect the provided client and adds it to the clients
    dictionary if the connection succeeds. This function is designed
    to be used in concurrent connection operations.
    
    Args:
        name (str): Server name to use as the key in the clients dictionary.
        client (MCPClient): The MCP client instance to connect.
        clients (Dict[str, MCPClient]): Dictionary to store the client
            in if connection succeeds.
            
    Returns:
        ConnectResult: Structured result describing the connection attempt.
    """
    result = await _connect_client(name, client, reuse=name in clients)
    if result.ok:
        clients[name] = client
    return result


async def disconnect_all_clients(
    clients: Dict[str, MCPClient],
    cache_invalidator: Callable[[], None]
) -> None:
    """
    Gracefully disconnect all MCP clients and clear the clients dictionary.
    
    Attempts to disconnect all clients concurrently, then clears the clients
    dictionary and invalidates the tool cache. Uses return_exceptions=True
    to ensure all disconnections are attempted even if some fail.
    
    Args:
        clients (Dict[str, MCPClient]): Dictionary of active MCP client
            connections. Will be cleared after disconnection attempts.
        cache_invalidator (Callable[[], None]): Function to call after
            disconnection to invalidate cached tool information.
    """
    if clients:
        await asyncio.gather(
            *[client.disconnect() for client in clients.values()],
            return_exceptions=True
        )
        clients.clear()
        cache_invalidator()


def resolve_server_name(server_name: str, clients: Dict[str, MCPClient]) -> Optional[str]:
    """
    Resolve a server name with case-insensitive matching.
    
    Attempts to find a matching server name in the clients dictionary,
    first trying an exact match, then falling back to case-insensitive
    matching. This provides user-friendly server name resolution.
    
    Args:
        server_name (str): The server name to resolve. Can be any case.
        clients (Dict[str, MCPClient]): Dictionary of active MCP client
            connections indexed by actual server names.
            
    Returns:
        Optional[str]: The actual server name from the clients dictionary if
            found, None if no match exists or clients is empty.
    """
    if not clients:
        return None
        
    # Try exact match first
    if server_name in clients:
        return server_name
        
    # Try case-insensitive match
    server_name_lower = server_name.lower()
    for actual_name in clients.keys():
        if actual_name.lower() == server_name_lower:
            return actual_name
            
    return None
