from typing import Dict, List, Any, Tuple

from loguru import logger

from coda_core.core.mcp.client import MCPClient
from coda_core.core.mcp.config import MCPServerConfig
from coda_core.core.mcp.utils.format_utils import create_error_response, format_result
from coda_core.core.mcp.utils import server_connections


async def execute_tool_async(
    server_name: str, 
    tool_name: str, 
    arguments: Dict[str, Any],
    clients: Dict[str, MCPClient],
    configs: Dict[str, MCPServerConfig],
    cache_invalidator,
    enabled_states: Dict[str, bool] = None,
) -> Dict[str, Any]:
    """
    Execute an MCP tool asynchronously with comprehensive error handling.
    
    This is the main tool execution function that handles connection management,
    tool invocation, result formatting, and error handling. It ensures the target
    server is connected before attempting tool execution and provides detailed
    error information if execution fails.
    
    Args:
        server_name (str): Name of the MCP server to execute the tool on.
        tool_name (str): Name of the tool to execute on the server.
        arguments (Dict[str, Any]): Arguments to pass to the tool. Should match
            the tool's expected parameter schema.
        clients (Dict[str, MCPClient]): Dictionary of active MCP client
            connections indexed by server name.
        configs (Dict[str, MCPServerConfig]): Dictionary of server configurations
            indexed by server name.
        cache_invalidator: Function to call when connections change to invalidate
            cached tool information.
        enabled_states (Optional[Dict[str, bool]]): Optional session-specific enabled 
            states. If provided, these override config.enabled values.
            
    Returns:
        Dict[str, Any]: A standardized response dictionary containing:
            - success: Boolean indicating if execution succeeded
            - result: The formatted tool execution result (if successful)
            - error: Error message (if unsuccessful)
            - server_name: The server that was called
            - tool_name: The tool that was executed
    """
    try:
        # Ensure specific server connection
        connect_result = await server_connections.ensure_server_connected(
            server_name, clients, configs, cache_invalidator, enabled_states
        )
        if not connect_result.ok:
            error_message = (
                connect_result.error.message if connect_result.error else f"Failed to connect to server '{server_name}'"
            )
            return create_error_response(
                error_message,
                server_name, 
                tool_name
            )
        
        # Execute tool
        result = await call_tool(server_name, tool_name, arguments, clients)
        
        return {
            "success": True,
            "result": format_result(result),
            "server_name": server_name,
            "tool_name": tool_name
        }
        
    except Exception as e:
        error_msg = f"Error in async execution: {e}"
        logger.exception(error_msg)
        return create_error_response(error_msg, server_name, tool_name)


async def call_tool(
    server_name: str, 
    tool_name: str, 
    arguments: Dict[str, Any], 
    clients: Dict[str, MCPClient]
) -> Any:
    """
    Execute a tool directly on a specific MCP server.
    
    Makes a direct call to the specified tool on the given server. This function
    assumes the server is already connected and will raise an exception if the
    server is not found in the clients dictionary.
    
    Args:
        server_name (str): Name of the MCP server to execute the tool on.
            Must exist in the clients dictionary.
        tool_name (str): Name of the tool to execute on the server.
        arguments (Dict[str, Any]): Arguments to pass to the tool.
        clients (Dict[str, MCPClient]): Dictionary of active MCP client
            connections indexed by server name.
            
    Returns:
        Any: The raw result from the MCP tool execution. The format depends
            on the specific tool and server implementation.
            
    Raises:
        KeyError: If the specified server is not found in the clients dictionary.
    """
    if server_name not in clients:
        raise KeyError(f"Server '{server_name}' not connected")
    
    client = clients[server_name]
    return await client.call_tool(tool_name, arguments)


def get_cached_tools(clients: Dict[str, MCPClient]) -> List[Tuple[str, Any]]:
    """
    Retrieve cached tool definitions from all connected MCP clients.
    
    Iterates through all connected clients and collects their cached tool
    definitions. Only tools from currently connected clients are included
    in the results. Each tool is paired with its server name for identification.
    
    Args:
        clients (Dict[str, MCPClient]): Dictionary of MCP client connections
            indexed by server name. Only connected clients will be queried.
            
    Returns:
        List[Tuple[str, Any]]: List of tuples where each tuple contains:
            - str: The server name where the tool is available
            - Any: The tool definition object with name, description, and schema
    """
    tools_cache = []
    for server_name, client in clients.items():
        if client.is_connected:
            tools = client._tools_cache
            for tool in tools:
                tools_cache.append((server_name, tool))
    return tools_cache
