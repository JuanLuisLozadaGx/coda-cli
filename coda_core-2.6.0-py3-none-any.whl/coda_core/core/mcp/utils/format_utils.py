from typing import Dict, List, Any
import json

from loguru import logger


def format_detailed_tool_info(server_tools: Dict[str, List[Any]]) -> str:
    """
    Format detailed tool information as comprehensive markdown documentation.
    
    Generates a complete reference document for all available MCP tools, including
    descriptions, parameter schemas, and usage examples. The output is formatted
    as markdown with proper headings and code blocks for easy reading.
    
    Args:
        server_tools (Dict[str, List[Any]]): Dictionary mapping server names to 
            lists of tool definition objects. Each tool object should have 'name',
            'description', and optionally 'inputSchema' or 'schema' attributes.
            
    Returns:
        str: A formatted markdown string containing comprehensive tool documentation
            with headings, descriptions, JSON schemas, and usage examples.
    """
    lines = ["# Available MCP Tools\n"]
    lines.append("Complete tool reference with descriptions and parameter schemas.\n")
    
    for server_name in sorted(server_tools.keys()):
        lines.append(f"## {server_name} Server\n")
        
        for tool_def in sorted(server_tools[server_name], key=lambda t: getattr(t, 'name', str(t))):
            tool_name = getattr(tool_def, 'name', 'unknown')
            description = getattr(tool_def, 'description', f'Tool {tool_name} from {server_name}')
            
            lines.append(f"### `{tool_name}`")
            lines.append(f"**Description:** {description}\n")
            
            # Schema information
            schema = getattr(tool_def, 'inputSchema', None) or getattr(tool_def, 'schema', None)
            if schema:
                lines.append("**Parameters Schema:**")
                lines.append("```json")
                if isinstance(schema, dict):
                    lines.append(json.dumps(schema, indent=2))
                else:
                    lines.append(str(schema))
                lines.append("```\n")
            else:
                lines.append("**Parameters:** No schema available\n")
            
            lines.append(f"**Usage:** `mcp_execute(server_name='{server_name}', tool_name='{tool_name}', arguments={{...}})`\n")
            lines.append("---\n")
    
    return "\n".join(lines)


def format_prompt_snippet(server_tools: Dict[str, List[Dict[str, Any]]]) -> str:
    """
    Format a concise prompt snippet for system prompt integration.
    
    Creates a brief, formatted summary of available MCP servers and their tools,
    highlighting required and optional parameter names. The output is designed
    to give the model quick access to argument names without overwhelming the
    context window.
    
    Args:
        server_tools (Dict[str, List[Dict[str, Any]]]): Dictionary mapping server
            names to lists of tool info dictionaries with keys:
                - name: tool name
                - required: list of required parameter names
                - optional: list of optional parameter names
            
    Returns:
        str: A formatted string listing servers, tools, and usage instructions
            suitable for system prompt inclusion.
    """
    lines = ["Available MCP servers, tools, and parameters:"]

    for server_name in sorted(server_tools.keys()):
        lines.append(f"\n**{server_name}** server:")
        for tool_info in sorted(server_tools[server_name], key=lambda t: t.get('name', '')):
            tool_name = tool_info.get('name', 'unknown')
            required = tool_info.get('required', []) or []
            optional = tool_info.get('optional', []) or []

            entry = f"- `{tool_name}`"
            if required:
                entry += f"; required: {', '.join(required)}"
            if optional:
                entry += f"; optional: {', '.join(optional)}"
            lines.append(entry)

    lines.append(
        "\nAlways call `mcp_execute` with `server_name`, `tool_name`, and an `arguments` object "
        "that contains the required fields for the selected tool."
    )
    return "\n".join(lines)


def format_result(mcp_result: Any) -> Any:
    """
    Format MCP result for consistent output while preserving data integrity.
    
    Intelligently processes MCP tool execution results to provide consistent,
    user-friendly output while preserving binary data, structured content, and
    special data types. Handles various MCP response formats including text
    content, lists, dictionaries, and objects with special attributes.
    
    Args:
        mcp_result (Any): The raw result from an MCP tool execution. Can be any
            type including primitives, objects with special attributes (text, content),
            lists, dictionaries, or binary data with MIME type information.
            
    Returns:
        Any: A formatted result that maintains the essential information while
            providing consistent presentation. Simple types are returned as-is,
            complex types are processed for better usability.
    """
    try:
        # Simple types
        if isinstance(mcp_result, (str, int, float, bool, type(None), bytes)):
            return mcp_result
        
        # Objects with text content
        if hasattr(mcp_result, 'text'):
            return mcp_result.text
        
        # Objects with content field
        if hasattr(mcp_result, 'content'):
            return format_result(mcp_result.content)
        
        # Check for content-type information to preserve binary data
        if hasattr(mcp_result, 'mimeType') or hasattr(mcp_result, 'content_type'):
            mime_type = getattr(mcp_result, 'mimeType', getattr(mcp_result, 'content_type', ''))
            if mime_type and not mime_type.startswith('text/'):
                return mcp_result
        
        # Lists
        if isinstance(mcp_result, list):
            if len(mcp_result) == 1:
                return format_result(mcp_result[0])
            else:
                formatted_items = [format_result(item) for item in mcp_result]
                return "\n\n".join(str(item) for item in formatted_items if item)
        
        # Dictionaries
        if isinstance(mcp_result, dict):
            if any(key in mcp_result for key in ['data', 'result', 'response', 'payload']):
                return mcp_result
            elif 'content' in mcp_result:
                return format_result(mcp_result['content'])
            else:
                return mcp_result
        
        return str(mcp_result)
        
    except Exception as e:
        logger.debug(f"Error formatting MCP result: {e}")
        return str(mcp_result)


def create_error_response(error: str, server_name: str = "", tool_name: str = "") -> Dict[str, Any]:
    """
    Create a standardized error response dictionary for MCP operations.
    
    Generates a consistent error response format used throughout the MCP service
    to provide uniform error handling and reporting. All error responses follow
    the same structure for predictable error processing.
    
    Args:
        error (str): The error message describing what went wrong.
        server_name (str, optional): Name of the MCP server where the error occurred.
            Defaults to empty string.
        tool_name (str, optional): Name of the tool that caused the error.
            Defaults to empty string.
            
    Returns:
        Dict[str, Any]: A standardized error response dictionary containing:
            - success: Always False for error responses
            - error: The provided error message
            - result: Always None for error responses  
            - server_name: The server where the error occurred
            - tool_name: The tool that caused the error
    """
    return {
        "success": False,
        "error": error,
        "result": None,
        "server_name": server_name,
        "tool_name": tool_name
    }
