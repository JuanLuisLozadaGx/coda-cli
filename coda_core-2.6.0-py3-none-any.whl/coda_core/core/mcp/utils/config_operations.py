from typing import Dict, Optional
from pathlib import Path
import json
from datetime import datetime

from loguru import logger

from coda_core.core.mcp.config import MCPServerConfig


def load_all_configurations(servers_dir: Path) -> Dict[str, MCPServerConfig]:
    """
    Load all MCP server configurations from a directory.
    
    Scans the specified directory for JSON files and attempts to load each one
    as an MCP server configuration. Malformed files are skipped with warnings.
    The function is resilient to individual file errors and will load all
    valid configurations it can find.
    
    Args:
        servers_dir (Path): Directory path containing MCP server configuration files.
            Each file should be named '{server_name}.json' and contain valid
            MCP server configuration data.
            
    Returns:
        Dict[str, MCPServerConfig]: Dictionary mapping server names to their
            loaded configuration objects. Empty dictionary if directory doesn't
            exist or contains no valid configurations.
    """
    configs = {}
    
    if not servers_dir or not servers_dir.exists():
        logger.info(f"No MCP servers directory found at {servers_dir}")
        return configs
        
    for config_file in servers_dir.glob("*.json"):
        try:
            with open(config_file, 'r') as f:
                data = json.load(f)
            
            server_name = config_file.stem
            config = MCPServerConfig.from_config_dict(server_name, data)
            configs[server_name] = config
            
        except Exception as e:
            logger.warning(f"Skipping malformed MCP config file {config_file}: {e}")
    
    logger.info(f"Loaded {len(configs)} MCP server configurations")
    return configs


def load_server_config(servers_dir: Path, server_name: str) -> Optional[MCPServerConfig]:
    """
    Load a specific MCP server configuration by name.
    
    Attempts to load a single server configuration from the expected JSON file
    in the servers directory. The file should be named '{server_name}.json'.
    Returns None if the file doesn't exist or can't be loaded.
    
    Args:
        servers_dir (Path): Directory path containing MCP server configuration files.
        server_name (str): Name of the server configuration to load. This should
            match the filename without the .json extension.
            
    Returns:
        Optional[MCPServerConfig]: The loaded server configuration object, or None
            if the file doesn't exist, directory is not initialized, or loading fails.
    """
    if not servers_dir:
        return None
        
    server_file = servers_dir / f"{server_name}.json"
    if not server_file.exists():
        return None
        
    try:
        with open(server_file, 'r') as f:
            data = json.load(f)
        return MCPServerConfig.from_config_dict(server_name, data)
    except Exception as e:
        logger.error(f"Error loading MCP server '{server_name}': {e}")
        return None


def save_server_config(servers_dir: Path, config: MCPServerConfig) -> None:
    """
    Save an MCP server configuration to a JSON file.
    
    Serializes the provided server configuration object to JSON and writes it
    to the appropriate file in the servers directory. The file will be named
    '{config.name}.json' and formatted with proper indentation for readability.
    
    Args:
        servers_dir (Path): Directory path where the configuration file should be saved.
            Must be initialized and writable.
        config (MCPServerConfig): The server configuration object to save. The
            config.name property determines the output filename.
            
    Raises:
        RuntimeError: If the servers directory is not initialized.
        Exception: If file writing fails due to permissions or other I/O errors.
    """
    if not servers_dir:
        raise RuntimeError("Servers directory not initialized")
        
    server_file = servers_dir / f"{config.name}.json"
    
    try:
        with open(server_file, 'w') as f:
            json.dump(config.to_config_dict(), f, indent=2)
        logger.success(f"Saved MCP server '{config.name}' to {server_file}")
    except Exception as e:
        logger.error(f"Error saving MCP server '{config.name}': {e}")
        raise


def remove_server_config(servers_dir: Path, server_name: str) -> bool:
    """
    Remove an MCP server configuration file from the filesystem.
    
    Safely deletes the JSON configuration file for the specified server from
    the servers directory. The operation is idempotent - it will not fail if
    the file doesn't exist, but will return False to indicate no action was taken.
    
    Args:
        servers_dir (Path): Directory path containing MCP server configuration files.
            If not initialized, the function returns False with a warning.
        server_name (str): Name of the server configuration to remove. The function
            will look for '{server_name}.json' in the servers directory.
            
    Returns:
        bool: True if the file was successfully removed, False if the file didn't
            exist, the directory is not initialized, or removal failed.
    """
    if not servers_dir:
        logger.warning("Servers directory not initialized")
        return False
        
    server_file = servers_dir / f"{server_name}.json"
    
    try:
        if server_file.exists():
            server_file.unlink()
            logger.success(f"Removed MCP server '{server_name}'")
            return True
        else:
            logger.warning(f"MCP server file '{server_name}.json' not found")
            return False
    except Exception as e:
        logger.error(f"Error removing MCP server '{server_name}': {e}")
        return False


def load_global_mcp_defaults(global_file: Path) -> Dict[str, bool]:
    """
    Load global MCP server default states.
    
    Args:
        global_file: Path to the global MCP defaults JSON file
        
    Returns:
        Dict[str, bool]: Dictionary mapping server names to default enabled states.
        Empty dictionary if file doesn't exist or can't be loaded.
    """
    if not global_file.exists():
        logger.debug(f"Global MCP defaults file not found: {global_file}")
        return {}
    
    try:
        with open(global_file, 'r') as f:
            data = json.load(f)
        
        server_states = data.get('server_states', {})
        logger.debug(f"Loaded global MCP defaults for {len(server_states)} servers")
        return server_states
        
    except Exception as e:
        logger.error(f"Error loading global MCP defaults: {e}")
        return {}


def save_global_mcp_defaults(global_file: Path, states: Dict[str, bool]) -> bool:
    """
    Save global MCP server default states.
    
    Args:
        global_file: Path to the global MCP defaults JSON file
        states: Dictionary mapping server names to default enabled states
        
    Returns:
        bool: True if saved successfully, False otherwise
    """
    try:
        # Ensure parent directory exists
        global_file.parent.mkdir(parents=True, exist_ok=True)
        
        data = {
            'server_states': states,
            'version': '1.0',
            'last_updated': datetime.now().isoformat()
        }
        
        with open(global_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        logger.success(f"Saved global MCP defaults for {len(states)} servers")
        return True
        
    except Exception as e:
        logger.error(f"Error saving global MCP defaults: {e}")
        return False


def load_session_mcp_config(session_file: Path) -> Dict[str, bool]:
    """
    Load session-specific MCP server state overrides.
    
    Args:
        session_file: Path to the session MCP config JSON file
        
    Returns:
        Dict[str, bool]: Dictionary mapping server names to overridden enabled states.
        Empty dictionary if file doesn't exist or can't be loaded.
    """
    if not session_file.exists():
        logger.debug(f"Session MCP config file not found: {session_file}")
        return {}
    
    try:
        with open(session_file, 'r') as f:
            data = json.load(f)
        
        server_overrides = data.get('server_overrides', {})
        logger.debug(f"Loaded session MCP overrides for {len(server_overrides)} servers")
        return server_overrides
        
    except Exception as e:
        logger.error(f"Error loading session MCP config: {e}")
        return {}


def save_session_mcp_config(session_file: Path, overrides: Dict[str, bool], session_id: str) -> bool:
    """
    Save session-specific MCP server state overrides.
    
    Args:
        session_file: Path to the session MCP config JSON file
        overrides: Dictionary mapping server names to overridden enabled states
        session_id: The session identifier
        
    Returns:
        bool: True if saved successfully, False otherwise
    """
    try:
        # Ensure parent directory exists
        session_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Load existing data to preserve timestamps
        existing_data = {}
        if session_file.exists():
            try:
                with open(session_file, 'r') as f:
                    existing_data = json.load(f)
            except:
                pass  # Start fresh if existing file is malformed
        
        data = {
            'server_overrides': overrides,
            'session_id': session_id,
            'created': existing_data.get('created', datetime.now().isoformat()),
            'last_updated': datetime.now().isoformat()
        }
        
        with open(session_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        logger.debug(f"Saved session MCP config for {len(overrides)} server overrides")
        return True
        
    except Exception as e:
        logger.error(f"Error saving session MCP config: {e}")
        return False


def merge_mcp_configs(global_states: Dict[str, bool], session_overrides: Dict[str, bool]) -> Dict[str, bool]:
    """
    Merge global MCP defaults with session-specific overrides.
    
    Args:
        global_states: Global default server enabled states
        session_overrides: Session-specific overrides
        
    Returns:
        Dict[str, bool]: Effective server enabled states (global + session)
    """
    # Start with global defaults
    effective_states = global_states.copy()
    
    # Apply session overrides
    effective_states.update(session_overrides)
    
    return effective_states
