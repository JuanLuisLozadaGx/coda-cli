from typing import TYPE_CHECKING
import os
import asyncio

from loguru import logger

if TYPE_CHECKING:
    from fastmcp.client.logging import LogMessage


class CustomStderrHandler:
    """Handler that creates a real pipe and forwards stderr to loguru."""
    
    def __init__(self, log_level: str = "DEBUG", prefix: str = "MCP"):
        self.log_level = log_level.upper()
        self.prefix = prefix
        self._read_fd = None
        self._write_fd = None
        self._read_file = None
        self._reader_task = None
        self._closed = False
        self._write_file = None
        
        # Initialize the pipe with proper error handling
        self._initialize_pipe()
    
    def _initialize_pipe(self):
        """Initialize the pipe with proper error handling to prevent resource leaks."""
        try:
            # Create a real pipe
            self._read_fd, self._write_fd = os.pipe()
            
            # Create the write file object once
            self._write_file = os.fdopen(self._write_fd, 'w')
            
            # Make read_fd non-blocking for better control (Unix only)
            try:
                import fcntl        # Default import for Unix-like systems
                flags = fcntl.fcntl(self._read_fd, fcntl.F_GETFL)
                fcntl.fcntl(self._read_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
            except (ImportError, OSError):
                # Windows or other platforms without fcntl
                pass
            
            # Create read file object once to avoid reusing file descriptor
            self._read_file = os.fdopen(self._read_fd, 'r')
            
        except Exception:
            # Clean up any partially created resources
            # Close write file if it exists
            if self._write_file is not None:
                try:
                    self._write_file.close()
                except OSError:
                    pass
                self._write_file = None
            
            # Close write fd if it exists and wasn't already closed by write_file
            if self._write_fd is not None:
                try:
                    os.close(self._write_fd)
                except OSError:
                    pass
                self._write_fd = None
            
            # Close read file if it exists
            if self._read_file is not None:
                try:
                    self._read_file.close()
                except OSError:
                    pass
                self._read_file = None
            
            # Close read fd if it exists and wasn't already closed by read_file
            if self._read_fd is not None:
                try:
                    os.close(self._read_fd)
                except OSError:
                    pass
                self._read_fd = None
            
            # Re-raise the original exception
            raise
    
    def get_write_file(self):
        """Get the file object that subprocess should write to."""
        return self._write_file
    
    def start_reader(self):
        """Start the background reader task (call this from async context)."""
        if self._reader_task is None and not self._closed:
            logger.debug(f"Starting stderr reader for {self.prefix}")
            self._reader_task = asyncio.create_task(self._read_stderr())
    
    async def _read_stderr(self):
        """Background task that reads from pipe and forwards to loguru."""
        logger.debug(f"{self.prefix} stderr reader started")
        
        try:
            while not self._closed:
                try:
                    # Try to read a line non-blocking
                    line = os.read(self._read_file) # os.read is non-blocking
                    if line:
                        # Decode the data
                        line = line.decode("utf-8", errors="replace")
                        # Got a line, process it
                        line = line.rstrip('\n\r')
                        if line.strip():  # Only log non-empty lines
                            logger.log(self.log_level, f"{self.prefix} stderr: {line}")
                    else:
                        # No data available or EOF, sleep briefly and check again
                        await asyncio.sleep(0.01)
                        
                except (BlockingIOError, OSError):
                    # No data available, sleep briefly
                    await asyncio.sleep(0.01)
                    continue
                except asyncio.CancelledError:
                    logger.debug(f"{self.prefix} stderr reader cancelled")
                    break
                except Exception as e:
                    logger.debug(f"Error reading stderr pipe: {e}")
                    break
            
        except Exception as e:
            logger.debug(f"Error in stderr reader: {e}")
        finally:
            logger.debug(f"{self.prefix} stderr reader finished")
    
    async def close(self):
        """Clean up pipe and reader task."""
        if self._closed:
            return
        
        # Close write file and fd first to signal EOF to reader
        try:
            if self._write_file is not None:
                self._write_file.close()
                self._write_file = None
        except OSError:
            pass
        
        try:
            if self._write_fd is not None:
                os.close(self._write_fd)
                self._write_fd = None
        except OSError:
            pass
        
        # Cancel and wait for reader task to finish
        if self._reader_task and not self._reader_task.done():
            logger.debug(f"Cancelling {self.prefix} stderr reader task")
            self._reader_task.cancel()
            try:
                await asyncio.wait_for(self._reader_task, timeout=2.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                pass
            except Exception as e:
                logger.debug(f"Error waiting for stderr reader to finish: {e}")
        
        self._reader_task = None
        
        # Close read file and fd
        try:
            if self._read_file is not None:
                self._read_file.close()
                self._read_file = None
        except OSError:
            pass
        
        try:
            if self._read_fd is not None:
                os.close(self._read_fd)
                self._read_fd = None
        except OSError:
            pass
        
        # Mark as closed only after all cleanup is complete
        self._closed = True


async def custom_log_handler(message: 'LogMessage'):
    """
    Custom log handler that routes MCP protocol logs through loguru.
    
    Args:
        message (fastmcp.client.logging.LogMessage): The log message from FastMCP.
        **Note**: Type hinting `'LogMessage'` used to avoid direct import of fastmcp module.
    """
    level_map = {
        "debug": "DEBUG",
        "info": "INFO", 
        "notice": "INFO",
        "warning": "WARNING",
        "error": "ERROR",
        "critical": "CRITICAL",
        "alert": "ERROR",
        "emergency": "CRITICAL"
    }
    
    # Extract message data following FastMCP's pattern
    if isinstance(message.data, dict):
        msg = message.data.get('msg', str(message.data))
        extra = message.data.get('extra', {})
    else:
        msg = str(message.data)
        extra = {}
    
    level = level_map.get(message.level.lower(), "INFO")
    logger_name = message.logger or 'server'
    
    # Log with server context and any extra data
    logger.log(level, f"MCP[{logger_name}]: {msg}", **extra)
