# Connection error detection patterns
# Used by MCPClient._is_connection_error() to identify recoverable connection errors
CONNECTION_ERROR_INDICATORS = [
    "connection",
    "closed", 
    "broken",
    "timeout",
    "network",
    "refused",
    "unreachable",
    "disconnected",
    "stream",
    "socket"
] 