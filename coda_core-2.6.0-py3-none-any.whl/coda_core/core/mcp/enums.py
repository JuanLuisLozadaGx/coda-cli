from enum import Enum

class TransportType(Enum):
    """
    Supported MCP transport protocols.
    
    Defines the communication protocols available for MCP server connections,
    following the official MCP specification for both local and remote servers.
    
    Values:
        STDIO: Standard input/output transport for local MCP servers
               (traditional Claude Desktop format)
        HTTP: HTTP Streamable transport for remote MCP servers
              (2025-03-26 specification)
    
    Example:
        # Use STDIO for local servers
        transport = TransportType.STDIO
        
        # Use HTTP for remote API servers  
        transport = TransportType.HTTP
    """
    STDIO = "stdio"
    HTTP = "http"  # HTTP Streamable transport (2025-03-26 spec)