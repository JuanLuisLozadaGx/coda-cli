import os
import contextlib
import asyncio

from loguru import logger
from mcp.client.stdio import stdio_client
from mcp import StdioServerParameters
from mcp.client.session import ClientSession
from fastmcp.client.transports import StdioTransport

from coda_core.core.mcp.logging import CustomStderrHandler


class CustomStdioTransport(StdioTransport):
    """Custom StdioTransport with configurable stderr handling."""
    
    def __init__(self, command: str, args: list[str], env: dict[str, str] | None = None,
                 cwd: str | None = None, keep_alive: bool | None = None,
                 stderr_mode: str = "suppress"):
        """
        Initialize CustomStdioTransport with stderr handling.
        
        Args:
            command: The command to run (e.g., "python", "node", "uvx")
            args: The arguments to pass to the command
            env: Environment variables to set for the subprocess
            cwd: Current working directory for the subprocess
            keep_alive: Whether to keep the subprocess alive between connections
            stderr_mode: How to handle stderr:
                - "suppress": Completely suppress stderr (default)
                - "log": Forward all stderr to loguru at DEBUG level
        """
        super().__init__(command, args, env, cwd, keep_alive)
        
        self.stderr_mode = stderr_mode
        self._stderr_handler = None
        self._custom_handler = None
        
        # Set up stderr handling based on mode
        if stderr_mode == "suppress":
            self._stderr_handler = open(os.devnull, 'w')
            self._custom_handler = None
        elif stderr_mode == "log":
            self._custom_handler = CustomStderrHandler(
                log_level="DEBUG",
                prefix=f"MCP[{self.command}]"
            )
            self._stderr_handler = self._custom_handler.get_write_file()
            logger.debug(f"Created custom stderr handler for {self.command} in log mode")
        else:
            raise ValueError(f"Invalid stderr_mode: {stderr_mode}. Must be 'suppress' or 'log'")

    async def connect(self, **session_kwargs) -> ClientSession | None:
        """Override connect to use our custom _connect_task with stderr handling."""
        if self._connect_task is not None:
            return

        async def _connect_task():
            try:
                async with contextlib.AsyncExitStack() as stack:
                    try:
                        server_params = StdioServerParameters(
                            command=self.command,
                            args=self.args,
                            env=self.env,
                            cwd=self.cwd,
                        )
                        
                        # Start stderr reader if using custom handler
                        if self._custom_handler:
                            self._custom_handler.start_reader()
                        
                        # Add errlog parameter
                        transport = await stack.enter_async_context(
                            stdio_client(server_params, errlog=self._stderr_handler)
                        )
                        
                        read_stream, write_stream = transport
                        self._session = await stack.enter_async_context(
                            ClientSession(read_stream, write_stream, **session_kwargs)
                        )

                        logger.debug(f"Custom stdio transport connected with stderr_mode='{self.stderr_mode}'")
                        self._ready_event.set()

                        # Wait until disconnect is requested
                        await self._stop_event.wait()
                    finally:
                        # Clean up client on exit
                        self._session = None
                        logger.debug("Custom stdio transport disconnected")
            except Exception:
                # Ensure ready event is set even if connection fails
                self._ready_event.set()
                raise

        # Start the connection task
        self._connect_task = asyncio.create_task(_connect_task())
        # Wait for the client to be ready before returning
        await self._ready_event.wait()

        # Check if connect task completed with an exception
        if self._connect_task.done():
            exception = self._connect_task.exception()
            if exception is not None:
                raise exception

    async def close(self):
        """Clean up stderr handling when closing transport."""
        logger.debug(f"Closing custom stdio transport for {self.command}")
        
        # Call parent close method first to trigger proper shutdown sequence
        await super().close()
        
        # Then clean up our custom stderr handler
        if self._custom_handler:
            try:
                await self._custom_handler.close()
            except Exception as e:
                logger.debug(f"Warning: Could not close custom stderr handler: {e}")
        
        # Clean up regular stderr handler
        if self._stderr_handler and hasattr(self._stderr_handler, 'close'):
            try:
                self._stderr_handler.close()
            except Exception as e:
                logger.debug(f"Warning: Could not close stderr handler: {e}")
        
        logger.debug(f"Custom stdio transport closed for {self.command}")
    
    def __repr__(self) -> str:
        return (
            f"<CustomStdioTransport(command='{self.command}', args={self.args}, "
            f"stderr_mode='{self.stderr_mode}')>"
        )
