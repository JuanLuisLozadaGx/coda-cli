from typing import Dict, List, Optional, Any, Union, TYPE_CHECKING
from contextlib import AsyncExitStack
import asyncio

from loguru import logger

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.core.mcp.config import MCPServerConfig, TransportType
from coda_core.core.mcp.constants import CONNECTION_ERROR_INDICATORS
from coda_core.core.mcp.logging import custom_log_handler

if TYPE_CHECKING:
    # Type hints
    from fastmcp import Client as _Client
    from fastmcp.client.transports import StreamableHttpTransport as _StreamableHttpTransport
    from coda_core.core.mcp.transports import CustomStdioTransport as _CustomStdioTransport


# References to lazy import FastMCP
Client: '_Client' = None
StreamableHttpTransport: '_StreamableHttpTransport' = None
CustomStdioTransport: '_CustomStdioTransport' = None


class MCPClient:
    """
    MCP client supporting STDIO and HTTP Streamable transports.
    """
    
    def __init__(self, config: MCPServerConfig):
        """
        Initialize MCP client with server configuration.
        
        Args:
            config: MCPServerConfig containing transport type, connection details,
                   and server-specific settings.
        """
        self.config = config
        self.client: Optional['_Client'] = None
        self._tools_cache: List[Any] = []
        self._connected = False
        self._exit_stack: Optional[AsyncExitStack] = None
        self._lock = asyncio.Lock()
        self.last_error: Optional[str] = None
    
    def _lazy_load_fastmcp(self) -> None:
        """
        Lazy load of different modules dependent on FastMCP.

        **Note**: The reason for lazy loads is to improve startup time on different
        clients of the `coda-core` package. As `FastMCP` import takes a noticeable time.
        """
        global Client, StreamableHttpTransport, CustomStdioTransport

        if Client is None:
            from fastmcp import Client as FastClient
            Client = FastClient
            logger.debug("Lazy-loaded FastMCP Client")

        if StreamableHttpTransport is None:
            from fastmcp.client.transports import StreamableHttpTransport as FastStream
            StreamableHttpTransport = FastStream
            logger.debug("Lazy-loaded StreamableHttpTransport")

        if CustomStdioTransport is None:
            from coda_core.core.mcp.transports import CustomStdioTransport as CodaCustomStdioTransport
            CustomStdioTransport = CodaCustomStdioTransport
            logger.debug("Lazy-loaded CustomStdioTransport")

    async def connect(self) -> bool:
        """Connect with appropriate strategy: persistent for stateful servers, test-only for stateless."""
        try:
            self.last_error = None
            self._lazy_load_fastmcp()

            # Build FastMCP configuration for official transports only
            self.fastmcp_config = self._build_fastmcp_config()
            
            if self._should_use_persistent_connection():
                # For stateful servers (Playwright, memory): create persistent connection
                await self._init_persistent_connection()
                # Set log level for persistent connection
                await self._set_mcp_log_level(self.client)

                # Get tools from the persistent client
                self._tools_cache = await self.client.list_tools()
            else:
                # For stateless servers: just test connection and cache schema
                async with Client(self.fastmcp_config, log_handler=custom_log_handler) as temp_client:
                    self._tools_cache = await temp_client.list_tools()
            
            self._connected = True
            
            transport_name = "HTTP Streamable" if self.config.transport_type == TransportType.HTTP else "STDIO"
            connection_type = "persistent" if self._should_use_persistent_connection() else "on-demand"
            logger.success(f"Connected to '{self.config.name}' via {transport_name} ({connection_type}) "
                         f"- {len(self._tools_cache)} tools available")
            return True
            
        except Exception as e:
            self.last_error = str(e)
            # Handle HTTP errors with proper status codes
            if hasattr(e, 'status_code') or hasattr(e, 'response'):
                status_code = getattr(e, 'status_code', None) or getattr(getattr(e, 'response', None), 'status_code', None)
                if status_code == 401:
                    logger.error(f"MCP authentication failed for '{self.config.name}': Check authorization token")
                elif status_code == 403:
                    logger.error(f"MCP authorization failed for '{self.config.name}': Insufficient permissions")
                elif status_code == 404:
                    logger.error(f"MCP server not found for '{self.config.name}': Check URL")
                elif status_code == 500:
                    logger.error(f"MCP server error for '{self.config.name}': Internal server error")
                else:
                    logger.error(f"MCP HTTP error for '{self.config.name}': {status_code} - {e}")
            else:
                # Fallback to string-based detection for non-HTTP errors
                error_msg = str(e).lower()
                if "timeout" in error_msg or "connection" in error_msg:
                    logger.error(f"MCP connection timeout for '{self.config.name}': Check URL and network")
                elif "unauthorized" in error_msg or "401" in error_msg:
                    logger.error(f"MCP authentication failed for '{self.config.name}': Check authorization token")
                elif "forbidden" in error_msg or "403" in error_msg:
                    logger.error(f"MCP authorization failed for '{self.config.name}': Insufficient permissions")
                else:
                    logger.error(f"MCP connection failed for '{self.config.name}': {e}")
            
            # Log additional debug info for HTTP connections
            if self.config.transport_type == TransportType.HTTP:
                logger.debug(f"Connection details - URL: {self.config.url}, Headers: {len(self.config.headers)} configured")
            
            await self._cleanup()
            return False
    
    async def disconnect(self) -> None:
        """Clean disconnect."""
        await self._cleanup()
    
    async def _cleanup(self) -> None:
        """Clean up connection resources."""
        self._connected = False
        self._tools_cache.clear()
        
        if self._exit_stack:
            try:
                await self._exit_stack.aclose()
            except Exception as e:
                logger.debug(f"Cleanup warning for '{self.config.name}': {e}")
            finally:
                self._exit_stack = None
        
        # Clear client reference after cleanup
        self.client = None
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """Execute tool using appropriate connection strategy with recovery."""
        logger.debug(f"call_tool called for {self.config.name}: connected={self._connected}")
        
        # For persistent connections, allow recovery even if _connected=False
        if not self._connected and not self._should_use_persistent_connection():
            logger.error(f"Not connected to '{self.config.name}': connected={self._connected}")
            raise RuntimeError(f"Not connected to '{self.config.name}'")

        self._lazy_load_fastmcp()

        max_retries = 2
        for attempt in range(max_retries):
            try:
                logger.debug(f"Calling tool '{tool_name}' on '{self.config.name}' (attempt {attempt + 1})")
                
                if self._should_use_persistent_connection():
                    # For persistent connections, ensure we have a valid client
                    if not self.client or not await self._is_connection_healthy():
                        logger.info(f"Connection unhealthy for '{self.config.name}', reconnecting...")
                        await self._force_cleanup()
                        await self._init_persistent_connection()
                        self._connected = True

                    # Serialise concurrent calls to the same process
                    async with self._lock:         
                        result = await self.client.call_tool(tool_name, arguments)
                else:
                    # For stateless servers: use fresh connection for each call
                    async with Client(self.fastmcp_config, log_handler=custom_log_handler) as client:
                        result = await client.call_tool(tool_name, arguments)
                
                logger.debug(f"Tool '{tool_name}' on '{self.config.name}' succeeded")
                return result
                
            except Exception as e:
                logger.warning(f"Tool '{tool_name}' attempt {attempt + 1} failed on '{self.config.name}': {e}")
                
                # Check if this is a connection error that we can recover from
                if self._is_connection_error(e) and attempt < max_retries - 1:
                    logger.info(f"Connection error detected, will retry (attempt {attempt + 1}/{max_retries})")
                    if self._should_use_persistent_connection():
                        await self._force_cleanup()
                        # Brief pause before retry
                        await asyncio.sleep(0.1)
                    continue
                else:
                    # Final failure or non-connection error
                    logger.error(f"Tool '{tool_name}' failed on '{self.config.name}' after {attempt + 1} attempts: {e}")
                    raise
    
    async def list_tools(self) -> List[Any]:
        """Get cached tools."""
        return self._tools_cache.copy()
    
    @property
    def is_connected(self) -> bool:
        if self._should_use_persistent_connection():
            return bool(self.client and getattr(self.client, "connected", True))
        else:
            return self._connected
    
    def _should_use_persistent_connection(self) -> bool:
        """Determine if this server should use persistent connections for session continuity."""
        # Check explicit stateful flag first
        if hasattr(self.config, 'stateful') and self.config.stateful is not None:
            return self.config.stateful
        
        # Default strategy: STDIO servers use persistent connections, HTTP servers use on-demand
        return self.config.transport_type == TransportType.STDIO
    
    async def _init_persistent_connection(self) -> None:
        """Initialize persistent FastMCP connection with proper async context management."""
        try:
            self._lazy_load_fastmcp()

            # Create AsyncExitStack to manage the context
            self._exit_stack = AsyncExitStack()
            
            # Enter the FastMCP client context using the exit stack
            self.client = await self._exit_stack.enter_async_context(
                Client(self.fastmcp_config, log_handler=custom_log_handler)
            )
            
            logger.debug(f"Initialized persistent connection for '{self.config.name}'")
            
        except Exception as e:
            logger.error(f"Failed to initialize persistent connection for '{self.config.name}': {e}")
            await self._cleanup()
            raise


    def _build_fastmcp_config(self) -> Union['_StreamableHttpTransport', '_CustomStdioTransport']:
        """Build FastMCP configuration for official MCP transports."""
        if self.config.transport_type == TransportType.HTTP:
            self._lazy_load_fastmcp()
            # Use HTTP Streamable transport
            return StreamableHttpTransport(
                url=self.config.url,
                headers=self.config.headers
            )
        
        else:  # TransportType.STDIO
            # Build environment variables for logging control
            server_env = self.config.env.copy() if self.config.env else {}
            if not server_env.get("LOG_LEVEL"):
                server_env.update({
                    "LOG_LEVEL": SETTINGS.get_env_var(EnvConfig.CODA_LOG_LEVEL)
            })
            
            return CustomStdioTransport(
                command=self.config.command,
                args=self.config.args,
                env=server_env,
                cwd=None,
                keep_alive=True,
                stderr_mode="log" if SETTINGS.get_env_var(EnvConfig.CODA_LOG_LEVEL).lower() == "debug" else "suppress"
            )

    def _is_connection_error(self, exception: Exception) -> bool:
        """Check if an exception indicates a connection problem that can be recovered."""
        # Import here to avoid circular imports
        try:
            from anyio import ClosedResourceError
        except ImportError:
            ClosedResourceError = type(None)
        
        error_msg = str(exception).lower()
        
        # Check exception type and message
        is_connection_error = (
            isinstance(exception, (ConnectionError, TimeoutError, OSError)) or
            isinstance(exception, ClosedResourceError) or
            any(indicator in error_msg for indicator in CONNECTION_ERROR_INDICATORS)
        )
        
        if is_connection_error:
            logger.debug(f"Detected connection error: {type(exception).__name__}: {exception}")
            
        return is_connection_error

    async def _is_connection_healthy(self) -> bool:
        """Check if the current connection is healthy."""
        if not self.client:
            return False
            
        # For persistent connections, check subprocess and stream state
        if self._should_use_persistent_connection():
            try:
                # Check if the underlying subprocess is still running
                if hasattr(self.client, '_subprocess') and self.client._subprocess:
                    if self.client._subprocess.poll() is not None:
                        logger.debug(f"Subprocess terminated for '{self.config.name}'")
                        return False
                
                # Check if client has connected attribute
                if hasattr(self.client, 'connected'):
                    if not self.client.connected:
                        logger.debug(f"Client reports not connected for '{self.config.name}'")
                        return False
                        
                return True
                
            except Exception as e:
                logger.debug(f"Health check failed for '{self.config.name}': {e}")
                return False
        
        # For non-persistent connections, assume healthy if client exists
        return True

    async def _force_cleanup(self) -> None:
        """Force cleanup of connection resources."""
        logger.debug(f"Force cleanup for '{self.config.name}'")
        
        try:
            # Mark as disconnected immediately
            self._connected = False
            
            # Clean up the persistent client
            if self._exit_stack:
                try:
                    await self._exit_stack.aclose()
                except Exception as e:
                    logger.debug(f"Error during exit stack cleanup: {e}")
                finally:
                    self._exit_stack = None
            
            # Clear client reference
            self.client = None
            
            logger.debug(f"Force cleanup completed for '{self.config.name}'")
            
        except Exception as e:
            logger.warning(f"Error during force cleanup for '{self.config.name}': {e}")

    async def _set_mcp_log_level(self, client: '_Client') -> None:
        """
        Set MCP server log level to match system log level (for persistent connections only).

        Args:
            client (fastmcp.Client): FastMCP client instance.
            **Note**: Type hinting `'_Client'` used to avoid direct import of fastmcp module.
        """
        try:
            system_log_level = SETTINGS.get_env_var(EnvConfig.CODA_LOG_LEVEL).lower()
            await client.set_logging_level(system_log_level)
            logger.info(f"Set MCP server '{self.config.name}' log level to {system_log_level}")
        except Exception as e:
            # Many MCP servers don't implement logging/setLevel - this is normal
            logger.warning(f"MCP server '{self.config.name}' doesn't support log level setting")
