# MCP (Model Context Protocol) Integration

## Overview

The MCP (Model Context Protocol) module provides comprehensive support for connecting CODA to external MCP servers, enabling CODA to access tools and services from the broader MCP ecosystem. This integration follows a sophisticated modular architecture with centralized coordination, connection management, and error handling.

## Architecture

The MCP integration is built around a modular architecture with clear separation of concerns:

```mermaid
classDiagram
    class MCPService {
        <<singleton>>
        +get() MCPService
        +initialize() bool
        +is_available() bool
        +execute(server_name, tool_name, arguments) Dict
        +list_servers() List[str]
        +list_tools() List[Tuple]
        +prompt_snippet() str
        +reload() bool
        +get_server_status() Dict
        +load_configurations() Dict
        +add_server(config) void
        +remove_server(name) bool
    }
    
    class MCPClient {
        +config: MCPServerConfig
        +is_connected: bool
        +connect() bool
        +disconnect() void
        +call_tool(tool_name, arguments) Any
        +list_tools() List[Any]
    }
    
    class MCPExecuteTool {
        +name: str = "mcp_execute"
        +description: str
        +execute(server_name, tool_name, arguments) Dict
        +is_available() bool
    }
    
    class MCPServerConfig {
        +name: str
        +transport_type: TransportType
        +enabled: bool
        +stateful: bool
        +from_config_dict() MCPServerConfig
        +to_config_dict() Dict
    }
    
    MCPExecuteTool --> MCPService
    MCPService --> MCPClient
    MCPClient --> MCPServerConfig
```

## Key Components

### MCPService - Centralized Coordinator

The `MCPService` is a singleton that acts as the primary coordinator for all MCP operations:

**Core Responsibilities:**
- **Singleton Management**: Ensures consistent state across the application
- **Connection Orchestration**: Delegates connection management to specialized utility modules
- **Tool Discovery**: Maintains cached tool definitions from all connected servers
- **Configuration Management**: Handles server configurations and state persistence
- **Session Management**: Supports session-specific server state overrides with global defaults

**Key Features:**
- **Modular Design**: Delegates specialized operations to functional modules:
  - `server_connections`: Connection lifecycle management
  - `tool_execution`: Tool execution and caching
  - `config_operations`: Configuration file operations
  - `format_utils`: Result and error formatting
- **Auto-initialization**: Automatically initializes when first accessed
- **File-based Configuration**: Automatically detects MCP servers from JSON configuration files
- **Error Isolation**: Server failures don't affect other servers or built-in tools
- **Graceful Degradation**: System continues to function even when MCP is unavailable

### MCPClient - Server Connection Management

The `MCPClient` handles individual server connections with sophisticated transport support:

**Transport Support:**
- **STDIO Transport**: Traditional subprocess-based communication (Claude Desktop compatible)
- **HTTP Streamable Transport**: Modern HTTP-based communication for remote servers

**Connection Strategies:**
- **Persistent Connections**: For stateful servers that maintain context (STDIO servers, Playwright)
- **On-demand Connections**: For stateless servers that don't require session continuity (HTTP services)

**Advanced Features:**
- **Connection Health Monitoring**: Automatic detection of broken connections
- **Auto-reconnection**: Intelligent retry logic for connection failures
- **Resource Management**: Proper cleanup with AsyncExitStack for connection contexts
- **Error Recovery**: Graceful handling of transport-specific errors with detailed diagnostics

### MCPExecuteTool - The Gateway

The `MCPExecuteTool` serves as the single entry point for all MCP functionality:

```python
class MCPExecuteTool(FunctionTool):
    """Single tool for executing any MCP server tool."""
    
    name = "mcp_execute"
    description = "Execute any tool from any configured MCP server. Specify the server name and tool name as separate parameters."
    
    def execute(self, server_name: str, tool_name: str, arguments: Optional[Dict[str, Any]] = None):
        """Execute an MCP tool through the centralized service."""
        mcp_service = MCPService.get()
        return mcp_service.execute(server_name, tool_name, arguments or {})
```

**Key Features:**
- **Gateway Pattern**: Single tool provides access to all MCP functionality
- **Dynamic Descriptions**: Automatically generates comprehensive descriptions including all available MCP tools
- **Standard Integration**: Properly registered in the tool registry like any other tool
- **Parameter Validation**: Validates server names and tool names
- **Error Handling**: Comprehensive error handling with detailed messages
- **Availability Checking**: Only available when MCP service is properly configured

### MCPServerConfig - Configuration Management

The `MCPServerConfig` class provides flexible server configuration with Claude Desktop compatibility:

**Transport Detection:**
- Automatically detects transport type based on configuration structure
- Maintains full compatibility with existing Claude Desktop configurations
- Extends support for modern HTTP Streamable transport

**Configuration Formats:**

**STDIO Server Example** (`filesystem.json`):
```json
{
  "name": "filesystem",
  "command": "npx",
  "args": ["-y", "@modelcontextprotocol/server-filesystem", "~/Documents"],
  "env": {
    "NODE_ENV": "production"
  },
  "enabled": true
}
```

**HTTP Server Example** (`github.json`):
```json
{
  "name": "github", 
  "url": "https://api.github.com/mcp",
  "authorization_token": "Bearer your-token",
  "timeout": 30,
  "enabled": true
}
```

## Tool Discovery and Execution Flow

```mermaid
sequenceDiagram
    participant Agent
    participant MCPExecuteTool
    participant MCPService
    participant ServerConnections
    participant ToolExecution
    participant MCPClient
    participant MCPServer
    
    Note over Agent,MCPServer: Tool Discovery
    Agent->>MCPExecuteTool: Get available tools info
    MCPExecuteTool->>MCPService: list_tools()
    MCPService->>ServerConnections: ensure_connected()
    ServerConnections->>MCPClient: connect() for each server
    MCPClient->>MCPServer: List tools
    MCPServer-->>MCPClient: Tool definitions
    MCPClient-->>ServerConnections: Connected with cached tools
    ServerConnections-->>MCPService: Connection status
    MCPService->>ToolExecution: get_cached_tools()
    ToolExecution-->>MCPService: Consolidated tool list
    MCPService-->>MCPExecuteTool: Available tools
    MCPExecuteTool-->>Agent: Tool catalog
    
    Note over Agent,MCPServer: Tool Execution
    Agent->>MCPExecuteTool: execute(server_name, tool_name, args)
    MCPExecuteTool->>MCPService: execute(server_name, tool_name, args)
    MCPService->>ToolExecution: execute_tool_async()
    ToolExecution->>ServerConnections: ensure_server_connected()
    ServerConnections->>MCPClient: Verify/establish connection
    ToolExecution->>MCPClient: call_tool(tool_name, args)
    MCPClient->>MCPServer: Execute tool with retry logic
    MCPServer-->>MCPClient: Tool result
    MCPClient-->>ToolExecution: Formatted result
    ToolExecution-->>MCPService: Execution result
    MCPService-->>MCPExecuteTool: Final result
    MCPExecuteTool-->>Agent: Tool output
```

## Configuration and Setup

### Auto-detection and Initialization

The MCP system automatically enables when server configuration files are detected in `~/.coda/.tools/mcp/servers.d/`:

```python
def is_available(self) -> bool:
    """Check if MCP functionality is available."""
    return (self._initialized and 
            self.servers_dir is not None and 
            self.servers_dir.exists() and 
            any(self.servers_dir.glob("*.json")))
```

**Benefits:**
- **Zero Configuration**: Simply adding a server file enables MCP functionality
- **Clean Separation**: MCP configuration is separate from tool configuration
- **Dynamic Loading**: New servers can be added without restarting CODA

### Session and Global Configuration Management

The MCP system implements a sophisticated hierarchical configuration system:

```mermaid
flowchart TD
    A[Global MCP Defaults] -->|Template for new sessions| B[Session MCP Config]
    C[Server Config Files] -->|Base configurations| A
    D[Session Overrides] -->|Temporary changes| B
    E[User Actions] -->|Enable/disable servers| D
    F[Make Global Default] -->|Persist preferences| A
```

**Configuration Hierarchy:**

1. **Server Configurations**: Base server definitions in `~/.coda/.tools/mcp/servers.d/*.json`
2. **Global Defaults**: Default enable/disable states in `global_default_mcp.json
`
3. **Session Overrides**: Session-specific states in `session_{id}_mcp.json`

**Key Features:**
- **Session Isolation**: Each session can have different server states without affecting others
- **Global Defaults**: Users can set preferred server states as system defaults
- **Automatic Fallback**: System gracefully handles missing configuration files
- **State Persistence**: Server states are saved and restored across sessions

## Integration with Tool Management

### Unified Tool Interface

The MCP gateway tool integrates seamlessly with CODA's existing tool system:

1. **Standard Registration**: `mcp_execute` is registered in the tool system like any other tool
2. **Type Classification**: Classified as `TOOL_TYPE_MCP` for proper organization
3. **Enable/Disable**: Can be enabled or disabled like any other tool through `/tools` command
4. **Configuration Persistence**: Settings are saved with other tool configurations

### Dynamic Tool Information

The MCP service generates dynamic tool information for the system prompt:

```python
def prompt_snippet(self) -> str:
    """Generate a markdown snippet describing available MCP tools."""
    # Groups tools by server and generates structured descriptions
    # Example output:
    # Available MCP servers and tools:
    # 
    # **github** server:
    # - `create_issue`: Create a new issue in a GitHub repository
    # - `get_file`: Get file contents from a repository
    # 
    # **filesystem** server:
    # - `read_file`: Read contents of a file
    # - `write_file`: Write content to a file
    # 
    # To use any MCP tool, call the mcp_execute function with server_name and tool_name parameters.
```

## Error Handling and Reliability

### Graceful Degradation

The MCP system is designed to fail gracefully:

- **Missing Dependencies**: If MCP dependencies are unavailable, the system continues without MCP functionality
- **Server Failures**: Individual server failures don't affect other servers or built-in tools
- **Connection Issues**: Network problems are handled with automatic retry logic
- **Invalid Configurations**: Malformed server configurations are logged and skipped

### Error Response Format

All MCP operations return standardized error responses:

```python
{
    "success": False,
    "error": "Detailed error message",
    "result": None,
    "server_name": "github",
    "tool_name": "create_issue"
}
```

### Connection Recovery

The system implements sophisticated connection recovery:

- **Health Monitoring**: Continuous monitoring of connection health
- **Automatic Retry**: Intelligent retry logic for transient failures
- **Connection Refresh**: Automatic reconnection for persistent connection servers
- **Resource Cleanup**: Proper cleanup of failed connections to prevent resource leaks

## Performance Considerations

### Connection Management

- **Lazy Loading**: Servers only connect when first accessed
- **Smart Connection Strategies**: 
  - Persistent connections for stateful servers (STDIO, Playwright)
  - On-demand connections for stateless servers (HTTP APIs)
- **Connection Pooling**: Efficient reuse of HTTP connections
- **Resource Cleanup**: Proper cleanup prevents resource leaks

### Caching Strategy

- **Tool Definition Caching**: Server tool definitions are cached to avoid repeated queries
- **Cache Invalidation**: Intelligent cache invalidation when connections change
- **Connection State Tracking**: Efficient tracking of server connection status

## CLI Integration

The MCP system includes a comprehensive CLI management interface through the `/mcp` command:

**Available Features:**
- **Server Management**: View, add, and remove MCP servers
- **Import/Export**: Claude Desktop configuration compatibility
- **Connection Testing**: Test server connections and tool availability  
- **Status Monitoring**: Real-time status of all configured servers
- **Tool Discovery**: Browse available tools from all servers
- **State Management**: Enable/disable servers for current session or globally

**Interactive Features:**
- **Guided Setup**: Step-by-step server configuration
- **Auto-completion**: Smart JSON input with validation
- **Bulk Operations**: Enable/disable multiple servers at once
- **Configuration Export**: Export configurations for sharing or backup

## Environment Configuration

The MCP module uses several environment variables for configuration:

| Variable | Description | Default |
|----------|-------------|---------|
| `CODA_MCP_SERVERS_DIR` | Directory containing MCP server configurations | `~/.coda/.tools/mcp/servers.d` |
| `CODA_MCP_GLOBAL_DEFAULTS_FILE` | Global defaults configuration file | `~/.coda/.tools/mcp/global_default_mcp.json
` |
| `CODA_MCP_SESSION_CONFIG_DIR` | Directory for session-specific MCP configurations | `~/.coda/.tools/mcp/sessions` |

## Benefits of the Architecture

The current MCP implementation provides significant advantages:

1. **Simplified Agent Interface**: One gateway tool instead of hundreds of individual MCP tool instances
2. **Unified Parameter Structure**: Consistent interface (server_name, tool_name, arguments)
3. **Better Resource Management**: No need to cache hundreds of tool instances  
4. **Modular Architecture**: Clean separation of concerns with functional modules
5. **Advanced Transport Support**: Both STDIO and modern HTTP Streamable transports
6. **Sophisticated Configuration**: Session-based overrides with global defaults
7. **Comprehensive CLI**: Full management interface for all MCP operations
8. **Production Ready**: Robust error handling, connection recovery, and resource management
9. **Standards Compliant**: Full compatibility with MCP specification and Claude Desktop
10. **Performance Optimized**: Smart connection strategies and efficient caching

## Dependencies

The MCP module requires the following external dependency:

- **fastmcp**: The MCP client library that handles the protocol implementation and server communication

This dependency is automatically installed when CODA is installed and is required for MCP functionality to be available.