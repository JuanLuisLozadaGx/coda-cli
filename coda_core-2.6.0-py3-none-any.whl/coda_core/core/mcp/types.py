import time
from dataclasses import dataclass, field
from typing import Any, Dict, Literal, NamedTuple, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from coda_core.core.mcp.client import MCPClient


class ServerValidationResult(NamedTuple):
    """Represents the result of validating an MCP server configuration."""
    success: bool
    message: str
    tool_count: int = 0


ErrorKind = Literal[
    "config",
    "disabled",
    "not_found",
    "connect_failed",
    "reconnect_failed",
    "exception",
]


@dataclass
class ErrorInfo:
    """
    Rich, serializable error details for UI, logs, or tests.

    Attributes:
        kind: Categorical error kind (e.g., connect_failed, disabled).
        message: Human-readable description of the error.
        retryable: Whether the caller may retry automatically.
        timestamp: Unix timestamp when the error was recorded.
        exception_type: Optional exception class name.
        exception_message: Optional exception message string.
        details: Optional structured metadata about the error.
    """

    kind: ErrorKind
    message: str
    retryable: bool = True
    timestamp: float = field(default_factory=lambda: float(time.time()))
    exception_type: Optional[str] = None
    exception_message: Optional[str] = None
    details: Optional[Dict[str, Any]] = None

    @classmethod
    def from_exception(
        cls,
        exc: BaseException,
        retryable: bool = True,
        kind: ErrorKind = "exception",
        details: Optional[Dict[str, Any]] = None,
    ) -> "ErrorInfo":
        return cls(
            kind=kind,
            message=str(exc),
            retryable=retryable,
            exception_type=exc.__class__.__name__,
            exception_message=str(exc),
            details=details,
        )


@dataclass
class ConnectResult:
    """
    Outcome of a single server connection attempt.

    Attributes:
        ok: True when the connection/reconnection succeeded.
        server: Server name the attempt targeted.
        client: The connected MCPClient instance when ok is True.
        error: ErrorInfo describing the failure when ok is False.
    """

    ok: bool
    server: str
    client: Optional["MCPClient"] = None
    error: Optional[ErrorInfo] = None

    @classmethod
    def success(cls, server: str, client: "MCPClient") -> "ConnectResult":
        return cls(ok=True, server=server, client=client)

    @classmethod
    def failure(cls, server: str, error: ErrorInfo) -> "ConnectResult":
        return cls(ok=False, server=server, error=error)
