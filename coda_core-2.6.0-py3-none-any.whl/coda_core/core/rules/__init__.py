"""Public APIs for AGENTS.md rules discovery, migration, and loading."""

from coda_core.core.rules.constants import (
    AGENTS_FILENAME,
    AGENTS_OVERRIDE_FILENAME,
    DEFAULT_MAX_CHARS,
    DEFAULT_MAX_LINES,
    LEGACY_CODARULES_FILENAME,
    RULES_SEPARATOR,
)
from coda_core.core.rules.loader import (
    build_directory_chain,
    discover_agents_md_paths,
    find_rules_file_in_dir,
    find_vcs_root,
    migrate_legacy_codarules,
    read_and_concatenate_files,
    read_user_defined_rules,
    resolve_rules_paths,
)
from coda_core.core.rules.types import (
    DiscoveryMode,
    MigrationEvent,
    MigrationReport,
    RuleDiscoveryResult,
    RulesLoadResult,
    RulesLoadStatus,
)

__all__ = [
    "AGENTS_FILENAME",
    "AGENTS_OVERRIDE_FILENAME",
    "DEFAULT_MAX_CHARS",
    "DEFAULT_MAX_LINES",
    "LEGACY_CODARULES_FILENAME",
    "RULES_SEPARATOR",
    "build_directory_chain",
    "discover_agents_md_paths",
    "find_rules_file_in_dir",
    "find_vcs_root",
    "migrate_legacy_codarules",
    "read_and_concatenate_files",
    "read_user_defined_rules",
    "resolve_rules_paths",
    "DiscoveryMode",
    "MigrationEvent",
    "MigrationReport",
    "RuleDiscoveryResult",
    "RulesLoadResult",
    "RulesLoadStatus",
]
