"""Type definitions for AGENTS.md rule loading and migration."""

from __future__ import annotations

from typing import List, Literal, Optional, TypedDict


RulesLoadStatus = Literal["success", "truncated", "empty", "not_found", "error"]
DiscoveryMode = Literal["single_file", "hierarchical"]


class MigrationEvent(TypedDict):
    """Single migration action performed while handling legacy codarules.md files."""

    directory: str
    action: Literal[
        "renamed",
        "removed_duplicate",
        "merged_and_removed",
        "error",
    ]
    legacy_path: str
    agents_path: str
    message: str


class MigrationReport(TypedDict):
    """Migration summary for a set of scanned directories."""

    events: List[MigrationEvent]
    warnings: List[str]
    error: Optional[str]


class RuleDiscoveryResult(TypedDict):
    """Resolved AGENTS.md paths for an interaction scope."""

    paths: List[str]
    search_dirs: List[str]
    vcs_root: Optional[str]
    vcs_type: Optional[str]


class RulesLoadResult(TypedDict):
    """Final payload returned by rule-loading utilities."""

    content: Optional[str]
    status: RulesLoadStatus
    was_truncated: bool
    char_count: int
    truncated_char_count: int
    line_count: int
    truncated_line_count: int
    path: str
    paths: List[str]
    vcs_root: Optional[str]
    vcs_type: Optional[str]
    discovery_mode: DiscoveryMode
    warnings: List[str]
    error: Optional[str]
