"""Utilities to discover, migrate, and load AGENTS.md user-defined rules."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from loguru import logger

from coda_core.core.rules.constants import (
    AGENTS_FILENAME,
    AGENTS_OVERRIDE_FILENAME,
    DEFAULT_MAX_CHARS,
    DEFAULT_MAX_LINES,
    LEGACY_CODARULES_FILENAME,
    RULES_SEPARATOR,
)
from coda_core.core.rules.types import (
    MigrationEvent,
    MigrationReport,
    RuleDiscoveryResult,
    RulesLoadResult,
)


def _empty_rules_result(path: str = "") -> RulesLoadResult:
    """Build an empty rule-loading result object.

    Args:
        path: Primary path associated with the result.

    Returns:
        A normalized not-found payload with zeroed counters.
    """
    return RulesLoadResult(
        content=None,
        status="not_found",
        was_truncated=False,
        char_count=0,
        truncated_char_count=0,
        line_count=0,
        truncated_line_count=0,
        path=path,
        paths=[],
        vcs_root=None,
        vcs_type=None,
        discovery_mode="single_file",
        warnings=[],
        error=None,
    )


def _empty_migration_report() -> MigrationReport:
    """Build an empty migration report.

    Returns:
        A migration report with no events, warnings, or errors.
    """
    return MigrationReport(
        events=[],
        warnings=[],
        error=None,
    )


def _normalize_for_comparison(content: str) -> str:
    """Normalize rules content before equality checks.

    Args:
        content: Raw file content.

    Returns:
        Content stripped by line-ending whitespace and outer blank lines.
    """
    stripped_lines = [line.rstrip() for line in content.strip().splitlines()]
    return "\n".join(stripped_lines)


def _make_migration_event(
    directory: str,
    action: MigrationEvent["action"],
    legacy_path: str,
    agents_path: str,
    message: str,
) -> MigrationEvent:
    """Create a typed migration event.

    Args:
        directory: Directory where migration happened.
        action: Migration action type.
        legacy_path: Legacy file path (`codarules.md`).
        agents_path: Destination `AGENTS.md` file path.
        message: Human-readable migration message.

    Returns:
        Typed migration event payload.
    """
    return MigrationEvent(
        directory=directory,
        action=action,
        legacy_path=legacy_path,
        agents_path=agents_path,
        message=message,
    )


def _is_legacy_codarules_path(path: str) -> bool:
    """Check whether a path points to a legacy codarules filename.

    Args:
        path: Candidate file path.

    Returns:
        True when the basename matches `codarules.md` (case-insensitive).
    """
    return os.path.basename(path).lower() == LEGACY_CODARULES_FILENAME.lower()


def _line_count(content: str) -> int:
    """Count content lines while preserving trailing newline behavior.

    Args:
        content: Text to analyze.

    Returns:
        Number of lines as interpreted by `splitlines(keepends=True)`.
    """
    if not content:
        return 0
    return len(content.splitlines(keepends=True))


def _collect_candidate_filenames(candidate_filenames: Optional[List[str]] = None) -> List[str]:
    """Resolve filename priority order for rules discovery.

    Args:
        candidate_filenames: Optional explicit filename priority list.

    Returns:
        Ordered list of candidate filenames.
    """
    if candidate_filenames:
        return candidate_filenames
    return [AGENTS_OVERRIDE_FILENAME, AGENTS_FILENAME]


def find_vcs_root(start_path: str) -> Tuple[Optional[str], Optional[str]]:
    """Find the nearest supported VCS root.

    Args:
        start_path: Starting directory for upward traversal.

    Returns:
        Tuple of `(vcs_root, vcs_type)` or `(None, None)` when no VCS root is found.
    """
    current = os.path.abspath(start_path)
    while True:
        git_marker = os.path.join(current, ".git")
        if os.path.exists(git_marker):
            return current, "git"
        parent = os.path.dirname(current)
        if parent == current:
            return None, None
        current = parent


def build_directory_chain(vcs_root: Optional[str], cwd: str) -> List[str]:
    """Build an ordered directory chain from VCS root to a target directory.

    Args:
        vcs_root: Detected VCS root, if available.
        cwd: Directory that defines the end of the chain.

    Returns:
        Ordered list of directories from root to `cwd`.
    """
    cwd_path = Path(cwd).resolve()
    if not vcs_root:
        return [str(cwd_path)]

    vcs_root_path = Path(vcs_root).resolve()

    try:
        rel_path = cwd_path.relative_to(vcs_root_path)
    except ValueError:
        return [str(cwd_path)]

    chain = [str(vcs_root_path)]
    current = vcs_root_path
    for part in rel_path.parts:
        current = current / part
        chain.append(str(current))

    return chain


def _resolve_case_insensitive_file_match(directory: str, filename: str) -> Optional[str]:
    """Resolve a file path in a directory using case-insensitive basename matching.

    Args:
        directory: Directory containing candidate files.
        filename: Canonical filename to match.

    Returns:
        Existing file path with on-disk casing, or None when no match exists.
    """
    canonical_path = os.path.join(directory, filename)
    if os.path.isfile(canonical_path):
        return canonical_path

    target_name = filename.lower()
    try:
        entries = sorted(os.listdir(directory))
    except (FileNotFoundError, NotADirectoryError, PermissionError):
        return None

    for entry_name in entries:
        if entry_name.lower() != target_name:
            continue
        entry_path = os.path.join(directory, entry_name)
        if os.path.isfile(entry_path):
            return entry_path

    return None


def _resolve_existing_file_path(path: str) -> Optional[str]:
    """Resolve an existing file path while tolerating case-only name differences.

    Args:
        path: Absolute or relative file path to resolve.

    Returns:
        Existing file path with on-disk casing, or None if no file exists.
    """
    directory = os.path.dirname(path) or os.getcwd()
    filename = os.path.basename(path)
    if not filename:
        return path if os.path.isfile(path) else None
    return _resolve_case_insensitive_file_match(directory, filename)


def find_rules_file_in_dir(directory: str, candidate_filenames: List[str]) -> Optional[str]:
    """Find the first matching rules file in a directory.

    Args:
        directory: Directory to inspect.
        candidate_filenames: Ordered filename priority list.

    Returns:
        Canonical absolute path using the requested candidate filename casing (for example
        `AGENTS.md`) when a matching on-disk file exists, or None.

        Note:
            On case-sensitive filesystems the returned basename casing may differ from the
            on-disk entry (for example, on disk `Agents.md` vs returned `AGENTS.md`).
            Callers performing file I/O should resolve the concrete existing file path first.
    """
    for filename in candidate_filenames:
        matched_path = _resolve_case_insensitive_file_match(directory, filename)
        if matched_path:
            # Keep canonical casing in metadata and user-facing output.
            return os.path.join(directory, filename)
    return None


def resolve_rules_paths(
    cwd: str,
    candidate_filenames: Optional[List[str]] = None,
) -> RuleDiscoveryResult:
    """Resolve ordered AGENTS.md file paths from VCS root to cwd.

    Args:
        cwd: Base working directory for discovery.
        candidate_filenames: Optional filename priority override.

    Returns:
        Discovery result with resolved paths, search directories, and VCS metadata.
    """
    effective_cwd = os.path.abspath(cwd)
    candidates = _collect_candidate_filenames(candidate_filenames)
    vcs_root, vcs_type = find_vcs_root(effective_cwd)
    search_dirs = build_directory_chain(vcs_root, effective_cwd)

    ordered_paths: List[str] = []
    for directory in search_dirs:
        matched_path = find_rules_file_in_dir(directory, candidates)
        if matched_path:
            ordered_paths.append(matched_path)

    return RuleDiscoveryResult(
        paths=ordered_paths,
        search_dirs=search_dirs,
        vcs_root=vcs_root,
        vcs_type=vcs_type,
    )


def discover_agents_md_paths(
    cwd: Optional[str] = None,
    candidate_filenames: Optional[List[str]] = None,
) -> Dict[str, Optional[str] | List[str]]:
    """Resolve AGENTS.md paths using the legacy discovery payload shape.

    Args:
        cwd: Optional working directory to start discovery from.
        candidate_filenames: Optional filename priority override.

    Returns:
        Backward-compatible discovery payload including `git_root`.
    """
    effective_cwd = os.path.abspath(cwd or os.getcwd())
    discovery = resolve_rules_paths(
        cwd=effective_cwd,
        candidate_filenames=candidate_filenames,
    )
    return {
        "paths": discovery["paths"],
        "vcs_root": discovery["vcs_root"],
        "vcs_type": discovery["vcs_type"],
        "git_root": discovery["vcs_root"] if discovery["vcs_type"] == "git" else None,
        "search_dirs": discovery["search_dirs"],
    }


def migrate_legacy_codarules(search_dirs: List[str]) -> MigrationReport:
    """Migrate legacy `codarules.md` files to `AGENTS.md`.

    Args:
        search_dirs: Directories that should be scanned for legacy files.

    Returns:
        Migration report including events, warnings, and last error.
    """
    report = _empty_migration_report()

    visited = set()
    for directory in search_dirs:
        absolute_directory = os.path.abspath(directory)
        if absolute_directory in visited:
            continue
        visited.add(absolute_directory)

        legacy_path = _resolve_existing_file_path(os.path.join(absolute_directory, LEGACY_CODARULES_FILENAME))
        if not legacy_path:
            continue

        agents_path = os.path.join(absolute_directory, AGENTS_FILENAME)
        existing_agents_path = _resolve_existing_file_path(agents_path)

        try:
            if not existing_agents_path:
                os.replace(legacy_path, agents_path)
                message = f"Migrated legacy codarules.md -> AGENTS.md at {absolute_directory}."
                logger.warning(message)
                report["warnings"].append(message)
                report["events"].append(
                    _make_migration_event(
                        directory=absolute_directory,
                        action="renamed",
                        legacy_path=legacy_path,
                        agents_path=agents_path,
                        message=message,
                    )
                )
                continue

            with open(legacy_path, "r", encoding="utf-8") as legacy_file:
                legacy_content = legacy_file.read()
            with open(existing_agents_path, "r", encoding="utf-8") as agents_file:
                agents_content = agents_file.read()

            normalized_legacy = _normalize_for_comparison(legacy_content)
            normalized_agents = _normalize_for_comparison(agents_content)

            if normalized_legacy == normalized_agents:
                os.remove(legacy_path)
                message = f"Removed duplicate legacy codarules.md at {absolute_directory}."
                logger.warning(message)
                report["warnings"].append(message)
                report["events"].append(
                    _make_migration_event(
                        directory=absolute_directory,
                        action="removed_duplicate",
                        legacy_path=legacy_path,
                        agents_path=agents_path,
                        message=message,
                    )
                )
                continue

            legacy_hash = hashlib.sha256(normalized_legacy.encode("utf-8")).hexdigest()[:12]
            start_marker = f"<!-- CODA-MIGRATED-CODARULES:{legacy_hash} -->"
            end_marker = f"<!-- /CODA-MIGRATED-CODARULES:{legacy_hash} -->"

            if start_marker not in agents_content:
                merged_content = (
                    agents_content.rstrip()
                    + "\n\n"
                    + start_marker
                    + "\n# Migrated from codarules.md\n"
                    + legacy_content.rstrip()
                    + "\n"
                    + end_marker
                    + "\n"
                )
                with open(existing_agents_path, "w", encoding="utf-8") as agents_file:
                    agents_file.write(merged_content)

            os.remove(legacy_path)
            message = f"Merged legacy codarules.md into AGENTS.md and removed legacy file at {absolute_directory}."
            logger.warning(message)
            report["warnings"].append(message)
            report["events"].append(
                _make_migration_event(
                    directory=absolute_directory,
                    action="merged_and_removed",
                    legacy_path=legacy_path,
                    agents_path=agents_path,
                    message=message,
                )
            )
        except Exception as exc:
            message = f"Failed to migrate legacy codarules.md at {absolute_directory}: {exc}"
            logger.error(message)
            report["warnings"].append(message)
            report["events"].append(
                _make_migration_event(
                    directory=absolute_directory,
                    action="error",
                    legacy_path=legacy_path,
                    agents_path=agents_path,
                    message=message,
                )
            )
            report["error"] = str(exc)

    return report


def _read_single_file(path: str, max_chars: int, max_lines: int) -> RulesLoadResult:
    """Load a single explicit rules file with shared truncation logic.

    Args:
        path: Absolute path to the target rules file.
        max_chars: Maximum number of characters to retain.
        max_lines: Maximum number of lines to retain.

    Returns:
        Rules loading result normalized for single-file mode.
    """
    result = read_and_concatenate_files([path], max_chars=max_chars, max_lines=max_lines)
    result["path"] = path
    result["paths"] = [path] if result["status"] != "not_found" else []
    result["discovery_mode"] = "single_file"
    return result


def read_and_concatenate_files(
    file_paths: List[str],
    max_chars: int = DEFAULT_MAX_CHARS,
    max_lines: int = DEFAULT_MAX_LINES,
) -> RulesLoadResult:
    """Read multiple rules files and apply character/line truncation limits.

    Args:
        file_paths: Ordered list of rules file paths.
        max_chars: Maximum combined character count.
        max_lines: Maximum combined line count.

    Returns:
        Result payload containing combined content, metadata, and warnings.
    """
    result = _empty_rules_result(path=file_paths[-1] if file_paths else "")

    parts: List[str] = []
    had_read = False
    had_non_empty_content = False
    truncation_reached = False
    errors: List[str] = []

    separator = RULES_SEPARATOR
    separator_line_count = _line_count(separator)

    for path in file_paths:
        resolved_path = _resolve_existing_file_path(path) or path
        try:
            with open(resolved_path, "r", encoding="utf-8") as file:
                content = file.read()
            had_read = True
        except FileNotFoundError:
            continue
        except Exception as exc:
            error_message = f"Error reading rules file at {path}: {exc}"
            logger.error(error_message)
            errors.append(error_message)
            continue

        if not content.strip():
            continue

        had_non_empty_content = True

        if parts:
            result["char_count"] += len(separator)
            result["line_count"] += separator_line_count

            if (
                result["truncated_char_count"] + len(separator) > max_chars
                or result["truncated_line_count"] + separator_line_count > max_lines
            ):
                truncation_reached = True
                break

            parts.append(separator)
            result["truncated_char_count"] += len(separator)
            result["truncated_line_count"] += separator_line_count

        result["char_count"] += len(content)
        content_lines = content.splitlines(keepends=True)
        result["line_count"] += len(content_lines)

        for line in content_lines:
            next_char_count = result["truncated_char_count"] + len(line)
            next_line_count = result["truncated_line_count"] + 1

            if next_char_count > max_chars or next_line_count > max_lines:
                truncation_reached = True
                break

            parts.append(line)
            result["truncated_char_count"] = next_char_count
            result["truncated_line_count"] = next_line_count

        if truncation_reached:
            break

    if not had_non_empty_content:
        if errors:
            result["status"] = "error"
            result["error"] = errors[-1]
            result["warnings"].extend(errors)
            return result
        if had_read:
            result["status"] = "empty"
            return result
        return result

    combined = "".join(parts)
    result["content"] = combined
    result["truncated_char_count"] = len(combined)
    result["truncated_line_count"] = _line_count(combined)

    if truncation_reached:
        result["status"] = "truncated"
        result["was_truncated"] = True
        logger.warning(
            "User-defined AGENTS rules were truncated "
            f"(loaded_chars={result['truncated_char_count']}, loaded_lines={result['truncated_line_count']}, "
            f"limit_chars={max_chars}, limit_lines={max_lines})."
        )
    else:
        result["status"] = "success"

    if errors:
        result["warnings"].extend(errors)

    return result


def read_user_defined_rules(
    path: Optional[str] = None,
    cwd: Optional[str] = None,
    max_chars: int = DEFAULT_MAX_CHARS,
    max_lines: int = DEFAULT_MAX_LINES,
) -> RulesLoadResult:
    """Load AGENTS.md rules for the current `cwd` hierarchy.

    Args:
        path: Optional explicit rules file path.
        cwd: Optional working directory used for relative resolution.
        max_chars: Maximum loaded character count.
        max_lines: Maximum loaded line count.

    Returns:
        Typed result payload with loaded content and discovery metadata.
    """
    effective_cwd = os.path.abspath(cwd or os.getcwd())

    if path:
        explicit_path = os.path.abspath(path if os.path.isabs(path) else os.path.join(effective_cwd, path))
        migration_report = _empty_migration_report()
        resolved_path = explicit_path

        if _is_legacy_codarules_path(explicit_path):
            migration_report = migrate_legacy_codarules([os.path.dirname(explicit_path) or effective_cwd])
            # Explicit legacy paths are migrated first; then we load only the AGENTS.md destination.
            resolved_path = os.path.join(os.path.dirname(explicit_path), AGENTS_FILENAME)

        result = _read_single_file(resolved_path, max_chars=max_chars, max_lines=max_lines)
        result["warnings"].extend(migration_report["warnings"])

        vcs_root, vcs_type = find_vcs_root(os.path.dirname(resolved_path) or effective_cwd)
        result["vcs_root"] = vcs_root
        result["vcs_type"] = vcs_type

        if migration_report["error"] and not result["error"]:
            result["error"] = migration_report["error"]

        return result

    discovery = resolve_rules_paths(
        cwd=effective_cwd,
        candidate_filenames=None,
    )

    migration_report = migrate_legacy_codarules(discovery["search_dirs"])
    if migration_report["events"]:
        discovery = resolve_rules_paths(
            cwd=effective_cwd,
            candidate_filenames=None,
        )

    result = read_and_concatenate_files(
        file_paths=discovery["paths"],
        max_chars=max_chars,
        max_lines=max_lines,
    )

    if discovery["paths"]:
        result["path"] = discovery["paths"][-1]
    else:
        result["path"] = os.path.join(effective_cwd, AGENTS_FILENAME)

    result["paths"] = discovery["paths"]
    result["vcs_root"] = discovery["vcs_root"]
    result["vcs_type"] = discovery["vcs_type"]
    result["discovery_mode"] = "hierarchical"
    result["warnings"].extend(migration_report["warnings"])

    if migration_report["error"] and not result["error"]:
        result["error"] = migration_report["error"]

    return result
