from typing import Callable

from loguru import logger

from coda_core.core.tools.function_tool import FunctionTool
from coda_core.core.tools.think.description import THINK_TOOL_DESC, THINK_TOOL_SHORT_DESC
from coda_core.core.tools.think.functions import execute_think

class ThinkTool(FunctionTool):
    """
    A tool for processing and documenting thought processes, encapsulating a name, description, and an execution function.

    Attributes:
        name (str): The name of the tool, defaulting to "think".
        description (str): A detailed description of the tool's capabilities.
        short_description (str): A brief description of the tool.
        function (Callable): A callable function that executes the tool's primary action of processing thoughts.
    """
    
    name: str = "think"
    description: str = THINK_TOOL_DESC
    short_description: str = THINK_TOOL_SHORT_DESC
    function: Callable = execute_think

    
    def __init__(self, name: str = name, description: str = description, short_description: str = short_description, function: Callable = function):
        """
        Initialize a ThinkTool instance.

        Args:
            name (str): The name of the tool. Defaults to "think".
            description (str): The description of the tool's functionality.
            short_description (str): A brief description of the tool.
            function (Callable): The function that executes the tool's primary action of processing thoughts.
        """
        super().__init__(name=name, description=description, short_description=short_description, function=function)

        # Log the initialization details
        logger.info(f"Initialized ThinkTool")