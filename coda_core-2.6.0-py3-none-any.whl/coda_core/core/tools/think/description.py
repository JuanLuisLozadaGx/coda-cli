THINK_TOOL_SHORT_DESC = """
A dedicated tool to record intermediate thoughts or brainstorming steps. 
Use it when you need extra space to reason during multi-step tasks, analyze complex tool outputs or creating a plan.
Example use cases: 
- the user requests a plan or you to think
- solve a bug, analyze a traceback
- implement a new complex feature

IMPORTANT: Keep the generation of the think tool brief. You may use bulleted lists, checklist but avoid large outputs.
"""

THINK_TOOL_DESC = """
Use the tool to think about something. 
It will not obtain new information or make any changes to the repository, but just log the thought.
Use it when complex reasoning or brainstorming is needed. 

IMPORTANT: Keep the generation of the think tool brief. You may use bulleted lists, checklist but avoid large outputs.

Example use cases:
- If you explore the repo and discover the source of a bug, 
call this tool to brainstorm several unique ways of fixing the bug, 
and assess which change(s) are likely to be simplest and most effective. 
- If you receive some test results or an error traceback, 
call this tool to brainstorm ways to fix the failing tests.
- If you need to verify if a task finished, call this tool to create a checklist like analysis of the progress.
this will help you understand if the task is finished or you need to continue calling other tools.
"""