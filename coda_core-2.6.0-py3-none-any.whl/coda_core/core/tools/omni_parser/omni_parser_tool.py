from typing import Callable, Optional, Dict, Any, List, Tuple
import copy
from pathlib import Path
import json
import uuid
from datetime import datetime
from loguru import logger

from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.tools.omni_parser.description import OMNI_PARSER_DESC, OMNI_PARSER_SHORT_DESC
from coda_core.core.tools.omni_parser.functions import execute_omni_parser
from coda_core.core.models.providers.geai_client import GEAIClient
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig


class OmniParserTool(FunctionTool):
    name: str = "omni_parser"
    description: str = OMNI_PARSER_DESC
    short_description: str = OMNI_PARSER_SHORT_DESC
    function: Callable = execute_omni_parser

    def __init__(
        self,
        name: str = name,
        description: str = description,
        short_description: str = short_description,
        function: Callable = function,
        client: Optional[GEAIClient] = None,
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            short_description=short_description,
            function=function,
            exclude_params=["client"],
        )
        self.client = client

    def execute(self, **kwargs) -> Dict[str, Any]:
        try:
            self._validate_parameters(execute_omni_parser, kwargs)
            if not self.client:
                raise ValueError("GEAIClient not set for OmniParserTool")
            
            # Filter out reserved arguments before calling the function
            filtered_kwargs = self._filter_reserved_arguments(kwargs)

            # Call the underlying API wrapper
            result = execute_omni_parser(self.client, **filtered_kwargs)

            # If the result is not a dict, just return it as-is
            if not isinstance(result, dict):
                return {"status": "error", "message": "Unexpected response from omni-parser"}

            # If error-shaped response, return directly without saving
            if result.get("status") == "error":
                return result

            # Make a full copy for saving BEFORE mutating for usage extraction
            to_save = copy.deepcopy(result)

            # Extract usage data if available and attach under _usage
            usage_data = result.pop("usage", None)
            usage_copy = None
            if usage_data is not None:
                try:
                    usage_copy = copy.deepcopy(usage_data)
                except Exception:
                    usage_copy = usage_data

            if usage_copy is not None:
                result["_usage"] = usage_copy

            # Compute smallness using total characters in parts[].text (assume text present per tool contract)
            parts: List[Dict[str, Any]] = []
            try:
                if isinstance(result.get("parts"), list):
                    parts = result.get("parts", [])
                elif isinstance(to_save.get("parts"), list):
                    parts = to_save.get("parts", [])
            except Exception:
                parts = []

            def _total_text_chars(items: List[Dict[str, Any]]) -> int:
                total = 0
                for p in items:
                    try:
                        text = p.get("text")
                        if isinstance(text, str):
                            total += len(text)
                    except Exception:
                        continue
                return total

            total_chars = _total_text_chars(parts)

            # Read threshold from env, fallback to 8000
            inline_threshold = int(SETTINGS.get_env_var(EnvConfig.CODA_OMNI_PARSER_INLINE_THRESHOLD_CHARS))

            # Prepare save directory under current working directory
            try:
                cwd = Path.cwd()
            except Exception:
                cwd = Path(".")
            save_dir = cwd / ".coda" / "omni-parser"
            save_dir.mkdir(parents=True, exist_ok=True)

            # Build filename using input file name, timestamp and short id
            input_file: str = kwargs.get("file_path") or "input"
            base_name = Path(input_file).stem or "input"
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            short_id = uuid.uuid4().hex[:8]
            filename = f"{base_name}__{timestamp}__{short_id}.json"
            abs_path = save_dir / filename

            # Save the raw API result to disk (human-readable)
            save_ok = True
            save_error: Optional[str] = None
            try:
                with abs_path.open("w", encoding="utf-8") as f:
                    json.dump(to_save, f, ensure_ascii=False, indent=2)
            except Exception as e:
                save_ok = False
                save_error = str(e)
                logger.exception(f"Failed saving omni-parser result to {abs_path}: {e}")

            # Build metadata summary for the agent
            def _extract_pages(items: List[Dict[str, Any]]) -> Optional[Tuple[int, int]]:
                pages: List[int] = []
                for p in items:
                    try:
                        page = p.get("page")
                        if isinstance(page, int):
                            pages.append(page)
                    except Exception:
                        continue
                if pages:
                    return (min(pages), max(pages))
                return None

            def _extract_time_range(items: List[Dict[str, Any]]) -> Optional[Tuple[Any, Any]]:
                times: List[Any] = []
                for p in items:
                    t = p.get("midTime")
                    if t is not None:
                        times.append(t)
                if times:
                    # Keep original ordering when unsure of type
                    return (times[0], times[-1])
                return None

            pages_detected = _extract_pages(parts)
            time_range = _extract_time_range(parts)

            # Format/mode metadata from kwargs
            hi_res = bool(kwargs.get("hiResMode", False))
            strategy = "hi_res" if hi_res else "auto"
            model_used = "openai/gpt-4o" if hi_res else None
            format_mode = {
                k: v
                for k, v in {
                    "outputFormat": kwargs.get("outputFormat"),
                    "structure": kwargs.get("structure"),
                    "dialogue": kwargs.get("dialogue"),
                    "strategy": strategy,
                    "model": model_used,
                }.items()
                if v is not None
            }

            metadata: Dict[str, Any] = {
                "file_name": Path(input_file).name if input_file else None,
                "parts_count": len(parts),
                "total_text_chars": total_chars,
                "pages_detected": list(pages_detected) if pages_detected else None,
                "time_range": list(time_range) if time_range else None,
                "format_mode": format_mode or None,
            }

            # Assemble the response depending on smallness and save result
            if not save_ok:
                # Fallback: include inline content with a note about save failure
                result["message"] = (
                    f"Omni-parser result could not be saved: {save_error}. "
                    f"Including inline content for immediate use."
                )
                result["metadata"] = metadata
                result["_usage"] = usage_copy if usage_copy is not None else result.get("_usage")
                return result

            # Always include where it was saved
            # Small result → include inline content too
            if total_chars <= inline_threshold:
                result["saved_to"] = str(abs_path)
                result["metadata"] = metadata
                result["message"] = (
                    "Omni-parser result is small; included inline and saved to disk. "
                    f"Path: {abs_path}"
                )
                result["_usage"] = usage_copy if usage_copy is not None else result.get("_usage")
                return result

            # Large result → return a compact summary with path and metadata only
            compact: Dict[str, Any] = {
                "status": "success",
                "message": f"Omni-parser result saved to {abs_path}. Use the view tool to open it.",
                "saved_to": str(abs_path),
                "metadata": metadata,
            }
            if usage_copy is not None:
                compact["_usage"] = usage_copy
            return compact
        except ParameterError as e:
            logger.error(f"Parameter error in {self.name} tool: {e}")
            raise
        except Exception as e:
            logger.exception(f"Error executing function {self.name}: {e}")
            return {"status": "error", "message": str(e)}
