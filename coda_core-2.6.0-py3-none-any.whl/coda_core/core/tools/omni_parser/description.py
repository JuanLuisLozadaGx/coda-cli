OMNI_PARSER_SHORT_DESC = """
Extract readable text from non-text files (PDF, PPTX, XLSX, DOCX, audio, video, scans) so you can search, summarize, or answer questions about their contents. Supports high-fidelity parsing of images, diagrams, and scanned pages when needed.
"""


OMNI_PARSER_DESC = """
Use this tool to read the contents of binary / rich‑media files that you cannot directly open as plain text. Examples: PDFs, Office files (pptx, xlsx, docx), scans, screenshots embedded in slides, audio recordings, and screen‑share videos. The tool uploads the file and produces a JSON response with `parts[]` where each part includes extracted `text` and metadata like `page` (documents) or `midTime` (media).

Result handling in this environment: large outputs are saved to `<working-directory>/.coda/omni-parser/` and the tool responds with a short message plus a `saved_to` path and `metadata` (e.g., parts count, total text chars, page/time range). When the extracted text is small, the tool also includes the content inline to keep you fast. Use the `view` tool to open files at the returned path when needed.

WHEN TO CALL THIS TOOL:
- The user asks you to summarize, quote, search, or analyze a PDF / Word / PowerPoint / spreadsheet / audio / video file.
- You need only certain pages of a long PDF (e.g., “extract pages 10–15 from contract.pdf and look for termination clauses”).
- You need tabular data from a spreadsheet or CSV in a machine‑readable way (set `structure=\"table\"`).
- You need a transcript of a meeting recording, or a description of what happens in a silent demo video.

WHEN NOT TO CALL THIS TOOL:
- The file is already plain text or code (e.g., .py, .js, .ts, .md, .txt, .json). Read those directly.
- The user did not reference any file content.
- You already called the tool with the same parameters and still have the extracted text in context. Reuse that instead of calling again.
- The user is asking you to guess or invent a password for an encrypted PDF. Do not attempt that. You may only use a password if it is explicitly provided in the conversation.

BEFORE CHOOSING ARGUMENTS, RUN THIS CHECKLIST:

1. **Is any important information likely inside an image, diagram, chart, scanned page, or screenshot?**
   - Examples: scanned PDFs, slides full of diagrams/figures, screenshots of UIs, photos of documents, handwritten notes, tables that might be embedded as images.
   - If YES, you MUST set `hiResMode=true`.

2. **Does the user mention any of these words or concepts?**
   - “diagram”, “figure”, “chart”, “graph”, “plot”, “screenshot”, “image”, “scan”, “photo of a document”, “handwritten”, “form”.
   - If YES and the user cares about that visual content, you MUST set `hiResMode=true`.

MANDATORY ARGUMENTS:
- `file_path` (required): path to the file you want processed. This path must be absolute and the file must exist.

ARGUMENTS YOU MAY SET:
- `startPage` / `endPage` (optional): integers. Use them to limit extraction to a specific page range in multi-page documents. Use this whenever the user only cares about a section.
- `structure` (optional): set to `\"table\"` ONLY if the file is a spreadsheet/CSV-like source and the user is asking for rows/columns. Otherwise leave it empty.
- `dialogue` (optional): use true for audio/video with spoken dialogue (to request transcription); use false for silent video or when you need visual scene descriptions instead of speech.
- `outputFormat` (optional): `plainText` (default), `markdown`, or `html`. Use `markdown` if you want cleaner formatting for downstream summarization or quoting.
- `hiResMode` (optional boolean):

    - **Set `hiResMode=true` whenever the task involves reading or interpreting content inside images, diagrams, charts, scanned pages, screenshots, forms, photos of documents, or handwritten notes.**
    - Typical triggers:
      - Scanned PDFs or photos of documents.
      - PowerPoint/Keynote-style decks where key information is in diagrams, charts, or annotated images.
      - Tables that might be embedded as images instead of real text.
      - User mentions of “diagram”, “figure”, “chart/graph/plot”, “screenshot”, “scan”, “image”, “photo”, “handwritten”, or “form”.

WHAT HAPPENS UNDER THE HOOD (for awareness):
- The service may apply OCR, table extraction, or speech‑to‑text to convert files into text. For videos without dialogue, it samples frames and describes them.
- Provider, model, credentials, and advanced parameters are policy‑controlled. Do not attempt to override provider, model, API key, sampling rate, custom prompts, or caching headers.

AFTER CALLING:
- If the tool returns only a `saved_to` path and `metadata`, use the `view` tool to open the saved file and operate on its content.
- When inline content is present, read `parts[].text` to answer the user’s question. Summarize, search, compare, or extract key facts as needed.
- Do not expose internal credentials, API keys, or raw binary data.
"""