import os
from typing import Annotated, Dict, Any, Optional
import requests
from loguru import logger

from coda_core.core.models.providers.geai_client import GEAIClient


OMNI_PARSER_TIMEOUT_SECONDS = 300
OMNI_PARSER_PROCESS_ENDPOINT = "/v1/omni-parser/process"


def _generate_request_data(
    startPage: Optional[int],
    endPage: Optional[int],
    structure: Optional[str],
    dialogue: Optional[bool],
    outputFormat: Optional[str],
    hiResMode: Optional[bool],
    password: Optional[str],
) -> Dict[str, Any]:
    """
    Generate the request data dictionary for the OmniParser API.

    Args:
        startPage (Optional[int]): Start page number.
        endPage (Optional[int]): End page number.
        structure (Optional[str]): Structure type (e.g., "table").
        dialogue (Optional[bool]): Whether to include dialogue.
        outputFormat (Optional[str]): Output format (e.g., "markdown").
        hiResMode (Optional[bool]): Whether to use high-resolution mode.
        password (Optional[str]): Password for the file.

    Returns:
        Dict[str, Any]: The request data dictionary.
    """
    data: Dict[str, Any] = {}

    # Page range
    if startPage is not None:
        data["startPage"] = str(startPage)
    if endPage is not None:
        data["endPage"] = str(endPage)

    # Spreadsheet/table mode
    if structure:
        data["structure"] = structure

    # Media transcription / frame description
    if dialogue is not None:
        # API samples show dialogue as "true"/"false" or 1/0; we'll send "true"/"false"
        data["dialogue"] = str(bool(dialogue)).lower()

    # Output formatting
    if outputFormat:
        data["outputFormat"] = outputFormat

    # Password-protected PDFs
    if password:
        data["password"] = password

    # Vision / OCR strategy
    # strategy:
    #   - auto     (default, cheaper)
    #   - hi_res   (higher cost, needs model)
    #
    # Docs: hi_res requires sending model (e.g. openai/gpt-4o) and is recommended
    # for documents with heavy images/tables/scans. More expensive. We only
    # enable it if hiResMode==True. Otherwise we force "auto".
    if hiResMode:
        data["strategy"] = "hi_res"
        # Controlled internal default model for hi_res. The docs say
        # default for image work is openai/gpt-4o (vision-capable).
        data["model"] = "openai/gpt-4o"
    else:
        data["strategy"] = "auto"

    return data


def execute_omni_parser(
    client: GEAIClient,
    file_path: Annotated[
        str,
        "Absolute path to the local file to parse. Only use this tool for non-plain-text "
        "files (pdf, pptx, docx, xlsx/csv, mp4, mp3, wav, etc.). Do NOT call it for .py, "
        ".js, .ts, .md, .txt, .json because you can read those directly."
    ],
    startPage: Annotated[
        Optional[int],
        "First page number to begin processing from (1-based). Use this to limit scope "
        "when the user only cares about a subsection of a long PDF or DOCX."
    ] = None,
    endPage: Annotated[
        Optional[int],
        "Last page number to process (inclusive). Use 0 to mean 'until the end'. Pair "
        "with startPage for page ranges."
    ] = None,
    structure: Annotated[
        Optional[str],
        'Set to "table" ONLY for spreadsheet/CSV-like sources when the user wants rows/'
        "columns in structured form. Otherwise leave empty."
    ] = None,
    dialogue: Annotated[
        Optional[bool],
        "For audio/video: True -> transcribe spoken dialogue. False -> describe visual "
        "frames instead of speech. Leave unset for normal documents."
    ] = None,
    outputFormat: Annotated[
        Optional[str],
        'Preferred output text format. Allowed: "plainText" (default), "html", '
        '"markdown". Pick "markdown" for nicer bullets/headings if you plan to show '
        "the text to the user."
    ] = None,
    hiResMode: Annotated[
        Optional[bool],
        "Request high-resolution OCR/vision mode for complex scans (slides with charts, "
        "logos, screenshots). This is more expensive. Only set True if the user "
        "explicitly asked for high visual fidelity. Otherwise leave False."
    ] = False,
    password: Annotated[
        Optional[str],
        "Password for password-protected PDFs. ONLY include if the human user explicitly "
        "provided it. DO NOT guess. This field is not exposed to the agent tool schema."
    ] = None,
) -> Dict[str, Any]:
    """
    High-level wrapper for the Globant Enterprise AI omni-parser API.

    This sends the file as multipart/form-data plus a controlled subset of
    parameters. We intentionally expose only 'safe' knobs to the LLM:
      - page range (startPage/endPage)
      - structure='table' for spreadsheets
      - dialogue (audio/video transcription vs frame description)
      - outputFormat (plainText | html | markdown)
      - hiResMode (maps to strategy=hi_res internally, which is more expensive)

    Args:
        client (GEAIClient): The GEAI client instance.
        file_path (str): Absolute path to the local file to parse.
        startPage (Optional[int]): First page number to begin processing from.
        endPage (Optional[int]): Last page number to process.
        structure (Optional[str]): 'table' for spreadsheets, else None.
        dialogue (Optional[bool]): True to transcribe dialogue, False for visual description.
        outputFormat (Optional[str]): 'plainText', 'html', or 'markdown'.
        hiResMode (Optional[bool]): True for high-resolution mode.
        password (Optional[str]): Password for protected PDFs.

    Returns:
        Dict[str, Any]: The API response dictionary.
    """

    # Basic validation
    if not client:
        return {"status": "error", "message": "GEAIClient not set for omni-parser"}

    if not os.path.isabs(file_path) or not os.path.isfile(file_path):
        return {
            "status": "error",
            "message": "file_path must be an existing absolute file path",
        }

    if outputFormat and outputFormat not in {"plainText", "html", "markdown"}:
        return {
            "status": "error",
            "message": (
                "Invalid outputFormat. Allowed: plainText | html | markdown."
            ),
        }

    if structure and structure not in {"table"}:
        return {
            "status": "error",
            "message": 'Invalid structure. Allowed: "table" or empty.',
        }

    # Endpoint
    url = f"{client.base_url}{OMNI_PARSER_PROCESS_ENDPOINT}"
    headers = client._build_request_headers()
    # NOTE: We intentionally do NOT expose or allow caller to override:
    # - provider (default is geai ingestion provider)
    # - model (we choose a safe default below if hiResMode is enabled)
    # - caching headers like X-Saia-Cache-Enabled
    # - frameSamplingRate, mediaPrompt, whisperModel, etc.

    data = _generate_request_data(
        startPage=startPage,
        endPage=endPage,
        structure=structure,
        dialogue=dialogue,
        outputFormat=outputFormat,
        hiResMode=hiResMode,
        password=password,
    )

    try:
        with open(file_path, "rb") as file_handle:
            files = {"file": (os.path.basename(file_path), file_handle)}

            # Fire request
            resp = requests.post(
                url,
                headers=headers,
                files=files,
                data=data,
                timeout=OMNI_PARSER_TIMEOUT_SECONDS,
            )

        # Handle common HTTP issues
        if resp.status_code == 401:
            return {
                "status": "error",
                "message": "Unauthorized: invalid GEAI API token",
            }
        if resp.status_code == 429:
            return {
                "status": "error",
                "message": "Rate limited by provider. Please retry with backoff.",
            }
        if resp.status_code >= 500:
            return {
                "status": "error",
                "message": f"Server error {resp.status_code}: retry later",
            }

        resp.raise_for_status()
        return resp.json()

    except requests.exceptions.RequestException as e:
        logger.exception(f"HTTP error calling omni-parser: {e}")
        return {"status": "error", "message": str(e)}
    except Exception as e:
        logger.exception(f"Unexpected error in execute_omni_parser: {e}")
        return {"status": "error", "message": str(e)}
