from typing import Callable, Dict, Any

from loguru import logger

from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.tools.ask_user.description import ASK_USER_TOOL_DESC, ASK_USER_TOOL_SHORT_DESC
from coda_core.core.tools.ask_user.functions import execute_ask_user

class AskUserTool(FunctionTool):
    """
    A tool for asking the user questions with suggested answers, encapsulating a name, description, and an execution function.

    Attributes:
        name (str): The name of the tool, defaulting to "ask_user".
        description (str): A detailed description of the tool's capabilities.
        short_description (str): A brief description of the tool.
        function (Callable): A callable function that executes the tool's primary action of asking the user a question.
    """
    
    name: str = "ask_user"
    description: str = ASK_USER_TOOL_DESC
    short_description: str = ASK_USER_TOOL_SHORT_DESC
    function: Callable = execute_ask_user

    
    def __init__(self, name: str = name, description: str = description, short_description: str = short_description, function: Callable = function):
        """
        Initialize an AskUserTool instance.

        Args:
            name (str): The name of the tool. Defaults to "ask_user".
            description (str): The description of the tool's functionality.
            short_description (str): A brief description of the tool.
            function (Callable): The function that executes the tool's primary action of asking the user a question.
        """
        super().__init__(name=name, description=description, short_description=short_description, function=function)

        # Log the initialization details
        logger.info(f"Initialized AskUserTool")
    
    
    def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute the ask_user function with validation.

        Args:
            question (str): The question to ask the user.
            suggestions (List[str]): A list of 2-4 suggested answers for the user to choose from.

        Returns:
            Dict[str, Any]: A dictionary containing the status of the operation and the user's response.
            
        Raises:
            ParameterError: If there are issues with the provided parameters.
        """
        try:
            # Validate parameters against the function signature
            self._validate_parameters(execute_ask_user, kwargs)
            
            # Filter out reserved arguments before calling the function
            filtered_kwargs = self._filter_reserved_arguments(kwargs)
            
            # Call the function with the filtered arguments
            return execute_ask_user(**filtered_kwargs)
            
        except ParameterError as e:
            # Log and re-raise parameter errors
            logger.error(f"Parameter error in {self.name} tool: {e}")
            raise
        except Exception as e:
            # Log other exceptions
            logger.exception(f"Error executing function {self.name}: {e}")
            return {"status": "error", "message": str(e)}