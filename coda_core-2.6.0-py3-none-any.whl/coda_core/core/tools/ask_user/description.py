ASK_USER_TOOL_SHORT_DESC = """
Ask the user a question to gather additional information needed to complete the task.
This tool should be used when you encounter ambiguities, need clarification, or require more details to proceed effectively. It should also be used to check plans before executing them, to confirm user preferences, or to validate assumptions made by the agent.
It allows for interactive problem-solving by enabling direct communication with the user.
Use this tool for any and all questions you may have, including follow up questions (you can use this tool many times in a row). Use it judiciously to maintain a balance between gathering necessary information and avoiding excessive back-and-forth.
"""

ASK_USER_TOOL_DESC = """
Ask the user a question and provide 2-4 suggested answers to choose from.

This tool allows the agent to interactively gather information from the user by asking
specific questions with suggested answers. The user can either select one of the provided
suggestions or enter their own custom response.

Parameters:
- question: The question to ask the user. It should be clear and concise, guiding the user to provide the necessary information.
- suggestions: A list of 2-4 suggested answers. These suggestions should be relevant to the question, self-explanatory, and have enough contextual information in order to help the user make a choice. 

Example use cases:
- Asking the user to choose between multiple implementation options
- Confirming user preferences before proceeding with a task
- Gathering specific information needed to complete a task
- Clarifying ambiguities in the user's original request
- Validating plans before execution

The tool will display the question and suggestions to the user, collect their response,
and return it to the agent for further processing.

You MUST use this tool for any and all questions you may have, including follow up questions (you can use this tool many times in a row). No questions should be asked without using this tool.

Use this tool wisely to strike a balance between collecting essential information and minimizing unnecessary back-and-forth communication.
"""