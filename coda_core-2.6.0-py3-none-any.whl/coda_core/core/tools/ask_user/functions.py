from typing import Annotated, Dict, List, Any, Optional
from loguru import logger
from coda_core.core.tools.function_tool import ParameterError


def execute_ask_user(
        question: Annotated[str, "The question to ask the user."],
        suggestions: Annotated[List[str], "A list of 2-4 suggested answers for the user to choose from."],
        actions: Annotated[Optional[Dict[int, str]], "Optional mapping of option indices to direct action triggers"] = None
    ) -> Dict[str, Any]:
    """
    Ask the user a question and provide suggested answers to choose from. 
    This function validates the inputs and returns a status indicating whether the operation was successful.
    
    Args:
        question (str): The question to ask the user.
        suggestions (List[str]): A list of 2-4 suggested answers for the user to choose from.
        actions (Optional[Dict[int, str]]): Optional mapping of option indices to direct action triggers.
        
    Returns:
        Dict[str, Any]: A dictionary containing the status and the user's selected answer.
        
    Raises:
        ParameterError: If there are issues with the provided parameters.
    """
    try:
        # Validate inputs
        if not question or not isinstance(question, str):
            raise ParameterError("Question must be a non-empty string.")
            
        if not suggestions or not isinstance(suggestions, list):
            raise ParameterError("Suggestions must be a non-empty list.")
            
        if len(suggestions) < 2 or len(suggestions) > 4:
            raise ParameterError("Must provide between 2 and 4 suggestions.")
            
        for suggestion in suggestions:
            if not suggestion or not isinstance(suggestion, str):
                raise ParameterError("All suggestions must be non-empty strings.")
        
        # Check for direct action triggers in suggestions
        if not actions:
            actions = {}
            
        if actions:
            logger.info(f"Ask user with direct action triggers: {actions}")
            
        # All checks passed, proceed with asking the user
        result = {"status": "success", "direct_actions": actions}
        return result
        
    except ParameterError:
        # Re-raise parameter errors to be handled by the tool
        raise
    except Exception as e:
        logger.exception(f"Error in ask_user tool: {e}")
        return {"status": "error", "message": str(e)}