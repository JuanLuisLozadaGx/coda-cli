ANALYZE_IMAGES_SHORT_DESC = """
Analyze images uploaded by the user using a vision model.
REQUIRED when user uploads images or mentions viewing/analyzing visual content.
"""

ANALYZE_IMAGES_DESC = """
Analyze images using a vision model by providing complete file paths.

IMPORTANT: This tool MUST be used when:
- The user's message contains image file paths
- The user mentions uploading, showing, or sharing images/screenshots
- You need to understand visual content (charts, diagrams, UI screenshots, etc.)

Use this tool to:
1. Read text content from images, screenshots, and other visual content
2. Understand charts, diagrams, or visual information
3. Analyze code screenshots or technical content
4. Answer questions about visual content
5. Describe what's shown in images

REQUIRED: You MUST always provide complete file paths in the file_paths parameter:
- Use absolute paths: file_paths=["/Users/username/Documents/screenshot.png", "/path/to/diagram.jpg"]
- Use relative paths from workspace: file_paths=["./images/screenshot.png", "../docs/diagram.jpg"]
- Complete paths are required - the tool cannot automatically find images in conversation

Example usage:
- examine_images(query="What's in this image?", file_paths=["/Users/user/Desktop/screenshot.png"])
- examine_images(query="What's the error message?", file_paths=["./debug/error_screenshot.png"])
- examine_images(query="Compare these diagrams", file_paths=["/path/to/diagram1.png", "/path/to/diagram2.jpg"])

To use this tool effectively:
- Always include the file_paths parameter with complete paths to the images
- Be specific in your query about what you want to understand from the images
- Mention specific aspects you want the model to focus on
- Ask follow-up questions if the initial analysis doesn't cover everything
- Ensure file paths are accurate and accessible

NOTE: Do NOT use View or Bash tools to read image files - always use this tool instead.
"""