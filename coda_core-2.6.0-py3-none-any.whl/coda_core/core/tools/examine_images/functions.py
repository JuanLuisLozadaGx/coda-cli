"""
Functions for analyzing images uploaded by the user.
"""

import os
import re
import base64
import mimetypes
import glob
import unicodedata
from typing import Dict, Any, List, Optional, Annotated, Tuple

from loguru import logger

from coda_core.core.models.llms.chat import ChatLLM
from coda_core.core.models.utils import extract_response_text
from coda_core.core.filesystem_ops.utils import extract_file_paths
from coda_core.config.constants import FILE_EXTENSIONS


def _process_file_paths(file_paths: Optional[List[str]]) -> List[str]:
    """
    Validates and prepares file paths for analysis.
    
    Args:
        file_paths: Optional list of file paths to process
        
    Returns:
        List of validated absolute file paths
    """
    files_to_analyze = []
    
    if not file_paths:
        return files_to_analyze
        
    logger.info(f"File paths received: {file_paths}, type: {type(file_paths)}")
    
    # Convert string to list if necessary (for robustness)
    if isinstance(file_paths, str):
        file_paths = extract_file_paths(file_paths)
        
    for file_path in file_paths:
        # Try to find the file by expanding the path and checking if it exists
        expanded_path = os.path.expanduser(file_path)
        
        # Check if file exists
        if os.path.isfile(expanded_path):
            abs_path = os.path.abspath(expanded_path)
            # Verify it's an image file
            ext = os.path.splitext(abs_path)[1].lower()
            if ext in FILE_EXTENSIONS:
                files_to_analyze.append(abs_path)
            else:
                logger.warning(f"File {abs_path} is not a supported image format. Supported: {FILE_EXTENSIONS}")
        else:
            # Try to find the file with glob patterns
            found_files = _find_files_with_glob(expanded_path)
            files_to_analyze.extend(found_files)
    
    # Remove duplicates
    return list(set(files_to_analyze))


def _find_files_with_glob(expanded_path: str) -> List[str]:
    """
    Finds files using pattern matching to handle special characters.
    
    Args:
        expanded_path: The expanded file path to search for
        
    Returns:
        List of found file paths
    """
    found_files = []
    
    # Normalize Unicode characters and try different patterns
    normalized_path = unicodedata.normalize('NFKC', expanded_path)
    
    # Try the normalized path first
    if os.path.isfile(normalized_path):
        abs_path = os.path.abspath(normalized_path)
        ext = os.path.splitext(abs_path)[1].lower()
        if ext in FILE_EXTENSIONS:
            found_files.append(abs_path)
            return found_files
    
    # Try glob pattern matching for the directory and filename
    dir_path = os.path.dirname(expanded_path)
    filename = os.path.basename(expanded_path)
    
    # Create a pattern by replacing special characters with wildcards
    pattern_filename = filename.replace(' ', '*').replace('\u202f', '*').replace('\u00a0', '*')
    pattern = os.path.join(dir_path, pattern_filename)
    
    matches = glob.glob(pattern)
    
    for match in matches:
        if os.path.isfile(match):
            abs_path = os.path.abspath(match)
            ext = os.path.splitext(abs_path)[1].lower()
            if ext in FILE_EXTENSIONS:
                found_files.append(abs_path)
                logger.info(f"Found file using pattern matching: {match}")
                break
    
    if not found_files:
        logger.warning(f"File not found: {expanded_path}")
    
    return found_files



def _prepare_image_data(query: str, files_to_analyze: List[str]) -> Tuple[List[Dict[str, Any]], List[str]]:
    """
    Encodes images and prepares the request payload.
    
    Args:
        query: The user's query about the images
        files_to_analyze: List of file paths to process
        
    Returns:
        Tuple of (content_segments, examined_files)
    """
    # Prepare the message with images
    content_segments = [{"type": "text", "text": query}]
    
    # Process each media file
    examined_files = []
    for file_path in files_to_analyze:
        try:
            if not os.path.exists(file_path):
                logger.warning(f"Media asset file not found: {file_path}")
                continue

            mime, _ = mimetypes.guess_type(file_path)
            if not mime:
                mime = "application/octet-stream"

            # Only support image files
            if mime.startswith("image/"):
                with open(file_path, "rb") as f:
                    b64 = base64.b64encode(f.read()).decode("utf-8")
                data_url = f"data:{mime};base64,{b64}"
                content_segments.append({"type": "image_url", "image_url": {"url": data_url}})
                filename = os.path.basename(file_path)
                logger.info(f"Added image to analysis request: {filename}")
                examined_files.append(filename)
            else:
                # Unsupported file type
                continue

        except Exception as e:
            logger.exception(f"Failed to process file {file_path}: {e}")
            content_segments.append({"type": "text", "text": f"[Error reading file {os.path.basename(file_path)}]"})

    return content_segments, examined_files


def _send_request_to_vision_model(vision_llm: ChatLLM, metadata: Optional[Dict[str, Any]], content_segments: List[Dict[str, Any]]) -> Dict[str, Any]:  
    """
    Sends the request and processes the response.
    
    Args:
        vision_llm: The initialized vision model
        metadata: Optional metadata dictionary to pass to GEAI.
        content_segments: The prepared content segments including images
        
    Returns:
        Dictionary containing the analysis results
    """
    try:
        messages = [{"role": "user", "content": content_segments}]
        response = vision_llm.generate_response(messages=messages, metadata=metadata)
        
        analysis = extract_response_text(response)

        if analysis is None:
            return {"status": "error", "message": "Failed to get a valid response from the vision model"}

        # Extract usage data from response
        usage = getattr(response, "usage", None)

        # Include model information and status - leave usage object as is
        # The ExamineImagesTool class will handle converting it to a serializable format
        return {
            "status": "success",
            "analysis": analysis,
            "usage": usage  # Pass the raw usage object
        }
            
    except Exception as e:
        logger.exception(f"Error in vision model request: {e}")
        return {"status": "error", "message": f"Failed to analyze images: {str(e)}"}


def examine_images(
    llm: ChatLLM,
    query: Annotated[str, "The specific question or request about the images"],
    file_paths: Annotated[List[str], "List of image file paths to analyze. Can be absolute paths, relative paths, or filenames."],
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Analyze images using a vision model.
    
    Args:
        llm: The ChatLLM instance configured for vision tasks
        metadata: Optional metadata dictionary to pass to GEAI.
        query: The specific query or request to analyze the images
        file_paths: List of image file paths to analyze. Can be absolute paths,
                 relative paths, or filenames.
        
    Returns:
        Dict with analysis results from the vision model
    """
    if not llm:
        return {"status": "error", "message": "LLM not available"}
    
    # Validate that file_paths is provided and not empty
    if not file_paths:
        return {"status": "error", "message": "file_paths parameter is required and cannot be empty"}
    
    # Process file paths
    files_to_analyze = _process_file_paths(file_paths)
    
    # If no valid images were found
    if not files_to_analyze:
        return {"status": "error", "message": f"No valid images found in the provided paths: {file_paths}"}
    
    # Prepare image data
    content_segments, examined_files = _prepare_image_data(query, files_to_analyze)
    
    # If no valid images were found after processing
    if not examined_files:
        return {"status": "error", "message": "No valid images found in the conversation"}
    
    # Send request to vision model
    return _send_request_to_vision_model(llm, metadata, content_segments)
