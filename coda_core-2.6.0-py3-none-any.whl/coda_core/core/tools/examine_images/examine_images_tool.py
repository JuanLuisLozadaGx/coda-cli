"""
Tool for analyzing images that have been uploaded to the session.
"""

from typing import Callable, Dict, Any, Optional, TYPE_CHECKING
import copy

from loguru import logger

from coda_core.core.tools.function_tool import FunctionTool
from coda_core.core.tools.examine_images.description import ANALYZE_IMAGES_DESC, ANALYZE_IMAGES_SHORT_DESC
from coda_core.core.tools.examine_images.functions import examine_images
from coda_core.core.models.llms.chat import ChatLLM
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig

if TYPE_CHECKING:
    from coda_core.core.models.providers.geai_client import GEAIClient


class ExamineImagesTool(FunctionTool):
    """
    A tool for analyzing images uploaded by users using vision models.
    
    Attributes:
        name (str): The name of the tool, defaulting to "examine_images".
        description (str): A detailed description of the tool's capabilities.
        short_description (str): A brief description of the tool.
        function (Callable): A callable function that executes the analysis.
    """
    
    name: str = "examine_images"
    description: str = ANALYZE_IMAGES_DESC
    short_description: str = ANALYZE_IMAGES_SHORT_DESC
    function: Callable = examine_images
    
    
    def __init__(
        self, 
        name: str = name, 
        description: str = description, 
        short_description: str = short_description, 
        function: Callable = function,
        client: Optional['GEAIClient'] = None,
        model_provider: str = None,
        model_name: str = None
    ):
        """
        Initialize an ExamineImagesTool instance.

        Args:
            name (str): The name of the tool.
            description (str): The description of the tool's functionality.
            short_description (str): A brief description of the tool.
            function (Callable): The function that executes the analysis.
            client (GEAIClient, optional): The GEAI client for making API calls.
            model_provider (str, optional): The vision model provider to use.
            model_name (str, optional): The vision model name to use.
        """
        super().__init__(
            name=name, 
            description=description, 
            short_description=short_description, 
            function=function,
        )
        
        # Initialize with provided dependencies
        self.client = client
        self.model_provider = model_provider
        self.model_name = model_name
        
        
    def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute the examine_images function with the provided arguments.
        
        Args:
            **kwargs: Arguments to pass to the function
            
        Returns:
            Dict[str, Any]: The result of the analysis
        """
        try:
            self._validate_parameters(examine_images, kwargs)
            if not self.client:
                raise ValueError("GEAIClient not set for ExamineImagesTool")
            
            # Get model settings with fallbacks to environment variables
            provider = self.model_provider or SETTINGS.get_env_var(EnvConfig.CODA_VISION_MODEL_PROVIDER)
            model = self.model_name or SETTINGS.get_env_var(EnvConfig.CODA_VISION_MODEL_NAME)
            
            # Check if we have valid model settings
            if not provider or not model:
                raise ValueError("Vision model not configured. Please set CODA_VISION_MODEL_PROVIDER and CODA_VISION_MODEL_NAME environment variables.")
            
            # Create a dedicated ChatLLM instance specifically for this vision request
            # This ensures complete isolation from the agent's main LLM
            vision_llm = ChatLLM(
                client=self.client,
                provider_name=provider,
                model_name=model,
                # No system prompt - we want the raw vision capabilities
                system_prompt=None,
                # Use empty params to avoid inheriting any settings
                params={}
            )
            
            # Clean up parameters - remove max_tokens if present as it's handled by ChatLLM
            if "max_tokens" in kwargs:
                kwargs.pop("max_tokens")
                
            metadata = None
            if "metadata" in kwargs:
                metadata = kwargs.pop("metadata")

            result = examine_images(vision_llm, metadata=metadata, **kwargs)
            
            # Process the result - extract usage data if available following WebSearchTool pattern
            usage_data = result.pop("usage", None) if isinstance(result, dict) else None
            
            # Create a copy of the usage data to avoid mutation issues
            if usage_data:
                try:
                    usage_copy = copy.deepcopy(usage_data)
                    # Add usage data to the result with special key
                    result["_usage"] = usage_copy
                except Exception as e:
                    logger.error(f"Error processing examine images usage: {e}")
            
            return result
            
        except Exception as e:
            logger.exception(f"Error executing {self.name}: {e}")
            return {"status": "error", "message": str(e)}
