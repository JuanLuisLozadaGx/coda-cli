# Bash command risk levels
RISK_LEVEL_SAFE = "safe"
RISK_LEVEL_LOW = "low"
RISK_LEVEL_MEDIUM = "medium"
RISK_LEVEL_HIGH = "high"
RISK_LEVEL_CRITICAL = "critical"

# Bash command risk assessment configuration - Used for Windows
BASH_RISK_CONFIG_WIN = {
    # Commands considered high risk with explanations
    'high_risk_commands': {
        "del": "File removal command that can delete important files",
        "rmdir": "Removes directories, can delete important directories",
        "diskpart": "Disk partitioning command",
        "Restart-Computer": "Restarts the system",
        "runas": "Runs a program as another user",
        "takeown": "Takes ownership of a file",
        "icacls": "Changes file permissions",
        "move": "Move command that can overwrite destinations",
        "sc": "Retrieves and sets control information about services",
        "wsl": "Windows Subsystem for Linux initialization",
        "net": "Network, user accounts, and system services management",
        "format": "Formats storage devices",
        "shutdown": "Shuts down the system",
    },
    
    # Commands considered medium risk with explanations
    'medium_risk_commands': {
        "mountvol": "Creates, deletes, or lists volume mount points",
        "Invoke-WebRequest": "Gets content from a web page",
        "robocopy": "Powerful command to copy file data from one location to another",
        "xcopy": "Copies files and directories, including subdirectories",
        "winget": "Package manager for Windows",
        "choco": "Package manager for Windows",
        "Compress-Archive": "Compresses files",
        "Expand-Archive": "Extracts compressed files",
        "curl": "Transfers data from or to a server",
        "ssh": "Secure shell for remote access",
        "scp": "Secure copy between hosts",
        "git": "Version control system",
        "npm": "Node.js package manager",
        "pip": "Python package installer",
        "mount": "Mounts a filesystem",
        "kill": "Terminates processes",
        "tar": "Tape archive utility",
    },
    
    # Paths considered sensitive
    'sensitive_paths': [
        "C:\\Windows", "C:\\Program Files", "C:\\",
        "C:\\Drivers", "C:\\cygwin64", "C:\\cygwin",
        "C:\\ProgramData"
    ],
    
    # Patterns that indicate potential risk, with associated scores
    'dangerous_patterns': {
        r'del\s+/f\s+/q\s+/s': 10,              # Force, quiet, recursive delete (CMD)
        r'del\s+/f': 7,                         # Force delete (CMD)
        r'del\s+/s': 7,                         # Recursive delete (CMD)
        r'rmdir\s+/s\s+/q': 10,                 # Remove directory tree quietly (CMD)
        r'rmdir\s+/s': 7,                       # Remove directory tree (CMD)
        r'diskpart\s+/s': 9,                    # Diskpart script execution (CMD)
        r'format\s+[a-zA-Z]:': 10,              # Format drive (CMD)
        r'rd\s+/s\s+/q': 10,                    # Remove directory tree quietly (CMD)
        r'Restart-Computer': 10,                # PowerShell restart
        r'Stop-Computer': 8,                    # PowerShell shutdown
        r'Invoke-Expression': 9,                # PowerShell command execution
        r'Invoke-Command': 8,                   # PowerShell remote command
        r'icacls\s+.*\s+/reset': 7,             # Reset permissions (CMD)
        r'takeown\s+/f': 7,                     # Take ownership (CMD)
        r'net\s+user\s+\w+\s+/delete': 8,       # Delete user account (CMD)
        r'echo\s+.*\s*>\s*[a-zA-Z]:\\': 6,      # Overwrite file in root (CMD)
        r'copy\s+/y': 5,                        # Overwrite files without prompt (CMD)
        r'runas\s+/user:': 7,                   # Run as another user (CMD)
        r'PowerShell\s+-Command\s+".*\|.*"': 8, # Piping in PowerShell
        r'Set-ExecutionPolicy': 7,              # Changes PowerShell script execution policy
        r'[;&|](?:\s*$|\s+[^-])': 5,            # Command chaining
        r'>.*': 6,                              # Output redirection
        r'<.*': 4,                              # Input redirection
        r'\\x[0-9a-fA-F]{2}': 8,                # Hex encoding
    },
    
    # Patterns that indicate critical risk with explanations
    'critical_risk_patterns': {
        r'del\s+/f\s+/q\s+/s\s+C:\\': "Attempts to recursively and forcefully delete all files from C:\\ (root drive)",
        r'del\s+/f\s+/q\s+/s\s+C:\\Users\\\w+': "Recursively deletes a user's home directory",
        r'rmdir\s+/s\s+/q\s+C:\\': "Recursively deletes all directories from C:\\ (root drive)",
        r'rmdir\s+/s\s+/q\s+C:\\Users\\\w+': "Recursively deletes a user's home directory",
        r'rd\s+/s\s+/q\s+C:\\': "Recursively deletes all directories from C:\\ (root drive)",
        r'rd\s+/s\s+/q\s+C:\\Users\\\w+': "Recursively deletes a user's home directory",
        r'format\s+[a-zA-Z]:\s+/q\s+/fs:\w+': "Formats a disk drive",
        r'diskpart\s+/s\s+\w+\.txt': "Runs a diskpart script, can repartition/format disks",
        r'echo\s+.*\s*>\s+C:\\Windows\\': "Overwrites critical system files",
        r'Invoke-WebRequest\s+.*\|\s*Invoke-Expression': "Executes code directly from the internet (PowerShell)",
        r'PowerShell\s+-Command\s+".*\|\s*Invoke-Expression"': "Executes code directly from the internet (PowerShell)",
        r'for\s+/l\s+%i\s+in.*do\s+start\s+cmd': "Fork bomb in CMD (spawns infinite processes)",
    }    
}

# Bash command risk assessment configuration - Used for Linux/UNIX/macOS
BASH_RISK_CONFIG_UNIX = {
    # Commands considered high risk with explanations
    'high_risk_commands': {
        "rm": "File removal command that can delete important files",
        "mkfs": "Creates a filesystem and can format drives",
        "dd": "Low-level copy tool that can overwrite disk data",
        "reboot": "Restarts the system",
        "halt": "Halts the system",
        "sudo": "Executes command with superuser privileges",
        "su": "Switches to another user, often root",
        "chown": "Changes file ownership",
        "chmod": "Changes file permissions",
        "mv": "Move command that can overwrite destinations",
        "fdisk": "Partition table manipulator for disk management",
        "systemctl": "Controls the systemd system and service manager",
        "service": "Runs a System V init script",
        "format": "Formats storage devices",
        "shutdown": "Shuts down the system",
    },
    
    # Commands considered medium risk with explanations
    'medium_risk_commands': {
        "wget": "Downloads files from the internet",
        "rsync": "Remote file synchronization",
        "apt": "Advanced Package Tool for Debian/Ubuntu",
        "yum": "Yellowdog Updater Modified for RPM-based systems",
        "brew": "Package manager for macOS",
        "umount": "Unmounts a filesystem",
        "zip": "Compresses files",
        "unzip": "Extracts compressed files",
        "curl": "Transfers data from or to a server",
        "ssh": "Secure shell for remote access",
        "scp": "Secure copy between hosts",
        "git": "Version control system",
        "npm": "Node.js package manager",
        "pip": "Python package installer",
        "mount": "Mounts a filesystem",
        "kill": "Terminates processes",
        "tar": "Tape archive utility",
    },
    
    # Paths considered sensitive
    'sensitive_paths': [
        "/etc", "/var", "/usr", "/bin", "/sbin", 
        "/boot", "/root", "/home", "/dev", "/proc",
    ],
    
    # Patterns that indicate potential risk, with associated scores
    'dangerous_patterns': {
        r'`.*`': 7,                             # Command substitution with backticks
        r'\$\(.*\)': 7,                         # Command substitution with $()
        r'\$\{.*:.*\}': 5,                      # Parameter expansion
        r'-rf\s+/': 10,                         # Recursive force delete from root
        r'--delete': 7,                         # Delete flag in commands like rsync
        r'-O-\s+\|\s+bash': 9,                  # Piping to bash (common in curl/wget exploits)
        r'[;&|](?:\s*$|\s+[^-])': 5,            # Command chaining
        r'>.*': 6,                              # Output redirection
        r'<.*': 4,                              # Input redirection
        r'\\x[0-9a-fA-F]{2}': 8,                # Hex encoding
    },
    
    # Patterns that indicate critical risk with explanations
    'critical_risk_patterns': {
        r'rm\s+-rf\s+/': "Attempts to recursively delete the root filesystem",
        r'rm\s+-rf\s+/\*': "Attempts to recursively delete all files from root",
        r'rm\s+-rf\s+~': "Recursively deletes the user's home directory",
        r'rm\s+-rf\s+\.': "Recursively deletes the current directory",
        r':\(\)\{\s+:\|\:\&\s+\};:': "Fork bomb that can crash the system",
        r'>\s+/dev/sd[a-z]': "Writes to a raw disk device, potentially corrupting it",
        r'dd\s+if=/dev/zero\s+of=/dev/sd[a-z]': "Overwrites a disk device with zeros",
        r'mkfs\.[a-z0-9]+\s+/dev/sd[a-z]': "Formats a disk device",
        r'curl\s+.*\|\s*(?:ba)?sh': "Executes code directly from the internet",
        r'wget\s+.*\s+-O-\s*\|\s*(?:ba)?sh': "Executes code directly from the internet",
    }
}

# Risk level thresholds. Shared between operating systems.
THRESHOLDS = {
    'low': 3,   # Maximum score for low risk
    'high': 8   # Minimum score for high risk
}

# Update shared thresholds
BASH_RISK_CONFIG_UNIX['thresholds'] = THRESHOLDS
BASH_RISK_CONFIG_WIN['thresholds'] = THRESHOLDS

# Tool type constants
TOOL_TYPE_BASIC = "basic"                   # Essential tools that can't be disabled
TOOL_TYPE_EXTENDED = "extended"             # System tools that can be disabled
TOOL_TYPE_EXPERIMENTAL = "experimental"     # Disabled by default, can be enabled
TOOL_TYPE_MCP = "mcp"
TOOL_TYPE_USER_DEFINED = "user_defined"
TOOL_TYPE_PLUGINS = "plugins"

# All valid tool types
TOOL_TYPES = [
    TOOL_TYPE_BASIC,
    TOOL_TYPE_EXTENDED,
    TOOL_TYPE_EXPERIMENTAL,
    TOOL_TYPE_MCP,
    TOOL_TYPE_USER_DEFINED,
    TOOL_TYPE_PLUGINS
]

# Tool category constants (functional categories)
TOOL_CATEGORY_SYSTEM = "system"
TOOL_CATEGORY_FILE_OPERATIONS = "file_operations"
TOOL_CATEGORY_REASONING = "reasoning"
TOOL_CATEGORY_EXTERNAL = "external"
TOOL_CATEGORY_UNKNOWN = "unknown"

# All valid tool categories
TOOL_CATEGORIES = [
    TOOL_CATEGORY_SYSTEM,
    TOOL_CATEGORY_FILE_OPERATIONS,
    TOOL_CATEGORY_REASONING,
    TOOL_CATEGORY_EXTERNAL,
    TOOL_CATEGORY_UNKNOWN
]

# Tools that require the GEAI client dependency to be injected
GEAI_CLIENT_DEPENDENT_TOOLS = ["web_search", "examine_images", "omni_parser"]

# Web Search default models
WEB_SEARCH_DEFAULT_PROVIDER = "openai"
WEB_SEARCH_DEFAULT_MODEL = "gpt-5.4"
