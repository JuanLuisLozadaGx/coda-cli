# Tools Module

## Overview

The Tools Module provides a flexible framework for defining and executing tools that enable agents to interact with the system and external environment. Tools are the primary way for AI agents to perform actions, such as:

- Executing shell commands
- Viewing and editing files
- Searching for information
- Processing and analyzing data
- Thinking and reasoning about complex problems
- Analyzing uploaded images
- Accessing external services via MCP (Model Context Protocol)

This module is designed with extensibility in mind, allowing for easy creation of new tools while providing a consistent interface for all tools.

## Architecture

The Tools Module is built around a hierarchical class structure that enables consistent tool definition and execution:

```mermaid
classDiagram
    class Tool {
        <<abstract>>
        +name: str
        +description: str
        +short_description: str
        +execute()**
    }
    
    class FunctionTool {
        +function: Callable
        +_generate_parameters()
        +_generate_tool_definition()
        +execute()
    }
    
    Tool <|-- FunctionTool
    FunctionTool <|-- AskUserTool
    FunctionTool <|-- BashTool
    FunctionTool <|-- EditTool
    FunctionTool <|-- ReplaceTool
    FunctionTool <|-- ThinkTool
    FunctionTool <|-- ViewTool
    FunctionTool <|-- ExamineImagesTool
    FunctionTool <|-- MCPExecuteTool
```

The tool execution flow follows a standard pattern:

```mermaid
sequenceDiagram
    participant Agent
    participant Tool
    participant Function
    
    Note over Agent,Tool: Tool instances provided during initialization
    
    Agent->>Tool: execute(parameters)
    Tool->>Tool: Validate parameters
    Tool->>Function: Call wrapped function
    Function-->>Tool: Return result
    Tool-->>Agent: Return formatted result
```

## Core Components

### Tool Management System

The Tools Module includes a comprehensive tool management system consisting of two main components:

```mermaid
classDiagram
    class ToolRegistry {
        +register_tool_class()
        +unregister_tool()
        +get_tool()
        +register_dependency()
        +register_tool_dependency()
    }
    
    class ToolManager {
        +config_id: str
        +registry: ToolRegistry
        +config: Dict
        +register_tool()
        +unregister_tool()
        +disable_tool()
        +enable_tool()
        +get_enabled_tools()
        +get_enabled_tool_names()
        +register_default_tools()
        +load_tools_from_config()
        +save_current_config_as_default()
        +reset_global_default_config()
        +has_global_default_config()
        +load_global_default_config()
    }
    
    ToolManager --> ToolRegistry
```

The ToolManager manages both global default configurations and session-specific configurations:

- **Global Default Configuration**: Serves as a template for new sessions, stored in `global_default_tools.json`
- **Session-specific Configuration**: Unique to each session, stored in `{config_id}_tools.json`

This hierarchical approach allows system-wide defaults while maintaining session-specific customizations.

#### ToolRegistry

The `ToolRegistry` class serves as a centralized registry for tool classes and their dependencies:

```mermaid
classDiagram
    class ToolRegistry {
        -tool_classes: Dict[str, Type[Tool]]
        -dependencies: Dict[str, Any]
        -tool_dependencies: Dict[str, Dict[str, str]]
        +register_tool_class(name, tool_class)
        +unregister_tool(name)
        +get_tool(name, **kwargs)
        +register_dependency(name, dependency)
        +register_tool_dependency(tool_name, param_name, dependency_name)
    }
```

**Key Features:**

- **Centralized Registration**: Maintains a registry of tool classes by name, providing a single source of truth for available tools
- **Tool Class Management**: Stores tool class definitions rather than instances, allowing for dynamic instantiation
- **Dependency Injection**: Automatically injects dependencies when instantiating tools
  - Global dependencies: Available to all tools
  - Tool-specific dependencies: Mapped to specific parameters of specific tools
- **Lazy Instantiation**: Tools are only instantiated when needed, improving performance
- **Dynamic Tool Discovery**: Tools can be registered at runtime from various parts of the application
- **Singleton Pattern**: Ensures consistent access to tools across the system

**Registration Process:**
1. Tool classes are registered with a unique name
2. Dependencies are registered separately with their own names
3. Tool-specific dependencies are mapped to specific parameter names
4. When a tool is requested, the registry:
   - Retrieves the tool class from the registry
   - Identifies required dependencies
   - Injects dependencies into the constructor
   - Returns the instantiated tool

**Example Usage:**
```python
# Register a tool class
registry.register_tool_class("edit", EditTool)

# Register a dependency
registry.register_dependency("file_editor", FileEditor())

# Map the dependency to a specific parameter
registry.register_tool_dependency("edit", "editor", "file_editor")

# Get an instantiated tool with dependencies injected
edit_tool = registry.get_tool("edit")  # FileEditor is automatically injected
```

#### ToolManager

The `ToolManager` class manages tool configuration, state, and lifecycle:

```mermaid
classDiagram
    class ToolManager {
        -config_id: str
        -registry: ToolRegistry
        -config: Dict
        -config_path: Path
        -_dirty: bool
        +register_tool(name, tool_class, tool_type, category)
        +unregister_tool(name)
        +disable_tool(name)
        +enable_tool(name)
        +get_enabled_tools()
        +get_enabled_tool_names()
        +register_default_tools()
        +load_tools_from_config()
        +save_config()
        +save_current_config_as_default()
        +reset_global_default_config()
        +has_global_default_config()
        +load_global_default_config()
    }
    
    ToolManager --> ToolRegistry: uses
```

**Key Features:**

- **Configuration Management**: Maintains a configuration of tools with their enabled status, type, and category
- **Tool Lifecycle Management**: Provides methods for enabling, disabling, registering, and unregistering tools
- **Persistence**: Saves and loads tool configuration from JSON files in the `CODA_TOOLS_DIR_PATH` directory
- **Tool Protection**: Prevents basic tools (type BASIC) from being disabled or removed
- **Batch Operations**: Optimizes configuration saving for batch operations with a dirty flag
- **Tool Categorization**: Organizes tools by type (BASIC, EXTENDED, EXPERIMENTAL, MCP) and category (SYSTEM, FILE_OPERATIONS, etc.)
- **Dependency Management**: Works with ToolRegistry to ensure proper dependency injection
- **Configuration Isolation**: Uses a unique config_id to maintain separate configurations for different components
- **Global Configuration**: Manages global default configurations that serve as templates for new sessions

#### Global Configuration Management

The ToolManager includes a global configuration system that provides consistent defaults across sessions:

```mermaid
flowchart TD
    A[System Default Configs] -->|Fallback if no global config| B[New Session Config]
    C[Global Default Config] -->|Primary template for| B
    B -->|Stored as| D[Session-specific Config]
    E[User Customization] -->|Modifies| D
    F[Save as Default] -->|Updates| C
```

**Global Configuration Features:**

- **Consistent Defaults**: Provides a consistent starting point for all new sessions
- **User Customization**: Allows users to save their preferred tool configurations as the global default
- **Configuration Inheritance**: New sessions inherit from the global default, but can be customized independently
- **Additive Merging**: When system defaults change, new tools are automatically merged with existing global configurations
- **File Persistence**: Global configuration is stored in `global_default_tools.json` in the `CODA_TOOLS_DIR_PATH` directory

**Configuration Loading Priority:**

1. Try to load the global default configuration
2. If global default exists, merge it with any new tools from system defaults
3. If no global default exists, fall back to system defaults

**Global Configuration Methods:**

- `save_current_config_as_default()`: Saves the current session's tool configuration as the global default
- `reset_global_default_config()`: Resets the global default to system defaults
- `has_global_default_config()`: Checks if a global default configuration exists
- `load_global_default_config()`: Loads the global default configuration

**Tool Lifecycle:**
1. **Registration**: Tools are registered with a name, class, type, and category
   - Basic tools are registered during initialization and cannot be disabled
   - Extended tools can be registered later and can be enabled/disabled
   - Experimental tools are clearly marked and can be enabled/disabled
   - MCP tools are managed through the centralized gateway tool
2. **Configuration**: Tool status (enabled/disabled) is stored in the configuration
3. **Instantiation**: When enabled tools are requested, they are instantiated via the ToolRegistry
4. **Usage**: Instantiated tools are provided to components that need them (e.g., agents)
5. **Persistence**: Configuration changes are saved to disk for persistence across sessions

**Session Integration:**

The global configuration system integrates with the session system:
- Each session has its own tool configuration with a unique config_id
- When a new session is created, it inherits from the global default configuration
- The session's tool configuration is serialized with the session
- When a session is loaded, its tool configuration is restored using the saved config_id

**Configuration Format:**
```json
{
  "metadata": {
    "last_modified": "2025-06-05T11:25:06.973000+00:00",
    "managed_by": "coda-core"
  },
  "tools": {
    "basic": {
      "bash": {
        "enabled": true,
        "category": "system"
      },
      "edit": {
        "enabled": true,
        "category": "file_operations"
      }
    },
    "extended": {
      "web_search": {
        "enabled": true,
        "category": "external"
      }
    },
    "mcp": {
      "mcp_execute": {
        "enabled": true,
        "category": "external"
      }
    }
  }
}
```

Both global default and session-specific configurations use the same JSON structure. The global default configuration is stored in `global_default_tools.json`, while session-specific configurations are stored in `{config_id}_tools.json` files.

### Tool Types and Categories

Tools are organized by type and category:

| Type | Description | Protection |
|------|-------------|------------|
| **BASIC** | Essential tools required for core functionality | Cannot be disabled or removed |
| **EXTENDED** | Additional tools that enhance functionality | Can be disabled or removed |
| **EXPERIMENTAL** | Experimental tools that may not be stable | Can be disabled or removed |
| **MCP** | External tools accessed via Model Context Protocol | Managed through gateway tool |

Tools are also categorized by their functional purpose:

| Category | Description | Examples |
|----------|-------------|----------|
| **SYSTEM** | Tools for system operations | bash, think |
| **FILE_OPERATIONS** | Tools for file operations | edit, view, replace |
| **EXTERNAL** | Tools for external services | web_search, mcp_execute |

### Tool Base Class

The `Tool` abstract base class defines the interface that all tools must implement:

- `name`: A unique identifier for the tool
- `description`: A detailed description of the tool's functionality
- `short_description`: A brief summary of the tool
- `execute()`: Abstract method that executes the tool with provided parameters

### FunctionTool Class

The `FunctionTool` class extends `Tool` to specifically enable function calling capabilities for LLMs:

- Designed for integration with LLM function calling APIs (OpenAI-compatible)
- Automatically generates parameter schemas from function signatures
- Handles parameter validation and type conversion
- Provides a consistent execution interface
- Generates standardized tool definitions for LLM consumption

### Specific Tool Implementations

| Tool | Purpose | Key Features |
|------|---------|--------------| 
| **AskUserTool** | Gather user input interactively | • Structured question presentation<br>• Multiple-choice options<br>• Custom response support<br> |
| **BashTool** | Execute shell commands | • Streaming stdout/stderr via callbacks<br>• Heartbeats during idle periods<br>• Interactive prompt detection and auto-cancellation<br>• Staged cross-platform cancellation<br>• Ring-buffered output with bounded memory<br>• Risk assessment<br>• Command validation<br>• Output formatting |
| **EditTool** | Edit file contents | • File existence checking<br>• Content validation<br>• Error handling |
| **ReplaceTool** | Replace content in files | • Pattern matching<br>• Content validation<br>• Error handling |
| **ThinkTool** | Facilitate reasoning | • Structured thinking<br>• Step-by-step reasoning<br>• Decision support |
| **ViewTool** | View file contents | • File existence checking<br>• Content formatting<br>• Error handling |
| **ExamineImagesTool** | Analyze uploaded images | • Vision model integration<br>• Read text from screenshots<br>• Understand diagrams |
| **WebSearchTool** | Search the web | • Search-enabled model<br>• Up-to-date information retrieval<br>• Summarized results<br>• Usage tracking<br>• Isolated search context<br>• Source URLs for inline citations |
| **RunSkillTool** | Load and execute user-defined skills | • Skill discovery and loading<br>• Execution context detection<br>• Platform-specific instructions<br>• Multiple execution environments (native, uv, docker, npm) |
| **MCPExecuteTool** | Execute MCP server tools | • Single gateway for all MCP functionality<br>• Server name and tool name parameters<br>• Centralized error handling<br>• Automatic service management |

### Bash Tool

This section documents the current Bash Tool execution model based on an internal streaming executor.

- Executor implementation: [coda_core/core/tools/bash/executor.py](coda_core/core/tools/bash/executor.py)
- Wrapper function (tool entrypoint): [execute_bash_command()](coda_core/core/tools/bash/functions.py)
- Constants (heartbeat, caps, limits): [coda_core/core/tools/bash/constants.py](coda_core/core/tools/bash/constants.py)

Capabilities
- Foreground streaming of stdout/stderr via callbacks (executor).
- Heartbeats emitted during prolonged silence, cadence configured by HEARTBEAT_INTERVAL_MS.
- Per-line trim during streaming capped by MAX_STREAM_LINE_BYTES (by encoded length).
- Final buffers are ring-buffered with a total cap OUTPUT_MAX_BYTES split evenly across stdout/stderr.
- Optional timeout terminates execution deterministically and returns a TIMEOUT status.
- Interactive prompt detection: regex-based detection of common interactive prompts (confirmations, password, package manager, etc.). When detected, the executor auto-cancels the process and returns PROMPT_DETECTED status with a prompt_excerpt field.
- Staged cross-platform cancellation via cancel(): POSIX uses SIGINT → SIGTERM → SIGKILL to the process group; Windows uses CTRL_BREAK → TerminateProcess. Best-effort child process cleanup via psutil after forceful termination.

Wrapper behavior: execute_bash_command
- Entrypoint used by the Bash tool: [execute_bash_command()](coda_core/core/tools/bash/functions.py)
- Delegates process execution to the executor.
- Normalizes outputs and truncates final stdout/stderr for presentation (post-exec).
- Return schema:
  - Success:
    {
      "status": "success",
      "stdout": "<possibly truncated>",
      "stderr": "<possibly truncated>"
    }
  - Non-zero exit (error):
    {
      "status": "error",
      "message": "Command failed with exit code X",
      "exit_code": X,
      "stdout": "<final>",
      "stderr": "<final>",
      "command": "<original command>"
    }
  - Timeout:
    {
      "status": "error",
      "message": "Command timed out after N seconds",
      "stdout": "<final so far>",
      "stderr": "<final so far>",
      "command": "<original command>"
    }
  - Interactive prompt detected:
    {
      "status": "error",
      "message": "Interactive prompt detected",
      "command": "<original command>",
      "stdout": "<final so far>",
      "stderr": "<final so far>",
      "prompt_excerpt": "<matched prompt line>"
    }

Executor behavior (streaming)
- The executor reads stdout/stderr concurrently on dedicated threads.
- Each reader thread also performs interactive prompt detection: lines are matched against compiled patterns from PROMPT_REGEX_STRINGS. On the first match the executor auto-cancels the process tree via cancel() and sets prompt_excerpt on the result.
- A heartbeat thread emits when no lines are observed for HEARTBEAT_INTERVAL_MS.
- An optional timeout watchdog delegates to cancel() for staged termination when the timeout expires.
- Join timeouts for reader/heartbeat/watchdog threads are configurable (see constants).
- Final buffers are assembled from ring segments and included in the result.

Stdio model and interactivity
- stdout and stderr are redirected to pipes, enabling line-by-line streaming from the child process.
- stdin is connected to /dev/null (subprocess.DEVNULL); commands that require interactive input will block or error. Heartbeats make such idle periods visible. Common interactive prompts (confirmations, password, package manager, etc.) are detected automatically via regex patterns and the process is auto-cancelled with PROMPT_DETECTED status.
- Child processes are started in their own process group / new session (POSIX: `start_new_session=True`; Windows: `CREATE_NEW_PROCESS_GROUP`). This allows cancellation and timeouts to signal and terminate the entire group rather than only the direct child. Shutdown still relies on the process exiting (normally or due to cancellation/timeout) followed by reader/heartbeat/watchdog thread joins.

Buffering caveats
- Streaming depends on the child process flushing to its pipes. The parent cannot force flush.
- For Python commands, prefer python -u and print(..., flush=True).
- On Unix, stdbuf -oL -eL can help with many programs; availability and behavior vary by platform.
- The included demo enforces unbuffered output and explicit flush for reliable streaming.

CLI demo
- See [tests/integration/coda_core/core/tools/bash/bash_streaming_demo.py](../../../tests/integration/coda_core/core/tools/bash/bash_streaming_demo.py) for a portable demo that:
  - Streams stdout/stderr via callbacks.
  - Emits heartbeats while the process is idle.
  - Demonstrates interactive prompt detection (--prompt-demo).
  - Prints a final summary (status, exit_code, elapsed_ms, stdout/stderr lengths, command).

- Examples:
  - Built-in demo (portable):
    poetry run python tests/integration/coda_core/core/tools/bash/bash_streaming_demo.py --demo
  - Prompt detection demo:
    poetry run python tests/integration/coda_core/core/tools/bash/bash_streaming_demo.py --prompt-demo
  - Adjust heartbeat and timeout:
    poetry run python tests/integration/coda_core/core/tools/bash/bash_streaming_demo.py --demo --heartbeat-ms 250 --timeout 10
  - Disable colors if needed:
    poetry run python tests/integration/coda_core/core/tools/bash/bash_streaming_demo.py --demo --no-color

Defaults and limits
All constants live in [coda_core/core/tools/bash/constants.py](coda_core/core/tools/bash/constants.py).
- HEARTBEAT_INTERVAL_MS: default cadence for idle heartbeats (ms).
- MAX_STREAM_LINE_BYTES: per-line byte cap during streaming to avoid pathological memory use.
- OUTPUT_MAX_BYTES: maximum total in-memory bytes for final buffers (split evenly across stdout/stderr).
- CANCEL_GRACE_MS: milliseconds to wait after SIGINT/CTRL_BREAK before escalating.
- KILL_GRACE_MS: milliseconds to wait after SIGTERM before escalating to SIGKILL.
- CHILD_CLEANUP_WAIT_SECONDS: delay between child terminate() and kill() passes during cleanup.
- READER_JOIN_TIMEOUT_SECONDS, HEARTBEAT_JOIN_TIMEOUT_SECONDS, WATCHDOG_JOIN_TIMEOUT_SECONDS: bounded join timeouts for background threads during shutdown.
- PROMPT_REGEX_STRINGS: list of regex patterns for interactive prompt detection (case-insensitive).

Logging and observability
- The executor logs start/completion/timeout/error/cancellation events with structured messages.
- Cancellation events include task_id, PID, applied stages, outcome, and elapsed time.
- Interactive prompt detection logs the matched line on detection and the cancellation outcome.
- No per-line logs are emitted by default to avoid noisy logs; callbacks receive lines for UI/CLI rendering.

Known limitations
- Streaming cadence relies on the child process flushing; not all programs line-buffer to pipes.
- Final buffers are capped; for extremely large outputs, only the most recent content is retained.
- Lines longer than MAX_STREAM_LINE_BYTES are trimmed during streaming. Trimmed lines are what end up in the final buffers, since streaming captures already-trimmed content. The wrapper may further shorten the returned text for presentation via its max_output_length parameter.
- Interactive prompt detection is regex-based and conservative; it may miss unconventional prompt patterns. Some CLIs read directly from /dev/tty and may not be detected through pipe-based scanning.
- Cancellation may report FAILED if the process or orphaned children resist all termination signals (e.g., zombied or reparented processes).

## MCP (Model Context Protocol) Integration

The Tools Module includes support for the Model Context Protocol (MCP) through a gateway tool that provides access to external MCP servers and their tools.

For comprehensive documentation about MCP integration, including architecture, configuration, and usage details, see the dedicated [MCP Integration Documentation](../mcp/README.md).

## Key Features

### Function Wrapping

The `FunctionTool` class enables any Python function to be exposed as a tool:

- Functions are wrapped with metadata (name, description)
- Parameter schemas are automatically generated from type hints
- Type annotations with `Annotated` can provide parameter descriptions
- Special handling for `FileEditor` parameters

### Risk Assessment

The Bash tool includes a comprehensive risk assessment system with configurable security preferences:

```mermaid
flowchart TD
    A[Tool Call] --> B{Is Bash Tool?}
    B -->|No| C[Normal Execution]
    B -->|Yes| D[Risk Assessment]
    D --> E{Risk Level}
    E -->|Critical| K[Ask User Authorization]
    E -->|High/Medium/Low| G{Auto-approved?}
    E -->|Safe| J[Report & Execute]
    
    G -->|Yes| J[Report & Execute]
    G -->|No| K
    
    K -->|Authorized| J
    K -->|Denied| F[Block Execution]
```

Risk assessment features include:
- Categorization of commands by risk level (SAFE, LOW, MEDIUM, HIGH, CRITICAL)
- Detection of dangerous patterns using regex
- Identification of sensitive paths
- Scoring system for risk quantification
- Warning system for high-risk operations
- Hierarchical security model with configurable security preferences
- Session-based security preferences

#### Auto-approval System

Commands can be "auto-approved" based on user-defined security preferences:

- **Auto-approval**: Commands that match the user's security preference level (or lower) are executed without requiring explicit confirmation
- **User confirmation**: Commands that exceed the user's security preference level require explicit confirmation before execution
- **User confirmation for CRITICAL**: CRITICAL risk commands always require explicit confirmation regardless of security preferences

#### Hierarchical Security Model

The security model follows a hierarchical approach where setting a security preference level automatically approves all lower levels:

| Risk Level | Description | Default Behavior | With Preferences |
|------------|-------------|------------------|------------------|
| **SAFE** | Commands with no risk | Auto-approved | Always auto-approved |
| **LOW** (default) | Commands with minimal risk | Auto-approved | Auto-approved if preference set to LOW or higher |
| **MEDIUM** | Commands with moderate risk | Prompt user | Auto-approved if preference set to MEDIUM or higher |
| **HIGH** | Commands with significant risk | Prompt user | Auto-approved if preference set to HIGH |
| **CRITICAL** | Commands with extreme risk | Prompt user | Always requires confirmation |

#### Security Preferences

Users can configure their bash security preferences through the `/prefs` command in the CLI:

- Set maximum auto-approve level (LOW, MEDIUM, HIGH)
- Reset to default settings
- Preferences are saved with the session

### Consistent Interface

All tools provide a consistent interface:

- Standard naming conventions
- Comprehensive descriptions
- Consistent parameter validation with detailed error messages
- Uniform error handling with specialized error types
- Structured result formatting

## Developer's Guide: Adding New Tools to CODA

This comprehensive guide walks you through the complete process of creating and integrating new tools into the CODA Core system. Whether you're adding a simple utility function or a complex external service integration, this guide covers all the necessary steps and considerations.

### Overview of Tool Integration Process

Adding a new tool to CODA involves several key steps:

1. **Create the tool structure** following CODA's file organization patterns
2. **Define the tool function** with proper type hints and documentation
3. **Create the tool class** extending the appropriate base class
4. **Register the tool** with the system's tool management infrastructure
5. **Handle dependencies** if your tool requires external services or resources
6. **Configure integration points** for proper system-wide availability

### File Structure and Organization

CODA follows a consistent file structure pattern for tools. Each tool should be organized in its own directory under [`coda_core/core/tools/`](/coda_core/core/tools/) with the following structure:

```
coda_core/core/tools/your_tool_name/
├── __init__.py              # Package initialization
├── description.py           # Tool descriptions and metadata
├── functions.py            # Core tool functionality
└── your_tool_name_tool.py  # Tool class implementation
```

**Why this structure?** This pattern provides:
- **Consistency**: All tools follow the same organizational pattern
- **Maintainability**: Clear separation of concerns between descriptions, functions, and implementation
- **Discoverability**: Easy to locate and understand tool components
- **Modularity**: Functions can be tested independently of the tool class

**Example from existing tools:**
- [`coda_core/core/tools/web_search/`](/coda_core/core/tools/web_search/) - External service integration
- [`coda_core/core/tools/edit/`](/coda_core/core/tools/edit/) - File operation tool
- [`coda_core/core/tools/bash/`](/coda_core/core/tools/bash/) - System command tool

### Step-by-Step Implementation Guide

#### Step 1: Create the Tool Directory Structure

Create a new directory for your tool and the required files:

```bash
mkdir coda_core/core/tools/your_tool_name
touch coda_core/core/tools/your_tool_name/__init__.py
touch coda_core/core/tools/your_tool_name/description.py
touch coda_core/core/tools/your_tool_name/functions.py
touch coda_core/core/tools/your_tool_name/your_tool_name_tool.py
```

#### Step 2: Define Tool Descriptions (description.py)

Create clear, informative descriptions for your tool:

```python
# coda_core/core/tools/your_tool_name/description.py
from datetime import datetime

YOUR_TOOL_SHORT_DESC = """Brief description of what your tool does.
Keep this concise and action-oriented."""

YOUR_TOOL_DESC = f"""Detailed description of your tool's functionality.
Explain when and how the AI should use this tool.

Include any important context or limitations.
"""
```

#### Step 3: Implement Core Functionality (functions.py)

Define the core function(s) that implement your tool's behavior:

```python
# coda_core/core/tools/your_tool_name/functions.py
from typing import Annotated, Dict, Any
from loguru import logger

def execute_your_tool(
    param1: Annotated[str, "Description of first parameter"],
    param2: Annotated[int, "Description of second parameter"],
    # Add more parameters as needed
) -> Dict[str, Any]:
    """
    Core function that implements your tool's functionality.
    
    Args:
        param1: Detailed description of the first parameter
        param2: Detailed description of the second parameter
        
    Returns:
        Dictionary containing the result and status information
    """
    try:
        # Implement your tool's logic here
        result = f"Processing {param1} with value {param2}"
        
        return {
            "status": "success",
            "result": result,
            # Add any additional metadata
        }
    except Exception as e:
        logger.exception(f"Error in your_tool execution: {e}")
        return {
            "status": "error",
            "message": str(e)
        }
```

**Best Practices for Tool Functions:**
- Use [`Annotated`](https://docs.python.org/3/library/typing.html#typing.Annotated) type hints for all parameters
- Include comprehensive docstrings
- Return structured dictionaries with status information
- Handle errors gracefully with try/except blocks
- Use the [`loguru`](https://github.com/Delgan/loguru) logger for consistent logging
- **Follow OpenAI's function calling best practices**: See [OpenAI's Best Practices for Defining Functions](https://platform.openai.com/docs/guides/function-calling#best-practices-for-defining-functions) for detailed guidance on parameter naming, descriptions, and function design

#### Step 4: Create the Tool Class (your_tool_name_tool.py)

Implement the tool class that wraps your function:

```python
# coda_core/core/tools/your_tool_name/your_tool_name_tool.py
from typing import Callable, Dict, Any
from loguru import logger

from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.tools.your_tool_name.description import YOUR_TOOL_DESC, YOUR_TOOL_SHORT_DESC
from coda_core.core.tools.your_tool_name.functions import execute_your_tool

class YourToolNameTool(FunctionTool):
    """Tool for [brief description of functionality]."""

    name: str = "your_tool_name"
    description: str = YOUR_TOOL_DESC
    short_description: str = YOUR_TOOL_SHORT_DESC
    function: Callable = execute_your_tool

    def __init__(
        self,
        name: str = name,
        description: str = description,
        short_description: str = short_description,
        function: Callable = function,
        # Add any dependencies your tool needs
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            short_description=short_description,
            function=function
        )
        
        # Store any dependencies
        # self.dependency = dependency
        
        # Override tool definition if you need to exclude internal parameters
        # self.tool_definition = self._generate_tool_definition(
        #     exclude_params=["internal_param"]
        # )

    def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute the tool with the provided parameters."""
        try:
            # Validate parameters (exclude internal ones if needed)
            self._validate_parameters(
                execute_your_tool,
                kwargs,
                exclude_params=[]  # Add any internal parameters to exclude
            )
            
            # Add any pre-processing logic here
            
            # Execute the core function
            result = execute_your_tool(**kwargs)
            
            # Add any post-processing logic here
            
            return result
        except ParameterError as e:
            logger.error(f"Parameter error in {self.name} tool: {e}")
            raise
        except Exception as e:
            logger.exception(f"Error executing {self.name} tool: {e}")
            return {"status": "error", "message": str(e)}
```

#### Step 5: Add Tool to System Configuration

Add your tool to the system's default tool configuration in [`coda_core/core/tools/schemas.py`](/coda_core/core/tools/schemas.py):

```python
# 1. Add the import at the top of the file
from coda_core.core.tools.your_tool_name.your_tool_name_tool import YourToolNameTool

# 2. Add your tool to the DEFAULT_TOOL_CONFIGS dictionary
# In the appropriate section (TOOL_TYPE_EXTENDED or TOOL_TYPE_EXPERIMENTAL):
TOOL_TYPE_EXTENDED: {
    "web_search": {
        "tool_class": WebSearchTool,
        "config": {
            "category": TOOL_CATEGORY_EXTERNAL,
            "enabled": True
        }
    },
    "your_tool_name": {  # Add your tool here
        "tool_class": YourToolNameTool,
        "config": {
            "category": "your_category",  # Use appropriate category constant
            "enabled": True
        }
    }
}
```

**Available Categories:**
- [`TOOL_CATEGORY_SYSTEM`](/coda_core/core/tools/constants.py): System operations
- [`TOOL_CATEGORY_FILE_OPERATIONS`](/coda_core/core/tools/constants.py): File-related operations
- [`TOOL_CATEGORY_REASONING`](/coda_core/core/tools/constants.py): Thinking and reasoning tools
- [`TOOL_CATEGORY_EXTERNAL`](/coda_core/core/tools/constants.py): External services and APIs
- Custom categories: Define your own category string if needed

**Tool Types:**
- [`TOOL_TYPE_BASIC`](/coda_core/core/tools/constants.py): Essential tools that cannot be disabled (use sparingly)
- [`TOOL_TYPE_EXTENDED`](/coda_core/core/tools/constants.py): Standard tools that can be enabled/disabled
- [`TOOL_TYPE_EXPERIMENTAL`](/coda_core/core/tools/constants.py): Experimental tools that may have limitations
- [`TOOL_TYPE_MCP`](/coda_core/core/tools/constants.py): MCP gateway tool (reserved)

**Tool Categories:**
- `system`: System operations (e.g., bash, think)
- `file_operations`: File-related operations (e.g., edit, view, replace)
- `external`: External services (e.g., web_search, mcp_execute)
- Custom categories: You can define custom categories for your tools

#### Step 6: Handle Dependencies and Integration Points

**For tools that need external clients or services:**

If your tool requires external dependencies (like API clients), you need to register them in the dependency injection system:

```python
# In the create_single_agent function, add dependency registration:
# External tools need specific clients
if tool_name in ["web_search", "your_tool_name"]:  # Add your tool here
    tool_manager.register_tool_dependency(tool_name, "client", geai_client)

# For tools that need file operations
if tool_name in ["edit", "view", "replace", "your_file_tool"]:
    tool_manager.register_tool_dependency(tool_name, "editor", file_editor)
```

**Important:** You **must** modify this section if your tool requires:
- External API clients (like `GEAIClient`)
- File operation capabilities (like `FileEditor`)
- Database connections
- Any other shared system resources

**For tools with custom dependencies:**

```python
# Register custom dependencies in the tool registry
from coda_core.core.tools.registry import ToolRegistry

def register_with_custom_dependencies(registry: ToolRegistry, custom_service):
    # Register the dependency
    registry.register_dependency("custom_service", custom_service)
    
    # Map the dependency to your tool's constructor parameter
    registry.register_tool_dependency(
        tool_name="your_tool_name",
        param_name="service",  # Parameter name in your tool's __init__
        dependency_name="custom_service"
    )
```

### Complete Example: Adding a Similarity Search Tool

Here's a comprehensive example that demonstrates adding a new tool with external dependencies, following all the patterns and best practices:

#### File Structure
```
coda_core/core/tools/similarity/
├── __init__.py
├── description.py
├── functions.py
└── similarity_tool.py
```

#### Step 1: Create description.py
```python
# coda_core/core/tools/similarity/description.py
SIMILARITY_TOOL_SHORT_DESC = """Find similar content using vector embeddings.
Use this to search for semantically related information."""

SIMILARITY_TOOL_DESC = """Use this tool to find similar content based on semantic meaning.
Provide a query text and get back the most similar items from the knowledge base.

The tool uses vector embeddings to calculate semantic similarity and returns
ranked results with similarity scores.
"""
```

#### Step 2: Create functions.py
```python
# coda_core/core/tools/similarity/functions.py
from typing import Annotated, Dict, Any, List
from loguru import logger

def execute_similarity_search(
    query: Annotated[str, "The search query to find similar content for"],
    limit: Annotated[int, "Maximum number of results to return"] = 5,
    threshold: Annotated[float, "Minimum similarity threshold (0.0 to 1.0)"] = 0.7,
) -> Dict[str, Any]:
    """
    Execute a similarity search using vector embeddings.
    
    Args:
        query: The search query text
        limit: Maximum number of results to return
        threshold: Minimum similarity score threshold
        
    Returns:
        Dictionary containing search results and metadata
    """
    try:
        # In a real implementation, this would:
        # 1. Generate embeddings for the query
        # 2. Search the vector database
        # 3. Return ranked results
        
        # Simplified example results
        results = [
            {"content": "Similar content 1", "score": 0.95},
            {"content": "Similar content 2", "score": 0.87},
            {"content": "Similar content 3", "score": 0.78},
        ]
        
        # Filter by threshold
        filtered_results = [r for r in results if r["score"] >= threshold][:limit]
        
        return {
            "status": "success",
            "results": filtered_results,
            "query": query,
            "total_found": len(filtered_results)
        }
    except Exception as e:
        logger.exception(f"Error in similarity search: {e}")
        return {
            "status": "error",
            "message": str(e)
        }
```

#### Step 3: Create similarity_tool.py
```python
# coda_core/core/tools/similarity/similarity_tool.py
from typing import Callable, Optional, Dict, Any
from loguru import logger

from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.tools.similarity.description import SIMILARITY_TOOL_DESC, SIMILARITY_TOOL_SHORT_DESC
from coda_core.core.tools.similarity.functions import execute_similarity_search
from coda_core.core.models.providers.geai_client import GEAIClient

class SimilarityTool(FunctionTool):
    """Tool for finding similar content using vector embeddings."""

    name: str = "similarity"
    description: str = SIMILARITY_TOOL_DESC
    short_description: str = SIMILARITY_TOOL_SHORT_DESC
    function: Callable = execute_similarity_search

    def __init__(
        self,
        name: str = name,
        description: str = description,
        short_description: str = short_description,
        function: Callable = function,
        client: Optional[GEAIClient] = None,
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            short_description=short_description,
            function=function
        )
        self.client = client
        
        if client:
            logger.info(f"SimilarityTool configured with client")
        else:
            logger.warning("SimilarityTool initialized without a client")

    def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute the similarity search with the provided parameters."""
        try:
            self._validate_parameters(execute_similarity_search, kwargs)
            
            if not self.client:
                raise ValueError("GEAIClient not set for SimilarityTool")
            
            # Execute the core function
            result = execute_similarity_search(**kwargs)
            
            return result
        except ParameterError as e:
            logger.error(f"Parameter error in {self.name} tool: {e}")
            raise
        except Exception as e:
            logger.exception(f"Error executing {self.name} tool: {e}")
            return {"status": "error", "message": str(e)}
```

#### Step 4: Add Tool to schemas.py
```python
# Add to coda_core/core/tools/schemas.py:

# 1. Add import at the top
from coda_core.core.tools.similarity.similarity_tool import SimilarityTool

# 2. Add to SYSTEM_DEFAULT_TOOL_CONFIGS in TOOL_TYPE_EXTENDED section:
TOOL_TYPE_EXTENDED: {
    "web_search": {
        "tool_class": WebSearchTool,
        "config": {
            "category": TOOL_CATEGORY_EXTERNAL,
            "enabled": True
        }
    },
    "similarity": {
        "tool_class": SimilarityTool,
        "config": {
            "category": TOOL_CATEGORY_EXTERNAL,
            "enabled": True
        }
    }
}
```

#### Step 5: Add Dependency Registration in utils.py
```python
# Modify coda_core/core/clients/cli/utils.py around line 303:
# External tools need the client
if tool_name in ["web_search", "similarity"]:  # Add "similarity" here
    tool_manager.register_tool_dependency(tool_name, "client", geai_client)
```

#### Step 6: Enable and Test the Tool
```python
# To enable the tool programmatically:
from coda_core.core.session.shared_state import SharedState

def register_similarity_tool():
    shared_state = SharedState()
    # Tool would be registered in manager.py during system initialization
    # Users can then enable/disable it via the /tools CLI command
    print("Similarity tool registered and available in /tools menu")

# The tool is now available for enabling via /tools command
```

### Key Integration Points Summary

Based on the feedback and this guide, here are the **mandatory** steps for proper CODA tool integration:

#### 1. **File Structure Pattern** ✅ **REQUIRED**
- Follow the [`description.py`](/coda_core/core/tools/web_search/description.py), [`functions.py`](/coda_core/core/tools/web_search/functions.py), [`tool_name_tool.py`](/coda_core/core/tools/web_search/web_search_tool.py) pattern
- This ensures consistency and maintainability across all tools

#### 2. **Tool Registration** ✅ **REQUIRED**
- Register your tool class under the appropriate [`TOOL_TYPE_EXTENDED`](/coda_core/core/tools/constants.py) or [`TOOL_TYPE_EXPERIMENTAL`](/coda_core/core/tools/constants.py)
- Add the import and registration call in [`coda_core/core/tools/manager.py`](/coda_core/core/tools/manager.py)

#### 3. **Tool Types and Categories** ✅ **REQUIRED**
- Use [`TOOL_TYPE_EXTENDED`](/coda_core/core/tools/constants.py) for standard tools that can be enabled/disabled
- Use [`TOOL_TYPE_EXPERIMENTAL`](/coda_core/core/tools/constants.py) for experimental features
- Choose appropriate categories: `system`, `file_operations`, `external`, or custom categories

### Troubleshooting Common Issues

**Tool not recognized by the CODA Agent**
- Ensure the tool is added to [`schemas.py`](/coda_core/core/tools/schemas.py) in the [`DEFAULT_TOOL_CONFIGS`](/coda_core/core/tools/schemas.py) dictionary
- Check that the import statement is correct and the tool class is accessible
- Verify the tool type is one of: [`TOOL_TYPE_BASIC`](/coda_core/core/tools/constants.py), [`TOOL_TYPE_EXTENDED`](/coda_core/core/tools/constants.py), or [`TOOL_TYPE_EXPERIMENTAL`](/coda_core/core/tools/constants.py)

**Tool function not being called:**
- Ensure your tool class extends [`FunctionTool`](/coda_core/core/tools/function_tool.py)
- Verify the [`function`](/coda_core/core/tools/web_search/web_search_tool.py) class attribute points to your implementation function
- Check parameter validation isn't excluding required parameters in [`_validate_parameters`](/coda_core/core/tools/function_tool.py) calls
- Ensure your function uses proper [`Annotated`](https://docs.python.org/3/library/typing.html#typing.Annotated) type hints

**Tool appears but gives parameter errors:**
- Check that your function signature matches the parameters the LLM is trying to pass
- Verify [`Annotated`](https://docs.python.org/3/library/typing.html#typing.Annotated) descriptions are clear and match expected usage
- Use [`exclude_params`](/coda_core/core/tools/web_search/web_search_tool.py) in [`_generate_tool_definition`](/coda_core/core/tools/function_tool.py) for internal parameters

**Tool registration succeeds but runtime errors occur:**
- Check that all imports in your tool files are correct and dependencies are available
- Verify error handling in your tool's [`execute`](/coda_core/core/tools/web_search/web_search_tool.py) method
- Ensure proper logging using [`loguru`](https://github.com/Delgan/loguru) logger for debugging

### Quick Reference for Existing Developers

For developers familiar with the CODA Core codebase who just need a quick checklist:

1. **Create tool directory**: `coda_core/core/tools/your_tool/`
2. **Add files**: `description.py`, `functions.py`, `your_tool_tool.py`, `__init__.py`
3. **Add to schemas**: Add import and tool config to [`schemas.py`](/coda_core/core/tools/schemas.py) `DEFAULT_TOOL_CONFIGS`
5. **Test**: Add unit tests or validate manually the functionality of your tool

### Frequently Asked Questions

**Q: Is registering under TOOL_TYPE_EXTENDED mandatory?**
A: **Yes, for new tools.** Use:
- [`TOOL_TYPE_BASIC`](/coda_core/core/tools/constants.py): Only for essential system tools (rare)
- [`TOOL_TYPE_EXTENDED`](/coda_core/core/tools/constants.py): Standard tools (recommended)
- [`TOOL_TYPE_EXPERIMENTAL`](/coda_core/core/tools/constants.py): Experimental/unstable tools
- [`TOOL_TYPE_MCP`](/coda_core/core/tools/constants.py): Reserved for MCP gateway tool

**Q: Why follow the description.py/functions.py pattern?**
A: This pattern provides:
- **Consistency**: All tools follow the same structure
- **Testability**: Functions can be unit tested independently
- **Maintainability**: Clear separation of concerns
- **Discoverability**: Easy to find and understand tool components

## Data Flow

The execution of a tool follows a standard flow:

```mermaid
flowchart TD
    A[Agent Requests Tool Execution] --> B[Tool Receives Parameters]
    B --> C[Parameter Validation]
    C -->|Invalid Parameters| D[Raise ParameterError with Details]
    D --> Z[Return Formatted Error]
    C -->|Valid Parameters| E[Prepare Function Call]
    E --> F[Execute Function]
    F -->|Success| G[Format Result]
    F -->|Failure| H[Handle Error]
    G --> I[Return Result to Agent]
    H --> J[Return Error to Agent]
```

1. The agent requests execution of a tool with specific parameters
2. The tool validates the parameters against its schema using the _validate_parameters method
3. If validation fails, a ParameterError is raised with detailed information about missing or unexpected parameters
4. If validation succeeds, the parameters are prepared for the function call
5. The function is executed with the prepared parameters
6. If execution succeeds, the result is formatted and returned
7. If execution fails, the error is handled and returned

## Integration

### Tool Registry and Manager Integration

Tools are integrated with agents through a two-phase process:

```mermaid
flowchart TD
    subgraph "Initialization Phase"
        A[SingleAgent Creation] --> B[ToolManager.get_enabled_tools]
        B --> C[Register Dependencies for Enabled Tools]
        C --> D[ToolRegistry Instantiates Tools]
        D --> E[Tool Instances Provided to Agent]
    end
    
    subgraph "Execution Phase"
        E --> F[Agent Calls Tools Directly]
        F --> G[Tool Executes with Dependencies]
        G --> H[Results Returned to Agent]
    end
```

The integration flow works as follows:

1. During initialization:
   - The `SharedState` lazily initializes a `ToolManager` instance
   - The `ToolManager` loads its configuration from a JSON file or creates a new one
   - When creating a `SingleAgent`, the `ToolManager` is passed as a parameter
   - The agent requests enabled tools from the `ToolManager.get_enabled_tools()`
   - For each enabled tool, dependencies are registered if needed
   - The `ToolRegistry` instantiates the tools with their dependencies
   - The agent receives the instantiated tool objects

2. During execution:
   - The agent calls the tool instances directly
   - Tools execute with their injected dependencies
   - Results are returned directly to the agent

Benefits of this architecture:

- Tool configuration is persisted across sessions
- Basic tools are always available
- Tool dependencies are only registered when needed
- Configuration changes are properly saved
- Tools are consistently available to all components that need them
- Performance is optimized by saving configuration only when necessary

### Agent Integration

Tools are integrated with agents directly:

- Agents receive tool instances from the `ToolManager.get_enabled_tools()` method during initialization
- Agents call tool instances directly during execution
- Tool results are formatted for agent consumption
- Errors are handled and reported to agents

### File System Integration

Many tools interact with the file system:

- The `ViewTool` reads file contents
- The `EditTool` modifies file contents
- The `ReplaceTool` performs pattern-based replacements
- The `BashTool` can execute commands that interact with files

### LLM Integration

Tools are exposed to LLMs through function calling:

- Tool definitions are generated in OpenAI-compatible format
- Parameters are described with types and descriptions
- Results are formatted for LLM consumption
- Errors are handled and reported to LLMs

## Extensibility

### Creating New Tools

To create a new tool:

1. Define a function that implements the tool's functionality
2. Use type hints to specify parameter types
3. Use `Annotated` to provide parameter descriptions
4. Create a new class extending `FunctionTool`
5. Initialize the class with the function and metadata

Example:

```python
from typing import Annotated
from core.tools.function_tool import FunctionTool

def calculate_sum(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Calculate the sum of two numbers."""
    return a + b

class CalculateTool(FunctionTool):
    """A tool for calculating the sum of two numbers."""
    
    name = "calculate"
    description = "Calculate the sum of two numbers."
    short_description = "Calculate sum of two numbers."
    function = calculate_sum
    
    def __init__(self, name=name, description=description, 
                 short_description=short_description, function=function):
        super().__init__(name=name, description=description, 
                         short_description=short_description, function=function)
```

### Parameter Validation

The FunctionTool class includes a robust parameter validation system:

- Parameters are validated against the function signature
- Required parameters are checked for presence
- Unexpected parameters are detected
- Custom ParameterError exceptions provide detailed feedback
- Special handling for internal parameters (like editor)
- Validation can exclude specific parameters when needed

This validation system ensures that tools receive the correct parameters and provides helpful error messages when validation fails, which are communicated back to the LLM to improve its usage of tools.

### Best Practices

When creating tools:

- Provide clear and detailed descriptions
- Use type hints for all parameters
- Handle errors gracefully using try/except blocks
- Return structured results
- Consider security implications
- Leverage the built-in parameter validation
- Follow naming conventions
- Checkout OpenAI's function calling guidelines: Refer to [OpenAI's Best Practices for Defining Functions](https://platform.openai.com/docs/guides/function-calling#best-practices-for-defining-functions) for optimal function design, parameter naming, and description writing

### Extending Existing Tools

Existing tools can be extended by:

- Subclassing the tool class
- Overriding the `execute` method
- Adding new parameters
- Enhancing validation logic
- Improving error handling

## Security Considerations

### Risk Assessment

The Bash tool includes a comprehensive risk assessment system:

- Commands are categorized as safe, low, medium, high, or critical risk
- Dangerous patterns are detected using regex
- Sensitive paths are identified
- Risk scores are calculated based on patterns and commands
- Warnings are issued for high-risk operations

### Mitigation Strategies

Several strategies are employed to mitigate risks:

- Validation of all parameters
- Checking of file paths
- Limiting of command execution
- Warning for high-risk operations
- Timeout for long-running operations

### Sensitive Operations

Special care is taken for sensitive operations:

- File editing requires validation
- Command execution is risk-assessed
- File paths are checked for validity
- Timeouts prevent resource exhaustion
- Error handling prevents cascading failures

### Interactive User Input

The AskUserTool provides a structured way for the agent to gather information from users:

```mermaid
flowchart TD
    A[Agent Needs Information] --> B[Call AskUserTool]
    B --> C[Format Question and Options]
    C --> D[Display in Clean UI]
    D --> E{User Response}
    E -->|Select Option| F[Return Selected Option]
    E -->|Custom Input| G[Return Custom Input]
    F --> H[Agent Continues with Response]
    G --> H
```

#### Input Processing

The tool handles both structured and free-form input:

1. **Option Selection**: If the user enters a number corresponding to a provided option, the tool returns the selected option text
2. **Custom Input**: If the user enters any other text, it's treated as a custom response and returned directly
3. **Type Handling**: The tool properly handles both string and array inputs for suggestions, ensuring compatibility with different LLM response formats

#### Integration with Agent Workflow

The AskUserTool is seamlessly integrated into the agent's workflow:

- **Contextual Questions**: The agent can ask contextually relevant questions based on the current task
- **Decision Points**: The tool can be used at decision points to gather user preferences
- **Information Gathering**: When the agent needs specific information, it can present structured options to guide the user

This interactive capability enhances the agent's ability to collaborate effectively with users, making it more versatile and responsive to user needs.

## Configuration Management

### JSON Configuration

Tool settings are stored in JSON configuration files:

- **Global Default Configuration**: Stored in `~/.coda/.tools/global_default_tools.json`
- **Session-specific Configuration**: Each `ToolManager` has a unique `config_id` and configuration is saved to `~/.coda/.tools/{config_id}_tools.json`
- Configuration includes tool metadata, enabled status, and categories
- Configuration is validated using Pydantic models

The global configuration system provides a hierarchical approach:

```mermaid
flowchart TD
    A[System Default Tool Configs] -->|Initial Source| B[Global Default Config]
    B -->|Template for| C[Session 1 Config]
    B -->|Template for| D[Session 2 Config]
    B -->|Template for| E[Session 3 Config]
    F[User Customization] -->|Can be saved as| B
    G[New Tools] -->|Merged with| B
```

When a tool configuration is needed:
1. The system first checks for a session-specific configuration
2. If no session configuration exists, it checks for a global default configuration
3. If no global default exists, it falls back to system defaults from `SYSTEM_DEFAULT_TOOL_CONFIGS`

This approach ensures:
- Consistent default settings across sessions
- Ability to customize individual sessions
- Persistence of user preferences
- Automatic incorporation of new tools

Example configuration:

```json
{
  "metadata": {
    "last_modified": "2025-06-05T11:25:06.973000+00:00"
  },
  "tools": {
    "basic": {
      "bash": {
        "enabled": true,
        "category": "system"
      },
      "edit": {
        "enabled": true,
        "category": "file_operations"
      },
      "view": {
        "enabled": true,
        "category": "file_operations"
      },
      "think": {
        "enabled": true,
        "category": "system"
      },
      "replace": {
        "enabled": true,
        "category": "file_operations"
      }
    },
    "extended": {
      "web_search": {
        "enabled": true,
        "category": "external"
      }
    },
    "mcp": {
      "mcp_execute": {
        "enabled": true,
        "category": "external"
      }
    },
    "experimental": {}
  }
}
```

### Loading and Saving

The configuration management system includes:

- Automatic loading from file when a `ToolManager` is initialized
- Validation of configuration structure using Pydantic models
- Saving configuration when tools are registered, enabled, or disabled
- Optimized saving for batch operations to reduce disk I/O
- File locking to prevent concurrent access issues

### Dependency Injection

The tool system supports dependency injection:

- Dependencies can be registered globally or per-tool
- Tool-specific dependencies take precedence over global dependencies
- Dependencies are injected during tool instantiation
- Only dependencies for enabled tools are registered
- Common dependencies include `FileEditor` for file operations and `GEAIClient` for external services

## View Tool Semantics and Metadata

The View tool exposes the filesystem viewing contract from the filesystem_ops module for LLM-friendly pagination and safety.

- Per-request safety cap
  - All reads (full or ranged) are capped per request by the configured cap in [coda_core/core/filesystem_ops/constants.py](coda_core/core/filesystem_ops/constants.py).
  - Use offset + limit pagination for large files and to avoid unnecessary token usage.

- Range semantics
  1. No offset & no limit  -> return entire file, capped at the per-request cap
  2. limit only            -> lines 1 .. min(limit, cap)
  3. offset only           -> lines offset .. end of file (subject to cap)
  4. offset + limit        -> at most min(limit, cap) lines starting at offset (may be fewer at EOF)

- Numbered output
  - File content is returned in “cat -n” style: “N: …” with original file line numbers preserved.
  - When using offset, numbering starts at offset; when no offset is provided, numbering starts at 1.

- Response shape (files vs directories)
  - Files return content and a metadata object:
    - start_line (int): starting 1-based line for the returned slice
    - end_line (int): last 1-based line for the returned slice
    - returned_lines (int): number of lines returned
    - has_more (bool): True if additional content exists beyond this slice
    - eof_reached (bool): True if EOF was reached within or exactly at this slice
    - truncated (bool): True only when the per-request cap engaged
  - Directories return a formatted listing and omit the metadata field entirely.

- Full-file reads (no offset/limit)
  - start_line is always 1
  - end_line equals returned_lines (0 for empty files)
  - truncated is True if and only if the per-request cap engaged
  - has_more is True if truncated; otherwise False
  - eof_reached is False if truncated; otherwise True

- Pagination guidance
  - If has_more is True, request the next slice with offset = end_line + 1 (keep limit unless you need to adjust).
  - If eof_reached is True or returned_lines == 0, you have reached the end of file.
  - If limit extends beyond EOF, fewer lines are returned and the result is not considered truncated.

For the authoritative, lower-level contract (including details about streaming reads and consistency guarantees), see [coda_core/core/filesystem_ops/README.md](coda_core/core/filesystem_ops/README.md).