from abc import ABC, abstractmethod
from typing import Any, Dict

class Tool(ABC):
    """
    Abstract base class for a tool that can be executed with specified parameters.

    Attributes:
        name (str): The name of the tool.
        description (str): The detailed description of the tool.
        short_description (str): A brief description of the tool.
    """

    def __init__(self, name: str, description: str, short_description: str):
        """
        Initialize a Tool instance.

        Args:
            name (str): The name of the tool.
            description (str): The detailed description of the tool.
            short_description (str): A brief description of the tool.
        """
        self.name = name
        self.description = description
        self.short_description = short_description

    @abstractmethod
    def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Abstract method to execute the tool with the provided arguments.

        Args:
            **kwargs: Keyword arguments to pass to the tool's function.

        Returns:
            Dict[str, Any]: The result of the tool execution.
        """
        pass