REPLACE_TOOL_SHORT_DESC = """Overwrites a file with new content at the specified absolute file path. Use for replacing entire file contents, not for partial edits (use the Edit tool instead). Ensure the directory exists before writing. Be careful!: This tool does not accept the same arguments as the Edit tool. Examples: Write "Hello, World!" to `/path/to/file.txt` or replace the contents of `/path/to/config.json` with valid JSON. Edge case: The tool will fail if the directory does not exist or the file path is not absolute."""

REPLACE_TOOL_DESC = """Write a file to the local filesystem. Overwrites the existing file if there is one.

Before using this tool:

1. Use the View tool to understand the file's contents and context
2. Directory Verification (only applicable when creating new files):
   - Use the Bash (ls) tool to verify the parent directory exists and is the correct location

To write a file, provide the following information:
1. file_path: The absolute path to the file to write (must be absolute, not relative)
2. content: The content to write to the file
The tool will overwrite the file at file_path with the provided content.
"""