from typing import Annotated, Any, Dict

from loguru import logger

from coda_core.core.filesystem_ops.file_editor import FileEditor

def execute_replace(
        editor: FileEditor,
        file_path: Annotated[str, "The absolute path to the file to write (must be absolute, not relative)"],
        content: Annotated[str, "The content to write to the file"]
) -> Dict[str, Any]:
    """
    Writes content to a file in the local filesystem, overwriting the file if it already exists.

    Args:
        editor (FileEditor): An instance of FileEditor used to perform the file writing operation.
        file_path (str): The absolute path to the file where content will be written.
        content (str): The content to write to the file.

    Returns:
        Dict[str, Any]: A dictionary containing the status of the operation, the file path, and the result or error message.
    """
    try:
        return editor.replace(file_path, content)
    except Exception as e:
        logger.error(f"Failed to write to file {file_path}: {e}")
        return {"status": "error", "file": file_path, "message": str(e)}