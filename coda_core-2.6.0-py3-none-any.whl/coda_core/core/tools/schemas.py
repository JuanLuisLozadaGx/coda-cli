"""
Pydantic schemas for tool configuration validation
"""
from datetime import datetime
from typing import Dict, Any, Optional
from pydantic import BaseModel, ConfigDict, Field

# Import tool classes
from coda_core.core.tools.bash.bash_tool import BashTool
from coda_core.core.tools.edit.edit_tool import EditTool
from coda_core.core.tools.view.view_tool import ViewTool
from coda_core.core.tools.think.think_tool import ThinkTool
from coda_core.core.tools.replace.replace_tool import ReplaceTool
from coda_core.core.tools.web_search.web_search_tool import WebSearchTool
from coda_core.core.tools.ask_user.ask_user_tool import AskUserTool
from coda_core.core.tools.examine_images.examine_images_tool import ExamineImagesTool
from coda_core.core.tools.mcp_execute.mcp_execute_tool import MCPExecuteTool
from coda_core.core.tools.step_by_step_tools.approve_plan.approve_plan_tool import ApprovePlanTool
from coda_core.core.tools.step_by_step_tools.create_plan.create_plan_tool import CreatePlanTool
from coda_core.core.tools.step_by_step_tools.mark_step.mark_step_tool import MarkStepTool
from coda_core.core.tools.step_by_step_tools.update_plan.update_plan_tool import UpdatePlanTool
from coda_core.core.tools.step_by_step_tools.mark_plan_as_pending.mark_plan_as_pending_tool import MarkPlanAsPendingTool
from coda_core.core.tools.step_by_step_tools.load_plan.load_plan_tool import LoadPlanTool 
from coda_core.core.tools.omni_parser.omni_parser_tool import OmniParserTool
from coda_core.core.tools.run_skill.run_skill_tool import RunSkillTool


# Import tool constants
from coda_core.core.tools.constants import (
    TOOL_TYPE_BASIC,
    TOOL_TYPE_EXTENDED,
    TOOL_TYPE_EXPERIMENTAL,
    TOOL_TYPE_MCP,
    TOOL_TYPE_USER_DEFINED,
    TOOL_TYPE_PLUGINS,
    TOOL_CATEGORY_SYSTEM,
    TOOL_CATEGORY_FILE_OPERATIONS,
    TOOL_CATEGORY_REASONING,
    TOOL_CATEGORY_EXTERNAL,
)


class ToolMetadata(BaseModel):
    """Metadata for tool configuration"""
    created_at: str
    last_modified: str
    managed_by: str = "coda-core"


class ToolConfig(BaseModel):
    """Configuration for a single tool"""
    enabled: bool = True
    category: str  # Functional category of the tool (e.g. "system", "file_operations")
    # Allow additional fields for tool-specific metadata
    extra_fields: Dict[str, Any] = Field(default_factory=dict, alias="extra")

    model_config = ConfigDict(extra="allow")


class ToolsConfig(BaseModel):
    """Configuration for all tools by category"""
    basic: Dict[str, ToolConfig] = Field(default_factory=dict, alias=TOOL_TYPE_BASIC)
    extended: Dict[str, ToolConfig] = Field(default_factory=dict, alias=TOOL_TYPE_EXTENDED)
    experimental: Dict[str, ToolConfig] = Field(default_factory=dict, alias=TOOL_TYPE_EXPERIMENTAL)
    mcp: Dict[str, ToolConfig] = Field(default_factory=dict, alias=TOOL_TYPE_MCP)
    user_defined: Dict[str, ToolConfig] = Field(default_factory=dict, alias=TOOL_TYPE_USER_DEFINED)
    plugins: Dict[str, ToolConfig] = Field(default_factory=dict, alias=TOOL_TYPE_PLUGINS)


class ToolManagerConfig(BaseModel):
    """Top-level configuration for the tool manager"""
    version: str
    schema_version: str = "1.0.0"
    metadata: Optional[ToolMetadata] = None
    tools: ToolsConfig

    @classmethod
    def create_default(cls) -> "ToolManagerConfig":
        """
        Create a default configuration with all default tools
        
        This method creates a new configuration with the current timestamp
        and populates it with all tools from SYSTEM_DEFAULT_TOOL_CONFIGS.
        """
        now = datetime.now().isoformat()
        
        # Create base config with empty tools
        config = cls(
            version="1.0",
            schema_version="1.0.0",
            metadata=ToolMetadata(
                created_at=now,
                last_modified=now,
                managed_by="coda-core"
            ),
            tools=ToolsConfig()
        )
        
        # Populate with default tools
        for tool_type, tools in SYSTEM_DEFAULT_TOOL_CONFIGS.items():
            for tool_name, tool_info in tools.items():
                # Extract tool configuration
                tool_config = tool_info["config"].copy()
                
                # Add to the appropriate tool type
                if not hasattr(config.tools, tool_type):
                    continue
                
                getattr(config.tools, tool_type)[tool_name] = ToolConfig(**tool_config)
        
        return config


# Define default tool configurations
SYSTEM_DEFAULT_TOOL_CONFIGS = {
    TOOL_TYPE_BASIC: {
        "view": {
            "tool_class": ViewTool,
            "config": {
                "category": TOOL_CATEGORY_FILE_OPERATIONS,
                "enabled": True
            }
        },
        "think": {
            "tool_class": ThinkTool,
            "config": {
                "category": TOOL_CATEGORY_REASONING,
                "enabled": True
            }
        }
    },
    TOOL_TYPE_EXTENDED: {
        "replace": {
            "tool_class": ReplaceTool,
            "config": {
                "category": TOOL_CATEGORY_FILE_OPERATIONS,
                "enabled": True
            }
        },
        "bash": {
            "tool_class": BashTool,
            "config": {
                "category": TOOL_CATEGORY_SYSTEM,
                "enabled": True
            }
        },
        "edit": {
            "tool_class": EditTool,
            "config": {
                "category": TOOL_CATEGORY_FILE_OPERATIONS,
                "enabled": True
            }
        },
        "web_search": {
            "tool_class": WebSearchTool,
            "config": {
                "category": TOOL_CATEGORY_EXTERNAL,
                "enabled": True
            }
        },
        "ask_user": {
            "tool_class": AskUserTool,
            "config": {
                "category": TOOL_CATEGORY_SYSTEM,
                "enabled": True
            }
        },
        "examine_images": {
            "tool_class": ExamineImagesTool,
            "config": {
                "category": TOOL_CATEGORY_EXTERNAL,
                "enabled": True
            }
        },
        "omni_parser": {
            "tool_class": OmniParserTool,
            "config": {
                "category": TOOL_CATEGORY_EXTERNAL,
                "enabled": True
            }
        },
        "run_skill": {
            "tool_class": RunSkillTool,
            "config": {
                "category": TOOL_CATEGORY_EXTERNAL,
                "enabled": True
            }
        }
    },
    TOOL_TYPE_MCP: {
        "mcp_execute": {
            "tool_class": MCPExecuteTool,
            "config": {
                "category": TOOL_CATEGORY_EXTERNAL,
                "enabled": True
            }
        }
    },
    TOOL_TYPE_EXPERIMENTAL: {
        "create_plan_tool": {
            "tool_class": CreatePlanTool,
            "config": {
                "category": TOOL_CATEGORY_REASONING,
                "enabled": False
            }
        },
        "approve_plan_tool": {
            "tool_class": ApprovePlanTool,
            "config": {
                "category": TOOL_CATEGORY_REASONING,
                "enabled": False
            }
        },
        "mark_step_tool": {
            "tool_class": MarkStepTool,
            "config": {
                "category": TOOL_CATEGORY_REASONING,
                "enabled": False
            }
        },
        "update_plan_tool": {
            "tool_class": UpdatePlanTool,
            "config": {
                "category": TOOL_CATEGORY_REASONING,
                "enabled": False
            }
        },
        "mark_plan_as_pending_tool": {
            "tool_class": MarkPlanAsPendingTool,
            "config": {
                "category": TOOL_CATEGORY_REASONING,
                "enabled": False
            }
        },
        "load_plan_tool": {
            "tool_class": LoadPlanTool,
            "config": {
                "category": TOOL_CATEGORY_REASONING,
                "enabled": False
            }
        }
    }
}
