from typing import Dict, Any

from loguru import logger

from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.tools.mcp_execute.description import MCP_EXECUTE_TOOL_DESC, MCP_EXECUTE_TOOL_SHORT_DESC
from coda_core.core.tools.mcp_execute.functions import execute_mcp_tool
from coda_core.core.mcp.service import MCPService


class MCPExecuteTool(FunctionTool):
    """
    Tool for executing any MCP server tool.
    
    This tool provides a unified interface that can dispatch to any MCP tool
    across all connected servers. It dynamically generates comprehensive
    descriptions including all available MCP tools and their schemas.
    """
    
    name: str = "mcp_execute"
    short_description: str = MCP_EXECUTE_TOOL_SHORT_DESC
    
    def __init__(self, **kwargs):
        """Initialize the MCP execute tool."""
        super().__init__(
            name=self.name,
            description=MCP_EXECUTE_TOOL_DESC,
            short_description=self.short_description,
            function=execute_mcp_tool,
        )
        
        # Log the initialization details
        logger.info("Initialized MCPExecuteTool")
    
    @property 
    def description(self) -> str:
        """Dynamic description that includes current tool information."""
        return MCP_EXECUTE_TOOL_DESC + "\n\n" + self._generate_comprehensive_description()
    
    @description.setter
    def description(self, value: str) -> None:
        """Setter for description - allows base class to set initial value."""
        # We ignore the set value and always use the dynamic description
        pass
    
    def _generate_comprehensive_description(self) -> str:
        """Generate comprehensive description including all available MCP tools and their schemas."""
        try:
            # Get the MCP service instance
            mcp_service = MCPService.get()
            
            # Ensure MCP service is initialized and connected
            if not mcp_service.is_available():
                logger.debug("MCP service not available during tool initialization, trying to initialize...")
                mcp_service.initialize()
            
            # Try to ensure connections are established
            if mcp_service.is_available():
                mcp_service._ensure_connected()
            
            # Get detailed tool information
            detailed_info = mcp_service.get_detailed_tool_info()
            
            return detailed_info
            
        except Exception as e:
            logger.error(f"Error generating comprehensive MCP tool description: {e}")
            # Fallback to empty string since base description is handled in property
            return ""
    
    def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute the MCP tool.
        
        Args:
            **kwargs: Arguments to pass to the tool's function.
            
        Returns:
            Dict[str, Any]: The result of the tool execution.
        """
        try:
            # Use base class parameter validation
            self._validate_parameters(self.function, kwargs)
            
            # Filter out reserved arguments before calling the function
            filtered_kwargs = self._filter_reserved_arguments(kwargs)
            
            # Call the function with the filtered arguments
            return self.function(**filtered_kwargs)
            
        except ParameterError as e:
            # Log and re-raise parameter errors
            logger.error(f"Parameter error in MCP tool: {e}")
            raise
        except Exception as e:
            logger.error(f"Error executing MCP tool: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def is_available(self) -> bool:
        """
        Check if MCP functionality is available.
        
        Returns:
            bool: True if MCP service is available
        """
        try:
            mcp_service = MCPService.get()
            return mcp_service.is_available()
        except Exception:
            return False