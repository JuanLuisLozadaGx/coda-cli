MCP_EXECUTE_TOOL_SHORT_DESC = "The mcp_execute allows executing any configured MCP server"

MCP_EXECUTE_TOOL_DESC = """Execute any tool from any configured MCP server.
Specify the server name and tool name as separate parameters.

To use any MCP tool, call the mcp_execute function with server_name, tool_name and arguments as parameters."""