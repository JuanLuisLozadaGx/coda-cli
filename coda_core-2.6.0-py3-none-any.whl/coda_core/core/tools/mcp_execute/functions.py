from typing import Annotated, Dict, Any, Optional
from loguru import logger

from coda_core.core.mcp.service import MCPService
from coda_core.core.tools.function_tool import ParameterError


def execute_mcp_tool(
    server_name: Annotated[str, "Name of the MCP server to call (e.g. 'github', 'zapier')"],
    tool_name: Annotated[str, "Name of the tool to execute on the server (e.g. 'get_file', 'create_issue')"], 
    arguments: Annotated[Optional[Dict[str, Any]], "Arguments to pass to the MCP tool"] = None
) -> Dict[str, Any]:
    """
    Execute an MCP tool through the centralized service.
    
    This function provides access to all available MCP tools across configured servers.
    It dynamically generates comprehensive documentation including available servers and tools.
    
    Args:
        server_name: Name of the MCP server
        tool_name: Name of the tool to execute  
        arguments: Optional arguments for the tool
        
    Returns:
        Dict containing execution result with success status and data or error information
    """
    try:
        # Validate inputs
        if not server_name or not isinstance(server_name, str):
            raise ParameterError("Server name must be a non-empty string")
        if not tool_name or not isinstance(tool_name, str):
            raise ParameterError("Tool name must be a non-empty string")
        
        # Get the MCP service instance
        mcp_service = MCPService.get()
        
        # Execute the tool using the current session ID
        result = mcp_service.execute(server_name, tool_name, arguments or {}, session_id=mcp_service.current_session_id or "default")
        
        logger.debug(f"MCP tool executed: {server_name}::{tool_name} -> success={result.get('success', False)}")
        return result
        
    except ParameterError as e:
        # Handle validation errors
        error_msg = f"Invalid parameters: {e}"
        logger.error(error_msg)
        raise
    except Exception as e:
        # Handle unexpected errors
        error_msg = f"Unexpected error executing MCP tool '{server_name}::{tool_name}': {e}"
        logger.error(error_msg)
        return {
            "success": False,
            "error": error_msg
        }