from typing import Dict, List, Optional, Type, Any
from loguru import logger

from coda_core.core.tools.base import Tool


class ToolRegistry:
    """Centralized registry for all available tools"""
    
    def __init__(self) -> None:
        """
        Initialize a new ToolRegistry instance.
        
        Creates empty dictionaries for storing tool instances, tool classes,
        and default dependencies for dependency injection.
        """
        self._tools: Dict[str, Tool] = {}
        self._tool_classes: Dict[str, Type[Tool]] = {}
        self._default_dependencies: Dict[str, Any] = {}
        self._tool_dependencies: Dict[str, Dict[str, Any]] = {}


    def register_dependency(self, name: str, dependency: Any) -> None:
        """
        Register a default dependency that will be available to all tools.
        
        Args:
            name: The name of the dependency
            dependency: The dependency object
        """
        self._default_dependencies[name] = dependency


    def register_tool_dependency(self, tool_name: str, dep_name: str, dependency: Any) -> None:
        """
        Register a dependency for a specific tool.
        
        Args:
            tool_name: The name of the tool
            dep_name: The name of the dependency
            dependency: The dependency object
        """
        if tool_name not in self._tool_dependencies:
            self._tool_dependencies[tool_name] = {}
        
        self._tool_dependencies[tool_name][dep_name] = dependency


    def register_tool(self, tool: Tool) -> bool:
        """
        Register a tool instance in the registry.
        
        Args:
            tool: The tool instance to register
            
        Returns:
            bool: True if registration was successful, False otherwise
        """
        if not isinstance(tool, Tool):
            logger.error(f"Cannot register tool: must be an instance of Tool class, got {type(tool)}")
            return False
        
        try:
            # Check if a tool instance with this name is already registered
            if tool.name in self._tools:
                existing_tool = self._tools[tool.name]
                if type(existing_tool) != type(tool):
                    logger.warning(f"Overwriting existing tool instance '{tool.name}' "
                                  f"({type(existing_tool).__name__}) with {type(tool).__name__}")
            
            self._tools[tool.name] = tool
            logger.info(f"Registered tool instance: {tool.name}")
            return True
        except Exception as e:
            logger.error(f"Failed to register tool instance '{tool.name}': {str(e)}")
            return False


    def register_tool_class(self, name: str, tool_class: Type[Tool]) -> bool:
        """
        Register a tool class for lazy instantiation.
        
        Args:
            name: The name to register the tool class under
            tool_class: The tool class to register
            
        Returns:
            bool: True if registration was successful, False otherwise
        """
        if not issubclass(tool_class, Tool):
            logger.error(f"Cannot register tool class: must be a subclass of Tool, got {tool_class}")
            return False
        
        try:
            # Check if a tool with this name is already registered
            if name in self._tool_classes:
                existing_class = self._tool_classes[name]
                if existing_class != tool_class:
                    logger.warning(f"Overwriting existing tool class '{name}' "
                                  f"({existing_class.__name__}) with {tool_class.__name__}")
            
            self._tool_classes[name] = tool_class
            logger.info(f"Registered tool class: {name} -> {tool_class.__name__}")
            return True
        except Exception as e:
            logger.error(f"Failed to register tool class '{name}': {str(e)}")
            return False


    def get_tool(self, name: str, **kwargs) -> Optional[Tool]:
        """
        Get a tool by name, instantiating if needed.
        
        If the tool is already instantiated and no kwargs are provided, returns the instance.
        If only the class is registered or kwargs are provided, instantiates the tool with
        dependencies from:
        1. Default dependencies for all tools
        2. Tool-specific dependencies
        3. Explicitly provided kwargs
        
        Args:
            name: The name of the tool to retrieve
            **kwargs: Arguments to pass to the tool constructor if instantiation is needed
            
        Returns:
            The tool instance if found or successfully instantiated, None otherwise
        """
        # If we have an instance and no new dependencies are provided, return the cached instance
        if name in self._tools and not kwargs:
            return self._tools[name]
        
        # If we need to instantiate or reconfigure with dependencies
        if name in self._tool_classes:
            try:
                tool_class = self._tool_classes[name]
                
                # Prepare dependencies in order of precedence:
                # 1. Start with default dependencies
                merged_kwargs = self._default_dependencies.copy()
                
                # 2. Add tool-specific dependencies if available
                if name in self._tool_dependencies:
                    merged_kwargs.update(self._tool_dependencies[name])
                
                # 3. Finally add explicitly provided dependencies (highest precedence)
                merged_kwargs.update(kwargs)
                
                # Instantiate with merged dependencies
                tool = tool_class(**merged_kwargs)
                
                # Always cache the instance, treating it as a reconfiguration if needed
                self._tools[name] = tool
                return tool
            except Exception as e:
                logger.error(f"Failed to instantiate tool '{name}': {str(e)}")
                return None
        
        logger.warning(f"Tool '{name}' not found in registry")
        return None


    def list_tools(self) -> List[str]:
        """
        List all available tool names.
        
        Returns:
            A list of all registered tool names (both instances and classes)
        """
        return list(set(self._tools.keys()) | set(self._tool_classes.keys()))


    def get_all_tools(self) -> List[Tool]:
        """
        Get all registered tools, instantiating as needed.
        
        Returns:
            A list of all tool instances, instantiating any registered classes
        """
        try:
            tools = []
            tool_names = self.list_tools()
            logger.info(f"Instantiating {len(tool_names)} registered tools")
            
            for name in tool_names:
                tool = self.get_tool(name)
                if tool:
                    tools.append(tool)
                else:
                    logger.warning(f"Failed to instantiate tool '{name}'")
            
            return tools
        except Exception as e:
            logger.error(f"Failed to get all tools: {str(e)}")
            return []


    def unregister_tool(self, name: str) -> bool:
        """
        Unregister a tool by name.
        
        Removes the tool from both the instances and classes dictionaries if present.
        
        Args:
            name: The name of the tool to unregister
            
        Returns:
            True if the tool was found and removed, False otherwise
        """
        removed = False
        
        if name in self._tools:
            del self._tools[name]
            removed = True
        
        if name in self._tool_classes:
            del self._tool_classes[name]
            removed = True
        
        if removed:
            logger.info(f"Unregistered tool: '{name}'")
        
        return removed


    def clear(self) -> bool:
        """
        Clear all registered tools.
        
        Removes all tool instances and classes from the registry.
        
        Returns:
            bool: True if clearing was successful, False otherwise
        """
        try:
            self._tools.clear()
            self._tool_classes.clear()
            logger.info("Cleared all tools from registry")
            return True
        except Exception as e:
            logger.error(f"Failed to clear tool registry: {str(e)}")
            return False


    def get_tool_info(self, name: str) -> Optional[Dict[str, str]]:
        """
        Get basic information about a tool.
        
        Args:
            name: The name of the tool to get information for
            
        Returns:
            A dictionary with tool information if found, None otherwise
        """
        try:
            tool = self.get_tool(name)
            if tool:
                return {
                    "name": tool.name,
                    "description": tool.description,
                    "short_description": tool.short_description,
                    "type": tool.__class__.__name__
                }
            logger.debug(f"Cannot get tool info: tool '{name}' not found or could not be instantiated")
            return None
        except Exception as e:
            logger.error(f"Failed to get tool info for '{name}': {str(e)}")
            return None