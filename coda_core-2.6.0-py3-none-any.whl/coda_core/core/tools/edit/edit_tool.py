from typing import Callable, Optional, Dict

from loguru import logger

from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.tools.edit.description import EDIT_TOOL_DESC, EDIT_TOOL_SHORT_DESC
from coda_core.core.tools.edit.functions import execute_edit
from coda_core.core.filesystem_ops.file_editor import FileEditor

class EditTool(FunctionTool):
    """
    A tool for editing files by encapsulating a name, description, and an execution function.

    Attributes:
        name (str): The name of the tool, defaulting to "edit".
        description (str): A detailed description of the tool's capabilities.
        short_description (str): A brief description of the tool.
        function (Callable): A callable function that executes the editing operation.
        editor (FileEditor): An instance of FileEditor used to perform file operations.
    """
    
    name: str = "edit"
    description: str = EDIT_TOOL_DESC
    short_description: str = EDIT_TOOL_SHORT_DESC
    function: Callable = execute_edit


    def __init__(self, name: str = name, description: str = description, short_description: str = short_description, function: Callable = function, editor: Optional[FileEditor] = None):
        """
        Initialize an EditTool instance.

        Args:
            name (str): The name of the tool. Defaults to "edit".
            description (str): The description of the tool's functionality.
            short_description (str): A brief description of the tool.
            function (Callable): The function that executes the tool's primary action, specifically editing files.
            editor (FileEditor): An instance of FileEditor used to perform file operations.
        """
        super().__init__(
            name=name,
            description=description,
            short_description=short_description,
            function=function,
        )
        self.editor = editor if editor else FileEditor()

        # Log the initialization details
        logger.info(f"Initialized EditTool")

    
    def execute(self, **kwargs) -> Dict[str, any]:
        """
        Execute the edit function using the internal FileEditor instance.

        Args:
            file_path (str): The absolute path to the file to read.
            old_string (str): The text to replace.
            new_string (str): The text to replace it with.

        Returns:
            Dict[str, any]: A dictionary containing the status of the operation, the file path, and the result or error message.
            
        Raises:
            ParameterError: If there are issues with the provided parameters.
        """
        try:
            # Validate parameters against the function signature, excluding the editor parameter
            self._validate_parameters(execute_edit, kwargs)
            
            # Filter out reserved arguments before calling the function
            filtered_kwargs = self._filter_reserved_arguments(kwargs)
            
            # Call the function with the filtered arguments
            return execute_edit(self.editor, **filtered_kwargs)
            
        except ParameterError as e:
            # Log and re-raise parameter errors
            logger.error(f"Parameter error in {self.name} tool: {e}")
            raise
        except Exception as e:
            # Log other exceptions
            logger.exception(f"Error executing function {self.name}: {e}")
            return {"status": "error", "message": str(e)}