from typing import Annotated, Any, Dict

from loguru import logger

from coda_core.core.filesystem_ops.file_editor import FileEditor

def execute_edit(
    editor: FileEditor,
    file_path: Annotated[str, "The absolute path to the file to modify"],
    old_string: Annotated[str, "The text to replace"],
    new_string: Annotated[str, "The text to replace it with"]
) -> Dict[str, Any]:
    """
    Edits a file by replacing one string with another using the FileEditor instance.

    Args:
        editor (FileEditor): An instance of FileEditor used to perform the string replacement.
        file_path (str): The absolute path to the file to be modified.
        old_string (str): The text that needs to be replaced in the file.
        new_string (str): The text to replace the old string with.

    Returns:
        Dict[str, Any]: A dictionary containing the status of the operation, the file path, and the result or error message.
        If successful, the dictionary will contain details of the operation.
        In case of an error, it will contain the error message and status as "error".
    """
    try:
        return editor.str_replace(file_path, old_string, new_string)
    except Exception as e:
        logger.error(f"Failed to edit file {file_path}: {e}")
        return {"status": "error", "file": file_path, "message": str(e)}
