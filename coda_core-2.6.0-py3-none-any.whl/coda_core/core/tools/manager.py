import json
import os
import uuid
import copy
import portalocker
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Any, Optional, Type
from loguru import logger
from pydantic import ValidationError

from coda_core.core.tools.registry import ToolRegistry
from coda_core.core.tools.base import Tool
from coda_core.core.tools.constants import (
    TOOL_TYPES,
    TOOL_TYPE_BASIC
)
from coda_core.core.tools.schemas import ToolManagerConfig
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig

from coda_core.core.tools.schemas import SYSTEM_DEFAULT_TOOL_CONFIGS

class ToolManager:
    """Manages tool registration and configuration for the CODA Core system"""
    
    def __init__(self, config_id: Optional[str] = None) -> None:
        """
        Initialize the ToolManager with registry and configuration
        
        Args:
            config_id: Optional configuration ID for tool configuration.
                If provided, uses this ID to determine the configuration file path.
                If not provided, generates a new UUID.
        
        Loads the tool configuration from the appropriate file
        or creates a default configuration if none exists.
        """
        self.registry = ToolRegistry()
        self.config_id = config_id if config_id else str(uuid.uuid4())
        
        self._load_config()


    @property
    def config_file_path(self) -> Path:
        """
        Get the configuration file path based on config ID
        
        Returns:
            Path: The path to the configuration file
        """
        # Get the tools directory path from Settings
        tools_dir = Path(SETTINGS.get_env_var(EnvConfig.CODA_TOOLS_DIR_PATH))
        
        # Use the config ID to create a unique configuration file path
        return tools_dir / f"{self.config_id}_tools.json"


    @property
    def global_default_config_file_path(self) -> Path:
        """
        Get the global default configuration file path
        
        Returns:
            Path: The path to the global default configuration file
        """
        # Get the tools directory path from Settings
        tools_dir = Path(SETTINGS.get_env_var(EnvConfig.CODA_TOOLS_DIR_PATH))
        
        # Return the global default configuration file path
        return tools_dir / "global_default_tools.json"


    def _load_config(self) -> None:
        """
        Load tool configuration from JSON file with file locking
        
        Attempts to read and parse the configuration file.
        If the file doesn't exist or can't be parsed, creates a default configuration.
        Validates the configuration using Pydantic.
        Uses portalocker for safe concurrent access.
        """
        # Determine the configuration file path
        config_path = self.config_file_path
        
        if config_path.exists():
            try:
                with open(config_path, 'r') as f:
                    portalocker.lock(f, portalocker.LOCK_SH)
                    config_data = json.load(f)
                
                # Validate configuration
                if self._validate_config(config_data):
                    # Convert to Pydantic model and back to ensure proper structure
                    validated_config = ToolManagerConfig(**config_data)
                    self.config = validated_config.model_dump()
                    logger.info(f"Loaded and validated tool config from {config_path}")
                    
                    # Load and register tools from the configuration
                    self.load_tools_from_config()
                else:
                    logger.warning("Invalid configuration structure. Creating default config.")
                    self._create_default_config()
            except Exception as e:
                logger.error(f"Failed to load tool configuration: {str(e)}")
                logger.info("Creating default configuration")
                self._create_default_config()
        else:
            logger.warning(f"No existing tool config found at {SETTINGS.get_env_var(EnvConfig.CODA_TOOLS_DIR_PATH)}")
            self._create_default_config()


    def _validate_config(self, config: Dict[str, Any]) -> bool:
        """
        Validate configuration using Pydantic
        
        Args:
            config: Configuration dictionary to validate
            
        Returns:
            bool: True if configuration is valid, False otherwise
        """
        try:
            ToolManagerConfig(**config)
            return True
        except ValidationError as e:
            logger.error(f"Configuration validation failed: {str(e)}")
            return False
    
    
    def _create_default_config(self) -> None:
        """
        Create default configuration structure
        
        Priority order:
        1. Global default configuration (if exists) + merge new tools from SYSTEM_DEFAULT_TOOL_CONFIGS
        2. System SYSTEM_DEFAULT_TOOL_CONFIGS
        
        Initializes a new configuration with default values and structure,
        ensuring a valid configuration. Also registers default tools and
        saves the configuration to disk.
        """
        # Try to load global default first
        global_default = self.load_global_default_config()
        
        if global_default:
            # Merge new tools from SYSTEM_DEFAULT_TOOL_CONFIGS while preserving user customizations
            self.config = self._merge_with_default_configs(global_default)
            logger.info("Created configuration from global default with new tools merged")
        else:
            # Fall back to system defaults
            default_config = ToolManagerConfig.create_default()
            self.config = default_config.model_dump()
            logger.info("Created default tool configuration from system defaults")
        
        # Filter out deprecated tools
        self.config = self._filter_deprecated_tools(self.config)
        
        # Register default tools for new configurations
        self.register_default_tools()
        
        # Save the configuration to disk
        self._save_config()


    def _update_metadata(self) -> None:
        """
        Update metadata when config changes
        
        Updates the last_modified timestamp in the configuration metadata
        to reflect the current time in UTC.
        """
        # Ensure metadata exists
        if "metadata" not in self.config:
            self.config["metadata"] = {}
            
        self.config["metadata"]["last_modified"] = datetime.now(timezone.utc).isoformat()


    def _save_config(self) -> None:
        """
        Save tool configuration to JSON file with file locking
        
        Validates the configuration with Pydantic before saving.
        Writes the current configuration to the specified file path
        with proper formatting (indentation). Uses portalocker for safe concurrent access.
        """
        try:
            # Validate configuration before saving
            if not self._validate_config(self.config):
                logger.error("Invalid configuration structure, not saving configuration")
                return
            
            # Determine the configuration file path
            config_path = self.config_file_path
            
            with open(config_path, 'w') as f:
                portalocker.lock(f, portalocker.LOCK_EX)
                json.dump(self.config, f, indent=2)
            logger.info(f"Saved tool config to {config_path}")
        except Exception as e:
            logger.error(f"Failed to save tool configuration: {str(e)}")


    def register_tool(self, tool_name: str, tool_class: Type[Tool], tool_type: str,
                 tool_category: str, enabled: bool = True, save_config: bool = True, **metadata) -> bool:
        """
        Register a tool in the specified type
        
        Args:
            tool_name: Name of the tool
            tool_class: The tool class to register
            tool_type: Type of tool to add (TOOL_TYPE_BASIC, TOOL_TYPE_EXTENDED, TOOL_TYPE_EXPERIMENTAL, etc.)
            tool_category: Functional category of the tool (TOOL_CATEGORY_SYSTEM, TOOL_CATEGORY_FILE_OPERATIONS, etc.)
            enabled: Whether the tool is enabled by default
            save_config: Whether to save the configuration after registration
            **metadata: Additional metadata for this specific tool
            
        Returns:
            bool: True if registration was successful, False otherwise
        """
        if tool_type not in TOOL_TYPES:
            logger.error(f"Invalid tool type '{tool_type}'. Valid types: {TOOL_TYPES}")
            return False
            
        try:
            if not self.registry.register_tool_class(tool_name, tool_class):
                return False
            
            # Configuration management
            tool_config = {
                "enabled": enabled,
                "category": tool_category  # Functional category of the tool
            }
            
            # Add any additional metadata
            tool_config.update(metadata)
            
            # Add to config
            self.config["tools"][tool_type][tool_name] = tool_config
            
            self._update_metadata()
            
            # Only save config if requested
            if save_config:
                self._save_config()
                
            logger.info(f"Registered {tool_type} tool: {tool_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to register {tool_type} tool '{tool_name}': {str(e)}")
            return False


    def register_default_tools(self) -> None:
        """
        Register all default tools
        
        Registers the standard set of default tools with their appropriate
        configurations using the SYSTEM_DEFAULT_TOOL_CONFIGS defined in schemas.py.
        Only adds tools to the configuration if they don't already exist there.
        
        Raises:
            Exception: If registration of any default tool fails
        """
        try:
            # Register tools from each tool type
            for tool_type, tools in SYSTEM_DEFAULT_TOOL_CONFIGS.items():
                for tool_name, tool_info in tools.items():
                    tool_class = tool_info["tool_class"]
                    config = tool_info["config"].copy()
                    
                    # Extract tool_category from config
                    tool_category = config.pop("category", "unknown")
                    
                    # Only register if not already in config
                    if tool_name not in self.config["tools"][tool_type]:
                        self.register_tool(tool_name, tool_class, tool_type, tool_category, save_config=False, **config)
                    else:
                        # Just register the class without modifying config
                        self.registry.register_tool_class(tool_name, tool_class)
            
            # Save configuration once after all tools are registered
            self._save_config()
            logger.info("Registered all default tools")
            
        except Exception as e:
            logger.error(f"Failed to register default tools: {str(e)}")
            raise


    def unregister_tool(self, tool_name: str) -> bool:
        """
        Unregister a tool from both registry and config
        
        Args:
            tool_name: Name of the tool to unregister
            
        Returns:
            bool: True if the tool was successfully unregistered, False otherwise
        """
        tool_type = self._find_tool_type(tool_name)
        if not tool_type:
            logger.warning(f"Cannot unregister tool '{tool_name}' - not found in any category")
            return False
        
        # Prevent unregistering BASIC tools
        if tool_type == TOOL_TYPE_BASIC:
            logger.warning(f"Cannot unregister tool '{tool_name}' - basic tools cannot be removed")
            return False
        
        try:
            # Delegate unregistration to registry
            if not self.registry.unregister_tool(tool_name):
                logger.warning(f"Tool '{tool_name}' not found in registry but was in configuration")
            
            # Check if the tool exists in the configuration before removing it
            if tool_type in self.config["tools"] and tool_name in self.config["tools"][tool_type]:
                # Remove from config
                del self.config["tools"][tool_type][tool_name]
                self._update_metadata()
                self._save_config()
                
                logger.info(f"Unregistered tool: {tool_name}")
                return True
            else:
                logger.warning(f"Tool '{tool_name}' not found in configuration")
                return False
            
        except Exception as e:
            logger.error(f"Failed to unregister tool '{tool_name}': {str(e)}")
            return False


    def get_enabled_tool_names(self) -> List[str]:
        """
        Get names of all enabled tools from all categories.
        
        Collects the names of all tools that are marked as enabled
        across all categories in the configuration.
        Basic tools are always included regardless of their enabled state.
        
        Returns:
            List[str]: List of enabled tool names
        """
        enabled_tools = []
        
        for category in TOOL_TYPES:
            # Check if the category exists in the configuration
            if category in self.config["tools"]:
                tools = self.config["tools"][category]
                
                if category == TOOL_TYPE_BASIC:
                    # For basic tools, include all regardless of enabled state
                    # This ensures basic tools are always active even if config is tampered with
                    enabled_tools.extend(tools.keys())
                else:
                    # For other categories, only include enabled tools
                    enabled_tools.extend([name for name, config in tools.items()
                                        if config.get("enabled", True)])
            else:
                logger.warning(f"Tool category '{category}' not found in configuration")
        
        return enabled_tools


    def _find_tool_type(self, tool_name: str) -> Optional[str]:
        """
        Find which config category a tool belongs to
        
        Args:
            tool_name: Name of the tool to find
            
        Returns:
            Optional[str]: Config category name if found, None otherwise
        """
        for tool_type in TOOL_TYPES:
            # Check if the tool type exists in the configuration
            if tool_type in self.config["tools"] and tool_name in self.config["tools"][tool_type]:
                return tool_type
        return None


    def get_enabled_tools(self, **kwargs) -> List[Tool]:
        """
        Get all enabled tools, instantiating as needed.
        
        This method:
        1. Gets the list of enabled tool names
        2. Instantiates each tool, passing any provided dependencies
        
        Args:
            **kwargs: Dependencies to pass to tool constructors
            
        Returns:
            List[Tool]: List of instantiated tool objects
        """
        enabled_tool_names = self.get_enabled_tool_names()
        
        tools = []
        for tool_name in enabled_tool_names:
            tool = self.registry.get_tool(tool_name, **kwargs)
            
            if tool:
                tools.append(tool)
            else:
                logger.warning(f"Enabled tool '{tool_name}' could not be instantiated - check registry")
        
        logger.debug(f"Returning {len(tools)} enabled tools")
        return tools

    def get_tools(self, agent_tools: Optional[List[str]] = None, **kwargs) -> List[Tool]:
        """
        Return instantiated tools, optionally filtered by `agent_tools`.

        Semantics:
        - agent_tools is None: return all enabled tools (default behavior).
        - agent_tools is []: return no tools (explicitly disable tools).
        - agent_tools is ["name", ...]: return only the intersection of enabled tools and the requested names.
        """

        if agent_tools is None:
            return self.get_enabled_tools(**kwargs)

        enabled_tool_names = set(self.get_enabled_tool_names())
        requested_tool_names = [name for name in agent_tools if name in enabled_tool_names]

        missing = set(agent_tools) - enabled_tool_names
        if missing:
            logger.warning(f"Requested tools not enabled or unavailable: {', '.join(sorted(missing))}")

        tools: List[Tool] = []
        for tool_name in requested_tool_names:
            tool = self.registry.get_tool(tool_name, **kwargs)
            if tool:
                tools.append(tool)
            else:
                logger.warning(f"Requested tool '{tool_name}' could not be instantiated from registry")

        logger.debug(f"Returning {len(tools)} requested tools out of {len(agent_tools)} requested")
        return tools


    def enable_tool(self, tool_name: str) -> bool:
        """
        Enable a specific tool
        
        Args:
            tool_name: Name of the tool to enable
            
        Returns:
            bool: True if the tool was successfully enabled, False otherwise
        """
        if tool_name not in self.registry.list_tools():
            logger.error(f"Cannot enable tool '{tool_name}' - not registered in system")
            return False
        
        tool_type = self._find_tool_type(tool_name)
        if tool_type:
            self.config["tools"][tool_type][tool_name]["enabled"] = True
            self._update_metadata()
            self._save_config()
            logger.info(f"Enabled tool: {tool_name}")
            return True
        else:
            logger.warning(f"Cannot enable tool '{tool_name}' - not found in configuration")
            return False
    
    
    def disable_tool(self, tool_name: str) -> bool:
        """
        Disable a specific tool
        
        Args:
            tool_name: Name of the tool to disable
            
        Returns:
            bool: True if the tool was successfully disabled, False otherwise
        """
        tool_type = self._find_tool_type(tool_name)
        
        # Prevent disabling BASIC tools
        if tool_type == TOOL_TYPE_BASIC:
            logger.warning(f"Cannot disable tool '{tool_name}' - basic tools cannot be disabled")
            return False
            
        if tool_type:
            self.config["tools"][tool_type][tool_name]["enabled"] = False
            self._update_metadata()
            self._save_config()
            logger.info(f"Disabled tool: {tool_name}")
            return True
        else:
            logger.warning(f"Cannot disable tool '{tool_name}' - not found in configuration")
            return False


    def is_tool_enabled(self, tool_name: str) -> bool:
        """
        Check if a tool is enabled
        
        Args:
            tool_name: Name of the tool to check
            
        Returns:
            bool: True if the tool exists and is enabled, False otherwise
            Note: Basic tools are always considered enabled regardless of config
        """
        tool_type = self._find_tool_type(tool_name)
        if tool_type:
            # Basic tools are always enabled regardless of their config
            # This protects against configuration tampering
            if tool_type == TOOL_TYPE_BASIC:
                return True
            
            # For other tool types, check the enabled state in config
            return self.config["tools"][tool_type][tool_name].get("enabled", True)
        return False


    def list_enabled_tools(self) -> List[str]:
        """
        List all enabled tool names
        
        Returns:
            List[str]: List of names of all enabled tools
        """
        return self.get_enabled_tool_names()


    def get_tool_info(self, tool_name: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a specific tool
        
        Retrieves tool information from the registry and adds
        the enabled status from the configuration.
        
        Args:
            tool_name: Name of the tool to get information about
            
        Returns:
            Optional[Dict[str, Any]]: Tool information if found, None otherwise
        """
        info = self.registry.get_tool_info(tool_name)
        if info:
            info["enabled"] = self.is_tool_enabled(tool_name)
        return info


    def get_config(self) -> Dict[str, Any]:
        """
        Get the current configuration
        
        Returns:
            Dict[str, Any]: A copy of the current tool configuration
        """
        return self.config.copy()


    def register_dependency(self, name: str, dependency: Any) -> None:
        """
        Register a default dependency that will be available to all tools.
        
        Args:
            name: The name of the dependency
            dependency: The dependency object
        """
        self.registry.register_dependency(name, dependency)

        
    def register_tool_dependency(self, tool_name: str, dep_name: str, dependency: Any) -> None:
        """
        Register a dependency for a specific tool.
        
        Args:
            tool_name: The name of the tool
            dep_name: The name of the dependency
            dependency: The dependency object
        """
        self.registry.register_tool_dependency(tool_name, dep_name, dependency)


    def load_tools_from_config(self) -> bool:
        """
        Load and register all tools from the current configuration
        
        This method:
        1. Iterates through all tool types and tools in the configuration
        2. Attempts to find and register each tool class if not already registered
        3. Preserves the enabled/disabled state and other configuration
        
        Returns:
            bool: True if all tools were successfully loaded, False if any failed
        """
        success = True
        
        # Ensure all tool types exist in the configuration
        for tool_type in TOOL_TYPES:
            if tool_type not in self.config["tools"]:
                logger.warning(f"Tool type '{tool_type}' not found in configuration, creating empty category")
                self.config["tools"][tool_type] = {}
        
        # Process each tool type
        for tool_type in TOOL_TYPES:
            # Process each tool in this type
            for tool_name, tool_config in self.config["tools"][tool_type].items():
                # Skip if already registered
                if tool_name in self.registry.list_tools():
                    logger.debug(f"Tool '{tool_name}' already registered, skipping")
                    continue
                    
                # For default tools, try to find in SYSTEM_DEFAULT_TOOL_CONFIGS
                tool_class = None
                for default_type, default_tools in SYSTEM_DEFAULT_TOOL_CONFIGS.items():
                    if tool_name in default_tools:
                        tool_class = default_tools[tool_name]["tool_class"]
                        break
                
                if tool_class:
                    # Extract category from config
                    tool_category = tool_config.get("category", "unknown")
                    
                    # Register the tool class
                    if not self.register_tool(
                        tool_name,
                        tool_class,
                        tool_type,
                        tool_category,
                        tool_config.get("enabled", True)
                    ):
                        logger.error(f"Failed to register tool '{tool_name}' from configuration")
                        success = False
                else:
                    logger.warning(f"Could not find tool class for '{tool_name}' in configuration")
                    success = False
        
        return success

 
    def register_tool_with_dependencies(self, tool_name: str, tool_class: Type[Tool],
                                      tool_type: str, tool_category: str,
                                      dependencies: Dict[str, Any] = None,
                                      enabled: bool = True, **metadata) -> bool:
        """
        Register a tool with its dependencies in a single operation.
        
        This is a convenience method that combines:
        1. Registering the tool class
        2. Registering dependencies for the tool
        
        Args:
            tool_name: Name of the tool
            tool_class: The tool class to register
            tool_type: Type of tool to add (TOOL_TYPE_BASIC, TOOL_TYPE_EXTENDED, etc.)
            tool_category: Functional category of the tool
            dependencies: Dictionary of dependencies for this tool
            enabled: Whether the tool is enabled by default
            **metadata: Additional metadata for this specific tool
            
        Returns:
            bool: True if registration was successful, False otherwise
        """
        # First register the tool class
        if not self.register_tool(tool_name, tool_class, tool_type, tool_category, enabled, **metadata):
            return False
            
        # Then register dependencies if provided
        if dependencies:
            for dep_name, dependency in dependencies.items():
                self.register_tool_dependency(tool_name, dep_name, dependency)
                
        return True


    def update_config(self, new_config: Dict[str, Any]) -> bool:
        """
        Update the configuration
        
        Args:
            new_config: New configuration values to merge with existing config
            
        Returns:
            bool: True if update was successful, False otherwise
        """
        try:
            self.config.update(new_config)
            self._update_metadata()
            self._save_config()
            logger.info("Updated tool configuration")
            return True
        except Exception as e:
            logger.error(f"Failed to update tool configuration: {str(e)}")
            return False


    def reset_config(self) -> bool:
        """
        Reset configuration to defaults
        
        Clears the current configuration and creates a new default configuration.
        
        Returns:
            bool: True if reset was successful, False otherwise
        """
        try:
            self._create_default_config()
            self._save_config()
            logger.info("Reset tool configuration to defaults")
            return True
        except Exception as e:
            logger.error(f"Failed to reset tool configuration: {str(e)}")
            return False


    def load_global_default_config(self) -> Optional[Dict[str, Any]]:
        """
        Load global default configuration with simple file locking
        
        Returns:
            Optional[Dict[str, Any]]: The global default config if valid, None otherwise
        """
        try:
            if not self.global_default_config_file_path.exists():
                logger.debug("Global default config file does not exist")
                return None
                
            with open(self.global_default_config_file_path, 'r') as f:
                # Use shared lock for reading
                portalocker.lock(f, portalocker.LOCK_SH)
                config = json.load(f)
                
            # Validate the loaded config structure
            if not self._validate_config(config):
                logger.warning("Global default config has invalid structure, ignoring")
                return None
                
            logger.info("Successfully loaded global default configuration")
            return config
            
        except json.JSONDecodeError as e:
            logger.error(f"Global default config contains invalid JSON: {e}")
            return None
        except IOError as e:
            logger.error(f"Failed to read global default config file: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error loading global default config: {e}")
            return None


    def _filter_deprecated_tools(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Remove deprecated tools from configuration and notify user
        
        Args:
            config: Configuration to filter
            
        Returns:
            Dict[str, Any]: Filtered configuration
        """
        # Create a deep copy to avoid modifying the original
        filtered_config = copy.deepcopy(config)
        
        # Track removed tools to notify user
        removed_tools = []
        
        # Filter out tools that aren't in SYSTEM_DEFAULT_TOOL_CONFIGS
        for tool_type in list(filtered_config["tools"].keys()):
            if tool_type in SYSTEM_DEFAULT_TOOL_CONFIGS:
                for tool_name in list(filtered_config["tools"][tool_type].keys()):
                    if tool_name not in SYSTEM_DEFAULT_TOOL_CONFIGS[tool_type]:
                        # Tool has been deprecated, remove it
                        del filtered_config["tools"][tool_type][tool_name]
                        removed_tools.append((tool_type, tool_name))
            else:
                # Skip removal of user-defined tool types
                # We only want to remove deprecated tools from known tool types
                continue
        
        # Notify user about removed tools
        if removed_tools:
            tool_names = [f"{t_type}.{t_name}" for t_type, t_name in removed_tools]
            logger.warning(f"Removed deprecated tools from configuration: {', '.join(tool_names)}")
        
        return filtered_config


    def _merge_with_default_configs(self, global_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merge global config with SYSTEM_DEFAULT_TOOL_CONFIGS to add new tools.

        Strategy: Additive only - add new tools from SYSTEM_DEFAULT_TOOL_CONFIGS,
        never remove or modify existing user customizations.
        
        Args:
            global_config: Existing global default configuration
            
        Returns:
            Dict[str, Any]: Merged configuration
        """
        # Create a deep copy to avoid modifying the original
        merged_config = copy.deepcopy(global_config)
        
        # Create a temporary config from SYSTEM_DEFAULT_TOOL_CONFIGS to get new tools
        system_defaults = ToolManagerConfig.create_default().model_dump()

        # For each tool type in SYSTEM_DEFAULT_TOOL_CONFIGS
        for tool_type, tools in system_defaults["tools"].items():
            # Ensure the tool type exists in merged config
            if tool_type not in merged_config["tools"]:
                merged_config["tools"][tool_type] = {}
                
            # Add new tools that don't exist in user's global config
            for tool_name, tool_config in tools.items():
                if tool_name not in merged_config["tools"][tool_type]:
                    merged_config["tools"][tool_type][tool_name] = tool_config
                    logger.info(f"Added new tool '{tool_name}' to global default config")
        
        # Update metadata to reflect the merge
        merged_config["metadata"]["last_modified"] = datetime.now(timezone.utc).isoformat()
        
        return merged_config


    def save_current_config_as_default(self) -> bool:
        """
        Save current configuration as global default with simple file locking
        
        Uses portalocker for direct file locking to prevent corruption during concurrent access
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Create a copy of current config for global default
            global_config = self.config.copy()
            
            # Update metadata for user modification
            if "metadata" not in global_config:
                global_config["metadata"] = {}
                
            global_config["metadata"]["last_modified"] = datetime.now(timezone.utc).isoformat()
            global_config["metadata"]["modified_by"] = "user"
            
            # Ensure the directory exists
            global_config_path = self.global_default_config_file_path
            global_config_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Write directly to the file with locking
            with open(global_config_path, 'w') as f:
                # Lock the file during write
                portalocker.lock(f, portalocker.LOCK_EX)
                
                # Write the configuration
                json_content = json.dumps(global_config, indent=2)
                f.write(json_content)
                f.flush()
                os.fsync(f.fileno())  # Ensure content is written to disk
            
            logger.info(f"Global default tool configuration updated: {global_config_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save global default configuration: {str(e)}")
            return False


    def has_global_default_config(self) -> bool:
        """
        Check if global default configuration exists
        
        Returns:
            bool: True if global default exists and is valid, False otherwise
        """
        return self.global_default_config_file_path.exists()


    def reset_global_default_config(self) -> bool:
        """
        Reset global default to system defaults
        
        Creates a new default configuration with all default tools properly registered
        and saves it as the global default configuration.
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Create a default configuration with all default tools
            default_config = ToolManagerConfig.create_default()
            config_dict = default_config.model_dump()
            
            # Save it as the global default
            global_config_path = self.global_default_config_file_path
            
            with open(global_config_path, 'w') as f:
                portalocker.lock(f, portalocker.LOCK_EX)
                json.dump(config_dict, f, indent=2)
                
            logger.info("Reset global default configuration to system defaults with all default tools")
            return True
            
        except Exception as e:
            logger.error(f"Failed to reset global default configuration: {str(e)}")
            return False


    def has_config_differences(self, target_config: Dict[str, Any]) -> bool:
        """
        Check if there are differences between current and target tool configurations.
        
        This method compares the current tool configuration with a target configuration
        to determine if any changes need to be applied. It checks for:
        1. Tools present in one config but not the other
        2. Tools with different enabled/disabled states
        
        Args:
            target_config: Target tool configuration to compare against
            
        Returns:
            bool: True if there are differences, False otherwise
        """
        current_config = self.get_config()
        
        # Extract tools from current config into a flat dictionary
        current_tools = {}
        for tool_type in current_config["tools"]:
            for tool_name, tool_config in current_config["tools"][tool_type].items():
                current_tools[tool_name] = tool_config.get("enabled", True)
                
        # Extract tools from target config into a flat dictionary
        target_tools = {}
        for tool_type in target_config["tools"]:
            for tool_name, tool_config in target_config["tools"][tool_type].items():
                target_tools[tool_name] = tool_config.get("enabled", True)
        
        # Compare the two dictionaries directly
        # This comparison automatically handles:
        # 1. Tools in current_tools but not in target_tools (different keys)
        # 2. Tools in target_tools but not in current_tools (different keys)  
        # 3. Tools with different enabled states (different values for same keys)
        # Returns True if ANY difference is found, False if configurations are identical
        return current_tools != target_tools
