from typing import Dict, Optional, Callable
from loguru import logger
from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.modes.step_by_step_utilities.schemas import Plan
from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.core.tools.step_by_step_tools.create_plan.description import CREATE_PLAN_TOOL_DESC, CREATE_PLAN_SHORT_DESC
from coda_core.core.tools.step_by_step_tools.create_plan.gpt_description import CREATE_PLAN_TOOL_DESC_GPT, CREATE_PLAN_SHORT_DESC_GPT
from coda_core.core.tools.step_by_step_tools.create_plan.functions import create_plan
from coda_core.config.settings import SETTINGS, EnvConfig

class CreatePlanTool(FunctionTool):
    """Class for managing project plans with markdown and JSON representations."""
    
    name: str = "create_plan"
    description: str = CREATE_PLAN_TOOL_DESC
    short_description: str = CREATE_PLAN_SHORT_DESC
    function: Callable = create_plan

    def __init__(self, 
                 name: str = name, 
                 description: str = None, 
                 short_description: str = None, 
                 function: Callable = function, 
                 editor: Optional[FileEditor] = None,
                 model_name: Optional[str] = None):
        """
        Initialize CreatePlanTool with model-specific descriptions.
        
        Args:
            name: Tool name
            description: Tool description (auto-selected based on model if not provided)
            short_description: Short description (auto-selected based on model if not provided)
            function: The create_plan function
            editor: Optional FileEditor instance
            model_name: Model name in format 'provider/model' (e.g., 'openai/gpt-4', 'anthropic/claude-3')
                       If provider is 'openai' and model contains 'gpt', uses GPT-optimized markdown mode
        """
        # Detect if we should use GPT mode
        self.is_gpt_mode = False
        if model_name:
            # Parse model_name in format "provider/model"
            parts = model_name.split('/')
            
            if len(parts) == 2:
                provider = parts[0].lower()
                model = parts[1].lower()
                
                # Check if it's OpenAI GPT model
                if provider == 'openai' and 'gpt' in model:
                    self.is_gpt_mode = True
                    logger.info(f"CreatePlanTool: GPT mode activated for {model_name}")
            else:
                logger.warning(f"CreatePlanTool: Invalid model_name format '{model_name}', expected 'provider/model'")
        
        # Select appropriate descriptions based on model
        if self.is_gpt_mode:
            final_description = description or CREATE_PLAN_TOOL_DESC_GPT
            final_short_description = short_description or CREATE_PLAN_SHORT_DESC_GPT
        else:
            final_description = description or CREATE_PLAN_TOOL_DESC
            final_short_description = short_description or CREATE_PLAN_SHORT_DESC
        
        super().__init__(
            name=name,
            description=final_description,
            short_description=final_short_description,
            function=function,
        )
        self.editor = editor if editor else FileEditor()
        self.plans_dir = SETTINGS.get_plans_dir()
        self.current_plan: Optional[Plan] = None
        self.model_name = model_name

    def _validate_steps_structure(self, steps) -> bool:
        """
        Validate the structure of the steps parameter (standard mode only).
        
        Args:
            steps: The steps parameter to validate
            
        Returns:
            bool: True if valid, False otherwise
        """
        if steps is None:
            return True
            
        if not isinstance(steps, list):
            logger.error(f"CreatePlanTool: Invalid steps type, expected list, got {type(steps).__name__}")
            return False
        
        for i, step_data in enumerate(steps):
            if not isinstance(step_data, dict):
                logger.warning(f"CreatePlanTool: Step {i} has invalid type, expected dict, got {type(step_data).__name__}")
        
        return True

    def execute(self, **kwargs) -> Dict[str, any]:
        """
        Execute the create_plan function with the provided arguments.
        Handles both GPT mode (markdown) and standard mode (structured data).
        
        Args:
            **kwargs: Arguments to pass to the create_plan function.
                     GPT mode expects: plan_id, markdown_plan
                     Standard mode expects: plan_id, summary, steps
        
        Returns:
            Dict[str, any]: Result from the create_plan function or error information.
            
        Raises:
            ParameterError: If there are issues with the provided parameters.
        """
        try:
            # Validate parameters against the function signature
            self._validate_parameters(create_plan, kwargs)
            
            # Additional validation for standard mode
            if not self.is_gpt_mode and 'steps' in kwargs:
                self._validate_steps_structure(kwargs['steps'])
            
            # Filter out reserved arguments before calling the function
            filtered_kwargs = self._filter_reserved_arguments(kwargs)
            
            # Add editor to filtered kwargs
            filtered_kwargs['editor'] = self.editor
            
            # Call the function with the filtered arguments
            result = create_plan(**filtered_kwargs)
            
            return result
            
        except ParameterError as e:
            logger.error(f"CreatePlanTool: Parameter error - {e}")
            raise
        except Exception as e:
            logger.exception(f"CreatePlanTool: Unexpected error - {e}")
            return {"status": "error", "message": str(e)}
