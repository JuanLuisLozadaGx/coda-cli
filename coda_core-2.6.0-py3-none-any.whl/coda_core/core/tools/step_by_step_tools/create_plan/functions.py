from typing import List, Dict, Any, Tuple, Annotated
from datetime import datetime
import uuid
from loguru import logger
from coda_core.core.modes.step_by_step_utilities.planning_converters import save_plan_files, markdown_to_json
from coda_core.core.modes.step_by_step_utilities.schemas import Plan
from coda_core.config.settings import SETTINGS, EnvConfig


def create_plan(plan_id: Annotated[str, "plan_id is a unique identifier for the plan to be created"], 
                summary: Annotated[str, "Summary of the current plan, objectives and details"] = None, 
                steps: Annotated[List[Dict[str, Any]], "Steps for the current plan with titles and subtasks"] = None,
                markdown_plan: Annotated[str, "Complete plan in markdown format (used for GPT models)"] = None,
                editor = None) -> Tuple[str, Dict[str, Any]]:
        
        """
        Create a new plan with the given ID, summary, and steps.
        
        Supports two modes:
        1. Structured mode (Claude/default): provide summary + steps as list of dicts
        2. Markdown mode (GPT): provide markdown_plan as formatted markdown string
        
        Args:
            plan_id: Unique identifier for the plan
            summary: Summary description of the plan (structured mode)
            steps: Optional list of step dictionaries with titles, subtasks, and dependencies (structured mode)
                  Each step can include:
                  - title: The step title (string)
                  - subtasks: List of subtask descriptions (strings)
            markdown_plan: Complete plan in markdown format (markdown mode for GPT)
            editor: Optional FileEditor instance for file operations
                    ```
        Returns:
            Tuple[str, Dict]: Path to the created markdown file and the plan data
        """
            
        # Add UUID to create a unique plan_id
        unique_plan_id = f"{plan_id}_{uuid.uuid4().hex[:8]}"
        
        # MODE 1: Markdown mode (GPT models)
        if markdown_plan:
            try:
                # Parse markdown to get plan structure
                plan_data = markdown_to_json(markdown_plan, plan_id=unique_plan_id)
                
                # Create Plan object from parsed data
                plan = Plan(
                    plan_id=unique_plan_id,
                    summary=plan_data.get("summary", ""),
                    created_at=datetime.now(),
                    updated_at=datetime.now()
                )
                
                # Add steps from parsed data
                for step_data in plan_data.get("steps", []):
                    if not isinstance(step_data, dict):
                        logger.warning(f"Invalid step in parsed markdown: {step_data}")
                        continue
                        
                    title = step_data.get("title", "")
                    # Extract subtask descriptions from the parsed data
                    subtasks = [
                        subtask.get("description", "") 
                        for subtask in step_data.get("subtasks", [])
                        if isinstance(subtask, dict)
                    ]
                    plan.add_step(title, subtasks)
                    
            except Exception as e:
                logger.error(f"Error parsing markdown plan: {e}")
                raise ValueError(f"Failed to parse markdown plan: {str(e)}")
        
        # MODE 2: Structured mode (Claude and other models)
        else:
            # Create a new Plan object
            plan = Plan(
                plan_id=unique_plan_id,
                summary=summary or "",
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            
            # Add steps if provided
            if steps:
                for step_data in steps:
                    # Validate step_data is a dictionary
                    if not isinstance(step_data, dict):
                        logger.warning(f"Invalid step data format: {step_data}. Expected a dictionary.")
                        continue
                    
                    title = step_data.get("title", "")
                    subtasks = step_data.get("subtasks", [])
                    
                    # First pass - add all steps without dependencies to get proper step numbers
                    plan.add_step(title, subtasks)
        
        # Save the plan files with both directories
        md_path, _ = save_plan_files(
            plan, 
            SETTINGS.get_plans_dir(),
            SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
        )
        
        logger.info(f"Created plan '{unique_plan_id}' with {len(plan.steps)} steps")
        return md_path, plan.dict_with_enum_values()
