CREATE_PLAN_TOOL_DESC_GPT = """Creates a structured project plan by returning markdown format.

IMPORTANT: Return ONLY the markdown plan content. Do NOT wrap it in code blocks or add explanations.

Return in this exact format:

# Plan: {{plan_id}}

## Summary
{{Detailed summary of the plan objectives and context. Include user feedback, relevant files, and any important context.}}

**Status:** ⏳ Pending

**Execution Mode:** Step by Step

**Created:** {{YYYY-MM-DD HH:MM:SS}}

**Last Updated:** {{YYYY-MM-DD HH:MM:SS}}

## Steps

### Step 1: [Status: ⏳ Pending] {{Title of first step}}

**Subtasks:**

1.1 {{Description of subtask 1}}
1.2 {{Description of subtask 2}}

### Step 2: [Status: ⏳ Pending] {{Title of second step}}

**Subtasks:**

2.1 {{Description of subtask 1}}
2.2 {{Description of subtask 2}}

Guidelines:
- IMPORTANT: The plan_id parameter MUST be in snake_case format (lowercase with underscores)
  Examples: 'learn_python_basics', 'fix_authentication_bug', 'implement_user_dashboard'
  NOT: 'Learn Python Basics', 'fix-authentication-bug', 'ImplementUserDashboard'
- Use the exact plan_id parameter provided in the function parameters
- Number steps sequentially starting from 1
- All new steps must have Status: ⏳ Pending
- Use current timestamp for Created and Last Updated
- Provide detailed subtasks
"""

CREATE_PLAN_SHORT_DESC_GPT = "Create a structured project plan in markdown format."
