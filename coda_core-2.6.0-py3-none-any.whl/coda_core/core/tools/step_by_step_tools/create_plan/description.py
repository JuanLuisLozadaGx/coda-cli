CREATE_PLAN_TOOL_DESC = """Permits creating a structured project plan with steps, summary and subtasks.

For example, to create a plan with steps:
```python
    name="create_plan", 
    plan_id="learn_python_basics", 
    summary="A structured plan for learning Python", 
    steps=[
        {
            "title": "Setup and Python Fundamentals", 
            "subtasks": ["Create folder", "Install Python"]
        }
    ]
```
- The plan summary provides an overview of the plan's objectives and context. It is fundamental to add into this summary 
the user feedback provided in the conversation, files or any other relevant information. If the user did not provide too much context
and it is creating a plan for learning or understanding new ideas, you can add relevant context to the summary based on your knowledge.

- Each subtask does not need to be too concise, the idea is to provide relevant details to the user so they can understand what needs to be done.
  
"""
CREATE_PLAN_SHORT_DESC = "Create a structured project plan with steps, summary and subtasks. Requires plan_id, summary and steps parameters."


