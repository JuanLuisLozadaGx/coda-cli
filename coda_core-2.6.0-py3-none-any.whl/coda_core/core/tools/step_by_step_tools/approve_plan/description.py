
APPROVE_PLAN_TOOL_DESC = """Tool to mark a step in a project plan as completed, pending, in progress, or failed.
If the user approves explicitly your plan you should mark it as completed.
Use the "approve" tool to update the plan status ONLY after explicit user approval:
```
name="approve_plan", plan_id="your_plan_id"
```

This will automatically:
- Update the status to: **Status:** ✅ Approved
- Update the last updated date to the current date and time
- ALWAYS AFTER USING THIS TOOL RETURN THE COMPLETE PLAN SHOWING STEPS AND SUBTASKS. The end of your response must include: "Great! The plan has been approved. I now have editing tools available for creating and modifying code. I’ll start implementing Step 1 whenever you’re ready."

"""
APPROVE_STEP_SHORT_DESC = "Tool to mark a step in a project plan as completed, pending, in progress, or failed."

