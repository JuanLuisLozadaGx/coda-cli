from typing import Dict, Any, Optional, Callable, Optional
from loguru import logger
from coda_core.core.modes.step_by_step_utilities.planning_converters import save_plan_files, load_plan
from coda_core.config.settings import SETTINGS, EnvConfig
from coda_core.core.modes.step_by_step_utilities.schemas import PlanStatus

# Module-level variable to store the mode transition callback
# This is set by the planning mode when it activates
_mode_transition_callback: Optional[Callable] = None

def set_mode_transition_callback(callback: Optional[Callable]) -> None:
    """
    Set the mode transition callback. Called by planning mode during activation.
    
    Args:
        callback: The callback function to trigger mode transition, or None to clear
    """
    global _mode_transition_callback
    _mode_transition_callback = callback
    if callback:
        logger.info("Mode transition callback registered in approve_plan tool")
    else:
        logger.info("Mode transition callback cleared from approve_plan tool")
        
def approve_plan(plan_id: str, start_command: Optional[bool] = False) -> Dict[str, Any]:
    """
    Approve a plan by ID and ask for execution preference.
    
    Args:
        plan_id: ID of the plan to approve
        start_command: Flag indicating if this was triggered by /start command
        
    Returns:
        Dict[str, Any]: The updated plan data with status information
    """
    # Load the plan
    plan = load_plan(
        plan_id, 
        SETTINGS.get_plans_dir(),
        SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
    )
    
    if not plan:
        logger.warning(f"Plan {plan_id} not found for approval")
        return {"error": f"Plan {plan_id} not found for approval", "status": "not_found"}
    
    # Update the plan status
    plan.update_plan_status(PlanStatus.APPROVED)
    
    # Save the updated plan with both directories
    md_path, json_path = save_plan_files(
        plan, 
        SETTINGS.get_plans_dir(),
        SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
    )
    
    logger.info(f"Saved markdown to: {md_path}")
    logger.info(f"Saved JSON to: {json_path}")
                
    # Add the plan file paths to the return value but wrap plan_id in metadata
    # This prevents double transitions by making plan_id only accessible via one handler
    result = plan.dict_with_enum_values()
    result['plan_file_path'] = md_path
    result['json_file_path'] = json_path
    result['plan_path'] = md_path  # Add additional key for UI handler compatibility
    
    # Check if mode transition callback exists
    global _mode_transition_callback
    if _mode_transition_callback:
        try:
            # Trigger the mode transition callback with plan details
            logger.info(f"Triggering mode transition for plan {plan_id}")
            _mode_transition_callback({
                'plan_id': plan_id,
                'plan_file': md_path,
                'details': result,
                'start_command': start_command  # Flag indicating this was NOT triggered by /start command
            })
            
            # Return a result that indicates execution should begin immediately
            # The mode transition has already happened via callback
            logger.info("Mode transition successful, returning execution-ready response")
            return {
                "status": "approved",
                "message": f"Plan approved, you do not need to use the approve plan tool again. Return to the user a message indicating that you now will have edition-creation tools available.",
                "metadata": {
                    "plan_id": plan_id,
                    "details": result,
                    "plan_file_path": md_path,
                    "plan_path": md_path,  # Add for UI handler compatibility
                    "execution_enabled": True
                }
            }
        except Exception as e:
            logger.warning(f"Mode transition callback failed: {e}")
            # Fall through to normal approval response
    
    # Normal approval response (no mode transition or transition failed)
    # Restructure to prevent dual transitions - this is the key change
    # Instead of returning plan_id at the top level, wrap it in metadata
    # This way only one transition handler will recognize and use it
    wrapped_result = {
        "status": "approved",
        "message":"Plan approved, you do not need to use the approve plan tool again. Return to the user a message indicating that you now will have edition-creation tools available.",
        "metadata": {
            "plan_id": plan_id,
            "details": result,
            "plan_file_path": md_path,
            "plan_path": md_path  # Add for UI handler compatibility
        }
    }
    
    return wrapped_result