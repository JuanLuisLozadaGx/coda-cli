from typing import Dict, Any, Optional, Tuple, List
from datetime import datetime
from loguru import logger
from coda_core.core.modes.step_by_step_utilities.planning_converters import save_plan_files, load_plan
from coda_core.config.settings import SETTINGS, EnvConfig
from coda_core.core.modes.step_by_step_utilities.schemas import SubTask, ExecutionPreference, PlanStatus
        

def update_plan(plan_id: str, 
                summary: Optional[str] = None, 
                steps: Optional[List[Dict[str, Any]]] = None,
                execution_preference: Optional[str] = None,
                plan_status: Optional[str] = None,
                replace_all_steps: bool = False) -> Tuple[str, Dict[str, Any]]:
    """
    Update an existing plan with structured data.
    
    Args:
        plan_id: ID of the plan to update
        summary: Updated summary description of the plan
        steps: Updated list of step dictionaries with titles, subtasks, and dependencies
                Each step can include:
                - title: The step title (string)
                - subtasks: List of subtask descriptions (strings)
                - inner_step_dependencies: dependencies between steps if applicable, using the following format:
                ```
                **Dependencies:**
                - Step 1: high     # This means the current step highly depends on Step 1
                - Step 2: medium   # This means the current step moderately depends on Step 2
                ```
                - step_number: (Optional) Specific step number to update/overwrite. If provided, this will
                replace the step at that position instead of adding a new step. If not provided, the step
                will be added as a new step (unless replace_all_steps is True).
        execution_preference: Optional execution preference ("step_by_step" or "all_at_once")
        plan_status: Optional plan status ("pending", "approved", "completed", "failed")
        replace_all_steps: If True, removes all existing steps before processing the new steps list.
                          This ensures no duplication when you want to completely redefine the plan.
        
    Returns:
        Tuple[str, Dict]: Path to the updated markdown file and the plan data
    """
    # Load existing plan to preserve creation date and other metadata
    existing_plan = load_plan(
        plan_id, 
        SETTINGS.get_plans_dir(),
        SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
    )
    
    if not existing_plan:
        logger.warning(f"Plan {plan_id} not found, cannot update")
        return None, {"error": f"Plan {plan_id} not found. Use create_plan to create a new plan."}
        
    # Update summary if provided
    if summary:
        existing_plan.summary = summary
        
    # Update execution preference if provided
    if execution_preference:
        if execution_preference.lower() in ["step_by_step", "all_at_once"]:
            # Convert string to enum
            pref_value = execution_preference.lower()
            enum_value = ExecutionPreference.STEP_BY_STEP
            if pref_value == "all_at_once":
                enum_value = ExecutionPreference.ALL_AT_ONCE
                
            # Update the plan's execution preference
            existing_plan.execution_preference = enum_value
            logger.info(f"Updated execution preference for plan {plan_id} to {pref_value}")
        else:
            logger.warning(f"Invalid execution preference: {execution_preference}. Must be 'step_by_step' or 'all_at_once'.")
            
    # Update plan status if provided
    if plan_status:
        status_enum = PlanStatus.from_string(plan_status)
        if status_enum:
            existing_plan.update_plan_status(status_enum)
            logger.info(f"Updated status for plan {plan_id} to {plan_status}")
        else:
            logger.warning(f"Invalid plan status: {plan_status}.")
        
    # Update steps if provided
    if steps:
        # If replace_all_steps is True, clear all existing steps first
        if replace_all_steps:
            logger.info(f"Replacing all steps for plan {plan_id}")
            # Remove all existing steps in reverse order to avoid renumbering issues
            for step_num in sorted([s.number for s in existing_plan.steps], reverse=True):
                existing_plan.remove_step(step_num)
            logger.info(f"Cleared all existing steps from plan {plan_id}")
            
        # Map of existing step numbers for checking overwrites
        existing_step_numbers = {step.number for step in existing_plan.steps}
        
        # Process removals first (if any) - in reverse order to avoid renumbering issues
        removal_steps = [s for s in steps if isinstance(s, dict) and s.get('remove', False)]
        if removal_steps:
            logger.info(f"Processing {len(removal_steps)} step removals for plan {plan_id}")
            # Sort in reverse order to remove highest step numbers first
            for step_data in sorted(removal_steps, key=lambda s: s.get('step_number', 0), reverse=True):
                step_number = step_data.get('step_number')
                if step_number is not None and step_number in existing_step_numbers:
                    success = existing_plan.remove_step(step_number)
                    if success:
                        logger.info(f"Removed step {step_number} from plan {plan_id}")
                    else:
                        logger.warning(f"Failed to remove step {step_number} from plan {plan_id}")
            
            # Update existing_step_numbers after removals
            existing_step_numbers = {step.number for step in existing_plan.steps}
        
        # First pass - add/update steps without dependencies
        for step_data in steps:
            # Skip removal steps which were already processed
            if step_data.get('remove', False):
                continue
                
            # Validate step_data is a dictionary
            if not isinstance(step_data, dict):
                logger.warning(f"Invalid step data format: {step_data}. Expected a dictionary.")
                continue
            
            try:
                title = step_data.get("title", None)  # Changed to None to detect if title was provided
                raw_subtasks = step_data.get("subtasks", [])
                step_number = step_data.get("step_number", None)
                
                # Convert subtasks to SubTask objects if they're strings
                subtasks = []
                for subtask in raw_subtasks:
                    if isinstance(subtask, str):
                        # It's a simple string description
                        subtasks.append(SubTask(description=subtask))
                    elif isinstance(subtask, dict) and "description" in subtask:
                        # It's already a dict with description
                        subtasks.append(SubTask(description=subtask["description"]))
                    else:
                        # Keep as is (might be SubTask object already)
                        subtasks.append(subtask)
                
                # Check if this is updating an existing step
                if step_number is not None and step_number in existing_step_numbers:
                    logger.info(f"Updating existing step {step_number} in plan {plan_id}")
                    # Find and update the existing step
                    for step in existing_plan.steps:
                        if step.number == step_number:
                            # Only update title if it was explicitly provided
                            if title is not None:
                                step.title = title
                            
                            # Always update subtasks if provided
                            step.subtasks = subtasks
                            break
                else:
                    # For add_step, convert subtasks back to strings since that's what it expects
                    if title is None:
                        title = ""  # Default empty title for new steps
                        
                    subtask_strings = []
                    for subtask in subtasks:
                        if hasattr(subtask, 'description'):
                            subtask_strings.append(subtask.description)
                        elif isinstance(subtask, dict) and 'description' in subtask:
                            subtask_strings.append(subtask['description'])
                        elif isinstance(subtask, str):
                            subtask_strings.append(subtask)
                        else:
                            logger.warning(f"Unexpected subtask type: {type(subtask)}")
                            
                    # Add as a new step
                    existing_plan.add_step(title, subtask_strings)
            except Exception as e:
                logger.error(f"Error adding/updating step: {e}")
                continue
        
        # Second pass - process dependencies for all steps
        updated_step_numbers = {step.number for step in existing_plan.steps}
        
        for step_data in steps:
            # Skip if step_data is not a dictionary
            if not isinstance(step_data, dict):
                continue
            
            step_number = step_data.get("step_number", None)
                
            # Find the step we're updating dependencies for
            target_step = None
            if step_number is not None and step_number in updated_step_numbers:
                # This is updating an existing step
                target_step = next((s for s in existing_plan.steps if s.number == step_number), None)
            else:
                # This is a newly added step, so find it by title
                title = step_data.get("title", "")
                # Find the last step with this title (in case of duplicates, we want the most recently added)
                for s in reversed(existing_plan.steps):
                    if s.title == title:
                        target_step = s
                        break
            
            if not target_step:
                logger.warning(f"Could not find step to update dependencies for: {step_data}")
                continue
                        
    # Update timestamp
    existing_plan.updated_at = datetime.now()
    
    try:
        # Save the updated plan with both directories
        md_path, json_path = save_plan_files(
            existing_plan, 
            SETTINGS.get_plans_dir(),
            SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
        )
        
        logger.info(f"Updated plan: {plan_id} with {len(existing_plan.steps)} steps")
        logger.info(f"Saved markdown to: {md_path}")
        logger.info(f"Saved JSON to: {json_path}")
        return md_path, existing_plan.dict_with_enum_values()
    except Exception as e:
        logger.error(f"Error saving plan {plan_id}: {e}")
        return None, {"error": f"Error saving plan: {str(e)}"}