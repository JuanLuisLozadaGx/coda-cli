from typing import Dict, Optional, Callable
from loguru import logger
from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.modes.step_by_step_utilities.schemas import Plan
from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.core.tools.step_by_step_tools.update_plan.description import UPDATE_PLAN_TOOL_DESC, UPDATE_PLAN_SHORT_DESC
from coda_core.core.tools.step_by_step_tools.update_plan.functions import update_plan
from coda_core.config.settings import SETTINGS, EnvConfig

class UpdatePlanTool(FunctionTool):
    """ Class for updating - modifying project plans with markdown and JSON representations."""
    
    name: str = "update_plan_tool"
    description: str = UPDATE_PLAN_TOOL_DESC
    short_description: str = UPDATE_PLAN_SHORT_DESC
    function: Callable = update_plan

    def __init__(self, name: str = name, 
                 description: str = description, 
                 short_description: str = short_description, 
                 function: Callable = function, 
                 editor: Optional[FileEditor] = None):
        super().__init__(
            name=name,
            description=description,
            short_description=short_description,
            function=function,
        )
        self.editor = editor if editor else FileEditor()

        # Set plans directory, default to user's home directory if not provided

        self.plans_dir = SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR)
        self.current_plan: Optional[Plan] = None

    def execute(self, **kwargs) -> Dict[str, any]:
        """
        Execute the mark_step_tool function with the provided arguments.
        Handles parameter validation and error logging.
        Args:
            **kwargs: Arguments to pass to the mark_step_tool function.
        Returns:
            Dict[str, any]: Result from the mark_step_tool function or error information.
        Raises:
            ParameterError: If there are issues with the provided parameters.
        """
        try:
            # Validate parameters against the function signature, excluding the editor parameter
            self._validate_parameters(update_plan, kwargs)
            
            # Filter out reserved arguments before calling the function
            filtered_kwargs = self._filter_reserved_arguments(kwargs)
            
            # Call the function with the filtered arguments
            return update_plan(**filtered_kwargs)
            
        except ParameterError as e:
            # Log and re-raise parameter errors
            logger.error(f"Parameter error in {self.name} tool: {e}")
            raise
        except Exception as e:
            # Log other exceptions
            logger.exception(f"Error executing function {self.name}: {e}")
            return {"status": "error", "message": str(e)}
               