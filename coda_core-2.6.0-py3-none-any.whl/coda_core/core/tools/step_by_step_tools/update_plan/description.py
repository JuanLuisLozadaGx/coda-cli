
UPDATE_PLAN_TOOL_DESC = """Tool for editing a plan step, execution mode or subtask
# Tool Usage
Parameters are passed directly to the tool:


Usage examples: 
```python
Example to add a new step:
```
    name="update_plan",
    plan_id="feature_plan",
    steps=[
        {
            "title": "New Step Title", 
            "subtasks": ["Subtask 1", "Subtask 2"]
        }
    ]
```

Example to update existing steps (use step_number):
```
    name="update_plan",
    plan_id="feature_plan",
    steps=[
        {
            "step_number": 1,  # Updates step 1
            "title": "Updated Step 1", 
            "subtasks": ["Updated subtask 1", "Updated subtask 2"]
        },
        {
            "step_number": 2,  # Updates step 2
            "title": "Updated Step 2", 
            "subtasks": ["New subtask"]
        }
    ]
```

Example to replace all steps (avoids duplication):
```
    name="update_plan",
    plan_id="feature_plan",
    replace_all_steps=True,  # Clears existing steps first
    steps=[
        {
            "title": "Step 1", 
            "subtasks": ["Subtask 1.1", "Subtask 1.2"]
        },
        {
            "title": "Step 2", 
            "subtasks": ["Subtask 2.1", "Subtask 2.2"]
        }
    ]
```

Example to change execution mode:
```
    name="update_plan",
    plan_id="feature_plan",
    execution_preference="all_at_once"  # Or "step_by_step"
```

Example to mark a plan as completed:
```
    name="update_plan",
    plan_id="feature_plan",
    plan_status="completed"  # Options: "pending", "approved", "completed", "failed"
```


In this update action be care about the following:
- If a substak is related to a user feedback then include a comment about it in the subtask like: # User mentioned this as important context: ...
- If the user did not provide too much context and it is creating a plan for learning or understanding new ideas, you can add relevant context to the summary based on your knowledge.
- Each subtask does not need to be too concise, the idea is to provide relevant details to the user so they can understand what needs to be done.
- Use step_number to update specific existing steps, omit it to add new steps
- Use replace_all_steps=True when you want to completely redefine the plan without duplicating steps
"""
UPDATE_PLAN_SHORT_DESC = "Tool for editing a plan step, execution mode, plan status, or subtask. Requires plan_id and at least one of the following parameters: steps, execution_preference, plan_status."

