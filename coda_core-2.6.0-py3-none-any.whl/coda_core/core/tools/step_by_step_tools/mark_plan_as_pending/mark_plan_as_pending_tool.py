from typing import Any, Dict, Callable, Optional
from loguru import logger
from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.core.tools.step_by_step_tools.mark_plan_as_pending import mark_plan_as_pending
from coda_core.core.tools.step_by_step_tools.mark_plan_as_pending.description import MARK_PLAN_AS_PENDING_TOOL_DESC, MARK_PLAN_AS_PENDING_TOOL_SHORT_DESC

class MarkPlanAsPendingTool(FunctionTool):
    """Tool to mark a plan as pending and transition back to planning mode."""
    
    def __init__(self, agent_callback: Callable = None):
        """
        Initialize the tool for marking a plan as pending.
        
        Args:
            agent_callback: Optional callback to update agent state
        """
        # Fix the name to match the actual tool name
        name: str = "mark_plan_as_pending_tool"
        description: str = MARK_PLAN_AS_PENDING_TOOL_DESC
        short_description: str = MARK_PLAN_AS_PENDING_TOOL_SHORT_DESC
        
        # Call the parent class constructor directly
        super().__init__(
            name=name,
            description=description,
            short_description=short_description,
            function=mark_plan_as_pending,
        )
        
        # Store the agent callback
        self._agent_callback = agent_callback
        
        # Initialize editor
        self.editor = FileEditor()
    
    def execute(self, **kwargs) -> Dict[str, any]:
        """
        Execute the create_plan function with the provided arguments.
        Handles parameter validation and error logging.
        Args:
            **kwargs: Arguments to pass to the create_plan function.
        Returns:
            Dict[str, any]: Result from the create_plan function or error information.
        Raises:
            ParameterError: If there are issues with the provided parameters.
        """
        try:
            # Validate parameters against the function signature
            self._validate_parameters(mark_plan_as_pending, kwargs)
            
            # The mark_plan_as_pending function doesn't actually use the editor parameter
            # but we validate it exists in case it's needed in the future
            # Notify the agent of the change if a callback is provided
            if self._agent_callback:
                try:
                    self._agent_callback("Transitioning to plan creation mode.")
                except Exception as e:
                    logger.error(f"Error in agent callback: {e}")
            
            # Filter out reserved arguments before calling the function
            filtered_kwargs = self._filter_reserved_arguments(kwargs)

            # Call the function with the filtered arguments
            return mark_plan_as_pending(**filtered_kwargs)
            
        except ParameterError as e:
            # Log and re-raise parameter errors
            logger.error(f"Parameter error in {self.name} tool: {e}")
            raise
        except Exception as e:
            # Log other exceptions
            logger.exception(f"Error executing function {self.name}: {e}")
            return {"status": "error", "message": str(e)}
        
    
    def cleanup(self) -> None:
        """
        Clean up the tool resources. This is called when the tool is being disabled or removed.
        It clears the mode transition callback to prevent memory leaks and orphaned callbacks.
        """
        logger.info(f"Cleaning up {self.name}")
        try:
            from coda_core.core.tools.step_by_step_tools.mark_plan_as_pending.functions import set_mode_transition_callback
            set_mode_transition_callback(None)
            logger.info(f"Successfully cleared mode transition callback from {self.name}")
        except Exception as e:
            logger.error(f"Error during cleanup of {self.name}: {e}")
            # Continue execution even if cleanup fails