from typing import Dict, Any, Optional, Callable
from loguru import logger
from coda_core.core.modes.step_by_step_utilities.planning_converters import save_plan_files, load_plan
from coda_core.config.settings import SETTINGS, EnvConfig
from coda_core.core.modes.step_by_step_utilities.schemas import PlanStatus

# Module-level variable to store the mode transition callback
# This is set by the planning mode when it activates
_mode_transition_callback: Optional[Callable] = None

def set_mode_transition_callback(callback: Optional[Callable]) -> None:
    """
    Set the mode transition callback. Called by planning mode during activation.
    
    Args:
        callback: The callback function to trigger mode transition, or None to clear
    """
    global _mode_transition_callback
    _mode_transition_callback = callback
    if callback:
        logger.info("Mode transition callback registered in mark_plan_as_pending tool")
    else:
        logger.info("Mode transition callback cleared from mark_plan_as_pending tool")

def mark_plan_as_pending(plan_id: str, reason: Optional[str] = None) -> Dict[str, Any]:
    """
    Mark a plan as pending and transition back to plan creation mode.
    
    Args:
        plan_id: ID of the plan to mark as pending
        reason: Optional reason for returning to the planning stage
        
    Returns:
        Dict: The result of the operation
    """
    # Load the plan
    plan = load_plan(
        plan_id, 
        SETTINGS.get_plans_dir(),
        SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
    )
    
    if not plan:
        logger.warning(f"Plan {plan_id} not found for marking as pending")
        return {"error": f"Plan {plan_id} not found", "status": "not_found"}
    
    # Update the plan status
    plan.update_plan_status(PlanStatus.PENDING)
    
    # Save the updated plan with both directories
    md_path, json_path = save_plan_files(
        plan, 
        SETTINGS.get_plans_dir(),
        SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
    )
    
    logger.info(f"Saved markdown to: {md_path}")
    logger.info(f"Saved JSON to: {json_path}")
    
    # Add the plan file paths to the return value
    result = plan.dict_with_enum_values()
    result['plan_file_path'] = md_path
    result['json_file_path'] = json_path
    
    # Check if mode transition callback exists
    global _mode_transition_callback
    if _mode_transition_callback:
        try:
            # Trigger the mode transition callback with plan details
            logger.info(f"Triggering mode transition for plan {plan_id} to creation mode")
            _mode_transition_callback({
                'plan_id': plan_id,
                'plan_file': md_path,
                'details': result,
                'transition_to': 'creation',
                'reason': reason
            })
            
            # Return a result that indicates transition back to creation mode
            logger.info("Mode transition successful, returning to creation mode")
            return {
                "status": "pending",
                "message": f"Plan marked as pending. Returning to planning mode.",
                "reason": reason,
                "metadata": {
                    "plan_id": plan_id,
                    "details": result,
                    "plan_file_path": md_path
                }
            }
        except Exception as e:
            logger.warning(f"Mode transition callback failed: {e}")
            # Fall through to normal response
    
    # Normal response (no mode transition or transition failed)
    return {
        "status": "pending",
        "message": f"Plan marked as pending.",
        "reason": reason,
        "metadata": {
            "plan_id": plan_id,
            "details": result,
            "plan_file_path": md_path
        }
    }