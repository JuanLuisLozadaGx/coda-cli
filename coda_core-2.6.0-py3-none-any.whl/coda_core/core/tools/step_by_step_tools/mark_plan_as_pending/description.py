MARK_PLAN_AS_PENDING_TOOL_DESC = """ 
It is used when the user explicitly wants to create a new plan to start from zero again with a new idea. 
The memory is reset, and the agent goes back to the plan creation mode. Use this when the user said for example:
- I want to create a new plan
- Let's start a new plan
- I want to go back to the planning stage
- I want to create a different plan
- I want to start over with a new plan
- I want to change the plan
{
        "name": "mark_plan_as_pending",
        "description": "Marks the current plan as pending and transitions back to plan creation mode.",
        "parameters": {
            "type": "object",
            "properties": {
                "plan_id": {
                    "type": "string",
                    "description": "ID of the plan to mark as pending"
                },
                "reason": {
                    "type": "string",
                    "description": "Reason for returning to the planning stage"
                }
            },
            "required": ["plan_id"]
        }
    }"""

MARK_PLAN_AS_PENDING_TOOL_SHORT_DESC = """ Marks the current plan as pending and transitions back to plan creation mode, allowing the user to start a new plan from scratch. 
It is used when the user explicitly wants to create a new plan to start from zero again with a new idea. 
The memory is reset, and the agent goes back to the plan creation mode. """