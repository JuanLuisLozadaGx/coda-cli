from typing import Dict, Any, Optional, Annotated, Callable
from loguru import logger
from coda_core.core.modes.step_by_step_utilities.planning_converters import save_plan_files, load_plan
from coda_core.config.settings import SETTINGS, EnvConfig
from coda_core.core.modes.step_by_step_utilities.schemas  import StepStatus, PlanStatus, ExecutionPreference

# Module-level variable to store the mark step callback
# This is set by the planning mode state machine
_mark_step_callback: Optional[Callable] = None

def set_mark_step_callback(callback: Optional[Callable]) -> None:
    """
    Set the callback to be triggered when mark_step is called.
    
    Args:
        callback: The callback function to trigger after step is marked, or None to clear
    """
    global _mark_step_callback
    _mark_step_callback = callback
    if callback:
        logger.info("Mark step callback registered in mark_step tool")
    else:
        logger.info("Mark step callback cleared from mark_step tool")

def mark_step(plan_id: Annotated[str, "Unique identifier for the plan to be created"], 
              step_number: Annotated[int, "Currrent step number to mark (1-based)"], 
              step_execution_summary: Annotated[str, "Summary of the step execution, implementation review and details"] = None, 
              status: Optional[str] = "completed") -> Optional[Dict[str, Any]]:
    """
    Mark a step as completed or with another status.
    
    Args:
        plan_id: ID of the plan
        step_number: Number of the step to mark (1-based)
        status: Status to set ("completed", "pending", "in_progress", "failed")
        step_execution_summary: Optional response text from the agent
    Returns:
        Optional[Dict]: The updated plan data or None if plan or step not found
    """
    plan = load_plan(
        plan_id, 
        SETTINGS.get_plans_dir(),
        SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
    )
    
    if not plan:
        logger.warning(f"Plan {plan_id} not found for marking step")
        return {"status": "error", "message": f"Plan {plan_id} not found"}
    
    # Map status string to enum
    status_map = {
        "completed": StepStatus.COMPLETED,
        "pending": StepStatus.PENDING,
        "in_progress": StepStatus.IN_PROGRESS,
        "failed": StepStatus.FAILED
    }
    
    step_status = status_map.get(status.lower(), StepStatus.PENDING)
    
    success = plan.mark_step_status(step_number, step_status, step_execution_summary)
    
    if not success:
        logger.warning(f"Step {step_number} not found in plan {plan_id}")
        return {"status": "error", "message": f"Step {step_number} not found in plan {plan_id}"}
    
    # Get the step title for the marked step
    step_title = None
    for step in plan.steps:
        if step.number == step_number:
            step_title = step.title
            break
    
    # Check if all steps are completed and update plan status if needed
    all_completed = all(step.status == StepStatus.COMPLETED for step in plan.steps)
    if all_completed and plan.status == PlanStatus.APPROVED:
        plan.update_plan_status(PlanStatus.COMPLETED)
    
    # Save the updated plan with both directories
    md_path, json_path = save_plan_files(
        plan, 
        SETTINGS.get_plans_dir(),
        SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
    )
    logger.info(f"Saved markdown to: {md_path}")
    logger.info(f"Saved JSON to: {json_path}")
        
    logger.info(f"Marked step {step_number} as {status} in plan {plan_id}")
        
    # Determine next action based on execution preference
    response = plan.dict_with_enum_values()
    
    # Always include status in the response to ensure memory transition conditions can be checked
    response = {
        "status": status.lower(),
        "step_number": step_number,
        "step_title": step_title,
        "plan_data": response
    }
    
    # Add user-facing messages based on execution preference
    if status.lower() == "completed":
        # Check if this is the last step
        max_step_number = max(s.number for s in plan.steps) if plan.steps else 0
        is_last_step = step_number == max_step_number
        
        if plan.execution_preference == ExecutionPreference.STEP_BY_STEP:
            # For step-by-step execution, inject a message to pause and summarize
            response["message"] = f"Step {step_number} marked as {status}."
            if is_last_step:
                response["system_message"] = f"[SYSTEM MESSAGE] You completed the last step {step_number} of the plan. Return to the user what you did. The last step of the plan is being completed. Now use the update_plan tool to mark the plan status as completed for the user to have a good reference of its finalized plans."
            else:
                response["system_message"] = f"[SYSTEM MESSAGE] You completed the step {step_number}. Return to the user what you did, and at the end add 'Do you want to proceed with the next step?'. Wait for the next user interaction for proceeding with the next step."
        elif plan.execution_preference == ExecutionPreference.ALL_AT_ONCE:
            # For all-at-once execution, inject a message to continue
            next_step = next((s for s in plan.steps if s.number > step_number), None)
            if next_step:
                response["message"] = f"Step {step_number} marked as {status}."
                response["system_message"] = f"[SYSTEM MESSAGE] The user wants to run all steps at once. Proceed with step {next_step.number}: {next_step.title}"
            elif is_last_step:
                response["message"] = f"Step {step_number} marked as {status}."
                response["system_message"] = f"[SYSTEM MESSAGE] You completed the last step {step_number} of the plan. Return to the user what you did. The last step of the plan is being completed. Now use the update_plan tool to mark the plan status as completed for the user to have a good reference of its finalized plans."
    
    logger.debug(f"Response after marking step: {response}")
    logger.debug(f"execution_preference: {plan.execution_preference}")
    
    # Call the callback if it exists
    global _mark_step_callback
    if _mark_step_callback:
        try:
            # Create callback data with relevant information
            callback_data = {
                'plan_id': plan_id,
                'step_number': step_number,
                'step_title': step_title,  # Include step title for UI display
                'status': status.lower(),
                'plan_data': plan.dict_with_enum_values(),
                'plan_file': None  # Will be set by the callback if needed
            }
            
            # Log the callback being triggered
            logger.info(f"Triggering mark step callback for plan {plan_id}, step {step_number}")
            
            # Call the callback
            _mark_step_callback(callback_data)
        except Exception as e:
            # Log any errors but don't fail the mark_step operation
            logger.error(f"Error in mark_step callback: {e}")
    return response