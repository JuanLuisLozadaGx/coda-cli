
MARK_STEP_PLAN_TOOL_DESC = """Allow marking the step as completed, tracking the progress of a plan in a programmatic way.

# Tool Usage
Parameters are passed directly to the tool:
- mark_step_tool: Mark a step as completed, pending, in progress, or failed using plan_id, step_number, step_execution_summary

For example, to create a plan with steps:
```python
    name="mark_step_tool",
    plan_id="your_plan_id",
    step_number=1,  # The step you just completed
    step_execution_summary="I implemented the login functionality by creating a new LoginForm component and connecting it to the authentication service. The component handles validation and displays error messages.",
    status="completed"  # Optional, defaults to "completed"
```

- The step_execution_summary provides an overview of the step execution main insights. It is fundamental to explain what was done in the step execution
in a concise way, prodividing essential information to the user, for example, if the step was to "Install Python", 
the step_execution_summary could be "Python 3.10 was installed successfully using the official installer from python.org". If this is related to a user feedback
you can add more information like "Python 3.10 was installed successfully using the official installer from python.org, as per your request to use the latest stable version"
or even explicit feedback like "Python 3.10 was installed successfully using the official installer from python.org, as per your request explicitly in previous conversation".
If no relevant information is provided, you can add relevant context to the summary based only on what was done.

IMPORTANT: inside the ```step_execution_summary``` always add the file paths of the edited or created files, add summarized code snippets of the essential parts of the implementation,
for giving to the user an overall idea of what was done in the step execution.

"""
MARK_STEP_SHORT_DESC = "Mark a step as completed, pending, in progress, or failed using plan_id, step_number, step_execution_summary parameters."

