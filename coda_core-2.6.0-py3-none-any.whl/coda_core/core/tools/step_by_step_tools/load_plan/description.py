LOAD_PLAN_TOOL_DESC = """Load an existing plan and immediately transition to execution mode. Only use this tool when the user explicitly requests to load a previously created plan.

# Tool Usage
Parameters are passed directly to the tool:
- load_plan_tool: Load an existing plan by ID and switch to execution mode

For example, to load an existing plan:
```python
    name="load_plan_tool",
    plan_id="your_plan_id"
```

This tool will:
1. Load the specified plan from the plans directory
2. Verify the plan is in an approved state
3. Transition the agent to execution mode
4. Begin execution with the first step of the plan

Important notes:
- Only approved plans can be loaded (plans must have been previously created and approved)
- After loading, the agent will immediately transition to execution mode
- The plan's steps will be available for execution using the mark_step_tool tool
- Always show the complete plan with all details (tasks and subtasks) after using this tool
"""
LOAD_PLAN_SHORT_DESC = """Load an existing plan by ID and immediately transition to execution mode."""

