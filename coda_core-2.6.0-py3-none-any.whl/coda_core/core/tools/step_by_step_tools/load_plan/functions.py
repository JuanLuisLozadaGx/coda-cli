from typing import Dict, Any, Optional, Callable, Annotated
import os
from loguru import logger
from coda_core.core.modes.step_by_step_utilities.planning_converters import load_plan as planning_load_plan
from coda_core.config.settings import SETTINGS, EnvConfig
from coda_core.core.modes.step_by_step_utilities.schemas import PlanStatus

# Module-level variable to store the mode transition callback
# This is set by the planning mode when it activates
_mode_transition_callback: Optional[Callable] = None

def set_mode_transition_callback(callback: Optional[Callable]) -> None:
    """
    Set the mode transition callback. Called by planning mode during activation.
    
    Args:
        callback: The callback function to trigger mode transition, or None to clear
    """
    global _mode_transition_callback
    _mode_transition_callback = callback
    if callback:
        logger.info("Mode transition callback registered in load_plan tool")
    else:
        logger.info("Mode transition callback cleared from load_plan tool")
        
def load_plan(plan_id: Annotated[str, "Unique identifier for the plan to be loaded"], save_json: Optional[bool] = False) -> Dict[str, Any]:
    """
    Load an existing plan by ID and transition to execution mode.
    
    Args:
        plan_id: ID of the plan to load
        save_json: Whether to save JSON file when loading from markdown (default: False)
        
    Returns:
        Dict[str, Any]: The loaded plan data with status information
    """        
    # Get plans directory from settings
    plans_dir = SETTINGS.get_plans_dir()
    private_plans_dir = SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
    
    # Load the plan (without saving JSON to avoid creating unnecessary files)
    plan = planning_load_plan(plan_id, plans_dir, private_plans_dir, save_json=save_json)
    
    if not plan:
        logger.warning(f"Plan {plan_id} not found for loading")
        return {"status": "error", "message": f"Plan {plan_id} not found", "plan_id": plan_id}
        
    # Get the plan file path (just construct it, don't save)
    md_path = os.path.join(
        SETTINGS.get_plans_dir(),
        f"{plan_id}.md"
    )
    
    # Prepare result data
    result = plan.dict_with_enum_values()
    result['plan_file_path'] = md_path
    result['plan_path'] = md_path  # Add additional key for UI handler compatibility
    
    # Check if mode transition callback exists
    global _mode_transition_callback
    if _mode_transition_callback:
        try:
            # Trigger the mode transition callback with plan details
            logger.info(f"Triggering mode transition for plan {plan_id}")
            _mode_transition_callback({
                'plan_id': plan_id,
                'plan_file': md_path,
                'details': result
            })
            
            # Return a result that indicates execution should begin immediately
            logger.info("Mode transition successful, returning execution-ready response")
            return {
                "status": "loaded",
                "message": f"Plan loaded. You can start asking the user if they want to execute the last pending step of the plan:",
                "metadata": {
                    "plan_id": plan_id,
                    "details": result,
                    "plan_file_path": md_path,
                    "plan_path": md_path,  # Add for UI handler compatibility
                    "execution_enabled": True
                }
            }
        except Exception as e:
            logger.warning(f"Mode transition callback failed: {e}")
            # Fall through to normal response
    
    # Normal response (no mode transition or transition failed)
    wrapped_result = {
        "status": "loaded",
        "metadata": {
            "plan_id": plan_id,
            "details": result,
            "plan_file_path": md_path,
            "plan_path": md_path  # Add for UI handler compatibility
        }
    }
    
    return wrapped_result