RUN_SKILL_TOOL_DESC = """Returns the complete instructions for executing a specialized skill.

Skills are pre-defined, reusable task templates created by users or the system to handle specific workflows 
efficiently and consistently. Each skill contains detailed instructions, execution scripts, and metadata.

When to use this tool:
- User asks for a task that matches a known skill (e.g., "create a web artifact", "generate sample data")
- The task requires following specific step-by-step procedures defined in a skill
- You want consistent, repeatable execution of a complex task


Parameters:
- skill_name: The exact name of the skill to execute (must match a skill in the available skills list)

Example:
```python
run_skill(
    skill_name="dataframe-generator"
)
```
Important notes:
- Only use skills listed in your available skills list (provided in context)
- The skill_name must exactly match the skill directory name
- Skills may run in different contexts: native (bash), uv (Python), or docker (containers)

What you receive back:
- The complete instructions for executing the skill including environment settings and platform information.

DO NOT:
- Use run_skill for tasks that can be done with standard tools (bash, view, edit)
- Call run_skill with skill names not in your available skills list
"""

RUN_SKILL_TOOL_SHORT_DESC = (
    "Returns the complete instructions for executing a specialized skill."
)
