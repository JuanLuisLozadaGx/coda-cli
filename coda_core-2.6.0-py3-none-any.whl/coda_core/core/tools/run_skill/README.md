# RunSkill Tool

CODA supports user-defined skills - reusable task templates that help the agent execute complex workflows consistently. Skills are discovered from:

- **Project-local**: `.coda/skills/` (in your working directory)
- **System-wide**: `~/.coda/skills/` (in your home directory)

**Note**: If a skill with the same name exists in both locations, the project-local skill takes precedence.

### Key Features

- **Skill Discovery**: Automatic discovery and loading of skills from designated directories
- **Execution Contexts**: Support for multiple execution environments (native, uv, docker, npm)
- **YAML Frontmatter**: Skills use YAML frontmatter for metadata and configuration
- **Interactive Management**: Enable/disable skills via CLI commands or interactive selection
- **Platform Awareness**: Automatic platform detection for cross-platform compatibility

### Skill Structure

Each skill consists of:
- **Metadata**: Name, description, execution context, and configuration
- **Instructions**: Detailed task instructions in markdown format
- **Scripts**: Optional executable scripts in the `scripts/` directory
- **Dependencies**: Requirements files (requirements.txt, package.json, etc.)

### Example Skill

See [examples/dataframe-generator.md](./examples/dataframe-generator.md) for a complete skill example.

### run_skill Tool

The `run_skill` tool enables the agent to load and execute skills. When invoked:

1. Loads the skill's metadata and instructions
2. Determines the execution context (native, uv, docker, npm)
3. Provides platform-specific information
4. Returns complete instructions for the agent to execute

The agent then uses standard tools (bash, view, edit, replace) to execute the skill's instructions in the appropriate environment.

## Overview

The `run_skill` tool enables the main agent to load and execute user-defined skills by providing the complete skill instructions and execution context. Skills are specialized task templates created by users to help the agent complete tasks efficiently and consistently.

```mermaid
graph TB
    A[Main Agent] -->|uses run_skill tool| B[RunSkillTool]
    B -->|loads skill| C[SkillLoader]
    C -->|finds skill| D[Skill Metadata + Content]
    B -->|extracts| E[Execution Context]
    B -->|detects| F[Platform Info]
    B -->|returns| G[Complete Instructions]
    G -->|to| A
    A -->|executes with| H[Standard Tools]
    H -->|bash, view, edit, replace| I[Task Completion]
```

## How It Works

The `run_skill` tool implements a simple instruction-loading mechanism:

1. **Skill Discovery**: Uses `SkillLoader` to find the requested skill by name
2. **Metadata Extraction**: Reads the skill's YAML frontmatter for execution configuration
3. **Context Detection**: Determines the execution context (native, uv, docker, npm)
4. **Platform Detection**: Identifies the user's platform (macOS, Windows, Linux)
5. **Instruction Assembly**: Combines skill content, context, and platform info
6. **Return to Agent**: Provides complete instructions for the main agent to execute

**Key Point**: The tool does NOT create subagents or isolated execution environments. It simply returns instructions that the main agent executes using its standard tools.

## Architecture

### Tool Registration

The tool is registered in the ToolManager via `schemas.py`:

```python
# In schemas.py
SYSTEM_DEFAULT_TOOL_CONFIGS = {
    "basic": {
        "run_skill": {
            "enabled": True,
            "category": "user_defined",
            "tool_class": RunSkillTool,
        }
    }
}
```

### Dependency Injection

The tool receives a `SkillLoader` dependency at initialization:

```python
class RunSkillTool(FunctionTool):
    def __init__(self, skill_loader: Optional[SkillLoader] = None):
        super().__init__(
            function=execute_run_skill,
            exclude_params=["skill_loader"]  # Hide from LLM
        )
        self.skill_loader = skill_loader if skill_loader else SkillLoader()
```

**Why exclude `skill_loader`?**
- The LLM only needs to provide `skill_name`
- Internal dependencies are hidden from the tool schema
- Dependency injection happens at the tool layer

### Execution Flow

```mermaid
sequenceDiagram
    participant Agent as Main Agent
    participant Tool as RunSkillTool
    participant Loader as SkillLoader
    participant Skill as Skill File
    
    Agent->>Tool: run_skill(skill_name="dataframe-generator")
    Tool->>Loader: find_skill_by_name("dataframe-generator")
    Loader->>Skill: Load SKILL.md
    Skill-->>Loader: Metadata + Content
    Loader-->>Tool: Skill object
    Tool->>Tool: Extract execution_config
    Tool->>Tool: Get platform_info
    Tool->>Tool: Build instruction string
    Tool-->>Agent: "Here are instructions: [skill content]..."
    
    Note over Agent: Agent receives instructions as text
    
    Agent->>Agent: Use bash, view, edit tools
    Agent->>Agent: Execute skill instructions
    Agent-->>User: Task completed
```

## Execution Contexts

Skills can specify different execution contexts in their YAML frontmatter:

### Native Context

```yaml
execution:
  context: native
  timeout: 120
```

**Behavior**: Scripts run directly in the current environment using bash/shell commands.

### UV Context

```yaml
execution:
  context: uv
  timeout: 120
  python: "3.11"
  requirements: requirements.txt
```

**Behavior**: Instructions indicate Python environment setup with uv. The agent uses bash to create and activate the environment. These instructions are essential for the agent to properly set up the environment before executing the skill, particularly directories that need to be created or timeout settings that need to be respected.

### Docker Context

```yaml
execution:
  context: docker
  timeout: 300
  docker_image: "python:3.11-slim"
```

**Behavior**: Instructions indicate containerized execution. The agent uses bash to run docker commands.

### NPM Context

```yaml
execution:
  context: npm
  timeout: 180
  package_manager: npm
```

**Behavior**: Instructions indicate Node.js environment. The agent uses bash to install and run npm scripts.

## Platform Detection

The tool detects the user's platform to provide appropriate instructions:

```python
def get_platform_info() -> dict:
    """Get platform information for skill execution."""
    return {
        "platform": "osx" | "windows" | "linux",
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "python_version": platform.python_version()
    }
```

This information helps the agent:
- Use correct path separators (/ vs \\)
- Choose appropriate activation scripts (source vs Scripts\\)
- Select platform-specific commands

## Usage Example

### Agent Workflow

```
User: "Create a pandas DataFrame with 100 rows"

Agent: [Thinks] This matches the dataframe-generator skill
Agent: [Calls] run_skill(skill_name="dataframe-generator")

Tool Response:
{
  "status": "success",
  "content": "Here the necessary information for running:dataframe-generator 
              Instructions: [Full SKILL.md content with examples and scripts]
              BE AWARE OF THE CORRECT ENVIRONMENT SETTINGS AND CONTEXT: uv.
              USER PLATFORM: {'platform': 'osx', 'system': 'Darwin', ...}
              Run the scripts following the instructions..."
}

Agent: [Receives instructions]
Agent: [Uses bash tool] Create uv environment: uv venv --python 3.11
Agent: [Uses bash tool] Activate: source .venv/bin/activate  
Agent: [Uses bash tool] Install: uv pip install pandas
Agent: [Uses bash tool] Run script: python scripts/generate.py --rows 100
Agent: [Uses view tool] Check output.csv

Agent → User: "Created DataFrame with 100 rows in output.csv"
```

**REMARK**: Sometimes it is better to explicitly name the tool as a ```skill```. For instance: "Create a pandas DataFrame with 100 rows using the skill dataframe-generator"

### What the Agent Sees

The agent receives a single string with:
- Skill name and description
- Full markdown content with instructions
- Execution context (native, uv, docker, npm)
- Platform information (OS, architecture, Python version)
- Guidance to run scripts and report results

The agent then:
1. Parses the instructions
2. Uses `bash` tool to set up environment (if needed)
3. Uses `bash` tool to run scripts
4. Uses `view` tool to check outputs
5. Reports results to user

## CLI Integration

The `/skills` command in coda-cli provides user-friendly skill management:

### List Skills

```bash
⫸ /skills

Available Skills:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
● dataframe-generator (enabled)
  Generate pandas DataFrames with custom data
  Context: uv | Timeout: 120s
```

### Interactive Selection

```bash
⫸ /skills select

Skill Selection Menu
====================

○ [1] dataframe-generator (disabled)
      Generate dummy pandas DataFrames

Enter number(s) to toggle: 1

  ● Enabled dataframe-generator

✓ Updated 1 skill(s)
```

### Enable/Disable

```bash
⫸ /skills enable dataframe-generator
✓ Enabled skill: dataframe-generator

⫸ /skills disable dataframe-generator  
✓ Disabled skill: dataframe-generator
```

### Refresh (Detect Manual Changes)

```bash
⫸ /skills refresh
✓ Detected new skills: pdf-extractor
✓ System prompt updated
```

Use this command after manually copying skill files to `.coda/skills/` to detect new or removed skills without restarting the CLI.

## Skill Discovery

Skills are discovered from two locations:

1. **Project-local**: `.coda/skills/` in current working directory
   - Automatically enabled when present
   - Project-specific skills
   - Version-controlled with your code

2. **Package defaults**: Built-in example skills
   - Disabled by default
   - Must be explicitly enabled
   - Serve as templates for custom skills

### Skill Structure

```
.coda/skills/
└── dataframe-generator/
    ├── SKILL.md          # Main skill file (required)
    ├── requirements.txt  # Python dependencies (optional)
    ├── scripts/          # Executable scripts (optional)
    │   ├── generate.py
    │   └── validate.py
    └── LICENSE.txt       # License info (optional)
```
