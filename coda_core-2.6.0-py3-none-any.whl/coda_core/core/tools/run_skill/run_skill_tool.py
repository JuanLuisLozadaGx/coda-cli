from typing import Callable, Optional, Dict, Any

from loguru import logger

from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.tools.run_skill.description import RUN_SKILL_TOOL_DESC, RUN_SKILL_TOOL_SHORT_DESC
from coda_core.core.tools.run_skill.functions import execute_run_skill
from coda_core.core.tools.run_skill.skill_state_tracker import SkillStateTracker
from coda_core.core.utils.skill_loader import SkillLoader


class RunSkillTool(FunctionTool):
    """
    A tool for loading and executing user-defined skills with memory optimization.

    Skills are specialized task instructions created by users to help the agent complete tasks
    efficiently and consistently. This tool loads the skill and returns its instructions
    for execution, with intelligent caching to avoid redundant loads.

    Attributes:
        name (str): The name of the tool, defaulting to "run_skill".
        description (str): A detailed description of the tool.
        short_description (str): A brief description of the tool.
        function (Callable): A callable that executes the tool's primary function.
        skill_loader (SkillLoader): An instance of SkillLoader used to discover and load skills.
        _skill_state_tracker (SkillStateTracker): Tracks skill loading state for memory optimization.
    """
    
    name: str = "run_skill"
    description: str = RUN_SKILL_TOOL_DESC
    short_description: str = RUN_SKILL_TOOL_SHORT_DESC
    function: Callable = execute_run_skill

    
    def __init__(
        self,
        name: str = name,
        description: str = description,
        short_description: str = short_description,
        function: Callable = function,
        skill_loader: Optional[SkillLoader] = None
    ):
        """
        Initialize a RunSkillTool instance.

        Args:
            name (str): The name of the tool. Defaults to "run_skill".
            description (str): The description of the tool.
            short_description (str): A brief description of the tool.
            function (Callable): The function that executes the tool's primary action.
            skill_loader (SkillLoader): An instance of SkillLoader used to discover and load skills.
        """
        super().__init__(
            name=name,
            description=description,
            short_description=short_description,
            function=function,
            exclude_params=["skill_loader", "skill_state_tracker"]
        )
        self.skill_loader = skill_loader if skill_loader else SkillLoader()
        self._skill_state_tracker = SkillStateTracker()

        logger.info(f"Initialized RunSkillTool with memory optimization and {len(self.skill_loader.skill_directories)} skill directories")


    def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute the run_skill function with state tracking and memory optimization.

        This method injects the skill_loader and skill_state_tracker dependencies.

        Args:
            skill_name (str): The name of the skill to load and execute
            **kwargs: Additional keyword arguments

        Returns:
            Dict[str, Any]: A dictionary containing the status and the skill execution results or error message.
            
        Raises:
            ParameterError: If there are issues with the provided parameters.
        """
        try:
            self._validate_parameters(execute_run_skill, kwargs)
            filtered_kwargs = self._filter_reserved_arguments(kwargs)
            
            result = execute_run_skill(
                skill_loader=self.skill_loader,
                skill_state_tracker=self._skill_state_tracker,
                **filtered_kwargs
            )
            
            return {"status": "success", "content": result}
            
        except ParameterError as e:
            logger.error(f"Parameter error in {self.name} tool: {e}")
            raise
        except ValueError as e:
            logger.warning(f"ValueError in {self.name} tool: {e}")
            return {"status": "error", "message": str(e)}
        except Exception as e:
            logger.exception(f"Error executing function {self.name}: {e}")
            return {"status": "error", "message": str(e)}
    
    def on_memory_condensed(self) -> None:
        """
        Callback invoked when memory is condensed.
        
        Marks the state tracker so that the next skill load will return full content.
        """
        self._skill_state_tracker.mark_memory_condensed()
        logger.info("Memory condensed - skill state tracker updated")
    
    def reset_state(self) -> None:
        """
        Reset the skill state tracker (e.g., on new conversation).
        """
        self._skill_state_tracker.reset()
        logger.info("Skill state tracker reset")
