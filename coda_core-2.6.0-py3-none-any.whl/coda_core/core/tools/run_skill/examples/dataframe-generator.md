---
name: dataframe-generator
description: Generate pandas DataFrames with custom data
execution:
  context: uv
  timeout: 120
  python: "3.11"
  requirements: requirements.txt
---

# DataFrame Generator Skill

This skill creates sample pandas DataFrames in isolated Python environments.

## When to Use
- Create sample CSV files
- Prototype data structures
- Generate test datasets
- Quick data analysis experiments

## Requirements

This skill requires:
- Python 3.11+
- pandas library (installed via requirements.txt)
- uv environment manager

## Usage Examples

Ask the agent:
- "Create a pandas DataFrame with 100 rows of random data"
- "Generate a CSV file with customer data"
- "Create a sample dataset for testing"

## How It Works

1. The agent sets up a uv virtual environment
2. Installs pandas from requirements.txt
3. Executes the data generation script
4. Outputs the result as CSV or displays the DataFrame
