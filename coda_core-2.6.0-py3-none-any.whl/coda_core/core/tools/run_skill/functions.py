from typing import Annotated, Optional
from loguru import logger

from coda_core.core.utils.skill_loader import SkillLoader
from coda_core.core.tools.run_skill.skill_state_tracker import SkillStateTracker
from coda_core.core.utils.skill_formatters import generate_skill_change_notification
from coda_core.config.system_info import SystemInfo
from coda_core.core.models.utils import load_prompt


def execute_run_skill(
    skill_name: Annotated[str, "The name of the skill to load"],
    skill_loader: SkillLoader = None,
    skill_state_tracker: Optional[SkillStateTracker] = None,
) -> str:
    """
    Execute the run_skill tool with memory optimization.
    
    Returns abbreviated response if skill is already in memory and hasn't
    been condensed. Otherwise loads and returns full skill content.
    
    Args:
        skill_name: The name of the skill to load (e.g., "web-artifacts-builder")
        skill_loader: SkillLoader instance (injected dependency)
        skill_state_tracker: SkillStateTracker instance (injected dependency)
        
    Returns:
        The skill instructions (full or abbreviated) as a string.
        
    Raises:
        ValueError: If skill is not found or required dependencies are not provided
    """
    logger.info(f"Executing run_skill for: {skill_name}")
    
    # Validate dependencies
    if skill_loader is None:
        logger.error("SkillLoader dependency not provided to run_skill tool")
        raise ValueError(
            "SkillLoader not available. This tool requires proper initialization."
        )
    
    # Check if skill is disabled or removed FIRST
    skill_status = skill_loader.check_skill_status(skill_name)
    if skill_status in ("disabled", "removed"):
        logger.warning(f"Attempted to use {skill_status} skill: {skill_name}")
        return generate_skill_change_notification(skill_name, skill_status)
    
    # Check if we can skip full load (memory optimization)
    if skill_state_tracker and not skill_state_tracker.should_load_full_skill(skill_name):
        return (
            f"[SKILL ALREADY LOADED]\n\n"
            f"The '{skill_name}' skill instructions are already present in your conversation memory. "
            f"Please use the previously loaded instructions to complete the user's request.\n\n"
            f"If you need to reload the full skill definition, it will be automatically reloaded "
            f"after memory condensation or if you call a different skill."
        )
    
    # Load the skill
    skill = skill_loader.find_skill_by_name(skill_name)

    if skill is None:
        available_skills = skill_loader.discover_skills()
        skill_names = [s.name for s in available_skills]
        
        logger.warning(f"Skill '{skill_name}' not found. Available: {skill_names}")
        
        if skill_names:
            raise ValueError(
                f"Skill '{skill_name}' not found. Available skills: {', '.join(skill_names)}"
            )
        else:
            raise ValueError(
                f"Skill '{skill_name}' not found. No skills are currently available. "
                "Please ensure skills are placed in .coda/skills/ (project) or ~/.coda/skills/ (system) directories."
            )
    
    logger.success(f"Successfully loaded skill '{skill_name}' from {skill.path}")
    
    # Get execution context from skill metadata
    execution_config = skill.metadata.get("execution", {})
    env_context = execution_config.get("context", "native")
    timeout = execution_config.get("timeout", 120)
    
    logger.info(f"Skill execution context: {env_context}, timeout: {timeout}s")
    
    system_info = SystemInfo()
    platform_info = SystemInfo.detect_system_based_on_shell()
    platform_type = system_info.get_formatted_environment_info()
    logger.debug(f"Platform info: {platform_info}")

    # Load and render the skill execution prompt template
    content = load_prompt(
        "run_skill_prompt.hbs",
        context={
            "skill_name": skill_name,
            "skill": {"full_content": skill.full_content},
            "skill_content": skill.full_content,
            "skill_path": str(skill.path),
            "context": env_context,
            "execution_context": env_context,
            "timeout": timeout,
            "platform_info": platform_info,
            "platform_type": platform_type,
            "python_version": execution_config.get('python', '3.11'),
            "requirements_file": execution_config.get('requirements', 'requirements.txt'),
            "docker_image": execution_config.get('docker_image', 'python:3.11-slim')
        }
    )

    # Mark skill as loaded in state tracker
    if skill_state_tracker:
        skill_state_tracker.mark_skill_loaded(skill_name)

    logger.debug(f"Rendered run_skill prompt for skill '{skill_name}' (length={len(content)})")
    return content
