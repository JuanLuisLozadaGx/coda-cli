import platform
from typing import Dict


def _get_platform() -> str:
    """Get the current platform (osx, windows, linux)."""
    system = platform.system().lower()
    if system == "darwin":
        return "osx"
    elif system == "windows":
        return "windows"
    else:
        return "linux"


def get_platform_info() -> Dict[str, str]:
    """
    Get detailed platform information for cross-platform support.
    
    Returns:
        Dictionary with platform details
    """
    return {
        "platform": _get_platform(),
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "python_version": platform.python_version(),
    }
