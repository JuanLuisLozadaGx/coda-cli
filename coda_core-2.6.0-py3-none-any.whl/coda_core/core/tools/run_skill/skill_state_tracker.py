from typing import Optional
from loguru import logger


class SkillStateTracker:
    """
    Tracks skill loading state to optimize memory usage.
    
    Prevents redundant skill loading by tracking:
    - Last loaded skill name
    - Memory condensation events
    
    Attributes:
        _last_loaded_skill: Name of the most recently loaded skill
        _memory_condensed: Flag indicating if memory was condensed since last load
    """
    
    def __init__(self):
        """Initialize the skill state tracker."""
        self._last_loaded_skill: Optional[str] = None
        self._memory_condensed: bool = False
    
    def should_load_full_skill(self, skill_name: str) -> bool:
        """
        Determine if full skill content should be loaded.
        
        Returns True if:
        - This is a different skill than last loaded
        - Memory was condensed since last load
        - This is the first skill load
        
        Args:
            skill_name: Name of the skill being requested
            
        Returns:
            bool: True if full skill should be loaded, False for short response
        """
        if self._last_loaded_skill is None or self._last_loaded_skill != skill_name:
            return True
        
        if self._memory_condensed:
            return True
        
        return False
    
    def mark_skill_loaded(self, skill_name: str) -> None:
        """
        Mark a skill as loaded and reset condensation flag.
        
        Args:
            skill_name: Name of the skill that was loaded
        """
        self._last_loaded_skill = skill_name
        self._memory_condensed = False
        logger.info(f"Marked skill '{skill_name}' as loaded")
    
    def mark_memory_condensed(self) -> None:
        """Mark that memory condensation occurred."""
        self._memory_condensed = True
        logger.info(f"Memory condensation marked (last skill: {self._last_loaded_skill})")
    
    def reset(self) -> None:
        """Reset tracker state (e.g., on new conversation)."""
        self._last_loaded_skill = None
        self._memory_condensed = False
        logger.info("Skill state tracker reset")
    
    @property
    def last_loaded_skill(self) -> Optional[str]:
        """Get the name of the last loaded skill."""
        return self._last_loaded_skill
    
    @property
    def memory_condensed(self) -> bool:
        """Check if memory was condensed since last skill load."""
        return self._memory_condensed
