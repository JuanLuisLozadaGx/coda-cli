from coda_core.core.filesystem_ops.constants import FILE_VIEW_MAX_LINES_CAP

VIEW_TOOL_SHORT_DESC = """Read numbered file slices. Use offset/limit to page. All reads are safety-capped per request. Includes pagination metadata."""

VIEW_TOOL_DESC = f"""Reads a file from the local filesystem. You can access any file directly by using this tool.

Request only files relevant to the task. If the User provides a path to a file assume that path is valid. It is okay to read a file that does not exist; an error will be returned.

Parameters:
- file_path (required, absolute path)
- offset (optional, 1-based line to start)
- limit (optional, at most limit lines, subject to cap; may be fewer at EOF)

Range semantics (mutually combinable):
1. No offset & no limit  -> return entire file (max {FILE_VIEW_MAX_LINES_CAP} for safety)
2. limit only            -> lines 1 .. min(limit, {FILE_VIEW_MAX_LINES_CAP})
3. offset only           -> lines offset .. end of file (subject to cap)
4. offset + limit        -> at most min(limit, {FILE_VIEW_MAX_LINES_CAP}) lines starting at offset (may be fewer at EOF)

Validation:
- offset and limit must be positive integers
- If offset > total lines => returns empty content (status success)
- If limit extends past EOF => returns fewer lines; not truncated

Output:
- Numbered lines (cat -n style), preserving original file line numbers
- When using offset, line numbers start from the offset value (e.g., offset=100 shows lines 100, 101, 102...)
- When no offset specified, line numbers start from 1
- Preserve original spacing (including tabs)
- Response metadata (files only; omitted for directories; to assist pagination decisions, not prescriptive):
  - start_line (int): starting 1-based line for this slice; for full-file reads this is always 1
  - end_line (int): last 1-based line for this slice; for full-file reads this equals returned_lines
  - returned_lines (int): number of lines returned in this response
  - has_more (bool): True if additional content exists beyond this slice
  - eof_reached (bool): True if EOF was reached within or exactly at this slice
  - truncated (bool): True if the result was limited by the cap ({FILE_VIEW_MAX_LINES_CAP}); otherwise False

Safety:
- All reads (full or ranged) are capped at {FILE_VIEW_MAX_LINES_CAP} lines per request
- Use pagination (offset + limit) for large files
- Ranged reads (offset/limit) are streamed; no full-file read performed

Usage guidance:
- Do not assume a fixed default limit; choose an initial slice size based on current task context. Ranged reads are streamed.
- Use metadata to guide decisions on further reads:
  - If you have enough information for your goal, you may stop reading this file.
  - If you need more context and has_more is true, continue with offset = end_line + 1; for limit tuning:
    - If returned_lines == limit and truncated is false: you may increase limit by a small to moderate increment, never exceeding the cap ({FILE_VIEW_MAX_LINES_CAP}).
    - If truncated is true: do not increase; keep the current limit (the cap may still apply).
  - If eof_reached is true or returned_lines == 0, stop.
- Avoid premature stopping when missing context might affect correctness; prefer reading the next slice over guessing.
- If you need multiple non-contiguous regions, request them sequentially.

Examples:
- First 80 lines: {{"file_path": "/abs/path/app.py", "limit": 80}}
  Output shows: "1: <code>", "2: <code>", ..., "80: <code>"
- Lines 201-260: {{"file_path": "/abs/path/app.py", "offset": 201, "limit": 60}}
  Output shows: "201: <code>", "202: <code>", ..., "260: <code>"
- Tail from line 500: {{"file_path": "/abs/path/app.py", "offset": 500}}
  Output shows: "500: <code>", "501: <code>", ..., up to end of file
- Pagination loop:
  1) Initial slice: {{"file_path": "/abs/path/app.py", "limit": 120}}
  2) If has_more is true and returned_lines == 120 and truncated is false:
     Next slice: {{"file_path": "/abs/path/app.py", "offset": end_line + 1, "limit": 170}}
  3) Repeat while has_more is true; adjust by small to moderate increments as needed and never exceed the per-request cap ({FILE_VIEW_MAX_LINES_CAP}). Do not increase on truncated pages.

Best practices:
- Avoid large full reads unless necessary
- Request the slice needed; paginate progressively
- Use follow-up narrowing after an initial scan

Error conditions:
- File does not exist or path is not absolute
- Invalid parameters (offset ≤ 0, limit ≤ 0)
"""