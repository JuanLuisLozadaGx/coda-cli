from typing import Annotated, Dict, Optional, Any

from loguru import logger

from coda_core.core.filesystem_ops.file_editor import FileEditor

def execute_view(
        editor: FileEditor,
        file_path: Annotated[str, "The absolute path to the file to read"],
        offset: Annotated[Optional[int], "The line number to start reading from. Only provide if the file is too large to read at once"] = None,
        limit: Annotated[Optional[int], "The number of lines to read. Only provide if the file is too large to read at once."] = None
) -> Dict[str, Any]:
    """Reads a file from the local filesystem with optional line range.
    
    Args:
        editor (FileEditor): An instance of FileEditor used to perform the file operations.
        file_path (str): The absolute path to the file to read.
        offset (Optional[int]): The line number to start reading from. Only provide if the file is too large to read at once.
        limit (Optional[int]): The number of lines to read. Only provide if the file is too large to read at once.
    
    Returns:
        Dict[str, any]: A dictionary containing the status of the operation, the file path, and the result or error message.
    """
    try:
        # Convert offset and limit to integers if they are strings
        if offset is not None and isinstance(offset, str):
            offset = int(offset)
        if limit is not None and isinstance(limit, str):
            limit = int(limit)
        
        # Validate parameters - return early to avoid logging noise
        if offset is not None and offset <= 0:
            return {
                "status": "error",
                "message": "Parameter error: offset must be positive (1-based indexing). Make sure offset and limit are valid integers."
            }
        if limit is not None and limit <= 0:
            return {
                "status": "error",
                "message": "Parameter error: limit must be positive. Make sure offset and limit are valid integers."
            }
            
        # Initialize view_range
        view_range = None  # Default: show entire file (subject to safety limits)
        
        # Build view_range if any parameter provided
        if offset is not None or limit is not None:
            # User specified parameters - read whole file, then apply range
            start_line = offset if offset is not None else 1
            if limit is not None:
                end_line = start_line + limit - 1  # Fix: subtract 1 because limit is count, not end position (e.g., offset=3, limit=2 should return lines 3-4)
            else:
                end_line = None  # Show to end of file
            view_range = [start_line, end_line]
        
        return editor.view(file_path=file_path, view_range=view_range).to_dict()
    except ValueError as e:
        logger.exception(f"Parameter conversion error while reading file {file_path}: {e}")
        return {"status": "error", "file": file_path, "message": f"Parameter error: {str(e)}. Make sure offset and limit are valid integers."}
    except Exception as e:
        logger.exception(f"Unexpected error while reading file {file_path}: {e}")
        return {"status": "error", "file": file_path, "message": str(e)}