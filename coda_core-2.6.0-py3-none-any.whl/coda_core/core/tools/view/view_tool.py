from typing import Callable, Optional, Dict

from loguru import logger

from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.tools.view.description import VIEW_TOOL_DESC, VIEW_TOOL_SHORT_DESC
from coda_core.core.tools.view.functions import execute_view
from coda_core.core.filesystem_ops.file_editor import FileEditor

class ViewTool(FunctionTool):
    """
    A tool for viewing files, encapsulating a name, description, and an execution function.

    Attributes:
        name (str): The name of the tool, defaulting to "view".
        description (str): A detailed description of the tool.
        short_description (str): A brief description of the tool.
        function (Callable): A callable that executes the tool's primary function.
        editor (FileEditor): An instance of FileEditor used to perform file operations.
    """
    
    name: str = "view"
    description: str = VIEW_TOOL_DESC
    short_description: str = VIEW_TOOL_SHORT_DESC
    function: Callable = execute_view

    
    def __init__(self, name: str = name, description: str = description, short_description: str = short_description, function: Callable = function, editor: Optional[FileEditor] = None):
        """
        Initialize a ViewTool instance.

        Args:
            name (str): The name of the tool. Defaults to "view".
            description (str): The description of the tool.
            short_description (str): A brief description of the tool.
            function (Callable): The function that executes the tool's primary action.
            editor (FileEditor): An instance of FileEditor used to perform file operations.
        """
        super().__init__(
            name=name,
            description=description,
            short_description=short_description,
            function=function,
        )
        self.editor = editor if editor else FileEditor()

        # Log the initialization details
        logger.info(f"Initialized ViewTool")


    def execute(self, **kwargs) -> Dict[str, any]:
        """
        Execute the view function using the internal FileEditor instance.

        Args:
            file_path (str): The absolute path to the file to read.
            offset (Optional[int]): The line number to start reading from.
            limit (Optional[int]): The number of lines to read.

        Returns:
            Dict[str, any]: A dictionary containing the status of the operation, the file path, and the result or error message.
            
        Raises:
            ParameterError: If there are issues with the provided parameters.
        """
        try:
            # Validate parameters against the function signature, excluding the editor parameter
            self._validate_parameters(execute_view, kwargs)
            
            # Filter out reserved arguments before calling the function
            filtered_kwargs = self._filter_reserved_arguments(kwargs)
            
            # Call the function with the filtered arguments
            return execute_view(self.editor, **filtered_kwargs)
            
        except ParameterError as e:
            # Log and re-raise parameter errors
            logger.error(f"Parameter error in {self.name} tool: {e}")
            raise
        except Exception as e:
            # Log other exceptions
            logger.exception(f"Error executing function {self.name}: {e}")
            return {"status": "error", "message": str(e)}