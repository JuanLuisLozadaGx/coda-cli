from typing import Annotated, Any, Dict, Callable, List, Optional, Tuple, Union, get_type_hints, get_origin, get_args
import inspect

from loguru import logger

from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.core.tools.base import Tool


class ParameterError(Exception):
    """Exception raised for parameter errors in function tools."""
    pass


class FunctionTool(Tool):
    """
    A tool that executes a function with specified parameters.
    """

    def __init__(
        self,
        name: str,
        description: str,
        short_description: str,
        function: Callable,
        exclude_params: Optional[List[str]] = None,
        allow_excluded_params: bool = False,
    ):
        """
        Initialize a FunctionTool instance.

        Args:
            name (str): The name of the tool.
            description (str): The description of the tool.
            short_description (str): A brief description of the tool.
            function (Callable): The function to execute for the tool.
            exclude_params (Optional[List[str]]): Function parameters to omit
                from schema generation and validation.
            allow_excluded_params (bool): If True, kwargs listed in exclude_params are
                allowed at runtime (not validated against the function signature).
                This is intended for runtime-injected parameters (e.g. streaming callbacks).
        """
        super().__init__(name, description, short_description)
        self.function = function
        self.allow_excluded_params = allow_excluded_params
        # Include common FileEditor parameter names in default excludes
        default_excludes = ["editor", "llm", "metadata"]
        if exclude_params:
            self.exclude_params = default_excludes + exclude_params
        else:
            self.exclude_params = default_excludes
        self.reserved_arguments = ["metadata"]
        self.tool_definition = self._generate_tool_definition()


    def _generate_parameters(self) -> Dict[str, Any]:
        """
        Generates the parameters schema based on the function signature.

        Returns:
            Dict[str, Any]: The parameters schema for the tool.
        """
        signature = inspect.signature(self.function)
        # Use include_extras=True to get detailed type hints including Annotated
        type_hints = get_type_hints(self.function, include_extras=True)
        properties = {}

        for param_name, param in signature.parameters.items():
            # Skip excluded parameters
            if param_name in self.exclude_params:
                continue
                
            # Get the type hint, defaulting to string if not specified
            param_type = type_hints.get(param_name, str)
            param_description = None

            # Check if the parameter type is Annotated
            if get_origin(param.annotation) is Annotated:
                # Extract the base type and metadata
                base_type, *metadata = get_args(param.annotation)
                param_type = base_type
                # Extract the description from metadata, if it exists
                for item in metadata:
                    if isinstance(item, str):
                        param_description = item
                        break

            # Map Python types to JSON Schema types
            type_mapping = {
                str: "string",
                int: "integer",
                float: "number",
                bool: "boolean",
                list: "array",
                dict: "object"
            }

            # Track object openness for strict-schema compatibility
            object_additional_schema: Optional[Dict[str, Any]] = None
            object_allows_additional = False
            item_object_additional_schema: Optional[Dict[str, Any]] = None
            item_object_allows_additional = False

            def _mapping_additional_schema(mapping_type: Any) -> Optional[Dict[str, Any]]:
                """Return schema for additionalProperties or None if fully open."""
                if mapping_type is dict:
                    return None
                origin = get_origin(mapping_type)
                if origin is dict:
                    args = get_args(mapping_type)
                    if len(args) >= 2:
                        value_type = args[1]
                        if value_type is Any:
                            return None
                        value_origin = get_origin(value_type)
                        if value_origin is list:
                            return {"type": "array"}
                        if value_origin is dict:
                            return {"type": "object"}
                        return {"type": type_mapping.get(value_type, "string")}
                return None
            
            # Handle generic types like List[str], Optional[str], etc.
            origin_type = get_origin(param_type)
            if origin_type is list:
                json_type = "array"
                # Extract the item type for arrays
                args = get_args(param_type)
                if args:
                    # Get the type of list items (e.g., str from List[str])
                    item_type = args[0]
                    # Check if item_type is also a generic (like Dict[str, Any])
                    item_origin = get_origin(item_type)
                    if item_origin is dict:
                        item_json_type = "object"
                        item_object_allows_additional = True
                        item_object_additional_schema = _mapping_additional_schema(item_type)
                    elif item_origin is list:
                        item_json_type = "array"
                    else:
                        item_json_type = type_mapping.get(item_type, "string")
                else:
                    # Default to string if no type specified
                    item_json_type = "string"
            elif origin_type is dict:
                json_type = "object"
                object_allows_additional = True
                object_additional_schema = _mapping_additional_schema(param_type)
            elif origin_type is Union:
                # Handle Union types (including Optional[T] which is Union[T, None])
                args = get_args(param_type)
                # Filter out NoneType to get the actual type
                non_none_types = [arg for arg in args if arg != type(None)]
                if non_none_types:
                    # Use the first non-None type
                    actual_type = non_none_types[0]
                    actual_origin = get_origin(actual_type)
                    if actual_origin is list:
                        json_type = "array"
                        # Handle nested list types
                        actual_args = get_args(actual_type)
                        if actual_args:
                            item_type = actual_args[0]
                            # Check if nested item is also generic
                            item_origin = get_origin(item_type)
                            if item_origin is dict:
                                item_json_type = "object"
                                item_object_allows_additional = True
                                item_object_additional_schema = _mapping_additional_schema(item_type)
                            elif item_origin is list:
                                item_json_type = "array"
                            else:
                                item_json_type = type_mapping.get(item_type, "string")
                        else:
                            item_json_type = "string"
                    elif actual_origin is dict:
                        json_type = "object"
                        object_allows_additional = True
                        object_additional_schema = _mapping_additional_schema(actual_type)
                    else:
                        json_type = type_mapping.get(actual_type, "string")
                else:
                    # All types were None, default to string
                    json_type = "string"
            else:
                json_type = type_mapping.get(param_type, "string")  # Default to "string" if type is unknown

            # Fill properties with type and optionally description
            property_schema = {"type": json_type}
            
            # Add items property for arrays
            if json_type == "array":
                items_schema = {"type": item_json_type}
                if item_json_type == "object":
                    if item_object_allows_additional:
                        items_schema["additionalProperties"] = item_object_additional_schema or True
                    else:
                        items_schema["additionalProperties"] = False
                property_schema["items"] = items_schema

            # Add additionalProperties for objects to allow flexible schemas
            if json_type == "object":
                if object_allows_additional:
                    property_schema["additionalProperties"] = object_additional_schema or True
                else:
                    property_schema["additionalProperties"] = False
            
            if param_description:
                property_schema["description"] = param_description
            properties[param_name] = property_schema

        # Determine required parameters (those without a default value)
        required_params = [
            param_name
            for param_name, param in signature.parameters.items()
            if (param.default == inspect.Parameter.empty and 
                param_name not in self.exclude_params)  # Exclude specified params
        ]

        return {
            "type": "object",
            "properties": properties,
            "required": required_params,
            # Keep top-level schema closed to align with strict tools when possible
            "additionalProperties": False,
        }


    def _generate_tool_definition(self) -> Dict[str, Any]:
        """
        Generate the tool definition dictionary for LLM function calling (compliant with OpenAI).

        Returns:
            Dict[str, Any]: The tool definition in the desired format.
        """
        parameters = self._generate_parameters()
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": parameters
            }
        }


    def _filter_reserved_arguments(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Filter out reserved arguments from kwargs.
        
        Args:
            kwargs: The keyword arguments to filter
            
        Returns:
            Dict[str, Any]: Filtered kwargs without reserved arguments
        """
        return {k: v for k, v in kwargs.items() if k not in self.reserved_arguments}
    
    
    def _validate_parameters(self, function: Callable, kwargs: Dict[str, Any]) -> None:
        """
        Validate the parameters passed to a function against its signature.
        
        Args:
            function: The function to validate parameters for
            kwargs: The keyword arguments to validate
            
        Raises:
            ParameterError: If there are missing or extra parameters
        """
        # Get the parameters of the function
        sig = inspect.signature(function)
        params = sig.parameters
            
        # Create a filtered set of parameters excluding those in exclude_params
        filtered_params = {name: param for name, param in params.items() if name not in self.exclude_params}
        # Check for missing required parameters
        missing_params = []
        for name, param in filtered_params.items():
            if param.default == param.empty and name not in kwargs:
                missing_params.append(name)
        # Check for extra parameters
        # Detect parameters that were not declared in the function signature.
        # A kwarg is allowed if it matches a visible parameter, a reserved argument,
        # or — when allow_excluded_params is True — a parameter that was excluded
        # from schema generation but is still accepted at runtime (e.g. streaming callbacks).
        extra_params = []
        for key in kwargs:
            if key not in filtered_params and key not in self.reserved_arguments:
                if self.allow_excluded_params and key in self.exclude_params:
                    continue
                extra_params.append(key)
        # Raise appropriate errors if needed
        if missing_params:
            expected_params = [f"{name}" for name in filtered_params.keys()]
            received_params = list(kwargs.keys())
            error_msg = f"Missing required parameters: {', '.join(missing_params)}. Expected parameters: {', '.join(expected_params)}. Received parameters: {', '.join(received_params)}."
            raise ParameterError(error_msg)
        
        if extra_params:
            expected_params = [f"{name}" for name in filtered_params.keys()]
            received_params = list(kwargs.keys())
            error_msg = f"Unexpected parameters provided: {', '.join(extra_params)}. Expected parameters: {', '.join(expected_params)}. Received parameters: {', '.join(received_params)}."
            raise ParameterError(error_msg)
        
        # If we get here, validation passed
        return
    
    
    def execute(self, **kwargs) -> Any:
        """
        Execute the tool with the provided arguments.

        Args:
            **kwargs: Arguments to pass to the tool's function.

        Returns:
            Any: The result of the tool execution.
            
        Raises:
            ParameterError: If there are issues with the provided parameters.
        """
        try:
            # Validate parameters - exclude any parameters that are handled internally
            self._validate_parameters(self.function, kwargs)
            
            # Filter out excluded parameters before calling the function
            filtered_kwargs = self._filter_reserved_arguments(kwargs)
            
            # Call the function with the filtered arguments
            return self.function(**filtered_kwargs)
            
        except ParameterError as e:
            # Log and re-raise parameter errors
            logger.error(f"Parameter error in function {self.name}: {e}")
            raise
        except Exception as e:
            # Log other exceptions
            logger.exception(f"Error executing function {self.name}: {e}")
            return None
