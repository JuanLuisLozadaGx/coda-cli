from typing import Callable, Optional, Dict, Any, TYPE_CHECKING
import copy

from loguru import logger

from coda_core.core.tools.constants import WEB_SEARCH_DEFAULT_MODEL, WEB_SEARCH_DEFAULT_PROVIDER
from coda_core.core.tools.function_tool import FunctionTool, ParameterError
from coda_core.core.tools.web_search.description import WEB_SEARCH_TOOL_DESC, WEB_SEARCH_TOOL_SHORT_DESC
from coda_core.core.tools.web_search.functions import execute_web_search
from coda_core.core.models.llms.chat import ChatLLM

if TYPE_CHECKING:
    from coda_core.core.models.providers.geai_client import GEAIClient


class WebSearchTool(FunctionTool):
    """Tool for performing web searches using configurable search models."""

    name: str = "web_search"
    description: str = WEB_SEARCH_TOOL_DESC
    short_description: str = WEB_SEARCH_TOOL_SHORT_DESC
    function: Callable = execute_web_search

    def __init__(
        self,
        name: str = name,
        description: str = description,
        short_description: str = short_description,
        function: Callable = function,
        client: Optional['GEAIClient'] = None,
        model_provider: str = WEB_SEARCH_DEFAULT_PROVIDER,
        model_name: str = WEB_SEARCH_DEFAULT_MODEL,
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            short_description=short_description,
            function=function,
        )
        self.client = client
        self.model_provider = model_provider
        self.model_name = model_name
        
        if client:
            logger.info(f"WebSearchTool configured with provider: {model_provider}, model: {model_name}")
        else:
            logger.warning("WebSearchTool initialized without a client")
        

    def execute(self, **kwargs) -> Dict[str, Any]:
        try:
            self._validate_parameters(execute_web_search, kwargs)
            if not self.client:
                raise ValueError("GEAIClient not set for WebSearchTool")
            
            # Create a dedicated ChatLLM instance specifically for this search request
            # This ensures complete isolation from the agent's main LLM
            search_llm = ChatLLM(
                client=self.client,
                provider_name=self.model_provider,
                model_name=self.model_name,
                # No system prompt - we want the raw search capabilities
                system_prompt=None,
                # Use empty params to avoid inheriting any settings
                params={}
            )
            
            metadata = None
            if "metadata" in kwargs:
                metadata = kwargs.pop("metadata")

            # Clean up parameters - remove max_tokens if present as it's handled by ChatLLM
            if "max_tokens" in kwargs:
                kwargs.pop("max_tokens")
                
            result = execute_web_search(search_llm, metadata=metadata, **kwargs)
            
            # Process the search result - extract usage data if available
            usage_data = result.pop("usage", None) if isinstance(result, dict) else None
            
            # Create a copy of the usage data to avoid mutation issues
            if usage_data:
                try:
                    usage_copy = copy.deepcopy(usage_data)                    # Add usage data to the result with special key
                    result["_usage"] = usage_copy
                except Exception as e:
                    logger.error(f"Error processing web search usage: {e}")
                
            return result
        except ParameterError as e:
            logger.error(f"Parameter error in {self.name} tool: {e}")
            raise
        except Exception as e:
            logger.exception(f"Error executing function {self.name}: {e}")
            return {"status": "error", "message": str(e)}
