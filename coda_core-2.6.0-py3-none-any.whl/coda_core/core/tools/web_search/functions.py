from typing import Annotated, Dict, Any, Optional
from loguru import logger

from coda_core.core.models.llms.chat import ChatLLM
from coda_core.core.models.utils import extract_response_text


def execute_web_search(
    llm: ChatLLM,
    query: Annotated[str, "The search query"],
    metadata: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Perform a web search using the specified search model and return the result.
    
    Args:
        llm: The ChatLLM instance to use for the search.
        metadata: Optional metadata dictionary to pass to GEAI. Not part of tool parameters.
        query: The search query to execute.

    Returns:
        Dict[str, Any]: A dictionary containing the search result.
    """
    try:
        response = llm.generate_response(
            messages=[{"role": "user", "content": query}],
            metadata=metadata,
            reasoning={"effort": "low"},
            tools=[{"type": "web_search"}],
            tool_choice="auto",
        )
        content = extract_response_text(response)

        # Resolve legacy message object for backward-compatible annotation parsing.
        choices = getattr(response, "choices", None)
        legacy_message = getattr(choices[0], "message", None) if isinstance(choices, list) and choices else None

        # Extract citations from annotations if present
        annotations = []
        try:
            if hasattr(response, "output"):
                for item in response.output:
                    for block in getattr(item, "content", []) or []:
                        if hasattr(block, "annotations"):
                            for annotation in block.annotations:
                                if getattr(annotation, "type", None) == "url_citation":
                                    annotations.append(
                                        {
                                            "url": annotation.url,
                                            "title": annotation.title,
                                            "start_index": annotation.start_index,
                                            "end_index": annotation.end_index,
                                        }
                                    )

            # Backward compatibility for chat-style annotation payloads.
            if not annotations and legacy_message is not None:
                for annotation in getattr(legacy_message, "annotations", []) or []:
                    citation = getattr(annotation, "url_citation", None)
                    if citation is not None:
                        annotations.append(
                            {
                                "url": citation.url,
                                "title": citation.title,
                                "start_index": citation.start_index,
                                "end_index": citation.end_index,
                            }
                        )
        except Exception as e:  # pragma: no cover - best effort parsing
            logger.error(f"Error parsing web search annotations: {e}")

        # Extract usage data from response
        usage = getattr(response, "usage", None)

        return {
            "status": "success",
            "content": content,
            "usage": usage,
            "sources": annotations,
        }
    except Exception as e:
        logger.exception(f"Error executing web search: {e}")
        return {"status": "error", "message": str(e)}
