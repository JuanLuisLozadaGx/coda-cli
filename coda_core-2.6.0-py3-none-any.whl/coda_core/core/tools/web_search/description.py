from datetime import datetime

WEB_SEARCH_TOOL_SHORT_DESC = """Search the web using a search-enabled AI model.
Use this to retrieve fresh information from the internet."""

current_date = datetime.now().strftime("%Y-%m-%d")

WEB_SEARCH_TOOL_DESC = f"""Use this tool to perform a web search for up-to-date information.
Provide a concise search query describing what you want to know.
The tool calls a search-enabled model and returns summarized results.

Always use the current date in your search queries.
Current date: {current_date} (YYYY-MM-DD)
"""