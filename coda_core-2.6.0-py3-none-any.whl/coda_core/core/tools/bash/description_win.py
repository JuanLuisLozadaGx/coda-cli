"""
    Description for the Bash tool, fine-grained for Windows systems.
"""

BASH_TOOL_SHORT_DESC_WIN = """Execute Windows systems shell commands. It's extremely important only Windows commands are executed."""

BASH_TOOL_DESC_WIN = """Execute Windows systems shell commands. It's extremely important only Windows commands are executed.

1. Commands recommendations:
    - When asked to search for files or patterns, always use `findstr`. It's the most powerful search command available in Windows.
    - Be as smart as possible when searching for files or patterns. Try to apply as many filters as possible to avoid searching for unnecessary files.
    - Avoid using commands that require user interaction.

2. Directory Verification:
    - When creating new directories or files, first verify the parent directory exists and the location is correct.
    - For example, before running `mkdir foo\\my_bar`, first use `dir` to verify that `foo` exists and is the intended parent directory.

3. Command Execution:
   - Always quote file paths that contain spaces with double quotes (e.g., cd "path with spaces\\my_file.txt")
   - Examples of proper quoting:
     - cd "C:\\Users\\username\\My Documents" (correct)
     - cd C:\\Users\\username\\My Documents (incorrect - will fail)
     - python "C:\\path with spaces\\script.py" (correct)
     - python C:\\path with spaces\\script.py (incorrect - will fail)
   - After ensuring proper quoting, execute the command.
   - Capture the output of the command.

4. Security Check:
    - Some commands are limited or banned. When using a disallowed command, it returns an error message explaining the restriction. Explain the error to the User.

*Notes* regarding git usage:
- Use the git context at the start of this conversation to determine which files are relevant to your commit. Be careful not to stage and commit files (e.g. with `git add .`) that aren\'t relevant to your commit.
- NEVER update the git config
- DO NOT run additional commands to read or explore code, beyond what is available in the git context
- DO NOT push to the remote repository
- IMPORTANT: Never use git commands with the -i flag (like git rebase -i or git add -i) since they require interactive input which is not supported.
- If there are no changes to commit (i.e., no untracked files and no modifications), do not create an empty commit
- Ensure your commit message is meaningful and concise. It should explain the purpose of the changes, not just describe them.
- Return an empty response - the user will see the git output directly
- In order to ensure good formatting, ALWAYS pass the commit message via a HEREDOC.
- Return an empty response - the user will see the gh output directly', 'input_schema': {'type': 'object', 'properties': {'command': {'type': 'string', 'description': 'The command to execute'}, 'timeout': {'type': 'number', 'description': 'Optional timeout in milliseconds (max 600000)

*Notes* regarding commiting with git:
When the user asks you to create a new git commit, follow these steps carefully:
1. Use BatchTool to run the following commands in parallel:
   - Run a git status command to see all untracked files.
   - Run a git diff command to see both staged and unstaged changes that will be committed.
   - Run a git log command to see recent commit messages, so that you can follow this repository\'s commit message style.
2. Analyze all staged changes (both previously staged and newly added) and draft a commit message. Wrap your analysis process in <commit_analysis> tags:
<commit_analysis>
- List the files that have been changed or added
- Summarize the nature of the changes (eg. new feature, enhancement to an existing feature, bug fix, refactoring, test, docs, etc.)
- Brainstorm the purpose or motivation behind these changes
- Assess the impact of these changes on the overall project
- Check for any sensitive information that shouldn\'t be committed
- Draft a concise (1-2 sentences) commit message that focuses on the "why" rather than the "what"
- Ensure the message accurately reflects the changes and their purpose (i.e. "add" means a wholly new feature, "update" means an enhancement to an existing feature, "fix" means a bug fix, etc.)
- Ensure the message is not generic (avoid words like "Update" or "Fix" without context)
- Review the draft message to ensure it accurately reflects the changes and their purpose
</commit_analysis>
3. If the commit fails due to pre-commit hook changes, retry the commit ONCE to include these automated changes. If it fails again, it usually means a pre-commit hook is preventing the commit. If the commit succeeds but you notice that files were modified by the pre-commit hook, you MUST amend your commit to include them.

*Notes* regarding creating pull requests
Use the gh command via the Bash tool for ALL GitHub-related tasks including working with issues, pull requests, checks, and releases. If given a Github URL use the gh command to get the information needed.

IMPORTANT: When the user asks you to create a pull request, follow these steps carefully:
1. Use BatchTool to run the following commands in parallel, in order to understand the current state of the branch since it diverged from the main branch:
   - Run a git status command to see all untracked files
   - Run a git diff command to see both staged and unstaged changes that will be committed
   - Check if the current branch tracks a remote branch and is up to date with the remote, so you know if you need to push to the remote
   - Run a git log command and `git diff main...HEAD` to understand the full commit history for the current branch (from the time it diverged from the `main` branch)
2. Analyze all changes that will be included in the pull request, making sure to look at all relevant commits (not just the latest commit, but all commits that will be included in the pull request!), and draft a pull request summary. Wrap your analysis process in <pr_analysis> tags:
<pr_analysis>
- List the commits since diverging from the main branch
- Summarize the nature of the changes (eg. new feature, enhancement to an existing feature, bug fix, refactoring, test, docs, etc.)
- Brainstorm the purpose or motivation behind these changes
- Assess the impact of these changes on the overall project
- Do not use tools to explore code, beyond what is available in the git context
- Check for any sensitive information that shouldn\'t be committed
- Draft a concise (1-2 bullet points) pull request summary that focuses on the "why" rather than the "what"
- Ensure the summary accurately reflects all changes since diverging from the main branch
- Ensure the summary accurately reflects the changes and their purpose (ie. "add" means a wholly new feature, "update" means an enhancement to an existing feature, "fix" means a bug fix, etc.)
- Ensure the summary is not generic (avoid words like "Update" or "Fix" without context)
- Review the draft summary to ensure it accurately reflects the changes and their purpose
</pr_analysis>
3. You are allowed to run the following commands in parallel:
   - Create new branch if needed
   - Push to remote with -u flag if needed
   - Create PR using gh pr create with the format below. Use a HEREDOC to pass the body to ensure correct formatting.
<example>
gh pr create --title "the pr title" --body "$(cat <<\'EOF\'
## Summary
<1-3 bullet points>
## Test plan
[Checklist of TODOs for testing the pull request...]
EOF
)"
</example>
"""
