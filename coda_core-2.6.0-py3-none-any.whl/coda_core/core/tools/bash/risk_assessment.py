import re
import platform
import shlex
from typing import Dict, Any

from loguru import logger

from coda_core.config.system_info import SystemInfo
from coda_core.core.tools.constants import (
    RISK_LEVEL_SAFE,
    RISK_LEVEL_LOW,
    RISK_LEVEL_MEDIUM,
    RISK_LEVEL_HIGH,
    RISK_LEVEL_CRITICAL,
    BASH_RISK_CONFIG_UNIX,
    BASH_RISK_CONFIG_WIN
)


def parse_command(command: str) -> Dict[str, Any]:
    """
    Parse a bash command into its components for analysis.
    
    Args:
        command (str): The bash command to parse
        
    Returns:
        Dict[str, Any]: A dictionary containing parsed command information
    """
    result = {
        "original_command": command,
        "tokens": [],
        "base_command": None,
        "args": [],
        "has_redirection": False,
        "has_pipe": False,
        "has_shell_expansion": False,
        "parsing_error": None
    }
    
    # Check for empty command
    if not command or command.strip() == "":
        return result
    
    # Check for basic redirections and pipes
    result["has_redirection"] = any(symbol in command for symbol in [">", ">>", "<"])
    result["has_pipe"] = "|" in command
    result["has_shell_expansion"] = any(pattern in command for pattern in ["$(", "`", "${"])
    
    # Try to tokenize the command for more detailed analysis
    try:
        tokens = shlex.split(command)
        result["tokens"] = tokens
        
        if tokens:
            result["base_command"] = tokens[0]
            result["args"] = tokens[1:] if len(tokens) > 1 else []
            
    except ValueError as e:
        # If we can't parse, record the error but continue with what we have
        result["parsing_error"] = str(e)
        
        # Try a basic split as fallback
        parts = command.split()
        if parts:
            result["base_command"] = parts[0]
            result["args"] = parts[1:] if len(parts) > 1 else []
    
    return result


def analyze_command(parsed_command: Dict[str, Any]) -> Dict[str, Any]:
    """
    Analyze a parsed command to determine its risk level and provide explanations.
    
    Args:
        parsed_command (Dict[str, Any]): The parsed command information
        
    Returns:
        Dict[str, Any]: A dictionary containing risk assessment information
    """
    command = parsed_command["original_command"]
    base_cmd = parsed_command["base_command"]
    
    assessment = {
        "command": command,
        "risk_level": RISK_LEVEL_SAFE,
        "reasons": [],
        "warnings": [],
        "recommendation": None
    }
    
    # Decide risk configuration based on platform
    BASH_RISK_CONFIG = BASH_RISK_CONFIG_UNIX if SystemInfo.detect_system_based_on_shell() != "windows" else BASH_RISK_CONFIG_WIN

    # Check for parsing errors
    if parsed_command["parsing_error"]:
        assessment["risk_level"] = RISK_LEVEL_MEDIUM
        assessment["reasons"].append(f"Command has complex syntax that couldn't be safely parsed: {parsed_command['parsing_error']}")
        assessment["recommendation"] = "Consider simplifying the command syntax."
        return assessment
    
    # Check for critical risk patterns
    for pattern, explanation in BASH_RISK_CONFIG.get('critical_risk_patterns', {}).items():
        if re.search(pattern, command):
            assessment["risk_level"] = RISK_LEVEL_CRITICAL
            assessment["reasons"].append(f"Command matches critical risk pattern: {explanation}")
            assessment["recommendation"] = "This command is extremely dangerous and should not be executed."
            return assessment
    
    # Check for high risk commands
    if base_cmd in BASH_RISK_CONFIG.get('high_risk_commands', {}):
        assessment["risk_level"] = RISK_LEVEL_HIGH
        explanation = BASH_RISK_CONFIG['high_risk_commands'][base_cmd]
        assessment["reasons"].append(f"Command '{base_cmd}' is potentially dangerous: {explanation}")
        
        # Add specific analysis for certain commands
        if base_cmd == "rm":
            args = parsed_command["args"]
            if "-rf" in args or ("-r" in args and "-f" in args):
                assessment["warnings"].append("Using recursive and force flags together with rm is dangerous")
                
        elif base_cmd == "chmod":
            args = parsed_command["args"]
            if "777" in args or "a+rwx" in args:
                assessment["warnings"].append("Setting world-writable permissions is a security risk")
        
        assessment["recommendation"] = "Review command carefully before execution."
    
    # Check for medium risk commands
    elif base_cmd in BASH_RISK_CONFIG.get('medium_risk_commands', {}):
        assessment["risk_level"] = RISK_LEVEL_MEDIUM
        explanation = BASH_RISK_CONFIG['medium_risk_commands'][base_cmd]
        assessment["reasons"].append(f"Command '{base_cmd}' has medium risk: {explanation}")
    
    # Check for sensitive paths
    for path in BASH_RISK_CONFIG.get('sensitive_paths', []):
        if path in command:
            if assessment["risk_level"] == RISK_LEVEL_SAFE:
                assessment["risk_level"] = RISK_LEVEL_LOW
            assessment["warnings"].append(f"Command operates on sensitive path: {path}")
    
    # Check dangerous patterns
    for pattern, score in BASH_RISK_CONFIG.get('dangerous_patterns', {}).items():
        if re.search(pattern, command):
            # Upgrade risk level based on pattern score
            if score >= BASH_RISK_CONFIG['thresholds'].get('high', 8):
                if assessment["risk_level"] not in [RISK_LEVEL_HIGH, RISK_LEVEL_CRITICAL]:
                    assessment["risk_level"] = RISK_LEVEL_HIGH
            elif score > BASH_RISK_CONFIG['thresholds'].get('low', 3):
                if assessment["risk_level"] not in [RISK_LEVEL_MEDIUM, RISK_LEVEL_HIGH, RISK_LEVEL_CRITICAL]:
                    assessment["risk_level"] = RISK_LEVEL_MEDIUM
            else:
                if assessment["risk_level"] == RISK_LEVEL_SAFE:
                    assessment["risk_level"] = RISK_LEVEL_LOW
            
            assessment["warnings"].append(f"Command contains potentially risky pattern: {pattern}")
    
    # Check for shell features that increase risk
    if parsed_command["has_pipe"] and any(shell in command for shell in ["bash", "sh", "zsh"]):
        if assessment["risk_level"] not in [RISK_LEVEL_HIGH, RISK_LEVEL_CRITICAL]:
            assessment["risk_level"] = RISK_LEVEL_MEDIUM
        assessment["warnings"].append("Command pipes output to a shell, which can execute arbitrary code")
    
    if parsed_command["has_redirection"] and ">" in command and not ">>" in command:
        if assessment["risk_level"] == RISK_LEVEL_SAFE:
            assessment["risk_level"] = RISK_LEVEL_LOW
        assessment["warnings"].append("Command uses file overwrite redirection")
    
    if parsed_command["has_shell_expansion"]:
        if assessment["risk_level"] == RISK_LEVEL_SAFE:
            assessment["risk_level"] = RISK_LEVEL_LOW
        assessment["warnings"].append("Command uses shell expansion which can have unexpected behavior")
    
    # Add recommendations based on risk level if not already set
    if not assessment["recommendation"]:
        if assessment["risk_level"] == RISK_LEVEL_HIGH:
            assessment["recommendation"] = "Carefully review this command before execution."
        elif assessment["risk_level"] == RISK_LEVEL_MEDIUM:
            assessment["recommendation"] = "Consider using safer alternatives."
        elif assessment["risk_level"] == RISK_LEVEL_LOW:
            assessment["recommendation"] = "Command appears relatively safe but review before execution."
        else:
            assessment["recommendation"] = "Command appears safe."
    
    return assessment


def assess_command_risk(command: str) -> Dict[str, Any]:
    """
    Assess the risk level of a bash command.
    
    This is the main function that combines parsing and analysis.
    
    Args:
        command (str): The bash command to assess
        
    Returns:
        Dict[str, Any]: A dictionary containing risk assessment information
    """
    try:
        # Parse the command
        parsed_command = parse_command(command)
        
        # Analyze the parsed command
        assessment = analyze_command(parsed_command)
        
        return assessment
        
    except Exception as e:
        # If anything goes wrong during assessment, treat as medium risk
        logger.exception(f"Error during command risk assessment: {e}")
        return {
            "command": command,
            "risk_level": RISK_LEVEL_MEDIUM,
            "reasons": [f"Error during risk assessment: {str(e)}"],
            "warnings": ["Unable to properly assess command safety"],
            "recommendation": "Unable to properly assess risk. Review manually before execution."
        }