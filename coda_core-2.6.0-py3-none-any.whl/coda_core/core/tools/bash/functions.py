from loguru import logger
from typing import Annotated, Dict, Any, Callable, Optional

from coda_core.core.tools.bash.executor import BashExecutor
from coda_core.core.tools.bash.types import ResultStatus


def truncate_output(output: str, max_length: int) -> str:
    """
    Truncate a string to a specified maximum length, adding ellipses if truncation occurs.

    Args:
        output (str): The string output to possibly truncate.
        max_length (int): The maximum allowed length of the output string.

    Returns:
        str: The truncated string, with ellipses added if truncation was necessary.
    """
    if len(output) > max_length:
        half_length = max_length // 2
        return (
            output[:half_length] +
            '\n... [output truncated] ...\n' +
            output[-half_length:]
        )
    return output


def execute_bash_command(
    command: Annotated[str, "The bash command to execute."],
    timeout: Annotated[int, "Optional. Maximum time (in seconds) to wait for command completion. Default is 30 seconds."] = 30,
    max_output_length: Annotated[int, "Optional. Maximum length of output to return before truncating. Default is 1000."] = 1000,
    on_stdout_line: Optional[Callable[[str], None]] = None,
    on_stderr_line: Optional[Callable[[str], None]] = None,
    on_heartbeat: Optional[Callable[[int], None]] = None,
) -> Dict[str, Any]:
    """
    Execute a bash command with optional timeout and output truncation.

    This is a thin wrapper around the internal streaming executor (BashExecutor). It preserves
    the legacy return schema used by callers of execute_bash_command while delegating process
    execution, encoding detection, and text error handling to BashExecutor.

    Args:
        command (str): The bash command to execute.
        timeout (int, optional): Maximum time in seconds to wait for command completion. Defaults to 30.
        max_output_length (int, optional): Maximum length for stdout/stderr in the returned dict. Truncation occurs after execution.
        on_stdout_line (Optional[Callable[[str], None]]): Callback invoked per stdout line (trimmed, no trailing newline). Forwarded to BashExecutor.run().
        on_stderr_line (Optional[Callable[[str], None]]): Callback invoked per stderr line (trimmed, no trailing newline). Forwarded to BashExecutor.run().
        on_heartbeat (Optional[Callable[[int], None]]): Callback invoked after prolonged silence. Receives elapsed milliseconds. Forwarded to BashExecutor.run().

    Returns:
        Dict[str, Any]: A dictionary containing:
            - status: 'success' or 'error'
            - stdout: possibly truncated stdout (on success or error)
            - stderr: possibly truncated stderr (on success or error)
            - exit_code: present on non-zero exit status
            - message: present on timeout, prompt detection, or other errors
            - command: the executed command (present on all error statuses)
            - prompt_excerpt: matched prompt line (present only on PROMPT_DETECTED)
    """
    try:
        t_out = float(timeout) if timeout is not None else None
        executor = BashExecutor(command=command, timeout_seconds=t_out)
        exec_result = executor.run(
            on_stdout_line=on_stdout_line,
            on_stderr_line=on_stderr_line,
            on_heartbeat=on_heartbeat,
        )

        # Normalize buffers and apply post-exec truncation for presentation
        stdout = truncate_output(output=(exec_result.stdout or ""), max_length=max_output_length)
        stderr = truncate_output(output=(exec_result.stderr or ""), max_length=max_output_length)

        status = exec_result.status

        if status == ResultStatus.SUCCESS:
            return {
                "status": "success",
                "stdout": stdout,
                "stderr": stderr,
            }

        if status == ResultStatus.TIMEOUT:
            logger.warning(f"Command timed out: {command}")
            return {
                "status": "error",
                "message": exec_result.message,
                "command": command,
                "stdout": stdout,
                "stderr": stderr,
            }

        # Map interactive prompt detection to the legacy error-shaped schema with detection metadata
        if status == ResultStatus.PROMPT_DETECTED:
            prompt_excerpt = exec_result.prompt_excerpt
            logger.warning("interactive_prompt_detected command='{}' excerpt='{}'", command, prompt_excerpt)
            return {
                "status": "error",
                "message": "Interactive prompt detected",
                "command": command,
                "stdout": stdout,
                "stderr": stderr,
                "prompt_excerpt": prompt_excerpt,
            }
 
        if status == ResultStatus.ERROR:
            exit_code = exec_result.exit_code
            message = exec_result.message
            logger.error(f"{message}: {command}")
            result_dict = {
                "status": "error",
                "message": message,
                "stdout": stdout,
                "stderr": stderr,
                "command": command,
            }
            if exit_code is not None:
                result_dict["exit_code"] = exit_code
            return result_dict

        return {
            "status": "error",
            "message": str(exec_result.message or ""),
            "stdout": stdout,
            "stderr": stderr,
            "command": command,
        }

    except FileNotFoundError:
        logger.error(f"Command not found: {command}")
        return {
            "status": "error",
            "message": f"Command not found: {command}",
            "command": command,
        }
    except Exception as e:
        logger.exception("Unexpected error occurred during command execution")
        return {
            "status": "error",
            "message": str(e),
            "command": command,
        }