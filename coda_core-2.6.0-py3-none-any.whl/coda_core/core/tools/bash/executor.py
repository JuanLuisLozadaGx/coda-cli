import os
import signal
import subprocess
import threading
import time
from typing import Callable, Optional, List, Tuple, TextIO, Pattern

import psutil
from loguru import logger

from coda_core.config.system_info import SystemInfo
from coda_core.core.utils.regex_utils import compile_patterns

from coda_core.core.tools.bash.constants import (
    HEARTBEAT_INTERVAL_MS,
    MAX_STREAM_LINE_BYTES,
    OUTPUT_MAX_BYTES,
    READER_JOIN_TIMEOUT_SECONDS,
    HEARTBEAT_JOIN_TIMEOUT_SECONDS,
    WATCHDOG_JOIN_TIMEOUT_SECONDS,
    CANCEL_GRACE_MS,
    KILL_GRACE_MS,
    CHILD_CLEANUP_WAIT_SECONDS,
    PROMPT_REGEX_STRINGS,
)
from coda_core.core.tools.bash.types import (
    ExecutorResult,
    ResultStatus,
    TextErrorPolicy,
    CancellationPolicy,
    CancellationResult,
    CancellationStage,
    CancellationOutcome,
)
 
DEFAULT_PROMPT_PATTERNS: Tuple[Pattern[str], ...] = tuple(
    compile_patterns(patterns=PROMPT_REGEX_STRINGS)
)

class BashExecutor:
    """Run a shell command with foreground streaming, heartbeats, and bounded buffers.

    Behavior:
      - Spawns a subprocess with shell=True using console encoding from SystemInfo.detect_console_encoding()
        and TextErrorPolicy.REPLACE for subprocess text I/O and internal encode/decode operations.
      - Redirects stdout/stderr to pipes (text mode) for line-by-line streaming; stdin is not interactive by default.
      - Streams stdout/stderr concurrently via reader threads, trimming each line to at most MAX_STREAM_LINE_BYTES
        (by encoded length). Trimmed lines are what enter the final buffers.
      - Emits heartbeats via a callback after prolonged silence; cadence is controlled by HEARTBEAT_INTERVAL_MS.
      - Maintains ring-buffered final outputs with a total cap OUTPUT_MAX_BYTES, split across stdout/stderr.
      - Enforces an optional timeout via a watchdog; if exceeded, sets TIMEOUT and includes partial buffers.

    Threading and shutdown:
      - Threads: stdout-reader, stderr-reader, heartbeat, and an optional timeout watchdog.
      - Reader threads block in readline() and exit on EOF when the process exits or is killed; they do not poll stop events.
        Each line read updates last_output_ns and is forwarded to callbacks.
      - Heartbeat thread checks quiet time since last output and emits at most once per quiet window to avoid spam.
      - Watchdog exists only when a timeout is configured; on expiry it sets _timed_out=True and delegates to cancel() for staged termination (with a fallback to process.kill() if cancel() raises).
      - The main thread always sets a shared stop_event in a finally block, then joins threads with:
          READER_JOIN_TIMEOUT_SECONDS, HEARTBEAT_JOIN_TIMEOUT_SECONDS, WATCHDOG_JOIN_TIMEOUT_SECONDS.

    Stdio and interactivity:
      - stdout/stderr are piped; stdin is connected to /dev/null (subprocess.DEVNULL).
      - Commands that require interactive input will block or error. Heartbeats make such idle periods visible.
      - Reader threads perform interactive prompt detection: each line is matched against compiled patterns
        from PROMPT_REGEX_STRINGS. On the first match the executor auto-cancels the process tree via cancel()
        and returns PROMPT_DETECTED with the matched line in prompt_excerpt.

    Logging policy:
      - No per-line logging; use callbacks to render lines in the UI/CLI.
      - Minimal structured logs for start, completion, timeout, and cancellation events.
      - Interactive prompt detection logs the matched line and the cancellation outcome.

    Notes and roadmap:
      - Each invocation starts the child process in a new session / process group (where supported),
        allowing cancellation to target the entire process tree via cancel() and related policies.
      - Spill-to-file for outputs exceeding memory caps will be introduced in a subsequent phase.
    """

    def __init__(
        self,
        command: str,
        timeout_seconds: Optional[float] = None,
    ) -> None:
        """Initialize the executor with command and runtime parameters.

        Args:
            command (str): Shell command to execute.
            timeout_seconds (Optional[float]): Wall-clock timeout in seconds. If None, no timeout is enforced.
        """
        self._command: str = command
        self._timeout_seconds: Optional[float] = timeout_seconds

        self._heartbeat_interval_ms: int = int(HEARTBEAT_INTERVAL_MS)
        self._max_stream_line_bytes: int = int(MAX_STREAM_LINE_BYTES)
        self._output_max_bytes: int = int(OUTPUT_MAX_BYTES)

        # Split output cap evenly across stdout/stderr ring buffers.
        half_cap = max(1, self._output_max_bytes // 2)
        self._stdout_cap_bytes: int = half_cap
        self._stderr_cap_bytes: int = half_cap

        # Internal state
        self._start_ns: int = 0
        self._last_output_ns: int = 0
        self._stop_event: threading.Event = threading.Event()
        self._timed_out: bool = False
        self._prompt_excerpt: Optional[str] = None  # Set when a prompt is detected

        # Cancellation policy and process handle
        self._policy: CancellationPolicy = CancellationPolicy(
            cancel_grace_ms=int(CANCEL_GRACE_MS),
            kill_grace_ms=int(KILL_GRACE_MS),
        )

        # Subprocess handle (set after start)
        self._process: Optional[subprocess.Popen] = None
        
        # Cache system detection once to avoid repeated calls and keep consistency across code paths.
        self._system: str = SystemInfo.detect_system_based_on_shell()

        # Ring buffers (store segments with their byte sizes for efficient trimming)
        self._stdout_segments: List[Tuple[str, int]] = []
        self._stderr_segments: List[Tuple[str, int]] = []
        self._stdout_bytes: int = 0
        self._stderr_bytes: int = 0

    def run(
        self,
        on_stdout_line: Optional[Callable[[str], None]] = None,
        on_stderr_line: Optional[Callable[[str], None]] = None,
        on_heartbeat: Optional[Callable[[int], None]] = None,
    ) -> ExecutorResult:
        """Execute the configured command and stream outputs via callbacks.

        Encoding and error handling:
            Uses SystemInfo.detect_console_encoding() and TextErrorPolicy.REPLACE for subprocess text I/O
            and for all internal encode/decode operations when trimming/assembling buffers.

        Args:
            on_stdout_line (Optional[Callable[[str], None]]): Callback invoked per stdout line (trimmed with MAX_STREAM_LINE_BYTES, no trailing newline).
            on_stderr_line (Optional[Callable[[str], None]]): Callback invoked per stderr line (trimmed with MAX_STREAM_LINE_BYTES, no trailing newline).
            on_heartbeat (Optional[Callable[[int], None]]): Callback invoked after HEARTBEAT_INTERVAL_MS of silence. Receives elapsed milliseconds.

        Returns:
            ExecutorResult: Structured result with final status, exit code, stdout/stderr buffers (ring-buffered under OUTPUT_MAX_BYTES),
            and total elapsed milliseconds.
        """
        self._start_ns = time.monotonic_ns()
        self._last_output_ns = self._start_ns

        # Detect console encoding
        encoding = SystemInfo.detect_console_encoding()
        
        # Start subprocess in its own process group/session for whole-tree cancellation
        creationflags: int = 0
        start_new_session: bool = False
        if self._system == "windows":
            # CREATE_NEW_PROCESS_GROUP is only available on Windows
            creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        else:
            # POSIX: start a new session (setsid) so we can signal the group
            start_new_session = True

        process = subprocess.Popen(
            args=self._command,
            # Pipe stdout for line-by-line streaming and bounded ring buffers
            stdout=subprocess.PIPE,
            # Pipe stderr separately to stream independently and keep channels distinct
            stderr=subprocess.PIPE,
            # Make stdin non-interactive (no input is consumed from our process).
            # Note: some CLIs read from /dev/tty or spawn interactive children and can still block;
            # prompt detection handles those by cancelling deterministically and returning PROMPT_DETECTED.
            stdin=subprocess.DEVNULL,
            text=True,
            shell=True,
            encoding=encoding,
            errors=TextErrorPolicy.REPLACE,
            creationflags=creationflags,
            start_new_session=start_new_session,
        )
        self._process = process

        # Launch reader threads
        stdout_thread = threading.Thread(
            target=self._reader_loop,
            name="bash-stdout-reader",
            kwargs={
                "stream": process.stdout,
                "is_stdout": True,
                "on_line": on_stdout_line,
                "cap_bytes": self._stdout_cap_bytes,
            },
            daemon=True,
        )
        stderr_thread = threading.Thread(
            target=self._reader_loop,
            name="bash-stderr-reader",
            kwargs={
                "stream": process.stderr,
                "is_stdout": False,
                "on_line": on_stderr_line,
                "cap_bytes": self._stderr_cap_bytes,
            },
            daemon=True,
        )
        stdout_thread.start()
        stderr_thread.start()

        # Heartbeat monitoring thread (periodically checks quiet time)
        heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop,
            name="bash-heartbeat",
            kwargs={"on_heartbeat": on_heartbeat},
            daemon=True,
        )
        heartbeat_thread.start()

        # Timeout watchdog thread (if timeout specified)
        timeout_thread: Optional[threading.Thread] = None
        if self._timeout_seconds is not None:
            timeout_thread = threading.Thread(
                target=self._timeout_watchdog,
                name="bash-timeout-watchdog",
                kwargs={
                    "process": process,
                    "timeout_seconds": float(self._timeout_seconds),
                },
                daemon=True,
            )
            timeout_thread.start()

        # Wait for process to finish
        exit_code: Optional[int] = None
        try:
            exit_code = process.wait()
        except (KeyboardInterrupt, SystemExit, GeneratorExit):
            # Ensure the subprocess tree is terminated deterministically before the interrupt propagates.
            logger.warning("Interrupt detected; requesting staged cancellation")
            try:
                self.cancel(task_id="interrupt")
            finally:
                # Propagate upward so orchestration (agent/CLI) can handle uniformly.
                raise
        finally:
            # Signal all background threads to stop. Readers don't poll stop_event,
            # but they should already be exiting due to pipe EOF (normal exit or kill).
            # Heartbeat/watchdog do observe stop_event and will break promptly.
            self._stop_event.set()

            # Join background threads with bounded timeouts to prevent hangs in case
            # a callback misbehaves or a thread fails to exit. These values are tuned
            # to be generous for shutdown but keep the main thread responsive.
            stdout_thread.join(timeout=READER_JOIN_TIMEOUT_SECONDS)
            stderr_thread.join(timeout=READER_JOIN_TIMEOUT_SECONDS)
            heartbeat_thread.join(timeout=HEARTBEAT_JOIN_TIMEOUT_SECONDS)
            if timeout_thread is not None:
                timeout_thread.join(timeout=WATCHDOG_JOIN_TIMEOUT_SECONDS)

        elapsed_ms = int((time.monotonic_ns() - self._start_ns) / 1_000_000)

        stdout_final = self._assemble_buffer(is_stdout=True)
        stderr_final = self._assemble_buffer(is_stdout=False)

        # If an interactive prompt was detected, report deterministically
        if self._prompt_excerpt is not None:
            logger.warning("interactive_prompt_cancelled command='{}'", self._command)
            return ExecutorResult(
                status=ResultStatus.PROMPT_DETECTED,
                exit_code=exit_code,
                stdout=stdout_final,
                stderr=stderr_final,
                message="Interactive prompt detected and cancelled",
                command=self._command,
                elapsed_ms=elapsed_ms,
                prompt_excerpt=self._prompt_excerpt,
            )

        if self._timed_out:
            logger.warning(
                "BashExecutor timeout",
            )
            return ExecutorResult(
                status=ResultStatus.TIMEOUT,
                message=f"Command timed out after {self._timeout_seconds} seconds",
                stdout=stdout_final,
                stderr=stderr_final,
                command=self._command,
                elapsed_ms=elapsed_ms,
            )

        if exit_code is None:
            # Should not happen, but guard anyway
            logger.error(
                "BashExecutor finished with unknown exit code",
            )
            return ExecutorResult(
                status=ResultStatus.ERROR,
                exit_code=-1,
                stdout=stdout_final,
                stderr=stderr_final,
                message="Unknown exit code",
                command=self._command,
                elapsed_ms=elapsed_ms,
            )

        if exit_code != 0:
            logger.error(
                "BashExecutor error",
            )
            return ExecutorResult(
                status=ResultStatus.ERROR,
                exit_code=exit_code,
                stdout=stdout_final,
                stderr=stderr_final,
                message=f"Command failed with exit code {exit_code}",
                command=self._command,
                elapsed_ms=elapsed_ms,
            )

        logger.info(
            "BashExecutor completed",
        )
        return ExecutorResult(
            status=ResultStatus.SUCCESS,
            exit_code=exit_code,
            stdout=stdout_final,
            stderr=stderr_final,
            command=self._command,
            elapsed_ms=elapsed_ms,
        )

    def _reader_loop(
        self,
        stream: Optional[TextIO],
        is_stdout: bool,
        on_line: Optional[Callable[[str], None]],
        cap_bytes: int,
    ) -> None:
        """Read lines from the given stream, invoke callbacks, and maintain ring buffers.

        Semantics:
            - Blocking I/O: With text=True, readline() blocks until a newline or EOF.
            - Exit condition: Readers do NOT poll stop_event; they terminate when the subprocess
              closes its pipes (normal exit) or is killed (timeout), which yields EOF.
            - Streaming safety: Each line is trimmed to MAX_STREAM_LINE_BYTES (by encoded length)
              before being forwarded to callbacks and appended to ring buffers.
            - Progress tracking: Each successfully read line updates last_output_ns, which the
              heartbeat loop uses to determine quiet windows.

        Args:
            stream (Optional[TextIO]): File-like text stream for stdout or stderr.
            is_stdout (bool): True if reading stdout; False for stderr.
            on_line (Optional[Callable[[str], None]]): Callback to invoke for each trimmed line read.
            cap_bytes (int): Ring buffer capacity for this stream in bytes.
        """
        if stream is None:
            return

        # Read line-by-line. With text=True, readline() blocks until a newline or EOF.
        # Readers do NOT poll stop_event; they exit when the process closes pipes (normal exit or kill).
        for raw_line in iter(stream.readline, ""):
            # Trim trailing newline for callbacks/buffer consistency
            line = raw_line.rstrip("\r\n")

            # Enforce per-line byte cap for streaming to avoid pathological memory use
            trimmed = self._trim_line(line=line, max_bytes=self._max_stream_line_bytes)

            # Update last output timestamp
            self._last_output_ns = time.monotonic_ns()

            # Interactive prompt detection
            if self._prompt_excerpt is None:
                for _pattern in DEFAULT_PROMPT_PATTERNS:
                    if _pattern.search(trimmed) is not None:
                        self._prompt_excerpt = trimmed
                        try:
                            logger.warning("interactive_prompt_detected line='{}'", trimmed)
                            self.cancel(task_id="interactive_prompt_detected")
                        except Exception:
                            # Do not let detection flow break the reader; main thread will finalize.
                            pass
                        break

            # Send to UI callback (if provided)
            if on_line is not None:
                on_line(trimmed)

            # Append to ring buffer (cap in bytes)
            self._append_segment(
                text=trimmed,
                cap_bytes=cap_bytes,
                is_stdout=is_stdout,
            )

        try:
            stream.close()
        except Exception:
            # Silently ignore close errors
            pass

    def _heartbeat_loop(self, on_heartbeat: Optional[Callable[[int], None]]) -> None:
        """Emit heartbeat callbacks after quiet windows.

        Semantics:
            - Uses start_ns and last_output_ns maintained by the executor.
            - Checks at intervals of HEARTBEAT_INTERVAL_MS; emits only if no output has been
              observed for at least that duration.
            - Deduplicates per quiet window using last_emitted_for_ns != last_output_ns to avoid
              repeated heartbeats until new output arrives.

        Args:
            on_heartbeat (Optional[Callable[[int], None]]): Callback to notify with total elapsed milliseconds since start.
        """
        if on_heartbeat is None:
            # Nothing to do if no consumer cares about heartbeats
            self._stop_event.wait()
            return

        # Emit heartbeats after quiet windows:
        # - A heartbeat is emitted only if no output has arrived for >= HEARTBEAT_INTERVAL_MS.
        # - Deduplicated per quiet window using last_emitted_for_ns != last_output_ns to avoid spam.
        # - Any stdout/stderr line resets last_output_ns and suppresses heartbeat until quiet again.
        last_emitted_for_ns: int = 0
        interval_s: float = float(self._heartbeat_interval_ms) / 1000.0

        while not self._stop_event.is_set():
            interrupted = self._stop_event.wait(timeout=interval_s)
            if interrupted:
                break

            now_ns = time.monotonic_ns()
            quiet_ns = now_ns - self._last_output_ns
            if quiet_ns >= int(self._heartbeat_interval_ms * 1_000_000):
                # Avoid emitting the same heartbeat repeatedly if no new output has arrived.
                if self._last_output_ns != last_emitted_for_ns:
                    elapsed_ms = int((now_ns - self._start_ns) / 1_000_000)
                    try:
                        on_heartbeat(elapsed_ms)
                    except Exception:
                        # Protect executor from UI callback failures
                        pass
                    last_emitted_for_ns = self._last_output_ns

    def _timeout_watchdog(self, process: subprocess.Popen, timeout_seconds: float) -> None:
        """Trigger staged cancellation if the process exceeds the timeout.

        Semantics:
            - Waits on the shared stop_event for up to timeout_seconds. If the process exits
              normally before the timeout, the main thread sets stop_event and the watchdog exits.
            - If the timeout elapses first, marks _timed_out=True and delegates to cancel() for
              staged termination and child cleanup (unified behavior and logging).

        Args:
            process (subprocess.Popen): The subprocess instance to monitor.
            timeout_seconds (float): Wall-clock timeout in seconds.
        """
        interrupted = self._stop_event.wait(timeout=timeout_seconds)
        if interrupted:
            return
        # If we reached here, the timeout expired before the process exited.
        # Mark timed out and request staged cancellation. This closes pipes, which causes
        # reader threads (blocked in readline) to receive EOF. The main thread will then
        # set stop_event and join all background threads in run().
        self._timed_out = True
        try:
            self.cancel(task_id="timeout")
        except Exception:
            # Fallback: ensure process is not left running if cancellation path raises.
            try:
                process.kill()
            except Exception:
                pass

    def _append_segment(self, text: str, cap_bytes: int, is_stdout: bool) -> None:
        """Append a text segment to the appropriate ring buffer enforcing byte caps.

        Args:
            text (str): Line content to append (already trimmed).
            cap_bytes (int): Maximum capacity for the selected buffer in bytes.
            is_stdout (bool): Target buffer selector. True for stdout, False for stderr.
        """
        seg_bytes = len(text.encode(errors=TextErrorPolicy.REPLACE))
        if is_stdout:
            self._stdout_segments.append((text, seg_bytes))
            self._stdout_bytes += seg_bytes
            # Trim from the head when exceeding capacity
            while self._stdout_bytes > cap_bytes and self._stdout_segments:
                _, dropped_bytes = self._stdout_segments.pop(0)
                self._stdout_bytes -= dropped_bytes
        else:
            self._stderr_segments.append((text, seg_bytes))
            self._stderr_bytes += seg_bytes
            while self._stderr_bytes > cap_bytes and self._stderr_segments:
                _, dropped_bytes = self._stderr_segments.pop(0)
                self._stderr_bytes -= dropped_bytes

    @staticmethod
    def _trim_line(line: str, max_bytes: int) -> str:
        """Trim a line to at most max_bytes (by encoded length), preserving valid text.

        Notes:
            - Pure helper (static): does not depend on instance state.
            - Encoding/decoding uses TextErrorPolicy.REPLACE to avoid exceptions on undecodable bytes.

        Args:
            line (str): Original line content.
            max_bytes (int): Maximum encoded byte length to return.

        Returns:
            str: The possibly trimmed line (no newline).
        """
        encoded = line.encode(errors=TextErrorPolicy.REPLACE)
        if len(encoded) <= max_bytes:
            return line
        # Truncate on byte boundary and decode back
        trimmed = encoded[:max_bytes]
        return trimmed.decode(errors=TextErrorPolicy.REPLACE)

    def _assemble_buffer(self, is_stdout: bool) -> str:
        """Assemble the final stdout or stderr buffer from ring segments.

        Args:
            is_stdout (bool): True to assemble stdout; False for stderr.

        Returns:
            str: The concatenated final buffer string.
        """
        if is_stdout:
            return "\n".join(seg for seg, _ in self._stdout_segments)
        return "\n".join(seg for seg, _ in self._stderr_segments)

    def cancel(self, task_id: Optional[str] = None) -> CancellationResult:
        """Cancel the running process tree with staged termination.

        Dispatches to platform-specific implementations while keeping a consistent
        result shape and structured logging.

        Args:
            task_id (Optional[str]): Identifier for structured logging.

        Returns:
            CancellationResult: Summary of the cancellation attempt.
        """
        # Stop heartbeat promptly; readers exit when pipes close after process exit.
        self._stop_event.set()
        if self._system == "windows":
            return self._cancel_windows(task_id=task_id)
        return self._cancel_unix(task_id=task_id)

    def _cancel_unix(self, task_id: Optional[str]) -> CancellationResult:
        """UNIX cancellation: SIGINT → SIGTERM → SIGKILL to the process group.

        Args:
            task_id (Optional[str]): Identifier for logs.

        Returns:
            CancellationResult: Outcome with applied stages.
        """
        start_ns = time.monotonic_ns()
        stages_applied: List[CancellationStage] = []

        process = self._process
        if process is None or process.poll() is not None:
            return self._finalize_cancellation(
                task_id=task_id,
                start_ns=start_ns,
                stages_applied=stages_applied,
                outcome=CancellationOutcome.ALREADY_EXITED,
                details="Process already exited before cancellation.",
            )

        # SIGINT
        if self._apply_unix_stage(
            process=process,
            sig=signal.SIGINT,
            stage=CancellationStage.SIGINT,
            grace_ms=self._policy.cancel_grace_ms,
            stages_applied=stages_applied,
        ):
            return self._finalize_cancellation(
                task_id=task_id,
                start_ns=start_ns,
                stages_applied=stages_applied,
                outcome=CancellationOutcome.GRACEFUL,
                details="Exited after SIGINT.",
            )

        # SIGTERM
        if self._apply_unix_stage(
            process=process,
            sig=signal.SIGTERM,
            stage=CancellationStage.SIGTERM,
            grace_ms=self._policy.kill_grace_ms,
            stages_applied=stages_applied,
        ):
            return self._finalize_cancellation(
                task_id=task_id,
                start_ns=start_ns,
                stages_applied=stages_applied,
                outcome=CancellationOutcome.GRACEFUL,
                details="Exited after SIGTERM.",
            )

        # SIGKILL
        _ = self._apply_unix_stage(
            process=process,
            sig=signal.SIGKILL,
            stage=CancellationStage.SIGKILL,
            grace_ms=self._policy.kill_grace_ms,
            stages_applied=stages_applied,
        )

        # Best-effort cleanup of any detached children
        self._ensure_children_terminated(root_pid=process.pid)

        if process.poll() is None:
            return self._finalize_cancellation(
                task_id=task_id,
                start_ns=start_ns,
                stages_applied=stages_applied,
                outcome=CancellationOutcome.FAILED,
                details="Process still alive after SIGKILL.",
            )

        return self._finalize_cancellation(
            task_id=task_id,
            start_ns=start_ns,
            stages_applied=stages_applied,
            outcome=CancellationOutcome.FORCEFUL,
            details="Exited after SIGKILL.",
        )

    def _cancel_windows(self, task_id: Optional[str]) -> CancellationResult:
        """Windows cancellation: CTRL_BREAK → TerminateProcess across descendants.

        Args:
            task_id (Optional[str]): Identifier for logs.

        Returns:
            CancellationResult: Outcome with applied stages.
        """
        start_ns = time.monotonic_ns()
        stages_applied: List[CancellationStage] = []

        process = self._process
        if process is None or process.poll() is not None:
            return self._finalize_cancellation(
                task_id=task_id,
                start_ns=start_ns,
                stages_applied=stages_applied,
                outcome=CancellationOutcome.ALREADY_EXITED,
                details="Process already exited before cancellation.",
            )

        # CTRL_BREAK (graceful)
        if self._apply_windows_break(
            process=process,
            grace_ms=self._policy.cancel_grace_ms,
            stages_applied=stages_applied,
        ):
            return self._finalize_cancellation(
                task_id=task_id,
                start_ns=start_ns,
                stages_applied=stages_applied,
                outcome=CancellationOutcome.GRACEFUL,
                details="Exited after CTRL_BREAK.",
            )

        # TerminateProcess (forceful path)
        self._apply_windows_terminate(
            process=process,
            stages_applied=stages_applied,
        )

        # Ensure descendants are gone
        self._ensure_children_terminated(root_pid=process.pid)

        if process.poll() is None:
            return self._finalize_cancellation(
                task_id=task_id,
                start_ns=start_ns,
                stages_applied=stages_applied,
                outcome=CancellationOutcome.FAILED,
                details="Process still alive after TerminateProcess.",
            )

        return self._finalize_cancellation(
            task_id=task_id,
            start_ns=start_ns,
            stages_applied=stages_applied,
            outcome=CancellationOutcome.FORCEFUL,
            details="Exited after TerminateProcess.",
        )

    def _apply_unix_stage(
        self,
        process: subprocess.Popen,
        sig: int,
        stage: CancellationStage,
        grace_ms: int,
        stages_applied: List[CancellationStage],
    ) -> bool:
        """Send a Unix signal to the process group (fallback to process) and wait for exit.

        Args:
            process (subprocess.Popen): Target process handle.
            sig (int): POSIX signal to send.
            stage (CancellationStage): Stage enum to record if dispatched.
            grace_ms (int): Milliseconds to wait for a graceful exit.
            stages_applied (List[CancellationStage]): Collector for applied stages.

        Returns:
            bool: True if the process exited within the grace window, otherwise False.
        """
        sent: bool = False
        try:
            os.killpg(process.pid, sig)
            sent = True
        except Exception:
            try:
                process.send_signal(sig)
                sent = True
            except Exception:
                sent = False

        if sent:
            stages_applied.append(stage)
        return self._wait_for_exit(process=process, grace_ms=grace_ms)

    def _apply_windows_break(
        self,
        process: subprocess.Popen,
        grace_ms: int,
        stages_applied: List[CancellationStage],
    ) -> bool:
        """Send CTRL_BREAK to the Windows process group and wait for exit.

        Args:
            process (subprocess.Popen): Target process handle.
            grace_ms (int): Milliseconds to wait for a graceful exit.
            stages_applied (List[CancellationStage]): Collector for applied stages.

        Returns:
            bool: True if the process exited within the grace window.
        """
        try:
            process.send_signal(signal.CTRL_BREAK_EVENT)
            stages_applied.append(CancellationStage.CTRL_BREAK)
        except Exception:
            return False
        return self._wait_for_exit(process=process, grace_ms=grace_ms)

    def _apply_windows_terminate(
        self,
        process: subprocess.Popen,
        stages_applied: List[CancellationStage],
    ) -> None:
        """Forcefully terminate a Windows process (and descendants via cleanup).

        Args:
            process (subprocess.Popen): Target process handle.
            stages_applied (List[CancellationStage]): Collector for applied stages.
        """
        try:
            process.terminate()
            stages_applied.append(CancellationStage.TERMINATE)
        except Exception:
            try:
                process.kill()
                stages_applied.append(CancellationStage.TERMINATE)
            except Exception:
                pass

    def _finalize_cancellation(
        self,
        task_id: Optional[str],
        start_ns: int,
        stages_applied: List[CancellationStage],
        outcome: CancellationOutcome,
        details: str,
    ) -> CancellationResult:
        """Finalize cancellation by logging and returning the result.

        Args:
            task_id (Optional[str]): Optional identifier for structured logs.
            start_ns (int): Nanoseconds timestamp when cancellation started.
            stages_applied (List[CancellationStage]): Ordered stages performed.
            outcome (CancellationOutcome): Final outcome classification.
            details (str): Human-readable summary.

        Returns:
            CancellationResult: Finalized structured result.
        """
        elapsed_ms = int((time.monotonic_ns() - start_ns) / 1_000_000)
        logger.info(
            "BashExecutor cancellation",
            task_id=task_id,
            pid=self._process.pid if self._process is not None else None,
            stages=[s.value for s in stages_applied],
            outcome=outcome.value,
            elapsed_ms=elapsed_ms,
            details=details,
        )
        return CancellationResult(
            outcome=outcome,
            stages_applied=stages_applied,
            elapsed_ms=elapsed_ms,
            details=details,
        )

    @staticmethod
    def _wait_for_exit(process: subprocess.Popen, grace_ms: int) -> bool:
        """Wait for a process to exit within the provided grace window.

        Args:
            process (subprocess.Popen): Process handle to wait on.
            grace_ms (int): Milliseconds to wait before considering it still alive.

        Returns:
            bool: True if the process exited during the grace window, False otherwise.
        """
        try:
            process.wait(timeout=float(grace_ms) / 1000.0)
            return True
        except Exception:
            return False

    @staticmethod
    def _ensure_children_terminated(root_pid: int) -> None:
        """Best-effort termination of any remaining child processes.

        Args:
            root_pid (int): PID of the (former) root process.

        Notes:
            - Handles races where children exit between enumeration and signaling.
            - Applies terminate() followed by kill() if still alive after a short delay.
        """
        # Resolve root process; if it no longer exists, there is nothing to do.
        try:
            root = psutil.Process(root_pid)
        except Exception:
            return

        # Enumerate children once; on failure, continue with an empty list.
        try:
            children: List[psutil.Process] = root.children(recursive=True)
        except Exception:
            children = []

        # First pass: request graceful termination.
        for child in children:
            try:
                if child.is_running():
                    child.terminate()
            except Exception:
                # Ignore races and permission issues
                continue

        # Allow grace period before forceful termination
        time.sleep(CHILD_CLEANUP_WAIT_SECONDS)

        # Second pass: forcefully kill any remaining children still alive.
        for child in children:
            try:
                if child.is_running():
                    child.kill()
            except Exception:
                # Ignore races and permission issues
                continue