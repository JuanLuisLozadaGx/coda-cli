from typing import Final, List

# Streaming / Heartbeats / Output caps
HEARTBEAT_INTERVAL_MS: Final[int] = 15000

# Maximum number of bytes to consider per streamed line (guards against pathological no-newline floods)
MAX_STREAM_LINE_BYTES: Final[int] = 8192

# Maximum total bytes to retain in-memory across stdout + stderr final buffers
OUTPUT_MAX_BYTES: Final[int] = 1_048_576  # 1 MiB

# Cancellation/grace timings
CANCEL_GRACE_MS: Final[int] = 2000
KILL_GRACE_MS: Final[int] = 2000

# Child cleanup wait between graceful terminate and forceful kill, to allow exits to settle
CHILD_CLEANUP_WAIT_SECONDS: Final[float] = 0.2

# Thread join timeouts (seconds)
READER_JOIN_TIMEOUT_SECONDS: Final[float] = 5.0
HEARTBEAT_JOIN_TIMEOUT_SECONDS: Final[float] = 5.0
WATCHDOG_JOIN_TIMEOUT_SECONDS: Final[float] = 5.0

# Interactive prompt detection patterns
# Keep patterns conservative to avoid false positives.
PROMPT_REGEX_STRINGS: Final[List[str]] = [
    # Generic continue/proceed confirmations like "Proceed? [Y/n]"
    r"\b(continue|proceed|ok to proceed|are you sure)\b.*\[(?:y|Y)/(?:n|N)\]",
    # Overwrite/exists prompts
    r"\b(overwrite|replace)\b|\balready exists\b.*\?",
    # Password/sudo/passphrase prompts (line ending with colon is common)
    r"\b(password|passphrase|sudo)\b.*:$",
    # Package manager confirmations (apt, yum, dnf, brew, pacman)
    r"\b(apt(?:-get)?|yum|dnf|brew|pacman)\b.*\[(?:y|Y)/(?:n|N)\]",
    # Scaffolding/selection prompts (framework CLIs, generators)
    r"\b(select|choose|pick)\b.*\b(option|template|preset)\b",
    # Editor invocations (git -i, editors showing interactive UI cues)
    r"\b(edit|vim|vi|nano|emacs)\b.*(\[New File\]|-- INSERT --|press)",
]