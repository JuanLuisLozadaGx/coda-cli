from typing import Callable

from loguru import logger

from coda_core.config.system_info import SystemInfo
from coda_core.core.tools.function_tool import FunctionTool
from coda_core.core.tools.bash.description import BASH_TOOL_DESC, BASH_TOOL_SHORT_DESC
from coda_core.core.tools.bash.description_win import BASH_TOOL_DESC_WIN, BASH_TOOL_SHORT_DESC_WIN
from coda_core.core.tools.bash.functions import execute_bash_command

class BashTool(FunctionTool):
    """A tool for executing bash commands with streaming, heartbeats, and prompt detection.

    Wraps execute_bash_command (which delegates to BashExecutor) as a FunctionTool.
    Streaming callbacks (on_stdout_line, on_stderr_line, on_heartbeat) are excluded from
    the LLM-facing schema but allowed at runtime via allow_excluded_params=True, so the
    agent runtime can inject them without triggering parameter validation errors.

    Attributes:
        name (str): The name of the tool.
        description (str): A description of the tool (platform-specific).
        short_description (str): A brief description of the tool (platform-specific).
        function (Callable): The function used to execute bash commands.
    """

    name: str = "bash"
    description: str = BASH_TOOL_DESC if SystemInfo.detect_system_based_on_shell() != "windows" else BASH_TOOL_DESC_WIN
    short_description: str = BASH_TOOL_SHORT_DESC if SystemInfo.detect_system_based_on_shell() != "windows" else BASH_TOOL_SHORT_DESC_WIN
    function: Callable = execute_bash_command

    def __init__(self, name: str = name, description: str = description, short_description: str = short_description, function: Callable = function) -> None:
        """Initialize a BashTool instance.

        Args:
            name: The name of the tool.
            description: The description of the tool.
            short_description: A brief description of the tool.
            function: The function that executes bash commands.
        """
        super().__init__(
            name=name,
            description=description,
            short_description=short_description,
            function=function,
            exclude_params=["on_stdout_line", "on_stderr_line", "on_heartbeat"],        # Exclude streaming callbacks from the tool interface
            allow_excluded_params=True,
        )

        logger.info("Initialized BashTool")