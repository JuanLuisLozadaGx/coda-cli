from enum import StrEnum
from dataclasses import dataclass
from typing import List, Optional


class ResultStatus(StrEnum):
    """Execution outcome categories for bash command runs.

    Values:
        SUCCESS: The process completed with exit code 0.
        ERROR: The process completed with a non-zero exit code or failed to start.
        TIMEOUT: The process exceeded the configured timeout window.
        PROMPT_DETECTED: Interactive prompt detected at runtime and auto-cancelled.
    """
    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"
    PROMPT_DETECTED = "prompt_detected"


class TextErrorPolicy(StrEnum):
    """Text decoding/encoding error handling policy for streams and file operations."""
    REPLACE = "replace"
    STRICT = "strict"
    IGNORE = "ignore"


@dataclass(slots=True, frozen=True)
class ExecutorResult:
    """Structured result returned by the internal bash executor.

    Fields:
        status (ResultStatus): Final outcome category.
        exit_code (Optional[int]): Process exit code when available (None for timeout/unknown).
        stdout (str): Final captured standard output buffer (ring-buffered).
        stderr (str): Final captured standard error buffer (ring-buffered).
        message (Optional[str]): Human-readable message for errors, timeouts, or special outcomes.
        command (str): The shell command that was executed.
        elapsed_ms (int): Total elapsed time in milliseconds, including streaming.
        prompt_excerpt (Optional[str]): Last matched prompt line when an interactive prompt is detected; None otherwise.
    """
    status: ResultStatus
    exit_code: Optional[int] = None
    stdout: str = ""
    stderr: str = ""
    message: Optional[str] = None
    command: str = ""
    elapsed_ms: int = 0
    prompt_excerpt: Optional[str] = None


class CancellationStage(StrEnum):
    """Stages used during cross-platform staged termination.

    Values:
        SIGINT: Send SIGINT to a Unix process group (terminal-like Ctrl+C).
        SIGTERM: Send SIGTERM to a Unix process group (polite termination).
        SIGKILL: Send SIGKILL to a Unix process group (forceful).
        CTRL_BREAK: Send CTRL_BREAK event to a Windows process group.
        TERMINATE: Forceful termination on Windows via TerminateProcess.
    """
    SIGINT = "sigint"
    SIGTERM = "sigterm"
    SIGKILL = "sigkill"
    CTRL_BREAK = "ctrl_break"
    TERMINATE = "terminate"


class CancellationOutcome(StrEnum):
    """Final outcome of a cancellation attempt.

    Values:
        GRACEFUL: Process exited during the initial graceful stage(s).
        FORCEFUL: Process required forceful termination (SIGKILL/TerminateProcess).
        ALREADY_EXITED: Target process had already exited before cancellation began.
        FAILED: Cancellation sequence failed to terminate the process tree.
    """
    GRACEFUL = "graceful"
    FORCEFUL = "forceful"
    ALREADY_EXITED = "already_exited"
    FAILED = "failed"


@dataclass(slots=True)
class CancellationPolicy:
    """Configuration for staged termination grace periods.

    Attributes:
        cancel_grace_ms: Milliseconds to wait after the first (graceful) signal before escalating.
        kill_grace_ms: Milliseconds to wait after the second stage before force-killing.
    """
    cancel_grace_ms: int
    kill_grace_ms: int


@dataclass(slots=True)
class CancellationResult:
    """Result describing how cancellation finished.

    Attributes:
        outcome: Final cancellation outcome category.
        stages_applied: Ordered list of stages applied during cancellation.
        elapsed_ms: Total milliseconds spent performing cancellation.
        details: Human-readable details for logs or diagnostics.
    """
    outcome: CancellationOutcome
    stages_applied: List[CancellationStage]
    elapsed_ms: int
    details: str