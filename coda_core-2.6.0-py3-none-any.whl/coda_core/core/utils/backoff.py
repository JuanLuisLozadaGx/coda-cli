import random


def compute_exponential_base_delay(attempt: int, base_delay: float, max_multiplier: int) -> float:
    """Compute exponential backoff base delay.

    Args:
        attempt (int): Zero-based retry attempt number.
        base_delay (float): Base delay in seconds for attempt 0.
        max_multiplier (int): Cap for exponential growth (2**n).

    Returns:
        float: The computed base delay in seconds.
    """
    if attempt < 0:
        attempt = 0
    if max_multiplier < 0:
        max_multiplier = 0
    exp = 2 ** min(attempt, max_multiplier)
    return base_delay * exp


def apply_equal_jitter(delay: float, jitter_factor: float) -> float:
    """Apply equal jitter to a delay.

    Equal jitter returns delay/f + random(0, delay/f), where f is the jitter factor.

    Args:
        delay (float): The pre-jitter delay in seconds.
        jitter_factor (float): The equal jitter factor; typical value is 2.0.

    Returns:
        float: Jittered delay in seconds.
    """
    if jitter_factor <= 0:
        return delay
    jitter_unit = delay / jitter_factor
    return jitter_unit + random.uniform(0.0, jitter_unit)