import re
from typing import List, Optional, Pattern, Tuple


def compile_patterns(patterns: Optional[List[str]] = None) -> Tuple[Pattern[str], ...]:
    """Compile regex pattern strings for interactive prompt detection.

    Args:
        patterns (Optional[List[str]]): Regex pattern strings to compile. When None,
            callers should pass an explicit default (e.g., from constants) to avoid
            hidden globals.

    Returns:
        Tuple[Pattern[str], ...]: Compiled regex patterns with case-insensitive matching.
    """
    source: List[str] = [] if patterns is None else patterns
    compiled: List[Pattern[str]] = [re.compile(pattern=p, flags=re.IGNORECASE) for p in source]
    return tuple(compiled)