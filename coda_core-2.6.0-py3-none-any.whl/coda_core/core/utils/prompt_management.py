from typing import Any, Dict, List, Optional 

from loguru import logger

from coda_core.config.context.schemas import WorkspaceContext
from coda_core.core.models.utils import load_prompt
from coda_core.config.system_info import SystemInfo
from coda_core.core.tools.function_tool import FunctionTool
from coda_core.core.mcp.service import MCPService
from coda_core.core.utils.constants import MAIN_AGENT_PROMPT_TEMPLATE, AGENT_PROMPT_TEMPLATE
from coda_core.core.utils.skill_loader import get_skills_for_prompt


def create_system_prompt(
    tools: List[FunctionTool],
    workspace_context: Optional[WorkspaceContext] = None,
    additional_context: Optional[Dict[str, Any]] = None,
    template_name: Optional[str] = None
) -> str:
    """
    Create a system prompt with the provided tools and any additional context.

    Args:
        tools (List[FunctionTool]): List of tools to include in the system prompt.
        workspace_context (Optional[WorkspaceContext]): Optional workspace context to include in the prompt.
        additional_context (Optional[Dict[str, Any]]): Optional dictionary containing additional context to include in the prompt template rendering.
        template_name (Optional[str]): Optional name of the template to use for the system prompt

    Returns:
        str: The formatted system prompt
    """
    # Extract tool metadata for the system prompt
    tools_metadata = [
        {"name": tool.name,
         "short_description": tool.short_description}
        for tool in tools
    ]

    # Initialize the context for the Agent
    context = {'tools': tools_metadata}

    if workspace_context:
        # Initialize the context based on the provided workspace context.
        context.update(workspace_context.to_dict()) # Add the "env_info", "dir_info", and "git_info" sections.
    else:
        # Fallback to the SystemInfo initialization, which takes the CWD as the workspace context.
        sys_info = SystemInfo() # Only initialize the system_info if no context is provided.
        context["env_info"] = sys_info.get_formatted_environment_info()
        context["dir_info"] = sys_info.get_formatted_directory_structure_info()
        context["git_info"] = sys_info.get_formatted_git_info()

    # Add MCP server information if available
    try:
        mcp_service = MCPService.get()
        if mcp_service.is_available():
            # Get MCP prompt snippet
            mcp_snippet = mcp_service.prompt_snippet()
            if mcp_snippet:
                context['mcp_info'] = mcp_snippet
                logger.debug("Added MCP server information to prompt context")
    except Exception as e:
        logger.debug(f"Could not add MCP information to prompt: {e}")

    # Add skills information if available
    try:
        skills = get_skills_for_prompt()
        if skills:
            context['skills'] = skills
            logger.debug(f"Added {len(skills)} skills to prompt context")
    except Exception as e:
        logger.debug(f"Could not add skills information to prompt: {e}")

    # Add any additional context if provided
    if additional_context:
        context.update(additional_context)
    
    if template_name is None:
        template_name = MAIN_AGENT_PROMPT_TEMPLATE

    # Load the system prompt template
    system_prompt = load_prompt(
        template_name=template_name,
        context=context
    )

    return system_prompt


def create_agent_prompt(
    system_prompt: str, 
    agent_prompt: str 
) -> str:
    """
    Combine the main agent system prompt with the agent prompt.

    Args:
        system_prompt (str): The main agent system prompt.
            Located at `/config/prompts/single_agent_system_prompt.hbs`

        agent_prompt (str): The agent-specific prompt.
            Located at `/config/prompts/agent_prompt.hbs`

    Returns:
        str: The combined subagent prompt.
    """
    subagent_prompt = load_prompt(
        template_name=AGENT_PROMPT_TEMPLATE,
        context={
            'system_prompt': system_prompt,
            'agent_prompt': agent_prompt
        }
    )

    return subagent_prompt
