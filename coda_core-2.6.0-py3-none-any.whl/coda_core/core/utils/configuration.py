from typing import Dict

from coda_core.config.env_config import EnvConfig
from coda_core.config.settings import SETTINGS
from coda_core.core.models.providers.geai_client import GEAIClient
from coda_core.core.models.utils import normalize_reasoning_effort

from loguru import logger


def update_default_model(provider_name: str, model_name: str) -> bool:
    """
    Update the default model settings in environment variables.
    
    Args:
        provider_name: The provider name to set as default
        model_name: The model name to set as default
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Update system provider/model environment variables
        SETTINGS.set_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_PROVIDER_NAME, provider_name)
        SETTINGS.set_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_MODEL_NAME, model_name)
        
        # Also update single agent provider/model environment variables
        SETTINGS.set_env_var(EnvConfig.CODA_DEFAULT_SINGLE_AGENT_PROVIDER_NAME, provider_name)
        SETTINGS.set_env_var(EnvConfig.CODA_DEFAULT_SINGLE_AGENT_MODEL_NAME, model_name)
        
        logger.info(f"Default model updated to {provider_name}/{model_name}")
        return True
    except Exception as e:
        logger.error(f"Error updating default model: {e}")
        return False


def update_default_bash_security_level(level: str) -> bool:
    """
    Update the default bash security level in environment variables.
    
    Args:
        level: The security level to set as default ('low', 'medium', or 'high')
        
    Returns:
        bool: True if successful, False otherwise
    """
    # Normalize the level to lowercase and strip whitespace
    if level is None:
        logger.error("Security level cannot be None")
        return False
        
    normalized_level = level.lower().strip()
    
    # Validate the level
    valid_levels = ['low', 'medium', 'high']
    if normalized_level not in valid_levels:
        logger.error(f"Invalid security level: '{normalized_level}'. Must be one of: {', '.join(valid_levels)}")
        return False
        
    try:
        SETTINGS.set_env_var(EnvConfig.CODA_DEFAULT_BASH_SECURITY_LEVEL, normalized_level)
        logger.info(f"Default bash security level updated to {normalized_level}")
        return True
    except Exception as e:
        logger.error(f"Error updating default bash security level: {e}")
        return False


def update_default_reasoning_effort(effort: str) -> bool:
    """
    Update the default reasoning effort in environment variables.

    Args:
        effort: The reasoning effort value to persist.

    Returns:
        bool: True if successful, False otherwise.
    """
    normalized_effort = normalize_reasoning_effort(effort)
    if normalized_effort is None:
        logger.error(
            "Invalid reasoning effort: '{}'. Must be one of: default, none, minimal, low, medium, high",
            effort,
        )
        return False

    try:
        SETTINGS.set_env_var(EnvConfig.CODA_DEFAULT_REASONING_EFFORT, normalized_effort)
        logger.info(f"Default reasoning effort updated to {normalized_effort}")
        return True
    except Exception as e:
        logger.error(f"Error updating default reasoning effort: {e}")
        return False


def save_configuration(credentials: Dict[EnvConfig, str]) -> None:
    """
    Save configuration values to persistent storage.
    
    Args:
        credentials (Dict[EnvConfig, str]): Dictionary mapping environment variable enums to their values.
    
    Raises:
        ValueError: If GEAI credentials are invalid or cannot be verified.
    """
    # If set, validate GEAI credentials
    if EnvConfig.CODA_GEAI_BASE_URL in credentials and EnvConfig.CODA_GEAI_API_KEY in credentials:
        GEAIClient.validate_credentials(
            base_url=credentials[EnvConfig.CODA_GEAI_BASE_URL],
            api_key=credentials[EnvConfig.CODA_GEAI_API_KEY]
        )

    for var_enum, value in credentials.items():
        # Skip empty values
        if not value:
            continue
        
        try:
            # Save to environment
            SETTINGS.set_env_var(var_enum, value)
        except Exception as e:
            logger.error(f"Error saving {var_enum.value}: {str(e)}")
            raise RuntimeError(f"Failed to save {var_enum.value}: {str(e)}") from e
