from typing import List, Dict, Optional, TYPE_CHECKING
from loguru import logger

if TYPE_CHECKING:
    from coda_core.core.utils.skill_loader import SkillInfo


def generate_skill_list_for_prompt(skills: List["SkillInfo"]) -> List[Dict[str, str]]:
    """
    Generate a concise skill list for system prompt rendering.
    
    Args:
        skills: List of SkillInfo objects
        
    Returns:
        List of dictionaries with 'name' and 'description' keys
    """
    return [
        {
            "name": skill.name,
            "description": skill.description
        }
        for skill in skills if skill.enabled
    ]


def generate_skill_change_notification(skill_name: str, action: str) -> Optional[str]:
    """
    Generate a context message for skill state changes to inject into agent memory.
    
    Args:
        skill_name: Name of the skill that was changed.
        action: The action performed: "enabled", "disabled", or "removed".
        
    Returns:
        The formatted context message, or None if action is invalid.
    """
    if action == "enabled":
        return (
            f"[System Context: The skill '{skill_name}' has been enabled and is now available "
            f"via the run_skill tool. You can use it to help with user tasks.]"
        )
    elif action == "disabled":
        return (
            f"[System Context: The skill '{skill_name}' has been disabled and is no longer available. "
            f"Do not reference or attempt to use this skill, do not re-enable the skill. The user needs to re-enable the skill if they want to use it again.]"
        )
    elif action == "removed":
        return (
            f"[System Context: The skill '{skill_name}' has been permanently removed and is no longer available. "
            f"Do not reference or attempt to use this skill.]"
        )
    else:
        logger.warning(f"Unknown skill action: {action}")
        return None
