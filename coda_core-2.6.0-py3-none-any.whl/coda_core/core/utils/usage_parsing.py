from typing import Any


def get_usage_value(source: Any, key: str) -> Any:
    """
    Retrieve a value from either an object attribute or dict key.

    Args:
        source (Any): The object or dictionary to retrieve from.
        key (str): The key or attribute name.

    Returns:
        Any: The value found or None.
    """
    if isinstance(source, dict):
        return source.get(key)
    return getattr(source, key, None)


def parse_int_safe(value: Any, default: int = 0) -> int:
    """
    Safely coerce a value to int.

    Args:
        value (Any): The value to convert.
        default (int, optional): The default value to return if conversion fails. Defaults to 0.

    Returns:
        int: The converted integer value or the default.
    """
    if value is None:
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return default


def parse_float_safe(value: Any, default: float = 0.0) -> float:
    """
    Safely coerce a value to float.

    Args:
        value (Any): The value to convert.
        default (float, optional): The default value to return if conversion fails. Defaults to 0.0.

    Returns:
        float: The converted float value or the default.
    """
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default

