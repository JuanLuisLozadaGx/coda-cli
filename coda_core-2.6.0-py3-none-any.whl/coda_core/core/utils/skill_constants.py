import re

FRONTMATTER_PATTERN = re.compile(r'^---\s*\n(.+?)\n---\s*\n(.*)$', re.DOTALL)

# Skill format template for error messages
SKILL_FORMAT_TEMPLATE = """
Required format for skill.md or SKILL.md:

---
name: skill-name
description: Brief description of what this skill does
---

# Skill Instructions
Your skill content here...

Minimum required fields in frontmatter:
  - name: unique identifier for the skill (lowercase, hyphens allowed)
  - description: one-line summary shown in skill list

Optional fields:
  - license: License information
  - execution: Execution context configuration
  - Any custom metadata fields
"""
