from typing import Dict, Any, List, Optional
import json
import hashlib
import math
import tiktoken
from cachetools import LRUCache
from loguru import logger

from coda_core.core.utils.constants import (
    DEFAULT_CHAR_TO_TOKEN_RATIO,
    DEFAULT_CACHE_SIZE,
    TOKENS_PER_MESSAGE,
    TOKENS_PER_NAME,
    ASSISTANT_PRIMING_TOKENS,
    MESSAGE_METADATA_OVERHEAD_CHARS,
    MIN_TOKEN_COUNT,
    IMAGE_TOKEN_CONSERVATIVE_ESTIMATE,
    TOKEN_COUNT_FUDGE_FACTOR,
    DEFAULT_FALLBACK_ENCODING
)

def get_message_cache_key(message: Dict[str, Any]) -> str:
    """
    Generate a cache key for a message.
    
    Args:
        message: The message to generate a key for
        
    Returns:
        A string key for caching
    """
    # Convert message to a JSON string
    message_str = json.dumps(message, sort_keys=True)
    
    # Create a hash of the message string
    return hashlib.md5(message_str.encode()).hexdigest()


def estimate_tokens_by_chars(message: Dict[str, Any], char_to_token_ratio: int = DEFAULT_CHAR_TO_TOKEN_RATIO) -> int:
    """
    Estimate the number of tokens in a message using character count.
    
    This is a fallback method when tiktoken is not available.
    
    Args:
        message: The message to estimate tokens for
        char_to_token_ratio: Approximate number of characters per token
        
    Returns:
        Estimated token count
    """
    total_chars = 0
    
    # Handle Responses-style items
    if "type" in message and "role" not in message:
        item_type = message.get("type")
        total_chars = 0
        if item_type == "message":
            content = message.get("content", "")
            if isinstance(content, list):
                for item in content:
                    if isinstance(item, dict):
                        if item.get("type") in {"input_text", "output_text"}:
                            total_chars += len(item.get("text", ""))
                        elif item.get("type") == "refusal":
                            total_chars += len(item.get("refusal", ""))
            elif isinstance(content, str):
                total_chars += len(content)
            else:
                total_chars += len(str(content))
            total_chars += len(message.get("role", "")) if message.get("role") else 0
            total_chars += MESSAGE_METADATA_OVERHEAD_CHARS
            return max(MIN_TOKEN_COUNT, total_chars // char_to_token_ratio) if total_chars else 0
        if item_type in {"function_call", "function_tool_call"}:
            total_chars += len(message.get("name", "")) + len(str(message.get("arguments", "")))
            total_chars += MESSAGE_METADATA_OVERHEAD_CHARS
            return max(MIN_TOKEN_COUNT, total_chars // char_to_token_ratio)
        if item_type in {"function_call_output", "function_tool_call_output"}:
            total_chars += len(str(message.get("output", "")))
            total_chars += MESSAGE_METADATA_OVERHEAD_CHARS
            return max(MIN_TOKEN_COUNT, total_chars // char_to_token_ratio)
        if item_type == "reasoning":
            total_chars += len(str(message.get("id", "")))
            summary = message.get("summary", [])
            if isinstance(summary, list):
                for block in summary:
                    if isinstance(block, dict):
                        total_chars += len(str(block.get("text", "")))
            encrypted_content = message.get("encrypted_content")
            if isinstance(encrypted_content, str):
                total_chars += len(encrypted_content)
            total_chars += MESSAGE_METADATA_OVERHEAD_CHARS
            return max(MIN_TOKEN_COUNT, total_chars // char_to_token_ratio) if total_chars else 0
        if item_type == "unknown":
            raw = message.get("raw", message)
            total_chars += len(json.dumps(raw, ensure_ascii=False))
            total_chars += MESSAGE_METADATA_OVERHEAD_CHARS
            return max(MIN_TOKEN_COUNT, total_chars // char_to_token_ratio)
        return 0

    # Handle content (including multi-modal)
    content = message.get("content", "")
    if content is None:
        content = ""
    
    if isinstance(content, list):
        # Multi-modal content (text + images)
        for item in content:
                if isinstance(item, dict):
                    if item.get("type") in {"text", "input_text", "output_text"}:
                        text = item.get("text", "")
                        total_chars += len(text)
                elif item.get("type") == "image":
                    # Handle image token estimation
                    source = item.get("source", {})
                    if source.get("type") == "base64" and "data" in source:
                        data_length = len(source["data"])
                        image_tokens = max(1, int(math.ceil(math.sqrt(data_length))))
                        total_chars += image_tokens * char_to_token_ratio  # Convert back to chars
                    else:
                        # Conservative estimate for images without data
                        total_chars += IMAGE_TOKEN_CONSERVATIVE_ESTIMATE * char_to_token_ratio
    elif isinstance(content, str):
        total_chars += len(content)
    else:
        # Non-string content, convert to JSON
        total_chars += len(json.dumps(content))
    
    # Add characters for message metadata
    role_chars = len(message.get("role", ""))
    total_chars += role_chars
    
    # Handle tool calls if present
    if "tool_calls" in message and message["tool_calls"]:
        tool_call_chars = len(json.dumps(message["tool_calls"]))
        total_chars += tool_call_chars
    
    # Handle files if present - fix the files handling
    if "files" in message and message["files"]:
        for f in message["files"]:
            if isinstance(f, str):
                total_chars += len(f)
            elif hasattr(f, 'name'):
                total_chars += len(str(f.name))
            else:
                # Fallback for other file objects
                total_chars += len(str(f))
    
    # Handle tool message specific fields
    if message.get("role") == "tool":
        total_chars += len(message.get("tool_call_id", ""))
        total_chars += len(message.get("name", ""))
    
    # Handle function message specific fields
    if message.get("role") == "function":
        total_chars += len(message.get("name", ""))
        
    # Add overhead for message formatting
    total_chars += MESSAGE_METADATA_OVERHEAD_CHARS
    
    # Return 0 for truly empty messages
    if total_chars <= MESSAGE_METADATA_OVERHEAD_CHARS:
        return 0
    
    estimated_tokens = total_chars // char_to_token_ratio
    return max(MIN_TOKEN_COUNT, estimated_tokens)


def count_tokens_with_tiktoken(message: Dict[str, Any], encoding) -> int:
    """
    Count tokens in a message using tiktoken.
    
    Based on OpenAI's official implementation approach:
    https://cookbook.openai.com/examples/how_to_count_tokens_with_tiktoken
    
    Args:
        message: The message to count tokens for
        encoding: The tiktoken encoding to use
        
    Returns:
        Token count
    """
    # Start with tokens per message (3 tokens for formatting)
    num_tokens = TOKENS_PER_MESSAGE

    if "type" in message and "role" not in message:
        item_type = message.get("type")
        if item_type == "message":
            content = message.get("content", "")
            if isinstance(content, list):
                for item in content:
                    if isinstance(item, dict):
                        if item.get("type") in {"input_text", "output_text"}:
                            num_tokens += len(encoding.encode(item.get("text", "")))
                        elif item.get("type") == "refusal":
                            num_tokens += len(encoding.encode(item.get("refusal", "")))
            elif isinstance(content, str):
                num_tokens += len(encoding.encode(content))
            else:
                num_tokens += len(encoding.encode(str(content)))
            role = message.get("role")
            if role:
                num_tokens += len(encoding.encode(str(role)))
            return max(MIN_TOKEN_COUNT, num_tokens)
        if item_type in {"function_call", "function_tool_call"}:
            num_tokens += len(encoding.encode(message.get("name", "")))
            num_tokens += len(encoding.encode(str(message.get("arguments", ""))))
            return max(MIN_TOKEN_COUNT, num_tokens)
        if item_type in {"function_call_output", "function_tool_call_output"}:
            num_tokens += len(encoding.encode(str(message.get("output", ""))))
            return max(MIN_TOKEN_COUNT, num_tokens)
        if item_type == "reasoning":
            num_tokens += len(encoding.encode(str(message.get("id", ""))))
            summary = message.get("summary", [])
            if isinstance(summary, list):
                for block in summary:
                    if isinstance(block, dict):
                        num_tokens += len(encoding.encode(str(block.get("text", ""))))
            encrypted_content = message.get("encrypted_content")
            if isinstance(encrypted_content, str):
                num_tokens += len(encoding.encode(encrypted_content))
            return max(MIN_TOKEN_COUNT, num_tokens)
        if item_type == "unknown":
            raw = message.get("raw", message)
            num_tokens += len(encoding.encode(json.dumps(raw, ensure_ascii=False)))
            return max(MIN_TOKEN_COUNT, num_tokens)
        return max(MIN_TOKEN_COUNT, num_tokens)
    
    # Process each key-value pair in the message
    for key, value in message.items():
        if value is None:
            continue
            
        # Handle content field (can be string or multi-modal array)
        if key == "content":
            if isinstance(value, list):
                # Multi-modal content (text + images)
                for item in value:
                    if isinstance(item, dict):
                        if item.get("type") in {"text", "input_text", "output_text"}:
                            text = item.get("text", "")
                            if text:  # Only count non-empty text
                                num_tokens += len(encoding.encode(text))
                        elif item.get("type") == "image":
                            # Handle image token counting
                            source = item.get("source", {})
                            if source.get("type") == "base64" and "data" in source:
                                # Calculate based on base64 data length
                                data_length = len(source["data"])
                                image_tokens = max(1, int(math.ceil(math.sqrt(data_length))))
                                num_tokens += image_tokens
                            else:
                                # Conservative estimate for images without data
                                num_tokens += IMAGE_TOKEN_CONSERVATIVE_ESTIMATE
            elif isinstance(value, str) and value:
                # Simple string content
                num_tokens += len(encoding.encode(value))
            elif value:
                # Non-string, non-list content
                num_tokens += len(encoding.encode(json.dumps(value)))
        else:
            # Handle other fields (role, tool_calls, etc.)
            if isinstance(value, str):
                num_tokens += len(encoding.encode(value))
            else:
                num_tokens += len(encoding.encode(json.dumps(value)))
        
        # Special handling for "name" field (applies to all name fields)
        if key == "name":
            num_tokens += TOKENS_PER_NAME
    
    return max(MIN_TOKEN_COUNT, num_tokens)


def count_message_tokens(
    message: Dict[str, Any],
    encoding: Optional[Any] = None,
    char_to_token_ratio: int = DEFAULT_CHAR_TO_TOKEN_RATIO,
    cache: Optional[LRUCache] = None
) -> int:
    """
    Count tokens in a message using tiktoken if available, otherwise fall back to character-based estimation.
    Uses caching for improved performance if a cache is provided.
    
    Args:
        message: The message to estimate tokens for
        encoding: Optional tiktoken encoding instance
        char_to_token_ratio: Fallback character to token ratio if tiktoken fails
        cache: Optional LRUCache instance for caching token counts
        
    Returns:
        Token count
    """
    # Input validation
    if not isinstance(message, dict):
        raise ValueError("Message must be a dictionary")
    
    if not message:
        return 0
    
    if "role" not in message:
        if "type" not in message:
            raise ValueError("Message must contain 'role' or 'type' field")
    else:
        if not isinstance(message.get("role"), str):
            raise ValueError("Message 'role' must be a string")
        # Validate role values
        valid_roles = {"system", "user", "assistant", "tool", "function"}
        if message["role"] not in valid_roles:
            raise ValueError(f"Invalid role '{message['role']}'. Must be one of: {valid_roles}")
    
    # Check for truly empty messages (no meaningful content)
    content = message.get("content")
    if not content or (isinstance(content, list) and all(
        not item.get("text") and item.get("type") != "image" for item in content if isinstance(item, dict)
    )):
        # Check if message has any other meaningful fields
        meaningful_fields = {k: v for k, v in message.items()
                           if k not in ["role", "content"] and v is not None}
        if not meaningful_fields:
            # Include token count for image items
            image_count = sum(1 for item in content if isinstance(item, dict) and item.get("type") == "image")
            return image_count * IMAGE_TOKEN_CONSERVATIVE_ESTIMATE
    
    # Generate cache key
    cache_key = get_message_cache_key(message)
    
    # Check cache first if provided
    if cache is not None and cache_key in cache:
        return cache[cache_key]
    
    # Calculate token count
    if encoding is not None:
        try:
            token_count = count_tokens_with_tiktoken(message, encoding)
        except Exception as e:
            logger.debug(f"Tiktoken encoding failed: {e}. Falling back to character-based estimation.")
            token_count = estimate_tokens_by_chars(message, char_to_token_ratio)
    else:
        # Fall back to character-based estimation
        token_count = estimate_tokens_by_chars(message, char_to_token_ratio)
    
    # Apply fudge factor for better accuracy
    token_count = int(token_count * TOKEN_COUNT_FUDGE_FACTOR)
    
    # Cache the result if cache is provided
    if cache is not None:
        cache[cache_key] = token_count
    
    return token_count


def count_messages_tokens(
    messages: List[Dict[str, Any]],
    model_name: Optional[str] = None,
    encoding: Optional[Any] = None,
    char_to_token_ratio: int = DEFAULT_CHAR_TO_TOKEN_RATIO,
    cache: Optional[LRUCache] = None
) -> int:
    """
    Count tokens in a list of messages.
    
    Based on OpenAI's official implementation approach:
    https://cookbook.openai.com/examples/how_to_count_tokens_with_tiktoken
    
    Args:
        messages: List of message dictionaries
        model_name: Optional model name to get the appropriate encoding
        encoding: Optional tiktoken encoding instance (overrides model_name)
        char_to_token_ratio: Fallback character to token ratio
        cache: Optional LRUCache instance for caching token counts
        
    Returns:
        Total token count
    """
    if not messages:
        return 0
    
    # Get encoding if not provided but model_name is
    if encoding is None and model_name is not None:
        try:
            encoding = get_encoding_for_model(model_name)
        except Exception as e:
            logger.warning(f"Failed to get encoding for model {model_name}: {e}")
    
    # Count tokens for each message
    total_tokens = 0
    for message in messages:
        total_tokens += count_message_tokens(message, encoding, char_to_token_ratio, cache)
    
    # Add tokens for assistant priming (every reply is primed with <|start|>assistant<|message|>)
    total_tokens += ASSISTANT_PRIMING_TOKENS
    
    return total_tokens


def get_encoding_for_model(model_name: str) -> Any:
    """
    Get the appropriate tiktoken encoding for a model.
    
    Args:
        model_name: Name of the model
        
    Returns:
        Tiktoken encoding
    """
    model_name = model_name.lower()
    
    try:
        # Try to use tiktoken's built-in model mapping first
        return tiktoken.encoding_for_model(model_name)
    except KeyError:
        # For non-OpenAI models, use DEFAULT_FALLBACK_ENCODING
        return tiktoken.get_encoding(DEFAULT_FALLBACK_ENCODING)
    except Exception as e:
        logger.warning(f"Error getting encoding for model {model_name}: {e}")
        # Fall back to DEFAULT_FALLBACK_ENCODING as a safe default
        return tiktoken.get_encoding(DEFAULT_FALLBACK_ENCODING)


def create_token_cache(maxsize: int = DEFAULT_CACHE_SIZE) -> LRUCache:
    """
    Create a new token count cache.
    
    Args:
        maxsize: Maximum size of the cache
        
    Returns:
        A new LRUCache instance
    """
    return LRUCache(maxsize=maxsize)
