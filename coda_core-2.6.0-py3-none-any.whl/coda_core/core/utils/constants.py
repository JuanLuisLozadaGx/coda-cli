# Token counting constants
DEFAULT_CHAR_TO_TOKEN_RATIO = 4
DEFAULT_CACHE_SIZE = 20000

# Token counting magic numbers (see https://cookbook.openai.com/examples/how_to_count_tokens_with_tiktoken)
TOKENS_PER_MESSAGE = 3  # Each message has 3 formatting tokens
TOKENS_PER_NAME = 1  # Additional token when "name" field is present
ASSISTANT_PRIMING_TOKENS = 3  # Every reply is primed with <|start|>assistant<|message|>
MESSAGE_METADATA_OVERHEAD_CHARS = 10  # Additional characters for message metadata (fallback estimation)
MIN_TOKEN_COUNT = 1  # Minimum token count for any message

# Multi-modal content constants
IMAGE_TOKEN_CONSERVATIVE_ESTIMATE = 300  # Conservative estimate for images without data
TOKEN_COUNT_FUDGE_FACTOR = 1.15  # 15% buffer for token count accuracy

# Default fallback encoding
DEFAULT_FALLBACK_ENCODING = "cl100k_base"
MAIN_AGENT_PROMPT_TEMPLATE = 'single_agent_system_prompt.hbs'
AGENT_PROMPT_TEMPLATE = 'agent_prompt.hbs'