import os
import importlib.resources
from pathlib import Path
from typing import List, Dict, Optional, Any, Literal
from dataclasses import dataclass, field
from loguru import logger
import yaml
import json
import tempfile
import portalocker
import shutil
from coda_core.core.utils.skill_constants import FRONTMATTER_PATTERN, SKILL_FORMAT_TEMPLATE
from coda_core.core.utils.skill_formatters import generate_skill_list_for_prompt
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.config.constants import SKILLS_PACKAGE_NAME, DEFAULT_SKILLS


class SkillFormatError(Exception):
    """Raised when a skill file doesn't match the required format."""
    def __init__(self, skill_path: Path, issue: str, help_text: str = ""):
        self.skill_path = skill_path
        self.issue = issue
        self.help_text = help_text or SKILL_FORMAT_TEMPLATE
        super().__init__(f"{issue}\n\n{self.help_text}")


@dataclass
class SkillInfo:
    """
    Data structure representing a parsed skill.
    
    Attributes:
        name: The skill name (from YAML frontmatter)
        description: Brief description of the skill (from YAML frontmatter)
        license: License information (from YAML frontmatter, optional)
        full_content: Complete markdown content of the skill file (SKILL.md or skill.md)
        path: Absolute path to the skill directory
        metadata: Additional metadata from YAML frontmatter
        is_default: Whether this is a package default skill
        enabled: Whether this skill is enabled
        source: Where the skill was loaded from ('project' or 'system')
    """
    name: str
    description: str
    full_content: str
    path: Path
    license: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    is_default: bool = False
    enabled: bool = True
    source: str = "project"


class SkillLoader:
    """
    Handles discovery and parsing of skills from multiple directories.
    """
    
    SKILL_FILENAMES = ["skill.md", "SKILL.md"]
    
    def __init__(self, skill_directories: Optional[List[Path]] = None, session_id: str = "default"):
        """
        Initialize the SkillLoader.
        
        Args:
            skill_directories: Optional list of directories to scan for skills.
                If None, scans both project-local (.coda/skills) and system-wide (~/.coda/skills) directories.
                Project-local skills take precedence over system-wide skills when names conflict.
            session_id: Session identifier for session-specific skill state (disabled/removed).
                Defaults to "default" for backward compatibility.
        """
        
        if skill_directories is None:
            self.project_local_dir = Path.cwd() / ".coda" / "skills"
            self.system_dir = Path(SETTINGS.private_skills_dir)
            self.package_default_dir = None
            self.skill_directories = [self.project_local_dir, self.system_dir]
        else:
            self.project_local_dir = None
            self.system_dir = None
            self.package_default_dir = None
            self.skill_directories = [Path(d) for d in skill_directories]
        
        # Session identifier for per-session skill state
        self.session_id = session_id
        
        # Timestamp-based caching to avoid unnecessary filesystem scans
        self._last_dir_mtimes: Dict[Path, float] = {}
        self._cached_skills: Optional[List[SkillInfo]] = None
        
        # Track format errors during skill discovery
        self._format_errors: List[SkillFormatError] = []
        
        # Project-local disabled skills file
        self._disabled_skills_file = Path.cwd() / ".coda" / "disabled_skills.json"
        
        logger.debug(f"SkillLoader initialized with directories: {self.skill_directories}, session_id: {session_id}")

        # Track whether default skills have already been initialized
        self._default_skills_initialized = False

    def initialize_default_skills(self, force: bool = False) -> None:
        """
        Initialize default skills from package resources if they don't exist.

        Copies skill directories from the package resources to the system-wide
        skills directory (~/.coda/skills/). Each default skill is stored as a
        full directory (containing a SKILL.md or skill.md file plus any
        supporting scripts/, references/, etc.) under
        coda_core/config/prompts/skills/<skill-name>/ and is copied in its
        entirety to ~/.coda/skills/<skill-name>/ using shutil.copytree.

        The copying behavior is controlled by the CODA_COPY_DEFAULT_SKILLS
        environment variable (defaults to "true").

        Only skills whose directory name is listed in DEFAULT_SKILLS are copied.
        Existing skill directories are fully replaced when copying is enabled.

        Concurrency: the entire replace/copy loop is guarded by an exclusive
        cross-process lock on ``<skills_dir>/.default_skills.lock`` (via
        portalocker), so concurrent sessions/processes cannot produce partial
        or corrupt installs.

        Args:
            force: If True, re-run initialization even if already done this session.

        Returns:
            None
        """
        if self._default_skills_initialized and not force:
            logger.debug("Default skills already initialized; skipping copy step.")
            return

        try:
            should_copy = SETTINGS.get_env_var(EnvConfig.CODA_COPY_DEFAULT_SKILLS) == 'true'
            skills_dir = Path(SETTINGS.private_skills_dir)

            logger.info(f"Initializing default skills in directory: {skills_dir}")

            # Ensure skills_dir exists so we can place the lock file inside it.
            skills_dir.mkdir(parents=True, exist_ok=True)

            resources = importlib.resources.files(SKILLS_PACKAGE_NAME)
            resource_dirs = [item for item in resources.iterdir() if item.is_dir()]

            lock_path = skills_dir / ".default_skills.lock"
            with open(lock_path, "a") as lock_file:
                portalocker.lock(lock_file, portalocker.LOCK_EX)
                try:
                    for resource_dir in resource_dirs:
                        skill_name = resource_dir.name

                        if not should_copy:
                            logger.debug(
                                f"Skipped default skill {skill_name!r}: "
                                f"copy disabled (CODA_COPY_DEFAULT_SKILLS != 'true')."
                            )
                            continue

                        if skill_name not in DEFAULT_SKILLS:
                            logger.debug(
                                f"Skipped bundled skill {skill_name!r}: "
                                f"not in DEFAULT_SKILLS."
                            )
                            continue

                        dest_dir = skills_dir / skill_name

                        with importlib.resources.as_file(resource_dir) as source_path:
                            if dest_dir.exists():
                                shutil.rmtree(dest_dir)
                            shutil.copytree(source_path, dest_dir)
                        logger.info(f"Copied default skill: {skill_name}")
                finally:
                    portalocker.unlock(lock_file)

            logger.info(
                f"Default skills initialization complete. "
                f"Found {len(list(skills_dir.iterdir())) if skills_dir.exists() else 0} skills."
            )
            self._default_skills_initialized = True

        except Exception as e:
            logger.error(f"Error initializing default skills: {e}", exc_info=True)

    def _check_directories_changed(self) -> bool:
        """
        Check if any skill directories have been modified since last scan.
        
        Returns:
            True if any directory has changed, False otherwise
        """
        for skill_dir in self.skill_directories:
            if not skill_dir.exists():
                continue
            
            try:
                current_mtime = skill_dir.stat().st_mtime
                last_mtime = self._last_dir_mtimes.get(skill_dir, 0)
                
                if current_mtime > last_mtime:
                    logger.debug(f"Directory changed: {skill_dir} (mtime: {last_mtime} -> {current_mtime})")
                    return True
            except OSError as e:
                logger.error(f"Failed to check mtime for {skill_dir}: {e}")
                return True
        
        return False
    
    def _update_dir_timestamps(self) -> None:
        """Update stored modification times for all skill directories."""
        for skill_dir in self.skill_directories:
            if skill_dir.exists():
                try:
                    self._last_dir_mtimes[skill_dir] = skill_dir.stat().st_mtime
                except OSError as e:
                    logger.error(f"Failed to update mtime for {skill_dir}: {e}")
    
    def _load_session_data(self) -> Dict[str, Any]:
        """
        Load the full session-aware skill data from JSON file with file locking.
        
        Returns:
            Dict with structure: {session_id: {"disabled": [...], "removed": [...]}}
        """
        if not self._disabled_skills_file.exists():
            return {}
        
        try:
            with open(self._disabled_skills_file, 'r', encoding='utf-8') as f:
                portalocker.lock(f, portalocker.LOCK_SH)
                data = json.load(f)
                
                if not isinstance(data, dict):
                    logger.error(f"Invalid data format in {self._disabled_skills_file}, expected dict, got {type(data)}")
                    return {}
                
                for session_id, session_data in data.items():
                    if not isinstance(session_data, dict):
                        logger.error(f"Invalid session data for {session_id}, expected dict, got {type(session_data)}")
                        data[session_id] = {"disabled": [], "removed": []}
                    else:
                        if "disabled" not in session_data:
                            session_data["disabled"] = []
                        if "removed" not in session_data:
                            session_data["removed"] = []
                        
                        # Ensure disabled/removed are lists to avoid runtime errors later
                        if not isinstance(session_data.get("disabled"), list):
                            logger.error(
                                f"Invalid type for 'disabled' in session {session_id}, "
                                f"expected list, got {type(session_data.get('disabled'))}. Resetting to empty list."
                            )
                            session_data["disabled"] = []
                        if not isinstance(session_data.get("removed"), list):
                            logger.error(
                                f"Invalid type for 'removed' in session {session_id}, "
                                f"expected list, got {type(session_data.get('removed'))}. Resetting to empty list."
                            )
                            session_data["removed"] = []
                
                return data
        except Exception as e:
            logger.error(f"Failed to read {self._disabled_skills_file}: {e}")
            return {}
    
    def _save_session_data(self, data: Dict[str, Any]) -> None:
        """
        Save the session-aware skill data to JSON file with atomic write and file locking.
        
        Uses temp file + atomic rename to prevent corruption from concurrent writes.
        """
        self._disabled_skills_file.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            temp_fd, temp_path = tempfile.mkstemp(
                dir=self._disabled_skills_file.parent,
                prefix='.tmp_disabled_skills_',
                suffix='.json'
            )
            
            try:
                with os.fdopen(temp_fd, 'w', encoding='utf-8') as f:
                    portalocker.lock(f, portalocker.LOCK_EX)
                    json.dump(data, f, indent=2)
                    f.flush()
                    os.fsync(f.fileno())
                
                os.replace(temp_path, self._disabled_skills_file)
                logger.debug(f"Saved session data to {self._disabled_skills_file}")
                
            except Exception:
                if os.path.exists(temp_path):
                    os.unlink(temp_path)
                raise
                
        except Exception as e:
            logger.error(f"Failed to write {self._disabled_skills_file}: {e}")
            raise
    
    def _get_disabled_local_skills(self) -> List[str]:
        """
        Get list of disabled skill names for current session.
        """
        session_data = self._load_session_data()
        
        if self.session_id in session_data:
            disabled = session_data[self.session_id].get("disabled", [])
            logger.debug(f"Loaded {len(disabled)} disabled skills for session {self.session_id}")
            return disabled
        
        return []
    
    def _get_removed_local_skills(self) -> List[str]:
        """
        Get list of removed (hidden) skill names for current session.
        
        These are typically global skills that are marked as removed for this session only.
        """
        session_data = self._load_session_data()
        
        if self.session_id in session_data:
            removed = session_data[self.session_id].get("removed", [])
            logger.debug(f"Loaded {len(removed)} removed skills for session {self.session_id}")
            return removed
        
        return []
    
    def _set_disabled_local_skills(self, skill_names: List[str]) -> None:
        """Save list of disabled skill names for current session."""
        session_data = self._load_session_data()
        
        if self.session_id not in session_data:
            session_data[self.session_id] = {"disabled": [], "removed": []}
        
        session_data[self.session_id]["disabled"] = skill_names
        self._save_session_data(session_data)
        logger.info(f"Saved {len(skill_names)} disabled skills for session {self.session_id}")
    
    def _set_removed_local_skills(self, skill_names: List[str]) -> None:
        """Save list of removed (hidden) skill names for current session."""
        session_data = self._load_session_data()
        
        if self.session_id not in session_data:
            session_data[self.session_id] = {"disabled": [], "removed": []}
        
        session_data[self.session_id]["removed"] = skill_names
        self._save_session_data(session_data)
        logger.info(f"Saved {len(skill_names)} removed skills for session {self.session_id}")
    
    def discover_skills(self, include_disabled: bool = False, force_refresh: bool = False) -> List[SkillInfo]:
        """
        Discover all skills from configured directories with optional caching.
        
        Project-local skills (.coda/skills) take precedence over system-wide skills (~/.coda/skills)
        when names conflict.
        
        Args:
            include_disabled: If True, include disabled skills in results
            force_refresh: If True, bypass cache and force re-scan
        
        Returns:
            List of SkillInfo objects for discovered skills
        """
        # Use cache if available and directories unchanged (unless force_refresh)
        if not force_refresh and self._cached_skills is not None:
            if not self._check_directories_changed():
                logger.debug("Using cached skills (directories unchanged)")
                if include_disabled:
                    return self._cached_skills
                else:
                    return [s for s in self._cached_skills if s.enabled]
        
        # Otherwise, run full discovery
        logger.debug("Re-scanning skill directories (changes detected or forced)")
        skills_dict: Dict[str, SkillInfo] = {}
        disabled_local_skills = self._get_disabled_local_skills()
        removed_local_skills = self._get_removed_local_skills()
        
        # Clear previous format errors
        self._format_errors = []
        
        for skill_dir in self.skill_directories:
            if not skill_dir.exists():
                logger.debug(f"Skill directory does not exist: {skill_dir}")
                continue
            
            if not skill_dir.is_dir():
                logger.warning(f"Skill path is not a directory: {skill_dir}")
                continue
            
            is_project_local = (self.project_local_dir and skill_dir == self.project_local_dir)
            is_system = (self.system_dir and skill_dir == self.system_dir)
            
            source = "project" if is_project_local else ("system" if is_system else "custom")
            
            for item in skill_dir.iterdir():
                if not item.is_dir():
                    continue
                
                skill_md_path = None
                for filename in self.SKILL_FILENAMES:
                    candidate_path = item / filename
                    if candidate_path.exists():
                        skill_md_path = candidate_path
                        break
                
                if skill_md_path is None:
                    logger.debug(f"Skipping {item.name}: no skill.md or SKILL.md found")
                    continue
                
                try:
                    skill_info = self.parse_skill(skill_md_path, item)
                    skill_info.is_default = False
                    skill_info.enabled = skill_info.name not in disabled_local_skills
                    skill_info.source = source
                    
                    if skill_info.name in removed_local_skills:
                        logger.debug(f"Skipping removed skill: {skill_info.name} (hidden for session {self.session_id})")
                        continue
                    
                    if skill_info.name in skills_dict:
                        existing_skill = skills_dict[skill_info.name]
                        logger.warning(
                            f"Skill name conflict: '{skill_info.name}' found in both "
                            f"{existing_skill.path} ({existing_skill.source}) and {skill_info.path} ({source}). "
                            f"Using the one from {existing_skill.path} ({existing_skill.source})"
                        )
                        continue
                    
                    skills_dict[skill_info.name] = skill_info
                    logger.info(f"Discovered skill: {skill_info.name} at {skill_info.path} (source={source}, enabled={skill_info.enabled})")
                    
                except SkillFormatError as e:
                    # Store error for UI display
                    self._format_errors.append(e)
                    
                    # Also log it
                    logger.warning(
                        f"\n{'='*60}\n"
                        f"SKILL FORMAT ERROR\n"
                        f"{'='*60}\n"
                        f"Path: {e.skill_path}\n"
                        f"Issue: {e.issue}\n\n"
                        f"{e.help_text}\n"
                        f"{'='*60}\n"
                    )
                    continue
                except Exception as e:
                    logger.error(f"Failed to parse skill at {item}: {e}")
                    continue
        
        all_skills = list(skills_dict.values())
        
        # Cleanup stale disabled skills for current session
        # This only runs when the session has disabled skills stored in JSON
        # (disabled_local_skills is empty if session_id not in session data)
        if disabled_local_skills:
            existing_skill_names = {skill.name for skill in all_skills}
            stale_disabled = [name for name in disabled_local_skills if name not in existing_skill_names]
            if stale_disabled:
                cleaned_disabled = [name for name in disabled_local_skills if name in existing_skill_names]
                logger.info(f"Removing {len(stale_disabled)} stale disabled skill entries: {stale_disabled}")
                self._set_disabled_local_skills(cleaned_disabled)
        
        # Cache the results and update timestamps
        self._cached_skills = all_skills
        self._update_dir_timestamps()
        
        if include_disabled:
            return all_skills
        else:
            return [s for s in all_skills if s.enabled]
    
    def parse_skill(self, skill_md_path: Path, skill_dir: Path) -> SkillInfo:
        """
        Parse a skill definition file and extract metadata and content.

        The skill file may be named either ``SKILL.md`` (canonical) or
        ``skill.md`` (lowercase fallback) — see ``SKILL_FILENAMES``.

        Args:
            skill_md_path: Path to the SKILL.md (or skill.md) file
            skill_dir: Path to the skill directory

        Returns:
            SkillInfo object with parsed data

        Raises:
            ValueError: If the skill file is malformed or missing required fields
            FileNotFoundError: If the skill file doesn't exist
        """
        if not skill_md_path.exists():
            raise FileNotFoundError(f"Skill file not found: {skill_md_path}")
        
        try:
            with open(skill_md_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            raise ValueError(f"Failed to read skill file {skill_md_path}: {e}")
        
        match = FRONTMATTER_PATTERN.match(content)
        if not match:
            raise SkillFormatError(
                skill_md_path,
                f"Skill file {skill_md_path.name} is missing YAML frontmatter"
            )
        
        frontmatter_str, _ = match.groups()
        
        try:
            frontmatter = yaml.safe_load(frontmatter_str)
        except yaml.YAMLError as e:
            raise SkillFormatError(
                skill_md_path,
                f"Invalid YAML syntax in {skill_md_path.name}: {e}"
            )
        
        if not isinstance(frontmatter, dict):
            raise SkillFormatError(
                skill_md_path,
                f"YAML frontmatter must be a dictionary in {skill_md_path.name}, got {type(frontmatter).__name__}"
            )
        
        if 'name' not in frontmatter:
            raise SkillFormatError(
                skill_md_path,
                f"Skill file {skill_md_path.name} is missing required field: 'name'"
            )
        
        if 'description' not in frontmatter:
            raise SkillFormatError(
                skill_md_path,
                f"Skill file {skill_md_path.name} is missing required field: 'description'"
            )
        
        name = frontmatter['name']
        description = frontmatter['description']
        license_info = frontmatter.get('license')
        
        metadata = {k: v for k, v in frontmatter.items() 
                   if k not in ('name', 'description', 'license')}
        
        return SkillInfo(
            name=name,
            description=description,
            full_content=content,
            path=skill_dir.resolve(),
            license=license_info,
            metadata=metadata
        )
    
    def enable_skill(self, skill_name: str) -> bool:
        """
        Enable a skill by name.
        
        Args:
            skill_name: Name of the skill to enable
            
        Returns:
            True if skill was enabled, False if not found or already enabled
        """
        all_skills = self.discover_skills(include_disabled=True, force_refresh=True)
        skill = next((s for s in all_skills if s.name == skill_name), None)
        
        if not skill:
            logger.warning(f"Skill '{skill_name}' not found")
            return False
        
        if skill.enabled:
            logger.info(f"Skill '{skill_name}' is already enabled")
            return False
        
        disabled_local_skills = self._get_disabled_local_skills()
        if skill_name in disabled_local_skills:
            disabled_local_skills.remove(skill_name)
            self._set_disabled_local_skills(disabled_local_skills)
            self._cached_skills = None
            logger.info(f"Enabled skill: {skill_name}")
            return True
        
        return False
    
    def disable_skill(self, skill_name: str) -> bool:
        """
        Disable a skill by name.
        
        Args:
            skill_name: Name of the skill to disable
            
        Returns:
            True if skill was disabled, False if not found or already disabled
        """
        all_skills = self.discover_skills(include_disabled=True, force_refresh=True)
        skill = next((s for s in all_skills if s.name == skill_name), None)
        
        if not skill:
            logger.warning(f"Skill '{skill_name}' not found")
            return False
        
        if not skill.enabled:
            logger.info(f"Skill '{skill_name}' is already disabled")
            return False
        
        disabled_local_skills = self._get_disabled_local_skills()
        if skill_name not in disabled_local_skills:
            disabled_local_skills.append(skill_name)
            self._set_disabled_local_skills(disabled_local_skills)
            self._cached_skills = None
            logger.info(f"Disabled skill: {skill_name}")
            return True
        
        return False
    
    def remove_skill(self, skill_name: str) -> bool:
        """
        Remove a skill by name.
        
        For local skills (source="project"): Deletes the skill folder from disk.
        For global skills (source="system"): Adds to "removed" list for this session (hides it without deleting).
        
        Args:
            skill_name: Name of the skill to remove
            
        Returns:
            True if skill was removed, False if not found
        """
        
        all_skills = self.discover_skills(include_disabled=True, force_refresh=True)
        skill = next((s for s in all_skills if s.name == skill_name), None)
        
        if not skill:
            logger.warning(f"Skill '{skill_name}' not found")
            return False
        
        if skill.source == "project":
            if skill.path.exists():
                try:
                    shutil.rmtree(skill.path)
                    logger.info(f"Deleted local skill folder: {skill.path}")
                except Exception as e:
                    logger.error(f"Failed to delete skill folder {skill.path}: {e}")
                    raise
            
            disabled_local_skills = self._get_disabled_local_skills()
            if skill_name in disabled_local_skills:
                disabled_local_skills.remove(skill_name)
                self._set_disabled_local_skills(disabled_local_skills)
            
            removed_local_skills = self._get_removed_local_skills()
            if skill_name in removed_local_skills:
                removed_local_skills.remove(skill_name)
                self._set_removed_local_skills(removed_local_skills)
            
            self._cached_skills = None
            logger.info(f"Removed local skill: {skill_name}")
            return True
        
        else:
            removed_local_skills = self._get_removed_local_skills()
            if skill_name not in removed_local_skills:
                removed_local_skills.append(skill_name)
                self._set_removed_local_skills(removed_local_skills)
                self._cached_skills = None
                logger.info(f"Hidden global skill for session {self.session_id}: {skill_name}")
            else:
                logger.info(f"Skill '{skill_name}' is already removed/hidden")
            return True
    
    def find_skill_by_name(self, skill_name: str) -> Optional[SkillInfo]:
        """
        Find a skill by name (only enabled skills).
        
        Args:
            skill_name: Name of the skill to find
            
        Returns:
            SkillInfo if found and enabled, None otherwise
        """
        skills = self.discover_skills(include_disabled=False)
        for skill in skills:
            if skill.name == skill_name:
                return skill
        return None
    
    def check_skill_status(self, skill_name: str) -> Optional[Literal["disabled", "removed"]]:
        """
        Check if a skill is disabled or removed.
        
        Args:
            skill_name: Name of the skill to check
            
        Returns:
            'disabled' if skill is disabled, 'removed' if skill is removed, None if enabled or not found
        """
        # Load session data once instead of twice to avoid redundant file I/O
        session_data = self._load_session_data()
        session = session_data.get(self.session_id, {})
        
        if skill_name in session.get("disabled", []):
            return "disabled"
        
        if skill_name in session.get("removed", []):
            return "removed"
        
        return None
    
    def generate_skill_change_notification(self, skill_name: str, action: str) -> Optional[str]:
        """
        Generate a notification message for the agent about skill state changes.
        
        Args:
            skill_name: Name of the skill that changed
            action: One of 'enabled', 'disabled', or 'removed'
            
        Returns:
            Notification message string, or None if invalid action
        """
        if action == "enabled":
            return f"[System Context: The skill '{skill_name}' has been enabled and is now available for use.]"
        elif action == "disabled":
            return (
                f"[System Context: The skill '{skill_name}' has been disabled and is no longer available. "
                f"Do not reference or attempt to use this skill, do not re-enable the skill. "
                f"The user needs to re-enable the skill if they want to use it again.]"
            )
        elif action == "removed":
            return (
                f"[System Context: The skill '{skill_name}' has been permanently removed and is no longer available. "
                f"Do not reference or attempt to use this skill.]"
            )
        else:
            logger.warning(f"Unknown skill change action: {action}")
            return None
    
    def get_format_errors(self) -> List[SkillFormatError]:
        """
        Get list of format errors encountered during the last skill discovery.
        
        Returns:
            List of SkillFormatError exceptions from malformed skills
        """
        return self._format_errors


def discover_skills(skill_directories: Optional[List[Path]] = None) -> List[SkillInfo]:
    """
    Convenience function to discover all enabled skills.
    
    Args:
        skill_directories: Optional list of directories to scan
        
    Returns:
        List of enabled SkillInfo objects
    """
    loader = SkillLoader(skill_directories)
    return loader.discover_skills(include_disabled=False)

def get_skills_for_prompt(skill_directories: Optional[List[Path]] = None) -> List[Dict[str, str]]:
    """
    Convenience function to get enabled skills formatted for system prompt.
    
    Args:
        skill_directories: Optional list of directories to scan
        
    Returns:
        List of dicts with 'name' and 'description' keys for enabled skills only
    """
    
    skills = discover_skills(skill_directories)
    return generate_skill_list_for_prompt(skills)
