from functools import wraps
from typing import Callable, Optional
from langfuse.decorators import observe

def observe(environment: Optional[str] = None) -> Callable:
    """
    A decorator factory that conditionally applies the `langfuse_observe` decorator
    based on the specified environment and configuration.

    If the environment is `"prod"` or the `USE_LANGFUSE` environment variable is set
    to `"False"`, the original function is returned unchanged. Otherwise, the
    `langfuse_observe` decorator is applied.

    Args:
        environment (Optional[str]): The current environment. If set to `"prod"`,
                                     or if `USE_LANGFUSE` is `False`, the function
                                     remains unmodified. Default is `None`.

    Returns:
        Callable: A decorator that either applies the `langfuse_observe` decorator
                  or leaves the function unchanged.
    """
    def wrapper(func: Callable) -> Callable:
        if environment == "prod":
            @wraps(func)
            def noop(*args, **kwargs):
                return func(*args, **kwargs)
            return noop
        else:
            return observe(func)

    return wrapper