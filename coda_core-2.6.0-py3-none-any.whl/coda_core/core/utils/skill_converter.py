from pathlib import Path
from typing import Dict, Any
import yaml
from loguru import logger

from coda_core.core.utils.skill_constants import FRONTMATTER_PATTERN


class SkillConverter:
    """
    Converts external skill formats to Coda SKILL.md format.
    
    Handles:
    - Flattening nested metadata
    - Merging AGENTS.md content if present
    - Adding default execution context
    - Preserving license and attribution
    """
    
    @staticmethod
    def parse_skill_content(content: str) -> tuple[Dict[str, Any], str]:
        """
        Parse skill content string into frontmatter dict and body content.
        
        Args:
            content: SKILL.md content string with YAML frontmatter
            
        Returns:
            Tuple of (frontmatter_dict, body_content)
            
        Raises:
            ValueError: If content doesn't have valid frontmatter
        """
        match = FRONTMATTER_PATTERN.match(content)
        if not match:
            raise ValueError("Content missing valid YAML frontmatter")
        
        frontmatter_str, body = match.groups()
        frontmatter = yaml.safe_load(frontmatter_str) or {}
        
        return frontmatter, body.strip()
    
    @staticmethod
    def parse_skill_file(skill_md_path: Path) -> tuple[Dict[str, Any], str]:
        """
        Parse a SKILL.md file into frontmatter dict and body content.
        
        Args:
            skill_md_path: Path to SKILL.md file
            
        Returns:
            Tuple of (frontmatter_dict, body_content)
            
        Raises:
            ValueError: If file doesn't have valid frontmatter
        """
        content = skill_md_path.read_text(encoding='utf-8')
        
        try:
            return SkillConverter.parse_skill_content(content)
        except ValueError as e:
            raise ValueError(f"SKILL.md missing valid YAML frontmatter: {skill_md_path}") from e

    @staticmethod
    def find_skill_md_path(skill_dir: Path) -> Path:
        """
        Locate the SKILL.md file for a skill directory.

        Supports:
        - SKILL.md or skill.md in the skill root
        - SKILL.md or skill.md nested under a skills/ subfolder
        - Recursive discovery under the skill directory

        Args:
            skill_dir: Directory containing the skill

        Returns:
            Path to the SKILL.md file

        Raises:
            ValueError: If no skill file is found
        """
        candidates = [
            skill_dir / "SKILL.md",
            skill_dir / "skill.md",
            skill_dir / "skills" / "SKILL.md",
            skill_dir / "skills" / "skill.md",
        ]

        for candidate in candidates:
            if candidate.exists():
                return candidate

        recursive_candidates = [
            *skill_dir.rglob("SKILL.md"),
            *skill_dir.rglob("skill.md"),
        ]

        if recursive_candidates:
            return min(recursive_candidates, key=lambda path: (len(path.parts), str(path)))

        raise ValueError(f"SKILL.md not found in {skill_dir}")

    @staticmethod
    def flatten_metadata(frontmatter: Dict[str, Any]) -> Dict[str, Any]:
        """
        Flatten nested metadata structure to Coda's flat format.
        
        Converts:
            metadata:
              author: vercel
              version: "1.0.0"
        To:
            author: vercel
            version: "1.0.0"
        
        Args:
            frontmatter: Original frontmatter dict
            
        Returns:
            Flattened frontmatter dict
            
        Raises:
            ValueError: If metadata key conflicts with top-level frontmatter key
        """
        result = {}
        
        for key, value in frontmatter.items():
            if key == 'metadata' and isinstance(value, dict):
                for meta_key, meta_value in value.items():
                    if meta_key in result:
                        raise ValueError(
                            f"Key conflict: '{meta_key}' exists in both top-level "
                            f"frontmatter and metadata dictionary"
                        )
                    result[meta_key] = meta_value
            else:
                result[key] = value
        
        return result
    
    @staticmethod
    def add_default_execution_context(frontmatter: Dict[str, Any]) -> Dict[str, Any]:
        """
        Add default execution context if not present.
        
        Args:
            frontmatter: Frontmatter dict
            
        Returns:
            Copy of frontmatter with execution context
        """
        result = frontmatter.copy()
        
        if 'execution' not in result:
            result['execution'] = {
                'context': 'native',
                'timeout': 300
            }
        
        return result
    
    @staticmethod
    def merge_agents_md(skill_dir: Path, body: str) -> str:
        """
        Merge AGENTS.md content if present (contains compiled rules).
        
        Args:
            skill_dir: Directory containing the skill
            body: Original SKILL.md body
            
        Returns:
            Merged content (AGENTS.md takes precedence)
        """
        agents_md_path = skill_dir / "AGENTS.md"
        
        if agents_md_path.exists():
            logger.debug(f"Found AGENTS.md, using as primary content for {skill_dir.name}")
            agents_content = agents_md_path.read_text(encoding='utf-8')
            
            return f"{body}\n\n---\n\n## Detailed Guidelines\n\n{agents_content}"
        
        return body
    
    @staticmethod
    def convert_to_coda_format(
        skill_dir: Path,
        preserve_source_info: bool = True
    ) -> tuple[Dict[str, Any], str]:
        """
        Convert an external skill to Coda SKILL.md format.
        
        Args:
            skill_dir: Directory containing SKILL.md and optional AGENTS.md
            preserve_source_info: Whether to add source attribution to description
            
        Returns:
            Tuple of (coda_frontmatter, coda_body)
            
        Raises:
            ValueError: If SKILL.md not found or invalid
        """
        skill_md_path = SkillConverter.find_skill_md_path(skill_dir)
        
        frontmatter, body = SkillConverter.parse_skill_file(skill_md_path)
        
        frontmatter = SkillConverter.flatten_metadata(frontmatter)
        
        frontmatter = SkillConverter.add_default_execution_context(frontmatter)
        
        body = SkillConverter.merge_agents_md(skill_dir, body)
        
        if preserve_source_info and 'author' in frontmatter:
            original_desc = frontmatter.get('description', '')
            author = frontmatter['author']
            frontmatter['description'] = f"{original_desc} (Source: {author})"
        
        return frontmatter, body
    
    @staticmethod
    def write_coda_skill(
        output_path: Path,
        frontmatter: Dict[str, Any],
        body: str
    ) -> None:
        """
        Write a Coda-formatted SKILL.md file.
        
        Args:
            output_path: Path to output SKILL.md
            frontmatter: YAML frontmatter dict
            body: Markdown body content
            
        Raises:
            IOError: If file write fails
        """
        try:
            frontmatter_str = yaml.dump(frontmatter, default_flow_style=False, sort_keys=False)
            output_content = f"---\n{frontmatter_str}---\n\n{body}\n"
            
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(output_content, encoding='utf-8')
            
            logger.info(f"Wrote Coda SKILL.md to {output_path}")
        except Exception as e:
            logger.error(f"Failed to write SKILL.md to {output_path}: {e}")
            raise IOError(f"Failed to write skill file: {e}") from e
