
import re
import shutil
import tempfile
import json
from pathlib import Path
from typing import List, Optional
from datetime import datetime, timezone
from dataclasses import dataclass
from urllib.parse import urlparse

from loguru import logger
from git import Repo
from git.exc import GitCommandError

from coda_core.core.utils.skill_converter import SkillConverter


@dataclass
class SkillPreview:
    """Preview information for a skill before installation."""
    name: str
    description: str
    size_kb: float
    has_scripts: bool
    script_count: int
    has_warnings: bool
    warnings: List[str]
    source_path: str
    category: Optional[str] = None
    tags: List[str] = None
    featured: bool = False
    verified: bool = False
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []


class GitHubSkillInstaller:
    """
    Handles installation of skills from GitHub repositories.
    
    Workflow:
    1. Shallow clone repository to temp directory
    2. Scan for skills in /skills/ directory
    3. Preview skills with security warnings
    4. Convert to Coda format
    5. Install to .coda/skills/
    6. Cleanup temp directory
    """
    
    DANGEROUS_SCRIPT_PATTERNS = [
        (r'rm\s+(-[rf]+|-[rf]\s+-[rf])\s+[~/.]', "Recursive file deletion"),
        (r'curl[^|]*\|\s*bash', "Piping network data to bash"),
        (r'wget[^|]*\|\s*bash', "Piping network data to bash"),
        (r'eval\s*\$', "Dynamic code evaluation"),
        (r'chmod\s+777', "Unsafe file permissions"),
        (r'sudo\s+', "Requires root privileges"),
        (r'mktemp.*\&\&.*rm', "Temp file manipulation"),
    ]
    
    def __init__(self, destination_dir: Optional[Path] = None):
        """
        Initialize the GitHub skill installer.
        
        Args:
            destination_dir: Target directory for skills (defaults to .coda/skills in cwd)
        """
        if destination_dir is None:
            self.destination_dir = Path.cwd() / ".coda" / "skills"
        else:
            self.destination_dir = Path(destination_dir)
        
        logger.debug(f"GitHubSkillInstaller initialized with destination: {self.destination_dir}")
        self._temporary_dirs: dict[Path, tempfile.TemporaryDirectory] = {}

    @staticmethod
    def _normalize_repo_input(repo_input: str) -> str:
        cleaned = repo_input.strip().replace("\r", "").replace("\n", "")
        if len(cleaned) >= 2 and cleaned[0] == cleaned[-1] and cleaned[0] in {"'", '"'}:
            cleaned = cleaned[1:-1].strip()
        return cleaned

    @staticmethod
    def parse_repo_url(repo_input: str) -> str:
        """
        Parse various GitHub repo URL formats to https clone URL.
        
        Supports:
        - vercel-labs/agent-skills
        - https://github.com/vercel-labs/agent-skills
        - https://github.com/vercel-labs/agent-skills.git
        
        Args:
            repo_input: User input for repository
            
        Returns:
            Full HTTPS clone URL
        """
        normalized_repo_input = GitHubSkillInstaller._normalize_repo_input(repo_input)
        if normalized_repo_input.startswith("http"):
            parsed = urlparse(normalized_repo_input)
            if parsed.scheme not in {"http", "https"}:
                raise ValueError("Incorrect URL: expected https://github.com/<owner>/<repo>.")
            if parsed.netloc not in {"github.com", "www.github.com"}:
                raise ValueError("Incorrect URL: only github.com repositories are supported.")

            path = parsed.path.strip("/")
            segments = [segment for segment in path.split("/") if segment]
            if len(segments) < 2:
                raise ValueError("Incorrect URL: expected https://github.com/<owner>/<repo>.")
            if len(segments) > 2:
                raise ValueError("Incorrect URL: do not include branch or path segments.")

            owner, repo = segments[0], segments[1].removesuffix(".git")
            if not owner or not repo:
                raise ValueError("Incorrect URL: expected https://github.com/<owner>/<repo>.")

            return f"https://github.com/{owner}/{repo}"
        
        if "/" in normalized_repo_input and not normalized_repo_input.startswith("git@"):
            parts = [segment for segment in normalized_repo_input.split("/") if segment]
            if len(parts) != 2:
                raise ValueError("Incorrect repository format: use <owner>/<repo>.")
            return f"https://github.com/{parts[0]}/{parts[1]}"
        
        raise ValueError(f"Invalid repository format: {normalized_repo_input}")

    def resolve_repo_source(self, repo_input: str) -> Path:
        """
        Resolve repository input to a local path or a cloned Git repository.

        Args:
            repo_input: Repository URL, shorthand, or local path.

        Returns:
            Path to repository root.

        Raises:
            ValueError: If repository input is invalid or not found.
        """
        normalized_repo_input = self._normalize_repo_input(repo_input)
        local_path = Path(normalized_repo_input).expanduser()
        if local_path.exists():
            if not local_path.is_dir():
                raise ValueError(f"Local path is not a directory: {local_path}")
            return local_path

        repo_url = self.parse_repo_url(normalized_repo_input)
        temp_dir = tempfile.TemporaryDirectory()
        repo_dir = Path(temp_dir.name) / "repo"
        try:
            self.clone_repository(repo_url, repo_dir)
        except Exception:
            temp_dir.cleanup()
            raise
        self._temporary_dirs[repo_dir] = temp_dir
        return repo_dir

    def cleanup_repo_source(self, repo_dir: Path) -> None:
        """Cleanup any temporary directories created by resolve_repo_source."""
        temp_dir = self._temporary_dirs.pop(repo_dir, None)
        if temp_dir is not None:
            temp_dir.cleanup()

    def clone_repository(self, repo_url: str, target_dir: Path) -> None:
        """
        Shallow clone a repository to target directory.
        
        Args:
            repo_url: HTTPS URL to repository
            target_dir: Directory to clone into
            
        Raises:
            GitCommandError: If clone fails
        """
        logger.info(f"Cloning {repo_url} to {target_dir}")
        
        try:
            Repo.clone_from(
                repo_url,
                str(target_dir),
                depth=1,
                single_branch=True
            )
            logger.debug(f"Successfully cloned {repo_url}")
        except GitCommandError as e:
            logger.error(f"Failed to clone repository: {e}")
            raise
    
    def load_skills_metadata(self, repo_dir: Path) -> Optional[dict]:
        """
        Load skills.json metadata file from repository if available.
        
        Args:
            repo_dir: Root directory of cloned repository
            
        Returns:
            Dictionary with skills metadata or None if not found
        """
        metadata_file = repo_dir / "skills.json"
        
        if not metadata_file.exists():
            logger.debug("No skills.json metadata file found")
            return None
        
        try:
            with open(metadata_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                logger.info(f"Loaded metadata for {data.get('total', 0)} skills")
                return data
        except Exception as e:
            logger.warning(f"Failed to parse skills.json: {e}")
            return None
    
    def get_skill_categories(self, metadata: Optional[dict]) -> List[str]:
        """
        Extract unique categories from skills metadata.
        
        Args:
            metadata: Skills metadata dictionary
            
        Returns:
            Sorted list of unique categories
        """
        if not metadata or 'skills' not in metadata:
            return []
        
        categories = set()
        for skill in metadata['skills']:
            if 'category' in skill:
                categories.add(skill['category'])
        
        return sorted(categories)
    
    def discover_skills_in_repo(self, repo_dir: Path, category_filter: Optional[str] = None, metadata: Optional[dict] = None) -> List[Path]:
        """
        Discover skills in repository's /skills/ directory.
        
        Args:
            repo_dir: Root directory of cloned repository
            category_filter: Optional category to filter by
            metadata: Optional pre-loaded metadata dictionary
            
        Returns:
            List of paths to skill directories
        """
        skills_dir = repo_dir / "skills"
        
        if not skills_dir.exists():
            root_skill_md = repo_dir / "SKILL.md"
            root_skill_md_lower = repo_dir / "skill.md"
            if root_skill_md.exists() or root_skill_md_lower.exists():
                return [repo_dir]

            skill_md_paths = list(repo_dir.glob("*/SKILL.md")) + list(repo_dir.glob("*/skill.md"))
            skill_dirs = []
            seen_dirs = set()
            for skill_md_path in skill_md_paths:
                skill_dir = skill_md_path.parent
                if not skill_dir.is_dir() or skill_dir in seen_dirs:
                    continue
                seen_dirs.add(skill_dir)
                skill_dirs.append(skill_dir)
            if skill_dirs:
                return skill_dirs

            logger.warning(f"No /skills/ directory or root SKILL.md found in {repo_dir}")
            return []

        allowed_skills = None
        if category_filter and metadata and 'skills' in metadata:
            allowed_skills = set()
            for skill in metadata['skills']:
                if skill.get('category') == category_filter:
                    allowed_skills.add(skill['name'])
            logger.debug(f"Category filter '{category_filter}' matched {len(allowed_skills)} skills")
        
        discovered = []
        discovered_dirs = set()

        for skill_md_path in skills_dir.rglob("SKILL.md"):
            skill_dir = skill_md_path.parent

            if skill_dir in discovered_dirs:
                continue

            if not self._validate_skill_name(skill_dir.name):
                logger.warning(
                    f"Skipping invalid skill directory name: {skill_dir.name}. "
                    f"Only alphanumeric, dash, and underscore allowed."
                )
                continue

            if allowed_skills is not None:
                try:
                    frontmatter, _ = SkillConverter.parse_skill_file(skill_md_path)
                    skill_name = frontmatter.get('name', skill_dir.name)
                    if skill_name not in allowed_skills:
                        continue
                except Exception:
                    if skill_dir.name not in allowed_skills:
                        continue

            discovered.append(skill_dir)
            discovered_dirs.add(skill_dir)
            logger.debug(f"Found skill: {skill_dir.name}")

        for skill_md_path in skills_dir.rglob("skill.md"):
            skill_dir = skill_md_path.parent

            if skill_dir in discovered_dirs:
                continue

            if not self._validate_skill_name(skill_dir.name):
                logger.warning(
                    f"Skipping invalid skill directory name: {skill_dir.name}. "
                    f"Only alphanumeric, dash, and underscore allowed."
                )
                continue
            
            if allowed_skills is not None:
                try:
                    frontmatter, _ = SkillConverter.parse_skill_file(skill_md_path)
                    skill_name = frontmatter.get('name', skill_dir.name)
                    if skill_name not in allowed_skills:
                        continue
                except Exception:
                    if skill_dir.name not in allowed_skills:
                        continue

            discovered.append(skill_dir)
            discovered_dirs.add(skill_dir)
            logger.debug(f"Found skill: {skill_dir.name}")
        
        logger.info(f"Discovered {len(discovered)} skills in repository")
        return discovered
    
    def scan_scripts_for_dangers(self, skill_dir: Path) -> List[str]:
        """
        Scan skill scripts for potentially dangerous patterns.
        
        Args:
            skill_dir: Path to skill directory
            
        Returns:
            List of warning messages
        """
        warnings = []
        scripts_dir = skill_dir / "scripts"
        
        if not scripts_dir.exists():
            return warnings
        
        for script_file in scripts_dir.rglob("*"):
            if not script_file.is_file():
                continue
            
            try:
                content = script_file.read_text(encoding='utf-8', errors='ignore')
                
                for pattern, description in self.DANGEROUS_SCRIPT_PATTERNS:
                    if re.search(pattern, content, re.IGNORECASE):
                        warnings.append(f"{script_file.name}: {description}")
                        logger.warning(f"Dangerous pattern in {script_file}: {description}")
            except Exception as e:
                logger.debug(f"Could not scan {script_file}: {e}")
        
        return warnings
    
    def calculate_skill_size(self, skill_dir: Path) -> float:
        """
        Calculate total size of skill directory in KB.
        
        Args:
            skill_dir: Path to skill directory
            
        Returns:
            Size in kilobytes
        """
        total_size = 0
        
        for file_path in skill_dir.rglob("*"):
            if file_path.is_file():
                total_size += file_path.stat().st_size
        
        return total_size / 1024
    
    def preview_skill(self, skill_dir: Path) -> SkillPreview:
        """
        Generate preview information for a skill.
        
        Args:
            skill_dir: Path to skill directory
            
        Returns:
            SkillPreview object with metadata
        """
        try:
            skill_md_path = SkillConverter.find_skill_md_path(skill_dir)
            frontmatter, _ = SkillConverter.parse_skill_file(skill_md_path)
        except Exception as e:
            logger.error(f"Failed to parse SKILL.md in {skill_dir}: {e}")
            frontmatter = {}
        
        name = frontmatter.get('name', skill_dir.name)
        description = frontmatter.get('description', 'No description available')
        
        scripts_dir = skill_dir / "scripts"
        has_scripts = scripts_dir.exists() and any(scripts_dir.iterdir())
        script_count = len(list(scripts_dir.rglob("*"))) if has_scripts else 0
        
        warnings = self.scan_scripts_for_dangers(skill_dir)
        
        size_kb = self.calculate_skill_size(skill_dir)
        
        return SkillPreview(
            name=name,
            description=description,
            size_kb=size_kb,
            has_scripts=has_scripts,
            script_count=script_count,
            has_warnings=len(warnings) > 0,
            warnings=warnings,
            source_path=str(skill_dir)
        )
    
    def copy_skill_files(self, source_dir: Path, dest_dir: Path) -> None:
        """
        Copy all skill files to destination.
        
        Args:
            source_dir: Source skill directory
            dest_dir: Destination directory
        """
        resolved_source_dir = source_dir.resolve()
        resolved_dest_dir = dest_dir.resolve()
        if resolved_source_dir == resolved_dest_dir:
            logger.debug("Source and destination are the same; skipping copy.")
            return
        if resolved_dest_dir.is_relative_to(resolved_source_dir):
            raise ValueError(
                f"Destination directory '{resolved_dest_dir}' is inside source directory '{resolved_source_dir}'"
            )

        dest_dir.mkdir(parents=True, exist_ok=True)
        
        for item in source_dir.iterdir():
            if item.name.startswith('.'):
                continue
            
            dest_path = dest_dir / item.name
            
            if item.is_file():
                shutil.copy2(item, dest_path)
                logger.debug(f"Copied {item.name} to {dest_dir}")
            elif item.is_dir():
                shutil.copytree(item, dest_path, dirs_exist_ok=True)
                logger.debug(f"Copied {item.name}/ to {dest_dir}")
    
    def create_metadata_file(
        self,
        skill_dir: Path,
        repo_url: str,
        source_path: str,
        version: Optional[str] = None,
        commit_sha: Optional[str] = None
    ) -> None:
        """
        Create .metadata.json file to track skill source.
        
        Args:
            skill_dir: Installed skill directory
            repo_url: Source repository URL
            source_path: Path within repository
            version: Skill version
            commit_sha: Git commit SHA
        """
        metadata = {
            "source_repo": repo_url,
            "source_path": source_path,
            "installed_at": datetime.now(timezone.utc).isoformat(),
            "version": version or "unknown",
            "commit_sha": commit_sha or "unknown",
            "installer": "github_skill_installer"
        }
        
        metadata_path = skill_dir / ".metadata.json"
        metadata_path.write_text(json.dumps(metadata, indent=2), encoding='utf-8')
        
        logger.debug(f"Created metadata file: {metadata_path}")
    
    def install_skill(
        self,
        skill_dir: Path,
        repo_url: str,
        commit_sha: Optional[str] = None,
        source_path: Optional[str] = None
    ) -> Path:
        """
        Install a single skill to destination directory.
        
        Args:
            skill_dir: Source skill directory
            repo_url: Source repository URL
            commit_sha: Git commit SHA
            source_path: Optional source path within the repository
            
        Returns:
            Path to installed skill directory
            
        Raises:
            ValueError: If skill conversion fails
        """
        frontmatter, body = SkillConverter.convert_to_coda_format(skill_dir)
        
        skill_name = frontmatter.get('name', skill_dir.name)
        dest_skill_dir = self.destination_dir / skill_name
        
        self.copy_skill_files(skill_dir, dest_skill_dir)
        
        SkillConverter.write_coda_skill(
            dest_skill_dir / "SKILL.md",
            frontmatter,
            body
        )
        
        self.create_metadata_file(
            dest_skill_dir,
            repo_url=repo_url,
            source_path=source_path or f"skills/{skill_dir.name}",
            version=frontmatter.get('version'),
            commit_sha=commit_sha
        )
        
        logger.info(f"Installed skill '{skill_name}' to {dest_skill_dir}")
        return dest_skill_dir

    @staticmethod
    def _validate_skill_name(skill_name: str) -> bool:
        """
        Validate skill name to prevent path traversal attacks.
        
        Args:
            skill_name: Skill name to validate
            
        Returns:
            True if valid, False otherwise
        """
        return bool(re.match(r'^[a-zA-Z0-9_-]+$', skill_name))
    
    def install_from_github(
        self,
        repo_input: str,
        skill_names: Optional[List[str]] = None
    ) -> List[Path]:
        """
        Install skills from a GitHub repository.
        
        Args:
            repo_input: Repository URL or shorthand (e.g., "vercel-labs/agent-skills")
            skill_names: Optional list of specific skill names to install (None = all)
            
        Returns:
            List of paths to installed skill directories
            
        Raises:
            ValueError: If repository is invalid or no skills found
        """
        if skill_names:
            for skill_name in skill_names:
                if not self._validate_skill_name(skill_name):
                    raise ValueError(f"Invalid skill name: {skill_name}. Only alphanumeric, dash, and underscore allowed.")
        
        normalized_repo_input = self._normalize_repo_input(repo_input)
        repo_url = self.parse_repo_url(normalized_repo_input)

        with tempfile.TemporaryDirectory() as tmpdir:
            repo_dir = Path(tmpdir) / "repo"
            
            self.clone_repository(repo_url, repo_dir)
            
            discovered_skills = self.discover_skills_in_repo(repo_dir)
            
            if not discovered_skills:
                raise ValueError(f"No skills found in repository: {repo_url}")
            
            if skill_names:
                discovered_skills = [
                    s for s in discovered_skills 
                    if s.name in skill_names
                ]
                
                if not discovered_skills:
                    raise ValueError(f"Specified skills not found: {skill_names}")
            
            try:
                with Repo(repo_dir) as repo:
                    commit_sha = repo.head.commit.hexsha
            except Exception:
                commit_sha = None
            
            installed = []
            for skill_dir in discovered_skills:
                try:
                    # Compute source_path relative to the repo root so it matches
                    # the actual location of the skill within the repository.
                    try:
                        relative_source_path = skill_dir.relative_to(repo_dir)
                    except ValueError:
                        # Fallback: if skill_dir is unexpectedly outside repo_dir,
                        # preserve the previous behavior based on directory name.
                        relative_source_path = Path("skills") / skill_dir.name

                    # Use "." for repo-root skills to clearly indicate root.
                    if str(relative_source_path) in ("", "."):
                        source_path_str = "."
                    else:
                        source_path_str = str(relative_source_path)

                    installed_path = self.install_skill(
                        skill_dir,
                        repo_url,
                        commit_sha,
                        source_path=source_path_str
                    )
                    installed.append(installed_path)
                except Exception as e:
                    logger.error(f"Failed to install {skill_dir.name}: {e}")
            
            return installed
