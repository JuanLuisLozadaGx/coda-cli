from abc import ABC, abstractmethod
from typing import Optional, Dict, List, Any
from loguru import logger


class Mode(ABC):
    """
    Abstract base class for all modes.
    
    This class defines the interface that all modes must implement.
    Each mode represents a different operational mode for the CODA CLI
    that can customize the agent's behavior, tools, and system prompt.
    """
    
    @property
    @abstractmethod
    def key(self) -> str:
        """
        Unique identifier for the mode.
        
        Returns:
            str: A unique key for this mode
        """
        pass
    
    @property
    @abstractmethod
    def name(self) -> str:
        """
        Human-readable name for the mode.
        
        Returns:
            str: Display name for this mode
        """
        pass
    
    @property
    def system_prompt(self) -> str:
        """
        Template name for system prompt.
        
        Returns:
            str: Name of the template file to use for system prompt
        """
        return "single_agent_system_prompt.hbs"  

    @property
    @abstractmethod
    def description(self) -> str:
        """
        Description of what this mode does.
        
        Returns:
            str: Description of the mode's purpose and behavior
        """
        pass

    @property
    def get_prompt_additions(self) -> Optional[Dict[str, Any]]:
        """
        Get additional content to include in the system prompt when this mode is active.
        
        Returns:
            Optional dict with 'content' key for additional rules text, or None
        """
        return None
    
    @property
    def get_enabled_tools(self) -> List[str]:
        """
        Get list of tool names to enable when this mode is active.
        
        Returns:
            List of tool names to be enabled
        """
        return []
    
    @property
    def get_tool_dependencies(self) -> Dict[str, Dict[str, Any]]:
        """
        Get tool dependencies to register when this mode is active.
        
        Returns:
            Dict mapping tool names to dictionaries of dependencies
            Format: {'tool_name': {'dep_name': dependency_object}}
        """
        return {}
    
    @abstractmethod
    def on_activate(self) -> bool:
        """
        Called when this mode is activated.
        
        Override this method to perform initialization when the mode is selected.
        The implementation should:
        1. Register any necessary tools
        2. Set up tool dependencies
        3. Enable required tools
        4. Configure or create the agent if needed            
        Returns:
            bool: True if activation was successful, False otherwise
        """
        pass
    
    @abstractmethod
    def on_deactivate(self) -> None:
        """
        Called when this mode is deactivated.
        
        Override this method to perform cleanup when the mode is unselected.
        """
        pass
        
    def sync_usage_from_main(self, main_shared_state):
        """
        Synchronize usage statistics from main agent to mode's shared state.
        
        Args:
            main_shared_state: The main agent's shared state with usage statistics
        """
        if not hasattr(self, 'shared_state'):
            return
            
        # Use the shared_state's sync_usage_from method to copy statistics
        # This ensures we're starting from the cumulative total (X) when we activate the mode
        self.shared_state.sync_usage_from(main_shared_state)
        
        logger.info(f"Synchronized usage from main agent to {self.name}: ${self.shared_state.total_cost:.6f}")
    
    def sync_usage_to_main(self, main_shared_state):
        """
        Synchronize usage statistics from mode's shared state back to main agent.
        
        Args:
            main_shared_state: The main agent's shared state to update
        
        Returns:
            dict: The usage delta that was transferred
        """
        if not hasattr(self, 'shared_state'):
            return {"total_cost": 0, "total_tokens": 0, "completion_tokens": 0, "prompt_tokens": 0}
        
        # Use the main_shared_state's sync_usage_from method to copy statistics from mode's shared_state
        # Important: This REPLACES the values, not adds them, to avoid double-counting
        delta = main_shared_state.sync_usage_from(self.shared_state)
        
        logger.info(f"Synchronized usage from {self.name} to main agent: +${delta['total_cost']:.6f}")
        return delta
        
    def clear_memory(self):
        """
        Clear the mode agent's memory while preserving the system message.
        
        This helps start each mode activation with a fresh conversation history,
        while maintaining the necessary system prompt/instructions.
        
        Returns:
            bool: True if memory was cleared, False if no agent or memory exists
        """
        # Check if the mode has an agent with memory
        if not hasattr(self, 'agent') or not hasattr(self.agent, 'memory'):
            return False
            
        # Extract system message if it exists
        system_msg = None
        for msg in self.agent.memory.messages:
            if msg.get('role') == 'system':
                system_msg = msg.get('content', '')
                break
                
        # Clear all messages
        self.agent.memory.clear()
        
        # Re-add system message if it exists
        if system_msg:
            self.agent.memory.upsert_system_message(system_msg)
            
        logger.info(f"Cleared {self.name} mode memory while preserving system prompt")
        return True
