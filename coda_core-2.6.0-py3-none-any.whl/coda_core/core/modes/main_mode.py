from loguru import logger
from typing import List

from coda_core.core.modes.base import Mode


class MainMode(Mode):
    """
    A simple mode to return to the main Coda agent.
    
    This mode serves as a way to exit any other mode (like Planning Mode)
    and return to the main Coda agent. It's equivalent to using Ctrl+C
    to exit a mode, but provides a more explicit command-based approach.
    """
    
    def __init__(self):
        """Initialize main mode with basic attributes."""
        self._key = "main_mode"
        self._name = "Main Mode"
        self._description = "Return to the main Coda agent."
        
        # These attributes will be set during activation
        self.agent = None
        self.shared_state = None
        self._enabled_tools = []
        
    @property
    def key(self) -> str:
        """
        Unique key for the main mode.
        
        Returns:
            str: Unique key string
        """
        return self._key
    
    @property
    def name(self) -> str:
        """
        Human-readable name for the main mode.
        
        Returns:
            str: Name of the mode
        """
        return self._name
    
    @property
    def description(self) -> str:
        """
        Description of the main mode.
        
        Returns:
            str: Description of the mode
        """
        return self._description
    
    @property
    def get_enabled_tools(self) -> List[str]:
        """
        Get list of tool names to enable when this mode is active.
        
        The main mode uses the default tools from the main agent,
        so we don't need to specify any additional tools here.
        
        Returns:
            List of tool names to be enabled
        """
        return []
        
    def on_activate(self) -> bool:
        """
        Activate the main mode - this essentially just returns to the main agent.
        
        This method is called when the mode is activated. Since the main mode
        is just a way to return to the main agent, it doesn't need to do much.
        
        Returns:
            bool: Always returns False to indicate that we should exit back to
                 the main agent rather than stay in this mode
        """
        logger.info("Main mode activated - returning to main agent")
        
        # Always return False to indicate we should exit back to main agent
        return False
        
    def on_deactivate(self) -> None:
        """
        Deactivate the main mode.
        
        This method is called when the mode is deactivated.
        Since the main mode doesn't have any state to clean up,
        this method doesn't need to do anything.
        """
        logger.info("Main mode deactivated")
        return