# Planning Mode Utilities

This module provides utilities for managing the planning mode, including state transitions between planning and execution modes, and memory optimization during plan execution. The `register_user_message_callback` method in `PlanningModeStateMachine` directly patches the agent's `get_response` method. This approach was chosen for several important reasons:

1. **Guaranteed Interception**: Standard callback mechanisms might not always be triggered reliably in all execution paths. By patching the `get_response` method, we guarantee that every user message is intercepted.

2. **Precise Timing**: Memory cleaning must occur at exactly the right moment - after a step is marked complete and when the next user message arrives. Patching ensures this precise timing.

3. **Early Interception**: By intercepting at the `get_response` level, we can clean memory before any LLM processing begins, maximizing token efficiency.

## Advanced Tool Usage Tracking

The `PlanMemoryManager` employs a callback-based approach to track tool usage:

1. **Direct Tracking**: It attempts to track tool calls and results directly via callbacks.

2. **Memory Extraction**: If callback tracking is incomplete, it can extract tool usage directly from the agent's memory.

3. **Format Normalization**: Tool results are normalized and formatted consistently regardless of their original structure.

### PlanningModeStateMachine

The State Machine manages transitions between planning and execution modes:

- **PLANNING_MODE**: When creating or updating plans
- **EXECUTION_MODE**: When executing an approved plan
- Controls which tools are active in each mode
- Handles callbacks for state transitions
- Coordinates with PlanMemoryManager for memory optimization

### PlanMemoryManager

The Memory Manager tracks and optimizes tool usage during plan execution:

- Captures which tools are called and with what arguments
- Records tool results
- Performs memory cleaning after steps are completed
- Creates reduced context for efficient agent operation
- Helps maintain agent performance by preventing context bloat

### Optimization Process

When a step is marked complete:
1. The state machine flags that memory cleaning is needed
2. When the user sends their next message, cleaning is triggered
3. The memory manager extracts essential information about tool usage
4. A reduced context is created containing just what's needed for the next step
5. The agent's memory is cleaned and the reduced context is injected
6. This process prevents memory bloat while maintaining necessary context

## Component Overview and Interaction

```mermaid
graph TB
    %% Define the main components
    StateMachine["PlanningModeStateMachine<br/>(State Management)"]
    MemManager["PlanMemoryManager<br/>(Memory & Tool Tracking)"]
    Agent["Agent<br/>(LLM Interaction)"]
    UserInterface["UI Handler<br/>(User Interaction)"]
    
    %% Define the states
    subgraph States
        Planning["PLANNING_MODE<br/>(Plan Creation)"]
        Execution["EXECUTION_MODE<br/>(Plan Execution)"]
    end
    
    %% Show state machine controlling states
    StateMachine -->|manages| States
    
    %% Show the key interactions between components
    StateMachine -->|registers callbacks with| Agent
    StateMachine -->|uses| MemManager
    MemManager -->|cleans & optimizes| Agent
    Agent -->|displays plans through| UserInterface
    
    %% Show the memory management process
    MemManager -->|tracks| ToolUsage["Tool Usage Tracking"]
    MemManager -->|performs| MemCleaning["Memory Cleaning"]
    MemManager -->|creates| ReducedContext["Reduced Context"]
    
    %% Define the tools and their relationship to states
    subgraph PlanningTools
        CreatePlanTool["create_plan_tool"]
        ApprovePlanTool["approve_plan_tool"]
        UpdatePlanTool["update_plan_tool"]
        LoadPlanTool["load_plan_tool"]
    end
    
    subgraph ExecutionTools
        MarkStepTool["mark_step_tool"]
        MarkPendingTool["mark_plan_as_pending_tool"]
        BashTool["bash"]
        ViewTool["view"]
        EditTool["edit"]
    end
    
    %% Connect tools to states
    Planning -->|enables| PlanningTools
    Execution -->|enables| ExecutionTools
    
    %% Show the state transitions
    ApprovePlanTool -->|triggers| TransitionToExec["Transition to<br/>EXECUTION_MODE"]
    LoadPlanTool -->|triggers| TransitionToExec
    MarkPendingTool -->|triggers| TransitionToPlan["Transition to<br/>PLANNING_MODE"]
    
    %% Connect transitions to state machine
    TransitionToExec -->|calls| StateMachine
    TransitionToPlan -->|calls| StateMachine
    
    %% Show how mark_step triggers memory cleaning
    MarkStepTool -->|triggers| FlagCleaning["Flag Memory<br/>for Cleaning"]
    FlagCleaning -->|when user messages| MemCleaning
```

## State Transition Flow

```mermaid
sequenceDiagram
    participant User
    participant Agent
    participant StateMachine as PlanningModeStateMachine
    participant MemManager as PlanMemoryManager
    participant Tools
    
    Note over StateMachine: Starts in PLANNING_MODE
    
    %% Plan Creation Phase
    User->>Agent: Request to create a plan
    Agent->>Tools: Use create_plan_tool
    Tools-->>Agent: Plan created
    Agent-->>User: Plan details
    
    %% Plan Approval/Loading
    User->>Agent: Approve plan or load plan
    Agent->>Tools: Use approve_plan_tool/load_plan_tool
    Tools->>StateMachine: handle_mode_transition_from_create_to_exec()
    StateMachine->>StateMachine: set_state(EXECUTION_MODE)
    StateMachine->>StateMachine: handle_execution_tools_activation()
    StateMachine->>MemManager: set_plan_id(plan_id)
    StateMachine->>MemManager: register_callbacks(agent)
    StateMachine->>Agent: Register mark_step_callback
    StateMachine-->>User: Mode switched to execution
    
    %% Plan Execution and Memory Management
    User->>Agent: Execute step 1
    Agent->>Tools: Use execution tools (bash, view, etc.)
    Tools-->>Agent: Tool results
    MemManager->>MemManager: Track tool usage
    
    %% Mark Step Completion
    Agent->>Tools: Use mark_step_tool
    Tools->>StateMachine: handle_mark_step_callback()
    StateMachine->>StateMachine: _needs_memory_cleaning = True
    
    %% Memory Cleaning
    User->>Agent: Next message after step completion
    Agent->>StateMachine: Intercepts via patched get_response
    StateMachine->>MemManager: memory_cleaning_after_mark_step()
    MemManager->>MemManager: extract_tool_calls_from_memory()
    MemManager->>MemManager: format_captured_tool_usage()
    MemManager->>MemManager: get_reduced_context_for_next_step()
    MemManager->>Agent: Update memory with reduced context
    Agent-->>User: Continue with optimized context
    
    %% Return to Planning Mode
    User->>Agent: Request to modify plan
    Agent->>Tools: Use mark_plan_as_pending_tool
    Tools->>StateMachine: handle_transition_from_exec_to_create()
    StateMachine->>StateMachine: set_state(PLANNING_MODE)
    StateMachine->>StateMachine: handle_planning_tools_activation()
    StateMachine->>MemManager: Deactivate and clear callbacks
    StateMachine-->>User: Mode switched to planning
```


