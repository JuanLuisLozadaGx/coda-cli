from enum import Enum
from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, field_validator


class StepStatus(str, Enum):
    """Status of a plan step."""
    PENDING = "⏳ Pending"
    COMPLETED = "✅ Completed"
    IN_PROGRESS = "🔄 In Progress"
    FAILED = "❌ Failed"


class PlanStatus(str, Enum):
    """Status of the entire plan."""
    PENDING = "⏳ Pending"
    APPROVED = "✅ Approved"
    COMPLETED = "✅ Completed"
    FAILED = "❌ Failed"
    
    @classmethod
    def from_string(cls, status: str):
        """Map a string status to its enum equivalent."""
        status_map = {
            "pending": cls.PENDING,
            "approved": cls.APPROVED,
            "completed": cls.COMPLETED,
            "failed": cls.FAILED
        }
        return status_map.get(status.lower(), cls.PENDING)


class ExecutionPreference(str, Enum):
    """Execution preference for a plan."""
    STEP_BY_STEP = "step_by_step"
    ALL_AT_ONCE = "all_at_once"


class SubTask(BaseModel):
    """A subtask within a step."""
    description: str
    
    def dict_with_enum_values(self) -> Dict[str, Any]:
        """Return a dict with enum values as strings."""
        return {
            "description": self.description
        }


class PlanStep(BaseModel):
    """A step in a plan."""
    number: int
    title: str
    status: StepStatus = Field(default=StepStatus.PENDING)
    subtasks: List[SubTask] = Field(default_factory=list)
    step_execution_summary: Optional[str] = None
    current_subtask_index: Optional[int] = None  # Points to the current/next pending subtask
    
    def dict_with_enum_values(self) -> Dict[str, Any]:
        """Return a dict with enum values as strings."""
        return {
            "number": self.number,
            "title": self.title,
            "status": self.status.value,
            "subtasks": [subtask.dict_with_enum_values() for subtask in self.subtasks],
            "step_execution_summary": self.step_execution_summary
        }
            
    
    @field_validator('subtasks', mode='before')
    @classmethod
    def ensure_subtasks_list(cls, v):
        """Ensure subtasks is a list."""
        if v is None:
            return []
        return v
                
class Plan(BaseModel):
    """A complete plan with metadata and steps."""
    plan_id: str
    summary: str
    status: PlanStatus = Field(default=PlanStatus.PENDING)
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
    steps: List[PlanStep] = Field(default_factory=list)
    current_step: Optional[int] = None
    execution_preference: ExecutionPreference = Field(default=ExecutionPreference.STEP_BY_STEP)
    
    def dict_with_enum_values(self) -> Dict[str, Any]:
        """Return a dict with enum values as strings and datetime as ISO format."""
        return {
            "plan_id": self.plan_id,
            "summary": self.summary,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "steps": [step.dict_with_enum_values() for step in self.steps],
            "current_step": self.current_step,
            "execution_preference": self.execution_preference.value
        }
    
    def add_step(self, title: str, subtasks: List[str] = None) -> PlanStep:
        """
        Add a new step to the plan with automatic numbering and optional inner_step_dependencies.
        
        Args:
            title: The title of the step
            subtasks: List of subtask descriptions (optional)
                
        Returns:
            PlanStep: The newly created step
            
        Raises:
            ValueError: If any dependency references an invalid step number
        """
        if subtasks is None:
            subtasks = []
            
        # Get the next step number
        next_number = len(self.steps) + 1
        
        # Create subtask objects
        subtask_objects = [SubTask(description=desc) for desc in subtasks]
        
        # Create the new step
        new_step = PlanStep(
            number=next_number,
            title=title,
            subtasks=subtask_objects
        )
                
        # Add the step to the plan
        self.steps.append(new_step)
        self.updated_at = datetime.now()
        
        return new_step
    
    def remove_step(self, step_number: int) -> bool:
        """
        Remove a step from the plan and renumber remaining steps.
        Also removes the step from all other steps' inner_step_dependencies
        and updates dependency references when steps are renumbered.
        
        Args:
            step_number: The number of the step to remove (1-based indexing)
            
        Returns:
            bool: True if successful, False if step not found
        """
        # Find the step to remove
        step_index = None
        for i, step in enumerate(self.steps):
            if step.number == step_number:
                step_index = i
                break
                
        if step_index is None:
            return False
            
        # Remove the step
        self.steps.pop(step_index)
        
        # Create a mapping of old to new step numbers
        old_to_new = {}
        for i, step in enumerate(self.steps):
            old_number = step.number
            new_number = i + 1
            old_to_new[old_number] = new_number
        
        self.updated_at = datetime.now()
        return True
    
    def mark_step_status(self, step_number: int, status: StepStatus, 
                         step_execution_summary: Optional[str] = None) -> bool:
        """
        Mark a step with a specific status.
        
        Args:
            step_number: The number of the step to mark (1-based indexing)
            status: The new status
            step_execution_summary: Optional response text from the agent
            
        Returns:
            bool: True if successful, False if step not found
        """
        for step in self.steps:
            if step.number == step_number:
                step.status = status
                if step_execution_summary:
                    step.step_execution_summary = step_execution_summary
                self.updated_at = datetime.now()
                
                # Update current_step counter for UI display when marking as completed
                if status == StepStatus.COMPLETED:
                    # Count all completed steps
                    completed_steps = sum(1 for s in self.steps if s.status == StepStatus.COMPLETED)
                    self.current_step = completed_steps
                
                return True
                
        return False
    
    def update_plan_status(self, status: PlanStatus) -> None:
        """Update the plan status."""
        self.status = status
        self.updated_at = datetime.now()
                        
    @field_validator('steps', mode='before')
    @classmethod
    def ensure_steps_list(cls, v):
        """Ensure steps is a list."""
        if v is None:
            return []
        return v