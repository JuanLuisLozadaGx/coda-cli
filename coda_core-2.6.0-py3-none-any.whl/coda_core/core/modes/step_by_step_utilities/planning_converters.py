import re
import json
import os
from loguru import logger
from typing import Tuple, Dict, Any, Optional, List
from datetime import datetime
from coda_core.core.modes.step_by_step_utilities.schemas import Plan, StepStatus, PlanStatus, ExecutionPreference


def json_to_markdown(plan: Plan) -> str:
    """
    Convert a Plan object to a markdown string representation.
    
    Args:
        plan: The Plan object to convert
        
    Returns:
        str: Markdown representation of the plan
    """
    # Format dates as readable strings
    created_at = plan.created_at.strftime("%Y-%m-%d %H:%M:%S")
    updated_at = plan.updated_at.strftime("%Y-%m-%d %H:%M:%S")
    
    # Start with the header and metadata
    markdown = f"# Plan: {plan.plan_id}\n\n"
    markdown += f"## Summary\n{plan.summary}\n\n"
    markdown += f"**Status:** {plan.status.value}\n\n"
    markdown += f"**Execution Mode:** {'Step by Step' if plan.execution_preference == ExecutionPreference.STEP_BY_STEP else 'All at Once'}\n\n"
    markdown += f"**Created:** {created_at}\n\n"
    markdown += f"**Last Updated:** {updated_at}\n\n"
    
    # Add the steps section if there are steps
    if plan.steps:
        markdown += "## Steps\n\n"
        
        for step in plan.steps:
            # Add the step header with clearly separated status
            # Use brackets around status to prevent confusion with words in the title
            # This format is essential for proper parsing - DO NOT REMOVE the brackets
            markdown += f"### Step {step.number}: [Status: {step.status.value}] {step.title}\n\n"
                        
            # Add subtasks if they exist
            if step.subtasks:
                markdown += "**Subtasks:**\n\n"
                for i, subtask in enumerate(step.subtasks, 1):
                    # Display subtasks with hierarchical numbering
                    markdown += f"{step.number}.{i} {subtask.description}\n"
                markdown += "\n"
            
            # Add agent response if it exists
            if step.step_execution_summary:
                markdown += f"**Step Execution Summary:**\n\n{step.step_execution_summary}\n\n"
            
            markdown += "---\n\n"
    
    return markdown


def markdown_to_json(markdown: str, plan_id: str = None) -> Dict[str, Any]:
    """
    Parse a markdown plan into a JSON representation.
    
    Args:
        markdown: The markdown text to parse
        plan_id: Optional plan ID to use if not found in markdown
        
    Returns:
        Dict: JSON representation of the plan
    """
    # Initialize the plan data structure
    plan_data = {
        "plan_id": plan_id or "",
        "summary": "",
        "status": PlanStatus.PENDING.value,
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
        "steps": [],
        "execution_preference": ExecutionPreference.STEP_BY_STEP.value,
        "current_step": None,
        "interrupted": False    # TODO: Keeping track of interrupted execution
    }
    # Regex patterns to extract metadata
    # Extract plan ID from the title
    title_match = re.search(r"# Plan: ([^\n]+)", markdown)
    if title_match:
        plan_data["plan_id"] = title_match.group(1).strip()
    
    # Extract summary
    summary_pattern = re.compile(r"## Summary\s+([^#]+?)(?=\n\*\*Status|\n## )", re.DOTALL)
    summary_match = summary_pattern.search(markdown)
    if summary_match:
        plan_data["summary"] = summary_match.group(1).strip()
    
    # Extract status
    status_match = re.search(r"\*\*Status:\*\* ([^\n]+)", markdown)
    if status_match:
        status_text = status_match.group(1).strip()
        # Map to PlanStatus enum
        for status in PlanStatus:
            if status.value == status_text:
                plan_data["status"] = status.value
                break
    
    # Extract execution preference
    execution_mode_match = re.search(r"\*\*Execution Mode:\*\* ([^\n]+)", markdown)
    if execution_mode_match:
        execution_mode_text = execution_mode_match.group(1).strip()
        if "step by step" in execution_mode_text.lower():
            plan_data["execution_preference"] = ExecutionPreference.STEP_BY_STEP.value
        else:
            plan_data["execution_preference"] = ExecutionPreference.ALL_AT_ONCE.value
    
    # Extract last updated time
    updated_match = re.search(r"\*\*Last Updated:\*\* ([^\n]+)", markdown)
    if updated_match:
        try:
            updated_time = datetime.strptime(updated_match.group(1).strip(), "%Y-%m-%d %H:%M:%S")
            plan_data["updated_at"] = updated_time.isoformat()
        except ValueError:
            # If parsing fails, use current time
            pass
    
    # Extract created time if it exists
    created_match = re.search(r"\*\*Created:\*\* ([^\n]+)", markdown)
    if created_match:
        try:
            created_time = datetime.strptime(created_match.group(1).strip(), "%Y-%m-%d %H:%M:%S")
            plan_data["created_at"] = created_time.isoformat()
        except ValueError:
            # If parsing fails, use current time
            pass
    
    # Try the new format with clear status delimiter first
    step_pattern = re.compile(r"### Step (\d+): \[Status: (.*?)\] (.*?)(?=\n\n|\n###|$)", re.DOTALL)
    step_matches = list(step_pattern.finditer(markdown))
    
    # If no matches with new format, trying second most common format for backward compatibility
    if not step_matches:
        # Legacy format - this can cause the issue with status confusion
        step_pattern = re.compile(r"### Step (\d+): (.*?) (.*?)(?=\n\n|\n###|$)", re.DOTALL)
        step_matches = list(step_pattern.finditer(markdown))
    
    for step_match in step_matches:
        step_number = int(step_match.group(1))
        step_status_text = step_match.group(2).strip()
        step_title = step_match.group(3).strip()
        
        # Map to StepStatus enum
        step_status = StepStatus.PENDING.value
        for status in StepStatus:
            if status.value == step_status_text:
                step_status = status.value
                break
        
        # Initialize step data
        step_data = {
            "number": step_number,
            "title": step_title,
            "status": step_status,
            "subtasks": [],
            "step_execution_summary": None
        }
        
        # Find the step content - try new format first, then fall back to old format
        step_content_match = None
        
        # Try new format with clear status delimiter
        new_format_pattern = re.compile(
            r"### Step \d+: \[Status:.*?\] " + re.escape(step_title) + r".*?(?=### Step \d+:|$)", 
            re.DOTALL
        )
        step_content_match = new_format_pattern.search(markdown, step_match.start())
        
        # If no match with new format, try old format
        if not step_content_match:
            old_format_pattern = re.compile(
                r"### Step \d+: .*?" + re.escape(step_title) + r".*?(?=### Step \d+:|$)", 
                re.DOTALL
            )
            step_content_match = old_format_pattern.search(markdown, step_match.start())
        
        # Removing step dependencies
        if step_content_match:
            step_content = step_content_match.group(0)
                        
            # Extract subtasks - now handling both formats (with or without status markers)
            # First try pattern with status markers - now updated for hierarchical numbering format
            subtask_pattern_with_status = re.compile(r"(\d+\.\d+) (.*?) (.*?)(?=\n\d+\.\d+|\n\n|$)")
            subtask_matches = subtask_pattern_with_status.finditer(step_content)
            
            subtasks_found = False
            for subtask_match in subtask_matches:
                subtasks_found = True
                # Group 1 is the numbering (e.g. "1.1")
                # Group 2 is the status text
                # Group 3 is the description
                # subtask_numbering = subtask_match.group(1).strip()
                subtask_status_text = subtask_match.group(2).strip()
                subtask_desc = subtask_match.group(3).strip()
                
                for status in StepStatus:
                    if status.value == subtask_status_text:
                        break
                
                step_data["subtasks"].append({
                    "description": subtask_desc
                })
            
            # If no subtasks found with status markers, try pattern without status markers
            if not subtasks_found:
                # Look for the subtasks section specifically to avoid matching dependencies
                subtasks_section_pattern = re.compile(r"\*\*Subtasks:\*\*\s*\n(.*?)(?=\n\*\*|\n---|\n###|$)", re.DOTALL)
                subtasks_section_match = subtasks_section_pattern.search(step_content)
                
                if subtasks_section_match:
                    subtasks_section = subtasks_section_match.group(1).strip()
                    # First try updated pattern to match hierarchical numbering format (e.g., "1.1 Description")
                    subtask_pattern_no_status = re.compile(r"(\d+\.\d+) (.+?)(?=\n\d+\.\d+|\n\n|$)")
                    subtask_matches = subtask_pattern_no_status.finditer(subtasks_section)
                    
                    subtasks_found_no_status = False
                    for subtask_match in subtask_matches:
                        subtasks_found_no_status = True
                        # Group 2 is now the description, group 1 is the numbering (e.g., "1.1")
                        subtask_desc = subtask_match.group(2).strip()
                        
                        step_data["subtasks"].append({
                            "description": subtask_desc
                        })
                    
                    # If still no matches, try the original bullet point format for backward compatibility
                    if not subtasks_found_no_status:
                        subtask_pattern_bullets = re.compile(r"- (.+?)(?=\n-|\n\n|$)")
                        subtask_matches = subtask_pattern_bullets.finditer(subtasks_section)
                        
                        for subtask_match in subtask_matches:
                            subtask_desc = subtask_match.group(1).strip()
                            
                            step_data["subtasks"].append({
                                "description": subtask_desc
                            })
            
            # Extract agent response
            agent_response_pattern = re.compile(r"\*\*Step Execution Summary:\*\*\s+(.*?)(?=\n---|\n###|$)", re.DOTALL)
            agent_response_match = agent_response_pattern.search(step_content)
            
            if agent_response_match:
                step_data["step_execution_summary"] = agent_response_match.group(1).strip()
        
        plan_data["steps"].append(step_data)
    
    # Sort steps by number to ensure proper order
    plan_data["steps"] = sorted(plan_data["steps"], key=lambda x: x["number"])
    
    return plan_data


def save_plan_files(plan: Plan, plans_dir: str, private_plans_dir: Optional[str] = None) -> Tuple[str, str]:
    """
    Save both markdown and JSON versions of a plan.
    
    Args:
        plan: The Plan object to save
        plans_dir: Directory where plans are stored
        private_plans_dir: Directory for JSON files (defaults to plans_dir if not provided)
        
    Returns:
        Tuple[str, str]: Paths to the saved markdown and JSON files
    """
    # Ensure plans directory exists
    os.makedirs(plans_dir, exist_ok=True)
    
    # If private_plans_dir is not provided, use plans_dir
    if private_plans_dir is None:
        logger.warning(f"private_plans_dir not provided, using plans_dir: {plans_dir}")
        private_plans_dir = plans_dir
    
    # Ensure private_plans_dir exists
    os.makedirs(private_plans_dir, exist_ok=True)
    
    # Generate the file paths
    md_path = os.path.join(plans_dir, f"{plan.plan_id}.md")
    json_path = os.path.join(private_plans_dir, f"{plan.plan_id}.json")
    
    logger.info(f"Saving plan JSON to: {json_path}")
    logger.info(f"Saving plan markdown to: {md_path}")
    
    # Always save the JSON first as the source of truth
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(plan.dict_with_enum_values(), f, indent=2)
    
    # Then generate markdown content from the plan object (not from parsing JSON)
    markdown_content = json_to_markdown(plan)
    
    # Write markdown file
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(markdown_content)
    
    return md_path, json_path


def load_plan(plan_id: str, plans_dir: str, private_plans_dir: Optional[str] = None, save_json: Optional[bool] = True) -> Optional[Plan]:
    """
    Load a plan from either JSON or markdown file.
    
    Args:
        plan_id: ID of the plan to load
        plans_dir: Directory where plans are stored
        private_plans_dir: Directory for JSON files (defaults to plans_dir if not provided)
        save_json: Whether to save JSON file when loading from markdown (default: True for backward compatibility)
        
    Returns:
        Optional[Plan]: The loaded Plan object or None if not found
    """
    # If private_plans_dir is not provided, use plans_dir
    if private_plans_dir is None:
        logger.warning(f"private_plans_dir not provided for loading, using plans_dir: {plans_dir}")
        private_plans_dir = plans_dir
    
    # Check if JSON file exists
    json_path = os.path.join(private_plans_dir, f"{plan_id}.json")
    logger.info(f"Looking for plan JSON at: {json_path}")
    if os.path.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                plan_data = json.load(f)
            
            # Create a copy to avoid modifying the original during conversion
            plan_data_copy = plan_data.copy()
            
            # Convert enum string values back to enum instances
            for i, step in enumerate(plan_data_copy.get("steps", [])):
                # Convert step status using text-based matching for safety
                status_text = step.get("status", "")
                for status_enum in StepStatus:
                    if status_text == status_enum.value or (
                        isinstance(status_text, str) and 
                        " " in status_text and 
                        " " in status_enum.value and
                        status_text.split(" ", 1)[1] == status_enum.value.split(" ", 1)[1]
                    ):
                        plan_data_copy["steps"][i]["status"] = status_enum
                        break
                else:
                    # Default if no match
                    plan_data_copy["steps"][i]["status"] = StepStatus.PENDING
                            
            # Convert plan status - with safer text-based matching fallback
            try:
                if "status" in plan_data_copy:
                    status_text = plan_data_copy["status"]
                    
                    # Try direct match first
                    matched = False
                    for status_enum in PlanStatus:
                        if status_text == status_enum.value:
                            plan_data_copy["status"] = status_enum
                            matched = True
                            break
                    
                    # If direct match fails, try matching just the text part
                    if not matched and isinstance(status_text, str) and " " in status_text:
                        status_label = status_text.split(" ", 1)[1]
                        for status_enum in PlanStatus:
                            if " " in status_enum.value and status_label == status_enum.value.split(" ", 1)[1]:
                                plan_data_copy["status"] = status_enum
                                matched = True
                                break
                    
                    # If still no match, use direct enum assignment based on keywords
                    if not matched:
                        if isinstance(status_text, str):
                            if "Approved" in status_text:
                                plan_data_copy["status"] = PlanStatus.APPROVED
                            elif "Completed" in status_text:
                                plan_data_copy["status"] = PlanStatus.COMPLETED
                            elif "Failed" in status_text:
                                plan_data_copy["status"] = PlanStatus.FAILED
                            else:
                                plan_data_copy["status"] = PlanStatus.PENDING
                        else:
                            plan_data_copy["status"] = PlanStatus.PENDING
                else:
                    # Default to PENDING if status is missing
                    plan_data_copy["status"] = PlanStatus.PENDING
            except Exception as e:
                logger.error(f"Error converting plan status: {e}")
                # Default to PENDING if conversion fails
                plan_data_copy["status"] = PlanStatus.PENDING
            
            # Convert dates from ISO format to datetime objects
            try:
                if "created_at" in plan_data_copy and isinstance(plan_data_copy["created_at"], str):
                    plan_data_copy["created_at"] = datetime.fromisoformat(plan_data_copy["created_at"])
            except Exception as e:
                logger.error(f"Error converting created_at date: {e}")
                plan_data_copy["created_at"] = datetime.now()
            
            try:
                if "updated_at" in plan_data_copy and isinstance(plan_data_copy["updated_at"], str):
                    plan_data_copy["updated_at"] = datetime.fromisoformat(plan_data_copy["updated_at"])
            except Exception as e:
                logger.error(f"Error converting updated_at date: {e}")
                plan_data_copy["updated_at"] = datetime.now()
            
            plan = Plan(**plan_data_copy)
            
            # Recalculate current_step based on completed steps count
            if plan.steps:
                completed_steps = sum(1 for step in plan.steps if step.status == StepStatus.COMPLETED)
                plan.current_step = completed_steps
                logger.info(f"Updated plan.current_step to {completed_steps} based on completed steps count")
            
            return plan
        except Exception as e:
            logger.error(f"Error loading JSON plan: {e}")
            # Fall back to markdown if JSON loading fails
    
    # If JSON file doesn't exist or loading failed, try markdown
    md_path = os.path.join(plans_dir, f"{plan_id}.md")
    if os.path.exists(md_path):
        try:
            with open(md_path, 'r', encoding='utf-8') as f:
                markdown_content = f.read()
            
            # Parse markdown to JSON
            plan_data = markdown_to_json(markdown_content, plan_id)
            
            # Save as JSON for future use (only if save_json is True)
            if save_json:
                json_path = os.path.join(private_plans_dir, f"{plan_id}.json")
                with open(json_path, 'w', encoding='utf-8') as f:
                    json.dump(plan_data, f, indent=2)
            
            # Create a copy to avoid modifying the original during conversion
            plan_data_copy = plan_data.copy()
            
            # Convert enum string values back to enum instances
            for i, step in enumerate(plan_data_copy.get("steps", [])):
                # Convert step status using text-based matching for safety
                status_text = step.get("status", "")
                for status_enum in StepStatus:
                    if status_text == status_enum.value or (
                        isinstance(status_text, str) and 
                        " " in status_text and 
                        " " in status_enum.value and
                        status_text.split(" ", 1)[1] == status_enum.value.split(" ", 1)[1]
                    ):
                        plan_data_copy["steps"][i]["status"] = status_enum
                        break
                else:
                    # Default if no match
                    plan_data_copy["steps"][i]["status"] = StepStatus.PENDING
                
                # Convert subtask status
                for j, subtask in enumerate(step.get("subtasks", [])):
                    if "status" in subtask:
                        status_text = subtask.get("status", "")
                        for status_enum in StepStatus:
                            if status_text == status_enum.value or (
                                isinstance(status_text, str) and
                                " " in status_text and 
                                " " in status_enum.value and
                                status_text.split(" ", 1)[1] == status_enum.value.split(" ", 1)[1]
                            ):
                                plan_data_copy["steps"][i]["subtasks"][j]["status"] = status_enum
                                break
                        else:
                            # Default if no match
                            plan_data_copy["steps"][i]["subtasks"][j]["status"] = StepStatus.PENDING
                            
            # Convert plan status - with safer text-based matching fallback
            try:
                if "status" in plan_data_copy:
                    status_text = plan_data_copy["status"]
                    
                    # Try direct match first
                    matched = False
                    for status_enum in PlanStatus:
                        if status_text == status_enum.value:
                            plan_data_copy["status"] = status_enum
                            matched = True
                            break
                    
                    # If direct match fails, try matching just the text part
                    if not matched and isinstance(status_text, str) and " " in status_text:
                        status_label = status_text.split(" ", 1)[1]
                        for status_enum in PlanStatus:
                            if " " in status_enum.value and status_label == status_enum.value.split(" ", 1)[1]:
                                plan_data_copy["status"] = status_enum
                                matched = True
                                break
                    
                    # If still no match, use direct enum assignment based on keywords
                    if not matched:
                        if isinstance(status_text, str):
                            if "Approved" in status_text:
                                plan_data_copy["status"] = PlanStatus.APPROVED
                            elif "Completed" in status_text:
                                plan_data_copy["status"] = PlanStatus.COMPLETED
                            elif "Failed" in status_text:
                                plan_data_copy["status"] = PlanStatus.FAILED
                            else:
                                plan_data_copy["status"] = PlanStatus.PENDING
                        else:
                            plan_data_copy["status"] = PlanStatus.PENDING
                else:
                    # Default to PENDING if status is missing
                    plan_data_copy["status"] = PlanStatus.PENDING
            except Exception as e:
                logger.error(f"Error converting plan status: {e}")
                # Default to PENDING if conversion fails
                plan_data_copy["status"] = PlanStatus.PENDING
            
            # Convert dates from ISO format to datetime objects
            try:
                if "created_at" in plan_data_copy and isinstance(plan_data_copy["created_at"], str):
                    plan_data_copy["created_at"] = datetime.fromisoformat(plan_data_copy["created_at"])
                else:
                    plan_data_copy["created_at"] = datetime.now()
            except Exception as e:
                logger.error(f"Error converting created_at date: {e}")
                plan_data_copy["created_at"] = datetime.now()
            
            try:
                if "updated_at" in plan_data_copy and isinstance(plan_data_copy["updated_at"], str):
                    plan_data_copy["updated_at"] = datetime.fromisoformat(plan_data_copy["updated_at"])
                else:
                    plan_data_copy["updated_at"] = datetime.now()
            except Exception as e:
                logger.error(f"Error converting updated_at date: {e}")
                plan_data_copy["updated_at"] = datetime.now()
            
            plan = Plan(**plan_data_copy)
            
            # Recalculate current_step based on completed steps count
            if plan.steps:
                completed_steps = sum(1 for step in plan.steps if step.status == StepStatus.COMPLETED)
                plan.current_step = completed_steps
                logger.info(f"Updated plan.current_step to {completed_steps} based on completed steps count")
            
            return plan
        except Exception as e:
            logger.error(f"Error loading markdown plan: {e}")
    
    return None


def cleanup_orphaned_plans(plans_dir: str, private_plans_dir: Optional[str] = None) -> List[str]:
    """
    Removes JSON plan files that don't have corresponding markdown files.
    
    Args:
        plans_dir: Directory where markdown plan files are stored
        private_plans_dir: Directory where JSON plan files are stored (defaults to plans_dir if not provided)
    
    Returns:
        List[str]: List of removed JSON file IDs
    """
    if not os.path.exists(plans_dir):
        logger.warning(f"Plans directory not found: {plans_dir}")
        return []
    
    # If private_plans_dir is not provided, use plans_dir
    if private_plans_dir is None:
        private_plans_dir = plans_dir
        
    if not os.path.exists(private_plans_dir):
        logger.warning(f"Private plans directory not found: {private_plans_dir}")
        return []
    
    removed_plans = []
    
    # Get all markdown files
    md_files = set()
    for filename in os.listdir(plans_dir):
        if filename.endswith(".md"):
            md_files.add(filename[:-3])  # Store without extension
    
    # Also check for markdown files in private_plans_dir if different from plans_dir
    if private_plans_dir != plans_dir and os.path.exists(private_plans_dir):
        for filename in os.listdir(private_plans_dir):
            if filename.endswith(".md"):
                md_files.add(filename[:-3])  # Store without extension
    
    # Check JSON files and remove those without markdown counterparts
    for filename in os.listdir(private_plans_dir):
        if filename.endswith(".json"):
            plan_id = filename[:-5]  # Remove .json extension
            
            # Check if there's a corresponding markdown file in either directory
            if plan_id not in md_files:
                json_path = os.path.join(private_plans_dir, filename)
                try:
                    logger.info(f"Removing orphaned JSON plan file: {json_path}")
                    os.remove(json_path)
                    removed_plans.append(plan_id)
                except Exception as e:
                    logger.error(f"Error removing orphaned JSON plan file {json_path}: {e}")
    
    return removed_plans

def list_plans(plans_dir: str, save_json: bool = False, private_plans_dir: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    List all available plans in the plans directory.
    
    Args:
        plans_dir: Directory where plans are stored
        save_json: Whether to save JSON files when loading from markdown (default: False for listing)
        private_plans_dir: Directory where JSON plan files are stored (defaults to plans_dir if not provided)
        
    Returns:
        List[Dict[str, Any]]: List of plan information dictionaries
    """
    if not os.path.exists(plans_dir):
        logger.warning(f"Plans directory not found: {plans_dir}")
        return []
    
    # If private_plans_dir is not provided, use plans_dir
    if private_plans_dir is None:
        private_plans_dir = plans_dir
    
    # Clean up orphaned JSON files
    cleanup_orphaned_plans(plans_dir, private_plans_dir)
    
    plans = []
    processed_plan_ids = set()
    for plan_dir in [plans_dir, private_plans_dir]:
        if not os.path.isdir(plan_dir):
            continue
        for filename in os.listdir(plan_dir):
            if not filename.endswith(".md"):
                continue
            plan_id = os.path.splitext(filename)[0]
            if plan_id in processed_plan_ids:
                continue
            processed_plan_ids.add(plan_id)  # Skip already processed plan IDs
            plan = load_plan(plan_id, plan_dir, private_plans_dir, save_json=save_json)
            if not plan:
                continue
            # Count completed steps
            completed_steps = sum(1 for step in plan.steps if step.status == StepStatus.COMPLETED) if plan.steps else 0
            plans.append({
                "id": plan.plan_id,
                "status": plan.status.value,
                "summary": plan.summary,
                "updated_at": plan.updated_at.strftime("%Y-%m-%d %H:%M:%S"),
                "steps_count": len(plan.steps) if plan.steps else 0,
                "current_step": plan.current_step,
                "completed_steps": completed_steps
            })
    
    # Sort plans by updated_at (most recent first)
    plans.sort(key=lambda x: datetime.strptime(x["updated_at"], "%Y-%m-%d %H:%M:%S"), reverse=True)
    
    return plans