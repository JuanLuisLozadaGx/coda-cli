from typing import Optional
from coda_core.core.memories import Memory
import json
from loguru import logger
from coda_core.core.models.providers.responses_api.enums import ItemType
from coda_core.core.modes.step_by_step_utilities.planning_converters import load_plan, json_to_markdown
from coda_core.core.modes.step_by_step_utilities.utils import get_reduced_context_for_next_step
from coda_core.core.modes.step_by_step_utilities.constants import cleaning_message

class PlanMemoryManager:
    """
    Manages and tracks tool usage in planning mode.
    
    This class captures which tools were used during plan creation and execution,
    providing insights into agent behavior and potentially helping optimize tool sets.
    
    It tracks:
    - Which tools are called
    - The arguments passed to each tool
    - The results returned by each tool
    """
    
    def __init__(self, plan_id: Optional[str] = None, plans_dir: Optional[str] = None, private_plans_dir: Optional[str] = None):
        """
        Initialize the plan memory manager.
        
        Args:
            plan_id: Optional ID for the plan being monitored
            plans_dir: Directory where plans are stored
        """
        self.plan_id = plan_id
        self.plans_dir = plans_dir
        self.private_plans_dir = private_plans_dir
        self.active = True
        self.tool_usage = []  # New list to store tool usage information
        
        logger.info(f"PlanMemoryManager initialized for plan: {plan_id or 'None'}")
    
    
    def register_callbacks(self, agent) -> None:
        """
        Register callbacks with the given agent.
        
        Args:
            agent: The agent to register callbacks with
        """
        if not agent:
            logger.warning("Cannot register callbacks: agent is None")
            return
        
        # Add our callbacks to any existing callbacks
        callbacks = getattr(agent, "mode_callbacks", {}) or {}

        
        # Also register the LLM start callback
        def on_llm_start():
            logger.info(f"LLM start callback triggered")
            # We can't access user message here, but we can see if the callback is being called
        
        callbacks["on_llm_start"] = on_llm_start
        
        # Register the merged callbacks with the agent
        agent.mode_callbacks = callbacks
        self.active = True
        
        logger.info(f"PlanMemoryManager callbacks registered with agent for plan: {self.plan_id or 'None'}")
        logger.info(f"Registered callback types: {list(callbacks.keys())}")
    
    def set_plan_id(self, plan_id: str) -> None:
        """
        Update the plan ID associated with this memory manager.
        
        Args:
            plan_id: The new plan ID
        """
        self.plan_id = plan_id
        logger.info(f"PlanMemoryManager updated plan_id to: {plan_id}")

    def add_plan_to_memory(self, memory: Memory):
        """
        Add the current plan content to the agent's memory.
        
        Args:
            memory: The memory object to add the plan to
        """
        if not self.plan_id:
            logger.warning("Cannot add plan to memory: plan_id is None")
            return
        
        plan = load_plan(plan_id=self.plan_id, plans_dir=self.plans_dir, private_plans_dir=self.private_plans_dir)
        if not plan:
            logger.warning(f"Cannot add plan to memory: no plan found for plan_id {self.plan_id}")
            return
        
        string_plan = json_to_markdown(plan)
        if not string_plan:
            logger.warning(f"Cannot add plan to memory: failed to convert plan to markdown for plan_id {self.plan_id}")
            return
        
        # Add the plan as a system message in memory
        memory.add_user_message("Show me the plan so far.")
        memory.add_assistant_message(f"Current Plan:\n{string_plan}")
        logger.info(f"Added plan {self.plan_id} to memory")

    def format_captured_tool_usage(self) -> str:
        """
        Format the captured tool usage into a string for context.
        
        Returns:
            A formatted string containing tool usage information
        """
        if not self.tool_usage:
            return ""
        
        chunks = []
        for entry in self.tool_usage:
            if entry["type"] == "call":
                name = entry.get("name")
                args = entry.get("args")
                chunks.append(f"tool call: {name}\narguments: {json.dumps(args, ensure_ascii=False)}")
            elif entry["type"] == "result":
                name = entry.get("name")
                success = entry.get("success")
                result = entry.get("result")
                
                # Format the result based on type
                if isinstance(result, (dict, list)):
                    result_str = json.dumps(result, ensure_ascii=False)
                else:
                    result_str = str(result)
                    
                chunks.append(f"tool name: {name}\nstatus: {'success' if success else 'error'}\nresult: {result_str}")
        
        formatted_output = "\n\n".join(chunks)
        return formatted_output
    
    def clear(self):
        """
        Clear the stored tool usage information.
        """
        self.tool_usage = []
        logger.info("Cleared stored tool usage information")
        
    def extract_tool_calls_from_memory(self, memory: Memory):
        """
        Extract tool calls and arguments directly from the agent's memory.
        
        Args:
            memory: The memory object to inspect
            
        Returns:
            List of tool usage entries
        """
        if not memory:
            return []
            
        extracted_usage = []
        messages = memory.retrieve()
        
        # Track the assistant messages with tool calls and find corresponding tool results
        tool_call_map = {}  # Map of tool_call_id to tool call info
        
        for message in messages:
            role = message.get('role')
            msg_type = message.get("type")

            if msg_type in {ItemType.FUNCTION_CALL, ItemType.FUNCTION_TOOL_CALL}:
                tool_call_id = message.get("call_id")
                tool_name = message.get("name")
                arguments = message.get("arguments", "{}")
                try:
                    args = json.loads(arguments)
                except Exception:
                    args = {"raw_arguments": arguments}
                tool_call_map[tool_call_id] = {
                    "type": "call",
                    "name": tool_name,
                    "args": args,
                }
                extracted_usage.append(tool_call_map[tool_call_id])
                continue

            if msg_type in {ItemType.FUNCTION_CALL_OUTPUT, ItemType.FUNCTION_TOOL_CALL_OUTPUT}:
                tool_call_id = message.get("call_id")
                result = message.get("output", None)
                try:
                    result_data = json.loads(result) if isinstance(result, str) else result
                except Exception:
                    result_data = result
                if tool_call_id in tool_call_map:
                    tool_name = tool_call_map[tool_call_id]["name"]
                    extracted_usage.append({
                        "type": "result",
                        "name": tool_name,
                        "success": True,
                        "result": result_data,
                    })
                continue

            # Legacy assistant messages with tool calls
            if role == 'assistant' and 'tool_calls' in message:
                tool_calls = message.get('tool_calls', [])
                for tool_call in tool_calls:
                    tool_call_id = tool_call.get('id')
                    function = tool_call.get('function', {})
                    tool_name = function.get('name')
                    arguments = function.get('arguments', '{}')
                    
                    # Try to parse arguments
                    try:
                        args = json.loads(arguments)
                    except Exception:
                        args = {"raw_arguments": arguments}
                    
                    # Store this tool call
                    tool_call_map[tool_call_id] = {
                        "type": "call",
                        "name": tool_name,
                        "args": args
                    }
                    extracted_usage.append(tool_call_map[tool_call_id])
                continue

            # Legacy tool messages
            if role == 'tool' and 'tool_call_id' in message:
                tool_call_id = message.get('tool_call_id')
                result = message.get('content', None)
                
                # Try to parse result if it's JSON
                try:
                    result_data = json.loads(result)
                except Exception as _e:
                    # If parsing fails, use the original string as is
                    result_data = result
                
                # Get the corresponding tool call
                if tool_call_id in tool_call_map:
                    tool_name = tool_call_map[tool_call_id]["name"]
                    extracted_usage.append({
                        "type": "result",
                        "name": tool_name,
                        "success": True,
                        "result": result_data
                    })
                continue

            logger.debug(f"Skipping non-tool message in memory: role={role}, type={msg_type}")
        logger.info(f"Extracted {len(extracted_usage)} tool usage entries from memory")
        return extracted_usage
        
    def memory_cleaning_after_mark_step(self, memory:Memory, plan_id=None, plans_dir=None):
        """
        Clean the memory after the mark_step tool is used, preserving only essential context.
        
        This method:
        1. Loads the plan content
        2. Creates a summary of the plan state and tool usage
        3. Clears the memory while maintaining system prompts
        4. Injects the reduced context as a new message
        
        Args:
            memory: The agent's memory instance to clean and inject into
            plan_id: The ID of the current plan (defaults to self.plan_id if not provided)
            plans_dir: The directory where plans are stored (defaults to self.plans_dir if not provided)
            
        Returns:
            The memory object with reduced context
        """
        # Early validation                                                                               
        if memory is None:                                                                               
            logger.warning("Memory cleaning called with None memory object - nothing to clean")          
            return None                                                                                  
                                                                                                        
        # Use instance values if not provided                                                            
        plan_id = plan_id or self.plan_id                                                                
        plans_dir = plans_dir or self.plans_dir
        private_plans_dir = self.private_plans_dir
                                                                                                       
        logger.info(f"Starting memory cleaning for plan: {plan_id}")                                     
        logger.info(f"Using plans_dir: {plans_dir}")
        logger.info(f"Using private_plans_dir: {private_plans_dir}")


        try:
            # Log initial memory state
            initial_memory_size = 0
            
            extracted_tool_usage = self.extract_tool_calls_from_memory(memory)
            
            # Update our tool_usage with the extracted data
            self.tool_usage = extracted_tool_usage
            
            # Try formatting again with the extracted data
            tool_usage = self.format_captured_tool_usage()
            logger.info(f"Extracted tool usage successfully: {len(tool_usage) if tool_usage else 0} characters")

            # Log initial memory messages for comparison
            messages = memory.retrieve()
            initial_memory_size = len(messages)
            
            logger.info(f"Tool usage context length: {len(tool_usage) if tool_usage else 0}")
            
            # Load the plan with both directories
            plan = load_plan(plan_id=plan_id, plans_dir=plans_dir, private_plans_dir=private_plans_dir)
            logger.info(f"Loaded plan: {plan_id}")

            # Convert plan to string representation
            if plan:
                string_plan = json_to_markdown(plan)
                logger.info(f"Converted plan to markdown format: {len(string_plan) if string_plan else 0} characters")
            else:
                string_plan = None
                logger.warning("No plan content found to include in memory summary")
            
            # Create reduced context with plan state and enhanced tool usage history
            reduced_context = get_reduced_context_for_next_step(string_plan, tool_usage)
            logger.info(f"Created reduced context summary with {len(reduced_context)} characters")
            logger.debug(f"Reduced context content: {reduced_context}")
            
            # Just for log purposes
            system_messages = []
            if memory:
                system_messages = [msg for msg in memory.retrieve() if msg.get('role') == 'system']
                logger.info(f"Preserved {len(system_messages)} system messages")
            
            # Clean the existing memory - this maintains system messages
            memory.clear()
            logger.info("Memory cleared while maintaining system messages")
            
            # Inject the reduced context as an assistant message
            context_message = cleaning_message(plan_id, reduced_context)
            memory.add_assistant_message(context_message)
            
            # Log final memory state
            final_messages = memory.retrieve()
            final_memory_size = len(final_messages)
            messages_removed = initial_memory_size - final_memory_size
            
            logger.info(f"✅ Cleaning memory done: memory has {final_memory_size} messages now (reduced from {initial_memory_size}, removed {messages_removed} messages)")
            
            # Clear the tool usage after injecting it into memory to avoid duplication in the next cleanup
            self.clear()
            
            return memory
            
        except Exception as e:
            logger.error(f"Memory cleaning error: {e}")
            return memory
