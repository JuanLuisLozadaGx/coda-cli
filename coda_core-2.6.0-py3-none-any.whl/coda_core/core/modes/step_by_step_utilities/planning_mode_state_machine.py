from typing import Dict, Any
from enum import Enum
from loguru import logger

from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.core.tools.step_by_step_tools.approve_plan.functions import set_mode_transition_callback
from coda_core.core.tools.step_by_step_tools.mark_plan_as_pending.functions import set_mode_transition_callback as set_mark_pending_callback
from coda_core.core.tools.step_by_step_tools.load_plan.functions import set_mode_transition_callback as set_load_plan_callback
from coda_core.core.tools.step_by_step_tools.mark_step.functions import set_mark_step_callback
from coda_core.core.modes.step_by_step_utilities.utils import create_agent_for_plan_mode
from coda_core.core.modes.step_by_step_utilities.planning_memory_management import PlanMemoryManager
from coda_core.config.settings import SETTINGS, EnvConfig
from coda_core.core.modes.step_by_step_utilities.constants import EXECUTION_TOOLS, CREATION_TOOLS


class PlanningModeState(Enum):
    """
    Enum representing the different states in the Planning Mode state machine.
    """
    PLANNING_MODE = "planning_mode"
    EXECUTION_MODE = "execution_mode"


class PlanningModeStateMachine:
    """
    A finite state machine for managing transitions between planning and execution modes.
    
    This class encapsulates state management logic that was previously embedded in the PlanningMode
    class. It handles state transitions, callback registration, and provides an interface for
    the PlanningMode class to interact with the underlying state.
    
    This FSM currently supports two states:
    - PLANNING_MODE: When the agent is creating or updating plans
    - EXECUTION_MODE: When the agent is executing an approved plan
    """
    
    def __init__(self, mode_instance=None):
        """
        Initialize the state machine.
        
        Args:
            mode_instance: Reference to the parent PlanningMode instance
        """
        self._current_state = PlanningModeState.PLANNING_MODE
        self._mode_instance = mode_instance
        
        # Store references to important objects needed during transitions
        self._agent = None
        self._shared_state = None
        self._ui_handler = None
        
        # Track the currently loaded plan
        self._current_plan_id = None
        
        # Initialize the memory manager
        self._memory_manager = PlanMemoryManager(
            plan_id=None,  # Will be set during transition to execution mode
            plans_dir=SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR),
            private_plans_dir=SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
        )
        
        # Flag to track if memory cleaning is needed after mark_step
        self._needs_memory_cleaning = False
        # The step number that was marked (to include in logging)
        self._last_marked_step = None
        
        logger.info("PlanningModeStateMachine initialized in PLANNING_MODE state")
    
    @property
    def current_state(self) -> PlanningModeState:
        """
        Get the current state of the state machine.
        
        Returns:
            The current state as a PlanningModeState enum value
        """
        return self._current_state
    
    @property
    def current_state_value(self) -> str:
        """
        Get the string value of the current state.
        
        Returns:
            The string value of the current state
        """
        return self._current_state.value
    
    def set_state(self, new_state: PlanningModeState) -> None:
        """
        Set the state machine to a new state.
        
        Args:
            new_state: The new state to transition to
        """
        if self._current_state == new_state:
            logger.info(f"State machine already in {new_state.name} state, no change needed")
            return
            
        logger.info(f"State machine transitioning from {self._current_state.name} to {new_state.name}")
        self._current_state = new_state
    
    def set_mode_references(self, agent, shared_state, ui_handler) -> None:
        """
        Set references to objects needed during state transitions.
        
        Args:
            agent: The agent instance used by the planning mode
            shared_state: The shared state object
            ui_handler: The UI handler for displaying plans
        """
        self._agent = agent
        self._shared_state = shared_state
        self._ui_handler = ui_handler
        logger.info("References updated in the state machine")
            
    def register_callbacks(self) -> None:
        """
        Register all callbacks for state transitions with the appropriate tools.
        """
        logger.info("Registering state transition callbacks with tools")
        set_mode_transition_callback(self.handle_mode_transition_from_create_to_exec)
        logger.info("Mode transition callback registered with approve_plan tool")
        
        set_mark_pending_callback(self.handle_transition_from_exec_to_create)
        logger.info("Mode transition callback registered with mark_plan_as_pending tool")
        
        set_load_plan_callback(self.handle_mode_transition_from_create_to_exec)
        logger.info("Mode transition callback registered with load_plan tool")
    
    def remove_memory_manager_callbacks(self, agent) -> None:
        # Remove the memory manager callbacks
        if agent.mode_callbacks:
            callbacks = agent.mode_callbacks.copy()
            
            # Remove any on_llm_start callback that belongs to the memory manager
            if "on_llm_start" in callbacks:
                callbacks.pop("on_llm_start")
                logger.info("Removed on_llm_start callback")
            
            if "on_start" in callbacks:
                # Preserve any other on_start callbacks that might be chained
                def is_our_on_start(fn):
                    fn_str = str(fn)
                    return "clean_memory_after_mark_step" in fn_str
                
                if is_our_on_start(callbacks["on_start"]):
                    callbacks.pop("on_start")
                    logger.info("Removed memory cleaning on_start callback")
            
            agent.mode_callbacks = callbacks
            logger.info("Unregistered memory manager callbacks from agent before mode switch")
        else:
            logger.info("No mode_callbacks found on agent to unregister memory manager callbacks")

    def unregister_callbacks(self) -> None:
        """
        Clear all callbacks when the state machine is no longer needed.
        """
        logger.info("Unregistering state transition callbacks from tools")
        set_mode_transition_callback(None)
        logger.info("Cleared mode transition callback from approve_plan tool")
        
        set_mark_pending_callback(None)
        logger.info("Cleared mode transition callback from mark_plan_as_pending tool")
        
        set_load_plan_callback(None)
        logger.info("Cleared mode transition callback from load_plan tool")
        
        set_mark_step_callback(None)
        logger.info("Cleared callback from mark_step tool")
        
        # Reset memory cleaning flags
        self._needs_memory_cleaning = False
        logger.info("Reset memory cleaning flags")
        
        # Unregister memory manager callbacks if agent exists
        agent = self._agent
        if agent and self._memory_manager and hasattr(agent, "mode_callbacks"):
            self.remove_memory_manager_callbacks(agent)
    
    def register_user_message_callback(self, agent) -> None:
        """
        Register a callback for when a user message is received.
        
        This is used to detect when a new user message arrives after mark_step 
        was used, so we can apply memory cleaning at the right time.
        
        Args:
            agent: The agent instance to register the callback with
        """
        if not agent:
            logger.warning("Cannot register user message callback: agent is None")
            return
        
        # Force direct monkey patching to guarantee the callback gets triggered
        original_get_response = agent.get_response
        
        # Wrap the original get_response method to intercept user messages
        def patched_get_response(user_message, callbacks=None, metadata_param=None):
            logger.info(f"Intercepted user message: {user_message[:50]}...")
            logger.info(f"_needs_memory_cleaning FLAG IS: {self._needs_memory_cleaning}")
            
            # Directly trigger memory cleaning if needed
            if self._needs_memory_cleaning:
                logger.info("✅ DIRECT MEMORY CLEANING TRIGGERED from patched get_response")
                try:
                    self.clean_memory_after_mark_step()
                except Exception as e:
                    logger.error(f"Error in direct memory cleaning: {e}")
            
            # Then call the original method
            return original_get_response(user_message, callbacks, metadata_param)
        
        # Replace the get_response method with our patched version
        agent.get_response = patched_get_response
        logger.info("Directly patched agent.get_response method to intercept all user messages")
        
        # ALSO register the callbacks as a backup
        callbacks = getattr(agent, "mode_callbacks", {}) or {}
        
        # Add our user message callback with clear logging
        def on_start(user_message):
            logger.info(f"Needs memory clean flag (on_start callback): {self._needs_memory_cleaning}")
            
            # Check if memory cleaning is needed
            if self._needs_memory_cleaning:
                logger.info("Cleaning memory after mark step (on_start callback) and injecting reduced context")
                self.clean_memory_after_mark_step(user_message)

        # Add to existing callbacks, preserving any existing on_start
        existing_on_start = callbacks.get("on_start")
        if existing_on_start:
            # Chain the callbacks
            def chained_on_start(user_message):
                # Run our callback first
                on_start(user_message)
                # Then run the existing one
                logger.info("🔄 CHAINED CALLBACK: Running previous on_start callback")
                existing_on_start(user_message)
            
            callbacks["on_start"] = chained_on_start
            logger.info("Chained our memory cleaning callback with existing on_start callback")
        else:
            callbacks["on_start"] = on_start
            logger.info("Registered new on_start callback for memory cleaning")
        
        # Update the agent's callbacks
        agent.mode_callbacks = callbacks
        
        # Register with ALL callback types that might receive user messages
        callback_types = ["on_start", "on_llm_start", "on_tool_call"]
        for cb_type in callback_types:
            if cb_type not in callbacks or callbacks[cb_type] != on_start:
                # Get any existing callback
                existing_callback = callbacks.get(cb_type)
                if existing_callback:
                    # Create a chained callback that runs ours first
                    def make_chained_callback(cb_type, existing, on_start_fn):
                        def chained(*args, **kwargs):
                            logger.info(f"🔄 CHAINED {cb_type} CALLBACK")
                            # Try to extract user_message if available
                            user_msg = None
                            if args and isinstance(args[0], str):
                                user_msg = args[0]
                            
                            if user_msg and self._needs_memory_cleaning:
                                on_start_fn(user_msg)
                            
                            # Then call the original
                            return existing(*args, **kwargs)
                        return chained
                    
                    # Set the chained callback
                    callbacks[cb_type] = make_chained_callback(cb_type, existing_callback, on_start)
                    logger.info(f"Chained callback for {cb_type}")
                else:
                    # Set our callback directly
                    callbacks[cb_type] = on_start
                    logger.info(f"Set direct callback for {cb_type}")
        
        # Final update
        agent.mode_callbacks = callbacks
        logger.info(f"User message callback registered with agent. Agent now has callbacks: {list(agent.mode_callbacks.keys())}")

    def handle_transition_from_exec_to_create(self, plan_data: Dict[str, Any]) -> None:
        """
        Handle the transition from execution to planning mode.
        Called by the mark_plan_as_pending tool via the shared_state callback.
        
        Args:
            plan_data: Dictionary containing plan details (plan_id, plan_file, details, reason)
        """
        logger.info(f"Handling transition to planning mode for plan: {plan_data.get('plan_id')}")
        
        try:
            # Clean up memory manager and callbacks before switching modes
            agent = self._agent
            if agent and self._memory_manager and hasattr(agent, 'mode_callbacks'):
                # Deactivate memory manager
                self._memory_manager.active = False
                
                # Remove the memory manager callbacks
                self.remove_memory_manager_callbacks(agent)
                    
                # Reset memory cleaning flags
                self._needs_memory_cleaning = False
                logger.info("Reset memory cleaning flags before mode switch")
            
            # Unregister the mark_step callback
            set_mark_step_callback(None)
            logger.info("Cleared mark_step callback before mode switch")
            
            # Switch to planning mode
            self.set_state(PlanningModeState.PLANNING_MODE)
            logger.info("Switched state to PLANNING_MODE")
                        
            # Handle tool activation directly in the FSM
            self.handle_planning_tools_activation(plan_data)
            
            reason = plan_data.get('reason', 'No reason provided')
            logger.info(f"Mode transition complete. Planning tools enabled. Reason: {reason}")
            logger.info(f"Plan file path: {plan_data.get('plan_file')}")
            
        except Exception as e:
            logger.error(f"Error during mode transition to planning: {e}")
            # Re-raise to let the tool handle the error
            raise
            
    def handle_mode_transition_from_create_to_exec(self, plan_data: Dict[str, Any]) -> None:
        """
        Handle the transition from planning to execution mode.
        Called by either the approve_plan tool or load_plan tool via the shared_state callback.
        
        Args:
            plan_data: Dictionary containing plan details (plan_id, plan_file, details)
        """
        logger.info(f"Handling mode transition for plan: {plan_data.get('plan_id')}")
        
        try:
            # Switch to execution mode
            self.set_state(PlanningModeState.EXECUTION_MODE)
            logger.info("Switched state to EXECUTION_MODE")
                        
            # Handle tool activation directly in the FSM
            self.handle_execution_tools_activation(plan_data)
            logger.info(f"Mode transition complete. Execution tools enabled.")
            
        except Exception as e:
            logger.error(f"Error during mode transition: {e}")
            # Re-raise to let the tool handle the error
            raise
            
    def handle_planning_tools_activation(self, plan_data: Dict[str, Any]) -> None:
        """
        Handle the activation of planning tools when transitioning to planning mode.
        Called during transition from execution to planning mode.
        
        Args:
            plan_data: Dictionary containing plan details (plan_id, plan_file, details, reason)
        """
        logger.info(f"Activating planning tools for plan: {plan_data.get('plan_id')}")
        
        try:
            # Get tool names for creation phase from the mode instance
            tool_names = []
            if self._mode_instance:
                tool_names = self._mode_instance.get_enabled_tools
                logger.info(f"Tool names for creation phase: {tool_names}")
                
            # Get shared state
            shared_state = self._shared_state
            if not shared_state and hasattr(self._mode_instance, 'shared_state'):
                shared_state = self._mode_instance.shared_state
                
            if not shared_state:
                # Import SharedState inside the method to avoid circular imports
                from coda_core.core.session.states.shared_state import SharedState
                shared_state = SharedState()
                        
                # Log which tools are actually registered and available
                if hasattr(shared_state, 'tool_manager'):
                    registered_tools = shared_state.tool_manager.registry.list_tools()
                    logger.info(f"Registered tools in tool manager: {registered_tools!r}")
                    
                    # Check if planning mode tools are actually registered
                    missing_tools = [name for name in CREATION_TOOLS if name not in registered_tools]
                    if missing_tools:
                        logger.warning(f"Missing tools for planning mode: {missing_tools!r}")
                    
                    # Log the current CREATION_TOOLS list for debugging
                    logger.info(f"PLANNING MODE: CREATION_TOOLS defined in constants: {CREATION_TOOLS!r}")
            
            # Register planning mode tool dependencies
            if hasattr(shared_state, 'tool_manager'):
                tool_manager = shared_state.tool_manager
                
                # Disable execution tools first
                for tool_name in EXECUTION_TOOLS:
                    if tool_name in tool_manager.registry.list_tools() and tool_manager.is_tool_enabled(tool_name):
                        tool_manager.disable_tool(tool_name)
                        logger.info(f"Disabled execution tool: {tool_name}")
                
                # Ensure file_editor is available for tools that need it
                try:
                    file_editor = FileEditor()
                    
                    # Register tool dependencies for planning tools
                    for name in tool_names:
                        # Check if the tool is registered but disabled
                        if name in tool_manager.registry.list_tools() and not tool_manager.is_tool_enabled(name):
                            # Enable the tool for planning mode
                            tool_manager.enable_tool(name)
                            logger.info(f"Enabled planning tool: {name}")
                        
                            # Register file_editor dependency for plan tools that need it
                        if name in CREATION_TOOLS:
                            tool_manager.register_tool_dependency(name, "editor", file_editor)
                            logger.info(f"Registered file_editor dependency for {name}")
                except Exception as e:
                    logger.error(f"Error setting up file_editor dependency: {e}")
                
                logger.info(f"Tool manager prepared with registered tools: {tool_manager.registry.list_tools()}")
            
            # Get actual tool objects from the tool manager
            filtered_tools = []
            if hasattr(shared_state, 'tool_manager'):
                tool_manager = shared_state.tool_manager
                logger.info(f"Tool manager found with {tool_manager.registry} registered tools")
                for name in tool_names:
                    # Check if tool exists in the registry
                    if name in tool_manager.registry.list_tools():
                        filtered_tools.append(tool_manager.registry.get_tool(name))
                        logger.info(f"Added tool: {name}")
                    else:
                        logger.warning(f"Tool not found in registry: {name}")
            logger.info(f"Filtered tools for agent: {[tool for tool in filtered_tools]}")
            
            # Get callbacks from the mode instance
            agent_callbacks = None
            if self._mode_instance:
                agent_callbacks = getattr(self._mode_instance, 'agent_callbacks', None)
                
            # Create the agent with callbacks
            agent, shared_state = create_agent_for_plan_mode(
                filtered_tools, 
                self._mode_instance.system_prompt if self._mode_instance else "modes/plan_creation_prompt.hbs", 
                shared_state, 
                agent_callbacks
            )
            
            # Update references in the mode instance
            if self._mode_instance:
                self._mode_instance.shared_state = shared_state
                self._mode_instance.agent = agent
                self._mode_instance.memory = agent.memory if agent else None
            
            # Update local references
            self._shared_state = shared_state
            self._agent = agent
            
            # Attach the UI handler to the agent with plan file path
            if agent and self._ui_handler:
                # Store the plan file path in the UI handler for later use
                if hasattr(self._ui_handler, 'set_plan_file_path') and plan_data.get('plan_file'):
                    self._ui_handler.set_plan_file_path(plan_data.get('plan_file'))
                    logger.info(f"Plan file path set in UI handler: {plan_data.get('plan_file')}")
                
                agent.ui_handler = self._ui_handler
                logger.info("UI handler attached to planning mode agent after transition")
            
            # Update references in the state machine
            self.set_mode_references(agent, shared_state, self._ui_handler)
            
            # Make sure callbacks are registered
            self.register_callbacks()
            
            reason = plan_data.get('reason', 'No reason provided')
            logger.info(f"Mode transition complete. Planning tools enabled. Reason: {reason}")
            logger.info(f"Plan file path: {plan_data.get('plan_file')}")
            
        except Exception as e:
            logger.error(f"Error activating planning tools: {e}")
            # Re-raise to let the tool handle the error
            raise
            
    def handle_execution_tools_activation(self, plan_data: Dict[str, Any]) -> None:
        """
        Handle the activation of execution tools when transitioning to execution mode.
        Called during transition from planning to execution mode.
        
        Args:
            plan_data: Dictionary containing plan details (plan_id, plan_file, details)
        """
        logger.info(f"Activating execution tools for plan: {plan_data.get('plan_id')}")
        
        try:
                
            # Get shared state
            shared_state = self._shared_state
            if not shared_state and hasattr(self._mode_instance, 'shared_state'):
                shared_state = self._mode_instance.shared_state
                
            # Get agent reference
            agent = self._agent
            if not agent and hasattr(self._mode_instance, 'agent'):
                agent = self._mode_instance.agent
            
            # Track enabled tools
            enabled_tools = []
            if self._mode_instance:
                enabled_tools = getattr(self._mode_instance, '_enabled_tools', [])
            
            # Enable execution tools dynamically
            if hasattr(shared_state, 'tool_manager'):
                tool_manager = shared_state.tool_manager
                
                # Disable planning creation tools first execept load_plan_tool
                for tool_name in CREATION_TOOLS:
                    if tool_name not in  ["load_plan_tool"]:  # Keep load_plan_tool enabled for execution
                        if tool_name in tool_manager.registry.list_tools() and tool_manager.is_tool_enabled(tool_name):
                            tool_manager.disable_tool(tool_name)
                            logger.info(f"Disabled planning tool: {tool_name}")
                
                # Add execution tools to the enabled tools list
                for tool_name in EXECUTION_TOOLS:
                    if tool_name in tool_manager.registry.list_tools():
                        # Enable the tool if not already enabled
                        if not tool_manager.is_tool_enabled(tool_name):
                            tool_manager.enable_tool(tool_name)
                            logger.info(f"Enabled execution tool: {tool_name}")
                        # Add to enabled tools list if not already there
                        if tool_name not in enabled_tools:
                            enabled_tools.append(tool_name)
                    else:
                        logger.warning(f"Execution tool not found in registry: {tool_name}")
                
                    # Update the agent's tools if it exists
                    if agent:
                        # Clear existing creation tools from agent's tools list, except those also in EXECUTION_TOOLS
                        # Tools like load_plan_tool and update_plan are in both CREATION_TOOLS and EXECUTION_TOOLS
                        if hasattr(agent, 'tools'):
                            tools_to_remove = [name for name in CREATION_TOOLS if name not in EXECUTION_TOOLS]
                            agent.tools = [tool for tool in agent.tools if tool.name not in tools_to_remove]
                            logger.info(f"Removed creation-only tools {tools_to_remove!r} from agent's tool list")
                            logger.info(f"EXECUTION MODE: Available tools after filtering: {[tool.name for tool in agent.tools]}")
                            logger.info(f"EXECUTION MODE: EXECUTION_TOOLS defined in constants: {EXECUTION_TOOLS!r}")
                    
                    # Get the new tool objects
                    new_tools = []
                    for tool_name in EXECUTION_TOOLS:
                        if tool_name in tool_manager.registry.list_tools():
                            tool_obj = tool_manager.registry.get_tool(tool_name)
                            new_tools.append(tool_obj)
                    
                    # Add the new tools to the agent's tool list
                    if hasattr(agent, 'tools'):
                        # Extend the existing tools list
                        existing_tool_names = {tool.name for tool in agent.tools}
                        for tool in new_tools:
                            if tool.name not in existing_tool_names:
                                agent.tools.append(tool)
                                logger.info(f"Added tool to agent: {tool.name}")
                        
                        # Log the final list of tools the agent has access to
                        agent_tool_names = [tool.name for tool in agent.tools]
                        logger.info(f"Agent's final tool list: {agent_tool_names}")


            # Get callbacks from the mode instance
            agent_callbacks = None
            if self._mode_instance:
                agent_callbacks = getattr(self._mode_instance, 'agent_callbacks', None)


            logger.info("Recreating agent with execution tools")
            
            # Get the plan_id to inject into the system prompt
            plan_id = plan_data.get('plan_id')
            
            # Create a new agent with execution tools
            agent, shared_state = create_agent_for_plan_mode(
                agent.tools, 
                self._mode_instance.system_prompt if self._mode_instance else "modes/plan_execution_prompt.hbs",
                shared_state, 
                agent_callbacks
            )
            
            # Update references in the mode instance
            if self._mode_instance:
                self._mode_instance.shared_state = shared_state
                self._mode_instance.agent = agent
                self._mode_instance.memory = agent.memory if agent else None

            # Update local references
            self._shared_state = shared_state
            self._agent = agent
            
            # Attach the UI handler to the agent
            if agent and self._ui_handler:
                agent.ui_handler = self._ui_handler
                logger.info("UI handler attached to agent in execution mode")

            # Update mode's enabled tools list
            if self._mode_instance:
                self._mode_instance._enabled_tools = enabled_tools.copy()
            
            # Set up the memory manager with the current plan ID
            try:
                plan_id = plan_data.get('plan_id')            
                if plan_id:
                    # Store the current plan ID in the state machine
                    self._current_plan_id = plan_id
                    logger.info(f"✅ Stored current plan ID in state machine: {plan_id}")
                    
                    # Update the memory manager with the current plan ID
                    self._memory_manager.set_plan_id(plan_id)
                    logger.info(f"Memory manager updated with plan ID: {plan_id}")
                    
                    # Register the memory manager callbacks with the agent - this ensures tool usage is tracked
                    if agent and hasattr(agent, 'mode_callbacks'):
                        # Force-clear the memory manager's data before registering
                        self._memory_manager.clear()
                        logger.info("Memory manager data cleared before registering")
                        
                        # Register callbacks to track tools
                        self._memory_manager.register_callbacks(agent)
                        logger.info("Memory manager callbacks registered with agent")
                        
                        # Log a prominent message to make this clearly visible
                        logger.info("⚠️ Memory manager is now tracking ALL tool usage with enhanced tool input capturing")
                    
                    # Register mark_step callback
                    set_mark_step_callback(self.handle_mark_step_callback)
                    logger.info("Mark step callback registered")
                    
                    # Register user message callback
                    if agent:
                        self.register_user_message_callback(agent)

                    # Inject plan context into the system prompt after agent creation
                    start_command = plan_data.get('start_command', False)
                    from_load_plan = 'start_command' not in plan_data  
                    logger.info(f"Start command flag: {start_command}")
                    
                    # Only inject plan when using /start command, NOT during tool call flow
                    if plan_id and agent and hasattr(agent, 'llm') and hasattr(agent.llm, 'system_prompt') and start_command:
                        logger.info(f"Injecting plan context into system prompt for plan {plan_id} (start_command={start_command})")
                        self._memory_manager.add_plan_to_memory(self._agent.memory)
                    else:
                        logger.info(f"Skipping plan context injection - not from /start command (start_command={start_command}, from_load_plan={from_load_plan})")


                else:
                    logger.warning("No plan ID provided, memory manager will not be fully initialized")
            except Exception as mem_error:
                # Log the error but don't fail the transition
                logger.error(f"Error initializing memory manager: {mem_error}")
        
            logger.info(f"Mode transition complete. Execution tools enabled: {EXECUTION_TOOLS!r}")
            logger.info(f"Plan file path: {plan_data.get('plan_file')}")
            logger.info(f"EXECUTION MODE COMPLETE: Final available tools: {[t.name for t in agent.tools] if agent and hasattr(agent, 'tools') else 'No tools available'}")
            
        except Exception as e:
            logger.error(f"Error activating execution tools: {e}")
            raise
            
    def handle_mark_step_callback(self, callback_data: Dict[str, Any]) -> None:
        """
        Handle the callback from mark_step tool.
        
        This method is called when a step is marked as completed or with another status.
        It sets a flag to indicate that memory cleaning should be performed when the next
        user message is received.
        
        Args:
            callback_data: Dictionary containing step details (plan_id, step_number, status, etc.)
        """
        try:
            plan_id = callback_data.get('plan_id')
            step_number = callback_data.get('step_number')
            status = callback_data.get('status')
            
            logger.info(f"Mark step callback received for plan {plan_id}, step {step_number}, status {status}")
            
            # Set the flag to indicate that memory cleaning is needed
            self._needs_memory_cleaning = True
            self._last_marked_step = step_number
            
            # Log that memory cleaning will be performed on next user message
            logger.info(f"Memory cleaning flag set after marking step {step_number}. Will clean on next user message.")
            
        except Exception as e:
            # Log any errors but don't fail the operation
            logger.error(f"Error in mark step callback: {e}")
            
    def clean_memory_after_mark_step(self, user_message=None) -> None:
        """
        Clean the memory after the mark_step tool is used, preserving essential context.
        
        This method:
        1. Uses the memory_cleaning_after_mark_step method from PlanMemoryManager
        2. Resets the cleaning flag
        
        Args:
            user_message: Optional. The user message that triggered the cleaning
        """
        if not self._needs_memory_cleaning:
            return
        
        try:            
            agent = self._agent
            if not agent or not hasattr(agent, 'memory'):
                logger.warning("Cannot clean memory: agent or memory is None")
                self._needs_memory_cleaning = False  # Reset flag
                return
            
            # Log the memory size before cleaning
            memory_size_before = len(agent.memory.messages) if hasattr(agent.memory, 'messages') else "unknown"
            logger.debug(f"MEMORY SIZE BEFORE CLEANING: {memory_size_before} messages")
            
            # Log memory structure for debugging
            if hasattr(agent.memory, 'messages'):
                role_counts = {}
                for msg in agent.memory.messages:
                    role = msg.get('role', 'unknown')
                    role_counts[role] = role_counts.get(role, 0) + 1
                logger.debug(f"Memory message types before cleaning: {role_counts}")
                
            # Perform the memory cleaning
            self._memory_manager.memory_cleaning_after_mark_step(agent.memory)
            
            # Log the memory size after cleaning
            memory_size_after = len(agent.memory.messages) if hasattr(agent.memory, 'messages') else "unknown"
            messages_removed = memory_size_before - memory_size_after if isinstance(memory_size_before, int) and isinstance(memory_size_after, int) else "unknown"
            
            logger.info(f"✅ Memory cleaning complete: {messages_removed} messages removed")
            logger.info(f"Memory size after cleaning: {memory_size_after} messages (reduced from {memory_size_before})")
            
            # Log memory structure after cleaning
            if hasattr(agent.memory, 'messages'):
                role_counts = {}
                for msg in agent.memory.messages:
                    role = msg.get('role', 'unknown')
                    role_counts[role] = role_counts.get(role, 0) + 1
                logger.info(f"Memory message types after cleaning: {role_counts}")
            
            # Reset flag
            self._needs_memory_cleaning = False
            logger.info(f"Memory cleaning flag reset, memory is now optimized for next interactions")
            
        except Exception as e:
            # Log any errors but don't fail the operation
            logger.error(f"Error in memory cleaning: {e}")
            # Reset the flag even if there was an error
            self._needs_memory_cleaning = False