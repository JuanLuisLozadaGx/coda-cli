
EXECUTION_TOOLS = ["bash","view","mark_step_tool","mark_plan_as_pending_tool","edit", "replace","load_plan_tool","update_plan_tool", "omni_parser"]

CREATION_TOOLS = ['create_plan_tool', 'approve_plan_tool', 'update_plan_tool', 'load_plan_tool',"omni_parser"]

def cleaning_message(plan_id: str, reduced_context: str) -> str:
    return  f"You are executing the plan {plan_id}. Here is your progress so far:\n\n{reduced_context}. After ending the next step execution, return to the user your last progress executing the step, waiting for its next instructions to continue."