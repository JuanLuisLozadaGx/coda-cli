import os
from typing import List, Optional
from loguru import logger
from coda_core.core.modes.base import Mode
from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.core.modes.step_by_step_utilities.utils import create_agent_for_plan_mode, force_cleanup_tools
from coda_core.core.modes.step_by_step_utilities.planning_mode_state_machine import PlanningModeStateMachine, PlanningModeState
from coda_core.core.modes.step_by_step_utilities.constants import EXECUTION_TOOLS, CREATION_TOOLS
from coda_core.core.modes.step_by_step_utilities.planning_converters import load_plan


class PlanningMode(Mode):
    """
    Mode for generating structured plans and organized execution steps.
    
    This class uses a finite state machine (PlanningModeStateMachine) to handle 
    transitions between planning and execution states. The state machine 
    encapsulates the state-related logic, making it easier to maintain and extend
    with new states in the future.
    """
    def __init__(self):
        """
        Mode for generating structured plans and organized execution steps.
        """
        self._key = "Plan Mode"
        self._name = "Plan Mode"
        self._description = "Mode for generating structured plans and organized execution steps."

        # Tool configuration
        self.creation_tools = CREATION_TOOLS
        self.execution_tools = EXECUTION_TOOLS
        self.agent = None
        self.memory = None
        self.agent_callbacks = None
        self._enabled_tools = []
                
        # Staged memory transition attributes
        self.pending_memory_transition = False
        
        # Custom UI handler for planning mode (to be set externally by CLI if needed)
        self.ui_handler = None
        
        # Initialize the state machine
        self.state_machine = PlanningModeStateMachine(self)
                
        # For debugging
        logger.info("PlanningMode initialized - memory transition will be registered at mode transition")
        
    def has_draft_plan(self) -> bool:
        """
        Checks if a draft plan has been created.
        
        Returns:
            bool: True if a plan ID exists in the memory manager
        """
        if hasattr(self.state_machine, '_memory_manager'):
            return bool(self.state_machine._memory_manager.plan_id)
        return False
        
    def get_plan_progress(self) -> tuple[int, int]:
        """
        Returns the current plan progress as a tuple.
        
        Returns:
            tuple[int, int]: (completed_steps, total_steps)
        """
        completed_steps = 0
        total_steps = 0
        
        try:
            # Access the plan ID from the memory manager
            if hasattr(self.state_machine, '_memory_manager'):
                plan_id = self.state_machine._memory_manager.plan_id
                if plan_id:
                    # Load the plan
                    plans_dir = self.state_machine._memory_manager.plans_dir
                    private_plans_dir = self.state_machine._memory_manager.private_plans_dir
                    plan = load_plan(plan_id, plans_dir, private_plans_dir)
                    
                    if plan:
                        # Get current step and total steps
                        completed_steps = plan.current_step if plan.current_step is not None else 0
                        total_steps = len(plan.steps) if plan.steps else 0
        except Exception as e:
            logger.error(f"Error getting plan progress: {e}")
        
        return (completed_steps, total_steps)
        
    @property
    def key(self) -> str:
        """
        Unique key for the planning mode.
        Used to identify the mode in the system.
        Returns:
            str: Unique key strings
        """
        return self._key
    
    @property
    def name(self) -> str:
        """
        Human-readable name for the planning mode with state indicator.
        Returns:
            str: Name of the mode with state (e.g., "Planning Mode][draft" or "Plan Mode [0/7] ⫸")
        """
        state_indicator = self._get_state_indicator()
        # Change from "Planning Mode" to "Plan Mode"
        return f"Plan Mode{state_indicator}"
    
    def _get_state_indicator(self) -> str:
        """
        Get the state indicator for the current mode state.
        Returns:
            str: Step counter "[current/total]" for execution mode, "][draft" for planning mode
        """
        if self.state_machine.current_state == PlanningModeState.EXECUTION_MODE:
            # Get current plan information for step counter
            current_step = 0
            total_steps = 0
            
            try:
                # Access the plan ID from the memory manager
                plan_id = self.state_machine._memory_manager.plan_id
                if plan_id:
                    # Get plan directories, ensuring they're absolute
                    plans_dir = self.state_machine._memory_manager.plans_dir
                    private_plans_dir = self.state_machine._memory_manager.private_plans_dir
                    
                    # Always first try loading the plan using the normal function path
                    logger.info(f"Attempting to load plan using load_plan with plan_id={plan_id}, plans_dir={plans_dir}, private_plans_dir={private_plans_dir}")
                    plan = None
                    
                    # Check if private_plans_dir is properly set up
                    json_path_exists = False
                    if private_plans_dir:
                        json_path_exists = os.path.isabs(private_plans_dir) and os.path.exists(os.path.join(private_plans_dir, f"{plan_id}.json"))
                    
                    # If private_plans_dir is not absolute or doesn't exist, try using environment variable
                    if not json_path_exists:
                        env_private_dir = os.environ.get('CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE')
                        if env_private_dir and os.path.exists(os.path.join(env_private_dir, f"{plan_id}.json")):
                            private_plans_dir = env_private_dir
                            logger.info(f"Using environment variable for private_plans_dir: {private_plans_dir}")
                    
                    # Try loading the plan
                    plan = load_plan(plan_id, plans_dir, private_plans_dir)
                    
                    if plan:
                        # Get current step and total steps
                        current_step = plan.current_step if plan.current_step is not None else 0
                        total_steps = len(plan.steps) if plan.steps else 0
                        logger.info(f"Loaded plan with current_step={current_step}, total_steps={total_steps}")
                    else:
                        # If plan couldn't be loaded, try a direct absolute path lookup
                        env_private_dir = os.environ.get('CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE', '')
                        if env_private_dir:
                            direct_json_path = os.path.join(env_private_dir, f"{plan_id}.json")
                            if os.path.exists(direct_json_path):
                                logger.info(f"Trying direct path load from: {direct_json_path}")
                                plan = load_plan(plan_id, plans_dir, private_plans_dir, save_json=False)
                                if plan:
                                    current_step = plan.current_step if plan.current_step is not None else 0
                                    total_steps = len(plan.steps) if plan.steps else 0
                                    logger.info(f"Loaded plan directly with current_step={current_step}, total_steps={total_steps}")
            except Exception as e:
                logger.error(f"Error getting step count for prompt: {e}")            
            # Return step counter format
            return f" [{current_step}/{total_steps}]"
            
        return " [draft]"
    
    @property
    def description(self) -> str:
        """
        Description of the planning mode.
        Returns:
            str: Description of the mode
        """
        return self._description
    
    @property
    def system_prompt(self) -> str:
        """
        Return the correct template name for the planning mode system prompt.
        
        Returns:
            str: Name of the template file to use for system prompt
        """
        # Choose template based on current FSM state
        if self.state_machine.current_state == PlanningModeState.EXECUTION_MODE:
            return "modes/plan_execution_prompt.hbs"
        # Default to plan creation template for PLANNING_MODE and any other state
        return "modes/plan_creation_prompt.hbs"
    
    @property
    def get_enabled_tools(self) -> List[str]:
        """
        Get the list of tools to enable for planning mode.
        
        Returns:
            List containing tools appropriate for current state
        """
        # Initialize with tools shared across all states
        common_tools = ["view", "think", "ask_user"]

        # Start with a set of common tools
        tool_names = set(common_tools)

        # Add tools based on current FSM state
        if self.state_machine.current_state == PlanningModeState.PLANNING_MODE:
            # For planning mode, add all creation tools
            tool_names.update(self.creation_tools)
        elif self.state_machine.current_state == PlanningModeState.EXECUTION_MODE:
            # For execution mode, add all execution tools
            tool_names.update(self.execution_tools)
            
        # Convert set back to a sorted list for consistency
        tool_list = sorted(list(tool_names))
        
        # Store these tools in the instance for deactivation
        self._enabled_tools = tool_list.copy()
        
        return tool_list
    
    def on_activate(self) -> bool:
        """
        Activate the planning mode.
        """
        logger.info("Activating step by step mode")
        
        try:
            logger.info("Initializing step by step mode")
            
            # Always start in planning mode by default when activated
            self.state_machine.set_state(PlanningModeState.PLANNING_MODE)
            logger.info("Reset state to PLANNING_MODE for fresh activation")
            
            # Clear any previous plan_id from the memory manager when starting fresh
            if hasattr(self.state_machine, '_memory_manager') and self.state_machine._memory_manager:
                self.state_machine._memory_manager.set_plan_id(None)
                logger.info("Cleared plan_id from memory manager for fresh planning session")
            
            # Reset the agent on every activation to ensure proper tools and state
            # If agent exists, clear it completely rather than just clearing memory
            if self.agent:
                logger.info("Resetting existing planning mode agent for fresh activation")
                self.agent = None
                self.memory = None
                
            # Initialize agent for current activation
            if not self.agent:
                logger.info("No existing agent found for planning mode - creating new agent")
                
                # Get shared state
                if not hasattr(self, 'shared_state'):
                    # Import SharedState inside the method to avoid circular imports
                    from coda_core.core.session.states.shared_state import SharedState
                    self.shared_state = SharedState()
                                
                # Get tool names for creation phase
                tool_names = self.get_enabled_tools
                logger.info(f"Tool names for creation phase: {tool_names}")
                
                # Register planning mode tool dependencies
                if hasattr(self.shared_state, 'tool_manager'):
                    tool_manager = self.shared_state.tool_manager
                    
                    # Ensure file_editor is available for tools that need it
                    try:
                        file_editor = FileEditor()
                        
                        # Register tool dependencies for planning tools
                        for name in tool_names:
                            # External tools need the client
                            if name in ["web_search", "examine_images","omni_parser"]:
                                tool_manager.register_tool_dependency(name, "client", self.shared_state.geai_client)
                                tool_manager.enable_tool(name)
                            # Check if the tool is registered but disabled
                            if name in tool_manager.registry.list_tools() and not tool_manager.is_tool_enabled(name):
                                # Enable the tool for planning mode
                                tool_manager.enable_tool(name)
                                logger.info(f"Enabled planning tool: {name}")
                            
                            # Register file_editor dependency for plan tools that need it
                            if name in CREATION_TOOLS and name != "omni_parser":
                                tool_manager.register_tool_dependency(name, "editor", file_editor)
                                logger.info(f"Registered file_editor dependency for {name}")
                    except Exception as e:
                        logger.error(f"Error setting up file_editor dependency: {e}")
                    
                    logger.info(f"Tool manager prepared with registered tools: {tool_manager.registry.list_tools()}")

                # Get actual tool objects from the tool manager
                filtered_tools = []
                if hasattr(self.shared_state, 'tool_manager'):
                    tool_manager = self.shared_state.tool_manager
                    logger.info(f"Tool manager found with {len(tool_manager.registry.list_tools())} registered tools")
                    logger.info(f"Available tools in registry: {tool_manager.registry.list_tools()!r}")
                    logger.info(f"Tool names to be added: {tool_names!r}")
                    
                    for name in tool_names:
                        # Check if tool exists in the registry
                        if name in tool_manager.registry.list_tools():
                            filtered_tools.append(tool_manager.registry.get_tool(name))
                            logger.info(f"Added tool: {name}")
                        else:
                            logger.warning(f"Tool not found in registry: {name}")
                            
                # Ensure we don't have None in filtered_tools (failed tool instantiations)
                filtered_tools = [tool for tool in filtered_tools if tool is not None]
                logger.info(f"Filtered tools for agent: {[tool.name for tool in filtered_tools]}")

                # Create the agent with callbacks
                agent, shared_state = create_agent_for_plan_mode(
                    filtered_tools, 
                    self.system_prompt, 
                    self.shared_state, 
                    self.agent_callbacks
                )
                
                self.shared_state = shared_state
                self.agent = agent
                self.memory = self.agent.memory if self.agent else None
                
                # Attach the UI handler to the agent
                if self.agent and self.ui_handler:
                    # Clear any previously stored plan file path
                    if hasattr(self.ui_handler, 'set_plan_file_path'):
                        self.ui_handler.set_plan_file_path(None)
                        logger.info("Reset plan file path in UI handler")
                    
                    self.agent.ui_handler = self.ui_handler
                    logger.info("UI handler attached to planning mode agent")
                
                # Log details of the created agent
                if self.agent:
                    if hasattr(self.agent, 'tools'):
                        tool_names = [tool.name for tool in self.agent.tools]
                        logger.info(f"Agent initialized with tools: {tool_names}")
                    else:
                        logger.warning("Agent has no tools attribute")
                
                # Update state machine references
                self.state_machine.set_mode_references(self.agent, self.shared_state, self.ui_handler)
                
                # Register the transition callbacks via the state machine
                self.state_machine.register_callbacks()
                logger.info("Registered transition callbacks via state machine")
                            
            return True
        except Exception as e:
            logger.error(f"Error activating planning mode FSM: {e}")
            return False
    
    def trigger_auto_execution(self) -> Optional[str]:
        """
        Trigger automatic execution of the first step after plan approval.
        This is called by the /start command to start execution immediately.
        
        Returns:
            Optional[str]: The agent's response text if successful,
                          A helpful error message if unsuccessful,
                          None only in critical failure cases
        """
        logger.info("trigger_auto_execution called - beginning diagnostics")
        
        # Validate agent is properly initialized
        if not self.agent:
            logger.warning("Cannot trigger auto-execution: agent is None")
            return "Auto-execution could not start because the agent is not initialized."
            
        # Set the state machine to execution mode with start_command flag
        if hasattr(self, 'state_machine') and self.state_machine:
            try:
                # Get the current plan ID from memory manager if possible
                plan_id = None
                if hasattr(self.state_machine, '_memory_manager'):
                    plan_id = self.state_machine._memory_manager.plan_id
                
                if plan_id and hasattr(self.state_machine, 'handle_mode_transition_from_create_to_exec'):
                    # Call the transition with the start_command flag
                    # This is only for edge cases where transition didn't happen earlier
                    self.state_machine.handle_mode_transition_from_create_to_exec({
                        'plan_id': plan_id,
                        'plan_file': None,  # Will be found by the handler
                        'start_command': True  # Flag indicating this was triggered by /start command
                    })
                    logger.info("Ensured state machine is in execution mode with start_command=True flag")
            except Exception as e:
                logger.error(f"Error transitioning to execution mode: {e}")
            
        try:
            logger.info("Triggering automatic execution start")
            # Call the agent to start executing
            start_message = "Please start executing the plan. Begin with step 1 and return to the user what you did."
            logger.debug(f"Sending message to agent: {start_message}")
            
            # Get the response from the agent
            response = self.agent.get_response(user_message=start_message)
            logger.debug(f"Received response from agent: {type(response).__name__}, {response}")
            
            # Detailed logging of response structure
            if response is None:
                logger.error("Agent returned None response")
                return "Auto-execution received no response from the agent."
                
            # Log all keys in the response
            logger.debug(f"Response keys: {list(response.keys()) if isinstance(response, dict) else 'not a dict'}")
            
            # Check for different response formats and handle accordingly
            # Case 1: Standard success format
            if isinstance(response, dict) and response.get("success") and response.get("content"):
                logger.info("Returning valid response content for CLI to render")
                return response["content"]
                
            # Case 2: Direct string response (agent may not always return dict)
            if isinstance(response, str) and response.strip():
                logger.info("Returning direct string response for CLI to render")
                return response
                
            # Case 3: Simple dict with just text
            if isinstance(response, dict) and isinstance(response.get("text"), str) and response.get("text").strip():
                logger.info("Returning text from response dict for CLI to render")
                return response["text"]
                
            # Case 4: Error message in response
            if isinstance(response, dict) and response.get("error"):
                error_msg = response.get("error")
                logger.warning(f"Agent returned error: {error_msg}")
                return f"Auto-execution encountered an error: {error_msg}"
                
            # Case 5: Unknown but non-empty response structure
            if isinstance(response, dict) and response:
                logger.warning(f"Unknown response structure with keys: {list(response.keys())}")
                # Try to extract any useful text content
                for key in ["content", "message", "response", "output", "result", "text"]:
                    if key in response and isinstance(response[key], str) and response[key].strip():
                        logger.info(f"Found usable content in key '{key}'")
                        return response[key]
            
            # If all extraction attempts failed
            logger.warning(f"Could not extract usable content from response")
            return "Auto-execution did not return usable content. Please start execution manually."
            
        except Exception as e:
            logger.error(f"Error during auto-execution trigger: {e}")
            return f"Auto-execution failed with an error: {str(e)}"  # Return error message instead of None
        
    def on_deactivate(self) -> None:
        """
        Deactivate the Step by Step Mode.

        Each of the three fallible cleanup steps (clear_memory,
        unregister_callbacks, force_cleanup_tools) runs in its own
        try/except block so that a failure in any one of them does not
        prevent the remaining steps from executing. The final assignments
        (agent reset, cleanup flag) are simple and cannot raise.
        """
        logger.info("Deactivating Step by Step Mode")

        # 1. Clear memory — isolated because a Pydantic validation error here
        #    must not abort the rest of the cleanup.
        if self.agent:
            try:
                self.clear_memory()
                logger.info("Cleared memory for fresh execution conversation")
            except Exception:
                logger.exception("Error clearing planning mode memory (continuing cleanup)")

        # 2. Unregister state-machine callbacks.
        try:
            self.state_machine.unregister_callbacks()
            logger.info("Cleared callbacks via state machine")
        except Exception:
            logger.exception("Error unregistering state machine callbacks (continuing cleanup)")

        # 3. Force tool cleanup via the tool manager.
        # Use a separate flag to track actual success: tool_manager being set does not
        # imply that force_cleanup_tools() completed without error.
        tool_manager = None
        tools_cleaned_up = False
        try:
            if self.agent and hasattr(self.agent, 'shared_state') and hasattr(self.agent.shared_state, 'tool_manager'):
                tool_manager = self.agent.shared_state.tool_manager
                force_cleanup_tools(tool_manager=tool_manager, planning_tools=self._enabled_tools)
                tools_cleaned_up = True
        except Exception:
            logger.exception("Error during planning mode tool cleanup (continuing cleanup)")

        # 4. Reset agent — simple assignment, cannot raise.
        if self.agent is not None:
            self.agent = None
            logger.info("Reset planning mode agent")

        # Set a cleanup flag to notify CLI that planning mode tools may need additional cleanup.
        # Based on tools_cleaned_up rather than tool_manager so that a failed force_cleanup_tools()
        # correctly signals the CLI to attempt fallback cleanup.
        self._needs_additional_tool_cleanup = not tools_cleaned_up
        logger.info(f"Planning mode deactivation complete, needs_additional_tool_cleanup: {self._needs_additional_tool_cleanup}")
