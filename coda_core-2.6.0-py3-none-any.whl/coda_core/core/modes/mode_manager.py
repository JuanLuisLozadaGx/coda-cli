from typing import Dict, Optional
from coda_core.core.modes.planning_mode import Mode, PlanningMode
from coda_core.core.modes.main_mode import MainMode
from loguru import logger

class ModeManager:
    """
    Manages different operational modes for the CODA CLIs (coda, coda-api, coda-batch).
    
    The ModeManager allows the user to select and switch between different modes,
    which can modify how the CLI behaves and processes input. Modes can customize
    agent behavior, enabled tools, and system prompts.
    """
    
    def __init__(self) -> None:
        """
        Initialize the ModeManager with default settings.
        """
        # Dictionary to store available modes by their keys
        self._modes: Dict[str, Mode] = {}
        
        # Track the current active mode (if any)
        self._current_mode_key: Optional[str] = None
        
        # Register default modes
        try:
            self.register_mode(PlanningMode())
            self.register_mode(MainMode())
        except Exception as e:  
            logger.error(f"Error registering default mode: {e}")
        
    def register_mode(self, mode: Mode) -> bool:
        """
        Register a new mode with the manager.
        
        Args:
            mode: The Mode instance to register
            
        Returns:
            bool: True if registration was successful, False if the mode key already exists
        """
        if mode.key in self._modes:
            return False
        
        self._modes[mode.key] = mode
        return True
    
    def remove_mode(self, key: str) -> bool:
        """
        Remove a mode from the manager.
        
        Args:
            key: The key of the mode to remove
            
        Returns:
            bool: True if the mode was removed, False if it doesn't exist
        """
        if key not in self._modes:
            return False
        
        # If the current mode is being removed, clear it
        if self._current_mode_key == key:
            self.clear_mode()
        
        del self._modes[key]
        return True
    
    def get_current_mode(self) -> Optional[str]:
        """
        Get the name of the currently active mode.
        
        Note: This always accesses the name property directly to ensure we get the most 
        up-to-date value (important for PlanningMode where the name includes a counter).
        
        Returns:
            Optional[str]: Name of the current mode, or None if no mode is active.
        """
        if not self._current_mode_key:
            return None
        
        mode = self._modes.get(self._current_mode_key)
        # Always get fresh name (not cached) to ensure counter updates are visible
        if mode:
            # Force access to the property to ensure we get current state
            return mode.name
        return None
    
    def get_available_modes(self) -> Dict[str, Dict[str, str]]:
        """
        Get information about all available modes.
        
        Returns:
            Dict[str, Dict[str, str]]: Dictionary mapping mode keys to mode info dictionaries
                                      containing 'name' and 'description'.
        """
        modes_info = {}
        for mode in self._modes.values():
            # Get clean name without state indicators for menu display
            display_name = mode.key
            if hasattr(mode, "_name"):
                display_name = mode._name
            
            modes_info[mode.key] = {
                "name": display_name,
                "description": mode.description
            }
        return modes_info
    
    def get_mode_by_key(self, key: str) -> Optional[Mode]:
        """
        Get a mode instance by its key.
        
        Args:
            key: The key of the mode to retrieve
            
        Returns:
            Optional[Mode]: The mode instance, or None if not found
        """
        return self._modes.get(key)
            
    def get_mode_agent(self):
        """
        Get the agent associated with the current mode, if any.
        Returns:
            The agent instance associated with the current mode, or None if no mode is active or no agent is defined.
        """
        single_agent = None
        if not self._current_mode_key:
            return None
            
        # Use the current mode key directly instead of the mode name
        mode = self._modes.get(self._current_mode_key)
        if not mode:
            return None
            
        try:
            # Try to get agent directly if it exists as a property
            if hasattr(mode, 'agent'):
                single_agent = mode.agent
            # Fall back to old pattern if needed
            elif hasattr(mode, 'mode_single_agent') and hasattr(mode.mode_single_agent, 'agent'):
                single_agent = mode.mode_single_agent.agent
        except Exception as e:
            logger.error(f"Error retrieving mode agent: {e}")
        return single_agent
    
    def select_mode(self, mode_key: str) -> bool:
        """
        Set the current mode to the specified key and handle its activation.

        If a mode is already active, it is deactivated via clear_mode() before
        the new mode is activated. Using clear_mode() guarantees that
        _current_mode_key is always cleared even if on_deactivate() raises,
        preventing the manager from getting stuck on the old mode key.
        
        Args:
            mode_key (str): The key of the mode to set as current.
            
        Returns:
            bool: True if mode was successfully set, False otherwise.
        """
        if mode_key in self._modes:
            # Deactivate current mode if there is one, using clear_mode() so
            # any exception in on_deactivate() is handled and the key is
            # always cleared before activating the new mode.
            if self._current_mode_key:
                self.clear_mode()
            
            # Get the mode instance
            mode = self._modes[mode_key]
            
            if mode is not None:
                # Call on_activate to set up any mode-specific state
                success = mode.on_activate()
                if not success:
                    logger.warning(f"Failed to activate mode '{mode_key}'")
                    self._current_mode_key = None
                    return False
            else:
                logger.error(f"Mode instance for key '{mode_key}' is None")
                return True
            
            # Set new mode key (only after successful activation)
            self._current_mode_key = mode_key
            logger.info(f"Successfully activated mode: {mode.name}")
            
            return True
        return False
    
    def clear_mode(self) -> None:
        """
        Clear the current mode, deactivating it if necessary.

        The key is guaranteed to be set to None regardless of whether
        on_deactivate() succeeds or raises, so the manager never ends up
        in an inconsistent state.
        """
        if self._current_mode_key and self._current_mode_key in self._modes:
            current_mode = self._modes[self._current_mode_key]
            try:
                current_mode.on_deactivate()
            except Exception:
                logger.exception("Error during mode deactivation (continuing cleanup)")
            finally:
                self._current_mode_key = None
        else:
            self._current_mode_key = None
