# Modes Module Documentation

The Modes Module in CODA Core provides a flexible architecture for extending and customizing agent behavior through different operational modes. Each mode can tailor the agent's capabilities, tools, and system prompts to support specific use cases.

## Architecture Overview

```mermaid
graph TD
    A[ModeManager] --> B[Mode ABC]
    B --> C[PlanningMode]
    B --> D[Future Modes...]
    
    A -- manages --> E[Current Mode]
    E -- has --> F[Tools]
    E -- has --> G[System Prompt]
    E -- has --> H[Callbacks]
    
    A -- provides --> I[Mode Registry]
    A -- handles --> J[Mode Transitions]
```

## Core Components

### Mode (Abstract Base Class)

The `Mode` class is the foundation of the modes system, defining the interface that all modes must implement:

```mermaid
classDiagram
    class Mode {
        <<abstract>>
        +key: str
        +name: str
        +description: str
        +system_prompt: str
        +get_prompt_additions(): Dict
        +get_enabled_tools(): List[str]
        +get_tool_dependencies(): Dict
        +on_activate(): bool
        +on_deactivate(): void
    }
```

Key characteristics of the `Mode` abstract class:
- **Unique Identifier**: Each mode has a unique key for identification
- **Human-Readable Information**: Name and description for user interfaces
- **Prompt Customization**: Controls the system prompt template and additions
- **Tool Management**: Specifies which tools should be enabled and their dependencies
- **Lifecycle Hooks**: Methods for setup and teardown when a mode is activated or deactivated

### ModeManager

The `ModeManager` is responsible for registering, activating, and managing different modes:

```mermaid
classDiagram
    class ModeManager {
        -_modes: Dict[str, Mode]
        -_current_mode_key: Optional[str]
        +register_mode(mode: Mode): bool
        +remove_mode(key: str): bool
        +get_current_mode(): Optional[str]
        +get_available_modes(): Dict
        +get_mode_by_key(key: str): Optional[Mode]
        +select_mode(mode_key: str): bool
        +clear_mode(): void
    }
```

Key responsibilities:
- **Mode Registry**: Maintains a collection of available modes
- **Mode Selection**: Handles activation and deactivation of modes
- **Current Mode Tracking**: Keeps track of which mode is currently active
- **Mode Information**: Provides access to information about available modes

## Mode Lifecycle

```mermaid
sequenceDiagram
    participant CLI
    participant ModeManager
    participant OldMode
    participant NewMode
    participant ToolManager
    
    CLI->>ModeManager: select_mode("new_mode_key")
    ModeManager->>OldMode: on_deactivate()
    OldMode->>ToolManager: disable_tools()
    ModeManager->>NewMode: on_activate()
    NewMode->>ToolManager: register_tool_dependencies()
    NewMode->>ToolManager: enable_tools()
    NewMode-->>ModeManager: return success
    ModeManager-->>CLI: return result
```

When a mode is activated:
1. The current mode (if any) is deactivated, cleaning up resources
2. The new mode's `on_activate()` method is called to:
   - Register any mode-specific tools
   - Set up tool dependencies
   - Enable required tools
   - Configure the agent if needed
3. The new mode becomes the current active mode

When a mode is deactivated:
1. The `on_deactivate()` method is called to:
   - Clean up any resources used by the mode
   - Disable mode-specific tools

## Plan Mode Implementation

The Plan Mode is a specialized mode that supports structured task planning and execution through a finite state machine approach.

### States and Transitions

```mermaid
stateDiagram-v2
    [*] --> PLANNING_MODE
    PLANNING_MODE --> EXECUTION_MODE: approve_plan
    PLANNING_MODE --> EXECUTION_MODE: load_plan
    EXECUTION_MODE --> PLANNING_MODE: mark_plan_as_pending
    EXECUTION_MODE --> [*]: complete all steps
```

The Plan Mode is implemented as a Finite State Machine with two states:
- **PLANNING_MODE**: Enables tools for creating, reviewing, and approving plans
- **EXECUTION_MODE**: Enables tools for executing plan steps and tracking progress

### Key Components

The Plan Mode architecture now has a fully implemented state machine:

```mermaid
graph TD
    A[PlanningMode] --> B[PlanningModeStateMachine]
    A --> C[Tool Management]
    A --> D[Agent Configuration]
    A --> E[Memory Management]
    
    B --> F[State Transitions]
    B --> G[Callback Registration]
    
    C --> H[Creation Tools]
    C --> I[Execution Tools]
    
    E --> J[PlanMemoryManager]
```

#### Tool Separation

Plan Mode carefully manages two distinct sets of tools:

1. **Creation Tools**:
   - `create_plan_tool`: For creating a new structured plan
   - `update_plan_tool`: For modifying an existing plan
   - `approve_plan_tool`: For approving a plan and transitioning to execution
   - `load_plan_tool`: For loading an existing approved plan and transitioning to execution

2. **Execution Tools**:
   - `mark_step_tool`: For marking steps as completed or pending
   - `mark_plan_as_pending_tool`: For returning to Plan Mode
   - Core editing tools: `edit`, `view`, `bash`

The state machine dynamically swaps these tool sets during state transitions.

#### State Machine Architecture

The state machine manages transitions and tool activation:

```mermaid
sequenceDiagram
    participant Agent
    participant Tools
    participant StateMachine as PlanningModeStateMachine
    participant MemManager as PlanMemoryManager
    
    Agent->>Tools: Call approve_plan_tool
    Tools->>StateMachine: handle_mode_transition_from_create_to_exec()
    StateMachine->>StateMachine: set_state(EXECUTION_MODE)
    StateMachine->>StateMachine: handle_execution_tools_activation()
    StateMachine->>MemManager: set_plan_id(plan_id)
    StateMachine->>MemManager: register_callbacks(agent)
    StateMachine->>Agent: Update agent's tools
    Tools-->>Agent: Return result
```

#### Memory Optimization

During plan execution, the system includes sophisticated memory management:
1. Tracks tool usage during step execution
2. Cleans memory after step completion
3. Creates reduced context with essential information
4. Maintains OpenAI message format compliance

### Plan Structure

Plans created in Plan Mode follow a structured schema:

```mermaid
classDiagram
    class Plan {
        +plan_id: str
        +title: str
        +description: str
        +steps: List[Step]
        +created_at: str
        +updated_at: str
    }
    
    class Step {
        +number: int
        +title: str
        +description: str
        +status: str
    }
    
    Plan "1" *-- "many" Step
```

### Utilities and Support Functions

The Plan Mode is supported by several utility functions:
- `create_agent_for_plan_mode`: Creates a properly configured agent for the current state
- `force_cleanup_tools`: Ensures tools are properly cleaned up during deactivation
- `unfold_plan_context`: Formats plan data as readable text for context

## Implementing a New Mode

To create a new mode:

1. Extend the `Mode` abstract base class
2. Implement the required abstract methods:
   - `key`, `name`, `description` properties
   - `on_activate()` and `on_deactivate()` methods
3. Optionally override:
   - `system_prompt` to customize the agent's prompt
   - `get_prompt_additions()` to add specific content to the prompt
   - `get_enabled_tools()` to specify which tools should be enabled
   - `get_tool_dependencies()` to register dependencies for tools
4. Register the mode with the `ModeManager`

Example:
```python
class MyCustomMode(Mode):
    @property
    def key(self) -> str:
        return "my_custom_mode"
    
    @property
    def name(self) -> str:
        return "My Custom Mode"
    
    @property
    def description(self) -> str:
        return "Description of what my custom mode does"
    
    def on_activate(self) -> bool:
        # Setup code here
        return True
    
    def on_deactivate(self) -> None:
        # Cleanup code here
        pass
```

## Current Enhancements 

The Plan Mode system has received significant enhancements:

- **Fully Implemented State Machine**: Replaced the placeholder FSM with a comprehensive `PlanningModeStateMachine`
- **Memory Management**: Added the `PlanMemoryManager` to optimize context and track tool usage
- **Callback Architecture**: Implemented a robust callback system for transitions and memory cleaning
- **OpenAI Message Compliance**: Ensured all memory operations maintain proper message structure