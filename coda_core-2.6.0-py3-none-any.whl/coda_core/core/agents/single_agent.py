from typing import Callable, Dict, List, Any, Optional
import json
import time
from pathlib import Path
from loguru import logger
from coda_core.core.utils.backoff import compute_exponential_base_delay, apply_equal_jitter

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig 
from coda_core.core.agents.types import MemoryOperationKind, MessageRole, ErrorRecoveryStrategy, MemoryErrorStrategy, StopReasonCode
from coda_core.core.agents.constants import (
    CODA_SYSTEM_MESSAGE_PREFIX,
    MAX_ITERATIONS_EXPLANATION_MESSAGE,
    MAX_ITERATIONS_EXPLANATION_MESSAGE,
    MAX_ITERATIONS_EXPLANATION_MESSAGE,
    OMNI_PARSER_MEDIA_EXTENSIONS,
    OMNI_PARSER_DOC_EXTENSIONS,
    GUIDANCE_INJECTION_LOG_TRUNCATE_LENGTH
)
from coda_core.core.agents.base_agent import BaseAgent
from coda_core.core.models.errors.types import LLMErrorAction
from coda_core.config.context.schemas import WorkspaceContext
from coda_core.core.models.llms.chat import ChatLLM
from coda_core.core.tools.function_tool import FunctionTool
from coda_core.core.models.providers.responses_api.response_schemas import ResponseObject
from coda_core.core.models.providers.responses_api.item_schemas import Reasoning as ResponseReasoning
from coda_core.core.models.providers.responses_api.item_schemas import FunctionToolCall as ResponseToolCall
from coda_core.core.models.providers.responses_api.item_schemas import UnknownItem as ResponseUnknownItem
from coda_core.core.models.providers.responses_api.enums import ResponseStatus
from coda_core.core.memories.base import Memory
from coda_core.core.tools.bash.risk_assessment import assess_command_risk
from coda_core.core.utils.prompt_management import create_system_prompt, create_agent_prompt
from coda_core.core.mcp.service import MCPService
from coda_core.core.models.errors.detection import classify_llm_error
from coda_core.core.models.errors.exceptions import LLMPlatformError
from coda_core.core.models.errors.constants import (
    ERROR_RECOVERY_MAX_RETRIES,
    ERROR_RECOVERY_MEMORY_REDUCTION_PERCENTAGE,
    ERROR_RECOVERY_BACKOFF_BASE_DELAY,
    ERROR_RECOVERY_BACKOFF_MAX_DELAY,
    ERROR_RECOVERY_BACKOFF_MAX_MULTIPLIER,
    ERROR_RECOVERY_BACKOFF_JITTER_FACTOR
)
from coda_core.core.memories.errors.exceptions import MemoryCapacityError
from coda_core.core.memories.errors.types import MemoryAssessmentAction, MemoryErrorCategory
from coda_core.core.agents.handlers import (
    handle_condense_suggestion,
    handle_insufficient_capacity,
    handle_oversized_message,
    handle_unknown_action
)
from coda_core.core.utils.constants import MAIN_AGENT_PROMPT_TEMPLATE

class SingleAgent(BaseAgent):
    """
    A single agent that uses an LLM to process user messages and generate responses.
    """

    def __init__(
        self,
        llm: ChatLLM,
        tools: List[FunctionTool],
        tool_choice: str = 'auto',
        memory: Optional[Memory] = None,
        max_iterations: Optional[int] = None,
        agent_prompt: Optional[str] = None
    ) -> None:
        """
        Initializes the SingleAgent with a language model and optional tools.

        Args:
            llm (ChatLLM): The language model to be used by the agent.
            tools (List[FunctionTool]): A list of tools that the agent can use.
            tool_choice (str, optional): The strategy for selecting tools. Defaults to 'auto'.
            memory (Memory, optional): A Memory instance for storing conversation history. Defaults to None.
            max_iterations (int, optional): The maximum number of iterations for processing. Defaults to 60 and is set via the CODA_SINGLE_AGENT_MAX_ITERATIONS environment variable.
            agent_prompt (str, optional): The agent-specific prompt (custom instructions). Defaults to None.
        """
        super().__init__(llm, tools, memory)
        self.tool_choice = tool_choice
        self.max_iterations = (
            max_iterations
            if max_iterations is not None
            else int(SETTINGS.get_env_var(EnvConfig.CODA_SINGLE_AGENT_MAX_ITERATIONS))
        )
        self.agent_prompt = agent_prompt

        # Log the initialization details
        logger.info(
            f"Initializing SingleAgent with LLM '{self.llm.model.full_name}' "
            f"and Tools: {', '.join([tool.name for tool in tools])}"
        )

    def get_response(self, user_message: str, callbacks: Dict[str, Callable] = None, optional: Any = None, metadata_param: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Generate a response for a user message with tool + recovery handling.
        Now supports memory management and custom UI handlers through callbacks.

        This executes an iterative loop:
          1. Stores user input.
          2. Optionally condenses memory.
          3. Calls the LLM (with retry + recovery strategies).
          4. Parses tool calls (if any) and executes them.
          5. Persists tool results and regenerates if guided.
          6. Returns final assistant response when no tools remain.
        
        Args:
            user_message (str): The message from the user.
            callbacks (Dict[str, Callable], optional): Dictionary of callback functions for different events.
                Supported callbacks:
                - on_start(user_message): Called at the start of processing
                - on_llm_start(): Called before sending request to LLM
                - on_llm_response(llm_response): Called when raw LLM response is received
                - on_llm_parsed(content, tool_calls, metadata): Called after parsing the response
                - on_tool_call(tool_name, tool_args): Called before a tool is executed
                - on_tool_result(tool_name, success, result): Called after a tool returns
                - on_max_iterations(last_message): Called when max iterations is reached
                - on_complete(success, content, metadata): Called when processing is complete
                - on_bash_risk_assessment(command, risk_assessment): Called for bash command risk assessment
                - on_ask_user(question, suggestions): Called for ask_user tool to get user response
                - on_memory_condensing_start(message): Called when memory condensing starts
                - on_memory_condensing_end(result): Called when memory condensing completes or is skipped
                  The result parameter contains metadata with LLM usage, condensing statistics,
                  and a "skipped" flag with reason if condensing was skipped
                - on_error_recovery_start(error, attempt): Called when error recovery starts
                - on_error_recovery_end(success, strategy, details): Called when error recovery completes

                Bash streaming callbacks (runtime-only):
                These callbacks enable streaming output for the bash tool. They are injected by the runtime.
                They may be called frequently while the subprocess is running.

                - on_bash_stdout_line(line: str): Called for each stdout line produced by the bash process
                - on_bash_stderr_line(line: str): Called for each stderr line produced by the bash process
                - on_bash_heartbeat(elapsed_ms: int): Called periodically when the process is quiet

            optional (Any): Reserved for future extension metadata.
            metadata_param (Optional[Dict[str, Any]]): Optional metadata dictionary to pass to the LLM.
                If provided and CODA_SEND_METADATA=True, this metadata will be included in LLM calls.
                
        Returns:
            Dict[str, Any]: Result payload:
                success (bool): Whether a final assistant reply was produced.
                content (str, optional): Assistant reply (on success).
                metadata (dict, optional): LLM usage / model metadata.
                error (str, optional): Error description on failure.
        """
        # Initialize empty callbacks dict if None provided
        callbacks = callbacks or {}
        
        # UI wiring: leverage optional self.ui_handler to provide default lifecycle printing callbacks.
        # Keeps core orchestration decoupled from presentation; explicit callbacks still take precedence.
        # If no UI handler or explicit callbacks are present, execution proceeds silently.
        # Check for custom UI handler in shared state or as an attribute
        ui_handler = None
        if hasattr(self, 'ui_handler') and self.ui_handler:
            ui_handler = self.ui_handler
        
        # If we have a custom UI handler, override the default UI callbacks
        if ui_handler:
            # Override tool call callback if not already provided
            if "on_tool_call" not in callbacks:
                callbacks["on_tool_call"] = lambda tool_name, tool_args: ui_handler.print_tool_call(tool_name, tool_args)
            
            # Override tool result callback if not already provided
            if "on_tool_result" not in callbacks:
                callbacks["on_tool_result"] = lambda tool_name, success, result: ui_handler.print_tool_result(tool_name, success, result)
        try:
            # Notify start
            if "on_start" in callbacks:
                callbacks["on_start"](user_message)

            # Setup LLM parameters and kwargs
            llm_kwargs = {}

            # Tool routing: expose available tool schemas and selection policy to the LLM
            # Rationale: model-side planner decides whether and which tools to call based on these.
            tool_definitions = [tool.tool_definition for tool in self.tools]
            llm_kwargs['tools'] = tool_definitions
            llm_kwargs['tool_choice'] = self.tool_choice

            # Handle metadata if enabled and provided
            if metadata_param is not None and SETTINGS.get_env_var(EnvConfig.CODA_SEND_METADATA).lower() == 'true':
                # Use the metadata dictionary directly (already transformed by extract_metadata)
                llm_kwargs['metadata'] = metadata_param


            # Setup message history
            # Persist user message first
            # Any failure here is fatal; we cannot proceed without a consistent conversation state.
            store_result = self._safe_store(MemoryOperationKind.USER_INPUT.value, self.memory.add_user_message, user_message)
            if not store_result["success"]:
                return {"success": False, "error": store_result["error"]}
            
            # Capacity management: proactively condense history to stay within model/memory token limits
            # Emits on_memory_condensing_* callbacks; may no-op if condensing is not required.
            # Check if memory has a condenser attached
            if self.memory.condenser is not None:
                # Set up callbacks for the condenser
                condenser_callbacks = {
                    name: callbacks[name]
                    for name in ['on_memory_condensing_start', 'on_memory_condensing_end']
                    if name in callbacks
                }
                
                # Update the condenser's callbacks
                self.memory.condenser.callbacks = condenser_callbacks
                    
                # Check and perform memory condensing if needed
                # Pass the same metadata dictionary that was passed to get_response
                self.memory.check_and_condense(metadata=metadata_param)
                
            
            # For loop until max_iterations
            # Main orchestration loop: iterate until final assistant reply or max_iterations is reached
            for iteration in range(self.max_iterations):
                logger.info(f"Iteration {iteration + 1}/{self.max_iterations}: Processing user message.")
                
                # Send message to LLM with error recovery
                llm_response = None
                
                # LLM request with bounded retries. On exception: classify and recover via _attempt_error_recovery,
                # potentially adjusting memory/prompt and backing off before retrying.
                for retry_attempt in range(ERROR_RECOVERY_MAX_RETRIES + 1):  # +1 for initial attempt
                    # Notify LLM request start (for each attempt)
                    if 'on_llm_start' in callbacks:
                        callbacks['on_llm_start']()

                    try:
                        llm_response = self.llm.generate_response(
                            messages=self.memory.retrieve(),
                            **llm_kwargs
                        )
                        # Success - notify response received and exit retry loop
                        if "on_llm_response" in callbacks:
                            callbacks["on_llm_response"](llm_response)
                        break
                        
                    except Exception as llm_error:
                        if retry_attempt < ERROR_RECOVERY_MAX_RETRIES:
                            # Notify error recovery start
                            if "on_error_recovery_start" in callbacks:
                                callbacks["on_error_recovery_start"](llm_error, retry_attempt + 1)
                            
                            # Attempt error recovery
                            recovery_result = self._attempt_error_recovery(llm_error, iteration)
                            
                            # Notify error recovery end
                            if "on_error_recovery_end" in callbacks:
                                callbacks["on_error_recovery_end"](
                                    recovery_result["success"],
                                    recovery_result.get("strategy"),
                                    recovery_result
                                )
                            
                            if recovery_result["success"]:
                                strategy = recovery_result.get("strategy", "unknown")
                                logger.info(f"Error recovery successful: {strategy} (retry {retry_attempt + 1}/{ERROR_RECOVERY_MAX_RETRIES})")
                                # Continue to next retry attempt
                                continue
                            else:
                                logger.error(f"Error recovery failed: {recovery_result.get('reason', 'Unknown reason')}")
                                # Re-raise the original error to be handled by outer exception handler
                                raise llm_error
                        else:
                            # No more retries left
                            logger.error(f"LLM call failed after {ERROR_RECOVERY_MAX_RETRIES} recovery attempts")
                            raise llm_error

                # Validate the model's stop condition before proceeding with parsing
                # Check the stop reason
                stop_reason_result = self._get_stop_reason(llm_response)
                if not stop_reason_result["success"]:
                    error_obj = stop_reason_result.get("error", {})
                    logger.error(f"Error in stop reason ({error_obj.get('code')}): {error_obj.get('message')}")
                    
                    # For recoverable finish reasons, inject orchestration guidance and regenerate
                    if stop_reason_result.get("recoverable"):
                        guidance_text = stop_reason_result.get("guidance")
                        if guidance_text:
                            self._inject_guidance(text=guidance_text)
                        # Skip further processing this iteration to allow regeneration
                        continue
                    # Maintain consistency: return string error messages from get_response()
                    return {"success": False, "error": error_obj.get("message")}

                # Parse the raw LLM response into content/tool_calls/metadata. Abort on malformed output.
                # Parse LLM response
                parsed_response = self._parse_llm_response(llm_response)
                if "error" in parsed_response:
                    logger.error(f"Error in LLM response: {parsed_response['error']}")
                    return {"success": False, "error": parsed_response["error"]}
                
                logger.success(f"Received LLM response!")

                # Unpack parsed response
                assistant_message = parsed_response.get("content")
                tool_calls = parsed_response.get("tool_calls")
                metadata = parsed_response.get("metadata")
                reasoning_items = self._extract_reasoning_items(llm_response)
                unknown_items = self._extract_unknown_items(llm_response)

                # Notify LLM response parsed
                # Observability: surface structured content/tool_calls/metadata to UI/logging layers.
                if "on_llm_parsed" in callbacks:
                    callbacks["on_llm_parsed"](assistant_message, tool_calls, metadata)

                # Usage metrics emitted for cost/latency tracking
                logger.info(f"Usage: {metadata.get('usage')}")

                # Persist the assistant turn first, then persist any side-channel reasoning/unknown items once.
                if tool_calls:
                    store_result = self._safe_store(
                        MemoryOperationKind.ASSISTANT_REPLY,
                        self.memory.add_assistant_message,
                        message=assistant_message,
                        tool_calls=tool_calls,
                    )
                    if not store_result["success"]:
                        # For assistant storage failures, continue loop to allow regeneration
                        # No guidance injection here; we re-query hoping the model produces a smaller or structured reply that stores cleanly.
                        logger.warning(f"Assistant reply storage failed, continuing loop for regeneration: {store_result['error']}")
                        continue
                else:
                    store_result = self._safe_store(
                        MemoryOperationKind.ASSISTANT_FINAL,
                        self.memory.add_assistant_message,
                        assistant_message,
                    )
                    if not store_result["success"]:
                        # For assistant storage failures, continue loop to allow regeneration
                        logger.warning(f"Assistant final storage failed, continuing loop for regeneration: {store_result['error']}")
                        continue

                self._store_reasoning_items(reasoning_items)
                self._store_unknown_items(unknown_items)

                # Tool phase: assistant tool-call message is already persisted, then tools run sequentially.
                if tool_calls:
                    restart_iteration = False       # Flag to indicate if we should restart the iteration after handling tools

                    # Process each tool call
                    for tool_call in tool_calls:
                        tool_name = tool_call.get("tool_name")
                        tool_args = tool_call.get("tool_args")

                        is_bash_tool_call = tool_name == "bash"

                        if metadata_param and SETTINGS.get_env_var(EnvConfig.CODA_SEND_METADATA).lower() == 'true':
                            tool_args['metadata'] = metadata_param
                            
                        # Notify tool call
                        if "on_tool_call" in callbacks:
                            callbacks["on_tool_call"](tool_name, tool_args)
                        
                        # Check if the tool is available
                        if tool_name in [tool.name for tool in self.tools]:
                            # Security gate: evaluate shell command risk and allow UI to veto execution
                            # Check for bash commands
                            if is_bash_tool_call and "command" in tool_args:
                                command = tool_args["command"]
                                
                                # Get risk assessment
                                risk_assessment = self._assess_bash_command_risk(command)
                                
                                # Check if bash risk assessment callback is registered
                                if "on_bash_risk_assessment" in callbacks:
                                    # Call the risk assessment callback
                                    proceed = callbacks["on_bash_risk_assessment"](command, risk_assessment)
                                    
                                    # If callback returns False, skip execution
                                    if not proceed:
                                        logger.warning(f"Bash command execution denied by user due to security risk: {command}")
                                        
                                        # Check if ask_user tool is available
                                        ask_user_available = any(tool.name == "ask_user" for tool in self.tools)
                                        base_message = "Command execution denied by user due to security risk."
                                        
                                        if ask_user_available:
                                            alternative_message = " Use the ask_user tool to understand what they want to do."
                                        else:
                                            alternative_message = " Try a different command."
                                        
                                        error_response = {
                                            "status": "error",
                                            "message": base_message + alternative_message,
                                            "risk_assessment": risk_assessment
                                        }
                                        store_result = self._safe_store(MemoryOperationKind.TOOL_ERROR,
                                                                        self.memory.add_tool_message,
                                                                        tool_call=tool_call,
                                                                        tool_response=error_response)
                                        if not store_result["success"]:
                                            try:
                                                self.memory.resolve_orphaned_tool_calls(
                                                    error_message=f"Tool '{tool_name}' storage failed: {store_result.get('error', 'Unknown error')}"
                                                )
                                            except Exception:
                                                pass
                                            return {"success": False, "error": store_result["error"]}
                                        continue
                            

                            # Check for ask_user tool
                            if tool_name == "ask_user" and "question" in tool_args and "suggestions" in tool_args:
                                question = tool_args["question"]
                                suggestions = tool_args["suggestions"]
                                
                                logger.info(f"Detected ask_user tool call")
                                
                                # Check if ask_user callback is registered
                                if "on_ask_user" in callbacks:
                                    # Call the callback and get the user's response
                                    user_response = callbacks["on_ask_user"](question, suggestions)
                                    logger.info(f"Received user response")
                                    
                                    # Return the user's response as the tool result
                                    success_response = {
                                        "status": "success",
                                        "user_response": user_response
                                    }
                                    store_result = self._safe_store(MemoryOperationKind.TOOL_SUCCESS,
                                                                    self.memory.add_tool_message,
                                                                    tool_call=tool_call,
                                                                    tool_response=success_response)
                                    if not store_result["success"]:
                                        try:
                                            self.memory.resolve_orphaned_tool_calls(
                                                error_message=f"Tool '{tool_name}' storage failed: {store_result.get('error', 'Unknown error')}"
                                            )
                                        except Exception as e:
                                            logger.warning(f"Failed to resolve orphaned tool calls (TOOL_SUCCESS for '{tool_name}'): {e}")
                                        return {"success": False, "error": store_result["error"]}
                                    continue
                            
                            # Omni-parser preflight check for large files to prevent accidental high costs
                            if tool_name == "omni_parser" and "file_path" in tool_args:
                                file_path_str = tool_args.get("file_path")
                                try:
                                    if file_path_str:
                                        file_path = Path(file_path_str)
                                        if file_path.is_absolute() and file_path.is_file():
                                            size_bytes = file_path.stat().st_size
                                            max_doc_mb = int(SETTINGS.get_env_var(EnvConfig.CODA_OMNI_PARSER_MAX_DOC_FILE_SIZE_MB))
                                            max_media_mb = int(SETTINGS.get_env_var(EnvConfig.CODA_OMNI_PARSER_MAX_MEDIA_FILE_SIZE_MB))
                                            hard_max_mb = int(SETTINGS.get_env_var(EnvConfig.CODA_OMNI_PARSER_HARD_MAX_FILE_SIZE_MB))

                                            size_mb = size_bytes / (1024 * 1024)
                                            ext = file_path.suffix.lower()
                                            category = "media" if ext in OMNI_PARSER_MEDIA_EXTENSIONS else ("doc" if ext in OMNI_PARSER_DOC_EXTENSIONS else "doc")
                                            threshold_mb = max_media_mb if category == "media" else max_doc_mb

                                            if size_mb > hard_max_mb:
                                                logger.warning(f"omni_parser preflight: file size {size_mb:.2f}MB exceeds hard max {hard_max_mb}MB")
                                                error_response = {
                                                    "status": "error",
                                                    "message": (
                                                        f"File is too large to upload ({size_mb:.2f} MB > hard max {hard_max_mb} MB). "
                                                        "Narrow pages (startPage/endPage), reduce media length, or adjust CODA_OMNI_PARSER_HARD_MAX_FILE_SIZE_MB."
                                                    ),
                                                    "file": str(file_path),
                                                    "size_mb": round(size_mb, 2),
                                                    "limits_mb": {"hard_max": hard_max_mb, "category_max": threshold_mb, "category": category}
                                                }
                                                store_result = self._safe_store(MemoryOperationKind.TOOL_ERROR,
                                                                                self.memory.add_tool_message,
                                                                                tool_call=tool_call,
                                                                                tool_response=error_response)
                                                if not store_result["success"]:
                                                    return {"success": False, "error": store_result["error"]}
                                                continue

                                            if size_mb > threshold_mb:
                                                logger.info(f"omni_parser preflight limit exceeded: {size_mb:.2f}MB > {threshold_mb}MB for {category}")
                                                cb = callbacks.get("on_omni_parser_preflight")
                                                context = {
                                                    "category": category,
                                                    "extension": ext,
                                                    "size_mb": round(size_mb, 2),
                                                    "threshold_mb": threshold_mb,
                                                    "hard_max_mb": hard_max_mb,
                                                    "hiResMode": tool_args.get("hiResMode", False),
                                                    "structure": tool_args.get("structure"),
                                                    "dialogue": tool_args.get("dialogue"),
                                                    "outputFormat": tool_args.get("outputFormat"),
                                                }
                                                proceed = False
                                                if cb:
                                                    try:
                                                        proceed = bool(cb(file_path, int(size_bytes), context))
                                                    except Exception as e:
                                                        logger.error(f"omni_parser preflight callback error: {e}")

                                                if not proceed:
                                                    error_response = {
                                                        "status": "error",
                                                        "message": (
                                                            f"Upload canceled due to file size ({size_mb:.2f} MB > {threshold_mb} MB). "
                                                            "Consider narrowing pages (startPage/endPage), disabling hiResMode, or reducing media length."
                                                        ),
                                                        "file": file_path,
                                                        "size_mb": round(size_mb, 2),
                                                        "limits_mb": {"hard_max": hard_max_mb, "category_max": threshold_mb, "category": category}
                                                    }
                                                    store_result = self._safe_store(MemoryOperationKind.TOOL_ERROR,
                                                                                    self.memory.add_tool_message,
                                                                                    tool_call=tool_call,
                                                                                    tool_response=error_response)
                                                    if not store_result["success"]:
                                                        return {"success": False, "error": store_result["error"]}
                                                    continue
                                except Exception as e:
                                    logger.warning(f"omni_parser preflight skipped due to file stat error: {e}")

                            # Execute the tool.
                            # For bash, inject runtime-only streaming callbacks
                            runtime_kwargs: Optional[Dict[str, Any]] = None
                            if is_bash_tool_call:
                                runtime_kwargs = {
                                    "on_stdout_line": callbacks.get("on_bash_stdout_line"),
                                    "on_stderr_line": callbacks.get("on_bash_stderr_line"),
                                    "on_heartbeat": callbacks.get("on_bash_heartbeat"),
                                }
                                runtime_kwargs = {key: value for key, value in runtime_kwargs.items() if value is not None}

                            logger.info(f"Calling tool: '{tool_name}' with arguments: {tool_args}")
                            tool_response = self._call_tool(tool_name=tool_name, tool_args=tool_args, runtime_kwargs=runtime_kwargs)

                            # Notify tool result
                            if "on_tool_result" in callbacks:
                                # Pass response or error based on success status
                                if tool_response['success']:
                                    callbacks["on_tool_result"](tool_name, tool_response['success'], tool_response['response'])
                                else:
                                    callbacks["on_tool_result"](tool_name, tool_response['success'], tool_response['error'])

                            # Check if the tool response is valid
                            if tool_response['success']:
                                # Update message history with the serialized tool response - handle memory capacity errors
                                store_result = self._safe_store(MemoryOperationKind.TOOL_RESPONSE,
                                                                self.memory.add_tool_message,
                                                                tool_call=tool_call,
                                                                tool_response=tool_response["response"])
                                if not store_result["success"]:
                                    # Heuristic: storage failure often indicates capacity issues; when true, a guidance
                                    # message was injected and we restart this iteration to let the model regenerate.
                                    if self._should_continue_after_failure(store_result, MemoryOperationKind.TOOL_RESPONSE.value):
                                            logger.info("Guidance injected for tool_response; restarting iteration for regeneration.")
                                            restart_iteration = True
                                            break
                                    try:
                                        self.memory.resolve_orphaned_tool_calls(
                                            error_message=f"Tool '{tool_name}' storage failed: {store_result.get('error', 'Unknown error')}"
                                        )
                                    except Exception as e:
                                        logger.warning(f"Failed to resolve orphaned tool calls (TOOL_RESPONSE for '{tool_name}'): {e}")
                                    return {"success": False, "error": store_result["error"]}

                                # If bash surfaced interactive prompt detection, inject concise guidance and restart
                                resp_data = tool_response.get("response", {})
                                if tool_name == "bash" and isinstance(resp_data, dict) and resp_data.get("prompt_excerpt"):
                                    excerpt = str(resp_data.get("prompt_excerpt") or "")
                                    guidance_text = (
                                        f"Interactive prompt detected in previous bash command: {excerpt}. "
                                        "Regenerate a non-interactive command that avoids prompts by adding appropriate flags "
                                        "(e.g., -y/--yes, --non-interactive, --noconfirm), explicitly specifying overwrite/selection when safe, "
                                        "and avoiding editors or interactive UIs. Respond with a single bash tool call only."
                                    )
                                    self._inject_guidance(
                                        guidance_text,
                                        has_tool_calls=False,
                                        strategy="prompt_detected",
                                        kind=MemoryOperationKind.TOOL_RESPONSE
                                    )
                                    # Restart iteration for regeneration after injecting guidance
                                    restart_iteration = True
                                    break

                            else:
                                # Add to memory, format the message and continue with next tool call
                                logger.warning(f"Error in tool '{tool_name}': {tool_response['error']}")
                                error_response = {
                                    "status": "error",
                                    "message": tool_response["error"]
                                }
                                store_result = self._safe_store(MemoryOperationKind.TOOL_ERROR, 
                                                                self.memory.add_tool_message,
                                                                tool_call=tool_call, 
                                                                tool_response=error_response)
                                if not store_result["success"]:
                                    # Same heuristic as above for error paths: prefer regeneration after guidance injection.
                                    if self._should_continue_after_failure(store_result, MemoryOperationKind.TOOL_ERROR.value):
                                        logger.info("Guidance injected for tool_error; restarting iteration for regeneration.")
                                        restart_iteration = True
                                        break
                                    try:
                                        self.memory.resolve_orphaned_tool_calls(
                                            error_message=f"Tool '{tool_name}' storage failed: {store_result.get('error', 'Unknown error')}"
                                        )
                                    except Exception as e:
                                        logger.warning(f"Failed to resolve orphaned tool calls (TOOL_ERROR for '{tool_name}'): {e}")
                                    return {"success": False, "error": store_result["error"]}
                                continue
                        else:
                            logger.warning(f"Tool '{tool_name}' is not available")
                            
                            # List available tools for guidance
                            available_tools = [t.name for t in self.tools]
                            tool_list = ", ".join(available_tools) if available_tools else "none"

                            # Resolve orphaned tool calls to maintain message history consistency
                            error_message = f"Tool '{tool_name}' is not available. Use only available tools: {tool_list}."
                            resolved_count = self.memory.resolve_orphaned_tool_calls(
                                error_message=error_message
                            )
                            if resolved_count > 0:
                                logger.info(f"Resolved {resolved_count} orphaned tool calls for unavailable tool")
                            else:
                                # Meta-level reminder only if no actionable placeholder was persisted during this iteration
                                self._inject_guidance(text=error_message)
                            # Restart iteration so the LLM can regenerate a plan without the unavailable tool
                            restart_iteration = True
                            break

                    # This is a fail-fast solution, which means that if the prior assistant message had
                    # several tool calls, and one of them failed to be stored, we will restart the iteration
                    if restart_iteration:
                        # Skip producing a final answer this pass; guidance now in memory
                        continue

                else:
                    # No tools requested: return after the assistant turn has been persisted.
                    # Notify completion
                    if "on_complete" in callbacks:
                        callbacks["on_complete"](True, assistant_message, metadata)
                    
                    # Return the LLM response
                    return {"success": True, "content": assistant_message, "metadata": metadata}

            # Guardrail: stop runaway loops; return last assistant content if available, else a standardized explanation
            # If max_iterations is reached, return the last message or a fallback message
            logger.warning("Max iterations reached")
            messages = self.memory.retrieve()
            last_message = messages[-1] if messages else None
            if last_message and last_message.get("role") == MessageRole.ASSISTANT.value:
                if "on_max_iterations" in callbacks:
                    callbacks["on_max_iterations"](last_message.get("content"))
                
                return {"success": False, "error": MAX_ITERATIONS_EXPLANATION_MESSAGE, "content": last_message.get("content")}
            else:
                # Reach max-iterations without assistant message
                if "on_max_iterations" in callbacks:
                    callbacks["on_max_iterations"](None)
                
                return {"success": False, "error": MAX_ITERATIONS_EXPLANATION_MESSAGE, "content": MAX_ITERATIONS_EXPLANATION_MESSAGE}

        except (KeyboardInterrupt, SystemExit, GeneratorExit) as e:
            # Abort-safe cleanup: resolve orphaned tool calls and propagate KeyboardInterrupt
            # Determine the appropriate error message based on exception type
            if isinstance(e, KeyboardInterrupt):
                error_message = "Process interrupted by user"
                log_message = f"Process interrupted by user."
            else:
                error_message = f"Process terminating: {e}"
                log_message = f"Process terminating abruptly: {e}"
            
            # Log the interruption/termination with appropriate level
            logger.warning(log_message)
            
            # Resolve any orphaned tool calls to maintain conversation coherence
            resolved_count = self.memory.resolve_orphaned_tool_calls(error_message=error_message)
            
            # Log resolution with appropriate level
            if resolved_count > 0:
                log_message = f"Resolved {resolved_count} orphaned tool calls after interruption"
                if isinstance(e, KeyboardInterrupt):
                    logger.warning(log_message)
                else:
                    logger.info(log_message)
            
            # Log re-raising for KeyboardInterrupt
            if isinstance(e, KeyboardInterrupt):
                logger.warning(f"Re-raising KeyboardInterrupt after cleanup")
            
            # Re-raise the exception to propagate it up the call stack
            raise
        except Exception as e:
            # Catch-all path: log error, resolve orphaned tool calls to keep transcript consistent, return typed failure
            logger.error(f"Error in get_response: {e}")
            
            # Some unexpected error occurred (e.g., LLM API error)
            # Resolve any orphaned tool calls to maintain conversation coherence
            resolved_count = self.memory.resolve_orphaned_tool_calls(error_message=str(e))
            if resolved_count > 0:
                logger.info(f"Resolved {resolved_count} orphaned tool calls")
            
            return {"success": False, "error": f"An error occurred while processing the request: {e}"}


    def _attempt_error_recovery(self, error: Exception, current_iteration: int) -> Dict[str, Any]:
        """
        Attempts to recover from LLM (Large Language Model) errors using appropriate strategies.

        This method classifies the encountered error and determines whether it is recoverable.
        Based on the error classification, it applies the relevant recovery strategy. If no recovery
        strategy matches the error action, or if the error is not recoverable, it returns a failure result.
        
        Args:
            error (Exception): The original error that occurred during LLM processing.
            current_iteration (int): The current iteration number in the processing loop.
            
        Returns:
            Dict[str, Any]: Normalized recovery result with the following keys:
                - success (bool): Whether recovery was successful
                - strategy (str, optional): Recovery strategy used (None if not applicable)
                - reason (str, optional): Failure reason (None on success)
                - details (dict): Additional recovery details
                - iteration (int): Current iteration number
                - error_category (str, optional): Error category value
        Raises:
            None. All errors are caught and logged internally, with details included in the returned dictionary.
        """
        try:
            # Classify the error
            category, action, severity = classify_llm_error(error)
            
            # Create enhanced error for logging
            llm_error = LLMPlatformError(
                original_error=error,
                error_category=category,
                error_action=action,
                error_severity=severity,
                metadata={
                    "iteration": current_iteration,
                    "max_iterations": self.max_iterations
                }
            )

            logger.warning(f"LLM {llm_error.error_category.value} error detected with {llm_error.error_severity.value} severity")

            # Check if error is recoverable
            if not llm_error.is_recoverable():
                return {
                    "success": False,
                    "strategy": None,
                    "reason": f"Error is not recoverable: {category.value}",
                    "details": {"error_details": llm_error.to_dict()},
                    "iteration": current_iteration,
                    "error_category": llm_error.error_category.value
                }
            
            # Attempt recovery based on error action
            if action == LLMErrorAction.RECOVER_WITH_MEMORY_REDUCTION:
                return self._attempt_memory_reduction_recovery(llm_error, current_iteration)
            elif action == LLMErrorAction.RECOVER_WITH_BACKOFF:
                return self._attempt_backoff_recovery(llm_error, current_iteration)
            else:
                return {
                    "success": False,
                    "strategy": None,
                    "reason": f"No recovery strategy for action: {action.value}",
                    "details": {"error_details": llm_error.to_dict()},
                    "iteration": current_iteration,
                    "error_category": llm_error.error_category.value
                }
                
        except Exception as recovery_error:
            logger.error(f"Error during recovery attempt: {recovery_error}")
            return {
                "success": False,
                "strategy": None,
                "reason": f"Recovery attempt failed: {recovery_error}",
                "details": {"exception_type": type(recovery_error).__name__},
                "iteration": current_iteration,
                "error_category": None
            }


    def _attempt_memory_reduction_recovery(self, error: LLMPlatformError, current_iteration: int) -> Dict[str, Any]:
        """
        Attempts to recover from context limit errors by reducing the agent's memory footprint.

        This recovery strategy is typically invoked when an LLM error indicates that the context window has been exceeded.
        The method forces a reduction in stored messages to free up tokens, enhancing the chance of a successful retry.

        Args:
            error (LLMPlatformError): The classified LLM error triggering recovery.
            current_iteration (int): The current iteration number in the agent's processing loop.
            
        Returns:
            Dict[str, Any]: Normalized recovery result with the following keys:
                - success (bool): Whether memory reduction was successful
                - strategy (str): Always "force_reduction"
                - reason (str, optional): Failure reason (None on success)
                - details (dict): Memory reduction details
                - iteration (int): Current iteration number
                - error_category (str): Error category value

        Raises:
            None. Any exceptions are caught and returned in the result dictionary.
        """
        if not self.memory:
            return {
                "success": False,
                "strategy": ErrorRecoveryStrategy.FORCE_REDUCTION.value,
                "reason": "No memory instance available for reduction",
                "details": {},
                "iteration": current_iteration,
                "error_category": error.error_category.value
            }
        
        logger.warning(f"Attempting memory reduction recovery for {error.error_category.value} error (iteration {current_iteration})")
        
        try:
            reduction_result = self.memory.force_memory_reduction(ERROR_RECOVERY_MEMORY_REDUCTION_PERCENTAGE)
            
            messages_removed = reduction_result.get('messages_removed', 0)
            tokens_reduced = reduction_result.get('tokens_reduced', 0)
            
            if messages_removed > 0:
                logger.info(f"Memory reduction successful: removed {messages_removed} messages, freed {tokens_reduced} tokens")
                return {
                    "success": True,
                    "strategy": ErrorRecoveryStrategy.FORCE_REDUCTION.value,
                    "reason": None,
                    "details": {
                        "reduction_result": reduction_result,
                        "requested_reduction_pct": ERROR_RECOVERY_MEMORY_REDUCTION_PERCENTAGE
                    },
                    "iteration": current_iteration,
                    "error_category": error.error_category.value
                }
            else:
                logger.warning(f"No messages could be removed for recovery (iteration {current_iteration})")
                return {
                    "success": False,
                    "strategy": ErrorRecoveryStrategy.FORCE_REDUCTION.value,
                    "reason": "No removable messages available",
                    "details": {"reduction_result": reduction_result},
                    "iteration": current_iteration,
                    "error_category": error.error_category.value
                }
                
        except Exception as reduction_error:
            logger.warning(f"Memory reduction failed on iteration {current_iteration}: {reduction_error}")
            return {
                "success": False,
                "strategy": ErrorRecoveryStrategy.FORCE_REDUCTION.value,
                "reason": f"Memory reduction error: {reduction_error}",
                "details": {"exception_type": type(reduction_error).__name__},
                "iteration": current_iteration,
                "error_category": error.error_category.value
            }


    def _attempt_backoff_recovery(self, error: LLMPlatformError, current_iteration: int) -> Dict[str, Any]:
        """
        Attempts to recover from resource limit errors encountered during LLM interactions using an exponential backoff strategy.

        The method calculates a delay period based on the current iteration, applies jitter for randomness, and waits
        before allowing a retry. This approach helps mitigate transient errors such as rate limiting or temporary
        resource unavailability when communicating with the LLM platform.

        Args:
            error (LLMPlatformError): The classified error instance describing the resource limit issue.
            current_iteration (int): The current iteration number in the processing loop.
            
        Returns:
            Dict[str, Any]: Normalized recovery result with the following keys:
                - success (bool): Whether backoff recovery was successful
                - strategy (str): Always "exponential_backoff"
                - reason (str, optional): Failure reason (None on success)
                - details (dict): Backoff timing details
                - iteration (int): Current iteration number
                - error_category (str): Error category value
        """
        # Check if we have retries left
        if current_iteration >= self.max_iterations - ERROR_RECOVERY_MAX_RETRIES:
            return {
                "success": False,
                "strategy": ErrorRecoveryStrategy.EXPONENTIAL_BACKOFF.value,
                "reason": "No retries left for backoff recovery",
                "details": {},
                "iteration": current_iteration,
                "error_category": error.error_category.value
            }
        
        logger.warning(f"Attempting backoff recovery for {error.error_category.value}")
        
        # Calculate backoff delay using equal jitter strategy
        base_delay = compute_exponential_base_delay(
            attempt=current_iteration,
            base_delay=ERROR_RECOVERY_BACKOFF_BASE_DELAY,
            max_multiplier=ERROR_RECOVERY_BACKOFF_MAX_MULTIPLIER,
        )
        jittered_delay = apply_equal_jitter(
            delay=base_delay,
            jitter_factor=ERROR_RECOVERY_BACKOFF_JITTER_FACTOR,
        )
        delay = min(jittered_delay, ERROR_RECOVERY_BACKOFF_MAX_DELAY)
        
        logger.warning(f"Waiting {delay:.2f} seconds before retry")
        time.sleep(delay)
        
        return {
            "success": True,
            "strategy": ErrorRecoveryStrategy.EXPONENTIAL_BACKOFF.value,
            "reason": None,
            "details": {"delay": delay},
            "iteration": current_iteration,
            "error_category": error.error_category.value
        }

    
    def _should_continue_after_failure(self, store_result: Dict[str, Any], kind: str) -> bool:
        """
        Decide if loop should continue after a storage failure.

        Conditions:
          - storage failed (success == False)
          - guidance was injected (guidance_injected == True)
          - operation kind is NOT user_input or transition

        Args:
            store_result (Dict[str, Any]): Result object from _safe_store.
            kind (str): MemoryOperationKind value indicating message type.

        Returns:
            bool: True if iteration should restart (guidance injected).
        """
        if not store_result or store_result.get("success") is True:
            return False
        if not store_result.get("guidance_injected"):
            return False
        if kind in (
            MemoryOperationKind.USER_INPUT,
            MemoryOperationKind.TRANSITION
        ):
            return False
        return True


    def _store_result_dict(
        self,
        success: bool,
        strategy: str,
        error: str = None,
        recovery_strategy: str = None,
        recovery_retry_count: int = 0,
        retry_count: int = 0,
        metadata: Dict[str, Any] = None,
        guidance_injected: bool = False,
        prior_recovery_strategy: str = None,
        prior_recovery_attempts: int = 0
    ) -> Dict[str, Any]:
        """Build a standardized store result dictionary.

        Args:
            success (bool): Whether the storage operation succeeded.
            strategy (str): Primary strategy used (e.g., "direct_store", "condensation").
            error (str): Error message if success=False. Defaults to None.
            recovery_strategy (str): Recovery strategy if retry was attempted. Defaults to None.
            recovery_retry_count (int): Number of recovery-driven retries. Defaults to 0.
            retry_count (int): Total retry attempts for this operation. Defaults to 0.
            metadata (Dict[str, Any]): Additional recovery metadata. Defaults to None.
            guidance_injected (bool): Whether guidance was injected. Defaults to False.
            prior_recovery_strategy (str): Previous recovery attempt info. Defaults to None.
            prior_recovery_attempts (int): Previous recovery attempt count. Defaults to 0.

        Returns:
            Dict[str, Any]: Standardized store result containing relevant fields.
        """
        result = {
            "success": success,
            "strategy": strategy,
            "retry_count": retry_count
        }
        
        if error is not None:
            result["error"] = error
        if recovery_strategy is not None:
            result["recovery_strategy"] = recovery_strategy
        if recovery_retry_count > 0:
            result["recovery_retry_count"] = recovery_retry_count
        if metadata is not None:
            result["metadata"] = metadata
        if guidance_injected:
            result["guidance_injected"] = guidance_injected
        if prior_recovery_strategy is not None:
            result["prior_recovery_strategy"] = prior_recovery_strategy
        if prior_recovery_attempts > 0:
            result["prior_recovery_attempts"] = prior_recovery_attempts
            
        return result


    def _safe_store(self, kind: str, fn: Callable, *args, **kwargs) -> Dict[str, Any]:
        """Execute a memory write operation with intelligent capacity-aware recovery.

        This method provides a robust wrapper around memory storage operations that can
        automatically recover from capacity errors through multiple strategies including
        memory condensation, guidance injection, and intelligent retry logic.

        Recovery Flow:
        1. **Direct Store**: Attempts the memory operation directly
        2. **Capacity Error Recovery**: If MemoryCapacityError occurs:
           - Invokes _handle_memory_capacity_error for intelligent recovery
           - May perform memory condensation to free space
           - Retries the operation if recovery was successful
        3. **Guidance Injection**: If recovery fails or isn't applicable:
           - For assistant/tool responses: Injects guidance messages to steer regeneration
           - For user input: Returns guidance to caller for user action
        4. **Graceful Failure**: Returns detailed error information if all strategies fail

        Memory Operation Kinds:
        - user_input: User messages (guidance returned to caller)
        - assistant_reply: Assistant responses (guidance injected for regeneration)
        - tool_response: Tool execution results (guidance injected for regeneration)

        Recovery Strategies:
        - direct_store: Operation succeeded without recovery
        - condensation: Memory was condensed to free space, then retried
        - oversized_guidance: Message too large, guidance provided
        - insufficient_capacity_guidance: Not enough removable tokens
        - unexpected_error: Unhandled exception occurred
        - retry_exhausted: Maximum retry attempts exceeded

        Args:
            kind (str): Memory operation kind (user_input, assistant_reply, tool_response).
                       Determines recovery behavior and guidance injection strategy.
            fn (Callable): The underlying memory write function to execute.
                          Typically memory.store() or similar storage operation.
            *args: Positional arguments passed through to the memory function.
            **kwargs: Keyword arguments passed through to the memory function.
                     May include 'tool_calls' for guidance generation context.

        Returns:
            Dict[str, Any]: Comprehensive result with the following keys:
                success (bool): Whether the storage operation ultimately succeeded
                error (str, optional): Human-readable error message if success=False
                strategy (str): Primary strategy used (see Recovery Strategies above)
                guidance_injected (bool, optional): Whether guidance was injected into memory
                metadata (dict, optional): Additional recovery metadata and statistics
                recovery_strategy (str, optional): Recovery strategy if retry was attempted
                recovery_retry_count (int, optional): Number of recovery-driven retries
                prior_recovery_strategy (str, optional): Previous recovery attempt info
                prior_recovery_attempts (int, optional): Previous recovery attempt count
                retry_count (int, optional): Total retry attempts for this operation

        Note:
            This method implements sophisticated retry logic with a maximum of 1 retry
            to prevent infinite loops while still allowing recovery from transient
            capacity issues. Guidance injection is limited to one attempt per store
            operation to avoid message spam.
        """
        max_retries = 1
        injection_attempted = False         # Track single injection per failing attempt
        recovery_strategy = None            # Last recovery strategy used (if any)
        recovery_attempts = 0               # Count recovery-driven retries
        
        for retry_count in range(max_retries + 1):
            try:
                fn(*args, **kwargs)
                return self._store_result_dict(
                    success=True,
                    strategy=MemoryErrorStrategy.DIRECT_STORE.value,
                    retry_count=retry_count,
                    recovery_strategy=recovery_strategy,
                    recovery_retry_count=recovery_attempts if recovery_strategy else 0
                )
                
            except MemoryCapacityError as memory_error:
                logger.warning(f"Memory capacity error on {kind} (attempt {retry_count + 1}/{max_retries + 1}): {memory_error}")
                
                # Handle the memory capacity error
                recovery_result = self._handle_memory_capacity_error(
                    memory_error,
                    kind,
                    retry_count,
                    **kwargs
                )
                
                assessment = memory_error.assessment
                logger.info(
                    f"Memory error metadata - current: {assessment.current_tokens}, "
                    f"max: {assessment.capacity_limit}, message: {assessment.message_tokens}, "
                    f"to_free: {assessment.tokens_to_free}, removable: {assessment.removable_tokens}"
                )
                
                # Case 1: Successful recovery path (handled=True AND retry=True, recovery succeeded - retry the store)
                # Meaning:
                #   A recovery strategy (currently only 'condensation') successfully freed enough tokens
                #   to make another attempt at storing the SAME message worthwhile. The original store
                #   operation that triggered the MemoryCapacityError did NOT persist the message (the
                #   exception aborted it), so we MUST retry explicitly after freeing space.
                # Why retry is REQUIRED:
                #   - We only freed capacity; we did NOT store the message yet.
                #   - Not retrying would silently drop the triggering message.
                #   - Retry count guard (retry_count < max_retries) prevents infinite loops if something
                #     pathological still blocks the store.
                # Future-proofing: Explicit retry=True check ensures forward compatibility if a future
                #   handler returns handled=True, retry=False (indicating it stored the message internally).
                if recovery_result["handled"] and recovery_result.get("retry") and retry_count < max_retries:
                    recovery_strategy = recovery_result["strategy"]
                    recovery_attempts += 1
                    logger.info(f"Retrying {kind} storage after {recovery_strategy}")
                    continue
                
                # Case 2: Guidance / failure path (handled=False OR handled=True but retry not requested)
                # Meaning:
                #   Automatic recovery could not (or should not) resolve the issue:
                #     - Condensation skipped or insufficient (remaining deficit)
                #     - Message itself is inherently too large (oversized)
                #     - Not enough removable tokens (hard capacity ceiling)
                #     - Unknown action / safety fallback
                # Action:
                #   - Produce guidance (user-facing or LLM-injected) explaining what to change.
                #   - For assistant/tool kinds we inject a synthetic user/system message to
                #     steer the next generation (regeneration loop).
                # Injection constraints:
                #   - Only one injection per failing store attempt (injection_attempted flag).
                #   - If injection itself hits capacity, we abort gracefully and return error upstream.
                else:
                    guidance = recovery_result.get("guidance", str(memory_error))
                    if recovery_result.get("handled") and not recovery_result.get("retry"):
                        # Future‑proof: treat as resolved (no retry) if a handler ever returns handled=True, retry=False
                        logger.info(f"{kind} memory issue resolved via {recovery_result['strategy']} (no retry requested)")
                        return self._store_result_dict(
                            success=True,
                            strategy=recovery_result["strategy"],
                            metadata=recovery_result.get("metadata", {})
                        )
                    
                    # Guidance injection logic:
                    # We only inject guidance for assistant/tool kinds (never for user_input):
                    #   - For user_input we return the guidance upstream so the caller/user can act.
                    #   - For assistant/tool messages we inject a synthetic user message that
                    #     instructs the model how to regenerate a smaller / compliant reply.
                    # Conditions:
                    #   - guidance must be non-empty
                    #   - injection not already attempted this store cycle (injection_attempted flag)
                    # has_tool_calls:
                    #   - Passed so guidance generation (already done) or future injection-time
                    #     logic can remind the model to reissue necessary tool calls after trimming.
                    injection_success = False
                    if kind != MemoryOperationKind.USER_INPUT and guidance and not injection_attempted:
                        has_tool_calls = "tool_calls" in kwargs and kwargs["tool_calls"] is not None
                        injection_success = self._inject_guidance(
                            guidance,
                            has_tool_calls=has_tool_calls,
                            strategy=recovery_result["strategy"],
                            kind=kind
                        )
                        injection_attempted = True
                        if injection_success:
                            logger.info(f"Injected guidance for {kind} memory error (strategy={recovery_result['strategy']})")
                        else:
                            logger.warning(f"Failed to inject guidance for {kind}, returning error to caller")
                    elif injection_attempted and kind != MemoryOperationKind.USER_INPUT:
                        logger.debug(f"Skipping duplicate guidance injection for {kind}")
                    
                    return self._store_result_dict(
                        success=False,
                        error=guidance,
                        strategy=recovery_result["strategy"],
                        metadata=recovery_result.get("metadata", {}),
                        guidance_injected=(injection_attempted and injection_success) if kind != MemoryOperationKind.USER_INPUT else False,
                        prior_recovery_strategy=recovery_strategy,
                        prior_recovery_attempts=recovery_attempts if recovery_strategy else 0
                    )
            except Exception as other_error:
                logger.error(f"Unexpected error during {kind} storage: {other_error}")
                return self._store_result_dict(
                    success=False,
                    error=f"Storage failed: {other_error}",
                    strategy=MemoryErrorStrategy.UNEXPECTED_ERROR.value,
                    recovery_strategy=recovery_strategy,
                    recovery_retry_count=recovery_attempts if recovery_strategy else 0
                )

        # Exhausted retries
        return self._store_result_dict(
            success=False,
            error="Max retries exceeded",
            strategy=MemoryErrorStrategy.RETRY_EXHAUSTED.value,
            recovery_strategy=recovery_strategy,
            recovery_retry_count=recovery_attempts
        )


    def _inject_guidance(self,
                         text: str,
                         has_tool_calls: bool = False,
                         strategy: str = None,
                         kind: Optional[str] = None) -> bool:
        """Inject guidance message into conversation while preserving tool call ordering.
        
        This method handles guidance injection for memory capacity errors, ensuring proper
        conversation flow and tool call state consistency. It adapts behavior based on the
        type of operation that failed.
        
        Behaviors by operation type:
          - Assistant reply failure (ASSISTANT_REPLY / ASSISTANT_FINAL):
              * The assistant message was never stored, so no dangling tool calls exist.
              * If has_tool_calls=True, optionally appends a reminder to reissue essential tool calls.
          - Tool message failure (TOOL_RESPONSE / TOOL_ERROR / TOOL_SUCCESS):
              * The assistant message with tool_calls WAS stored earlier.
              * Failed tool response risks leaving dangling tool call IDs.
              * Resolves orphaned tool calls first (via resolve_orphaned_tool_calls) before injecting guidance.
          - User input failures:
              * Never invoke this method (guarded upstream in _safe_store).
        
        Args:
            text (str): Tailored guidance message (already includes size/regeneration instructions
                from get_tailored_guidance).
            has_tool_calls (bool, optional): Whether the original (failed) assistant message
                declared tool calls. Defaults to False.
            strategy (str, optional): Recovery strategy name (for logging context). Defaults to None.
            kind (str, optional): MemoryOperationKind value indicating which operation failed
                (e.g., ASSISTANT_REPLY, TOOL_RESPONSE). Defaults to None.

        Returns:
            bool: True if guidance injection succeeded; False if injection failed.
            
        Note:
            The injected guidance is prefixed with CODA_SYSTEM_MESSAGE_PREFIX to distinguish
            it from regular conversation messages.
        """
        try:
            # 1. Tool response / error failure path: resolve any orphaned tool calls first.
            if kind in (
                MemoryOperationKind.TOOL_RESPONSE,
                MemoryOperationKind.TOOL_ERROR,
                MemoryOperationKind.TOOL_SUCCESS
            ):
                orphan_msg = (
                    "Tool execution aborted due to memory limits. Marking pending tool calls as failed. "
                    "Regenerate a shorter reply; reissue only essential tool calls with minimal arguments."
                )
                formatted_orphan_msg = f"{CODA_SYSTEM_MESSAGE_PREFIX} {orphan_msg}"
                resolved = self.memory.resolve_orphaned_tool_calls(error_message=formatted_orphan_msg)
                if resolved > 0:
                    logger.warning(f"Resolved {resolved} orphaned tool calls prior to guidance injection ({strategy or 'no_strategy'})")

            # 2. Assistant reply failure with tool calls: add a regeneration hint if not already present.
            augmented_text = text
            if kind in (MemoryOperationKind.ASSISTANT_REPLY, MemoryOperationKind.ASSISTANT_FINAL) and has_tool_calls:
                lower = text.lower()
                if "tool call" not in lower and "tool_call" not in lower:
                    augmented_text = (
                        f"{text}\nReissue only essential tool calls with trimmed arguments if still needed."
                    )

            guidance_message = f"{CODA_SYSTEM_MESSAGE_PREFIX} {augmented_text}"
            self.memory.add_user_message(guidance_message)

            logger.info(
                f"Injected guidance ({kind or 'unknown_kind'} / {strategy or 'no_strategy'}): "
                f"{augmented_text[:GUIDANCE_INJECTION_LOG_TRUNCATE_LENGTH]}..."
            )
            return True

        except MemoryCapacityError:
            logger.warning("Could not inject guidance due to memory capacity - guidance dropped")
            return False
        except Exception as e:
            logger.error(f"Failed to inject guidance: {e}")
            return False


    def _handle_memory_capacity_error(self, error: MemoryCapacityError, kind: str, retry_count: int = 0, **kwargs) -> Dict[str, Any]:
        """Route memory capacity errors to appropriate strategy.
        
        Args:
            error (MemoryCapacityError): The MemoryCapacityError that occurred
            kind (str): Description of the storage purpose
            retry_count (int): Current retry attempt number
            **kwargs: Additional context from storage operation (e.g., tool_calls)
            
        Returns:
            Dict containing:
                - handled (bool):- Whether the error was handled
                - retry (bool): Whether the operation should be retried
                - guidance (str): User guidance message (if applicable)
                - strategy (str): The strategy used
                - metadata (dict): Additional metadata for logging
        """
        assessment = error.assessment
        category = error.category
        
        # Extract tool call context for guidance generation
        has_tool_calls = "tool_calls" in kwargs and kwargs["tool_calls"] is not None
        
        logger.warning(f"Handling memory capacity error for {kind}: {category.value} - {assessment.reason_if_failed}")
        
        # Note: retry_count > 0 means we're past the first store attempt.
        # Condensation is only attempted on retry_count == 0; subsequent attempts
        # route directly to guidance. This log is informational only.
        if retry_count > 0:
            logger.warning(f"Retry attempt {retry_count} for {kind}; recovery paths already limited (no further condensation).")
        
        # Handle based on assessment action
        if assessment.action == MemoryAssessmentAction.SUGGEST_CONDENSE:
            # Memory has removable content - attempt forced condensation to free space
            # This bypasses condenser thresholds since assessment already determined it could help
            return handle_condense_suggestion(memory=self.memory, error=error, kind=kind, retry_count=retry_count, has_tool_calls=has_tool_calls)
        elif assessment.action == MemoryAssessmentAction.REPORT_TO_AGENT:
            if category == MemoryErrorCategory.OVERSIZED_MESSAGE:
                # Single message exceeds capacity limits - provide guidance for message reduction
                # No condensation possible since the issue is the current message size
                return handle_oversized_message(error=error, kind=kind)
            else:
                # Insufficient removable capacity - provide intelligent guidance routing
                # For user_input: direct user guidance, for assistant: LLM injection with regeneration
                return handle_insufficient_capacity(error=error, kind=kind, has_tool_calls=has_tool_calls)
        else:
            # Unknown or unexpected assessment action - fallback safety net
            # Should rarely occur but ensures graceful degradation with observability
            return handle_unknown_action(error=error, kind=kind)


    def _parse_llm_response(self, llm_response: ResponseObject) -> Dict[str, Any]:
        """
        Parses the LLM response to extract the relevant information, including tool calls, metadata,
        reasoning content, and thinking blocks.

        Args:
            llm_response (ResponseObject): The normalized response from the LLM.

        Returns:
            Dict[str, Any]: A dictionary containing the parsed response content, tool calls, metadata,
            reasoning content, and thinking blocks.
        """
        try:
            # Parse the assistant's message content
            message_result = self._parse_message_content(llm_response)
            if not message_result["success"]:
                return {"error": message_result["error"]}

            # Parse tool call information (if any)
            tool_calls = self._parse_tool_requests(llm_response)
            if tool_calls is None:
                logger.debug("No tool calls found in the LLM response.")

            # Parse metadata (e.g., model, usage)
            metadata = self._parse_metadata(llm_response)
            if not metadata:
                logger.debug("No metadata found in the LLM response.")
                
            # Parse reasoning content (if available)
            reasoning_content = self._parse_reasoning_content(llm_response)
            if reasoning_content is None:
                logger.debug("No reasoning content found in the LLM response.")
                
            # Parse thinking blocks (if available, typically only for Anthropic models)
            thinking_blocks = self._parse_thinking_blocks(llm_response)
            if thinking_blocks is None:
                logger.debug("No thinking blocks found in the LLM response.")

            # Return the parsed response
            return {
                "content": message_result["content"],
                "tool_calls": tool_calls,
                "metadata": metadata,
                "reasoning_content": reasoning_content,
                "thinking_blocks": thinking_blocks,
            }

        except Exception as e:
            logger.error(f"Error parsing LLM response: {e}")
            return {"error": "An error occurred while parsing the response."}

    def _parse_reasoning_content(self, llm_response: ResponseObject) -> Optional[str]:
        """
        Extract reasoning summary content from the Responses-style object.
        """
        try:
            for item in llm_response.output:
                if isinstance(item, ResponseReasoning):
                    if item.summary:
                        return " ".join(
                            [summary.text for summary in item.summary if summary.text]
                        ) or None
            return None
        except Exception as e:
            logger.error(f"Error extracting reasoning content: {e}")
            return None

    def _extract_reasoning_items(self, llm_response: ResponseObject) -> List[Dict[str, Any]]:
        """
        Extract reasoning items from a Responses-style object in canonical dict shape.

        Args:
            llm_response: Normalized Responses envelope returned by the model layer.

        Returns:
            List of reasoning item dictionaries suitable for memory persistence.
        """
        reasoning_items: List[Dict[str, Any]] = []
        try:
            for item in llm_response.output:
                if not isinstance(item, ResponseReasoning):
                    continue

                normalized_summary: List[Dict[str, Any]] = []
                for summary in item.summary or []:
                    normalized_summary.append({
                        "type": "summary_text",
                        "text": summary.text,
                    })

                reasoning_item: Dict[str, Any] = {
                    "type": "reasoning",
                    "id": item.id,
                    "summary": normalized_summary,
                }
                if item.encrypted_content:
                    reasoning_item["encrypted_content"] = item.encrypted_content

                # Ignore empty reasoning shells to avoid noisy memory writes.
                if not reasoning_item["summary"] and "encrypted_content" not in reasoning_item:
                    continue
                reasoning_items.append(reasoning_item)
        except Exception as e:
            logger.error(f"Error extracting reasoning items: {e}")
            return []
        return reasoning_items

    def _store_reasoning_items(self, reasoning_items: List[Dict[str, Any]]) -> None:
        """
        Persist reasoning items in memory as a best-effort operation.

        Args:
            reasoning_items: Reasoning item dictionaries extracted from model output.
        """
        if not reasoning_items or self.memory is None:
            return

        try:
            self.memory.add_reasoning_items(reasoning_items)
        except MemoryCapacityError as e:
            logger.warning(f"Skipping reasoning persistence due to memory capacity limits: {e}")
        except Exception as e:
            logger.warning(f"Failed to persist reasoning items: {e}")

    def _extract_unknown_items(self, llm_response: ResponseObject) -> List[Dict[str, Any]]:
        """
        Extract unknown output items preserved by interop normalization.

        Args:
            llm_response: Normalized Responses envelope returned by the model layer.

        Returns:
            List of unknown item dictionaries suitable for memory persistence.
        """
        unknown_items: List[Dict[str, Any]] = []
        try:
            for item in llm_response.output:
                if not isinstance(item, ResponseUnknownItem):
                    continue

                if not isinstance(item.raw, dict) or not item.raw:
                    continue

                unknown_item: Dict[str, Any] = {
                    "type": "unknown",
                    "raw": item.raw,
                }
                if isinstance(item.original_type, str) and item.original_type:
                    unknown_item["original_type"] = item.original_type

                unknown_items.append(unknown_item)
        except Exception as e:
            logger.error(f"Error extracting unknown items: {e}")
            return []
        return unknown_items

    def _store_unknown_items(self, unknown_items: List[Dict[str, Any]]) -> None:
        """
        Persist unknown items in memory as a best-effort operation.

        Args:
            unknown_items: Unknown item dictionaries extracted from model output.
        """
        if not unknown_items or self.memory is None:
            return

        try:
            self.memory.add_unknown_items(unknown_items)
        except MemoryCapacityError as e:
            logger.warning(f"Skipping unknown-item persistence due to memory capacity limits: {e}")
        except Exception as e:
            logger.warning(f"Failed to persist unknown items: {e}")

    def _parse_thinking_blocks(self, llm_response: ResponseObject) -> Optional[List[Dict[str, str]]]:
        """
        Thinking blocks are provider-specific; not supported in Responses normalization yet.
        """
        return None

    def _parse_message_content(self, llm_response: ResponseObject) -> Dict[str, Any]:
        """
        Extract the assistant's message content from a Responses-style object.
        """
        try:
            content = llm_response.output_text
            return {"success": True, "content": content}
        except Exception as e:
            logger.error(f"Error extracting message content: {e}")
            return {"success": False, "error": f"Error extracting message content: {e}"}

    def _parse_tool_requests(self, llm_response: ResponseObject) -> Optional[List[Dict[str, Any]]]:
        """
        Extract tool call information from a Responses-style object.
        """
        try:
            tool_calls: List[Dict[str, Any]] = []
            for tool_call in llm_response.tool_calls():
                if not isinstance(tool_call, ResponseToolCall):
                    continue
                raw_args = tool_call.arguments
                try:
                    tool_args = json.loads(raw_args) if raw_args else {}
                except json.JSONDecodeError as e:
                    logger.error(f"Error decoding tool arguments: {e}")
                    tool_args = {}

                tool_calls.append({
                    "tool_id": tool_call.call_id,
                    "tool_name": tool_call.name,
                    "tool_args": tool_args,
                })

            return tool_calls if tool_calls else None
        except Exception as e:
            logger.error(f"Error extracting tool requests: {e}")
            return None

    def _call_tool(
        self,
        tool_name: str,
        tool_args: Dict[str, Any],
        runtime_kwargs: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Call the specified tool with the given arguments.

        Args:
            tool_name (str): The name of the tool to call.
            tool_args (Dict[str, Any]): The arguments to pass to the tool (LLM-provided).
            runtime_kwargs (Optional[Dict[str, Any]]): Runtime-only kwargs injected by the runtime (e.g., streaming callbacks).

        Returns:
            Dict[str, Any]: A dictionary containing the tool's response or error information.
        """
        try:
            tool = next((tool for tool in self.tools if tool.name == tool_name), None)
            if tool:
                merged_args: Dict[str, Any] = dict(tool_args or {})
                if runtime_kwargs:
                    merged_args.update(runtime_kwargs)

                response = tool.execute(**merged_args)
                return {"success": True, "response": response}
            else:
                # Tool not found
                error_message = f"Tool '{tool_name}' is not available. Please use only currently available tools."
                
                # Add a reminder about available tools to help the model
                available_tools = [t.name for t in self.tools]
                tool_reminder = f"Currently available tools: {', '.join(available_tools)}"
                full_error = f"{error_message}\n{tool_reminder}"
                
                logger.error(f"Tool '{tool_name}' not found.")
                return {"success": False, "error": full_error}
        except Exception as e:
            # Handle any exceptions during tool execution
            logger.error(f"Error calling tool '{tool_name}': {e}")
            
            # Check if this is a parameter error
            if "ParameterError" in e.__class__.__name__:
                # Format a helpful error message for the LLM
                error_message = f"Parameter error in tool '{tool_name}': {str(e)}"
                return {"success": False, "error": error_message}

            return {"success": False, "error": f"An error occurred while calling the tool: {e}"}

    def _parse_metadata(self, llm_response: ResponseObject) -> Dict[str, Any]:
        """
        Extract metadata from a Responses-style object.

        Preserves legacy keys that older callers may still read while using normalized usage data.
        """
        try:
            return {
                "model": llm_response.model,
                "usage": llm_response.usage_summary(),
                "created": llm_response.created_at,
                "service_tier": getattr(llm_response, "service_tier", None),
                "system_fingerprint": getattr(llm_response, "system_fingerprint", None),
                "object": llm_response.object,
                "status": llm_response.status,
            }
        except Exception as e:
            logger.error(f"Error extracting metadata: {e}")
            return {}

    def _get_stop_reason(self, llm_response: ResponseObject) -> Dict[str, Any]:
        """
        Interpret completion status from a Responses-style object.
        """
        try:
            if llm_response.error:
                return {
                    "success": False,
                    "error": {
                        "code": StopReasonCode.EXCEPTION,
                        "message": llm_response.error.message,
                        "finish_reason": None,
                    },
                }

            if llm_response.tool_calls():
                return {"success": True, "finish_reason": "tool_calls"}

            if llm_response.status == ResponseStatus.COMPLETED:
                return {"success": True, "finish_reason": "stop"}

            if llm_response.status == ResponseStatus.INCOMPLETE:
                incomplete_reason = (
                    llm_response.incomplete_details.reason
                    if llm_response.incomplete_details
                    else None
                )
                normalized_reason = (
                    incomplete_reason.strip().lower()
                    if isinstance(incomplete_reason, str)
                    else None
                )

                if normalized_reason in {"content_filter", "content_filtered"}:
                    logger.warning("LLM response was filtered due to content restrictions.")
                    return {
                        "success": False,
                        "error": {
                            "code": StopReasonCode.CONTENT_FILTER,
                            "message": "LLM response was filtered due to content restrictions.",
                            "finish_reason": "content_filter",
                        },
                        "recoverable": True,
                        "guidance": (
                            "The prior output was blocked by a content filter. "
                            "Re-answer safely and avoid restricted details."
                        ),
                    }

                logger.warning("LLM response was truncated.")
                return {
                    "success": False,
                    "error": {
                        "code": StopReasonCode.LENGTH,
                        "message": "LLM response was truncated.",
                        "finish_reason": "length",
                    },
                    "recoverable": True,
                    "guidance": (
                        "Previous response was truncated due to token limits. "
                        "Regenerate a concise answer that fits within the token limit. "
                        "If tool calls are still needed, reissue only essential calls with minimal arguments."
                    ),
                }

            if llm_response.status == ResponseStatus.FAILED:
                return {
                    "success": False,
                    "error": {
                        "code": StopReasonCode.EXCEPTION,
                        "message": "LLM response failed.",
                        "finish_reason": "failed",
                    },
                }

            if llm_response.status == ResponseStatus.CANCELLED:
                return {
                    "success": False,
                    "error": {
                        "code": StopReasonCode.UNEXPECTED_FINISH_REASON,
                        "message": "LLM response was cancelled.",
                        "finish_reason": "cancelled",
                    },
                }

            if llm_response.status in {ResponseStatus.IN_PROGRESS, ResponseStatus.QUEUED}:
                return {
                    "success": False,
                    "error": {
                        "code": StopReasonCode.UNEXPECTED_FINISH_REASON,
                        "message": f"Non-terminal response status received: {llm_response.status}",
                        "finish_reason": str(llm_response.status),
                    },
                    "recoverable": True,
                    "guidance": (
                        "The provider returned a non-terminal response state. "
                        "Retry generation to obtain a completed response."
                    ),
                }

            return {
                "success": False,
                "error": {
                    "code": StopReasonCode.UNEXPECTED_FINISH_REASON,
                    "message": f"Unexpected response status: {llm_response.status}",
                    "finish_reason": None,
                },
            }
        except Exception as e:
            logger.error(f"Error extracting finish_reason: {e}")
            return {
                "success": False,
                "error": {
                    "code": StopReasonCode.EXCEPTION,
                    "message": f"Error extracting finish_reason: {e}",
                    "finish_reason": None,
                },
            }

    def _assess_bash_command_risk(self, command: str) -> Dict[str, Any]:
        """
        Assesses the risk level of a bash command.
        
        Args:
            command (str): The bash command to assess
            
        Returns:
            Dict[str, Any]: A dictionary containing risk assessment information
        """
        # Get risk assessment
        risk_assessment = assess_command_risk(command)
        
        return risk_assessment

    def update_system_prompt(
        self, 
        user_defined_rules: Optional[Dict[str, Any]] = None,
        template_name: Optional[str] = None,
        workspace_context: Optional[WorkspaceContext] = None
    ) -> None:
        """
        Updates the system prompt of a SingleAgent with the latest tools, user-defined rules and workspace context.

        Args:
            user_defined_rules (Optional[Dict[str, Any]]): Optional dictionary containing user-defined rules.
            workspace_context (Optional[WorkspaceContext]): Optional metadata about the workspace environment.
            template_name (Optional[str]): The template name to use for the system prompt
            workspace_context (Optional[WorkspaceContext]): Optional metadata about the workspace environment.
        """        
        # Prepare additional context for system prompt
        additional_context = {}

        # Add user-defined rules if available
        if user_defined_rules and user_defined_rules.get('content'):
            additional_context['user_defined_rules'] = user_defined_rules['content']

        # Use the default template if none is specified or stored
        if template_name is None:
            template_name = MAIN_AGENT_PROMPT_TEMPLATE
            logger.info(f"No template specified, using default: {template_name}")

        # Create the system prompt with tools, workspace context, additional context, and proper template
        system_prompt = create_system_prompt(
            tools=self.tools, 
            workspace_context=workspace_context,
            additional_context=additional_context,
            template_name=template_name
        )

        # Append agent-specific prompt if available (restoring custom instructions)
        if self.agent_prompt:
            system_prompt = create_agent_prompt(system_prompt, self.agent_prompt)

        # Add MCP info if available
        try:
            mcp_service = MCPService.get()
            mcp_snippet = mcp_service.prompt_snippet()
            if mcp_snippet:
                additional_context['mcp_info'] = mcp_snippet
        except Exception as e:
            logger.error(f"Error adding MCP info to system prompt: {e}")

        # Update the agent's LLM system prompt
        self.llm.system_prompt = system_prompt

        # Also update the system message in memory
        self.memory.upsert_system_message(system_prompt)

        logger.info(f"Updated system prompt for agent {self.id} with current tools")

    def _has_ongoing_conversation(self) -> bool:
        """
        Determines whether there is an ongoing conversation by checking the agent's memory for
        any user or assistant messages (excluding the system message).

        Returns:
            bool: Returns True if there is at least one user or assistant message in memory,
            indicating an ongoing conversation. Returns False if there are no such messages,
            or if the memory attribute is not present.
        """
        if not hasattr(self, 'memory'):
            return False
        
        # Get message counts by role
        counts = self.memory.count_by_role()
        # Check if there are any user or assistant messages
        return counts.get('user', 0) > 0 or counts.get('assistant', 0) > 0

    def handle_tool_transition(
        self,
        result: Dict[str, Any],
        update_system_prompt_flag: bool = True,
        user_defined_rules: Optional[Dict[str, Any]] = None,
        active_mode: Optional[Dict[str, Any]] = None,
        workspace_context: Optional[WorkspaceContext] = None
    ) -> None:
        """
        Handle the transition when tools are added or removed.

        Adds a new user message to inform the model about tool changes, rather than modifying the existing system prompt.
        Only adds a transition message if there's an ongoing conversation.

        Args:
            result (Dict[str, Any]): The result from update_tools, add_tools, remove_tools, or set_tools.
            update_system_prompt_flag (bool): Whether to update the system prompt.
            user_defined_rules (Optional[Dict[str, Any]]): Optional user-defined rules to include in system prompt.
            active_mode (Optional[Dict[str, Any]]): Optional active mode dict if using modes containing (template name and key), otherwise None
            workspace_context (Optional[WorkspaceContext]): Optional metadata about the workspace environment.
        """
        if result['changed']:
            # Only add a transition message if there's an ongoing conversation
            if self._has_ongoing_conversation():
                # Generate a transition message
                transition_message = self.generate_tool_transition_message(
                    result['added'], result['removed']
                )

                # Add the transition message as a user message in the conversation - handle memory capacity errors
                store_result = self._safe_store(MemoryOperationKind.TRANSITION, self.memory.add_user_message, transition_message)
                if not store_result["success"]:
                    return {"success": False, "error": store_result["error"]}
                
                logger.info(f"Added tool transition message as user message for agent {self.id}")
            else:
                logger.info(f"No ongoing conversation, skipping transition message for agent {self.id}")

            # Update the system prompt if requested
            if update_system_prompt_flag:
                # Get current template name if it exists
                template_name = None
                if active_mode is not None and active_mode["key"] is not None: 
                    template_name = active_mode["system_prompt_template_name"]
                    logger.info(f"Preserving template name during tool transition: {template_name}")
                else:
                    if hasattr(self.llm, 'template_name') and self.llm.template_name:
                        logger.info(f"Preserving template name during tool transition: {self.llm.template_name}")
                        template_name = self.llm.template_name
                        logger.info(f"Preserving template name during tool transition: {template_name}")

                self.update_system_prompt(user_defined_rules, template_name=template_name, workspace_context=workspace_context)

    def handle_mcp_transition(
        self,
        added_servers: List[str],
        removed_servers: List[str],
        update_system_prompt_flag: bool = True,
        user_defined_rules: Optional[Dict[str, Any]] = None,
        active_mode: Optional[Dict[str, Any]] = None,
        workspace_context: Optional[WorkspaceContext] = None
    ) -> None:
        """
        Handle the transition when MCP servers are enabled/disabled/added/removed.

        Adds a new user message to inform the model about MCP server changes,
        and updates the system prompt to reflect new tool availability.
        Only adds a transition message if there's an ongoing conversation.

        Args:
            added_servers (List[str]): List of MCP server names that were enabled/added.
            removed_servers (List[str]): List of MCP server names that were disabled/removed.
            update_system_prompt_flag (bool): Whether to update the system prompt. Defaults to True.
            user_defined_rules (Optional[Dict[str, Any]]): Optional user-defined rules to include in system prompt.
            active_mode (Optional[Dict[str, Any]]): Optional active mode dict if using modes containing (template name and key), otherwise None
            workspace_context (Optional[WorkspaceContext]): Optional metadata about the workspace environment.
        """
        # Check if there are any actual changes
        if not added_servers and not removed_servers:
            return

        # Only add a transition message if there's an ongoing conversation
        if self._has_ongoing_conversation():
            # Get tool changes for more detailed transition message
            added_tools = []
            removed_tools = []

            try:
                mcp_service = MCPService.get()
                if mcp_service.is_available():
                    all_tools = mcp_service.list_tools()

                    # Group tools by server for comparison
                    for server_name, tool_name, _ in all_tools:
                        if server_name in added_servers:
                            added_tools.append(f"{server_name}.{tool_name}")
                        elif server_name in removed_servers:
                            removed_tools.append(f"{server_name}.{tool_name}")
            except Exception:
                pass  # Don't let tool listing break the transition

            # Generate a transition message
            transition_message = self.generate_mcp_transition_message(
                added_servers, removed_servers, added_tools, removed_tools
            )

            # Add the transition message as a user message in the conversation - handle memory capacity errors
            store_result = self._safe_store(MemoryOperationKind.TRANSITION, self.memory.add_user_message, transition_message)
            if not store_result["success"]:
                return {"success": False, "error": store_result["error"]}

            logger.info(f"Added MCP transition message as user message for agent {self.id}")
        else:
            logger.info(f"No ongoing conversation, skipping MCP transition message for agent {self.id}")

        # Update the system prompt if requested
        if update_system_prompt_flag:
            # Get current template name if it exists
            template_name = None
            if active_mode is not None and active_mode["key"] is not None:
                template_name = active_mode["system_prompt_template_name"]
                logger.info(f"Preserving template name during tool transition: {template_name}")
            else:
                if hasattr(self.llm, 'template_name') and self.llm.template_name:
                    logger.info(f"Preserving template name during tool transition: {self.llm.template_name}")
                    template_name = self.llm.template_name
                    logger.info(f"Preserving template name during tool transition: {template_name}")

            self.update_system_prompt(user_defined_rules, template_name=template_name, workspace_context=workspace_context)

    def update_agent_with_tool_changes(
        self,
        updated_tools: List[FunctionTool],
        update_system_prompt_flag: bool = True,
        user_defined_rules: Optional[Dict[str, Any]] = None,
        active_mode: Optional[Dict[str, Any]] = None,
        workspace_context: Optional[WorkspaceContext] = None
    ) -> Dict[str, Any]:
        """
        Update an agent's tools and handle system message updates.

        This is a convenience function that combines updating tools and handling
        the transition in one operation.

        Args:
            updated_tools (List[FunctionTool]): The new list of tools to use.
            update_system_prompt_flag (bool): Whether to update the system prompt.
            user_defined_rules (Optional[Dict[str, Any]]): Optional user-defined rules to include in system prompt.
            active_mode (Optional[Dict[str, Any]]): Optional active mode dict if using modes containing (template name and key), otherwise None
            workspace_context (Optional[WorkspaceContext]): Optional metadata about the workspace environment.

        Returns:
            (Dict[str, Any]): Result of the update operation.
        """
        # Update the agent's tools
        result = self.update_tools(updated_tools)

        # Handle the transition if tools changed
        if result['changed']:
            self.handle_tool_transition(result, update_system_prompt_flag, user_defined_rules, active_mode, workspace_context)

        return result
