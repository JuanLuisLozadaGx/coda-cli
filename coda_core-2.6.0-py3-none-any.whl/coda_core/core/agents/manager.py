import os
import shutil
import re
import time
import importlib.resources
from typing import Dict, List, Optional, Any, Tuple
from loguru import logger
from pydantic import ValidationError
import portalocker

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.config.utils import are_geai_credentials_available
from coda_core.config.context.schemas import WorkspaceContext
from coda_core.core.session.states.shared_state import SharedState
from coda_core.core.agents.schemas import AgentDefinition, AgentMetadata
from coda_core.core.agents.single_agent import SingleAgent
from coda_core.core.memories.base import Memory
from coda_core.core.memories.token_limited_memory import TokenLimitedMemory
from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.config.constants import DEFAULT_AGENTS, AGENTS_PACKAGE_NAME
from coda_core.core.agents.constants import REMOTE_AGENTS_CACHE_TS_DEFAULT
from coda_core.core.agents.utils import parse_user_message_for_agents
from coda_core.core.memories.constants import MEMORY_DEFAULT_TOKEN_LIMIT


class AgentManager:
    """
    Manages agent files and provides functionality to load, list, and initialize agents.
    """

    def __init__(self, shared_state: SharedState = None):
        """
        Initialize the AgentManager.

        The agents directory is determined from the environment configuration.
        """
        self.agents_dir = SETTINGS.get_env_var(EnvConfig.CODA_AGENTS_DIR_PATH)
        self.shared_state = shared_state
        self._remote_agents_cache: List[Any] = []
        self._remote_agents_ts: float = REMOTE_AGENTS_CACHE_TS_DEFAULT
        self._default_agents_initialized = False

    def _parse_tools_list(self, tools_str: str) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        """
        Parse the tools string from agent metadata.

        Handles:
        - "default": Returns (None, None) (implies all enabled tools)
        - "default, -tool": Start with None (all), exclude 'tool'
        - "-tool": Implicitly starts with None (all), exclude 'tool'
        - "tool1, tool2": Only these tools (included=['tool1', 'tool2'], excluded=[])

        Returns:
            Tuple[Optional[List[str]], Optional[List[str]]]: (included_tools, excluded_tools)
        """
        tools_str = tools_str.strip()
        if tools_str == "default":
            return None, None

        items = [tool.strip() for tool in tools_str.split(",") if tool.strip()]

        included = []
        excluded = []
        has_default = False

        for item in items:
            if item == "default":
                has_default = True
            elif item.startswith("-"):
                tool_name = item[1:].strip()
                if tool_name:
                    excluded.append(tool_name)
            else:
                included.append(item)

        # Determine agent_tools (None = all, [] = none, [...] = specific)
        # We use default (None) if:
        # 1. "default" keyword is explicitly present
        # 2. There are exclusions but no explicit inclusions (implicit default)
        if has_default or (excluded and not included):
            return None, excluded

        return included, excluded

    def list_agents(self) -> List[str]:
        """
        Returns a list of all agent names available.

        Returns:
            List[str]: List of agent names
        """
        agents = []
        try:
            if os.path.exists(self.agents_dir):
                for file in os.listdir(self.agents_dir):
                    if file.endswith(".md"):
                        agent_name = os.path.splitext(file)[0]
                        agents.append(agent_name)
            return agents
        except Exception as e:
            logger.error(f"Error listing agents: {e}")
            return []

    def _parse_frontmatter(self, content: str) -> Tuple[Dict[str, str], str]:
        """
        Parse frontmatter from markdown content.

        Args:
            content: The markdown content with frontmatter

        Returns:
            tuple: (metadata_dict, content_without_frontmatter)
        """
        if not content.startswith("---"):
            return {}, content

        # Find the second "---"
        parts = content.split("---", 2)
        if len(parts) < 3:
            return {}, content

        # Parse frontmatter
        frontmatter_content = parts[1].strip()
        agent_content = parts[2].strip()

        logger.info(f"Parsed frontmatter with {len(frontmatter_content)} characters")

        # Convert frontmatter to dictionary
        metadata_dict = {}
        for line in frontmatter_content.split("\n"):
            line = line.strip()
            if not line or ":" not in line:
                continue
            key, value = line.split(":", 1)
            metadata_dict[key.strip()] = value.strip()

        logger.info(f"Extracted metadata: {metadata_dict}")
        return metadata_dict, agent_content

    def _process_metadata(self, metadata_dict: Dict[str, Any]) -> dict:
        """
        Process and normalize metadata values.

        Args:
            metadata_dict: The metadata dictionary to process

        Returns:
            dict: Processed metadata dictionary
        """
        # Handle boolean values
        for field in ['command', 'discoverable']:
            if field in metadata_dict:
                if metadata_dict[field].lower() == 'true':
                    metadata_dict[field] = True
                elif metadata_dict[field].lower() == 'false':
                    metadata_dict[field] = False

        # Process model field
        if 'model' in metadata_dict:
            if metadata_dict['model'] == "default":
                provider_name = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_PROVIDER_NAME)
                model_name = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_MODEL_NAME)
                metadata_dict['model'] = f"{provider_name}/{model_name}"

        return metadata_dict

    def load_agent_metadata(self, agent_name: str) -> Optional[AgentDefinition]:
        """
        Loads an agent definition from the agents directory.

        Uses file locking via portalocker to handle concurrent access from multiple processes,
        preventing race conditions and ensuring data consistency.

        Args:
            agent_name: Name of the agent to load

        Returns:
            Optional[Agent]: Agent object if found, None otherwise
        """
        try:
            agent_file_path = os.path.join(self.agents_dir, f"{agent_name}.md")

            logger.info(f"Attempting to load agent from: {agent_file_path}")

            if not os.path.exists(agent_file_path):
                logger.warning(f"Agent file not found: {agent_file_path}")
                return None

            with open(agent_file_path, encoding="utf-8", mode="r") as f:
                portalocker.lock(f, portalocker.LOCK_SH)  # Acquire shared lock for reading
                content = f.read()

            logger.info(f"Loaded agent file with {len(content)} characters")

            # Parse frontmatter and content
            metadata_dict, agent_content = self._parse_frontmatter(content)
            if not metadata_dict:
                logger.error(f"No frontmatter found in agent file: {agent_file_path}")
                return None

            # Process metadata fields
            metadata_dict = self._process_metadata(metadata_dict)

            # Create metadata object
            try:
                metadata = AgentMetadata(**metadata_dict)
                agent = AgentDefinition(
                    metadata=metadata,
                    content=agent_content,
                    file_path=agent_file_path
                )
                logger.info(f"Successfully loaded agent: {agent_name}")
                return agent
            except ValidationError as e:
                logger.error(f"Validation error in agent metadata: {e}")
                return None

        except Exception as e:
            logger.error(f"Error loading agent {agent_name}: {e}", exc_info=True)
            return None

    def create_agent(self,
        agent_name: str,
        memory: Optional[Memory] = None,
        file_editor: Optional[FileEditor] = None,
        user_defined_rules: Optional[Dict[str, Any]] = None,
        agent_definition: Optional[AgentDefinition] = None,
        workspace_context: Optional[WorkspaceContext] = None
    ) -> SingleAgent:
        """
        Creates an agent instance from a given agent name or from a pre-loaded AgentDefinition instance.

        Args:
            agent_name (str): Name of the agent to load.
            memory (Optional[Memory]): Optional Memory instance for the agent. Defaults to None.
            file_editor (Optional[FileEditor]): Optional FileEditor instance for file operations.
            user_defined_rules (Optional[Dict[str, Any]]): Optional user-defined rules to include in the agent's context.
            agent_definition (Optional[AgentDefinition]): Optional pre-loaded agent definition to use instead of loading from file.
            workspace_context (Optional[WorkspaceContext]): Optional metadata about the workspace environment.

        Raises:
            ValueError: If the agent name is not found.

        Returns:
            SingleAgent: A configured SingleAgent instance.
        """
        if not agent_definition:
            agent_definition = self.load_agent_metadata(agent_name)

        if agent_definition is None:
            raise ValueError(f"Agent definition not found: {agent_name}")

        if memory is None:
            memory = TokenLimitedMemory(capacity=MEMORY_DEFAULT_TOKEN_LIMIT)

        # These will be set by default if not provided
        provider_name, model_name = agent_definition.metadata.model.split("/")

        # Parse tools from comma-delimited string to list
        agent_tools, excluded_tools = self._parse_tools_list(agent_definition.metadata.tools)

        tools_log_msg = (
            "Using default tools" if agent_tools is None
            else f"Using tools: {agent_tools}"
        )
        if excluded_tools:
            tools_log_msg += f" (excluding: {excluded_tools})"

        logger.info(f"{tools_log_msg} for agent {agent_name}")

        return self.shared_state.create_configured_single_agent(
            provider_name=provider_name,
            model_name=model_name,
            memory=memory,
            file_editor=file_editor,
            user_defined_rules=user_defined_rules,
            agent_prompt=agent_definition.content,
            agent_tools=agent_tools,
            excluded_tools=excluded_tools,
            workspace_context=workspace_context
        )

    def initialize_default_agents(self, preferences: dict = None, force: bool = False) -> None:
        """
        Initializes default agents from package resources if they don't exist.

        This method ensures that default agents are always available by copying agent
        markdown files from the package resources to the agents directory, unless the
        files already exist. The copying behavior is controlled by the
        CODA_COPY_DEFAULT_AGENTS environment variable.

        File operations use portalocker to handle concurrent access from multiple processes,
        preventing race conditions and ensuring file integrity.

        Args:
            preferences (dict, optional): Unused. Present for future compatibility.

        Returns:
            None
        """
        if self._default_agents_initialized and not force:
            logger.debug("Default agents already initialized; skipping copy step.")
            return

        try:
            # Determine if copying of default agents is enabled
            should_copy_default_agents = SETTINGS.get_env_var(EnvConfig.CODA_COPY_DEFAULT_AGENTS) == 'true'
            logger.info(f"Initializing default agents in directory: {self.agents_dir}")
            # Use importlib.resources to access the agent prompts
            resources = importlib.resources.files(AGENTS_PACKAGE_NAME)
            resource_files = [f for f in resources.iterdir() if f.name.endswith(".md")]
        except Exception as e:
            logger.error(f"Error accessing default agent resources: {e}", exc_info=True)
            return

        for resource in resource_files:
            try:
                agent_file = resource.name
                dest_path = os.path.join(self.agents_dir, agent_file)
                agent_name = re.sub(r'\.md$', '', agent_file)

                # overwrite built-in agent definition if should_copy_default_agents is true
                if should_copy_default_agents and agent_name in DEFAULT_AGENTS:
                    # Read content from resource and write to destination
                    with resource.open("r", encoding="utf-8") as src_file:
                        content = src_file.read()
                        # Use portalocker to lock the file during writing to prevent race conditions
                        # when multiple processes try to access it simultaneously
                        with open(dest_path, encoding="utf-8", mode="w") as dest_file:
                            portalocker.lock(dest_file, portalocker.LOCK_EX)  # Acquire exclusive lock for writing
                            dest_file.write(content)
                    logger.info(f"Overwrote default agent: {agent_file}")
                else:
                    logger.info(f"Skipped default agent: {agent_file}")
            except Exception as e:
                logger.error(f"Error processing default agent {resource.name}: {e}", exc_info=True)

        logger.info(f"Default agents initialization complete. Found {len(os.listdir(self.agents_dir))} agents.")
        self._default_agents_initialized = True

    def filter_agents_list(self, attribute: str = "command") -> List[AgentDefinition]:
        """
        Returns a filtered list of agents given an attribute

        Args:
            attribute: The attribute to filter by

        Returns:
            List[AgentDefinition]: List of agent objects
        """
        all_agents = []
        for agent_name in self.list_agents():
            agent_definition = self.load_agent_metadata(agent_name)
            if agent_definition and agent_definition.metadata.command:
                all_agents.append(agent_name)
        return all_agents

    def delete_agent(self, agent_name: str) -> bool:
        """
        Delete an agent by name.

        Args:
            agent_name (str): Name of the agent to delete

        Returns:
            bool: True if the agent was successfully deleted, False otherwise
        """
        try:
            agent_file_path = os.path.join(self.agents_dir, f"{agent_name}.md")
            logger.info(f"Attempting to delete agent: {agent_file_path}")

            if not os.path.exists(agent_file_path):
                logger.warning(f"Agent file not found: {agent_file_path}")
                return False

            # Delete the agent file
            os.remove(agent_file_path)

            logger.info(f"Successfully deleted agent: {agent_name}")
            return True

        except Exception as e:
            logger.error(f"Error deleting agent {agent_name}: {e}", exc_info=True)
            return False

    def list_all_agent_names(self, include_remote: bool = False) -> List[str]:
        """
        Return combined names for local agents and, optionally, remote GEAI agents.

        Notes:
            - Local agents always take precedence when names collide.
            - Remote names are appended only if not already present.
        """

        names: List[str] = []
        seen: set = set()

        # Local agents first (define precedence)
        try:
            for n in self.list_agents():
                if n not in seen:
                    names.append(n)
                    seen.add(n)
        except Exception as exc:
            logger.debug(f"Unable to list local agents: {exc}")

        # Optionally include remote agent names
        if include_remote:
            try:
                remote_agents = self.list_remote_agents_cached()
                for agent in remote_agents:
                    if agent.name not in seen:
                        names.append(agent.name)
                        seen.add(agent.name)
            except Exception as exc:
                logger.debug(f"Unable to list remote agents: {exc}")

        return names

    def list_remote_agents(
        self,
        status: str = "active",
        allow_drafts: bool = False,
        include_external: bool = False,
    ) -> List[Any]:
        """Return remote GEAI agents.

        Args:
            status: Agent status filter (default: "active")
            allow_drafts: Whether to include draft agents
            include_external: Whether to include external agents

        Returns:
            List of remote agent objects, empty list if not configured or on error
        """
        if not self.shared_state:
            logger.debug("Cannot list remote agents: shared_state not available")
            return []

        if not are_geai_credentials_available():
            return []

        try:
            agents = self.shared_state.geai_client.list_agents(
                status=status,
                allow_drafts=allow_drafts,
                include_external=include_external,
            )
            logger.info(f"Found {len(agents)} remote GEAI agents")
            return agents
        except Exception as exc:
            logger.error(f"Error listing remote GEAI agents: {exc}")
            return []

    def list_remote_agents_cached(
        self,
        ttl: int = 60,
        status: str = "active",
        allow_drafts: bool = False,
        include_external: bool = False,
    ) -> List[Any]:
        """Return remote agents with a simple TTL-based cache.

        Args:
            ttl: Cache time-to-live in seconds (default: 60)
            status: Agent status filter (default: "active")
            allow_drafts: Whether to include draft agents
            include_external: Whether to include external agents

        Returns:
            List of cached remote agent objects, empty list if not configured or on error
        """
        if not are_geai_credentials_available():
            return []

        now = time.time()
        if self._remote_agents_cache and (now - self._remote_agents_ts) < ttl:
            return self._remote_agents_cache

        agents = self.list_remote_agents(
            status=status,
            allow_drafts=allow_drafts,
            include_external=include_external,
        )
        self._remote_agents_cache = agents or []
        self._remote_agents_ts = now
        return self._remote_agents_cache

    def _get_remote_mentions_preferences(self) -> Tuple[str, set]:
        """Return (mode, allowlist_set) from shared env configuration."""
        mode = (SETTINGS.get_env_var(EnvConfig.CODA_REMOTE_MENTIONS_MODE) or "favorites").strip().lower()
        raw_allowlist = SETTINGS.get_env_var(EnvConfig.CODA_REMOTE_MENTIONS_ALLOWLIST) or ""
        allowlist = {item.strip() for item in raw_allowlist.split(",") if item.strip()}
        return mode, allowlist

    def list_visible_remote_agents(self) -> List[Any]:
        """
        Return remote agents filtered by remote mentions preferences.

        Modes:
        - all: include every remote agent
        - none: include none
        - favorites (default): only include names in the allowlist
        """
        mode, allowlist = self._get_remote_mentions_preferences()
        remote_agents = self.list_remote_agents_cached()

        if mode == "all":
            return remote_agents
        if mode == "none":
            return []
        return [agent for agent in remote_agents if getattr(agent, "name", None) in allowlist]

    def build_available_agent_names(self) -> List[str]:
        """
        Combine local agent names with visible remote names using remote mention prefs.

        Returns:
            Ordered list of unique agent names (local + filtered remote).
        """
        names: List[str] = []
        seen = set()

        try:
            local_names = self.list_agents()
        except Exception as exc:
            logger.debug(f"Unable to list local agents: {exc}")
            local_names = []

        try:
            remote_names = [a.name for a in self.list_visible_remote_agents()]
        except Exception as exc:
            logger.debug(f"Unable to load visible remote agents: {exc}")
            remote_names = []

        for name in local_names + remote_names:
            if name not in seen:
                names.append(name)
                seen.add(name)

        return names

    def create_remote_geai_agent(
        self,
        name_or_id: str,
        memory: Optional[Memory] = None,
    ) -> SingleAgent:
        """Create a `SingleAgent` that proxies a remote GEAI agent.

        Args:
            name_or_id: The name or ID of the remote GEAI agent
            memory: Optional Memory instance. Defaults to TokenLimitedMemory if not provided

        Returns:
            SingleAgent: A configured SingleAgent instance proxying the remote GEAI agent

        Raises:
            ValueError: If shared_state is not available
        """
        if not self.shared_state:
            raise ValueError("AgentManager requires shared_state to create remote agents")

        if memory is None:
            memory = TokenLimitedMemory(capacity=MEMORY_DEFAULT_TOKEN_LIMIT)

        return self.shared_state.create_configured_single_agent(
            provider_name="saia",
            model_name="agent",
            memory=memory,
            file_editor=None,
            agent_tools=[],
            llm_params={"model": f"saia:agent:{name_or_id}"},
            use_coda_system_prompt=False,
        )

    def parse_user_message(self, user_message: str) -> List[Dict[str, str]]:
        """
        Parses a user message to identify and extract commands addressed to agents.

        This method scans the input message for references to known agents in the format "@agent-name [input]".
        It returns a list of dictionaries, each containing the agent's name and the associated user input (if any).
        When GEAI is configured, remote agent names are included alongside local agents, with local agents taking
        precedence when there is a name collision.

        Args:
            user_message (str): The message from the user potentially containing agent commands.

        Returns:
            List[Dict[str, str]]: A list where each item is a dictionary with 'agent_name' and 'user_input' keys,
            representing each agent command found in the user message.

        Example:
            >>> agent_manager.parse_user_message("@diagnose fix this bug @fix")
            [
                {'agent_name': 'diagnose', 'user_input': 'fix this bug'},
                {'agent_name': 'fix', 'user_input': ''},
            ]
        """
        available_agents = self.list_all_agent_names(include_remote=True)
        return parse_user_message_for_agents(user_message, available_agents)
