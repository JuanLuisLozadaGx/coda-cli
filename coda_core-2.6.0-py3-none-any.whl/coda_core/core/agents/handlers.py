from typing import Dict, Any
from loguru import logger

from coda_core.core.memories.errors.exceptions import MemoryCapacityError
from coda_core.core.agents.utils import get_tailored_guidance
from coda_core.core.agents.types import MemoryErrorStrategy, MemoryOperationKind

from coda_core.core.memories.base import Memory


def handle_condense_suggestion(memory: Memory, error: MemoryCapacityError, kind: MemoryOperationKind, retry_count: int, has_tool_calls: bool = False) -> Dict[str, Any]:
    """Handle condense action by attempting memory condensation to free space.
    
    This handler is invoked when the memory assessment determines that condensation
    might resolve the capacity issue. It attempts to run the memory condenser to
    summarize older conversation history, potentially freeing enough tokens to
    allow the current operation to proceed.
    
    The handler implements several safeguards:
    - Prevents retry loops by only attempting condensation on the first try
    - Falls back to insufficient capacity handling if no condenser is available
    - Forces condensation (bypasses threshold checks) when assessment recommends it
    - Measures actual tokens freed vs tokens needed to determine success
    - Preserves tool call context through all fallback paths
    
    Success Scenarios:
    - Condensation frees enough tokens: Returns handled=True, retry=True
    - Condensation helps but insufficient: Returns guidance for user/LLM
    - Condensation fails/unavailable: Delegates to insufficient capacity handler
    
    This approach eliminates the architectural mismatch between assessment and condenser
    systems by trusting the assessment recommendation and forcing condensation.
    
    Args:
        memory: Memory instance (for token counting and condensation operations)
        error: The memory capacity error containing assessment details
        kind: Type of memory storage operation (MemoryOperationKind enum value)
        retry_count: Number of retries attempted so far (prevents infinite loops)
        has_tool_calls: Whether the original message had tool calls (for guidance context)
        
    Returns:
        Dict containing recovery strategy and guidance with keys:
            - handled: bool - Whether the error was successfully resolved
            - retry: bool - Whether the operation should be retried immediately
            - strategy: str - The strategy used ("condensation", "condensation_attempted")
            - guidance: str or None - User/LLM guidance message (None if handled)
            - metadata: dict - Logging metadata (tokens_needed, tokens_freed, etc.)
    """
    # Prevent retry loops - only attempt condense on first try
    if retry_count > 0:
        logger.warning("Condense already attempted, treating as insufficient capacity")
        return handle_insufficient_capacity(error=error, kind=kind, has_tool_calls=has_tool_calls)
        
    if not memory.condenser:
        logger.warning("Condenser suggested but not available, treating as insufficient capacity")
        return handle_insufficient_capacity(error=error, kind=kind, has_tool_calls=has_tool_calls)
    
    try:
        # Handle edge case where no tokens need to be freed
        tokens_needed = error.assessment.tokens_to_free
        if tokens_needed == 0:
            logger.info("No tokens need to be freed, treating as success")
            return {
                "handled": True,
                "retry": True,
                "strategy": MemoryErrorStrategy.CONDENSATION.value,
                "guidance": None,
                "metadata": {
                    "tokens_needed": 0,
                    "removable_tokens": error.assessment.removable_tokens,
                    "tokens_freed": 0,
                    "overflow": None
                }
            }
        
        initial_tokens = memory.token_count
        
        # Force condensation as per assessment recommendation
        condensation_result = memory.check_and_condense(force=True)
        final_tokens = memory.token_count
        
        # Check if condensation was actually performed
        metadata = condensation_result.get("metadata", {})
        was_skipped = metadata.get("skipped", False)
        if was_skipped:
            skip_reason = metadata.get("reason", "Unknown")
            logger.warning(f"Condensation was skipped: {skip_reason}")
            # Delegate to insufficient capacity handling for cleaner logic
            return handle_insufficient_capacity(error=error, kind=kind, has_tool_calls=has_tool_calls)
        
        # Use both token count delta and metadata for accuracy
        tokens_freed_delta = initial_tokens - final_tokens
        tokens_freed_metadata = metadata.get("tokens_removed", 0)
        tokens_freed = max(tokens_freed_delta, tokens_freed_metadata)  # Use the larger value for safety
        
        # Log both values for forensic clarity
        if tokens_freed_delta != tokens_freed_metadata:
            logger.debug(f"Token count discrepancy - delta: {tokens_freed_delta}, metadata: {tokens_freed_metadata}, using: {tokens_freed}")
        
        if tokens_freed >= tokens_needed:
            logger.info(f"Condensation freed {tokens_freed} tokens (needed {tokens_needed}) [delta: {tokens_freed_delta}, metadata: {tokens_freed_metadata}]")
            logger.info(f"guidance_event kind={kind} strategy=condensation tokens_needed={tokens_needed} removable={error.assessment.removable_tokens} tokens_freed={tokens_freed} overflow=None capacity_limit={error.assessment.capacity_limit} current_tokens={error.assessment.current_tokens}")
            return {
                "handled": True,
                "retry": True,
                "strategy": MemoryErrorStrategy.CONDENSATION.value,
                "guidance": None,
                "metadata": {
                    "tokens_needed": tokens_needed,
                    "removable_tokens": error.assessment.removable_tokens,
                    "tokens_freed": tokens_freed,
                    "overflow": None
                }
            }
        else:
            remaining = tokens_needed - tokens_freed
            # Use remaining tokens for consistency between guidance and metadata
            effective_tokens_needed = remaining if remaining > 0 else tokens_needed
            
            guidance = get_tailored_guidance(
                kind=kind,
                scenario=MemoryErrorStrategy.CONDENSATION_ATTEMPTED.value,
                tokens_needed=effective_tokens_needed,
                removable_tokens=error.assessment.removable_tokens,
                tokens_freed=tokens_freed,
                overflow=None,
                capacity_limit=error.assessment.capacity_limit,
                current_tokens=error.assessment.current_tokens
            )
            logger.info(f"guidance_event kind={kind} strategy=condensation_attempted tokens_needed={effective_tokens_needed} removable={error.assessment.removable_tokens} tokens_freed={tokens_freed} overflow=None capacity_limit={error.assessment.capacity_limit} current_tokens={error.assessment.current_tokens}")
            return {
                "handled": False,
                "retry": False,
                "strategy": MemoryErrorStrategy.CONDENSATION_ATTEMPTED.value,
                "guidance": guidance,
                "metadata": {
                    "tokens_needed": effective_tokens_needed,
                    "removable_tokens": error.assessment.removable_tokens,
                    "tokens_freed": tokens_freed,
                    "overflow": None
                }
            }
    except MemoryCapacityError as e:
        logger.error(f"Condensation failed with MemoryCapacityError: {e}")
        return handle_insufficient_capacity(error=error, kind=kind, has_tool_calls=has_tool_calls)
    except Exception as e:
        logger.error(f"Error in handle_condense_suggestion: {e}")
        # Return a safe fallback response instead of delegating to another handler
        return {
            "handled": False,
            "retry": False,
            "strategy": MemoryErrorStrategy.UNEXPECTED_ERROR.value,
            "guidance": f"Memory condensation failed due to an internal error: {str(e)}",
            "metadata": {
                "error": str(e),
                "error_type": type(e).__name__,
                "tokens_needed": error.assessment.tokens_to_free,
                "removable_tokens": error.assessment.removable_tokens
            }
        }


def handle_insufficient_capacity(error: MemoryCapacityError, kind: MemoryOperationKind, has_tool_calls: bool = False) -> Dict[str, Any]:
    """Handle insufficient removable capacity scenarios with intelligent guidance routing.
    
    This handler is invoked when memory capacity cannot be resolved through condensation
    or when no condenser is available. It generates tailored guidance messages that are
    intelligently routed based on the operation type and context.
    
    The handler implements the Enhanced Guidance System's core routing logic:
    - For user input operations: Returns guidance directly to the user
    - For assistant operations: Injects guidance into memory for LLM regeneration
    - Includes tool call reminders when the original message had tool calls
    - Implements regeneration guard (only generates guidance when tokens_needed > 0)
    
    Guidance Generation:
    - Calculates target token reduction for assistant regeneration (80-250 tokens)
    - Provides context-aware suggestions (shorter response, fewer details, etc.)
    - Includes tool call reminders for assistant messages that had tool calls
    - Uses different wording for user vs assistant guidance
    
    This handler never resolves the error (handled=False) but provides actionable
    guidance for users or enables LLM self-correction through regeneration.
    
    Args:
        error: The memory capacity error containing assessment and token details
        kind: Type of memory storage operation (MemoryOperationKind enum value, determines guidance routing)
        has_tool_calls: Whether the original message had tool calls (affects guidance content)
        
    Returns:
        Dict containing recovery strategy and guidance with keys:
            - handled: bool - Always False (guidance-only, doesn't resolve error)
            - retry: bool - Always False (no automatic retry, requires user/LLM action)
            - strategy: str - Always "insufficient_capacity_guidance"
            - guidance: str - Tailored guidance message for user or LLM injection
            - metadata: dict - Logging metadata (tokens_needed, removable_tokens, etc.)
    """
    assessment = error.assessment
    tokens_needed = assessment.tokens_to_free
    
    # Handle edge case: if no tokens need to be freed, treat as resolved no-op
    # Note: This should be rare
    if tokens_needed == 0:
        logger.info(f"No token deficit for {kind}, treating as resolved (original message still needs storing)")
        logger.info(f"guidance_event kind={kind} strategy=insufficient_capacity_no_deficit tokens_needed=0 removable={assessment.removable_tokens} tokens_freed=None overflow=None capacity_limit={assessment.capacity_limit} current_tokens={assessment.current_tokens}")
        return {
            "handled": True,
            "retry": True,  # Original message was never stored due to exception, retry needed
            "strategy": MemoryErrorStrategy.INSUFFICIENT_CAPACITY_NO_DEFICIT.value,
            "guidance": None,
            "metadata": {
                "tokens_needed": 0,
                "removable_tokens": assessment.removable_tokens,
                "tokens_freed": None,  # No freeing step performed
                "overflow": None
            }
        }
    
    logger.warning(f"Insufficient capacity for {kind}: need {tokens_needed} tokens, only {assessment.removable_tokens} removable")

    guidance = get_tailored_guidance(
        kind=kind,
        scenario=MemoryErrorStrategy.INSUFFICIENT_CAPACITY_GUIDANCE.value,
        tokens_needed=tokens_needed,
        removable_tokens=assessment.removable_tokens,
        tokens_freed=None,
        overflow=None,
        capacity_limit=assessment.capacity_limit,
        current_tokens=assessment.current_tokens,
        has_tool_calls=has_tool_calls
    )

    logger.info(
        f"guidance_event kind={kind} strategy=insufficient_capacity_guidance "
        f"tokens_needed={tokens_needed} removable={assessment.removable_tokens} "
        f"tokens_freed=None overflow=None capacity_limit={assessment.capacity_limit} "
        f"current_tokens={assessment.current_tokens}"
    )
    return {
        "handled": False,
        "retry": False,
        "strategy": MemoryErrorStrategy.INSUFFICIENT_CAPACITY_GUIDANCE.value,
        "guidance": guidance,
        "metadata": {
            "tokens_needed": tokens_needed,
            "removable_tokens": assessment.removable_tokens,
            "tokens_freed": None,
            "overflow": None
        }
    }


def handle_oversized_message(error: MemoryCapacityError, kind: MemoryOperationKind) -> Dict[str, Any]:
    """Handle oversized messages that exceed memory capacity limits entirely.
    
    This handler is invoked when a single message (typically user input) is too large
    to fit in memory even if all removable content were deleted. This represents a
    fundamental capacity constraint that cannot be resolved through condensation or
    memory management - the message itself must be shortened.
    
    Oversized Message Scenarios:
    - User input exceeds the total memory capacity
    - Assistant response is too large for available space
    - Tool response contains excessive content
    
    The handler calculates the overflow amount (tokens over the limit) and generates
    specific guidance asking the user to shorten their message by that amount. Unlike
    insufficient capacity scenarios, this always requires direct user intervention
    since no amount of memory management can resolve the issue.
    
    Key Characteristics:
    - Always requires user action (never resolved automatically)
    - Provides specific token reduction targets
    - Cannot be resolved through condensation or memory cleanup
    - Represents a hard limit violation rather than capacity management issue
    
    Args:
        error: The memory capacity error containing assessment and overflow details
        kind: Type of memory storage operation (MemoryOperationKind enum value, typically USER_INPUT for oversized)
        
    Returns:
        Dict containing recovery strategy and guidance with keys:
            - handled: bool - Always False (requires user intervention)
            - retry: bool - Always False (user must modify input first)
            - strategy: str - Always "oversized_guidance"
            - guidance: str - Specific guidance with token reduction target
            - metadata: dict - Logging metadata including overflow amount
    """
    assessment = error.assessment
    overflow = assessment.message_tokens - assessment.capacity_limit
    if overflow <= 0:
        # Defensive fallback
        return handle_insufficient_capacity(error=error, kind=kind, has_tool_calls=False)
    
    guidance = get_tailored_guidance(
        kind=kind,
        scenario=MemoryErrorStrategy.OVERSIZED_GUIDANCE.value,
        tokens_needed=None,
        removable_tokens=None,
        tokens_freed=None,
        overflow=overflow,
        capacity_limit=assessment.capacity_limit,
        current_tokens=assessment.current_tokens
    )
    logger.info(f"guidance_event kind={kind} strategy=oversized_guidance tokens_needed=None removable=None tokens_freed=None overflow={overflow} capacity_limit={assessment.capacity_limit} current_tokens={assessment.current_tokens}")
    return {
        "handled": False,
        "retry": False,
        "strategy": MemoryErrorStrategy.OVERSIZED_GUIDANCE.value,
        "guidance": guidance,
        "metadata": {
            "tokens_needed": None,
            "removable_tokens": None,
            "tokens_freed": None,
            "overflow": overflow
        }
    }


def handle_unknown_action(error: MemoryCapacityError, kind: MemoryOperationKind) -> Dict[str, Any]:
    """Handle unknown or unexpected assessment actions with robust fallback guidance.
    
    This handler serves as a safety net for scenarios where the memory assessment
    system produces an action that isn't recognized by the handler routing logic.
    This should rarely occur in normal operation but provides graceful degradation
    when new assessment actions are added or unexpected edge cases arise.
    
    Fallback Strategy:
    - Logs the unknown action for debugging and system monitoring
    - Provides generic guidance about memory capacity issues
    - Never attempts to resolve the error (handled=False)
    - Includes full assessment metadata for troubleshooting
    
    This handler ensures that memory capacity errors never go completely unhandled,
    even when the assessment system produces unexpected results. It maintains
    system stability while providing observability for debugging.
    
    Typical Scenarios:
    - New assessment actions added but handlers not updated
    - Corrupted or malformed assessment data
    - Edge cases in assessment logic producing unexpected actions
    - Development/testing scenarios with experimental assessment logic
    
    Args:
        error: The memory capacity error with unknown assessment action
        kind: Type of memory storage operation (MemoryOperationKind enum value, for context in guidance)
        
    Returns:
        Dict containing fallback strategy and guidance with keys:
            - handled: bool - Always False (unknown actions cannot be resolved)
            - retry: bool - Always False (requires investigation/user action)
            - strategy: str - Always "unknown_action"
            - guidance: str - Generic guidance about memory capacity issues
            - metadata: dict - Full assessment metadata for debugging
    """
    assessment = error.assessment
    
    # Enhanced logging for unknown action observability
    logger.info(f"guidance_event kind={kind} strategy=unknown_action tokens_needed={assessment.tokens_to_free} removable={assessment.removable_tokens} tokens_freed=None overflow=None capacity_limit={assessment.capacity_limit} current_tokens={assessment.current_tokens}")
    
    return {
        "handled": False,
        "retry": False,
        "strategy": MemoryErrorStrategy.UNKNOWN_ACTION.value,
        "guidance": f"Unknown memory assessment action: {assessment.action}",
        "metadata": {
            "tokens_needed": assessment.tokens_to_free,
            "removable_tokens": assessment.removable_tokens,
            "tokens_freed": None,
            "overflow": None
        }
    }