from typing import Dict, List, Optional
from pydantic import BaseModel, ConfigDict, Field

class AgentMetadata(BaseModel):
    """
    Validates agent metadata from frontmatter
    """
    name: str = Field(..., description="Name of the agent")
    description: str = Field(..., description="Description of what the agent does")
    tools: str = Field("default", description="Tools available to the agent")
    model: str = Field("default", description="Provider and LLM model-name to use for the agent")
    command: bool = Field(True, description="Whether the agent is available as a command")
    discoverable: bool = Field(True, description="Whether the agent is available as a tool for the single agent")
    
    model_config = ConfigDict(extra="ignore")

class AgentDefinition(BaseModel):
    """
    Represents a complete agent with metadata and content
    """
    metadata: AgentMetadata = Field(..., description="Agent metadata from frontmatter")
    content: str = Field(..., description="Content of the agent prompt")
    file_path: Optional[str] = Field(None, description="Path to the agent file")