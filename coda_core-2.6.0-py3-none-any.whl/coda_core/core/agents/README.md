# Agents Module

## Overview

The Agents Module provides the core AI agent functionality for the CODA system. It defines the architecture and implementation for AI agents that can process user messages, use tools, and generate responses. The agents serve as the central orchestrators that connect language models, tools, and memory systems to create an interactive and helpful AI assistant.

Key capabilities of the agents include:

- Processing user messages and generating contextual responses
- Using tools to perform actions (file operations, shell commands, etc.)
- Maintaining conversation history and context
- Intelligent error recovery with automatic classification and recovery strategies
- Handling errors and edge cases gracefully with automatic retry logic
- Assessing risk for potentially dangerous operations
- Memory reduction recovery for context limit errors
- Exponential backoff recovery for rate limits and service issues

## Architecture

The Agents Module follows a hierarchical class structure with a base abstract class and concrete implementations:

```mermaid
classDiagram
    class BaseAgent {
        <<abstract>>
        +id: UUID
        +tools: List
        +llm: LLM
        +memory: Memory
        +get_response()**
    }
    
    class SingleAgent {
        +tool_choice: str
        +max_iterations: int
        +get_response()
        +_parse_llm_response()
        +_parse_message_content()
        +_parse_tool_requests()
        +_call_tool()
        +_parse_metadata()
        +_get_stop_reason()
        +_assess_bash_command_risk()
        +_safe_store()
        +_inject_guidance()
        +_handle_memory_capacity_error()
    }
    
    class MemoryHandlers {
        <<module>>
        +handle_condense_suggestion()
        +handle_insufficient_capacity()
        +handle_oversized_message()
        +handle_unknown_action()
    }
    
    class GuidanceUtils {
        <<module>>
        +get_tailored_guidance()
    }
    
    class AgentManager {
        +agents_dir: str
        +shared_state: SharedState
        +list_agents()
        +load_agent_metadata()
        +create_agent()
        +initialize_default_agents()
        +filter_agents_list()
        +delete_agent()
        +parse_user_message()
    }
    
    BaseAgent <|-- SingleAgent
    SingleAgent --> MemoryHandlers : uses
    SingleAgent --> GuidanceUtils : uses
    MemoryHandlers --> GuidanceUtils : uses
    AgentManager --> SingleAgent : creates
```

The agent processing flow follows this pattern:

```mermaid
sequenceDiagram
    participant User
    participant Agent
    participant LLM
    participant Tool
    participant Memory
    
    User->>Agent: Send message
    Agent->>Memory: Add user message
    Agent->>LLM: Request response with tools
    LLM-->>Agent: Return response with tool calls
    
    alt Tool calls present
        Agent->>Tool: Execute tool
        Tool-->>Agent: Return tool result
        Agent->>Memory: Add tool result
        Agent->>LLM: Request next response
        LLM-->>Agent: Return final response
    end
    
    Agent->>Memory: Add assistant response
    Agent-->>User: Return response
```

## Core Components

### BaseAgent

The `BaseAgent` abstract base class defines the interface that all agent implementations must follow:

- `id`: A unique identifier for the agent instance
- `tools`: A list of tools available to the agent
- `llm`: The language model used by the agent
- `memory`: A memory system for storing conversation history
- `get_response()`: Abstract method that processes user input and generates a response

### SingleAgent

The `SingleAgent` class extends `BaseAgent` to provide a concrete implementation:

- Processes user messages and generates responses
- Uses tools to perform actions
- Maintains conversation history
- Handles errors and edge cases
- Supports callbacks for monitoring and interaction

Key methods include:

| Method | Purpose | Description |
|--------|---------|-------------|
| `get_response()` | Process user messages | Main entry point that handles the conversation flow |
| `_parse_llm_response()` | Extract information from LLM responses | Parses content, tool calls, and metadata |
| `_parse_message_content()` | Extract message content | Gets the assistant's message text |
| `_parse_tool_requests()` | Extract tool calls | Identifies and formats tool call information |
| `_call_tool()` | Execute tools | Calls the appropriate tool with arguments and handles errors |
| `_parse_metadata()` | Extract metadata | Gets model, usage, and other metadata |
| `_get_stop_reason()` | Handle LLM stop conditions | Extracts and validates finish_reason, returns structured error with recovery guidance for length/content_filter |
| `_assess_bash_command_risk()` | Security assessment | Evaluates risk level of bash commands |
| `_safe_store()` | Safe memory operations | Handles memory storage with assessment, recovery, and guidance |
| `_inject_guidance()` | Guidance injection | Injects tailored guidance for LLM regeneration scenarios |
| `_handle_memory_capacity_error()` | Memory error routing | Routes memory capacity errors to appropriate handlers |
| `add_tools()` | Add tools to agent | Dynamically adds tools to the agent during a session |
| `remove_tools()` | Remove tools from agent | Dynamically removes tools from the agent during a session |
| `update_tools()` | Update agent tools | Updates the agent's tools and regenerates tool definitions |
| `generate_tool_transition_message()` | Create transition message | Generates a message explaining tool changes |

### AgentManager

The `AgentManager` class manages agent definitions and handles the creation and management of agent instances:

- Loads agent definitions from markdown files with frontmatter metadata
- Creates properly configured SingleAgent instances
- Manages default agents and initializes them if needed
- Provides filtering and management of agent definitions
- Parses user messages to identify agent commands

Key methods include:

| Method | Purpose | Description |
|--------|---------|-------------|
| `list_agents()` | List available agents | Returns a list of all agent names available in the agents directory |
| `load_agent_metadata()` | Load agent definition | Loads an agent definition from the agents directory with its metadata |
| `create_agent()` | Create agent instance | Creates a SingleAgent instance with the specified configuration |
| `initialize_default_agents()` | Initialize default agents | Copies default agent definitions from package resources if needed |
| `filter_agents_list()` | Filter agents by attribute | Returns a filtered list of agents based on an attribute |
| `delete_agent()` | Delete an agent | Removes an agent definition file and associated resources |
| `parse_user_message()` | Parse agent commands | Extracts agent commands from user messages in format "@agent-name [input]" |

## Key Features

### Memory Condensing Integration

The SingleAgent integrates with the memory condensing system to optimize token usage during long conversations:

- Initializes the memory condenser with appropriate callbacks for UI integration
- Checks for memory condensing before the first LLM call in the processing loop; additional condensation attempts occur only when storage assessment recommends it
- Provides visual feedback during the condensing process
- Shows token savings statistics after condensing
- Propagates memory condensing events to the UI
- Ensures conversation coherence is maintained during condensing

This integration allows the agent to maintain longer conversations without hitting token limits, while preserving essential context through intelligent summarization of older messages.

### Enhanced Memory Assessment Integration

The SingleAgent integrates deeply with the enhanced memory assessment system to provide intelligent, proactive memory management:

#### Pre-Flight Memory Assessment
- Performs pre-flight memory checks before storing any content using [`pre_flight_memory_check()`](../memories/base.py)
- Receives detailed [`MemoryAssessment`](../memories/schemas.py) with specific action recommendations
- Routes assessment actions to specialized handlers for optimal recovery strategies
- Prevents memory capacity errors through proactive assessment rather than reactive error handling

#### Assessment-Driven Storage Strategy
The agent uses assessment results to determine the optimal storage approach:

- **STORE_DIRECT**: Content fits within capacity limits - proceed with normal storage
- **EVICT_THEN_STORE**: Sufficient removable content exists - perform intelligent eviction first
- **SUGGEST_CONDENSE**: Memory condensing may resolve capacity issues - attempt condensation
- **REPORT_TO_AGENT**: Requires user intervention or LLM regeneration with guidance

#### Safe Storage Operations
All memory operations use the [`_safe_store()`](single_agent.py) method which provides:

- **Assessment Integration**: Pre-flight checks before every storage operation
- **Intelligent Recovery**: Automatic condensation attempts when recommended
- **Retry Logic**: Configurable retry attempts after successful recovery
- **Guidance Injection**: Automatic LLM guidance for regeneration scenarios
- **Error Propagation**: Clear error reporting when recovery is not possible

#### Storage Strategy Reference

The [`_safe_store()`](single_agent.py) method returns different strategies based on the outcome:

| Strategy | When Emitted | Next Agent Action |
|----------|--------------|-------------------|
| **direct_store** | Storage succeeded immediately | Continue with conversation flow |
| **condensation** | Condensation freed sufficient tokens | Continue with conversation flow |
| **condensation_attempted** | Condensation helped but insufficient | Inject guidance for LLM regeneration |
| **insufficient_capacity_guidance** | Not enough removable tokens | Inject guidance for LLM regeneration |
| **insufficient_capacity_no_deficit** | Zero tokens needed (edge case) | Continue with conversation flow |
| **oversized_guidance** | Message exceeds total capacity | Return guidance to user for input modification |
| **unexpected_error** | Non-memory error during storage | Log error and propagate to caller |
| **retry_exhausted** | Max retries exceeded | Log error and propagate to caller |

#### _safe_store Return Schema

The [`_safe_store()`](single_agent.py) method returns a dictionary with the following keys:

| Key | Type | Always Present | Description |
|-----|------|----------------|-------------|
| **success** | `bool` | ✅ | Whether the storage operation succeeded |
| **strategy** | `str` | ✅ | The strategy used (see table above) |
| **retry_count** | `int` | ✅ | Number of retries attempted for this operation |
| **error** | `str` | ❌ | Error message (only when success=False) |
| **recovery_strategy** | `str` | ❌ | Recovery strategy used (only when recovery was attempted) |
| **recovery_retry_count** | `int` | ❌ | Number of recovery-driven retries (only when recovery was attempted) |
| **guidance_injected** | `bool` | ❌ | Whether guidance was injected (only for non-user_input failures) |
| **metadata** | `dict` | ❌ | Additional metadata from handlers (tokens_needed, tokens_freed, etc.) |
| **prior_recovery_strategy** | `str` | ❌ | Previous recovery strategy (only when multiple recovery attempts made) |
| **prior_recovery_attempts** | `int` | ❌ | Previous recovery attempt count (only when multiple recovery attempts made) |

**Example Success Response:**
```python
{
    "success": True,
    "strategy": "condensation",
    "retry_count": 1,
    "recovery_strategy": "condensation",
    "recovery_retry_count": 1
}
```

**Example Failure Response:**
```python
{
    "success": False,
    "error": "Previous reply did not fit. Regenerate concise version ≤ 150 tokens.",
    "strategy": "insufficient_capacity_guidance",
    "metadata": {"tokens_needed": 2000, "removable_tokens": 500},
    "guidance_injected": True
}
```

### Tool Integration

The SingleAgent seamlessly integrates with the tools system:

- Formats tool definitions for LLM function calling
- Parses tool calls from LLM responses
- Executes tools with appropriate arguments
- Handles tool execution results and errors
- Provides tool results and error details back to the LLM for further processing
- Continues execution after non-critical errors
- Addresses the tool confusion problem with transition messages

### Tool Confusion Problem

The agent includes mechanisms to address the Tool Confusion Problem that occurs during dynamic tool management:

- **Problem**: When tools are referenced in conversation history but removed from the current tools array, the model may:
  - Attempt to call removed tools that were previously used successfully
  - Reference unavailable capabilities in its responses
  - Generate invalid tool calls resulting in API errors

- **Solution**: The `generate_tool_transition_message()` method creates explicit transition messages that:
  - Inform the model about tool changes (additions or removals)
  - Clarify which tools are currently available
  - Provide context for why capabilities may have changed
  - Are added to memory as system messages to guide the model's behavior

This approach ensures that the model maintains a consistent understanding of available tools throughout the conversation, even as the tool set changes dynamically.

### Memory Capacity Error Handling System

The SingleAgent implements a sophisticated memory capacity error handling system that provides intelligent recovery strategies and user guidance:

#### Specialized Error Handlers

The agent uses dedicated handlers from [`handlers.py`](handlers.py) for different memory capacity scenarios:

- **[`handle_condense_suggestion()`](handlers.py)**: Attempts memory condensation when assessment recommends it
- **[`handle_insufficient_capacity()`](handlers.py)**: Provides tailored guidance when capacity cannot be resolved
- **[`handle_oversized_message()`](handlers.py)**: Handles messages that exceed total memory capacity
- **[`handle_unknown_action()`](handlers.py)**: Fallback handler for unexpected assessment actions

#### Recovery Strategy Flow

```mermaid
flowchart TD
    A[Memory Storage Attempt] --> B[MemoryCapacityError]
    B --> C{Assessment Action}
    C -->|SUGGEST_CONDENSE| D[handle_condense_suggestion]
    C -->|REPORT_TO_AGENT| E[handle_insufficient_capacity]
    C -->|Unknown| F[handle_unknown_action]
    
    D --> G{Condensation Success?}
    G -->|Yes| H[Retry Storage]
    G -->|No| I[Generate Guidance]
    
    E --> I
    F --> I
    
    H --> J{Storage Success?}
    J -->|Yes| K[Continue Execution]
    J -->|No| I
    
    I --> L{Kind = user_input?}
    L -->|Yes| M[Return Guidance to User]
    L -->|No| N[Inject Guidance for LLM]
    
    style K fill:#90EE90
    style M fill:#FFE4B5
    style N fill:#87CEEB
```

#### Guidance Routing Details

The agent implements intelligent guidance routing based on operation type:

- **User Input Failures**: Guidance returned directly to user for message modification
- **Assistant Reply Failures**: Guidance injected as system message for LLM regeneration
- **Tool Response Failures**: Orphaned tool calls resolved, then guidance injected

### Agent Management System

The AgentManager provides a comprehensive system for managing different agent definitions:

- **Agent Definition Format**: Agents are defined in markdown files with YAML frontmatter for metadata
- **Dynamic Loading**: Agent definitions are loaded at runtime, allowing for easy modification and extension
- **Default Agent Management**: Built-in agents are automatically initialized when needed
- **User Command Parsing**: The system can parse user messages to identify commands directed at specific agents
- **Agent Creation**: Properly configured agent instances are created with appropriate LLMs, tools, and memory

This system makes it easy to define, customize, and manage different agent personalities and capabilities without modifying the core codebase.

### Conversation Management

The agent manages the full conversation flow:

- Adds user messages to memory
- Processes LLM responses
- Executes tools when needed
- Maintains conversation context
- Handles multi-turn interactions

### Risk Assessment

For potentially dangerous operations, the agent includes security measures:

- Assesses risk level of bash commands
- Provides risk information to the user
- Allows blocking of high-risk operations
- Logs security-related events

### Enhanced Guidance System

The SingleAgent implements an intelligent guidance system that provides context-aware instructions for memory capacity issues:

#### Tailored Guidance Generation

The [`get_tailored_guidance()`](utils.py) function generates specific guidance based on:

- **Operation Type**: Different guidance for user input vs assistant replies vs tool responses
- **Failure Scenario**: Oversized messages, insufficient capacity, or condensation attempts
- **Context Awareness**: Token counts, capacity limits, and tool call presence
- **Regeneration Targets**: Specific token reduction goals for assistant regeneration

#### Guidance Scenarios

| Scenario | Operation Type | Guidance Strategy |
|----------|---------------|-------------------|
| **Oversized Message** | User Input | "Message too large (exceeds by X tokens). Break into smaller parts." |
| **Oversized Message** | Assistant Reply | "Previous reply did not fit. Produce a much shorter version next turn." |
| **Oversized Message** | Tool Response | "Tool output too large. Re-run with narrower scope (filter/range)." |
| **Insufficient Capacity** | User Input | "Cannot store message: need X tokens, only Y removable. Summarize earlier steps." |
| **Insufficient Capacity** | Assistant Reply | "Previous reply did not fit. Regenerate concise version ≤ X tokens." |
| **Condensation Attempted** | Any | "Memory condensation freed X tokens, still need Y. Reduce verbosity." |

#### Guidance Injection Mechanism

The [`_inject_guidance()`](single_agent.py) method handles the injection of guidance messages into the conversation to enable agent self-correction. This is a critical component of the enhanced guidance system that allows the agent to recover from memory capacity errors through regeneration.

##### Injection Flow

```mermaid
flowchart TD
    A[Memory Storage Fails] --> B{Operation Kind?}
    B -->|USER_INPUT| C[Return Guidance to User]
    B -->|ASSISTANT_REPLY/FINAL| D[_inject_guidance]
    B -->|TOOL_RESPONSE/ERROR/SUCCESS| E[_inject_guidance]
    
    D --> F{Has Tool Calls?}
    F -->|Yes| G[Append Tool Call Reminder]
    F -->|No| H[Use Guidance As-Is]
    
    E --> I[Resolve Orphaned Tool Calls]
    I --> J[Inject Placeholder Responses]
    J --> K[Inject Guidance Message]
    
    G --> L[Inject as User Message (prefixed with CODA_SYSTEM_MESSAGE_PREFIX)]
    H --> L
    K --> L
    
    L --> M[Restart Iteration Loop]
    M --> N[LLM Regenerates Response]
    
    style C fill:#FFE4B5
    style N fill:#90EE90
```

##### Operation-Specific Behaviors

The injection mechanism adapts its behavior based on the type of operation that failed:

**Assistant Reply Failures** (`ASSISTANT_REPLY`, `ASSISTANT_FINAL`):
- The assistant message was never stored (failed before storage)
- No dangling tool calls exist in memory
- If `has_tool_calls=True`, appends a reminder: "If tool calls are still needed, reissue them."
- Guidance injected as a user message prefixed with `CODA_SYSTEM_MESSAGE_PREFIX`

**Tool Response Failures** (`TOOL_RESPONSE`, `TOOL_ERROR`, `TOOL_SUCCESS`):
- The assistant message with tool_calls WAS stored earlier
- Failed tool response leaves orphaned tool call IDs in memory
- **Critical**: Must resolve orphaned tool calls BEFORE injecting guidance
- Calls `memory.resolve_orphaned_tool_calls()` to insert placeholder failure responses
- Orphan message: "Tool execution aborted due to memory limits. Marking pending tool calls as failed."
- Then injects the tailored guidance message

**User Input Failures** (`USER_INPUT`, `TRANSITION`):
- Never invoke `_inject_guidance()` (guarded upstream in `_safe_store()`)
- Guidance returned directly to caller for user action

##### Tool Call Ordering Preservation

The injection mechanism ensures proper conversation flow by maintaining tool call ordering:

1. **For tool failures**: Orphaned tool calls are resolved first with placeholder responses
2. **For assistant failures with tools**: Reminder appended to encourage tool call reissuance
3. **System message prefix**: All injected guidance uses `CODA_SYSTEM_MESSAGE_PREFIX` for clarity

This prevents the LLM from seeing incomplete tool call sequences and ensures it understands the current state.

##### Injection Return Value

The method returns a boolean indicating injection success:
- `True`: Guidance successfully injected into memory
- `False`: Injection failed (logged as error)

When injection succeeds and the operation kind is not `USER_INPUT` or `TRANSITION`, the agent loop restarts via [`_should_continue_after_failure()`](single_agent.py), allowing the LLM to regenerate based on the injected guidance.

#### Intelligent Guidance Routing

The guidance system routes instructions based on operation context:

1. **User Input Failures**: Guidance returned directly to caller for user action
2. **Assistant Reply Failures**: Guidance injected via [`_inject_guidance()`](single_agent.py) for LLM regeneration
3. **Tool Response Failures**: Orphaned tool calls resolved first, then guidance injected

#### Regeneration Target Calculation

For assistant reply failures, the system calculates optimal regeneration targets:

```python
# Target token calculation for assistant regeneration
raw_available = capacity_limit - current_tokens
target = max(
    REGENERATION_TARGET_MIN_TOKENS,  # 80 tokens minimum
    min(
        REGENERATION_TARGET_MAX_TOKENS,  # 250 tokens maximum
        raw_available - REGENERATION_SAFETY_MARGIN  # 50 token safety buffer
    )
)
```

This ensures the LLM receives specific, achievable token reduction targets rather than vague "make it shorter" instructions.

### Memory Error Handlers

The agent system includes specialized handlers in [`handlers.py`](handlers.py) for different memory capacity scenarios:

#### Handler Functions

| Handler | Purpose | Recovery Strategy |
|---------|---------|-------------------|
| [`handle_condense_suggestion()`](handlers.py) | Attempt memory condensation | Force condensation, measure tokens freed, retry or provide guidance |
| [`handle_insufficient_capacity()`](handlers.py) | Generate tailored guidance | Calculate regeneration targets, route guidance appropriately |
| [`handle_oversized_message()`](handlers.py) | Handle messages exceeding capacity | Calculate overflow, provide specific reduction targets |
| [`handle_unknown_action()`](handlers.py) | Fallback for unexpected actions | Log unknown action, provide generic guidance |

#### Condensation Handler Logic

The [`handle_condense_suggestion()`](handlers.py) implements sophisticated condensation logic:

```python
# Prevent retry loops - only attempt condense on first try
if retry_count > 0:
    return handle_insufficient_capacity(error=error, kind=kind, has_tool_calls=has_tool_calls)

# Force condensation as per assessment recommendation
condensation_result = memory.check_and_condense(force=True)
tokens_freed = max(tokens_freed_delta, tokens_freed_metadata)

if tokens_freed >= tokens_needed:
    return {"handled": True, "retry": True, "strategy": "condensation"}
else:
    # Generate guidance for remaining deficit
    return {"handled": False, "retry": False, "strategy": "condensation_attempted"}
```

#### Guidance Generation Integration

All handlers integrate with [`get_tailored_guidance()`](utils.py) to provide context-specific instructions:

- **Scenario-based**: Different guidance for oversized, insufficient capacity, and condensation scenarios
- **Operation-aware**: Tailored messages for user input vs assistant replies vs tool responses
- **Token-specific**: Includes exact token counts and reduction targets
- **Tool-aware**: Reminds about tool call reissuance when applicable

### Finish Reason Handling

The [`_get_stop_reason()`](single_agent.py) method processes LLM finish_reason values and provides structured error handling with recovery guidance:

#### Structured Error Response

The method returns a dictionary with the following structure:

**Success Response** (finish_reason is valid):
```python
{
    "success": True,
    "finish_reason": "stop"  # or "tool_calls"
}
```

**Error Response** (finish_reason indicates a problem):
```python
{
    "success": False,
    "error": {
        "code": StopReasonCode.LENGTH,  # Normalized error code
        "message": "LLM response was truncated due to token limit.",
        "finish_reason": "length"
    },
    "recoverable": True,  # Only for length/content_filter
    "guidance": "Previous response was truncated..."  # Recovery instructions
}
```

#### Finish Reason Categories

| Finish Reason | Success | Recoverable | Behavior |
|---------------|---------|-------------|----------|
| `stop` | ✅ | N/A | Normal completion - continue conversation flow |
| `tool_calls` | ✅ | N/A | Tool calls requested - execute tools and continue |
| `length` | ❌ | ✅ | Token limit exceeded - inject guidance for regeneration |
| `content_filter` | ❌ | ✅ | Content policy violation - inject guidance for safe regeneration |
| `null`/missing | ❌ | ❌ | Missing finish_reason - log error and fail |
| unexpected | ❌ | ❌ | Unknown finish_reason - log error and fail |

#### Recovery Guidance for Recoverable Errors

For `length` and `content_filter` finish reasons, the method includes specific guidance:

**Length Truncation**:
```
"Previous response was truncated due to token limits. Regenerate a concise answer
that fits within the token limit. If tool calls are still needed, reissue only
essential calls with minimal arguments."
```

**Content Filter**:
```
"Previous response was blocked by content restrictions. Regenerate a safe,
policy-compliant answer that avoids restricted content."
```

#### Integration with Guidance System

When a recoverable finish_reason error occurs:
1. [`_get_stop_reason()`](single_agent.py) returns the structured error with guidance
2. [`get_response()`](single_agent.py) detects `recoverable=True` in the result
3. Guidance is injected via [`_inject_guidance()`](single_agent.py)
4. Agent loop restarts, allowing LLM to regenerate based on the guidance

This provides automatic recovery from token limit and content filter issues without user intervention.

### Error Recovery System

The SingleAgent includes a sophisticated error recovery system that automatically handles LLM errors and attempts intelligent recovery strategies:

#### Error Recovery Integration

The agent integrates with the [models error submodule](../models/errors/) to provide automatic error recovery:

```mermaid
sequenceDiagram
    participant Agent as SingleAgent
    participant LLM as ChatLLM
    participant Recovery as Error Recovery
    participant Memory as Memory
    
    Agent->>LLM: generate_response()
    LLM-->>Agent: Exception (e.g., Context Limit)
    
    loop Retry Attempts (up to ERROR_RECOVERY_MAX_RETRIES)
        Agent->>Recovery: _attempt_error_recovery(error, iteration)
        Recovery->>Recovery: classify_llm_error() → (category, action, severity)
        Recovery->>Recovery: Create LLMPlatformError with metadata
        
        alt Context Limit Error
            Recovery->>Memory: force_memory_reduction(20%)
            Memory-->>Recovery: {messages_removed, tokens_reduced}
            Recovery-->>Agent: {success: true, strategy: "force_reduction"}
        else Rate Limit Error
            Recovery->>Recovery: Calculate exponential backoff with jitter
            Recovery->>Recovery: time.sleep(calculated_delay)
            Recovery-->>Agent: {success: true, strategy: "exponential_backoff"}
        else Service Error
            Recovery->>Recovery: Exponential backoff retry
            Recovery-->>Agent: {success: true, strategy: "exponential_backoff"}
        else Non-recoverable Error
            Recovery-->>Agent: {success: false, reason: "User action required"}
        end
        
        alt Recovery Successful
            Agent->>LLM: generate_response() [retry]
            LLM-->>Agent: Success or new error
        else Recovery Failed
            Agent-->>Agent: Log error and re-raise
        end
    end
```

#### Recovery Strategies

The agent implements multiple recovery strategies based on error classification:

| Error Type | Recovery Strategy | Description |
|------------|------------------|-------------|
| **Context Limit** | Memory Reduction | Removes 20% of conversation history while preserving tool call coherence |
| **Rate Limit** | Exponential Backoff | Waits with increasing delays (1s → 2s → 4s → ...) up to 30s max |
| **Service Error** | Exponential Backoff | Same backoff strategy for temporary service issues |
| **Authentication** | User Notification | Informs user that API key or credentials need attention |
| **Content Policy** | User Notification | Informs user about content filtering violations |

#### Error Recovery Configuration

The error recovery system is highly configurable. All configuration constants are defined in `coda_core.core.models.errors.constants`. See the [Models module README](../models/README.md) for detailed configuration options and constant definitions.

#### Real-World Error Handling

The system handles actual error patterns from major LLM providers:

**Context Limit Example:**
```
Error code: 400 - {'error': {'message': 'input length and `max_tokens` exceed context limit: 165127 + 40000 > 200000, decrease input length or `max_tokens` and try again'}}
```

**Recovery Process:**
1. **Detection**: Keyword "context limit" triggers `ErrorCategory.CONTEXT_LIMIT`
2. **Action**: `ErrorAction.RECOVER_WITH_MEMORY_REDUCTION`
3. **Execution**: `memory.force_memory_reduction(0.20)` removes ~33K tokens
4. **Retry**: New total: 132K + 40K = 172K < 200K ✅
5. **Success**: LLM call succeeds with reduced context

### Callback System

The agent supports an extensive callback system for monitoring and interaction:

- `on_start`: Called at the start of processing
- `on_llm_start`: Called before sending request to LLM
- `on_llm_response`: Called when raw LLM response is received
- `on_llm_parsed`: Called after parsing the response
- `on_tool_call`: Called before a tool is executed
- `on_tool_result`: Called after a tool returns
- `on_max_iterations`: Called when max iterations is reached
- `on_complete`: Called when processing is complete
- `on_bash_risk_assessment`: Called for bash command risk assessment
- `on_error_recovery_start`: Called when error recovery begins
- `on_error_recovery_end`: Called when error recovery completes

## Data Flow

The processing of a user message follows this flow:

```mermaid
flowchart TD
    A[User Message] --> B[_safe_store: Pre-flight Assessment]
    B --> C{Assessment Action}
    C -->|STORE_DIRECT| D[Add to Memory]
    C -->|SUGGEST_CONDENSE| E[Attempt Condensation]
    C -->|REPORT_TO_AGENT| F[Generate Guidance]
    
    E --> G{Condensation Success?}
    G -->|Yes| D
    G -->|No| F
    
    F --> H{User Input?}
    H -->|Yes| I[Return Guidance to User]
    H -->|No| J[Inject Guidance via _inject_guidance]
    
    D --> K[Send to LLM]
    J --> K
    K --> L[Parse Response]
    L --> M{Contains Tool Calls?}
    M -->|Yes| N[Process Tool Calls]
    N --> O[Execute Tools]
    O --> P[_safe_store: Add Tool Results]
    P --> Q{Storage Success?}
    Q -->|Yes| K
    Q -->|No| R[Handle Tool Storage Error]
    R --> S[Resolve Orphaned Tool Calls]
    S --> T[Inject Tool Guidance]
    T --> K
    M -->|No| U[_safe_store: Add Response]
    U --> V{Storage Success?}
    V -->|Yes| W[Return Response to User]
    V -->|No| X[Handle Response Storage Error]
    X --> Y[Inject Response Guidance]
    Y --> K
    
    style D fill:#90EE90
    style W fill:#90EE90
    style I fill:#FFE4B5
    style J fill:#87CEEB
    style T fill:#87CEEB
    style Y fill:#87CEEB
```

1. **User Message Processing**: The user message is received and processed through [`_safe_store()`](single_agent.py) with pre-flight memory assessment
2. **Memory Assessment**: The system evaluates storage capacity and determines the optimal action:
   - **STORE_DIRECT**: Message fits within capacity - proceed normally
   - **SUGGEST_CONDENSE**: Attempt memory condensation to free space
   - **REPORT_TO_AGENT**: Generate guidance for user or LLM action
3. **Condensation Recovery**: If condensation is attempted and successful, retry storage; if unsuccessful, generate guidance
4. **Guidance Routing**:
   - **User Input Failures**: Return guidance directly to user for message modification
   - **Assistant/Tool Failures**: Inject guidance via [`_inject_guidance()`](single_agent.py) for LLM regeneration
5. **LLM Processing**: The message history is sent to the LLM with tool definitions
6. **Response Parsing**: The LLM response is parsed to extract content, tool calls, and metadata
7. **Tool Call Processing**: If tool calls are present:
   - Each tool is executed with the provided arguments
   - Tool results are processed through [`_safe_store()`](single_agent.py) with the same assessment logic
   - If tool storage fails, orphaned tool calls are resolved and guidance is injected
8. **Response Storage**: Assistant responses are stored through [`_safe_store()`](single_agent.py):
   - If storage fails, guidance is injected for LLM regeneration with specific token targets
   - The LLM regenerates a shorter response based on the guidance
9. **Completion**: The process continues until a final response is successfully stored and returned to the user

```mermaid
flowchart TD
    A[User Message with @agent] --> B[AgentManager.parse_user_message]
    B --> C[Identify Agent Command]
    C --> D[Load Agent Definition]
    D --> E[Create Agent Instance]
    E --> F[Process User Message]
    F --> G[Return Response to User]
```

1. A user message containing @agent syntax is received
2. The AgentManager parses the message to identify the agent and input
3. The appropriate agent definition is loaded from file
4. A SingleAgent instance is created with the proper configuration
5. The user input is processed by the agent
6. The response is returned to the user

## Integration

### Memory Integration

The agent integrates with the memory system:

- Uses memory to store and retrieve conversation history
- Adds user messages, assistant responses, and tool results to memory
- Retrieves conversation context for LLM requests

### LLM Integration

The agent works with the language model system:

- Formats requests for the LLM
- Includes tool definitions for function calling
- Parses LLM responses
- Handles different response formats (content, tool calls)

### Tool Integration

The agent connects with the tools system:

- Passes tool definitions to the LLM
- Executes tools based on LLM requests
- Provides tool results and error details back to the LLM
- Handles tool errors and edge cases
- Continues conversation flow after parameter validation errors

### Metadata Integration

The agent integrates with the metadata system to pass session information to GEAI (Globant Enterprise AI) API calls for tracking and analytics purposes.

The [`extract_metadata()`](../metadata/metadata.py) function transforms a `SessionMetadata` Pydantic object into a dictionary format. It converts the object to a dictionary, applies field transformations (maps `task_name` from `task_id`, retrieves `user_name` from OS if missing, overrides `agent` with `CODA_AGENT_NAME` constant), and preserves `session_id`, `task_id`, and `client` values.

Metadata flows from `get_response()` through the agent system: when provided and `CODA_SEND_METADATA` is enabled, it's included in all LLM `generate_response()` calls and automatically injected into tool arguments when tools are executed. The metadata dictionary is then passed through the LLM layer to the underlying GEAI client for inclusion in API requests.

**Web Search Tool**: Metadata is extracted from tool arguments, passed to a dedicated search LLM instance, and included in the GEAI API request. This enables tracking of search operations by session and user for analytics on usage patterns and costs.

**Examine Images Tool**: Metadata follows the same pattern - extracted from tool arguments, passed to a dedicated vision LLM instance, and included in GEAI API requests. This enables tracking of image analysis operations for analytics on vision model usage, costs, and feature adoption.

Metadata transmission is controlled by the `CODA_SEND_METADATA` environment variable. When set to `'true'`, metadata is included in all GEAI API calls. When disabled or omitted, metadata is still accepted by `get_response()` but not passed to LLM or tool calls, ensuring backward compatibility.

## Memory Error Handling Examples

### Example 1: Successful Condensation Recovery

```python
# Scenario: Assistant reply too large, condensation resolves the issue
user_message = "Please analyze this large dataset..."
agent_response = "Here's a detailed analysis..." # 15,000 tokens

# Flow:
1. _safe_store("assistant_reply", add_assistant_message, agent_response)
2. Pre-flight assessment: tokens_to_free = 3,000, action = SUGGEST_CONDENSE
3. handle_condense_suggestion() called
4. memory.check_and_condense(force=True) frees 4,500 tokens
5. tokens_freed (4,500) >= tokens_needed (3,000) ✅
6. Return: {"handled": True, "retry": True, "strategy": "condensation"}
7. Retry storage succeeds
8. Continue with conversation
```

### Example 2: Insufficient Capacity with Guidance Injection

```python
# Scenario: Assistant reply too large, insufficient removable content
user_message = "Write a comprehensive report..."
agent_response = "Here's the complete report..." # 12,000 tokens

# Flow:
1. _safe_store("assistant_reply", add_assistant_message, agent_response)
2. Pre-flight assessment: tokens_to_free = 8,000, removable_tokens = 2,000
3. handle_insufficient_capacity() called
4. get_tailored_guidance() generates: "Previous reply did not fit. Regenerate concise version ≤ 150 tokens."
5. _inject_guidance() adds system message to memory
6. Return error to get_response() with guidance_injected = True
7. Next LLM call receives guidance and regenerates shorter response
8. New response storage succeeds
```

### Example 3: Oversized User Input

```python
# Scenario: User message exceeds total memory capacity
user_message = "Please process this massive text..." # 50,000 tokens (capacity = 40,000)

# Flow:
1. _safe_store("user_input", add_user_message, user_message)
2. Pre-flight assessment: message_tokens = 50,000, capacity_limit = 40,000
3. handle_oversized_message() called
4. overflow = 10,000 tokens
5. get_tailored_guidance() generates: "Your message is too large (exceeds capacity by 10,000 tokens). Please break your input into smaller parts."
6. Return error with guidance to caller
7. User receives specific guidance about reduction needed
```

### Example 4: Tool Response Storage Failure with Orphan Resolution

```python
# Scenario: Tool response too large, orphaned tool calls need resolution
tool_response = "Large file contents..." # 8,000 tokens

# Flow:
1. _safe_store("tool_response", add_tool_message, tool_response, tool_calls=[...])
2. Pre-flight assessment: insufficient capacity
3. handle_insufficient_capacity() called
4. _inject_guidance() called for tool response failure
5. memory.resolve_orphaned_tool_calls() resolves pending tool calls
6. Guidance injected: "Tool execution aborted due to memory limits. Regenerate shorter reply."
7. LLM regenerates response with awareness of tool call failure
```

## Extensibility

### Creating New Agent Types

The agent system is designed to be extensible:

1. Create a new class that extends `BaseAgent`
2. Implement the required `get_response()` method
3. Add any additional functionality needed
4. Register the new agent type with the system

Example:

```python
from coda_core.core.agents.base_agent import BaseAgent
from coda_core.core.models.llms.base import LLM
from coda_core.core.memories.base import Memory
from typing import List, Dict, Any, Optional

class CustomAgent(BaseAgent):
    """A custom agent implementation."""
    
    def __init__(
        self,
        llm: LLM,
        tools: List,
        memory: Optional[Memory] = None,
        custom_param: str = "default"
    ):
        super().__init__(llm, tools, memory)
        self.custom_param = custom_param
    
    def get_response(self, user_message: str, **kwargs) -> Dict[str, Any]:
        """Process user message and generate a response."""
        # Custom implementation here
        return {"success": True, "content": "Custom response"}
```

### Creating New Agent Definitions

To create a new agent definition:

1. Create a markdown file in the agents directory with proper frontmatter
2. Include the agent metadata in the frontmatter
3. Write the agent's instructions and personality in the markdown content

Example agent definition:

```markdown
---
name: expert_coder
description: An expert coding assistant
model: default
tools: default
command: true
discoverable: true
---

# Expert Coding Assistant

You are an expert coding assistant that helps users write, debug, and optimize code.

## Capabilities
- Write high-quality code in multiple languages
- Troubleshoot and fix bugs
- Optimize code for performance
- Explain code in detail

Always follow best practices and ensure code is well-documented.
```

### Configuring Tools

The `tools` field in the frontmatter supports flexible configuration:

- **All tools**: Use `default` to enable all available tools.
  ```yaml
  tools: default
  ```

- **Specific tools**: List the tools you want to include (comma-separated).
  ```yaml
  tools: bash, view, edit
  ```

- **Excluding tools**: Use the `-` prefix to exclude specific tools. This implicitly starts with "all tools" (default).
  ```yaml
  tools: -bash, -replace
  ```
  You can also explicitly combine `default` with exclusions:
  ```yaml
  tools: default, -bash
  ```

### Extending Existing Agents

Existing agents can be extended by:

- Subclassing and overriding methods
- Adding new functionality
- Modifying the processing flow
- Adding new callback types

### Error Handling

The agent includes comprehensive error handling at multiple levels:

#### LLM Error Recovery
- **Automatic Classification**: All LLM errors are classified using [`classify_llm_error()`](../models/errors/detection.py) from the models error submodule
- **Intelligent Recovery**: Context limit errors trigger memory reduction, rate limits trigger backoff
- **Retry Logic**: Configurable retry attempts with different strategies per error type
- **Callback Integration**: Error recovery events are exposed through `on_error_recovery_start` and `on_error_recovery_end`
- **Provider Agnostic**: Handles error patterns from all major LLM providers (OpenAI, Anthropic, Google, etc.)

#### Tool Execution Error Handling
- **Parameter Validation**: Errors are caught and formatted with detailed information
- **Memory Integration**: Error messages are added to the conversation memory
- **Graceful Continuation**: The agent continues processing other tool calls after non-critical errors
- **Callback Support**: The `on_tool_result` callback handles both successful results and errors
- **Learning Integration**: Detailed error information helps the LLM learn from mistakes

#### Memory Capacity Error Handling
- **Pre-Flight Assessment**: All memory operations use [`pre_flight_memory_check()`](../memories/base.py) to prevent capacity errors
- **Intelligent Recovery**: Assessment-driven condensation attempts and guidance generation
- **Safe Storage**: The [`_safe_store()`](single_agent.py) method provides robust error handling with retry logic
- **Guidance Injection**: Failed storage operations trigger intelligent guidance via [`_inject_guidance()`](single_agent.py)
- **Orphan Resolution**: Tool response failures automatically resolve orphaned tool calls
- **Context-Aware Guidance**: Tailored instructions based on operation type and failure scenario

#### Error Recovery Benefits
This comprehensive approach ensures that:
1. **Automatic Recovery**: Most LLM errors are resolved without user intervention
2. **Context Preservation**: Memory reduction maintains conversation coherence while freeing tokens
3. **Resilient Operation**: Rate limits and service issues are handled with intelligent backoff
4. **Continuous Learning**: The LLM receives feedback about parameter errors and can correct behavior
5. **User Experience**: Users receive a more resilient and helpful experience with minimal interruptions
6. **Observability**: Rich error tracking and recovery metrics for monitoring and debugging