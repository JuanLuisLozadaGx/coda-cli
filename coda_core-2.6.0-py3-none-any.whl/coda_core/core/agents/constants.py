# Agent-level constants for memory guidance and error handling

# System message prefix for injected guidance
CODA_SYSTEM_MESSAGE_PREFIX = "[CODA SYSTEM MESSAGE]"

# Guidance injection settings
GUIDANCE_INJECTION_LOG_TRUNCATE_LENGTH = 100


# Target token computation settings for regeneration
REGENERATION_TARGET_MIN_TOKENS = 80
REGENERATION_TARGET_MAX_TOKENS = 250
REGENERATION_SAFETY_MARGIN = 50

MAX_ITERATIONS_EXPLANATION_MESSAGE = "The agent reached the maximum number of iterations allowed.\nIf you want it to continue, just write 'continue' in the prompt. \nIt's also possible to provide extra instructions to steer the agent."


# Remote agents settings
REMOTE_AGENTS_CACHE_TS_DEFAULT: float = 0.0

# Agent invocation context defaults
AGENT_CONTEXT_DEFAULT_MODE = "recent"
AGENT_CONTEXT_VALID_MODES = {"recent", "full", "none"}


# Omni-parser file categorization
OMNI_PARSER_MEDIA_EXTENSIONS = {
    ".mp4",
    ".mov",
    ".avi",
    ".mkv",
    ".mp3",
    ".wav",
    ".m4a",
    ".aac",
}

OMNI_PARSER_DOC_EXTENSIONS = {
    ".pdf",
    ".docx",
    ".pptx",
    ".xlsx",
    ".csv",
}
