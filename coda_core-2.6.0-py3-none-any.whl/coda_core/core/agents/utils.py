from typing import List, Dict, Tuple, Optional
import re
import shlex
from loguru import logger

from coda_core.core.agents.constants import (
    REGENERATION_TARGET_MIN_TOKENS,
    REGENERATION_TARGET_MAX_TOKENS,
    REGENERATION_SAFETY_MARGIN,
    AGENT_CONTEXT_DEFAULT_MODE,
    AGENT_CONTEXT_VALID_MODES,
)
from coda_core.core.agents.types import MemoryErrorStrategy, MemoryOperationKind
from coda_core.core.session.constants import MEMORY_KEY_MAIN

def get_tailored_guidance(kind: str, scenario: MemoryErrorStrategy, tokens_needed: int = None, removable_tokens: int = None,
                         tokens_freed: int = None, overflow: int = None, capacity_limit: int = None,
                         current_tokens: int = None, has_tool_calls: bool = False) -> str:
    """Generate tailored guidance based on memory operation and failure scenario.
    
    This function produces context-aware guidance messages for memory capacity errors,
    adapting the message based on the operation type (user input, assistant reply, tool response)
    and the specific failure scenario (oversized message, insufficient capacity, etc.).
    
    Args:
        kind (str): Type of memory operation (e.g., MemoryOperationKind.USER_INPUT,
            MemoryOperationKind.ASSISTANT_REPLY, MemoryOperationKind.TOOL_RESPONSE).
        scenario (MemoryErrorStrategy): Failure scenario enum value (e.g.,
            MemoryErrorStrategy.OVERSIZED_GUIDANCE, MemoryErrorStrategy.INSUFFICIENT_CAPACITY_GUIDANCE).
            Can be passed as enum or enum.value string.
        tokens_needed (int, optional): Number of tokens that need to be freed to store the message.
        removable_tokens (int, optional): Number of tokens that can be removed via condensation.
        tokens_freed (int, optional): Number of tokens actually freed (for condensation scenarios).
        overflow (int, optional): Number of tokens over capacity (for oversized scenarios).
        capacity_limit (int, optional): Maximum token capacity of the memory.
        current_tokens (int, optional): Current token usage before attempting to store.
        has_tool_calls (bool, optional): Whether the message includes tool calls. Defaults to False.
        
    Returns:
        str: Tailored guidance message as plain text, suitable for injection into the conversation
            to help the agent self-correct.
            
    Note:
        For assistant replies with insufficient capacity, this function computes a target token
        budget using REGENERATION_TARGET_MIN_TOKENS, REGENERATION_TARGET_MAX_TOKENS, and
        REGENERATION_SAFETY_MARGIN to guide the agent toward a concise regeneration.
    """
    if scenario == MemoryErrorStrategy.OVERSIZED_GUIDANCE.value:
        if kind == MemoryOperationKind.USER_INPUT:
            overflow_text = f" (exceeds capacity by {overflow} tokens)" if overflow is not None else ""
            return f"Your message is too large{overflow_text}. Please break your input into smaller parts or summarize your request."
        elif kind.startswith(MemoryOperationKind.TOOL_RESPONSE.split('_')[0] + "_"):
            overflow_text = f" (exceeds capacity by {overflow} tokens)" if overflow is not None else ""
            return f"Tool output too large{overflow_text}. Re-run with narrower scope (subset / range / filter)."
        else:
            # Assistant oversized
            overflow_text = f" (exceeds capacity by {overflow} tokens)" if overflow is not None else ""
            return f"Previous reply did not fit{overflow_text}. Produce a much shorter version next turn."
    
    elif scenario == MemoryErrorStrategy.INSUFFICIENT_CAPACITY_GUIDANCE.value:
        if kind == MemoryOperationKind.USER_INPUT:
            needed_text = f"need {tokens_needed} tokens, " if tokens_needed is not None else ""
            removable_text = f"only {removable_tokens} removable" if removable_tokens is not None else "limited space available"
            return f"Cannot store your message: {needed_text}{removable_text}. Summarize earlier steps or split your input."
        
        elif kind.startswith(MemoryOperationKind.ASSISTANT_REPLY.split('_')[0] + "_") and tokens_needed is not None and tokens_needed > 0:
            # Assistant regeneration with target token computation
            if capacity_limit is not None and current_tokens is not None:
                raw_available = capacity_limit - current_tokens
                target = REGENERATION_TARGET_MIN_TOKENS if raw_available - REGENERATION_SAFETY_MARGIN < 0 else max(REGENERATION_TARGET_MIN_TOKENS, min(REGENERATION_TARGET_MAX_TOKENS, raw_available - REGENERATION_SAFETY_MARGIN))
                
                # Include hint only if we have reasonable space
                if raw_available > target + REGENERATION_SAFETY_MARGIN:
                    guidance = f"Previous reply did not fit (need {tokens_needed} more tokens). Regenerate a concise version ≤ {target} tokens."
                else:
                    guidance = f"Previous reply did not fit. Regenerate a concise version ≤ {target} tokens."
                
                # Add tool call reminder if needed
                if has_tool_calls:
                    guidance += " If tool calls are still needed, reissue them."
                
                return guidance
            else:
                # Fallback without target computation
                guidance = f"Previous reply did not fit (need {tokens_needed} more tokens). Regenerate a more concise version."
                if has_tool_calls:
                    guidance += " If tool calls are still needed, reissue them."
                return guidance
        
        else:
            # Tool responses
            needed_text = f"needs {tokens_needed} tokens, " if tokens_needed is not None else ""
            removable_text = f"only {removable_tokens} removable" if removable_tokens is not None else "limited space available"
            return f"Tool output {needed_text}{removable_text}. Re-run with narrower scope (subset / range / filter)."
    
    elif scenario == MemoryErrorStrategy.CONDENSATION_ATTEMPTED.value:
        freed_text = f"freed {tokens_freed}" if tokens_freed is not None else "freed some tokens"
        needed_text = f", still need {tokens_needed}" if tokens_needed is not None else ""
        
        if kind == MemoryOperationKind.USER_INPUT:
            return f"Memory condensation {freed_text}{needed_text}. Summarize your request or split into smaller parts."
        else:
            return f"Memory condensation {freed_text}{needed_text}. Reduce verbosity or summarize earlier context."
    
    # Default fallback
    needed_text = f"need {tokens_needed} tokens, " if tokens_needed is not None else ""
    removable_text = f"{removable_tokens} removable" if removable_tokens is not None else "limited space"
    return f"Memory capacity issue with {kind}: {needed_text}{removable_text}. Please reduce content size."

def parse_user_message_for_agents(user_message: str, available_agents: List[str]) -> List[Dict[str, str]]:
    """
    Parse sequences of @agent [optional text] blocks.

    Returns list preserving order of appearance.
    """
    if not user_message or not available_agents:
        return []

    # Escape @ and normalize newlines
    marker = "__ESC_AT__"
    # First handle literal escaped newlines
    text = user_message.replace("\\n", "\n")
    # Then normalize all newline variants
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\\@", marker)

    # Build regex to match agent commands
    agent_alts = "|".join(re.escape(a) for a in sorted(available_agents, key=len, reverse=True))
    pattern = re.compile(
        rf"@(?P<agent>{agent_alts})"           # @agent
        r"(?:[ \t\n]+(?P<input>.*?))?"         # optional space/tab/newline + input (non-greedy)
        rf"(?=\s*(?:@(?:{agent_alts})|\Z))",   # lookahead: whitespace + next @agent or end
        re.DOTALL
    )

    results: List[Dict[str, str]] = []
    for m in pattern.finditer(text):
        agent = m.group("agent")
        raw_input = m.group("input") or ""
        cleaned = raw_input.strip().replace(marker, "@")
        results.append({"agent_name": agent, "user_input": cleaned})

    return results


def extract_remote_agent_command(rest: str, available_remote_names: List[str]) -> Tuple[str, str]:
    """Parse `/agents run-remote` input into the remote agent name and the remaining prompt.

    Handles quoted names (single or double quotes) and falls back to matching any of the
    known remote agent names before defaulting to "first token is the name" semantics.
    Returns a tuple of (agent_name, agent_input). Missing input yields empty strings.
    """
    if not rest:
        return "", ""

    rest = rest.strip()
    agent_name = None
    agent_input = ""

    if rest.startswith('"') and '"' in rest[1:]:
        end = rest.find('"', 1)
        agent_name = rest[1:end]
        agent_input = rest[end + 1 :].strip()
    elif rest.startswith("'") and "'" in rest[1:]:
        end = rest.find("'", 1)
        agent_name = rest[1:end]
        agent_input = rest[end + 1 :].strip()
    else:
        for name in sorted(available_remote_names or [], key=len, reverse=True):
            if rest == name or rest.startswith(name + " "):
                agent_name = name
                agent_input = rest[len(name):].strip()
                break

    if not agent_name:
        parts = rest.split(maxsplit=1)
        agent_name = parts[0]
        agent_input = parts[1] if len(parts) > 1 else ""

    return agent_name, agent_input


class AgentInvocation:
    def __init__(self, context_mode: str, prompt: str) -> None:
        self.context_mode = context_mode
        self.prompt = prompt


def parse_agent_invocation(raw: str, default_mode: str = AGENT_CONTEXT_DEFAULT_MODE, valid_modes: Optional[set] = None) -> AgentInvocation:
    """
    Parse user-provided agent input for context options and prompt.

    Shared helper so other clients can reuse the same parsing rules.
    """
    valid = valid_modes or AGENT_CONTEXT_VALID_MODES
    if not raw:
        return AgentInvocation(context_mode=default_mode, prompt="")

    def _tokenize(value: str) -> List[str]:
        """
        Tokenize while treating apostrophes as normal characters to avoid unbalanced quote errors
        (e.g., \"what's up\") and still support double-quoted context flags.
        """
        lexer = shlex.shlex(value, posix=True)
        lexer.whitespace_split = True
        lexer.commenters = ""
        lexer.quotes = '"'
        return list(lexer)

    try:
        tokens = _tokenize(raw)
    except Exception as exc:  # pragma: no cover - defensive for lexer edge cases
        raise ValueError(f"Unable to parse agent input: {exc}") from exc

    context_mode = default_mode
    index = 0

    while index < len(tokens):
        token = tokens[index]

        if token == "--context":
            index += 1
            if index >= len(tokens):
                raise ValueError("Expected value after --context")
            value = tokens[index]
        elif token.startswith("--context="):
            value = token.split("=", 1)[1]
        else:
            break

        normalized = value.lower()
        if normalized not in valid:
            raise ValueError(f"Invalid context mode '{value}'")
        context_mode = normalized
        index += 1
        continue

    prompt = " ".join(tokens[index:]) if index < len(tokens) else ""
    return AgentInvocation(context_mode=context_mode, prompt=prompt)


def build_agent_prompt(shared_state, agent_input: str, context_mode: str) -> str:
    """Build the message body sent to sub- or remote agents with optional context injection."""
    agent_input = agent_input or ""

    if context_mode == "none":
        return agent_input

    memory = shared_state.memories.get(MEMORY_KEY_MAIN)
    if not memory:
        return agent_input

    try:
        messages: List[dict] = memory.retrieve()
    except Exception as exc:
        logger.debug(f"Unable to retrieve memory for context injection: {exc}")
        return agent_input

    if not messages:
        return agent_input

    # Build pairs by finding the last assistant response with content for each user message.
    # This ensures we capture the final response after tool use, not intermediate tool-call messages.
    pairs = []
    user_indices = [i for i, msg in enumerate(messages) if msg.get("role") == "user"]

    for idx, user_idx in enumerate(user_indices):
        user_msg = messages[user_idx]

        # Find the boundary (next user message or end of messages)
        next_user_idx = user_indices[idx + 1] if idx + 1 < len(user_indices) else len(messages)

        # Find the last assistant message with non-empty content between this user and next user
        last_assistant = None
        for i in range(next_user_idx - 1, user_idx, -1):
            msg = messages[i]
            if msg.get("role") == "assistant":
                content = msg.get("content")
                if content and str(content).strip():
                    last_assistant = msg
                    break

        if last_assistant:
            pairs.append((user_msg, last_assistant))

    if not pairs:
        return agent_input

    if context_mode == "full":
        selected_pairs = pairs
    else:
        selected_pairs = pairs[-3:] if len(pairs) >= 3 else pairs

    if not selected_pairs:
        return agent_input

    formatted_blocks = []
    for index, (user_msg, assistant_msg) in enumerate(selected_pairs, 1):
        user_content = user_msg.get("content", "") if isinstance(user_msg, dict) else ""
        assistant_content = assistant_msg.get("content", "") if isinstance(assistant_msg, dict) else ""
        block = [
            f"<message{index}>",
            f"User: {user_content}",
            f"Assistant: {assistant_content}",
            f"</message{index}>\n",
        ]
        formatted_blocks.append("\n".join(block))

    formatted_context = "\n".join(formatted_blocks)
    return f"Previous conversation for context:\n{formatted_context}\n\nCurrent User: {agent_input}"
