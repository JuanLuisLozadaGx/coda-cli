from enum import Enum, StrEnum


class MemoryOperationKind(StrEnum):
    """Types of memory storage operations for error handling context."""
    USER_INPUT = "user_input"
    ASSISTANT_REPLY = "assistant_reply" 
    ASSISTANT_FINAL = "assistant_final"
    TOOL_RESPONSE = "tool_response"
    TOOL_SUCCESS = "tool_success"
    TOOL_ERROR = "tool_error"
    TRANSITION = "transition"


class MessageRole(Enum):
    """Message roles in conversation."""
    ASSISTANT = "assistant"
    USER = "user"
    SYSTEM = "system"
    TOOL = "tool"


class MemoryErrorStrategy(Enum):
    """Memory error handling strategies."""
    CONDENSATION = "condensation"
    CONDENSATION_ATTEMPTED = "condensation_attempted"
    OVERSIZED_GUIDANCE = "oversized_guidance"
    INSUFFICIENT_CAPACITY_GUIDANCE = "insufficient_capacity_guidance"
    INSUFFICIENT_CAPACITY_NO_DEFICIT = "insufficient_capacity_no_deficit"
    UNKNOWN_ACTION = "unknown_action"
    DIRECT_STORE = "direct_store"
    UNEXPECTED_ERROR = "unexpected_error"
    RETRY_EXHAUSTED = "retry_exhausted"


class ErrorRecoveryStrategy(Enum):
    """Error recovery strategies for LLM platform errors."""
    FORCE_REDUCTION = "force_reduction"
    EXPONENTIAL_BACKOFF = "exponential_backoff"


class StopReasonCode(StrEnum):
    """Normalized stop-reason codes for LLM finish_reason outcomes."""

    NO_CHOICES = "no_choices"
    MISSING_FINISH_REASON = "missing_finish_reason"
    LENGTH = "length"
    CONTENT_FILTER = "content_filter"
    UNEXPECTED_FINISH_REASON = "unexpected_finish_reason"
    EXCEPTION = "exception"