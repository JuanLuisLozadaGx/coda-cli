from typing import Dict, Any, List, Optional, Union, TYPE_CHECKING
from collections import deque
from copy import deepcopy
import hashlib
import json
import time

from loguru import logger

from coda_core.config.env_config import EnvConfig
from coda_core.config.settings import SETTINGS
from coda_core.core.models.llms.base import LLM
from coda_core.core.utils.constants import DEFAULT_CACHE_SIZE, DEFAULT_CHAR_TO_TOKEN_RATIO
from coda_core.core.memories.constants import (
    MIN_SAFE_MAX_TOKENS,
    OUTPUT_TOKENS_PERCENTAGE,
    SAFETY_BUFFER_PERCENTAGE,
)
from coda_core.core.models.llms.constants import (
    ANTHROPIC_THINKING_BUDGET_BY_EFFORT,
    CHAT_REASONING_EFFORTS,
    MIN_ANTHROPIC_THINKING_BUDGET,
    RESPONSES_CHAIN_RESET_ERROR_MARKERS,
    RESPONSES_CHAIN_RETRY_ATTEMPTS,
    RESPONSES_EXTERNAL_ITEM_TYPES,
    RESPONSES_EXTERNAL_MESSAGE_ROLES,
    RESPONSES_GATEWAY_INCOMPATIBLE_ITEM_TYPES,
    RESPONSES_TRANSIENT_STATUS_CODES,
)
from coda_core.core.utils.token_counting import count_messages_tokens, create_token_cache
from coda_core.core.models.utils import (
    get_model_reasoning_efforts,
    normalize_reasoning_effort,
)
from coda_core.core.models.providers.responses_api.interop import chat_messages_to_items, response_from_chat_completion
from coda_core.core.models.providers.responses_api.enums import ItemType, MessageRole

if TYPE_CHECKING:
    from coda_core.core.models.providers.geai_client import GEAIClient


class ChatLLM(LLM):
    """
    A chat-based language model (LLM) that generates responses based on a conversation history.
    This class interacts with a client to send requests and retrieve responses from the model.
    """

    def __init__(
        self,
        client: 'GEAIClient',
        provider_name: str,
        model_name: str,
        system_prompt: Optional[str] = None,
        params: Dict[str, Any] = None,
        responses_chain_state_store: Optional[Dict[str, Dict[str, Any]]] = None,
        responses_chain_scope: str = "main",
    ):
        """
        Initialize ChatLLM and optional Responses chaining state.

        Args:
            client: The client used to issue model requests.
            provider_name: Provider identifier (for example, ``openai``).
            model_name: Model identifier.
            system_prompt: Optional system instruction.
            params: Default model parameters for each request.
            responses_chain_state_store: Optional persisted store for OpenAI
                Responses chaining metadata.
            responses_chain_scope: Logical scope name used to separate chain
                state entries (for example, ``main`` memory).
        """
        super().__init__(client, provider_name, model_name, system_prompt, params)

        # Initialize token count cache
        self._token_count_cache = create_token_cache(maxsize=DEFAULT_CACHE_SIZE)

        # Character to token ratio for fallback estimation
        self.char_to_token_ratio = DEFAULT_CHAR_TO_TOKEN_RATIO

        # Responses chain state: persisted store from SharedState when available.
        self._responses_chain_state_store = responses_chain_state_store if responses_chain_state_store is not None else {}
        self._responses_chain_scope = responses_chain_scope or "main"

        logger.info(f"Initialized ChatLLM with provider: {provider_name}, model: {model_name}")

    def _count_tokens(self, messages: Union[List[Dict[str, Any]], deque[Dict[str, Any]]]) -> int:
        """
        Count tokens in a list or deque of messages using the shared token utility.

        Args:
            messages: List or deque of message dictionaries.

        Returns:
            Estimated token count.
        """
        return count_messages_tokens(
            messages,
            model_name=self.model.name.lower(),
            char_to_token_ratio=self.char_to_token_ratio,
            cache=self._token_count_cache
        )

    def _adjust_max_tokens_for_context(self, messages: Union[List[dict], deque[dict]]) -> int:
        """
        Calculate a safe max-output token budget for the current context.

        Args:
            messages: Message list that will be sent to the model.

        Returns:
            Max output tokens that fit the model context window.
        """
        estimated_input_tokens = self._count_tokens(messages)
        context_window = self.model.context_window

        max_output_tokens_limit = int(context_window * OUTPUT_TOKENS_PERCENTAGE)
        max_output_tokens = min(self.model.max_output_tokens, max_output_tokens_limit)

        logger.info(
            f"Token usage - Input: {estimated_input_tokens}, Max Output: {max_output_tokens}, "
            f"Total: {estimated_input_tokens + max_output_tokens}, Context Window: {context_window}"
        )

        excess_tokens = (estimated_input_tokens + max_output_tokens) - context_window
        if excess_tokens > 0:
            safety_buffer = int(context_window * SAFETY_BUFFER_PERCENTAGE)
            adjusted_max_tokens = max(MIN_SAFE_MAX_TOKENS, max_output_tokens - excess_tokens - safety_buffer)
            logger.warning(
                f"Reducing max_tokens from {max_output_tokens} to {adjusted_max_tokens} "
                f"to fit within context window of {context_window}"
            )
            return adjusted_max_tokens

        return max_output_tokens

    def _build_responses_chain_key(self, provider: str, model_name: str) -> str:
        """
        Build a stable key for persisted Responses chain state.

        Args:
            provider: Provider name for the active request.
            model_name: Model name for the active request.

        Returns:
            Unique chain-state key.
        """
        return f"{self._responses_chain_scope}:{provider.lower()}:{model_name}"

    def _get_chain_state(self, chain_key: str) -> Dict[str, Any]:
        """
        Read chain state for the given key.

        Args:
            chain_key: Chain-state lookup key.

        Returns:
            Stored chain state or an empty dictionary.
        """
        state = self._responses_chain_state_store.get(chain_key)
        return state if isinstance(state, dict) else {}

    def _set_chain_state(self, chain_key: str, state: Dict[str, Any]) -> None:
        """
        Persist chain state for a key.

        Args:
            chain_key: Chain-state key.
            state: Chain metadata payload.
        """
        self._responses_chain_state_store[chain_key] = state

    def _clear_chain_state(self, chain_key: str) -> None:
        """
        Remove persisted chain state for a key.

        Args:
            chain_key: Chain-state key.
        """
        self._responses_chain_state_store.pop(chain_key, None)

    def _extract_external_input_items(self, items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Extract request items that are valid external input for chained Responses calls.

        Args:
            items: Full normalized memory item list.

        Returns:
            List containing only user/system/developer messages and tool outputs.
        """
        external_items: List[Dict[str, Any]] = []
        for item in items:
            if not isinstance(item, dict):
                continue

            item_type = item.get("type")
            if item_type == ItemType.MESSAGE.value and item.get("role") in RESPONSES_EXTERNAL_MESSAGE_ROLES:
                external_items.append(deepcopy(item))
                continue

            if item_type in RESPONSES_EXTERNAL_ITEM_TYPES:
                external_items.append(deepcopy(item))

        return external_items

    def _contains_gateway_incompatible_items(self, items: List[Dict[str, Any]]) -> bool:
        """
        Detect items known to trigger GEAI/LiteLLM Responses compatibility 400s.

        Args:
            items: Full normalized memory item list.

        Returns:
            True when model-output items are present in input history.
        """
        for item in items:
            if not isinstance(item, dict):
                continue

            item_type = item.get("type")
            if item_type == ItemType.MESSAGE.value and item.get("role") == MessageRole.ASSISTANT.value:
                return True
            if item_type in RESPONSES_GATEWAY_INCOMPATIBLE_ITEM_TYPES:
                return True

        return False

    def _hash_items(self, items: List[Dict[str, Any]]) -> str:
        """
        Compute a deterministic digest for a list of items.

        Args:
            items: Item list to hash.

        Returns:
            Hex SHA-256 digest.
        """
        canonical = json.dumps(items, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def _build_request_signature(
        self,
        provider: str,
        model_name: str,
        max_output_tokens: int,
        request_kwargs: Dict[str, Any],
    ) -> str:
        """
        Build a signature representing non-input request semantics.

        Args:
            provider: Provider name.
            model_name: Model name.
            max_output_tokens: Output token budget.
            request_kwargs: Non-input request kwargs.

        Returns:
            Hex SHA-256 signature string.
        """
        signature_payload = {
            "provider": provider.lower(),
            "model": model_name,
            "max_output_tokens": max_output_tokens,
            "kwargs": request_kwargs,
        }
        canonical = json.dumps(signature_payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def _can_continue_responses_chain(
        self,
        chain_state: Dict[str, Any],
        signature: str,
        external_items: List[Dict[str, Any]],
    ) -> bool:
        """
        Validate whether the current request can continue an existing Responses chain.

        Args:
            chain_state: Persisted chain state.
            signature: Current non-input request signature.
            external_items: Current external-input item projection.

        Returns:
            True if ``previous_response_id`` chaining is safe.
        """
        if not isinstance(chain_state, dict) or not chain_state:
            return False

        previous_response_id = chain_state.get("last_response_id")
        previous_signature = chain_state.get("request_signature")
        previous_count = chain_state.get("external_input_count")
        previous_hash = chain_state.get("external_input_hash")

        if not isinstance(previous_response_id, str) or not previous_response_id:
            return False
        if previous_signature != signature:
            return False
        if not isinstance(previous_count, int) or previous_count < 0:
            return False
        if not isinstance(previous_hash, str) or not previous_hash:
            return False
        if len(external_items) < previous_count:
            return False

        prefix_hash = self._hash_items(external_items[:previous_count])
        return prefix_hash == previous_hash

    def _extract_status_code(self, exc: Exception) -> Optional[int]:
        """
        Extract an integer HTTP-like status code from an exception.

        Args:
            exc: Exception instance.

        Returns:
            Integer status code when available, otherwise None.
        """
        status = getattr(exc, "status_code", None) or getattr(exc, "status", None)
        if isinstance(status, int):
            return status
        if isinstance(status, str) and status.isdigit():
            return int(status)
        message = str(exc).lower()
        if "error code:" in message:
            try:
                raw_code = message.split("error code:", maxsplit=1)[1].strip().split(" ", maxsplit=1)[0]
                if raw_code.isdigit():
                    return int(raw_code)
            except Exception:
                return None
        return None

    def _is_transient_responses_error(self, exc: Exception) -> bool:
        """
        Determine whether a Responses call failure is transient and retryable.

        Args:
            exc: Exception raised by the Responses path.

        Returns:
            True when a bounded retry should be attempted.
        """
        status = self._extract_status_code(exc)
        if status in RESPONSES_TRANSIENT_STATUS_CODES:
            return True

        message = str(exc).lower()
        return any(marker in message for marker in (
            "connection error",
            "timeout",
            "temporarily unavailable",
        ))

    def _is_chain_reset_error(self, exc: Exception) -> bool:
        """
        Determine whether a failure should invalidate chain state and fallback.

        Args:
            exc: Exception raised by Responses.

        Returns:
            True when chain state should be cleared and chat fallback used.
        """
        status = self._extract_status_code(exc)
        message = str(exc).lower()

        if status in {400, 404}:
            return any(marker in message for marker in RESPONSES_CHAIN_RESET_ERROR_MARKERS)

        return False

    def _sleep_before_retry(self, attempt: int) -> None:
        """
        Sleep for a short exponential backoff interval before retrying.

        Args:
            attempt: Zero-based retry attempt index.
        """
        delay_seconds = 0.2 * (2 ** attempt)
        time.sleep(delay_seconds)

    def _call_chat_fallback(
        self,
        model_provider: str,
        model_name: str,
        input_items: List[Dict[str, Any]],
        max_output_tokens: int,
        request_kwargs: Dict[str, Any],
    ) -> Any:
        """
        Route the request through chat.completions using full context.

        Args:
            model_provider: Provider name.
            model_name: Model name.
            input_items: Full normalized item history.
            max_output_tokens: Max output token budget.
            request_kwargs: Additional model request kwargs.

        Returns:
            Responses-normalized response object.
        """
        logger.warning(
            "Falling back to chat.completions for provider='{}' model='{}'.",
            model_provider,
            model_name,
        )
        chat_request_kwargs = self._apply_reasoning_effort_policy(
            provider=model_provider.lower(),
            transport="chat",
            request_kwargs=request_kwargs,
            max_output_tokens=max_output_tokens,
        )
        return self.client.create_response(
            model_provider=model_provider,
            model_name=model_name,
            input_items=input_items,
            max_output_tokens=max_output_tokens,
            force_chat_completion=True,
            **chat_request_kwargs,
        )

    def _extract_response_id(self, response: Any) -> Optional[str]:
        """
        Extract response identifier from an SDK/model payload.

        Args:
            response: Response payload object.

        Returns:
            Response id string when available, otherwise None.
        """
        if isinstance(response, dict):
            response_id = response.get("id")
        else:
            response_id = getattr(response, "id", None)

        if isinstance(response_id, str) and response_id:
            return response_id
        return None

    def _call_openai_responses_with_chain(
        self,
        model_provider: str,
        model_name: str,
        input_items: List[Dict[str, Any]],
        max_output_tokens: int,
        request_kwargs: Dict[str, Any],
    ) -> Any:
        """
        Execute OpenAI Responses with ``previous_response_id`` chaining when possible.

        Args:
            model_provider: Provider name (expected ``openai``).
            model_name: Model name.
            input_items: Full normalized item history.
            max_output_tokens: Max output token budget.
            request_kwargs: Additional model request kwargs.

        Returns:
            Responses-normalized response object.
        """
        chain_key = self._build_responses_chain_key(model_provider, model_name)
        chain_state = self._get_chain_state(chain_key)
        request_signature = self._build_request_signature(
            provider=model_provider,
            model_name=model_name,
            max_output_tokens=max_output_tokens,
            request_kwargs=request_kwargs,
        )
        external_items = self._extract_external_input_items(input_items)

        responses_kwargs = deepcopy(request_kwargs)
        request_items = input_items
        chain_attempt = False
        if self._can_continue_responses_chain(chain_state, request_signature, external_items):
            previous_count = chain_state.get("external_input_count", 0)
            request_items = external_items[previous_count:]
            previous_response_id = chain_state.get("last_response_id")
            if not request_items or not isinstance(previous_response_id, str):
                self._clear_chain_state(chain_key)
                request_items = input_items
            else:
                responses_kwargs["previous_response_id"] = previous_response_id
                chain_attempt = True

        last_exc: Optional[Exception] = None
        for attempt in range(RESPONSES_CHAIN_RETRY_ATTEMPTS + 1):
            try:
                response = self.client.create_response(
                    model_provider=model_provider,
                    model_name=model_name,
                    input_items=request_items,
                    max_output_tokens=max_output_tokens,
                    **responses_kwargs,
                )
                response_id = self._extract_response_id(response)
                if response_id:
                    self._set_chain_state(
                        chain_key,
                        {
                            "last_response_id": response_id,
                            "request_signature": request_signature,
                            "external_input_count": len(external_items),
                            "external_input_hash": self._hash_items(external_items),
                            "updated_at": time.time(),
                        },
                    )
                else:
                    self._clear_chain_state(chain_key)
                return response
            except Exception as exc:
                last_exc = exc
                if attempt < RESPONSES_CHAIN_RETRY_ATTEMPTS and self._is_transient_responses_error(exc):
                    logger.warning(
                        "Transient Responses error (attempt {}/{}). Retrying.",
                        attempt + 1,
                        RESPONSES_CHAIN_RETRY_ATTEMPTS,
                    )
                    self._sleep_before_retry(attempt)
                    continue
                break

        if chain_attempt and last_exc is not None and self._is_chain_reset_error(last_exc):
            self._clear_chain_state(chain_key)
            recovery_kwargs = deepcopy(request_kwargs)
            recovery_kwargs.pop("previous_response_id", None)
            try:
                response = self.client.create_response(
                    model_provider=model_provider,
                    model_name=model_name,
                    input_items=input_items,
                    max_output_tokens=max_output_tokens,
                    **recovery_kwargs,
                )
                response_id = self._extract_response_id(response)
                if response_id:
                    self._set_chain_state(
                        chain_key,
                        {
                            "last_response_id": response_id,
                            "request_signature": request_signature,
                            "external_input_count": len(external_items),
                            "external_input_hash": self._hash_items(external_items),
                            "updated_at": time.time(),
                        },
                    )
                else:
                    self._clear_chain_state(chain_key)
                return response
            except Exception:
                return self._call_chat_fallback(
                    model_provider=model_provider,
                    model_name=model_name,
                    input_items=input_items,
                    max_output_tokens=max_output_tokens,
                    request_kwargs=request_kwargs,
                )

        if last_exc is not None:
            raise last_exc

        raise RuntimeError("Unexpected state: Responses call exited without response or error.")

    def _validate_response_shape(self, response: Any) -> Any:
        """
        Validate normalized response shape and surface provider failure envelopes.

        Args:
            response: Model response payload.

        Returns:
            The same response object when valid.

        Raises:
            Exception: If the payload encodes a failed response envelope.
        """
        def _get(obj: Any, key: str, default: Any = None) -> Any:
            """Read an attribute-like key from dict or object payloads."""
            if isinstance(obj, dict):
                return obj.get(key, default)
            return getattr(obj, key, default)

        failure = bool(
            _get(response, "error")
            or _get(response, "success") is False
            or _get(response, "status") == "failed"
        )
        if not failure:
            return response

        err = _get(response, "error") or {}
        code = _get(err, "code", 500)
        message = _get(err, "message", "Agent failed to process the request")
        normalized = {
            "error": {"message": str(message)},
            "requestId": None,
            "context": {
                "provider": self.model.full_name.split("/")[0],
                "model": self.model.name,
            },
        }
        raise Exception(f"Error code: {int(code)} - {normalized}")

    def _resolve_default_reasoning_effort(self) -> str:
        """
        Resolve default reasoning effort from persisted configuration.

        Returns:
            Normalized reasoning effort value. Falls back to ``none``.
        """
        configured_effort = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_REASONING_EFFORT)
        normalized_effort = normalize_reasoning_effort(configured_effort)
        return normalized_effort or "none"

    def _resolve_requested_reasoning_effort(self, request_kwargs: Dict[str, Any]) -> tuple[Dict[str, Any], str]:
        """
        Resolve requested reasoning effort from explicit kwargs or default config.

        Args:
            request_kwargs: Request kwargs merged from model params and call kwargs.

        Returns:
            Tuple of sanitized kwargs and selected normalized effort.
        """
        normalized_kwargs = deepcopy(request_kwargs)
        reasoning_payload = normalized_kwargs.get("reasoning")
        explicit_effort: Optional[str] = None
        if isinstance(reasoning_payload, dict):
            explicit_effort = normalize_reasoning_effort(reasoning_payload.get("effort"))
        elif isinstance(reasoning_payload, str):
            explicit_effort = normalize_reasoning_effort(reasoning_payload)

        if "reasoning_effort" in normalized_kwargs:
            kwargs_effort = normalize_reasoning_effort(normalized_kwargs.pop("reasoning_effort"))
            if kwargs_effort is not None:
                explicit_effort = kwargs_effort

        selected_effort = explicit_effort or self._resolve_default_reasoning_effort()
        return normalized_kwargs, selected_effort

    def _map_chat_reasoning_effort(self, selected_effort: str) -> Optional[str]:
        """
        Map canonical effort levels to chat-compatible effort values.

        Args:
            selected_effort: Canonical effort value.

        Returns:
            Chat-compatible effort value, or ``None`` if unsupported.
        """
        if selected_effort in CHAT_REASONING_EFFORTS:
            return selected_effort
        if selected_effort == "minimal":
            return "low"
        return None

    def _resolve_anthropic_thinking_budget_tokens(self, effort: str, max_output_tokens: int) -> Optional[int]:
        """
        Resolve Anthropic thinking budget from reasoning effort and output budget.

        Args:
            effort: Chat-compatible reasoning effort.
            max_output_tokens: Current max output tokens budget.

        Returns:
            Thinking budget tokens for Anthropic chat requests, or ``None``.
        """
        base_budget = ANTHROPIC_THINKING_BUDGET_BY_EFFORT.get(effort)
        if base_budget is None:
            return None

        if max_output_tokens <= 0:
            return None

        bounded_budget = min(base_budget, max_output_tokens)
        if bounded_budget < MIN_ANTHROPIC_THINKING_BUDGET:
            return None

        return bounded_budget

    def _apply_anthropic_chat_reasoning_defaults(
        self,
        request_kwargs: Dict[str, Any],
        effort: str,
        max_output_tokens: int,
    ) -> Dict[str, Any]:
        """
        Add Anthropic chat-compatible thinking settings for a selected effort.

        Args:
            request_kwargs: Request kwargs for chat transport.
            effort: Chat-compatible reasoning effort value.
            max_output_tokens: Current max output tokens budget.

        Returns:
            Updated kwargs with Anthropic-compatible ``extra_body.thinking``.
        """
        updated_kwargs = deepcopy(request_kwargs)
        budget_tokens = self._resolve_anthropic_thinking_budget_tokens(
            effort=effort,
            max_output_tokens=max_output_tokens,
        )
        if budget_tokens is None:
            return updated_kwargs

        extra_body = updated_kwargs.get("extra_body")
        if not isinstance(extra_body, dict):
            extra_body = {}
        else:
            extra_body = deepcopy(extra_body)

        thinking_payload = extra_body.get("thinking")
        if not isinstance(thinking_payload, dict):
            extra_body["thinking"] = {
                "type": "enabled",
                "budget_tokens": budget_tokens,
            }
            updated_kwargs["extra_body"] = extra_body
            return updated_kwargs

        if "budget_tokens" not in thinking_payload:
            thinking_payload = deepcopy(thinking_payload)
            thinking_payload["type"] = thinking_payload.get("type") or "enabled"
            thinking_payload["budget_tokens"] = budget_tokens
            extra_body["thinking"] = thinking_payload
            updated_kwargs["extra_body"] = extra_body

        return updated_kwargs

    def _apply_reasoning_effort_policy(
        self,
        provider: str,
        transport: str,
        request_kwargs: Dict[str, Any],
        max_output_tokens: int,
    ) -> Dict[str, Any]:
        """
        Apply provider- and transport-aware reasoning effort configuration.

        Args:
            provider: Lowercase provider name (for example ``openai``).
            transport: Target transport, either ``responses`` or ``chat``.
            request_kwargs: Request kwargs merged from model params and call kwargs.
            max_output_tokens: Current max output token budget.

        Returns:
            Updated kwargs ready for the selected transport.
        """
        normalized_kwargs, selected_effort = self._resolve_requested_reasoning_effort(request_kwargs)
        supported_efforts = get_model_reasoning_efforts(self.model)
        supported_non_none = {effort for effort in supported_efforts if effort != "none"}
        effective_effort = selected_effort
        if transport == "chat" and selected_effort == "minimal" and "low" in supported_non_none:
            effective_effort = "low"

        reasoning_payload = normalized_kwargs.get("reasoning")
        if effective_effort == "none" or effective_effort not in supported_non_none:
            if isinstance(reasoning_payload, dict):
                updated_payload = deepcopy(reasoning_payload)
                updated_payload.pop("effort", None)
                if updated_payload:
                    normalized_kwargs["reasoning"] = updated_payload
                else:
                    normalized_kwargs.pop("reasoning", None)
            else:
                normalized_kwargs.pop("reasoning", None)
            normalized_kwargs.pop("reasoning_effort", None)
            return normalized_kwargs

        if transport == "responses":
            updated_payload = deepcopy(reasoning_payload) if isinstance(reasoning_payload, dict) else {}
            updated_payload["effort"] = effective_effort
            normalized_kwargs["reasoning"] = updated_payload
            normalized_kwargs.pop("reasoning_effort", None)
            return normalized_kwargs

        normalized_kwargs.pop("reasoning", None)
        chat_effort = self._map_chat_reasoning_effort(effective_effort)
        if chat_effort is None:
            normalized_kwargs.pop("reasoning_effort", None)
            return normalized_kwargs

        normalized_kwargs["reasoning_effort"] = chat_effort
        if provider == "anthropic":
            normalized_kwargs = self._apply_anthropic_chat_reasoning_defaults(
                request_kwargs=normalized_kwargs,
                effort=chat_effort,
                max_output_tokens=max_output_tokens,
            )

        return normalized_kwargs

    def generate_response(self, messages: Union[List[dict], deque[dict]], **kwargs: Any) -> Any:
        """
        Generate a response from conversation history.

        Args:
            messages: Conversation history as legacy chat messages or Responses items.
            **kwargs: Additional request parameters.

        Returns:
            Normalized Responses-style object.
        """
        def _contains_non_text_blocks(message: Dict[str, Any]) -> bool:
            """Return whether a legacy chat message contains non-text content blocks."""
            content = message.get("content")
            if isinstance(content, list):
                for item in content:
                    if isinstance(item, dict):
                        item_type = item.get("type")
                        if item_type and item_type not in {"text"}:
                            return True
            return False

        def _is_item_message(message: Dict[str, Any]) -> bool:
            """Return whether a dict follows Responses item shape."""
            return isinstance(message, dict) and isinstance(message.get("type"), str)

        def _is_item_list(msgs: List[Dict[str, Any]]) -> bool:
            """Return whether all messages already use Responses item shape."""
            return bool(msgs) and all(_is_item_message(msg) for msg in msgs)

        def _has_system_message(msgs: List[Dict[str, Any]]) -> bool:
            """Return whether the conversation already includes a system-role message."""
            for message in msgs:
                if not isinstance(message, dict):
                    continue
                if message.get("role") == MessageRole.SYSTEM.value:
                    return True
            return False

        def _normalize_mixed_messages(msgs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            """Normalize mixed legacy+item message lists into pure Responses items."""
            has_item = any(_is_item_message(msg) for msg in msgs if isinstance(msg, dict))
            has_legacy = any(
                isinstance(msg, dict) and "role" in msg and not _is_item_message(msg)
                for msg in msgs
            )
            if not (has_item and has_legacy):
                return msgs

            normalized: List[Dict[str, Any]] = []
            for message in msgs:
                if not isinstance(message, dict):
                    continue
                if _is_item_message(message):
                    normalized.append(message)
                    continue
                if "role" in message:
                    normalized.extend(chat_messages_to_items([message]))
            return normalized

        message_list = list(messages) if isinstance(messages, deque) else list(messages)
        message_list = _normalize_mixed_messages(message_list)
        is_item_format = _is_item_list(message_list)

        if not _has_system_message(message_list) and self.system_prompt:
            if is_item_format:
                system_message: Dict[str, Any] = {
                    "type": "message",
                    "role": MessageRole.SYSTEM.value,
                    "content": [{"type": "input_text", "text": self.system_prompt}],
                }
            else:
                system_message = {
                    "role": MessageRole.SYSTEM.value,
                    "content": self.system_prompt,
                }
            message_list.insert(0, system_message)
            is_item_format = _is_item_list(message_list)

        max_tokens = self._adjust_max_tokens_for_context(message_list)

        try:
            provider = self.model.full_name.split("/")[0]

            if message_list and not is_item_format:
                if any(_contains_non_text_blocks(msg) for msg in message_list if isinstance(msg, dict)):
                    response = self.client.chat_completion(
                        model_provider=provider,
                        model_name=self.model.name,
                        max_tokens=max_tokens,
                        messages=message_list,
                        **self.params,
                        **kwargs
                    )
                    return response_from_chat_completion(response)

                message_list = chat_messages_to_items(message_list)
                is_item_format = True

            request_kwargs = {**self.params, **kwargs}
            target_transport = "responses" if provider.lower() == "openai" else "chat"
            request_kwargs = self._apply_reasoning_effort_policy(
                provider=provider.lower(),
                transport=target_transport,
                request_kwargs=request_kwargs,
                max_output_tokens=max_tokens,
            )
            if provider.lower() == "openai":
                response = self._call_openai_responses_with_chain(
                    model_provider=provider,
                    model_name=self.model.name,
                    input_items=message_list,
                    max_output_tokens=max_tokens,
                    request_kwargs=request_kwargs,
                )
            else:
                response = self.client.create_response(
                    model_provider=provider,
                    model_name=self.model.name,
                    input_items=message_list,
                    max_output_tokens=max_tokens,
                    **request_kwargs,
                )

            return self._validate_response_shape(response)
        except Exception as e:
            logger.error(f"Error in generate_response: {e}")
            raise
