from coda_core.core.models.providers.responses_api.enums import ItemType, MessageRole, ReasoningEffort


RESPONSES_CHAIN_RETRY_ATTEMPTS = 2
RESPONSES_TRANSIENT_STATUS_CODES = {408, 409, 429, 500, 502, 503, 504}
RESPONSES_CHAIN_RESET_ERROR_MARKERS = (
    "litellm general error",
    "previous_response_id",
    "response id",
    "not found",
)
RESPONSES_EXTERNAL_MESSAGE_ROLES = {
    MessageRole.SYSTEM.value,
    MessageRole.USER.value,
    MessageRole.DEVELOPER.value,
}
RESPONSES_EXTERNAL_ITEM_TYPES = {
    ItemType.FUNCTION_CALL_OUTPUT.value,
    ItemType.FUNCTION_TOOL_CALL_OUTPUT.value,
}
RESPONSES_GATEWAY_INCOMPATIBLE_ITEM_TYPES = {
    ItemType.FUNCTION_CALL.value,
    ItemType.FUNCTION_TOOL_CALL.value,
    ItemType.REASONING.value,
}
CHAT_REASONING_EFFORTS = {
    ReasoningEffort.LOW.value,
    ReasoningEffort.MEDIUM.value,
    ReasoningEffort.HIGH.value,
}
ANTHROPIC_THINKING_BUDGET_BY_EFFORT = {
    ReasoningEffort.LOW.value: 2048,
    ReasoningEffort.MEDIUM.value: 4096,
    ReasoningEffort.HIGH.value: 8192,
}
MIN_ANTHROPIC_THINKING_BUDGET = 1024
