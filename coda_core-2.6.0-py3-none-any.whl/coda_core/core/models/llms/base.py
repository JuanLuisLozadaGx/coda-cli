from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, TYPE_CHECKING

from coda_core.core.models.schemas import Model

if TYPE_CHECKING:
    from coda_core.core.models.providers.geai_client import GEAIClient


class LLM(ABC):
    """
    Abstract base class for Language Models (LLMs).

    Attributes:
        model (Model): The model configuration and metadata.
        params (Dict[str, Any]): Optional parameters for the LLM.
        client (GEAIClient): The client for interacting with the model.
        system_prompt (Optional[str]): Optional system prompt for the LLM.
    """

    def __init__(
        self,
        client: 'GEAIClient',
        provider_name: str,
        model_name: str,
        system_prompt: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Initializes the LLM with the specified provider, model name, and optional parameters.

        Args:
            client (GEAIClient): The client for interacting with the model.
            provider_name (str): The provider of the model (e.g., "openai").
            model_name (str): The name of the model (e.g., "gpt-4o").
            system_prompt (Optional[str], optional): Optional system prompt for the LLM. Defaults to None.
            params (Optional[Dict[str, Any]], optional): Optional parameters for the LLM. Defaults to an empty dictionary.
        """
        self.client = client
        self.model = self._create_model(provider_name, model_name)
        self.system_prompt = system_prompt
        self.params = params if params is not None else {}

    @abstractmethod
    def generate_response(
        self, messages: List[Dict[str, Any]], kwargs: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Generate a response based on the provided messages.

        Args:
            messages (List[Dict[str, Any]]): A list of message objects to process.
            kwargs (Optional[Dict[str, Any]], optional): Additional parameters for generating the response. Defaults to None.

        Returns:
            str: The generated response from the LLM.
        """
        pass


    def get_model_info(self) -> Dict[str, str]:
        """
        Retrieve information about the chat model.

        Returns:
            Dict[str, str]: A dictionary containing model information.
        """
        return self.model.model_dump_json()


    def update_model(self, provider_name: str, model_name: str) -> bool:
        """
        Update the LLM to use a different provider and model.
        
        This method updates the model attribute of the LLM instance
        while keeping the same system prompt and parameters.
        
        Args:
            provider_name (str): The new provider name
            model_name (str): The new model name
            
        Returns:
            bool: True if the model was successfully updated, False otherwise
        """
        try:
            # Create a new model instance with the updated provider and model
            new_model = self._create_model(provider_name, model_name)
            
            # Update the model attribute
            self.model = new_model
            
            return True
        except Exception:
            return False
    
    
    def _create_model(self, provider_name: str, model_name: str) -> Model:
        """
        Create a Model instance based on the provider and model name.

        Args:
            provider_name (str): The provider of the model (e.g., "openai").
            model_name (str): The name of the model (e.g., "gpt-4o").

        Returns:
            Model: The created Model instance.

        Raises:
            ValueError: If the specified model is not available on the client.
        """
        model = self.client.check_model_availability(
            provider_name=provider_name, model_name=model_name
        )
        if not model:
            raise ValueError(
                f"Model '{model_name}' from provider '{provider_name}' is not available on client '{self.client.base_url}'."
            )
        return model