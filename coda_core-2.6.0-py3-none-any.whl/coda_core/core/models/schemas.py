from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class Provider(BaseModel):
    description: str = Field(..., description="A brief description of the provider")
    interface_type: str = Field(..., description="The type of interface the provider uses", alias='interfaceType')
    name: str = Field(..., description="The name of the provider")

class Property(BaseModel):
    id: str = Field(..., description="The unique identifier for the property")
    name: str = Field(..., description="The name of the property")
    type: str = Field(..., description="The type of the property")
    value: str = Field(..., description="The value of the property")

class Model(BaseModel):
    context_window: int = Field(..., ge=0, description="The context window size, must be non-negative", alias='contextWindow')
    description: Optional[str] = Field(None, description="A description of the model's capabilities")                                   # Sometimes, this field is not present
    full_name: str = Field(..., description="The full name of the model", alias='fullName')
    id: str = Field(..., description="The unique identifier for the model")
    is_custom: bool = Field(..., description="Indicates if the model is custom", alias='isCustom')
    max_output_tokens: int = Field(..., ge=0, description="The maximum number of output tokens allowed", alias='maxOutputTokens')
    name: str = Field(..., description="The name of the model")
    priority: int = Field(..., ge=0, description="The priority level of the model")
    properties: List[Property] = Field(default_factory=list, description="A list of properties associated with the model")              # Sometimes, there are no properties
    type: str = Field(..., description="The type of the model")

class ProviderWithModels(BaseModel):
    provider: Provider = Field(..., description="Provider information")
    models: List[Model] = Field(default_factory=list, description="A list of models associated with the provider")

class GEAIInstanceInfo(BaseModel):
    providers_with_models: List[ProviderWithModels] = Field(..., description="A list of providers and their associated models for the SAIA instance")


class AgentSummary(BaseModel):
    """Summary of a GEAI agent exposed by the public agents API."""

    id: str = Field(..., description="Unique identifier for the agent")
    name: str = Field(..., description="Agent name")
    description: Optional[str] = Field(None, description="Agent description")
    status: str = Field(..., description="Agent status (active, inactive, etc.)")
    version: Optional[int] = Field(None, description="Agent version")
    revision: Optional[int] = Field(None, description="Agent revision")
    created_at: Optional[str] = Field(None, description="Creation timestamp", alias="createdAt")
    updated_at: Optional[str] = Field(None, description="Last update timestamp", alias="updatedAt")


class AgentDetail(BaseModel):
    """Detailed information for a specific GEAI agent."""

    id: str = Field(..., description="Unique identifier for the agent")
    name: str = Field(..., description="Agent name")
    description: Optional[str] = Field(None, description="Agent description")
    status: str = Field(..., description="Agent status")
    version: Optional[int] = Field(None, description="Agent version")
    revision: Optional[int] = Field(None, description="Agent revision")
    prompt: Optional[str] = Field(None, description="Agent prompt/instructions")
    tools: Optional[List[str]] = Field(default_factory=list, description="Tools available to the agent")
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional agent metadata")
    created_at: Optional[str] = Field(None, description="Creation timestamp", alias="createdAt")
    updated_at: Optional[str] = Field(None, description="Last update timestamp", alias="updatedAt")
