# HTTP/client constants for the models module

# Total attempts: initial try + (HTTP_MAX_ATTEMPTS - 1) retries
HTTP_MAX_ATTEMPTS: int = 3

# Default per-request timeout (seconds)
HTTP_DEFAULT_TIMEOUT: float = 10.0

# Exponential backoff with equal jitter parameters (aligned with LLM module practices)
# Base delay (seconds) used to compute exponential growth: base * (2 ** attempt_index), capped by multiplier
HTTP_BACKOFF_BASE_DELAY: float = 0.5

# Caps exponential growth at 2 ** HTTP_BACKOFF_MAX_MULTIPLIER (e.g., 3 → up to 8x base)
HTTP_BACKOFF_MAX_MULTIPLIER: int = 3

# Equal jitter factor: delay/factor + random(0, delay/factor)
# Example: delay=4s, factor=2.0 → guaranteed 2s + random 0–2s → 2–4s
HTTP_BACKOFF_JITTER_FACTOR: float = 2.0