from typing import Any, Dict, Optional, TYPE_CHECKING


if TYPE_CHECKING:
    from openai import OpenAI

def create_oai_client(api_key: str, base_url: str, default_headers: Optional[Dict[str, str]] = None) -> 'OpenAI':
    """
    Creates and returns an OpenAI client with the specified configuration.
    Lazily imports the `OpenAI` class.

    **Note**: the reason for lazy imports is to improve startup time on different
    clients of the `coda-core` package, since the OpenAI import can be slow.

    Args:
        api_key (str): The API key for authentication.
        base_url (str): The base URL for the OpenAI API.
        default_headers (Optional[Dict[str, str]]): Optional dictionary of default headers to include in all requests.

    Returns:
        OpenAI: An instance of the OpenAI client.
    """
    from openai import OpenAI
    return OpenAI(api_key=api_key, base_url=base_url, default_headers=default_headers or {})


def is_completion_usage(obj: Any) -> bool:
    """
    Check if the given object is an instance of OpenAI `CompletionUsage` type.
    Lazily imports the `CompletionUsage` class.

    **Note**: the reason for lazy imports is to improve startup time on different
    clients of the `coda-core` package, since the OpenAI import can be slow.

    Args:
        obj (Any): The object to check.

    Returns:
        bool: True if the object is an instance of CompletionUsage, False otherwise.
    """
    from openai.types.completion_usage import CompletionUsage
    return isinstance(obj, CompletionUsage)
