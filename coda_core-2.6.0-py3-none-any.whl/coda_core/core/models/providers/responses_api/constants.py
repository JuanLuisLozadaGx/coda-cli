from typing import Final

from coda_core.core.models.providers.responses_api.enums import ImageDetail


# Discriminator strings
ALLOWED_TOOLS_DISCRIMINATOR: Final[str] = "allowed_tools"

# Limits and bounds
TOP_LOGPROBS_MAX: Final[int] = 20
TOP_LOGPROBS_MIN: Final[int] = 0

# Defaults
DEFAULT_IMAGE_DETAIL: Final[ImageDetail] = ImageDetail.AUTO