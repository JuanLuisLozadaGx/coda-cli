from typing import Any, Dict, List, Optional, Union, Literal

from pydantic import BaseModel, Field

from coda_core.core.models.providers.responses_api.enums import MessageRole, ItemStatus, LegacyFinishReason, ImageDetail, ItemType


class FileCitation(BaseModel):
    """Citation to a file.

    Attributes:
        type: Discriminator ('file_citation').
        file_id: File identifier.
        filename: Filename for display.
        index: File index.
    """
    type: Literal[ItemType.FILE_CITATION] = Field(default=ItemType.FILE_CITATION, description="Discriminator")
    file_id: str = Field(..., description="File ID")
    filename: str = Field(..., description="Filename")
    index: int = Field(..., ge=0, description="File index")


class URLCitation(BaseModel):
    """Citation to a URL.

    Attributes:
        type: Discriminator ('url_citation').
        end_index: End char index in the text.
        start_index: Start char index in the text.
        title: Title of the resource.
        url: URL string.
    """
    type: Literal[ItemType.URL_CITATION] = Field(default=ItemType.URL_CITATION, description="Discriminator")
    end_index: int = Field(..., ge=0, description="End character index")
    start_index: int = Field(..., ge=0, description="Start character index")
    title: str = Field(..., description="Resource title")
    url: str = Field(..., description="Resource URL")


class ContainerFileCitation(BaseModel):
    """Citation to a file inside a container.

    Attributes:
        type: Discriminator ('container_file_citation').
        container_id: Container identifier.
        end_index: End char index.
        file_id: File identifier.
        filename: Filename for display.
        start_index: Start char index.
    """
    type: Literal[ItemType.CONTAINER_FILE_CITATION] = Field(default=ItemType.CONTAINER_FILE_CITATION, description="Discriminator")
    container_id: str = Field(..., description="Container ID")
    end_index: int = Field(..., ge=0, description="End character index")
    file_id: str = Field(..., description="File ID")
    filename: str = Field(..., description="Filename")
    start_index: int = Field(..., ge=0, description="Start character index")


class FilePath(BaseModel):
    """File path annotation.

    Attributes:
        type: Discriminator ('file_path').
        file_id: File identifier.
        index: File index.
    """
    type: Literal[ItemType.FILE_PATH] = Field(default=ItemType.FILE_PATH, description="Discriminator")
    file_id: str = Field(..., description="File ID")
    index: int = Field(..., ge=0, description="File index")


Annotation = Union[FileCitation, URLCitation, ContainerFileCitation, FilePath]


class TopLogProbEntry(BaseModel):
    """Alternative token with probability information.

    Attributes:
        bytes: Byte-level representation of the token.
        logprob: Log probability.
        token: Token string.
    """
    bytes: List[int] = Field(..., description="Token bytes")
    logprob: float = Field(..., description="Log probability")
    token: str = Field(..., description="Token")


class OutputLogProbEntry(BaseModel):
    """Token-level log probability details.

    Attributes:
        bytes: Byte-level representation of the token.
        logprob: Log probability of the token.
        token: Token string.
        top_logprobs: Alternatives with probabilities.
    """
    bytes: List[int] = Field(..., description="Token bytes")
    logprob: float = Field(..., description="Log probability")
    token: str = Field(..., description="Token")
    top_logprobs: List[TopLogProbEntry] = Field(default_factory=list, description="Top alternative tokens")


class OutputText(BaseModel):
    """Assistant output text block.

    Attributes:
        type: Discriminator ('output_text').
        text: Output text (may be empty).
        annotations: List of annotations/citations.
        logprobs: Optional token-level probabilities.
    """
    type: Literal[ItemType.OUTPUT_TEXT] = Field(default=ItemType.OUTPUT_TEXT, description="Discriminator")
    text: Optional[str] = Field(default="", description="Output text")
    annotations: List[Annotation] = Field(default_factory=list, description="Text annotations")
    logprobs: List[OutputLogProbEntry] = Field(default_factory=list, description="Token logprobs")


class Refusal(BaseModel):
    """Assistant refusal explanation.

    Attributes:
        type: Discriminator ('refusal').
        refusal: Explanation text.
    """
    type: Literal[ItemType.REFUSAL] = Field(default=ItemType.REFUSAL, description="Discriminator")
    refusal: str = Field(..., description="Refusal explanation")


OutputMessageContent = Union[OutputText, Refusal]


class InputText(BaseModel):
    """Text input to the model.

    Attributes:
        type: Discriminator ('input_text').
        text: Text content.
    """
    type: Literal[ItemType.INPUT_TEXT] = Field(default=ItemType.INPUT_TEXT, description="Discriminator")
    text: str = Field(..., description="Input text")


class InputImage(BaseModel):
    """Image input to the model.

    Attributes:
        type: Discriminator ('input_image').
        detail: Desired detail level.
        file_id: Optional uploaded file ID.
        image_url: Optional URL or data URL.
    """
    type: Literal[ItemType.INPUT_IMAGE] = Field(default=ItemType.INPUT_IMAGE, description="Discriminator")
    detail: Optional[ImageDetail] = Field(default=ImageDetail.AUTO, description="Detail level")
    file_id: Optional[str] = Field(default=None, description="Image file ID")
    image_url: Optional[str] = Field(default=None, description="Image URL or data URL")


class InputFile(BaseModel):
    """Generic file input to the model.

    Attributes:
        type: Discriminator ('input_file').
        file_data: Base64-encoded file contents.
        file_id: Optional uploaded file ID.
        file_url: Optional fetch URL.
        filename: Optional filename for display.
    """
    type: Literal[ItemType.INPUT_FILE] = Field(default=ItemType.INPUT_FILE, description="Discriminator")
    file_data: Optional[str] = Field(default=None, description="Base64-encoded file data")
    file_id: Optional[str] = Field(default=None, description="File ID")
    file_url: Optional[str] = Field(default=None, description="File URL")
    filename: Optional[str] = Field(default=None, description="Filename")


MessageContentItem = Union[InputText, InputImage, InputFile]


class InputMessage(BaseModel):
    """User/system/developer input message.

    Attributes:
        type: Discriminator ('message').
        role: Message role.
        content: Text or list of input content items.
        status: Optional status (set by API when echoed back).
    """
    type: Literal[ItemType.MESSAGE] = Field(default=ItemType.MESSAGE, description="Discriminator")
    role: MessageRole = Field(..., description="Message role")
    content: Union[str, List[MessageContentItem]] = Field(..., description="Text or input content items")
    status: Optional[ItemStatus] = Field(default=None, description="Optional item status")

    def flatten_content(self) -> str:
        """Flatten message content (text or list of items) into a string.

        Returns:
            Concatenated string of textual parts, or a best-effort description for non-text items.
        """
        if isinstance(self.content, str):
            return self.content
        parts: List[str] = []
        for item in self.content:
            if hasattr(item, "text"):
                text = getattr(item, "text", "")
                if text:
                    parts.append(str(text))
            else:
                parts.append(item.__class__.__name__)
        return " ".join(parts).strip()


class OutputMessage(BaseModel):
    """Assistant output message.

    Attributes:
        type: Discriminator ('message').
        id: Item identifier.
        role: Always 'assistant'.
        status: Item status.
        content: List of output content blocks.
    """
    type: Literal[ItemType.MESSAGE] = Field(default=ItemType.MESSAGE, description="Discriminator")
    id: str = Field(..., description="Message item ID")
    role: Literal[MessageRole.ASSISTANT] = Field(default=MessageRole.ASSISTANT, description="Always 'assistant'")
    status: ItemStatus = Field(..., description="Item status")
    content: List[OutputMessageContent] = Field(..., description="Output content blocks")

    def text_blocks(self) -> List[OutputText]:
        """Return all OutputText blocks contained in this message.
    
        Returns:
            List of OutputText items present in content.
        """
        return [block for block in self.content if isinstance(block, OutputText)]


class LegacyOutputMessage(BaseModel):
    """Assistant output message (legacy Chat Completions).

    Attributes:
        type: Discriminator ('message').
        id: Item identifier.
        role: Always 'assistant'.
        status: Legacy finish_reason value (e.g., 'stop', 'length', 'tool_calls', 'content_filter').
        content: List of output content blocks.
    """
    type: Literal[ItemType.MESSAGE] = Field(default=ItemType.MESSAGE, description="Discriminator")
    id: str = Field(..., description="Message item ID")
    role: Literal[MessageRole.ASSISTANT] = Field(default=MessageRole.ASSISTANT, description="Always 'assistant'")
    status: LegacyFinishReason = Field(..., description="Legacy Chat Completions finish_reason")
    content: List[OutputMessageContent] = Field(..., description="Output content blocks")


class FunctionToolCall(BaseModel):
    """Function tool call request from the model.

    Attributes:
        type: Discriminator ('function_call' or 'function_tool_call').
        call_id: Unique call identifier.
        name: Function name.
        arguments: JSON string arguments.
        id: Optional item ID.
        status: Optional status.
    """
    type: Union[Literal[ItemType.FUNCTION_CALL], Literal[ItemType.FUNCTION_TOOL_CALL]] = Field(
        default=ItemType.FUNCTION_CALL,
        description="Discriminator",
    )
    call_id: str = Field(..., description="Function call ID")
    name: str = Field(..., description="Function name")
    arguments: str = Field(..., description="JSON string arguments")
    id: Optional[str] = Field(default=None, description="Optional item ID")
    status: Optional[ItemStatus] = Field(default=None, description="Optional item status")


class FunctionToolCallOutput(BaseModel):
    """Function tool call output to the model.

    Attributes:
        type: Discriminator ('function_call_output' or 'function_tool_call_output').
        call_id: Correlated function call ID.
        output: JSON string or array of input items representing output.
        id: Optional item ID.
        status: Optional item status.
    """
    type: Union[Literal[ItemType.FUNCTION_CALL_OUTPUT], Literal[ItemType.FUNCTION_TOOL_CALL_OUTPUT]] = Field(
        default=ItemType.FUNCTION_CALL_OUTPUT,
        description="Discriminator",
    )
    call_id: str = Field(..., description="Function call ID")
    output: Union[str, List[MessageContentItem]] = Field(..., description="Tool output body")
    id: Optional[str] = Field(default=None, description="Optional item ID")
    status: Optional[ItemStatus] = Field(default=None, description="Optional item status")


class ReasoningText(BaseModel):
    """Reasoning text item.

    Attributes:
        type: Discriminator ('reasoning_text').
        text: Reasoning text body.
    """
    type: Literal[ItemType.REASONING_TEXT] = Field(default=ItemType.REASONING_TEXT, description="Discriminator")
    text: str = Field(..., description="Reasoning text")


class ReasoningSummary(BaseModel):
    """Reasoning summary content.

    Attributes:
        type: Discriminator ('summary_text').
        text: Optional summary text.
    """
    type: Literal[ItemType.SUMMARY_TEXT] = Field(default=ItemType.SUMMARY_TEXT, description="Discriminator")
    text: Optional[str] = Field(default=None, description="Summary text")


class Reasoning(BaseModel):
    """Reasoning container.

    Attributes:
        type: Discriminator ('reasoning').
        id: Reasoning content ID.
        summary: Summary content.
        content: Optional list of detailed reasoning text items.
        encrypted_content: Optional encrypted reasoning content.
        status: Optional item status.
    """
    type: Literal[ItemType.REASONING] = Field(default=ItemType.REASONING, description="Discriminator")
    id: str = Field(..., description="Reasoning content ID")
    summary: List[ReasoningSummary] = Field(..., description="Reasoning summary")
    content: Optional[List[ReasoningText]] = Field(default=None, description="Detailed reasoning text")
    encrypted_content: Optional[str] = Field(default=None, description="Encrypted reasoning content")
    status: Optional[ItemStatus] = Field(default=None, description="Item status")


class ItemReference(BaseModel):
    """Reference to another item by ID.

    Attributes:
        type: Discriminator ('item_reference').
        id: Referenced item ID.
    """
    type: Literal[ItemType.ITEM_REFERENCE] = Field(default=ItemType.ITEM_REFERENCE, description="Discriminator")
    id: str = Field(..., description="Referenced item ID")


class UnknownItem(BaseModel):
    """Raw item preserved when a provider returns an unknown output type.

    Attributes:
        type: Canonical discriminator ('unknown').
        raw: Original raw provider item payload.
        original_type: Original provider item type value, if present.
    """
    type: Literal[ItemType.UNKNOWN] = Field(default=ItemType.UNKNOWN, description="Discriminator")
    raw: Dict[str, Any] = Field(..., description="Original provider payload")
    original_type: Optional[str] = Field(default=None, description="Original provider item type")


InputItem = Union[
    InputMessage,
    FunctionToolCall,
    FunctionToolCallOutput,
    Reasoning,
    ItemReference,
]


OutputItem = Union[
    OutputMessage,
    FunctionToolCall,
    FunctionToolCallOutput,
    Reasoning,
    ItemReference,
    UnknownItem,
]

LegacyOutputItem = Union[
    LegacyOutputMessage,
    FunctionToolCall,
    FunctionToolCallOutput,
    Reasoning,
    ItemReference,
    UnknownItem,
]


Item = Union[InputItem, OutputItem]
