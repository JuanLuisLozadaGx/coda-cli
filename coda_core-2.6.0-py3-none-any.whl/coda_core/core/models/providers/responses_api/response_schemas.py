from typing import Any, Dict, List, Optional, Union, Literal

from pydantic import BaseModel, Field, ConfigDict, model_validator, model_serializer, field_validator

from coda_core.core.models.providers.responses_api.enums import (
    ResponseStatus,
    ToolChoiceMode,
    TruncationStrategy,
    ReasoningEffort,
    ReasoningSummaryLevel,
    ObjectType,
    LegacyObjectType,
    TextFormatKind,
    AllowedToolsType,
)
from coda_core.core.models.providers.responses_api.item_schemas import (
    OutputItem,
    LegacyOutputItem,
    OutputMessage,
    LegacyOutputMessage,
    OutputText,
    MessageRole,
    FunctionToolCall,
)
from coda_core.core.models.providers.responses_api.constants import TOP_LOGPROBS_MAX, TOP_LOGPROBS_MIN


class InputTokensDetails(BaseModel):
    """Detailed breakdown of input tokens.

    Attributes:
        cached_tokens: Number of cached tokens.
    """
    cached_tokens: int = Field(default=0, ge=0, description="Number of cached tokens")


class OutputTokensDetails(BaseModel):
    """Detailed breakdown of output tokens.

    Attributes:
        reasoning_tokens: Number of tokens used for reasoning.
    """
    reasoning_tokens: int = Field(default=0, ge=0, description="Reasoning tokens used")


class Usage(BaseModel):
    """Token usage details for a response.
    
    Supports both Responses API and legacy Chat Completions field names:
    - Responses API: input_tokens, output_tokens
    - Chat Completions: prompt_tokens, completion_tokens

    Attributes:
        input_tokens: Number of input tokens (Responses API).
        prompt_tokens: Number of input tokens (legacy alias).
        input_tokens_details: Optional input token detail.
        output_tokens: Number of output tokens (Responses API).
        completion_tokens: Number of output tokens (legacy alias).
        output_tokens_details: Optional output token detail.
        total_tokens: Total tokens used.
    """
    input_tokens: Optional[int] = Field(default=0, ge=0, description="Input tokens")
    prompt_tokens: Optional[int] = Field(default=0, ge=0, description="Input tokens (legacy alias)")
    input_tokens_details: Optional[InputTokensDetails] = Field(default=None, description="Input token details")
    output_tokens: Optional[int] = Field(default=0, ge=0, description="Output tokens")
    completion_tokens: Optional[int] = Field(default=0, ge=0, description="Output tokens (legacy alias)")
    output_tokens_details: Optional[OutputTokensDetails] = Field(default=None, description="Output token details")
    total_tokens: Optional[int] = Field(default=0, ge=0, description="Total tokens used")
    total_cost: Optional[float] = Field(default=None, description="Total cost")
    currency: Optional[str] = Field(default=None, description="Currency")
    prompt_cost: Optional[float] = Field(default=None, description="Prompt cost")
    completion_cost: Optional[float] = Field(default=None, description="Completion cost")

    @staticmethod
    def _coerce_cost_value(value: Any) -> Optional[float]:
        """Best-effort parse of numeric cost values from provider payloads."""
        if value is None or isinstance(value, bool):
            return None
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return None
            try:
                return float(stripped)
            except ValueError:
                return None
        if isinstance(value, dict):
            for key in ("total", "total_cost", "amount", "value", "usd", "cost"):
                if key in value:
                    parsed = Usage._coerce_cost_value(value.get(key))
                    if parsed is not None:
                        return parsed
        return None

    @classmethod
    def _extract_cost_component(cls, container: Dict[str, Any], keys: tuple[str, ...]) -> Optional[float]:
        """Extract the first numeric cost component from a provider cost container."""
        for key in keys:
            if key not in container:
                continue
            parsed = cls._coerce_cost_value(container.get(key))
            if parsed is not None:
                return parsed
        return None

    @model_validator(mode='before')
    @classmethod
    def normalize_cost_fields(cls, data: Any) -> Any:
        """Normalize provider-specific cost aliases to canonical Usage fields."""
        if not isinstance(data, dict):
            return data

        normalized = dict(data)
        cost_container = normalized.get("cost") or normalized.get("costs")
        if isinstance(cost_container, dict):
            if normalized.get("prompt_cost") is None:
                normalized["prompt_cost"] = cls._extract_cost_component(
                    cost_container,
                    ("prompt_cost", "prompt", "input_cost", "input", "input_tokens_cost"),
                )
            if normalized.get("completion_cost") is None:
                normalized["completion_cost"] = cls._extract_cost_component(
                    cost_container,
                    ("completion_cost", "completion", "output_cost", "output", "output_tokens_cost"),
                )

            if normalized.get("total_cost") is None:
                total_cost = cls._extract_cost_component(
                    cost_container,
                    ("total_cost", "total", "amount"),
                )
                if total_cost is None:
                    prompt_cost = cls._coerce_cost_value(normalized.get("prompt_cost"))
                    completion_cost = cls._coerce_cost_value(normalized.get("completion_cost"))
                    if prompt_cost is not None and completion_cost is not None:
                        total_cost = prompt_cost + completion_cost
                normalized["total_cost"] = total_cost

        if normalized.get("total_cost") is None:
            prompt_cost = cls._coerce_cost_value(normalized.get("prompt_cost"))
            completion_cost = cls._coerce_cost_value(normalized.get("completion_cost"))
            if prompt_cost is not None and completion_cost is not None:
                normalized["total_cost"] = prompt_cost + completion_cost

        return normalized
    
    @field_validator(
        'input_tokens', 'prompt_tokens', 'output_tokens', 'completion_tokens', 'total_tokens',
        mode='before'
    )
    @classmethod
    def convert_none_to_zero(cls, v: Any) -> int:
        """Convert None values to 0 for token counts.
        
        Args:
            v: Input value (may be None, int, or other).
            
        Returns:
            0 if None, otherwise the value.
        """
        return 0 if v is None else v


class ResponseError(BaseModel):
    """Error object when generation fails.

    Attributes:
        code: Optional error code.
        message: Error message.
        type: Optional error type.
    """
    code: Optional[str] = Field(default=None, description="Error code")
    message: str = Field(..., description="Error message")
    type: Optional[str] = Field(default=None, description="Error type")


class IncompleteDetails(BaseModel):
    """Details about an incomplete response.

    Attributes:
        reason: Reason for incompleteness.
    """
    reason: str = Field(..., description="Reason for incompleteness")


class TextFormat(BaseModel):
    """Default text response format."""
    type: Literal[TextFormatKind.TEXT] = Field(default=TextFormatKind.TEXT, description="Format discriminator")


class JSONSchemaFormat(BaseModel):
    """JSON Schema response format for Structured Outputs.

    Attributes:
        type: Discriminator 'json_schema'.
        name: Format name.
        schema: JSON Schema object (aliased as 'schema' to match SDK).
        description: Optional description.
        strict: Whether schema adherence is strict.
    """
    model_config = ConfigDict(populate_by_name=True)

    type: Literal[TextFormatKind.JSON_SCHEMA] = Field(default=TextFormatKind.JSON_SCHEMA, description="Format discriminator")
    name: str = Field(..., description="Format name")
    schema_: Dict[str, Any] = Field(
        ...,
        alias="schema",
        serialization_alias="schema",
        description="JSON Schema definition",
    )
    description: Optional[str] = Field(default=None, description="Format description")
    strict: bool = Field(default=True, description="Enable strict schema adherence")


class JSONObjectFormat(BaseModel):
    """JSON object response format (legacy)."""
    type: Literal[TextFormatKind.JSON_OBJECT] = Field(default=TextFormatKind.JSON_OBJECT, description="Format discriminator")


TextFormatType = Union[TextFormat, JSONSchemaFormat, JSONObjectFormat]


class TextConfig(BaseModel):
    """Configuration for text response formatting.

    Attributes:
        format: Output format specification (text, json_schema, or json_object).
    """
    format: Optional[TextFormatType] = Field(default=None, description="Text output format")


class ReasoningConfig(BaseModel):
    """Configuration for reasoning-capable models.

    Attributes:
        effort: Reasoning effort level.
        summary: Reasoning summary verbosity.
    """
    effort: Optional[ReasoningEffort] = Field(default=None, description="Reasoning effort level")
    summary: Optional[ReasoningSummaryLevel] = Field(default=None, description="Reasoning summary verbosity")


class Conversation(BaseModel):
    """Conversation (stateful) container.

    Attributes:
        id: Conversation identifier.
    """
    id: str = Field(..., description="Conversation ID")


class AllowedTools(BaseModel):
    """Constraint list of allowed tools.

    Attributes:
        type: Discriminator 'allowed_tools'.
        mode: Selection mode (auto or required).
        tools: List of allowed tool definitions.
    """
    type: Literal[AllowedToolsType.ALLOWED_TOOLS] = Field(default=AllowedToolsType.ALLOWED_TOOLS, description="Discriminator")
    mode: ToolChoiceMode = Field(..., description="Tool choice mode")
    tools: List[Dict[str, Any]] = Field(..., description="Allowed tool definitions")


ToolChoiceType = Union[ToolChoiceMode, AllowedTools]


class ResponseObject(BaseModel):
    """Top-level Responses API object.
    
    Supports both Responses API and legacy Chat Completions formats.

    Attributes:
        id: Response identifier.
        object: 'response' (Responses API) or 'chat.completion' (legacy).
        created_at: Unix timestamp.
        status: Response status.
        error: Optional error object if failed.
        incomplete_details: Optional details for incomplete response.
        instructions: Optional instruction metadata.
        max_output_tokens: Optional max output tokens.
        model: Model identifier.
        output: Output items list (supports both formats).
        parallel_tool_calls: Whether tool calls may run in parallel.
        previous_response_id: Previous response identifier in a chain.
        reasoning: Reasoning configuration for reasoning-capable models.
        store: Whether conversation is stored by provider.
        temperature: Sampling temperature.
        text: Text formatting config.
        tool_choice: Tool selection mode or constraints.
        tools: Tool definitions provided to the model.
        top_p: Nucleus sampling.
        truncation: Truncation strategy.
        usage: Token usage (supports both input_tokens/output_tokens and prompt_tokens/completion_tokens).
        user: Caller identifier.
        metadata: Arbitrary metadata.
        conversation: Optional conversation container (stateful).
        background: Optional flag for background execution.
        top_logprobs: Optional top logprobs count.
        max_tool_calls: Optional maximum built-in tool calls.
    """
    id: str = Field(..., description="Response ID")
    object: Union[Literal[ObjectType.RESPONSE], Literal[LegacyObjectType.CHAT_COMPLETION]] = Field(
        default=ObjectType.RESPONSE,
        description="Object discriminator (accepts both 'response' and legacy 'chat.completion')"
    )
    created_at: int = Field(..., ge=0, description="Creation Unix timestamp")
    status: ResponseStatus = Field(..., description="Response status")
    error: Optional[ResponseError] = Field(default=None, description="Error object if failed")
    incomplete_details: Optional[IncompleteDetails] = Field(default=None, description="Incomplete details")
    instructions: Optional[Union[str, List[Dict[str, Any]]]] = Field(default=None, description="Instruction metadata")
    max_output_tokens: Optional[int] = Field(default=None, ge=0, description="Max output tokens")
    model: str = Field(..., description="Model identifier")
    output: List[Union[OutputItem, LegacyOutputItem]] = Field(default_factory=list, description="Output items")
    parallel_tool_calls: Optional[bool] = Field(default=None, description="Parallel tool calls enabled")
    previous_response_id: Optional[str] = Field(default=None, description="Previous response ID")
    reasoning: Optional[ReasoningConfig] = Field(default=None, description="Reasoning configuration")
    store: Optional[bool] = Field(default=None, description="Store conversation flag")
    temperature: Optional[float] = Field(default=None, ge=0.0, le=2.0, description="Sampling temperature")
    text: Optional[TextConfig] = Field(default=None, description="Text formatting options")
    tool_choice: Optional[ToolChoiceType] = Field(default=None, description="Tool choice mode or constraints")
    tools: Optional[List[Dict[str, Any]]] = Field(default=None, description="Tool definitions")
    top_p: Optional[float] = Field(default=None, description="Nucleus sampling")
    truncation: Optional[TruncationStrategy] = Field(default=None, description="Truncation strategy")
    usage: Usage = Field(..., description="Token usage metrics (supports both Responses API and legacy Chat Completions field names)")
    user: Optional[str] = Field(default=None, description="User identifier")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadata")
    conversation: Optional[Conversation] = Field(default=None, description="Conversation container (stateful)")
    background: Optional[bool] = Field(default=None, description="Background execution")
    top_logprobs: Optional[int] = Field(default=None, ge=TOP_LOGPROBS_MIN, le=TOP_LOGPROBS_MAX, description="Top logprobs count")
    max_tool_calls: Optional[int] = Field(default=None, ge=0, description="Max built-in tool calls")


    @model_validator(mode='before')
    @classmethod
    def convert_sdk_response(cls, data: Any) -> Any:
        """Convert OpenAI SDK Response object to dict.
        
        The OpenAI SDK returns its own Pydantic Response model. We convert it to
        a dict for validation. Legacy Chat Completions values are accepted via Union types
        in the schema fields (object, status), so no normalization is needed.
        
        Args:
            data: Input data (may be SDK Response object, dict, or other).
            
        Returns:
            Dict representation for validation.
        """
        # Convert SDK Response object to dict
        if not isinstance(data, dict):
            if hasattr(data, 'model_dump'):
                return data.model_dump(by_alias=True, exclude_none=False)
            elif hasattr(data, 'dict'):
                return data.dict()
        
        return data


    @property
    def output_text(self) -> Optional[str]:
        """Extract the first assistant OutputText block, if present.

        Returns:
            First OutputText.text found in assistant message content, or None.
        """
        for item in self.output:
            if isinstance(item, (OutputMessage, LegacyOutputMessage)):
                if item.role == MessageRole.ASSISTANT:
                    for block in item.content:
                        if isinstance(block, OutputText):
                            return block.text
        return None

    def tool_calls(self) -> List[FunctionToolCall]:
        """Collect all function tool calls emitted in this response.

        Returns:
            List of FunctionToolCall items discovered in the response output.
        """
        results: List[FunctionToolCall] = []
        for item in self.output:
            if isinstance(item, FunctionToolCall):
                results.append(item)
        return results

    def assistant_messages(self) -> List[Union[OutputMessage, LegacyOutputMessage]]:
        """Return all assistant OutputMessage items.

        Returns:
            List of assistant messages found in output.
        """
        messages: List[Union[OutputMessage, LegacyOutputMessage]] = []
        for item in self.output:
            if isinstance(item, (OutputMessage, LegacyOutputMessage)) and item.role == MessageRole.ASSISTANT:
                messages.append(item)
        return messages

    def usage_summary(self) -> Dict[str, int]:
        """Summarize token usage as a plain dictionary.

        Returns:
            Dictionary containing input_tokens, output_tokens, total_tokens,
            cached_tokens, reasoning_tokens, and billable_tokens.
        """
        # Prefer Responses API fields, fallback to legacy fields
        input_tok = self.usage.input_tokens or self.usage.prompt_tokens or 0
        output_tok = self.usage.output_tokens or self.usage.completion_tokens or 0
        
        cached_tokens = (
            self.usage.input_tokens_details.cached_tokens
            if self.usage.input_tokens_details
            else 0
        )
        reasoning_tokens = (
            self.usage.output_tokens_details.reasoning_tokens
            if self.usage.output_tokens_details
            else 0
        )
        
        return {
            "input_tokens": input_tok,
            "output_tokens": output_tok,
            "prompt_tokens": self.usage.prompt_tokens or input_tok,
            "completion_tokens": self.usage.completion_tokens or output_tok,
            "total_tokens": self.usage.total_tokens or 0,
            "cached_tokens": cached_tokens,
            "reasoning_tokens": reasoning_tokens,
            "billable_tokens": max(0, (self.usage.total_tokens or 0) - cached_tokens),
            "total_cost": self.usage.total_cost,
            "currency": self.usage.currency,
            "prompt_cost": self.usage.prompt_cost,
            "completion_cost": self.usage.completion_cost,
        }
