from enum import StrEnum


class MessageRole(StrEnum):
    """Role of a message in the Responses API.

    Values:
        USER: End-user authored content.
        ASSISTANT: Assistant authored content.
        TOOL: Legacy Chat Completions tool-response content used during interop.
        SYSTEM: System instructions.
        DEVELOPER: Developer instructions.
    """
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"
    SYSTEM = "system"
    DEVELOPER = "developer"


class ItemStatus(StrEnum):
    """Lifecycle status for items."""
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    INCOMPLETE = "incomplete"


class ImageDetail(StrEnum):
    """Detail level for input images."""
    HIGH = "high"
    LOW = "low"
    AUTO = "auto"


class ItemType(StrEnum):
    """Item discriminator values in Responses output and input content."""
    MESSAGE = "message"
    FUNCTION_CALL = "function_call"
    FUNCTION_TOOL_CALL = "function_tool_call"
    FUNCTION_CALL_OUTPUT = "function_call_output"
    FUNCTION_TOOL_CALL_OUTPUT = "function_tool_call_output"
    INPUT_TEXT = "input_text"
    INPUT_IMAGE = "input_image"
    INPUT_FILE = "input_file"
    OUTPUT_TEXT = "output_text"
    REFUSAL = "refusal"
    FILE_CITATION = "file_citation"
    URL_CITATION = "url_citation"
    CONTAINER_FILE_CITATION = "container_file_citation"
    FILE_PATH = "file_path"
    LOGPROBS = "logprobs"
    REASONING = "reasoning"
    REASONING_TEXT = "reasoning_text"
    SUMMARY_TEXT = "summary_text"
    ITEM_REFERENCE = "item_reference"
    UNKNOWN = "unknown"


class ResponseStatus(StrEnum):
    """Top-level response status lifecycle."""
    COMPLETED = "completed"
    FAILED = "failed"
    IN_PROGRESS = "in_progress"
    CANCELLED = "cancelled"
    QUEUED = "queued"
    INCOMPLETE = "incomplete"


class ReasoningEffort(StrEnum):
    """Reasoning effort level for reasoning-capable models.
    """
    MINIMAL = "minimal"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ReasoningSummaryLevel(StrEnum):
    """Reasoning summary verbosity for configuration."""
    AUTO = "auto"
    CONCISE = "concise"
    DETAILED = "detailed"


class Verbosity(StrEnum):
    """Response verbosity."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class TruncationStrategy(StrEnum):
    """Truncation strategy for context handling."""
    AUTO = "auto"
    DISABLED = "disabled"


class ToolChoiceMode(StrEnum):
    """Tool selection mode."""
    NONE = "none"
    AUTO = "auto"
    REQUIRED = "required"


class ObjectType(StrEnum):
    """Top-level object discriminator values."""
    RESPONSE = "response"


class LegacyObjectType(StrEnum):
    """Legacy Chat Completions object type discriminator.
    
    Used when providers return Chat Completions format through LiteLLM middleware.
    """
    CHAT_COMPLETION = "chat.completion"


class LegacyFinishReason(StrEnum):
    """Legacy Chat Completions finish_reason values.
    
    Used when providers return Chat Completions format through LiteLLM middleware.
    Maps to ItemStatus:
    - stop -> COMPLETED
    - length -> INCOMPLETE
    - tool_calls -> COMPLETED
    - content_filter -> INCOMPLETE
    """
    STOP = "stop"
    LENGTH = "length"
    TOOL_CALLS = "tool_calls"
    CONTENT_FILTER = "content_filter"


class TextFormatKind(StrEnum):
    """Supported text output format kinds."""
    TEXT = "text"
    JSON_SCHEMA = "json_schema"
    JSON_OBJECT = "json_object"


class AllowedToolsType(StrEnum):
    """Discriminator for the AllowedTools object in tool_choice unions."""
    ALLOWED_TOOLS = "allowed_tools"
