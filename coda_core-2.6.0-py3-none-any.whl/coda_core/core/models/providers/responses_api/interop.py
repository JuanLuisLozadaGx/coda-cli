import json
import time
from copy import deepcopy
from typing import Any, Dict, Iterable, List, Optional

from loguru import logger
from pydantic import BaseModel, ValidationError

from coda_core.core.models.providers.responses_api.enums import (
    ItemStatus,
    ItemType,
    LegacyFinishReason,
    LegacyObjectType,
    MessageRole,
    ReasoningEffort,
    ReasoningSummaryLevel,
    ResponseStatus,
)
from coda_core.core.models.providers.responses_api.item_schemas import (
    FunctionToolCall,
    FunctionToolCallOutput,
    InputMessage,
    InputText,
    Item,
    MessageContentItem,
    OutputMessage,
    OutputText,
    Reasoning,
)
from coda_core.core.models.providers.responses_api.response_schemas import ResponseObject, Usage


_SUPPORTED_PROVIDER_OUTPUT_ITEM_TYPES = {
    item_type.value for item_type in ItemType if item_type is not ItemType.UNKNOWN
}
_KNOWN_REASONING_EFFORTS = {effort.value for effort in ReasoningEffort}
_KNOWN_REASONING_SUMMARIES = {summary.value for summary in ReasoningSummaryLevel}


def response_to_dict(response: Any) -> Dict[str, Any]:
    """Convert an SDK/model response object to a plain dictionary.

    Raises:
        TypeError: If the response cannot be converted to a dictionary.
    """
    if isinstance(response, dict):
        return deepcopy(response)
    if hasattr(response, "model_dump"):
        return response.model_dump(by_alias=True, exclude_none=False)
    if hasattr(response, "dict"):
        return response.dict()
    raise TypeError(f"Unsupported response type: {type(response)}")


def normalize_response_payload(data: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize provider-specific response quirks into canonical schema values."""
    normalized = deepcopy(data)

    metadata = normalized.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}
        normalized["metadata"] = metadata

    reasoning = normalized.get("reasoning")
    if isinstance(reasoning, dict):
        effort = reasoning.get("effort")
        if isinstance(effort, str):
            lowered = effort.strip().lower()
            if lowered in {"", "none", "null"}:
                reasoning["effort"] = None
            elif lowered in _KNOWN_REASONING_EFFORTS:
                reasoning["effort"] = lowered
            else:
                metadata["provider_reasoning_effort"] = effort
                reasoning["effort"] = None

        summary = reasoning.get("summary")
        if isinstance(summary, str):
            lowered_summary = summary.strip().lower()
            if lowered_summary in {"", "none", "null"}:
                reasoning["summary"] = None
            elif lowered_summary in _KNOWN_REASONING_SUMMARIES:
                reasoning["summary"] = lowered_summary
            else:
                metadata["provider_reasoning_summary"] = summary
                reasoning["summary"] = None

    usage = normalized.get("usage")
    if isinstance(usage, dict):
        prompt_details = usage.get("prompt_tokens_details")
        completion_details = usage.get("completion_tokens_details")
        if usage.get("input_tokens_details") is None and isinstance(prompt_details, dict):
            usage["input_tokens_details"] = prompt_details
        if usage.get("output_tokens_details") is None and isinstance(completion_details, dict):
            usage["output_tokens_details"] = completion_details

    output = normalized.get("output")
    if isinstance(output, list):
        filtered_output: List[Any] = []
        unknown_types: List[str] = []
        for item in output:
            if isinstance(item, dict):
                item_type = item.get("type")
                if isinstance(item_type, str) and item_type not in _SUPPORTED_PROVIDER_OUTPUT_ITEM_TYPES:
                    unknown_types.append(item_type)
                    filtered_output.append({
                        "type": ItemType.UNKNOWN.value,
                        "raw": deepcopy(item),
                        "original_type": item_type,
                    })
                    continue
            filtered_output.append(item)

        if unknown_types:
            metadata["unknown_output_item_count"] = len(unknown_types)
            metadata["unknown_output_item_types"] = sorted(set(unknown_types))
        normalized["output"] = filtered_output

    return normalized


def _to_dict(item: Any) -> Dict[str, Any]:
    """Convert a Responses item into a plain dictionary.

    Raises:
        TypeError: If the item cannot be converted to a dictionary.
    """
    if isinstance(item, dict):
        return item
    if isinstance(item, BaseModel):
        return item.model_dump(by_alias=True, exclude_none=True)
    raise TypeError(f"Unsupported item type: {type(item)}")


def _flatten_message_content(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for item in content:
            if isinstance(item, dict):
                item_type = item.get("type")
                if item_type in {"input_text", "output_text"}:
                    parts.append(str(item.get("text", "")))
                elif item_type == "refusal":
                    parts.append(str(item.get("refusal", "")))
                elif "text" in item:
                    parts.append(str(item.get("text", "")))
            elif hasattr(item, "text"):
                parts.append(str(getattr(item, "text", "")))
        return " ".join([p for p in parts if p])
    return str(content)


def build_input_message(role: MessageRole, text: str) -> Dict[str, Any]:
    item = InputMessage(role=role, content=[InputText(text=text)])
    return item.model_dump(by_alias=True, exclude_none=True)


def build_function_call(call_id: str, name: str, arguments: str) -> Dict[str, Any]:
    item = FunctionToolCall(call_id=call_id, name=name, arguments=arguments)
    return item.model_dump(by_alias=True, exclude_none=True)


def build_function_call_output(call_id: str, output: Any) -> Dict[str, Any]:
    if not isinstance(output, str):
        output = json.dumps(output, ensure_ascii=False)
    item = FunctionToolCallOutput(call_id=call_id, output=output)
    return item.model_dump(by_alias=True, exclude_none=True)


def _schema_allows_additional(schema: Any) -> bool:
    if isinstance(schema, list):
        return any(_schema_allows_additional(item) for item in schema)
    if not isinstance(schema, dict):
        return False

    schema_type = schema.get("type")
    if schema_type == "object":
        if "additionalProperties" not in schema:
            return True
        if schema.get("additionalProperties") is not False:
            return True

    # Recurse into properties/items
    properties = schema.get("properties", {}) or {}
    for prop_schema in properties.values():
        if _schema_allows_additional(prop_schema):
            return True
    items = schema.get("items")
    if items and _schema_allows_additional(items):
        return True
    return False


def _schema_is_strict_compatible(schema: Any) -> bool:
    """Check if a JSON schema is compatible with strict function calling.

    Strict mode requires:
    - additionalProperties=false for every object schema
    - every key in properties must be included in required
    """
    if isinstance(schema, list):
        return all(_schema_is_strict_compatible(item) for item in schema)
    if not isinstance(schema, dict):
        return True

    schema_type = schema.get("type")
    includes_object = (
        schema_type == "object"
        or (isinstance(schema_type, list) and "object" in schema_type)
    )

    if includes_object:
        if schema.get("additionalProperties") is not False:
            return False

        properties = schema.get("properties") or {}
        if not isinstance(properties, dict):
            return False

        required = schema.get("required")
        if not isinstance(required, list):
            return False

        if set(properties.keys()) != set(required):
            return False

    properties = schema.get("properties", {}) or {}
    for prop_schema in properties.values():
        if not _schema_is_strict_compatible(prop_schema):
            return False

    items = schema.get("items")
    if items is not None and not _schema_is_strict_compatible(items):
        return False

    for union_key in ("allOf", "anyOf", "oneOf"):
        union_schema = schema.get(union_key)
        if union_schema is not None and not _schema_is_strict_compatible(union_schema):
            return False

    return True


def tool_definitions_to_responses(tools: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    responses_tools: List[Dict[str, Any]] = []
    for tool in tools or []:
        if not isinstance(tool, dict):
            continue
        if tool.get("type") == "function" and "function" in tool:
            func = tool.get("function") or {}
            parameters = func.get("parameters")
            strict_compatible = _schema_is_strict_compatible(parameters)
            strict = tool.get("strict")
            if strict is None:
                strict = strict_compatible
            elif strict is True and not strict_compatible:
                # Avoid provider-side 400s when a schema cannot satisfy strict mode.
                logger.warning(
                    "Tool '{}' is not strict-compatible; forcing strict=false for Responses API.",
                    func.get("name") or "<unnamed>",
                )
                strict = False
            responses_tools.append({
                "type": "function",
                "name": func.get("name"),
                "description": func.get("description"),
                "parameters": parameters,
                "strict": strict,
            })
        else:
            responses_tools.append(tool)
    return responses_tools


def chat_messages_to_items(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    for msg in messages:
        if not isinstance(msg, dict):
            continue
        role = msg.get("role")
        if not role:
            continue

        # Handle tool role messages (Chat API tool responses → function_call_output items)
        if role == MessageRole.TOOL.value:
            call_id = msg.get("tool_call_id") or ""
            output = msg.get("content", "")
            if not isinstance(output, str):
                output = json.dumps(output, ensure_ascii=False)
            item = build_function_call_output(call_id=call_id, output=output)
            if msg.get("name"):
                item["name"] = msg["name"]
            items.append(item)
            continue

        try:
            role_enum = MessageRole(role)
        except ValueError:
            logger.warning(f"Skipping unsupported role in chat message: {role}")
            continue

        content = msg.get("content", "")
        text = _flatten_message_content(content)

        # For assistant messages: only store text item when non-empty, then expand tool_calls
        if role_enum == MessageRole.ASSISTANT:
            if text:
                items.append(build_input_message(role_enum, text))
            tool_calls = msg.get("tool_calls") or []
            for tool_call in tool_calls:
                if not isinstance(tool_call, dict):
                    continue
                func = tool_call.get("function") or {}
                arguments = func.get("arguments") or ""
                if not isinstance(arguments, str):
                    try:
                        arguments = json.dumps(arguments, ensure_ascii=False)
                    except (TypeError, ValueError):
                        arguments = str(arguments)
                items.append(build_function_call(
                    call_id=tool_call.get("id") or "",
                    name=func.get("name") or "",
                    arguments=arguments,
                ))
            if not text and not tool_calls:
                items.append(build_input_message(role_enum, text))
        else:
            items.append(build_input_message(role_enum, text))

    return items


def contains_assistant_message_input(items: Iterable[Dict[str, Any]]) -> bool:
    """Return whether Responses input items contain assistant role messages.

    Args:
        items: Responses input item dictionaries.

    Returns:
        True when at least one item is a ``type=message`` with ``role=assistant``.
    """
    for item in items or []:
        if not isinstance(item, dict):
            continue
        if item.get("type") != ItemType.MESSAGE:
            continue
        if item.get("role") == MessageRole.ASSISTANT:
            return True
    return False


def strip_assistant_message_input(items: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Drop assistant role message items from Responses input.

    This is used as a compatibility shim for provider gateways that reject
    assistant-role input messages while still accepting other item types
    (e.g., user/system/developer messages and tool lifecycle items).

    Args:
        items: Responses input item dictionaries.

    Returns:
        A new list with assistant message items removed.
    """
    sanitized: List[Dict[str, Any]] = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        if item.get("type") == ItemType.MESSAGE and item.get("role") == MessageRole.ASSISTANT:
            continue
        sanitized.append(deepcopy(item))
    return sanitized


def items_to_responses_input(items: Iterable[Item | Dict[str, Any]]) -> List[Dict[str, Any]]:
    result: List[Dict[str, Any]] = []
    for raw in items:
        item = _to_dict(raw)
        item_type = item.get("type")
        if item_type == ItemType.MESSAGE:
            role = item.get("role")
            text_block_type = "output_text" if role == MessageRole.ASSISTANT else "input_text"
            content = item.get("content", "")
            if isinstance(content, list):
                normalized: List[Dict[str, Any]] = []
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    block_type = block.get("type")
                    if block_type in {"input_text", "output_text"}:
                        normalized.append({"type": text_block_type, "text": block.get("text", "")})
                    elif block_type == "refusal":
                        normalized.append({"type": text_block_type, "text": block.get("refusal", "")})
                if not normalized:
                    normalized = [{"type": text_block_type, "text": ""}]
                content = normalized
            elif isinstance(content, str):
                content = [{"type": text_block_type, "text": content}]
            else:
                content = [{"type": text_block_type, "text": str(content)}]
            result.append({"type": "message", "role": role, "content": content})
        elif item_type in {ItemType.FUNCTION_CALL, ItemType.FUNCTION_TOOL_CALL}:
            arguments = item.get("arguments", "")
            if not isinstance(arguments, str):
                arguments = json.dumps(arguments, ensure_ascii=False)
            result.append({
                "type": item_type,
                "call_id": item.get("call_id"),
                "name": item.get("name"),
                "arguments": arguments,
            })
        elif item_type in {ItemType.FUNCTION_CALL_OUTPUT, ItemType.FUNCTION_TOOL_CALL_OUTPUT}:
            output = item.get("output", "")
            if isinstance(output, list):
                output_parts: List[str] = []
                for block in output:
                    if not isinstance(block, dict):
                        continue
                    block_type = block.get("type")
                    if block_type in {"input_text", "output_text"}:
                        output_parts.append(str(block.get("text", "")))
                    elif block_type == "refusal":
                        output_parts.append(str(block.get("refusal", "")))
                output = "\n".join(part for part in output_parts if part).strip()
            elif not isinstance(output, str):
                output = json.dumps(output, ensure_ascii=False)
            if not isinstance(output, str):
                output = str(output)
            result.append({
                "type": item_type,
                "call_id": item.get("call_id"),
                "output": output,
            })
        elif item_type == ItemType.REASONING:
            # Replay reasoning for Responses-capable models (OpenAI path) to avoid
            # forcing the model to re-reason from scratch every turn.
            summary_blocks = item.get("summary")
            normalized_summary: List[Dict[str, Any]] = []
            if isinstance(summary_blocks, list):
                for block in summary_blocks:
                    if not isinstance(block, dict):
                        continue
                    if block.get("type") != ItemType.SUMMARY_TEXT:
                        continue
                    normalized_summary.append({
                        "type": ItemType.SUMMARY_TEXT,
                        "text": block.get("text"),
                    })

            encrypted_content = item.get("encrypted_content")
            reasoning_input: Dict[str, Any] = {"type": ItemType.REASONING}
            if isinstance(item.get("id"), str) and item.get("id"):
                reasoning_input["id"] = item.get("id")
            if normalized_summary:
                reasoning_input["summary"] = normalized_summary
            if isinstance(encrypted_content, str) and encrypted_content:
                reasoning_input["encrypted_content"] = encrypted_content

            # Skip empty shells that have neither summary nor encrypted content.
            if "summary" not in reasoning_input and "encrypted_content" not in reasoning_input:
                continue
            result.append(reasoning_input)
        elif item_type is None and "role" in item:
            # Handle legacy Chat format messages stored before the migration.
            role = item.get("role")
            if role == MessageRole.TOOL.value:
                call_id = item.get("tool_call_id") or ""
                output = item.get("content", "")
                if not isinstance(output, str):
                    output = json.dumps(output, ensure_ascii=False)
                result.append({
                    "type": ItemType.FUNCTION_CALL_OUTPUT,
                    "call_id": call_id,
                    "output": output,
                })
            elif role == MessageRole.ASSISTANT.value and item.get("tool_calls"):
                content = _flatten_message_content(item.get("content"))
                if content:
                    result.append({
                        "type": "message",
                        "role": "assistant",
                        "content": [{"type": "output_text", "text": content}],
                    })
                for tc in (item.get("tool_calls") or []):
                    if not isinstance(tc, dict):
                        continue
                    func = tc.get("function") or {}
                    args = func.get("arguments") or ""
                    if not isinstance(args, str):
                        try:
                            args = json.dumps(args, ensure_ascii=False)
                        except (TypeError, ValueError):
                            args = str(args)
                    result.append({
                        "type": ItemType.FUNCTION_CALL,
                        "call_id": tc.get("id") or "",
                        "name": func.get("name") or "",
                        "arguments": args,
                    })
            else:
                try:
                    role_enum = MessageRole(role)
                except (ValueError, TypeError):
                    logger.warning(f"Skipping legacy Chat message with unsupported role: {role}")
                    continue
                content = _flatten_message_content(item.get("content", ""))
                text_block_type = "output_text" if role_enum == MessageRole.ASSISTANT else "input_text"
                result.append({
                    "type": "message",
                    "role": role,
                    "content": [{"type": text_block_type, "text": content}],
                })
        else:
            logger.warning(f"Skipping unsupported input item type: {item_type}")
    return result


def items_to_chat_messages(items: Iterable[Item | Dict[str, Any]]) -> List[Dict[str, Any]]:
    messages: List[Dict[str, Any]] = []
    pending_tool_calls: List[Dict[str, Any]] = []

    def _flush_tool_calls() -> None:
        nonlocal pending_tool_calls
        if pending_tool_calls:
            # Merge into the preceding assistant message when it has no tool_calls yet.
            # This handles the Responses API pattern where text content and tool calls
            # are stored as separate items but Chat API expects them in a single message.
            if (
                messages
                and messages[-1].get("role") == "assistant"
                and "tool_calls" not in messages[-1]
            ):
                messages[-1]["tool_calls"] = pending_tool_calls
            else:
                messages.append({
                    "role": "assistant",
                    "content": "",
                    "tool_calls": pending_tool_calls,
                })
            pending_tool_calls = []

    for raw in items:
        item = _to_dict(raw)
        item_type = item.get("type")

        if item_type in {ItemType.FUNCTION_CALL, ItemType.FUNCTION_TOOL_CALL}:
            arguments = item.get("arguments", "")
            if not isinstance(arguments, str):
                arguments = json.dumps(arguments, ensure_ascii=False)
            pending_tool_calls.append({
                "id": item.get("call_id"),
                "type": "function",
                "function": {
                    "name": item.get("name"),
                    "arguments": arguments,
                },
            })
            continue

        if item_type == ItemType.FUNCTION_CALL_OUTPUT or item_type == ItemType.FUNCTION_TOOL_CALL_OUTPUT:
            _flush_tool_calls()
            output = item.get("output", "")
            if not isinstance(output, str):
                output = json.dumps(output, ensure_ascii=False)
            tool_message = {
                "role": "tool",
                "tool_call_id": item.get("call_id"),
                "content": output,
            }
            if item.get("name"):
                tool_message["name"] = item.get("name")
            messages.append(tool_message)
            continue

        if item_type == ItemType.MESSAGE:
            _flush_tool_calls()
            role = item.get("role")
            content = _flatten_message_content(item.get("content"))
            messages.append({"role": role, "content": content})
            continue

        if item_type == ItemType.REASONING:
            continue

        # Handle legacy Chat format messages stored in memory before the migration
        # (no "type" discriminator, identified by the presence of a "role" field).
        if item_type is None and "role" in item:
            role = item.get("role")
            if role == MessageRole.TOOL.value:
                _flush_tool_calls()
                output = item.get("content", "")
                if not isinstance(output, str):
                    output = json.dumps(output, ensure_ascii=False)
                tool_message = {
                    "role": "tool",
                    "tool_call_id": item.get("tool_call_id") or "",
                    "content": output,
                }
                if item.get("name"):
                    tool_message["name"] = item["name"]
                messages.append(tool_message)
            elif role == MessageRole.ASSISTANT.value and item.get("tool_calls"):
                _flush_tool_calls()
                content = _flatten_message_content(item.get("content"))
                legacy_tool_calls = [
                    {"id": tc.get("id"), "type": "function", "function": tc.get("function", {})}
                    for tc in (item.get("tool_calls") or [])
                    if isinstance(tc, dict)
                ]
                msg: Dict[str, Any] = {"role": "assistant", "content": content}
                if legacy_tool_calls:
                    msg["tool_calls"] = legacy_tool_calls
                messages.append(msg)
            else:
                _flush_tool_calls()
                content = _flatten_message_content(item.get("content", ""))
                messages.append({"role": role, "content": content})
            continue

        logger.warning(f"Skipping unsupported chat message item type: {item_type}")

    _flush_tool_calls()
    return messages


def response_from_chat_completion(chat_response: Any) -> ResponseObject:
    if isinstance(chat_response, dict):
        data = chat_response
    elif hasattr(chat_response, "model_dump"):
        data = chat_response.model_dump(exclude_none=False)
    elif hasattr(chat_response, "dict"):
        data = chat_response.dict()
    else:
        raise TypeError("Unsupported chat completion response type")

    created_at = data.get("created") or int(time.time())
    model = data.get("model") or "unknown"
    choices = data.get("choices") or []
    usage_raw = data.get("usage") or {}

    try:
        usage = Usage.model_validate(usage_raw)
    except ValidationError:
        usage = Usage()

    output_items: List[Dict[str, Any]] = []
    status = ResponseStatus.COMPLETED
    incomplete_reason: Optional[str] = None
    unknown_types: List[str] = []

    def _append_unknown(raw_item: Any, original_type: str) -> None:
        """Preserve malformed payloads as UnknownItem-compatible dictionaries."""
        payload: Dict[str, Any]
        if isinstance(raw_item, dict):
            payload = deepcopy(raw_item)
        else:
            payload = {"raw": raw_item}
        output_items.append({
            "type": ItemType.UNKNOWN.value,
            "raw": payload,
            "original_type": original_type,
        })
        unknown_types.append(original_type)

    if not isinstance(choices, list):
        _append_unknown({"choices": choices}, "choices")
        choices = []

    for idx, choice in enumerate(choices):
        if not isinstance(choice, dict):
            _append_unknown({"choice_index": idx, "choice": choice}, "choice")
            continue

        finish_reason = choice.get("finish_reason")
        if finish_reason in {LegacyFinishReason.LENGTH.value, LegacyFinishReason.CONTENT_FILTER.value}:
            status = ResponseStatus.INCOMPLETE
            if incomplete_reason is None and isinstance(finish_reason, str):
                incomplete_reason = finish_reason

        message = choice.get("message")
        if not isinstance(message, dict):
            _append_unknown({"choice_index": idx, "message": message}, "message")
            continue

        content_text = _flatten_message_content(message.get("content"))
        tool_calls = message.get("tool_calls") or []
        # Only emit an OutputMessage when there is actual text content.
        # When a model responds with tool_calls only, content is null/empty and
        # creating an empty OutputMessage would produce a spurious assistant text
        # item in memory that leads to duplicate adjacent assistant messages on
        # subsequent Chat API turns.
        if content_text:
            output_items.append(
                OutputMessage(
                    id=f"msg_{data.get('id', 'chat')}_{idx}",
                    role=MessageRole.ASSISTANT,
                    status=ItemStatus.COMPLETED,
                    content=[OutputText(text=content_text)],
                ).model_dump(by_alias=True, exclude_none=True)
            )
        if not isinstance(tool_calls, list):
            _append_unknown({"choice_index": idx, "tool_calls": tool_calls}, "tool_calls")
            continue

        for tool_call in tool_calls:
            if not isinstance(tool_call, dict):
                _append_unknown({"choice_index": idx, "tool_call": tool_call}, "tool_call")
                continue

            func = tool_call.get("function")
            if not isinstance(func, dict):
                _append_unknown(tool_call, "tool_call")
                continue

            arguments = func.get("arguments") or ""
            if not isinstance(arguments, str):
                try:
                    arguments = json.dumps(arguments, ensure_ascii=False)
                except (TypeError, ValueError):
                    arguments = str(arguments)

            try:
                output_items.append(
                    FunctionToolCall(
                        call_id=tool_call.get("id"),
                        name=func.get("name"),
                        arguments=arguments,
                    ).model_dump(by_alias=True, exclude_none=True)
                )
            except ValidationError:
                _append_unknown(tool_call, "tool_call")

    response_data: Dict[str, Any] = {
        "id": data.get("id") or f"resp_{int(time.time())}",
        "object": LegacyObjectType.CHAT_COMPLETION,
        "created_at": created_at,
        "status": status,
        "model": model,
        "output": output_items,
        "usage": usage.model_dump(exclude_none=True),
    }

    if incomplete_reason:
        response_data["incomplete_details"] = {"reason": incomplete_reason}
    if unknown_types:
        response_data["metadata"] = {
            "unknown_output_item_count": len(unknown_types),
            "unknown_output_item_types": sorted(set(unknown_types)),
        }

    return ResponseObject.model_validate(response_data)


def normalize_item_list(items: Iterable[Item | Dict[str, Any]]) -> List[Dict[str, Any]]:
    normalized: List[Dict[str, Any]] = []
    for raw in items:
        item = _to_dict(raw)
        try:
            # Validate item shape; ensure it's a known item
            _ = Reasoning.model_validate(item) if item.get("type") == ItemType.REASONING else None
        except ValidationError:
            pass
        normalized.append(item)
    return normalized
