"""
GEAI Client Manager Module

This module provides the GEAIClientManager class for managing and caching GEAIClient instances.
The manager ensures that only one client instance exists per unique configuration, improving
performance and resource usage.

Usage:
    Basic usage:
        >>> from coda_core.core.models.providers.geai_config import GEAIConfig
        >>> from coda_core.core.models.providers.geai_client_manager import GEAIClientManager
        >>> 
        >>> config = GEAIConfig.from_api_key(
        ...     base_url="https://geai.internal.example.com",
        ...     api_key="sk-12345"
        ... )
        >>> client = GEAIClientManager.get_client(config)  # Creates and caches
        >>> client2 = GEAIClientManager.get_client(config)  # Returns cached instance
        >>> assert client is client2  # Same instance

    Multiple configurations:
        >>> config1 = GEAIConfig.from_api_key(base_url, "key1")
        >>> config2 = GEAIConfig.from_api_key(base_url, "key2")
        >>> 
        >>> client1 = GEAIClientManager.get_client(config1)
        >>> client2 = GEAIClientManager.get_client(config2)
        >>> assert client1 is not client2  # Different instances for different configs

See Also:
    - GEAIConfig for authentication configuration
    - GEAIClient for client implementation
    - coda_core/core/models/providers/README.md for complete guide
"""

from typing import Dict, Tuple
from threading import RLock
import hashlib

from loguru import logger

from coda_core.core.models.providers.geai_client import GEAIClient
from coda_core.core.models.providers.geai_config import GEAIConfig


class GEAIClientManager:
    """
    Manager for GEAIClient instances with caching.
    
    This class manages a global cache of GEAIClient instances, ensuring that only
    one client exists per unique configuration (base_url, auth_token, project_id).
    This improves performance by avoiding redundant client creation and reduces
    resource usage.
    
    The manager is thread-safe and can be safely used in multi-threaded applications.
    
    Cache Key:
        Clients are cached by (base_url, hashed_auth_token, project_id) tuple, where the
        auth token is hashed for security. This allows multiple configurations to coexist
        while preventing credential exposure in debugging sessions.
    
    Examples:
        Get client (creates if needed):
            >>> config = GEAIConfig.from_api_key(
            ...     base_url="https://geai.example.com",
            ...     api_key="sk-12345"
            ... )
            >>> client = GEAIClientManager.get_client(config)
        
        Subsequent calls return cached instance:
            >>> client2 = GEAIClientManager.get_client(config)
            >>> assert client is client2  # Same instance
        
        Different configs get different instances:
            >>> config_alt = GEAIConfig.from_api_key(
            ...     base_url="https://geai.example.com",
            ...     api_key="sk-different"
            ... )
            >>> client_alt = GEAIClientManager.get_client(config_alt)
            >>> assert client is not client_alt  # Different instances
    
    See Also:
        - GEAIConfig for creating authentication configurations
        - GEAIClient for client implementation details
        - coda_core/core/models/providers/README.md for usage guide
    """

    _clients: Dict[Tuple[str, str, str], GEAIClient] = {}
    _lock = RLock()

    @staticmethod
    def _make_cache_key(config: GEAIConfig) -> Tuple[str, str, str]:
        """
        Generate a secure cache key with hashed auth token.
        
        The auth token is hashed to prevent credential exposure during debugging,
        while maintaining deterministic keys for proper cache lookups.
        
        Args:
            config: GEAIConfig instance
            
        Returns:
            Tuple of (base_url, hashed_auth_token, project_id)
        """
        auth_hash = hashlib.sha256(config.auth_token.encode()).hexdigest()
        return (config.base_url, auth_hash, config.project_id or "")

    @classmethod
    def get_client(cls, config: GEAIConfig) -> GEAIClient:
        """
        Get the GEAIClient for a configuration, initializing it if needed.
        
        Clients are cached by (base_url, hashed_auth_token, project_id) to allow
        different configurations to coexist while keeping credentials secure.

        Args:
            config: GEAIConfig instance with authentication details

        Returns:
            GEAIClient: The GEAIClient instance

        Raises:
            ValueError: If configuration is invalid
        """
        config.validate()
        
        key = cls._make_cache_key(config)
        
        with cls._lock:
            client = cls._clients.get(key)
            if client is None:
                logger.info(f"Creating new GEAIClient for {config.base_url}")
                client = GEAIClient(config)
                cls._clients[key] = client
            return client

    @classmethod
    def clear_cache(cls) -> None:
        """
        Clear all cached clients. Reserved for future use.
        
        This method clears the global client cache. It can be useful for:
        - Testing scenarios where cache state needs to be reset
        - Resource cleanup when credentials change frequently
        - Resetting the manager state without restarting the application
        
        Note: In typical usage, clients are already keyed by hashed credentials,
        so cache clearing is not necessary for security. This method is provided
        for resource management and testing purposes.
        """
        with cls._lock:
            cache_size = len(cls._clients)
            cls._clients.clear()
            logger.debug(f"GEAIClientManager cache cleared ({cache_size} entries removed)")
