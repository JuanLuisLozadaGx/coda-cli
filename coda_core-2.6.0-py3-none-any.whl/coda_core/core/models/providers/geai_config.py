"""
GEAI Authentication Configuration Module

This module provides flexible authentication configuration for GEAI (Globant Enterprise AI)
clients. It supports multiple authentication methods while maintaining backward compatibility
with environment variable-based configuration.

Key Features:
    - Multiple authentication methods (API Key, Access Token)
    - Type-safe configuration with validation
    - Secure credential handling (never exposed in logs or repr)
    - Backward compatible with environment variables
    - Project ID support for access token authentication

Authentication Methods:
    1. API Key Authentication - Traditional method for service accounts
    2. Access Token Authentication - For user-specific credentials and OAuth flows
    3. Environment Variables - Backward compatible fallback (API key only)

Usage Examples:
    API Key Authentication:
        >>> from coda_core.core.models.providers.geai_config import GEAIConfig
        >>> config = GEAIConfig.from_api_key(
        ...     base_url="https://geai.internal.example.com",
        ...     api_key="sk-12345abcdef"
        ... )
        >>> print(config.auth_mode)
        'api_key'

    Access Token Authentication (requires project_id):
        >>> config = GEAIConfig.from_access_token(
        ...     base_url="https://geai.internal.example.com",
        ...     access_token="at_xyz789token",
        ...     project_id="project-abc-123"
        ... )
        >>> print(config.auth_mode)
        'access_token'

    Environment Variables (backward compatible):
        >>> # Requires CODA_GEAI_BASE_URL and CODA_GEAI_API_KEY env vars
        >>> config = GEAIConfig.from_env()

    With SharedState:
        >>> from coda_core.core.session.states.shared_state import SharedState
        >>> config = GEAIConfig.from_api_key(
        ...     base_url="https://geai.internal.example.com",
        ...     api_key="sk-12345"
        ... )
        >>> shared_state = SharedState(geai_config=config)

    Session Persistence:
        >>> from coda_core.core.session.session_manager import SessionManager
        >>> session_manager = SessionManager()
        >>> session = session_manager.load_session("session-id")
        >>> # Always provide geai_config when loading (credentials not persisted)
        >>> shared_state = SharedState.from_dict(
        ...     data=session.shared_state,
        ...     geai_config=config
        ... )

Security:
    - Credentials are never exposed in repr() or str() (using field(repr=False))
    - Credentials are not persisted to database (excluded from to_dict())
    - Validation ensures only one authentication method is active

For complete documentation, see:
    coda_core/core/models/providers/README.md
"""

from dataclasses import dataclass, field
from typing import Optional
from loguru import logger

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig


@dataclass
class GEAIConfig:
    """
    Configuration for GEAI client authentication.
    
    This class encapsulates authentication credentials for the GEAI service.
    Use factory methods to create instances with specific authentication modes.
    
    Attributes:
        base_url: The base URL for the GEAI service
        project_id: Optional project ID to be sent as a header (required for access tokens)
        _api_key: Private API key for API key authentication (never exposed in repr)
        _access_token: Private access token for token-based authentication (never exposed in repr)
    
    Properties:
        auth_token: Returns the authentication token (API key or access token)
        auth_mode: Returns "api_key" or "access_token"
    
    Examples:
        API key authentication:
            >>> config = GEAIConfig.from_api_key(
            ...     base_url="https://geai.example.com",
            ...     api_key="sk-12345"
            ... )
        
        Access token authentication with project ID:
            >>> config = GEAIConfig.from_access_token(
            ...     base_url="https://geai.example.com",
            ...     access_token="at_xyz789",
            ...     project_id="project-123"
            ... )
        
        Environment variables (backward compatible):
            >>> config = GEAIConfig.from_env()
    
    See Also:
        - coda_core/core/models/providers/README.md for complete usage guide
        - GEAIClient for client usage with GEAIConfig
        - GEAIClientManager for client caching
    """
    
    base_url: str
    project_id: Optional[str] = None
    _api_key: Optional[str] = field(default=None, repr=False, init=False)
    _access_token: Optional[str] = field(default=None, repr=False, init=False)
    
    @classmethod
    def from_api_key(
        cls,
        base_url: str,
        api_key: str,
        project_id: Optional[str] = None
    ) -> 'GEAIConfig':
        """
        Create configuration using API key authentication.
        
        Args:
            base_url: The base URL for the GEAI service
            api_key: The API key for authentication
            project_id: Optional project ID
            
        Returns:
            GEAIConfig instance configured for API key authentication
        """
        config = cls(base_url=base_url, project_id=project_id)
        config._api_key = api_key
        return config
    
    @classmethod
    def from_access_token(
        cls,
        base_url: str,
        access_token: str,
        project_id: str
    ) -> 'GEAIConfig':
        """
        Create configuration using access token authentication.
        
        Args:
            base_url: The base URL for the GEAI service
            access_token: The access token for authentication
            project_id: Project ID (required for access token auth)
            
        Returns:
            GEAIConfig instance configured for access token authentication
        """
        config = cls(base_url=base_url, project_id=project_id)
        config._access_token = access_token
        return config
    
    @classmethod
    def from_env(cls) -> 'GEAIConfig':
        """
        Create configuration from environment variables (fallback/backward compatibility).

        Only API key authentication is supported from environment variables.
        For access token authentication, use from_access_token() explicitly.

        Reads from the following environment variables:
        - CODA_GEAI_BASE_URL (required)
        - CODA_GEAI_API_KEY (required)

        Returns:
            GEAIConfig instance created from environment variables

        Raises:
            ValueError: If API key is not found in environment
        """
        base_url = SETTINGS.get_env_var(EnvConfig.CODA_GEAI_BASE_URL)
        api_key = SETTINGS.get_env_var(EnvConfig.CODA_GEAI_API_KEY)

        if not base_url or not api_key:
            raise ValueError("Missing environment variables to initialize GEAIConfig.")

        logger.info("Using API key authentication from environment")
        return cls.from_api_key(base_url, api_key)
    
    @property
    def auth_token(self) -> str:
        """
        Get the authentication token (either API key or access token).
        
        Returns:
            The authentication token to use
        """
        return self._access_token or self._api_key
    
    @property
    def auth_mode(self) -> str:
        """
        Get the authentication mode being used.
        
        Returns:
            "api_key" or "access_token"
        """
        return "access_token" if self._access_token else "api_key"
    
    def validate(self) -> None:
        """
        Validate the configuration.
        
        Raises:
            ValueError: If configuration is invalid
        """
        if not self.base_url:
            raise ValueError("base_url is required")
        
        if not (self._api_key or self._access_token):
            raise ValueError("Either api_key or access_token is required")
        
        if self._api_key and self._access_token:
            raise ValueError("Cannot specify both api_key and access_token")
        
        if self._access_token and not self.project_id:
            raise ValueError(
                "Access token authentication requires project_id. "
                f"Got project_id={self.project_id!r}"
            )
