"""
GEAI Client Module

This module provides the GEAIClient class for interacting with the GEAI (Globant Enterprise AI)
service. The client handles authentication, API requests, and response processing.

The client is initialized with a GEAIConfig object that specifies authentication method and
credentials. It supports both API key and access token authentication.

Usage:
    Basic usage with API key:
        >>> from coda_core.core.models.providers.geai_config import GEAIConfig
        >>> from coda_core.core.models.providers.geai_client import GEAIClient
        >>> 
        >>> config = GEAIConfig.from_api_key(
        ...     base_url="https://geai.internal.example.com",
        ...     api_key="sk-12345"
        ... )
        >>> client = GEAIClient(config)
        >>> providers = client.get_providers()

    With GEAIClientManager (recommended):
        >>> from coda_core.core.models.providers.geai_client_manager import GEAIClientManager
        >>> 
        >>> config = GEAIConfig.from_access_token(
        ...     base_url="https://geai.internal.example.com",
        ...     access_token="at_xyz",
        ...     project_id="proj-123"
        ... )
        >>> client = GEAIClientManager.get_client(config)  # Cached

See Also:
    - GEAIConfig: Configuration class for authentication
    - GEAIClientManager: Client factory with caching
    - coda_core/core/models/providers/README.md: Complete authentication guide
"""

from typing import Any, Dict, List, Optional, TYPE_CHECKING
import time
from copy import deepcopy

from requests import Session
from pydantic import ValidationError
from loguru import logger

from coda_core.core.models import schemas, utils
from coda_core.core.models.providers.oai.utils import create_oai_client
from coda_core.core.models.providers.responses_api.response_schemas import ResponseObject
from coda_core.core.models.providers.responses_api.interop import (
    items_to_chat_messages,
    items_to_responses_input,
    normalize_response_payload,
    response_to_dict,
    response_from_chat_completion,
    tool_definitions_to_responses,
)
from coda_core.core.models.providers.geai_config import GEAIConfig

if TYPE_CHECKING:
    from openai import OpenAI


SAIA_ROUTED_PROVIDER_NAME = "saia"
SAIA_ROUTED_TARGET_MODELS = {"agent", "assistant", "flow", "search"}
SAIA_ROUTED_CONTEXT_WINDOW = 128_000
SAIA_ROUTED_MAX_OUTPUT_TOKENS = 4_096
SAIA_ROUTED_PROPERTIES = [
    {"id": "SupportsToolCalling", "name": "SupportsToolCalling", "type": "boolean", "value": "true"},
    {"id": "SupportsFunctionCalling", "name": "SupportsFunctionCalling", "type": "boolean", "value": "true"},
]


class GEAIClient:
    """
    Client for interacting with the GEAI service.
    
    This client handles all communication with the GEAI API, including authentication,
    provider/model discovery, chat completions, and health checks. It is initialized
    with a GEAIConfig object that specifies the authentication method.
    
    Attributes:
        base_url: The base URL for the GEAI service
        chat_url: The chat endpoint URL
        oai_client: OpenAI-compatible client for chat completions
        
    Examples:
        Create client with API key:
            >>> config = GEAIConfig.from_api_key(
            ...     base_url="https://geai.example.com",
            ...     api_key="sk-12345"
            ... )
            >>> client = GEAIClient(config)
        
        Create client with access token:
            >>> config = GEAIConfig.from_access_token(
            ...     base_url="https://geai.example.com",
            ...     access_token="at_xyz",
            ...     project_id="proj-123"
            ... )
            >>> client = GEAIClient(config)
        
        Use with GEAIClientManager (recommended):
            >>> from coda_core.core.models.providers.geai_client_manager import GEAIClientManager
            >>> client = GEAIClientManager.get_client(config)
    
    See Also:
        - GEAIConfig for authentication configuration
        - GEAIClientManager for client caching
        - coda_core/core/models/providers/README.md for usage guide
    """

    def __init__(self, config: GEAIConfig) -> None:
        """
        Initializes the GEAIClient with a configuration object.

        Args:
            config: GEAIConfig instance with authentication details
            
        Raises:
            ValueError: If configuration is invalid
            
        Examples:
            >>> config = GEAIConfig.from_api_key(
            ...     base_url="https://geai.example.com",
            ...     api_key="sk-12345"
            ... )
            >>> client = GEAIClient(config)
        """
        config.validate()
        
        # Defensive validation: Verify credentials exist after config validation
        if not config.auth_token:
            raise ValueError(
                "GEAIConfig must have either api_key or access_token. "
                "Both are None after validation."
            )

        self.base_url = config.base_url
        self.chat_url = f"{config.base_url}/chat"
        self.responses_url = config.base_url
        self._auth_token = config.auth_token
        self._project_id = config.project_id

        # Lazy initialize OpenAI client
        self._oai_client: Optional['OpenAI'] = None

        self._responses_client: Optional['OpenAI'] = None
        self._session = Session()

        # Add health check cache attributes
        self._health_status_cache = None
        self._health_check_timestamp = 0
        self._health_cache_ttl = 300  # 5 minutes

        # Log the initialization details
        logger.info(f"Initialized GEAIClient with base URL: {self.base_url}")
        if self._project_id:
            logger.info(f"Using project ID: {self._project_id}")

    @property
    def oai_client(self) -> 'OpenAI':
        """
        Lazily initialize an OpenAI client for chat completions.

        Returns:
            OpenAI: An instance of the OpenAI client.
        """
        if self._oai_client is None:
            # Build custom headers for OpenAI client
            default_headers = {}
            if self._project_id:
                default_headers["project-id"] = self._project_id
            
            # Create OpenAI client with custom headers
            self._oai_client = create_oai_client(
                api_key=self._auth_token,
                base_url=self.chat_url,
                default_headers=default_headers
            )
        return self._oai_client

    @property
    def responses_client(self) -> 'OpenAI':
        """
        Lazily initialize an OpenAI client for Responses API calls.

        Returns:
            OpenAI: An instance of the OpenAI client.
        """
        if self._responses_client is None:
            # Build custom headers for OpenAI client
            default_headers = {}
            if self._project_id:
                default_headers["project-id"] = self._project_id

            # Create OpenAI client with custom headers
            self._responses_client = create_oai_client(
                api_key=self._auth_token,
                base_url=self.responses_url,
                default_headers=default_headers
            )

        return self._responses_client

    def _build_request_headers(self) -> Dict[str, str]:
        """
        Build headers for direct HTTP requests (non-OpenAI).
        
        Returns:
            Dictionary of headers including authorization and project ID if set
        """
        headers = {
            "Authorization": f"Bearer {self._auth_token}",
            "Accept": "application/json"
        }
        if self._project_id:
            headers["project-id"] = self._project_id
        return headers

    def chat_completion(self, model_provider: str, model_name: str, max_tokens: int, messages: List[dict], **kwargs) -> Dict:
        """
        Generates a chat completion request using the specified model provider, model name, and messages.

            model_provider (str): The name of the provider for the model (e.g., "openai").
            model_name (str): The name of the model to use (e.g., "gpt-3.5-turbo").
            max_tokens (int): The maximum number of tokens to generate in the response.
            messages (List[dict]): A list of message dictionaries, where each dictionary contains
                a "role" (e.g., "user", "assistant") and "content" (the message text).
            **kwargs: Additional keyword arguments to customize the request.

            Dict: The response from the chat completion request, including generated messages and metadata.

        Raises:
            Exception: If an error occurs during the request, such as an out-of-context error.

        Notes:
            - Messages are preprocessed to escape harmful sequences before sending the request.
            - The roles in the messages are adjusted to match the requirements of the specified provider.
            - Retry logic is implemented to handle specific errors by truncating the message history.
            - Harmful sequences in the response are unescaped before returning the result.
        """
        # Prepare request arguments
        request_args = deepcopy(kwargs)
        request_args.setdefault("model", f'{model_provider}/{model_name}')
        request_args.setdefault("max_tokens", max_tokens)
        request_args["messages"] = messages

        # Create client and prepare sanitized arguments
        sanitized_kwargs = utils.sanitize_call_arguments(self.oai_client.chat.completions.create, **request_args)

        # Attempt request with retry logic
        try:
            response = self.oai_client.chat.completions.create(**sanitized_kwargs)
        except Exception as e:
            logger.error(f"Error during chat completion: {e}")

            # Check if this is a connection error and invalidate the health cache if so
            if self._is_connection_error(e):
                logger.warning(f"Connection error detected: {e}. Invalidating health cache.")
                self.invalidate_health_cache()

            # Repackage the error into a normalized format the CLI can display
            try:
                status_code = (
                    getattr(e, "status_code", None)
                    or getattr(e, "status", None)
                    or 500
                )

                request_id = (
                    getattr(e, "request_id", None)
                    or (
                        getattr(e, "response", None).headers.get("x-request-id")
                        if getattr(e, "response", None) is not None and hasattr(getattr(e, "response", None), "headers")
                        else None
                    )
                    or "N/A"
                )

                # Preserve original error message for downstream classification
                error_details = {
                    "error": {"message": str(e)},
                    "requestId": request_id,
                    "context": {
                        "provider": model_provider,
                        "model": model_name,
                    },
                }

                # Raise a normalized exception string that UI parser understands
                raise Exception(f"Error code: {int(status_code)} - {error_details}")
            except Exception as wrap_exc:
                # If normalization fails for any reason, re-raise original
                logger.debug(f"Failed to normalize GEAI error: {wrap_exc}")
                raise

        return response

    def create_response(
        self,
        model_provider: str,
        model_name: str,
        input_items: List[Dict[str, Any]],
        max_output_tokens: int,
        force_chat_completion: bool = False,
        **kwargs: Any,
    ) -> ResponseObject:
        """
        Create a non-streaming response and normalize into a Responses API envelope.

        For OpenAI models, this calls the Responses API.
        For non-OpenAI providers (via GEAI), this bridges through Chat Completions
        and normalizes the response into a Responses-style object.
        """
        provider = model_provider.lower()
        is_openai = provider == "openai" and not force_chat_completion

        if is_openai:
            request_args = deepcopy(kwargs)
            request_args["model"] = f"{model_provider}/{model_name}"
            request_args["input"] = items_to_responses_input(input_items)
            request_args["max_output_tokens"] = max_output_tokens
            request_args = self._normalize_openai_responses_args(model_name, request_args)

            if "tools" in request_args and request_args["tools"]:
                request_args["tools"] = tool_definitions_to_responses(request_args["tools"])

            sanitized_kwargs = utils.sanitize_call_arguments(
                self.responses_client.responses.create,
                **request_args,
            )

            try:
                response = self.responses_client.responses.create(**sanitized_kwargs)
            except Exception as e:
                logger.error(f"Error during responses.create: {e}")
                if self._is_connection_error(e):
                    logger.warning(f"Connection error detected: {e}. Invalidating health cache.")
                    self.invalidate_health_cache()
                self._raise_normalized_error(e, model_provider, model_name)

            response_payload = normalize_response_payload(response_to_dict(response))
            return ResponseObject.model_validate(response_payload)

        # Non-OpenAI or forced legacy path: use chat completions and normalize.
        response = self.chat_completion(
            model_provider=model_provider,
            model_name=model_name,
            max_tokens=max_output_tokens,
            messages=items_to_chat_messages(input_items),
            **kwargs,
        )
        return response_from_chat_completion(response)

    def _normalize_openai_responses_args(
        self,
        model_name: str,
        request_args: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Apply model-specific request compatibility rules for OpenAI Responses."""
        normalized = deepcopy(request_args)
        model = (model_name or "").lower()

        if not model.startswith("gpt-5"):
            return normalized

        reasoning = normalized.get("reasoning")
        effort = reasoning.get("effort") if isinstance(reasoning, dict) else None
        effort_norm = effort.strip().lower() if isinstance(effort, str) else effort
        reasoning_enabled = effort_norm not in {None, "", "none"}

        if isinstance(reasoning, dict) and effort_norm in {"", "none"}:
            reasoning["effort"] = None

        if reasoning_enabled:
            removed: List[str] = []
            for key in ("temperature", "top_p"):
                if key in normalized:
                    normalized.pop(key, None)
                    removed.append(key)
            if removed:
                logger.warning(
                    "Removed {} for model '{}' because GPT-5 reasoning mode rejects sampling params.",
                    ", ".join(removed),
                    model_name,
                )

        return normalized

    def _raise_normalized_error(self, exc: Exception, model_provider: str, model_name: str) -> None:
        status_code = (
            getattr(exc, "status_code", None)
            or getattr(exc, "status", None)
            or 500
        )
        request_id = (
            getattr(exc, "request_id", None)
            or (
                getattr(exc, "response", None).headers.get("x-request-id")
                if getattr(exc, "response", None) is not None and hasattr(getattr(exc, "response", None), "headers")
                else None
            )
            or "N/A"
        )
        error_details = {
            "error": {"message": str(exc)},
            "requestId": request_id,
            "context": {
                "provider": model_provider,
                "model": model_name,
            },
        }
        raise Exception(f"Error code: {int(status_code)} - {error_details}")

    def get_providers(self) -> List[schemas.Provider]:
        """
        Fetches a list of available LLM providers.

        Returns:
            List[schemas.Provider]: A list of Provider objects containing provider information.

        Raises:
            HTTPError: If an HTTP error occurs during the request.
            ValidationError: If the response data fails to validate against the schema.
            Exception: For any other exceptions that occur.
        """
        # Set URL
        url = f"{self.base_url}/v2/llm/providers"

        logger.debug(f"Fetching providers from URL: {url}")

        try:
            # Send request and handle response
            headers = self._build_request_headers()
            data = utils.send_request(url=url, headers=headers, session=self._session)
            if data:
                try:
                    return [schemas.Provider.model_validate(provider) for provider in data.get("providers", [])]
                except ValidationError as val_err:
                    logger.error(f"Validation error occurred: {val_err}")
            return []
        except Exception as e:
            # Only invalidate health cache for connection errors
            if self._is_connection_error(e):
                logger.warning(f"Connection error detected: {e}. Invalidating health cache.")
                self.invalidate_health_cache()
            logger.error(f"Error fetching providers: {e}")
            return []

    def get_models_for_provider(self, provider_name: str, model_type: str = None) -> List[schemas.Model]:
        """
        Fetches a list of models for a specific provider.

        Args:
            provider_name (str): The name of the provider.
            model_type (str): The type of model to filter by. Must be one of "Chat", "Embedding", "Image", or "Rerank".
                            If not one of these values, the type parameter is omitted from the request.

        Returns:
            List[schemas.Model]: A list of Model objects associated with the provider.

        Raises:
            HTTPError: If an HTTP error occurs during the request.
            ValidationError: If the response data fails to validate against the schema.
            Exception: For any other exceptions that occur.
        """
        # Set URL
        model_type_param = f"?type={model_type}" if model_type in {"Chat", "Embedding", "Image", "Rerank"} else ""
        url = f"{self.base_url}/v2/llm/providers/{provider_name}/models{model_type_param}"

        logger.debug(f"Fetching models for provider '{provider_name}' from URL: {url}")

        try:
            # Send request and handle response
            headers = self._build_request_headers()
            data = utils.send_request(url=url, headers=headers, session=self._session)
            if data:
                try:
                    return [schemas.Model.model_validate(model) for model in data.get("models", [])]
                except ValidationError as val_err:
                    logger.error(f"Validation error occurred: {val_err}")
            return []
        except Exception as e:
            # Only invalidate health cache for connection errors
            if self._is_connection_error(e):
                logger.warning(f"Connection error detected: {e}. Invalidating health cache.")
                self.invalidate_health_cache()
            logger.error(f"Error fetching models for provider '{provider_name}': {e}")
            return []

    def get_full_info(self, export_to_json: bool = False, file_name: str = "geai_instance_info.json") -> schemas.GEAIInstanceInfo:
        """
        Merges all providers and their models into a single object.

        Args:
            export_to_json (bool): Whether to export the result to a JSON file. Default is False.
            file_name (str): The name of the file to export to, if applicable. Default is "geai_instance_info.json".

        Returns:
            schemas.GEAIInstanceInfo: An object containing a list of providers and their associated models.

        Raises:
            Exception: For any exceptions that occur during the merging process.
        """
        try:
            providers = self.get_providers()
            providers_with_models = [
                schemas.ProviderWithModels(provider=provider, models=self.get_models_for_provider(provider.name))
                for provider in providers
            ]

            full_info = schemas.GEAIInstanceInfo(providers_with_models=providers_with_models)

            if export_to_json:
                with open(file_name, 'w', encoding='utf-8') as f:
                    f.write(full_info.model_dump_json(indent=4))

            return full_info

        except Exception as err:
            logger.error(f"An error occurred while merging data: {err}")
            return schemas.GEAIInstanceInfo(providers_with_models=[])

    def check_model_availability(self, provider_name: str, model_name: str, model_type: Optional[str] = None) -> Optional[schemas.Model]:
        """
        Checks if a specific model is available under a given provider and returns the Model object if available.

        Args:
            provider_name (str): The name of the provider to check.
            model_name (str): The name of the model to check.
            model_type (Optional[str]): The type of model to filter by (e.g., "Chat", "Embedding").

        Returns:
            Optional[Model]: The Model object if found, or None if the model is not available.
        """
        try:
            # Synthetic support for routed SAIA targets (agents/assistants/flows/search).
            # These are invoked via chat completions and are not part of the provider catalog, so we
            # materialize a compatible schema to keep the downstream pipeline working.
            if provider_name == SAIA_ROUTED_PROVIDER_NAME and model_name in SAIA_ROUTED_TARGET_MODELS:
                logger.debug(
                    f"Creating synthetic SAIA model for remote agent: {provider_name}/{model_name}"
                )
                return schemas.Model.model_validate({
                    "contextWindow": SAIA_ROUTED_CONTEXT_WINDOW,
                    "description": "Synthetic SAIA routed target",
                    "fullName": f"{provider_name}/{model_name}",
                    "id": f"{provider_name}-{model_name}",
                    "isCustom": False,
                    "maxOutputTokens": SAIA_ROUTED_MAX_OUTPUT_TOKENS,
                    "name": model_name,
                    "priority": 0,
                    "properties": SAIA_ROUTED_PROPERTIES,
                    "type": "Chat",
                })

            # Fetch the list of models for the specified provider
            models = self.get_models_for_provider(provider_name, model_type)

            if (model := next(filter(lambda m: m.name == model_name, models), None)):
                logger.debug(f"Model '{model_name}' is available under provider '{provider_name}'.")
                return model

            logger.debug(f"Model '{model_name}' is not available under provider '{provider_name}'.")
            return None

        except Exception as e:
            logger.error(f"An error occurred while checking model availability: {e}")
            return None

    def check_health(self, force_refresh: bool = False) -> Dict[str, Any]:
        """
        Checks the health of the GEAI service.

        Args:
            force_refresh (bool): If True, ignores cached status and performs a new check

        Returns:
            dict: A dictionary containing health status information with the following keys:
                - is_healthy (bool): Indicates if the service is healthy and running
                - timestamp (str): The timestamp from the service response
                - error (str, optional): Error message if the health check failed
        """
        current_time = time.time()

        # Return cached status if it's still valid and force_refresh is False
        if (not force_refresh and
            self._health_status_cache is not None and
            current_time - self._health_check_timestamp < self._health_cache_ttl):
            return self._health_status_cache

        # Perform actual health check
        try:
            url = f"{self.base_url}/v1/system/status"
            logger.debug(f"Checking health status from URL: {url}")

            headers = self._build_request_headers()
            data = utils.send_request(url=url, headers=headers, session=self._session)

            if data and data.get("running", False):
                status = {
                    "is_healthy": True,
                    "timestamp": data.get("timestamp", ""),
                    "error": None
                }
            else:
                # Handle the case when data is None (service is down)
                if data is None:
                    status = {
                        "is_healthy": False,
                        "timestamp": "",
                        "error": "GEAI service is not accessible"
                    }
                else:
                    status = {
                        "is_healthy": False,
                        "timestamp": data.get("timestamp", ""),
                        "error": "System reported as not running"
                    }

            # Update cache
            self._health_status_cache = status
            self._health_check_timestamp = current_time

            return status

        except Exception as e:
            logger.error(f"Health check failed: {e}")
            status = {
                "is_healthy": False,
                "timestamp": "",
                "error": f"GEAI service health check failed: {str(e)}"
            }

            # Update cache
            self._health_status_cache = status
            self._health_check_timestamp = current_time

            return status

    def _is_connection_error(self, e: Exception) -> bool:
        """
        Checks if an exception is related to connection issues.

        Args:
            e (Exception): The exception to check

        Returns:
            bool: True if it's a connection-related error, False otherwise
        """
        error_str = str(e).lower()
        return any(keyword in error_str for keyword in ["connection", "timeout", "network"])

    def invalidate_health_cache(self) -> None:
        """
        Invalidates the health status cache, forcing the next check_health call
        to perform a fresh check.
        """
        self._health_status_cache = None
        self._health_check_timestamp = 0

    def list_agents(
        self,
        status: Optional[str] = None,
        start: int = 0,
        count: int = 20,
        access_scope: Optional[str] = None,
        allow_drafts: bool = False,
        include_external: bool = False,
    ) -> List[schemas.AgentSummary]:
        """
        Return a list of GEAI agents accessible to the current user.

        Args:
            status: Optional status filter (e.g., "active"). If provided, only agents in this status are returned.
            start: Optional pagination start offset. Defaults to 0.
            count: Page size for results. Defaults to 20. Always sent to the server to reflect caller intent.
            access_scope: Optional scope filter as supported by the GEAI API (e.g., tenant/account scoping).
            allow_drafts: Include draft agents when True. Defaults to False.
            include_external: Include externally sourced agents when True. Defaults to False.

        Returns:
            List[schemas.AgentSummary]: Parsed list of agent summaries. Returns an empty list on errors or no data.
        """

        # Always include the requested count to avoid relying on server defaults
        params = [f"count={count}"]
        if status:
            params.append(f"status={status}")
        if start > 0:
            params.append(f"start={start}")
        if access_scope:
            params.append(f"accessScope={access_scope}")
        if allow_drafts:
            params.append("allowDrafts=true")
        if include_external:
            params.append("includeExternal=true")

        query = f"?{'&'.join(params)}"
        url = f"{self.base_url}/v2/agents{query}"
        logger.debug(f"Fetching GEAI agents from URL: {url}")

        try:
            headers = self._build_request_headers()
            data = utils.send_request(url=url, headers=headers)
        except Exception as exc:
            if self._is_connection_error(exc):
                logger.warning(f"Connection issue while listing agents: {exc}. Invalidating cached health status.")
                self.invalidate_health_cache()
            logger.error(f"Error fetching GEAI agents: {exc}")
            return []

        if data and "agents" in data:
            try:
                return [schemas.AgentSummary.model_validate(item) for item in data["agents"]]
            except ValidationError as err:
                logger.error(f"Failed to validate agent list payload: {err}")
        return []

    def get_agent(
        self,
        id_or_name: str,
        revision: Optional[str] = None,
        version: Optional[str] = None,
        allow_drafts: bool = False,
    ) -> Optional[schemas.AgentDetail]:
        """
        Fetch details for a specific GEAI agent by id or name.

        Args:
            id_or_name: Agent identifier or unique name.
            revision: Optional revision identifier. When provided, fetches that specific revision.
            version: Optional version identifier. When provided, fetches that specific version.
            allow_drafts: Include draft agent content when True. Defaults to False.

        Returns:
            schemas.AgentDetail or None: Parsed agent detail on success, otherwise None.
        """

        params = []
        if revision:
            params.append(f"revision={revision}")
        if version:
            params.append(f"version={version}")
        if allow_drafts:
            params.append("allowDrafts=true")

        query = f"?{'&'.join(params)}" if params else ""
        url = f"{self.base_url}/v2/agents/{id_or_name}{query}"
        logger.debug(f"Fetching GEAI agent '{id_or_name}' from URL: {url}")

        try:
            headers = self._build_request_headers()
            data = utils.send_request(url=url, headers=headers)
            if data:
                try:
                    return schemas.AgentDetail.model_validate(data)
                except ValidationError as err:
                    logger.error(f"Failed to validate GEAI agent payload for '{id_or_name}': {err}")
            return None
        except Exception as exc:
            if self._is_connection_error(exc):
                logger.warning(f"Connection issue while fetching agent '{id_or_name}': {exc}. Invalidating cached health status.")
                self.invalidate_health_cache()
            logger.error(f"Error fetching GEAI agent '{id_or_name}': {exc}")
            return None

    @staticmethod
    def validate_credentials(base_url: str, api_key: str) -> None:
        """
        Validates the provided GEAI credentials.

        Args:
            base_url (str): The base URL of the GEAI service.
            api_key (str): The API key for authentication.

        Returns:
            None: If the credentials are valid and the service is reachable.

        Raises:
            ValueError: If the credentials are invalid or the service is unreachable.
        """
        url = f"{base_url}/v1/accessControl/apitoken/validate"
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Accept": "application/json"
        }
        data = utils.send_request(url=url, headers=headers)

        if not data:
            raise ValueError("Cannot reach the GEAI Service. Please verify your URL and API Key and try again.")
