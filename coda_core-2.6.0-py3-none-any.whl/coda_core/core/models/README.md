# Models Module

## Overview

The Models Module provides a flexible framework for interacting with Large Language Models (LLMs) in the CODA Core application. This module abstracts the complexities of working with different model providers and offers a unified interface for:

- Discovering available providers and models
- Creating and configuring language model instances
- Sending chat completion requests
- Managing model parameters and system prompts
- Handling provider-specific message formats
- Monitoring service health and handling errors
- Tracking LLM usage for cost monitoring and optimization

The module is designed with extensibility in mind, allowing for easy integration of new model providers while providing a consistent interface for all language model interactions.

## Architecture

The Models Module is built around a hierarchical class structure that enables consistent model definition and interaction:

```mermaid
classDiagram
    class LLM {
        <<abstract>>
        +client: GEAIClient
        +model: Model
        +system_prompt: str
        +params: Dict
        +generate_response()**
        +get_model_info()
        #_create_model()
    }
    
    class ChatLLM {
        +generate_response()
    }

    class GEAIClientManager {
        -_clients: Dict[Tuple[url, api_key], GEAIClient]
        +get_client()
    }
    
    class GEAIClient {
        +base_url: str
        +api_key: str
        +chat_completion()
        +get_providers()
        +get_models_for_provider()
        +get_full_info()
        +check_model_availability()
        +check_health()
    }
    
    class Model {
        +context_window: int
        +description: str
        +full_name: str
        +id: str
        +is_custom: bool
        +max_output_tokens: int
        +name: str
        +priority: int
        +properties: List[Property]
        +type: str
    }
    
    class Provider {
        +description: str
        +interface_type: str
        +name: str
    }
    
    LLM <|-- ChatLLM
    LLM o-- GEAIClient
    LLM o-- Model
    Model o-- Property
    GEAIClient ..> Provider
    GEAIClient ..> Model
    GEAIClientManager o-- GEAIClient
```

The model interaction flow follows a standard pattern:

```mermaid
sequenceDiagram
    participant Application
    participant ChatLLM
    participant GEAIClient
    participant API
    
    Application->>ChatLLM: Create with provider/model
    ChatLLM->>GEAIClient: Check model availability
    GEAIClient-->>ChatLLM: Return model info
    
    Application->>ChatLLM: generate_response(messages)
    ChatLLM->>ChatLLM: Add system prompt if needed
    ChatLLM->>GEAIClient: chat_completion(messages)
    GEAIClient->>GEAIClient: Prepare request
    GEAIClient->>API: Send request
    API-->>GEAIClient: Return response
    GEAIClient-->>ChatLLM: Return formatted response
    ChatLLM-->>Application: Return result
```

## Core Components

### LLM Base Class

The `LLM` abstract base class defines the interface that all language model implementations must follow:

- `client`: The GEAIClient instance for API interaction
- `model`: The Model instance with metadata
- `system_prompt`: Optional system prompt for guiding model behavior
- `params`: Optional parameters for customizing model behavior
- `generate_response()`: Abstract method that generates responses from messages
- `get_model_info()`: Returns information about the model
- `_create_model()`: Creates a Model instance from provider and model names

### ChatLLM Class

The `ChatLLM` class extends `LLM` to provide chat-based interaction with language models:

- Implements the `generate_response()` method for chat completions
- Adds system prompts when needed
- Handles message formatting
- Passes parameters to the underlying client

### GEAIClientManager Class
The `GEAIClientManager` class serves as an entry point to initialize only the needed `GEAIClient` instances. For now, the manager initializes only one client per `URL/API_KEY` combination, avoiding unnecessary re-instantiation and re-usage of a stateless component.

### GEAIClient Class

The `GEAIClient` class handles all interactions with the GEAI API:

- Manages API connections
- Discovers available providers and models
- Sends chat completion requests
- Handles provider-specific message formats
- Monitors service health
- Implements error handling and retry logic

### Data Schemas

The module uses Pydantic models for data validation and serialization:

| Schema | Purpose | Key Fields |
|--------|---------|------------|
| **Provider** | Represents a model provider | • name<br>• description<br>• interface_type |
| **Model** | Represents a language model | • name<br>• full_name<br>• context_window<br>• max_output_tokens<br>• type |
| **Property** | Represents a model property | • id<br>• name<br>• type<br>• value |
| **ProviderWithModels** | Links providers and models | • provider<br>• models |
| **GEAIInstanceInfo** | Contains all provider/model info | • providers_with_models |

## Error Submodule

The Models Module includes a sophisticated error handling submodule (`coda_core.core.models.errors`) designed to provide intelligent error recovery for LLM interactions. This submodule focuses on actionable error classification and automatic recovery strategies.

### Architecture

The error submodule consists of three main components:

```mermaid
classDiagram
    class ErrorCategory {
        <<enumeration>>
        CONTEXT_LIMIT
        RATE_LIMIT
        AUTHENTICATION
        CONTENT_POLICY
        SERVICE_ERROR
        UNKNOWN
    }
    
    class ErrorAction {
        <<enumeration>>
        RECOVER_WITH_MEMORY_REDUCTION
        RECOVER_WITH_BACKOFF
        RECOVER_WITH_FALLBACK
        INFORM_USER
        FAIL_IMMEDIATELY
    }
    
    class ErrorSeverity {
        <<enumeration>>
        RECOVERABLE
        USER_ACTION_REQUIRED
        FATAL
    }
    
    class LLMPlatformError {
        +original_error: Exception
        +error_category: ErrorCategory
        +error_action: ErrorAction
        +error_severity: ErrorSeverity
        +metadata: Dict
        +is_recoverable(): bool
        +requires_memory_reduction(): bool
        +requires_backoff(): bool
        +to_dict(): Dict
    }
    
    class ErrorDetection {
        +classify_llm_error(): Tuple
        +is_recoverable_error(): bool
        +get_error_action(): ErrorAction
        +is_context_limit_error(): bool
    }
    
    LLMPlatformError --> ErrorCategory
    LLMPlatformError --> ErrorAction
    LLMPlatformError --> ErrorSeverity
    ErrorDetection ..> ErrorCategory
    ErrorDetection ..> ErrorAction
    ErrorDetection ..> ErrorSeverity
```

### Error Classification

The error detection system uses keyword-based classification to identify actionable error types:

| Error Category | Keywords | Recovery Action | Severity |
|----------------|----------|-----------------|----------|
| **CONTEXT_LIMIT** | "context limit", "token limit", "input length", "max_tokens" | Memory Reduction | Recoverable |
| **RATE_LIMIT** | "rate limit", "quota", "too many requests", "throttl" | Exponential Backoff | Recoverable |
| **SERVICE_ERROR** | "server error", "timeout", "unavailable", "maintenance" | Exponential Backoff | Recoverable |
| **AUTHENTICATION** | "unauthorized", "api key", "invalid key", "forbidden" | Inform User | User Action Required |
| **CONTENT_POLICY** | "content policy", "inappropriate", "filtered", "safety" | Inform User | Fatal |
| **UNKNOWN** | No keyword matches | Inform User | User Action Required |

### Recovery Strategies

#### Memory Reduction Recovery
For context limit errors, the system automatically reduces memory usage:

```python
# Triggered by context limit errors like:
# "input length and max_tokens exceed context limit: 165127 + 40000 > 200000"

# Configuration
ERROR_RECOVERY_MEMORY_REDUCTION_PERCENTAGE = 0.20  # 20% reduction

# Process
1. Calculate target tokens to remove (current_tokens × 0.20)
2. Use memory.force_memory_reduction() to safely remove older messages
3. Preserve tool call coherence and system messages
4. Update token counts and retry LLM call
```

#### Exponential Backoff Recovery
For rate limits and service errors, the system implements intelligent backoff with **equal jitter strategy**:

```python
# Configuration
ERROR_RECOVERY_BACKOFF_BASE_DELAY = 1.0      # 1 second base
ERROR_RECOVERY_BACKOFF_MAX_DELAY = 30.0      # Maximum 30 seconds
ERROR_RECOVERY_BACKOFF_MAX_MULTIPLIER = 5    # Cap at 2^5 = 32
ERROR_RECOVERY_BACKOFF_JITTER_FACTOR = 2.0   # Equal jitter factor

# Enhanced Equal Jitter Calculation
base_delay = base × 2^min(iteration, max_multiplier)
jittered_delay = base_delay/2 + random(0, base_delay/2)
final_delay = min(jittered_delay, max_delay)
```

**Equal Jitter Benefits:**
- **Guaranteed minimum delay**: Never goes below 50% of base delay
- **Bounded randomness**: Never exceeds 100% of base delay
- **Better load distribution**: More effective than simple percentage jitter
- **Thundering herd prevention**: Spreads retry attempts more evenly
- **Industry standard**: Based on AWS backoff best practices

**Delay Progression Examples:**
```
Iteration 0: 0.5-1.0s   (vs old: 1.1-1.3s)
Iteration 1: 1.0-2.0s   (vs old: 2.2-2.6s)
Iteration 2: 2.0-4.0s   (vs old: 4.4-5.2s)
Iteration 3: 4.0-8.0s   (vs old: 8.8-10.4s)
Iteration 4: 8.0-16.0s  (vs old: 17.6-20.8s)
Iteration 5+: 15.0-30.0s (capped at max_delay)
```
#### How Exponential Backoff Works

**Basic Concept**: Exponential backoff increases retry delays exponentially (1s, 2s, 4s, 8s...) to prevent overwhelming failing services while allowing quick recovery when possible.

**What is Jitter?**: Jitter adds randomness to retry delays to prevent the "thundering herd" problem - when many clients retry at exactly the same time, overwhelming the recovering service.

**Without Jitter** (bad):
```
Client A retries at: 1s, 2s, 4s, 8s...
Client B retries at: 1s, 2s, 4s, 8s...  ← All clients hit at same time!
Client C retries at: 1s, 2s, 4s, 8s...
```

**With Equal Jitter** (good):
```
Client A retries at: 0.7s, 1.3s, 3.2s, 6.8s...
Client B retries at: 0.9s, 1.8s, 2.1s, 7.4s...  ← Spread out over time
Client C retries at: 0.5s, 1.6s, 3.9s, 5.2s...
```

**Our Implementation**:
```python
def _calculate_backoff_delay(self, current_iteration: int) -> float:
    # Step 1: Calculate exponential base delay
    base_delay = ERROR_RECOVERY_BACKOFF_BASE_DELAY * (2 ** min(current_iteration, ERROR_RECOVERY_BACKOFF_MAX_MULTIPLIER))
    
    # Step 2: Apply equal jitter (50% guaranteed + 50% random)
    jittered_delay = base_delay / ERROR_RECOVERY_BACKOFF_JITTER_FACTOR + random.uniform(0, base_delay / ERROR_RECOVERY_BACKOFF_JITTER_FACTOR)
    
    # Step 3: Apply maximum delay cap
    return min(jittered_delay, ERROR_RECOVERY_BACKOFF_MAX_DELAY)
```

**Parameter Explanations**:

- **`ERROR_RECOVERY_BACKOFF_BASE_DELAY`** (1.0s): The starting delay for the first retry attempt
- **`ERROR_RECOVERY_BACKOFF_MAX_DELAY`** (30.0s): Maximum delay cap - prevents waiting too long
- **`ERROR_RECOVERY_BACKOFF_MAX_MULTIPLIER`** (5): Caps exponential growth at 2^5 = 32x to prevent infinite delays
- **`ERROR_RECOVERY_BACKOFF_JITTER_FACTOR`** (2.0): Controls jitter amount in equal jitter strategy:
  - Divides base delay by this factor (2.0) to get jitter range
  - For 4s base delay: guaranteed 2s + random 0-2s = final delay 2-4s
  - Ensures minimum 50% delay while adding randomness

**Equal Jitter Benefits**:
- **Prevents thundering herd**: Clients retry at different times
- **Guaranteed minimum**: Never waits less than 50% of calculated delay
- **Bounded maximum**: Never exceeds 100% of calculated delay
- **Predictable**: Easy to reason about behavior

**When Applied**: Automatically used for rate limit and service errors to give the API time to recover.


### Integration with SingleAgent

The error recovery system is seamlessly integrated into the SingleAgent processing loop:

```mermaid
sequenceDiagram
    participant Agent as SingleAgent
    participant LLM as ChatLLM
    participant Memory as Memory
    participant Recovery as Error Recovery
    
    Agent->>LLM: generate_response()
    LLM-->>Agent: Exception (Context Limit)
    Agent->>Recovery: _attempt_error_recovery()
    Recovery->>Recovery: classify_llm_error()
    Recovery->>Recovery: Create LLMPlatformError
    
    alt Context Limit Error
        Recovery->>Memory: force_memory_reduction(20%)
        Memory-->>Recovery: {messages_removed: 5, tokens_reduced: 33000}
        Recovery-->>Agent: {success: true, strategy: "force_reduction"}
        Agent->>LLM: generate_response() [retry]
        LLM-->>Agent: Success
    else Rate Limit Error
        Recovery->>Recovery: Calculate backoff delay
        Recovery->>Recovery: time.sleep(delay)
        Recovery-->>Agent: {success: true, strategy: "exponential_backoff"}
        Agent->>LLM: generate_response() [retry]
    else Non-recoverable Error
        Recovery-->>Agent: {success: false, reason: "User action required"}
        Agent-->>Agent: Inform user and stop
    end
```

### Configuration

The error recovery system is highly configurable:

```python
# Recovery limits
ERROR_RECOVERY_ENABLED = True
ERROR_RECOVERY_MAX_RETRIES = 1      # Max LLM retries after recovery

# Memory reduction
ERROR_RECOVERY_MEMORY_REDUCTION_PERCENTAGE = 0.20  # 20% reduction per attempt

# Backoff recovery configuration
ERROR_RECOVERY_BACKOFF_BASE_DELAY = 1.0      # 1 second base delay
ERROR_RECOVERY_BACKOFF_MAX_DELAY = 30.0      # Maximum 30 seconds
ERROR_RECOVERY_BACKOFF_MAX_MULTIPLIER = 5    # Cap at 2^5 = 32
ERROR_RECOVERY_BACKOFF_JITTER_FACTOR = 2.0   # Equal jitter: delay/factor + random(0, delay/factor)
```

### Real-World Error Handling

The system handles actual error patterns from major LLM providers:

**OpenAI Context Limit:**
```
Error code: 400 - {'error': {'message': 'input length and `max_tokens` exceed context limit: 165127 + 40000 > 200000, decrease input length or `max_tokens` and try again'}}
```

**Anthropic Rate Limit:**
```
Rate limit exceeded: too many requests per minute
```

**Service Unavailable:**
```
Internal server error - service temporarily unavailable
```

### Monitoring and Callbacks

The error recovery system provides comprehensive monitoring through callbacks:

- `on_error_recovery_start(error, attempt)`: Called when recovery begins
- `on_error_recovery_end(success, strategy, details)`: Called when recovery completes
- Rich logging with error classification and recovery metrics
- Detailed error metadata for debugging and monitoring

## Key Features

### Provider and Model Discovery

The module provides comprehensive provider and model discovery capabilities:

- Fetch available providers from the GEAI API
- Fetch models for specific providers
- Filter models by type (Chat, Embedding, Image, Rerank)
- Check model availability for specific provider/model combinations
- Retrieve comprehensive information about all providers and models

### Chat Completion

The module supports sophisticated chat-based interactions with language models:

- Send messages with different roles (system, user, assistant)
- Automatically add system prompts when needed
- Handle provider-specific message formatting requirements
- Configure model parameters (temperature, max tokens, etc.)
- Process and return structured responses

### Health Monitoring

The module includes health monitoring capabilities:

- Check service health with caching for performance
- Force refresh health status when needed
- Detect and handle connection errors
- Invalidate health cache on connection failures
- Log health status for monitoring

### Error Handling and Recovery

The module provides comprehensive error handling through a dedicated error submodule:

- **Intelligent Error Classification**: Automatic detection and categorization of LLM errors
- **Recovery Strategies**: Context limit recovery through memory reduction, rate limit recovery through backoff
- **Retry Logic**: Configurable retry attempts with exponential backoff and jitter
- **Error Enrichment**: Enhanced error objects with metadata and recovery recommendations
- **Integration**: Seamless integration with SingleAgent and memory systems for automatic recovery
- **Monitoring**: Comprehensive logging and callback system for error tracking
- **Real-world Coverage**: Handles actual error patterns from major LLM providers

### Usage Tracking

The module includes comprehensive usage tracking capabilities:

- Track token usage for all LLM interactions
- Capture input and output token counts
- Track model and provider information for each request
- Support for background operations like session auto-renaming
- Consistent usage tracking across all interaction types
- Usage data is preserved in session state for persistence
- Provides data for cost estimation and optimization

## Data Flow

The execution of a model interaction follows a standard flow:

```mermaid
flowchart TD
    A[Application Creates ChatLLM] --> B[Application Prepares Messages]
    B --> C[Application Calls generate_response]
    C --> D[ChatLLM Adds System Prompt if Needed]
    D --> E[ChatLLM Calls client.chat_completion]
    E --> F[GEAIClient Prepares Request]
    F --> G[GEAIClient Sends Request to API]
    G -->|Success| H[GEAIClient Processes Response]
    G -->|Failure| I[GEAIClient Implements Retry Logic]
    I --> J[GEAIClient Truncates Messages]
    J --> G
    H --> K[ChatLLM Returns Response to Application]
    
    L[Application Requests Model Info] --> M[GEAIClient Checks Cache]
    M -->|Cache Valid| N[Return Cached Info]
    M -->|Cache Invalid| O[Fetch Fresh Info]
    O --> P[Update Cache]
    P --> Q[Return Info to Application]
```

1. The application creates a ChatLLM instance with a specific provider and model
2. The application prepares messages for the conversation
3. The application calls generate_response with the messages
4. The ChatLLM adds a system prompt if needed
5. The ChatLLM calls the GEAIClient's chat_completion method
6. The GEAIClient prepares the request with appropriate parameters
7. The GEAIClient sends the request to the API
8. If successful, the GEAIClient processes the response
9. If unsuccessful, the GEAIClient implements retry logic
10. The ChatLLM returns the response to the application

## Integration

### Application Integration

The models module is integrated with the CODA Core application:

- The ChatLLM class provides a simple interface for generating responses
- The GEAIClient handles the complexities of provider interactions
- The LLM base class ensures consistent behavior across different model types
- Model context window limits are enforced through integration with the memory module

### Agent Integration

The models module integrates with the agent system:

- Agents can create and use ChatLLM instances
- Agents can configure models with system prompts and parameters
- Agents can send messages and receive responses
- Agents can retrieve model information
- Model switching capabilities respect context window constraints

### Memory Integration

The models module integrates with the memory system:

- Provides context window information to memory management
- Supports token counting validation before request submission
- Enables safe model switching with different context windows
- Helps enforce the inequality `input_tokens + max_output_tokens <= context_window`
- Communicates model capabilities to inform memory constraints

### Error Handling Integration

The error submodule provides sophisticated error handling integration:

- **Automatic Classification**: All LLM errors are automatically classified using `classify_llm_error()`
- **Recovery Integration**: SingleAgent automatically attempts recovery using appropriate strategies
- **Memory Integration**: Context limit errors trigger `force_memory_reduction()` in the memory system
- **Callback Integration**: Error recovery events are exposed through the callback system
- **Logging Integration**: Comprehensive error tracking with classification and recovery metrics
- **Health Monitoring**: Connection errors trigger health cache invalidation
- **Proactive Prevention**: Context window violations are prevented through token validation
- **Provider Agnostic**: Handles error patterns from all major LLM providers (OpenAI, Anthropic, Google, etc.)