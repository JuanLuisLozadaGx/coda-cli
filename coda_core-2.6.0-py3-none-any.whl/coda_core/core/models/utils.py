from typing import Any, Callable, Dict, List, Optional
import importlib.resources
from inspect import signature
import html
import json
import time

from loguru import logger
import requests
from requests import Session

from coda_core.core.utils.backoff import compute_exponential_base_delay, apply_equal_jitter
from coda_core.core.models.constants import (
    HTTP_MAX_ATTEMPTS,
    HTTP_DEFAULT_TIMEOUT,
    HTTP_BACKOFF_BASE_DELAY,
    HTTP_BACKOFF_MAX_MULTIPLIER,
    HTTP_BACKOFF_JITTER_FACTOR,
)
from coda_core.core.models.providers.responses_api.enums import ReasoningEffort
from coda_core.core.models.schemas import Model


REASONING_EFFORT_NONE = "none"
REASONING_EFFORT_MINIMAL = ReasoningEffort.MINIMAL.value
REASONING_EFFORT_LOW = ReasoningEffort.LOW.value
REASONING_EFFORT_MEDIUM = ReasoningEffort.MEDIUM.value
REASONING_EFFORT_HIGH = ReasoningEffort.HIGH.value
REASONING_EFFORT_ORDER = (
    REASONING_EFFORT_MINIMAL,
    REASONING_EFFORT_LOW,
    REASONING_EFFORT_MEDIUM,
    REASONING_EFFORT_HIGH,
)
REASONING_EFFORT_VALUES = (REASONING_EFFORT_NONE, *REASONING_EFFORT_ORDER)
CHAT_REASONING_EFFORT_ORDER = (
    REASONING_EFFORT_LOW,
    REASONING_EFFORT_MEDIUM,
    REASONING_EFFORT_HIGH,
)


def extract_response_text(response: Any) -> Optional[str]:
    text = getattr(response, "output_text", None)
    if isinstance(text, str) and text.strip():
        return text
    choices = getattr(response, "choices", None)
    if isinstance(choices, list) and choices:
        message = getattr(choices[0], "message", None)
        if message is not None:
            content = getattr(message, "content", None)
            return content if isinstance(content, str) else None
        return None
    return None


def send_request(
    url: str,
    api_key: Optional[str] = None,
    headers: Optional[Dict[str, str]] = None,
    session: Optional[Session] = None
) -> Optional[Dict]:
    """Send an HTTP GET with minimal resiliency for transient connection issues.

    Implements a small retry loop for requests.ConnectionError using exponential
    backoff with equal jitter (aligned with LLM backoff practices). Supports flexible
    authentication headers that can be merged with or override the default Bearer token.

    Args:
        url (str): The URL to send the request to.
        api_key (Optional[str]): The API key for authorization. If provided, creates a Bearer token.
        headers (Optional[Dict[str, str]]): Additional headers to merge with defaults.
        session (Optional[Session]): Optional requests Session to reuse connections.

    Returns:
        Optional[Dict]: JSON response as a dict on success, or None if an error occurs.
    """
    request_headers = {"Accept": "application/json"}
    
    if api_key:
        request_headers["Authorization"] = f"Bearer {api_key}"
    
    if headers:
        request_headers.update(headers)

    for attempt in range(HTTP_MAX_ATTEMPTS):
        try:
            response = (
                session.get(url=url, headers=request_headers, timeout=HTTP_DEFAULT_TIMEOUT)
                if session
                else requests.get(url=url, headers=request_headers, timeout=HTTP_DEFAULT_TIMEOUT)
            )
            response.raise_for_status()
            return response.json()

        except (requests.exceptions.ConnectionError, requests.exceptions.ReadTimeout) as conn_err:
            if attempt < HTTP_MAX_ATTEMPTS - 1:
                base_delay = compute_exponential_base_delay(
                    attempt=attempt,
                    base_delay=HTTP_BACKOFF_BASE_DELAY,
                    max_multiplier=HTTP_BACKOFF_MAX_MULTIPLIER,
                )
                delay = apply_equal_jitter(
                    delay=base_delay,
                    jitter_factor=HTTP_BACKOFF_JITTER_FACTOR,
                )

                logger.warning(
                    f"Connection error on GET {url}; retrying in {delay:.2f}s "
                    f"(attempt {attempt + 1}/{HTTP_MAX_ATTEMPTS}): {conn_err}"
                )
                time.sleep(delay)
                continue

            logger.exception(
                f"Connection error after {HTTP_MAX_ATTEMPTS} attempts for {url}: {conn_err}"
            )
            break

        except requests.exceptions.HTTPError as http_err:
            logger.exception(f"HTTP error occurred: {http_err}")
            break

        except Exception as err:
            logger.exception(f"An error occurred: {err}")
            break

    return None


def sanitize_call_arguments(func: Callable, **kwargs: Any) -> Dict[str, Any]:
    """
    Filters and returns only the keyword arguments that are valid for the given function.

    Args:
        func (Callable): The function for which arguments are being sanitized.
        **kwargs: Arbitrary keyword arguments to be filtered.

    Returns:
        Dict[str, Any]: A dictionary containing only the valid arguments for the function.
    """
    valid_args = set(signature(func).parameters)
    return {k: v for k, v in kwargs.items() if k in valid_args}


def load_prompt(template_name: str, context: Optional[Dict[str, Any]] = None) -> str:
    """
    Loads and renders a Handlebars template from the package resources.
    
    Args:
        template_name (str): The name of the Handlebars (.hbs) template in config.prompts
        context (Optional[Dict[str, Any]]): A dictionary of variables to render the template.
    
    Returns:
        str: The rendered template as a string.
    """
    from pybars import Compiler

    try:
        file_path = importlib.resources.files('coda_core.config.prompts') / template_name
        with open(file_path, 'r', encoding='utf-8') as file:
            template_content = file.read()

            if not template_content.strip():
                raise ValueError(f"The file '{file_path}' is empty.")

            if context is None:
                context = {}

            if not isinstance(context, dict):
                raise ValueError("The context must be a dictionary.")

            compiler = Compiler()
            template = compiler.compile(template_content)

            rendered_prompt = template(context)

            rendered_prompt = html.unescape(rendered_prompt)

            return rendered_prompt

    except (ImportError, FileNotFoundError) as e:
        logger.exception(f"Template '{template_name}' not found in package resources: {e}")
        raise FileNotFoundError(f"Template '{template_name}' not found in package resources: {e}")


def is_model_supported(model: Model) -> bool:
    """
    Analyze if a model is supported.

    This function checks for the following conditions:
    - The model type must be "Chat".
    - The model must have a positive max_output_tokens value.
    - The model must support function calling or tool calling.

    Args:
        model (Model): The model to analyze.
    
    Returns:
        bool: Whether the model is supported.
    """
    supports_function_calling = any(
        property for property in model.properties if
            property.name in ("SupportsFunctionCalling", "SupportsToolCalling") and
            property.value.lower() == "true"
    )
    
    is_supported = (
        model.type == "Chat" and
        model.max_output_tokens > 0 and
        supports_function_calling
    )

    if not is_supported:
        logger.warning(f"Model '{model.name}' is not supported: "
                       f"type={model.type}, "
                       f"max_output_tokens={model.max_output_tokens}, "
                       f"supports_function_calling={supports_function_calling}")
    
    return is_supported


def normalize_reasoning_effort(effort: Optional[str]) -> Optional[str]:
    """
    Normalize a reasoning effort string to a known value.

    Args:
        effort: Raw reasoning effort value.

    Returns:
        Normalized effort value when valid, otherwise ``None``.
        The alias ``default`` is normalized to ``none``.
    """
    if not isinstance(effort, str):
        return None

    normalized = effort.strip().lower()
    if normalized == "default":
        return REASONING_EFFORT_NONE

    if normalized in REASONING_EFFORT_VALUES:
        return normalized
    return None


def _extract_reasoning_efforts(value: str) -> List[str]:
    """
    Extract recognized reasoning efforts from a property value string.

    Args:
        value: Raw property value.

    Returns:
        Ordered list of recognized efforts without duplicates.
    """
    if not value:
        return []

    parsed_values: List[str] = []
    stripped = value.strip()
    if stripped.startswith("["):
        try:
            decoded = json.loads(stripped)
            if isinstance(decoded, list):
                parsed_values = [str(item) for item in decoded]
        except Exception:
            parsed_values = []

    if not parsed_values:
        separators_normalized = (
            stripped.replace("|", ",")
            .replace(";", ",")
            .replace("/", ",")
        )
        parsed_values = [token.strip() for token in separators_normalized.split(",")]

    found = {
        effort
        for token in parsed_values
        if (effort := normalize_reasoning_effort(token)) in REASONING_EFFORT_ORDER
    }
    return [effort for effort in REASONING_EFFORT_ORDER if effort in found]


def _infer_reasoning_efforts_from_model_name(model: Model) -> List[str]:
    """
    Infer reasoning-effort support from provider/model naming heuristics.

    Args:
        model: Model metadata object.

    Returns:
        Ordered list of inferred efforts, excluding ``none``.
    """
    full_name = str(getattr(model, "full_name", "") or "").lower()
    model_name = str(getattr(model, "name", "") or "").lower()
    provider_name = full_name.split("/", maxsplit=1)[0] if "/" in full_name else ""

    if provider_name == "openai" and model_name.startswith("gpt-5"):
        return list(REASONING_EFFORT_ORDER)

    if "claude" in model_name and provider_name in {"anthropic", "vertex_ai", "bedrock"}:
        return list(CHAT_REASONING_EFFORT_ORDER)

    return []


def get_model_reasoning_efforts(model: Model) -> List[str]:
    """
    Resolve supported reasoning efforts for a model.

    Returned values always include ``none`` as an opt-out and then any supported
    effort levels in canonical order.

    Args:
        model: Model metadata object.

    Returns:
        List of available reasoning effort values.
    """
    supports_reasoning: Optional[bool] = None
    explicit_efforts: List[str] = []
    properties = getattr(model, "properties", []) or []

    for prop in properties:
        prop_name = str(getattr(prop, "name", "") or "").lower().replace("_", "")
        prop_value = str(getattr(prop, "value", "") or "").strip()
        lowered_value = prop_value.lower()

        if prop_name in {"supportsreasoning", "supportsreasoningeffort"}:
            if lowered_value in {"true", "1", "yes"}:
                supports_reasoning = True
            elif lowered_value in {"false", "0", "no"}:
                supports_reasoning = False

        if prop_name in {"reasoningefforts", "supportedreasoningefforts", "reasoningeffort"}:
            explicit_efforts = _extract_reasoning_efforts(prop_value)

    if supports_reasoning is False:
        return [REASONING_EFFORT_NONE]

    if explicit_efforts:
        return [REASONING_EFFORT_NONE, *explicit_efforts]

    if supports_reasoning is True:
        return [REASONING_EFFORT_NONE, REASONING_EFFORT_LOW, REASONING_EFFORT_MEDIUM, REASONING_EFFORT_HIGH]

    inferred_efforts = _infer_reasoning_efforts_from_model_name(model)
    if inferred_efforts:
        return [REASONING_EFFORT_NONE, *inferred_efforts]

    return [REASONING_EFFORT_NONE]
