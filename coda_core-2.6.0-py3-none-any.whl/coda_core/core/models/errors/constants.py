from typing import List

# Error recovery configuration
ERROR_RECOVERY_MAX_RETRIES: int = 1     # Maximum LLM call retries after successful recovery
ERROR_RECOVERY_MEMORY_REDUCTION_PERCENTAGE: float = 0.20  # 20% reduction per attempt

# Backoff recovery configuration
ERROR_RECOVERY_BACKOFF_BASE_DELAY: float = 1.0  # 1 second base delay
ERROR_RECOVERY_BACKOFF_MAX_DELAY: float = 30.0  # Maximum 30 seconds
ERROR_RECOVERY_BACKOFF_MAX_MULTIPLIER: int = 5  # Cap at 2^5 = 32
ERROR_RECOVERY_BACKOFF_JITTER_FACTOR: float = 2.0  # Equal jitter: delay/factor + random(0, delay/factor)

# Keyword lists for simple error classification
CONTEXT_LIMIT_KEYWORDS: List[str] = [
    "context limit", "context exceed", "max_tokens", "input length", "token limit",
    "context window", "maximum context", "reduce the length", "prompt is too long",
    "context length", "too many tokens", "input too long", "message too long",
    "context_length_exceeded", "maximum context length", "request too large",
    "resource_exhausted", "maximum length"
]

RATE_LIMIT_KEYWORDS: List[str] = [
    "rate limit", "quota", "throttl", "too many requests",
    "rate_limit_exceeded", "quota_exceeded", "requests per", "per minute",
    "per second", "per hour", "usage limit", "billing", "insufficient quota",
    "rate exceeded"
]

SERVICE_ERROR_KEYWORDS: List[str] = [
    "server error", "service unavailable", "timeout", "connection", "network",
    "internal error", "bad gateway", "service down", "maintenance", "overloaded",
    "internal server error", "temporarily unavailable", "capacity"
]

AUTHENTICATION_KEYWORDS: List[str] = [
    "unauthorized", "authentication", "api key", "invalid key", "access denied",
    "forbidden", "permission", "credential", "token invalid", "not authorized",
    "invalid api key", "authentication failed", "api key not found", "invalid authentication"
]

CONTENT_POLICY_KEYWORDS: List[str] = [
    "content policy", "inappropriate", "violation", "filtered", "blocked",
    "safety", "harmful", "offensive", "moderation", "policy violation",
    "content filter", "safety filter", "inappropriate content", "content violation",
    "harmful content", "blocked by guardrails"
]
