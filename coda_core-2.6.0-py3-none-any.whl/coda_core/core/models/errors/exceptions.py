from typing import Any, Optional

from coda_core.core.models.errors.types import LLMErrorSeverity
from coda_core.core.models.errors.types import LLMErrorAction, LLMErrorCategory


class LLMPlatformError(Exception):
    """Exception for LLM errors with actionable classification.
    
    This exception preserves the original error context while adding
    classification information for error handling and recovery strategies.
    Focuses on actionable error categories for recovery.
    
    Attributes:
        original_error: The original exception that was caught.
        error_category: Category of the error (context_limit, rate_limit, etc.).
        error_action: Recommended action for handling.
        error_severity: Severity level of the error.
        metadata: Optional additional metadata about the error.
    """
    
    def __init__(
        self,
        original_error: Exception,
        error_category: LLMErrorCategory,
        error_action: LLMErrorAction,
        error_severity: LLMErrorSeverity,
        message: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None
    ) -> None:
        """Initialize the LLM platform error.
        
        Args:
            original_error: The original exception that was caught.
            error_category: Category of the error.
            error_action: Recommended action for handling.
            error_severity: Severity level of the error.
            message: Optional custom message, defaults to original error message.
            metadata: Optional additional metadata (tokens, limits, retry_after, etc.).
        """
        self.original_error = original_error
        self.error_category = error_category
        self.error_action = error_action
        self.error_severity = error_severity
        self.metadata = metadata or {}
        
        # Use custom message or fall back to original error message
        error_message = message or str(original_error)
        super().__init__(error_message)
    
    def __str__(self) -> str:
        """Return string representation with classification info."""
        return (
            f"{self.error_category.value} error: "
            f"{super().__str__()} (action: {self.error_action.value})"
        )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert error to dictionary for logging/serialization.
        
        Returns:
            Dictionary containing error details and classification.
        """
        return {
            "error_type": self.__class__.__name__,
            "original_error": str(self.original_error),
            "original_error_type": type(self.original_error).__name__,
            "error_category": self.error_category.value,
            "error_action": self.error_action.value,
            "error_severity": self.error_severity.value,
            "message": super().__str__(),
            "metadata": self.metadata
        }
    
    def get_metadata(self, key: str, default: Any = None) -> Any:
        """Get metadata value by key.
        
        Args:
            key: Metadata key to retrieve.
            default: Default value if key not found.
            
        Returns:
            Metadata value or default.
        """
        return self.metadata.get(key, default)
    
    def set_metadata(self, key: str, value: Any) -> None:
        """Set metadata value.
        
        Args:
            key: Metadata key to set.
            value: Value to set.
        """
        self.metadata[key] = value
    
    def is_recoverable(self) -> bool:
        """Check if this error is recoverable.
        
        Returns:
            True if error severity is RECOVERABLE.
        """
        return self.error_severity == LLMErrorSeverity.RECOVERABLE
    
    def requires_memory_reduction(self) -> bool:
        """Check if this error requires memory reduction for recovery.
        
        Returns:
            True if error action is RECOVER_WITH_MEMORY_REDUCTION.
        """
        return self.error_action == LLMErrorAction.RECOVER_WITH_MEMORY_REDUCTION
    
    def requires_backoff(self) -> bool:
        """Check if this error requires backoff retry for recovery.
        
        Returns:
            True if error action is RECOVER_WITH_BACKOFF.
        """
        return self.error_action == LLMErrorAction.RECOVER_WITH_BACKOFF
    
    def requires_user_action(self) -> bool:
        """Check if this error requires user intervention.
        
        Returns:
            True if error severity is USER_ACTION_REQUIRED.
        """
        return self.error_severity == LLMErrorSeverity.USER_ACTION_REQUIRED