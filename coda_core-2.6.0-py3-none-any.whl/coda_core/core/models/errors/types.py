from dataclasses import dataclass
from enum import Enum
from typing import Callable


class LLMErrorCategory(Enum):
    """Category of the LLM error.

    Attributes:
        CONTEXT_LIMIT: Token/context window exceeded
        RATE_LIMIT: Quota, rate limits, capacity issues
        AUTHENTICATION: Auth, API key, permission issues
        CONTENT_POLICY: Content filtering, policy violations
        SERVICE_ERROR: Server errors, timeouts, unavailable
        UNKNOWN: Cannot categorize
    """
    CONTEXT_LIMIT = "context_limit"
    RATE_LIMIT = "rate_limit"
    AUTHENTICATION = "authentication"
    CONTENT_POLICY = "content_policy"
    SERVICE_ERROR = "service_error"
    UNKNOWN = "unknown"


class LLMErrorAction(Enum):
    """Action to take for error recovery.

    Attributes:
        RECOVER_WITH_MEMORY_REDUCTION: Try to reduce context and retry
        RECOVER_WITH_BACKOFF: Retry with exponential backoff
        RECOVER_WITH_FALLBACK: Try alternative model/provider
        INFORM_USER: Log and inform user, no retry
        FAIL_IMMEDIATELY: Fatal error, stop processing
    """
    RECOVER_WITH_MEMORY_REDUCTION = "memory_reduction"
    RECOVER_WITH_BACKOFF = "backoff"
    RECOVER_WITH_FALLBACK = "fallback"
    INFORM_USER = "inform_user"
    FAIL_IMMEDIATELY = "fail_immediately"


class LLMErrorSeverity(Enum):
    """Severity level of the error.

    Attributes:
        RECOVERABLE: Can attempt automatic recovery
        USER_ACTION_REQUIRED: Requires user intervention
        FATAL: Cannot be recovered
    """
    RECOVERABLE = "recoverable"
    USER_ACTION_REQUIRED = "user_action"
    FATAL = "fatal"


@dataclass(frozen=True)
class ErrorRule:
    """Represents an error classification rule with priority ordering."""
    priority: int
    detector: Callable[[str], bool]
    category: LLMErrorCategory
    action: LLMErrorAction
    severity: LLMErrorSeverity
    description: str