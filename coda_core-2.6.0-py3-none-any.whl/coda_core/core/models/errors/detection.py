from typing import Tuple

from coda_core.core.models.errors.constants import (
    CONTEXT_LIMIT_KEYWORDS,
    RATE_LIMIT_KEYWORDS,
    SERVICE_ERROR_KEYWORDS,
    AUTHENTICATION_KEYWORDS,
    CONTENT_POLICY_KEYWORDS,
)
from coda_core.core.models.errors.types import ErrorRule, LLMErrorAction, LLMErrorCategory, LLMErrorSeverity


def _is_context_limit_error(error_str: str) -> bool:
    """Simple keyword detection for context limits.
    
    Uses comprehensive keyword list covering all provider patterns.
    
    Args:
        error_str: Lowercase error string to check.
        
    Returns:
        True if error string contains context limit keywords.
    """
    return any(keyword in error_str for keyword in CONTEXT_LIMIT_KEYWORDS)


def _is_rate_limit_error(error_str: str) -> bool:
    """Simple keyword detection for rate limits.
    
    Uses comprehensive keyword list covering all provider patterns.
    
    Args:
        error_str: Lowercase error string to check.
        
    Returns:
        True if error string contains rate limit keywords.
    """
    return any(keyword in error_str for keyword in RATE_LIMIT_KEYWORDS)


def _is_service_error(error_str: str) -> bool:
    """Simple keyword detection for service errors.
    
    Uses comprehensive keyword list covering all provider patterns.
    
    Args:
        error_str: Lowercase error string to check.
        
    Returns:
        True if error string contains service error keywords.
    """
    return any(keyword in error_str for keyword in SERVICE_ERROR_KEYWORDS)


def _is_authentication_error(error_str: str) -> bool:
    """Simple keyword detection for auth errors.
    
    Uses comprehensive keyword list covering all provider patterns.
    
    Args:
        error_str: Lowercase error string to check.
        
    Returns:
        True if error string contains authentication error keywords.
    """
    return any(keyword in error_str for keyword in AUTHENTICATION_KEYWORDS)


def _is_content_policy_error(error_str: str) -> bool:
    """Simple keyword detection for content policy errors.
    
    Uses comprehensive keyword list covering all provider patterns.
    
    Args:
        error_str: Lowercase error string to check.
        
    Returns:
        True if error string contains content policy keywords.
    """
    return any(keyword in error_str for keyword in CONTENT_POLICY_KEYWORDS)


# Ordered error classification rules (lower priority number = higher priority)
_ERROR_RULES = (
    ErrorRule(1, _is_context_limit_error,  LLMErrorCategory.CONTEXT_LIMIT,  LLMErrorAction.RECOVER_WITH_MEMORY_REDUCTION, LLMErrorSeverity.RECOVERABLE, "Context/token limit"),
    ErrorRule(2, _is_rate_limit_error,     LLMErrorCategory.RATE_LIMIT,     LLMErrorAction.RECOVER_WITH_BACKOFF,          LLMErrorSeverity.RECOVERABLE, "Rate limit"),
    ErrorRule(3, _is_service_error,        LLMErrorCategory.SERVICE_ERROR,  LLMErrorAction.RECOVER_WITH_BACKOFF,          LLMErrorSeverity.RECOVERABLE, "Service/server"),
    ErrorRule(4, _is_authentication_error, LLMErrorCategory.AUTHENTICATION, LLMErrorAction.INFORM_USER,                   LLMErrorSeverity.USER_ACTION_REQUIRED, "Auth"),
    ErrorRule(5, _is_content_policy_error, LLMErrorCategory.CONTENT_POLICY, LLMErrorAction.INFORM_USER,                   LLMErrorSeverity.FATAL, "Content policy"),
)


def classify_llm_error(exception: Exception) -> Tuple[LLMErrorCategory, LLMErrorAction, LLMErrorSeverity]:
    """Classify an LLM error using an ordered dispatcher pattern.
    
    Uses priority-ordered rules to classify errors, making it easy to add new
    error types and maintain consistent priority ordering. Rules are processed
    in priority order (lowest number first) until a match is found.
    
    Args:
        exception: The exception to classify.
        
    Returns:
        Tuple of (category, action, severity) for handling the error.
    """
    error_str = str(exception).lower()
    
    # Process rules in priority order until we find a match
    for rule in _ERROR_RULES:
        if rule.detector(error_str):
            return rule.category, rule.action, rule.severity
    
    # Default: unknown error, inform user
    return (LLMErrorCategory.UNKNOWN,
            LLMErrorAction.INFORM_USER,
            LLMErrorSeverity.USER_ACTION_REQUIRED)


# Utility functions for external use

def is_recoverable_error(exception: Exception) -> bool:
    """Quick check if an error is recoverable.
    
    Useful for simple recovery decisions without full classification.
    
    Args:
        exception (Exception): The exception to check.

    Returns:
        bool: True if the error severity is RECOVERABLE, False otherwise.
    """
    _, _, severity = classify_llm_error(exception)
    return severity == LLMErrorSeverity.RECOVERABLE


def get_error_action(exception: Exception) -> LLMErrorAction:
    """Quick check for the recommended action for an error.
    
    Useful when you just need to know what action to take.
    
    Args:
        exception (Exception): The exception to check.

    Returns:
        LLMErrorAction: The recommended error action.
    """
    _, action, _ = classify_llm_error(exception)
    return action


def is_context_limit_error(exception: Exception) -> bool:
    """Quick check if an error is a context limit error.
    
    Useful for specific context limit handling.
    
    Args:
        exception (Exception): The exception to check.

    Returns:
        bool: True if the error category is CONTEXT_LIMIT, False otherwise.
    """
    category, _, _ = classify_llm_error(exception)
    return category == LLMErrorCategory.CONTEXT_LIMIT


def get_error_category(exception: Exception) -> LLMErrorCategory:
    """Quick check for error category.
    
    Useful for debugging and monitoring.
    
    Args:
        exception (Exception): The exception to check.

    Returns:
        LLMErrorCategory: The category assigned to the exception.
    """
    category, _, _ = classify_llm_error(exception)
    return category