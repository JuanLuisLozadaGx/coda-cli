# Memory type identifiers
MEMORY_TYPE_BASE = "base"
MEMORY_TYPE_TOKEN_LIMITED = "token_limited"
MEMORY_TYPE_COUNT_LIMITED = "count_limited"

# Memory capacity constants
MEMORY_DEFAULT_COUNT_LIMIT = 10000  # Default maximum number of messages for count-limited memory
MEMORY_DEFAULT_TOKEN_LIMIT = 100000  # Default maximum token count for token-limited memory

# Memory sizing constants
MIN_SAFE_MAX_TOKENS = 2000  # Minimum safe token limit for any memory
MEMORY_TARGET_TOKEN_RATIO = 0.9  # Target percentage of max_tokens for memory trimming
MEMORY_SIZE_CHANGE_THRESHOLD = 0.1  # Significant memory size change threshold (10%)

# Context window allocation percentages
OUTPUT_TOKENS_PERCENTAGE = 0.20  # 20% of context window reserved for model output
SAFETY_BUFFER_PERCENTAGE = 0.10  # 10% of context window reserved as safety buffer
MEMORY_PERCENTAGE = 0.70  # 70% of context window available for conversation history

# Memory condensing constants
MEMORY_DEFAULT_PRESERVE_RECENT_PERCENTAGE = 0.2     # Default to preserving 20% of recent messages
MEMORY_MIN_MESSAGES_TO_CONDENSE = 10                # Minimum number of messages to consider condensing
MEMORY_MIN_TOKENS_TO_CONDENSE = 500                 # Minimum total tokens to make condensing worthwhile
MEMORY_MIN_MESSAGES_TO_LEAVE_BEHIND = 4             # Minimum number of messages that must be left behind for condensing