from typing import Dict, Optional

from loguru import logger

from coda_core.core.utils.token_counting import get_encoding_for_model
from coda_core.core.memories.types import MemoryMigrationContext
from coda_core.core.memories import Memory


def migrate_memories(
    memories: Dict[str, Optional[Memory]],
    old_provider: str,
    old_model: str,
    new_provider: str,
    new_model: str,
    context_window: int,
    max_output_tokens: int
):
    """
    Migrate multiple memories in-place when the model is changed. 

    Args:
        memories (Dict[str, Optional[Memory]]): A dictionary of memory instances to migrate
        old_provider (str): The previous provider name
        old_model (str): The previous model name
        new_provider (str): The new provider name
        new_model (str): The new model name
        context_window (int): The context window size of the new model
        max_output_tokens (int): The maximum output tokens of the new model
    """
    # Skip if old and new models are the same
    if old_provider == new_provider and old_model == new_model:
        return

    # Log migration start
    logger.info(f"Memory migration started: {old_provider}/{old_model} → {new_provider}/{new_model}")
    logger.info(f"Context window: {context_window} tokens, Max output tokens: {max_output_tokens} tokens")

    # Track migration statistics
    migration_stats = {
        "memories_migrated": 0,
        "total_messages_before": 0,
        "total_messages_after": 0,
        "total_tokens_before": 0,
        "total_tokens_after": 0
    }

    # For each memory key
    for key in memories:
        memory = memories[key]

        # Skip if memory is not initialized
        if memory is None:
            continue

        # Log memory details before migration
        messages_before = len(memory.messages)
        tokens_before = memory.token_count
        logger.info(f"Memory '{key}' before migration: {messages_before} messages, {tokens_before} tokens")

        # Update migration statistics
        migration_stats["total_messages_before"] += messages_before
        migration_stats["total_tokens_before"] += tokens_before

        # Create a tiktoken encoding for accurate token counting
        encoding = None
        try:
            encoding = get_encoding_for_model(new_model)
        except Exception as e:
            logger.warning(f"Could not initialize tiktoken encoding: {e}. Will use character-based estimation.")

        # Migrate the memory in-place
        migration_ctx = MemoryMigrationContext(context_window=context_window, encoding=encoding)
        memory.migrate(migration_ctx)

        # Log memory details after migration
        messages_after = len(memory.messages)
        tokens_after = memory.token_count

        # Log message preservation/trimming information
        if messages_before != messages_after:
            preserved_count = messages_after
            trimmed_count = messages_before - preserved_count
            logger.info(
                f"Memory '{key}' messages: {preserved_count} preserved, {trimmed_count} trimmed "
                f"({preserved_count/messages_before*100:.1f}% preserved)"
            )
        else:
            logger.info(f"Memory '{key}': All {messages_before} messages preserved")

        # Update migration statistics
        migration_stats["memories_migrated"] += 1
        migration_stats["total_messages_after"] += messages_after
        migration_stats["total_tokens_after"] += tokens_after

    # Log migration summary
    logger.info(
        f"Memory migration completed: {migration_stats['memories_migrated']} memories migrated, "
        f"{migration_stats['total_messages_before']} → {migration_stats['total_messages_after']} messages, "
        f"{migration_stats['total_tokens_before']} → {migration_stats['total_tokens_after']} tokens"
    )
