from typing import List, Dict, Any, Optional, Set, Callable, TYPE_CHECKING
import copy
import json
import base64
import msgpack
from abc import ABC, abstractmethod
from collections import deque
from cachetools import LRUCache

from loguru import logger
from tiktoken.core import Encoding
import tiktoken

from coda_core.core.memories.types import MemoryMigrationContext
from coda_core.core.memories.constants import MEMORY_TYPE_BASE, MEMORY_MIN_MESSAGES_TO_CONDENSE, MEMORY_MIN_TOKENS_TO_CONDENSE
from coda_core.core.models.providers.oai.utils import is_completion_usage
from coda_core.core.models.providers.responses_api.enums import ItemType, MessageRole
from coda_core.core.models.providers.responses_api.interop import (
    build_function_call,
    build_function_call_output,
    build_input_message,
)
from coda_core.core.utils.constants import DEFAULT_CACHE_SIZE, DEFAULT_FALLBACK_ENCODING, DEFAULT_CHAR_TO_TOKEN_RATIO
from coda_core.core.utils.token_counting import count_message_tokens, create_token_cache, get_message_cache_key, get_encoding_for_model
from coda_core.core.memories.schemas import MemoryAssessment


if TYPE_CHECKING:
    from coda_core.core.memories.condenser import MemoryCondenser


class Memory(ABC):
    """
    Base class for memory implementations.
    
    This abstract class defines the interface that all memory implementations
    must follow, and provides common functionality for managing conversation
    history.
    """
    
    # Default type identifier, should be overridden by subclasses
    TYPE = MEMORY_TYPE_BASE
    
    # Registry to store memory class types
    _registry = {}
    
    @classmethod
    def register(cls, memory_type: str):
        """
        Decorator to register a memory implementation class.
        
        Args:
            memory_type: The type identifier for this memory class
        """
        def decorator(subclass):
            cls._registry[memory_type] = subclass
            return subclass
        return decorator


    def __init__(
        self, 
        char_to_token_ratio: int = DEFAULT_CHAR_TO_TOKEN_RATIO, 
        encoding: Optional[Encoding] = None,
        on_condensation_callback: Optional[Callable[[], None]] = None
    ):
        """
        Initialize the memory.
        
        Args:
            char_to_token_ratio: Fallback approximate number of characters per token if tiktoken fails
            encoding: Optional tiktoken encoding instance for accurate token counting
            on_condensation_callback: Optional callback to invoke when memory is condensed
        """
        self.messages = deque()
        
        # Maps tool call IDs to sets of message indices
        self.tool_call_map: Dict[str, Set[int]] = {}
        
        # Token counting attributes
        self._encoding = encoding
        self.char_to_token_ratio = char_to_token_ratio
        self.token_count = 0
        
        # Initialize token count cache
        self._token_count_cache = create_token_cache(maxsize=DEFAULT_CACHE_SIZE)
        
        # Condenser attribute
        self._condenser = None
        
        # Condensation callback
        self._condensation_callback = on_condensation_callback


    def set_condensation_callback(self, callback: Callable[[], None]) -> None:
        """
        Set or update the condensation callback.
        
        This allows registering a callback after memory initialization, useful when
        tools are created after memory.
        
        Args:
            callback: Callable to invoke when memory is condensed (takes no arguments)
        """
        self._condensation_callback = callback
        logger.info(f"Condensation callback registered: {callback.__name__ if hasattr(callback, '__name__') else callback}")


    def __getitem__(self, index: int | slice) -> Dict[str, Any] | List[Dict[str, Any]]:
        """
        Get a message by index.
        
        Args:
            index: The index to retrieve
            
        Returns:
            The message at the specified index
        """
        if isinstance(index, slice):
            # Handle slice notation
            return list(self.messages)[index]
        return list(self.messages)[index]


    def __len__(self) -> int:
        """
        Get the number of messages in memory.
        
        Returns:
            The number of messages
        """
        return len(self.messages)
    

    def __iter__(self) -> iter:
        """
        Iterate over messages.
        
        Returns:
            Iterator over messages
        """
        return iter(self.messages)


    def count_by_role(self, role: Optional[str] = None) -> Dict[str, int]:
        """
        Count messages by role.
        
        Args:
            role: Optional role to count. If provided, returns count for that role only.
                 If None, returns counts for all roles.
        
        Returns:
            Dict[str, int]: Count of messages by role. When role is specified, returns
                           a dictionary with that role as key and its count as value.
                           When role is None, returns counts for all roles.
        """
        if role is not None:
            # Count messages for a specific role and return as dictionary
            count = sum(1 for msg in self.messages if msg.get("role") == role)
            return {role: count}
        
        # Count messages for all roles
        counts = {}
        for msg in self.messages:
            msg_role = msg.get("role", "unknown")
            counts[msg_role] = counts.get(msg_role, 0) + 1
        
        return counts
    

    @abstractmethod
    def store(self, message: Dict[str, Any]) -> None:
        """
        Store a message in the conversation history.
        
        Args:
            message: A message dictionary with at least 'role' key
        """
        pass
    

    @abstractmethod
    def retrieve(self, query: Any = None) -> List[Dict[str, Any]]:
        """
        Retrieve messages from the conversation history.
        
        Args:
            query: Optional query parameter for filtering or searching
            
        Returns:
            List of message dictionaries
        """
        pass
    

    @abstractmethod
    def clear(self) -> None:
        """
        Clear all messages from memory except the system message.
        
        This method should reset the memory to its initial empty state
        while preserving any system message.
        """
        pass

    
    def pre_flight_memory_check(self, message: Dict[str, Any]) -> MemoryAssessment:
        """
        Assess memory's internal capabilities for storing message without mutation.
        
        Args:
            message: The message to check for storage
            
        Returns:
            MemoryAssessment containing memory's assessment of its own capabilities:
            - can_store: bool indicating if memory can handle the message
            - action (MemoryAssessmentAction): One of STORE_DIRECT, EVICT_THEN_STORE, SUGGEST_CONDENSE, REPORT_TO_AGENT
            - message_tokens: int token count for the message
            - current_tokens: int current token count in memory
            - capacity_limit: int maximum token capacity of the memory
            - tokens_to_free: int tokens that need to be freed (if applicable)
            - removable_tokens: int tokens that can be removed via eviction
            - reason_if_failed: str reason if can_store is False
        """
        raise NotImplementedError("Subclasses should implement pre_flight_memory_check")


    def force_memory_reduction(self, target_reduction_percentage: float = 0.20) -> Dict[str, Any]:
        """
        Force a memory size reduction (token trimming) using only internal mechanisms.

        Args:
            target_reduction_percentage: Fraction (0.0 - 1.0) of current token usage to attempt freeing.

        Returns:
            Dict[str, Any]: Implementation-specific reduction metrics
                (TokenLimitedMemory provides: initial_tokens, final_tokens, tokens_reduced,
                 requested_tokens, requested_percentage, actual_percentage,
                 messages_removed, plan_tokens_available).

        Notes:
            Concrete implementations must respect their protection / coherence guarantees
            (e.g., system messages, atomic tool call units, incomplete units).
        """
        raise NotImplementedError("Subclasses should implement force_memory_reduction")


    def is_system_message(self, message: Dict[str, Any]) -> bool:
        """
        Check if a message is a system message.
        
        Args:
            message: The message to check
            
        Returns:
            bool: True if the message is a system message, False otherwise
        """
        if message.get("type") == ItemType.MESSAGE and message.get("role") == MessageRole.SYSTEM.value:
            return True
        return message.get("role") == MessageRole.SYSTEM.value


    def get_system_message(self) -> Optional[Dict[str, Any]]:
        """
        Get the current system message if it exists.
        
        Returns:
            Optional[Dict[str, Any]]: The system message if it exists, None otherwise
        """
        for msg in self.messages:
            if self.is_system_message(msg):
                return msg
        return None


    def upsert_system_message(self, content: str) -> None:
        """
        Add or update the system message in memory.
        
        This method will:
        - Update the existing system message if one exists
        - Add a new system message at the beginning if none exists
        - Handle token accounting appropriately
        
        Args:
            content: The content of the system message
        """
        # Create the system message as a Responses-style input message
        system_message = build_input_message(MessageRole.SYSTEM, content)
        
        # Check if a system message already exists
        for i, msg in enumerate(self.messages):
            if self.is_system_message(msg):
                # Found existing system message - update it
                old_message = self.messages[i]
                self.messages[i] = system_message
                
                # For token-limited memory, update token count
                if hasattr(self, '_estimate_tokens') and hasattr(self, 'token_count'):
                    old_tokens = self._estimate_tokens(old_message)
                    new_tokens = self._estimate_tokens(system_message)
                    self.token_count = self.token_count - old_tokens + new_tokens
                    
                    # Log the system message update
                    logger.info(
                        "Stored message: role={role}, tokens={message_tokens}, total_token_count={total_token_count} (update operation)",
                        role=system_message.get("role"),
                        message_tokens=new_tokens,
                        total_token_count=self.token_count,
                    )
                    
                return
        
        # No system message found - add at beginning
        self.messages.appendleft(system_message)
        
        # For token-limited memory, update token count
        if hasattr(self, '_estimate_tokens') and hasattr(self, 'token_count'):
            message_tokens = self._estimate_tokens(system_message)
            self.token_count += message_tokens
            
            # Log the system message addition
            logger.info(
                "Stored message: role={role}, tokens={message_tokens}, total_token_count={total_token_count}",
                role=system_message.get("role"),
                message_tokens=message_tokens,
                total_token_count=self.token_count,
            )
    
    
    def resolve_orphaned_tool_calls(self, error_message: str) -> int:
        """
        Find tool calls without corresponding responses and add error responses for them.
        This helps maintain the integrity of the conversation history when errors occur.
        
        Args:
            error_message: The error message to include in the tool response
            
        Returns:
            int: Number of orphaned tool calls that were resolved
        """
        tool_call_ids = set()
        tool_response_ids = set()
        
        # First pass: collect all tool call IDs and tool response IDs
        for msg in self.messages:
            msg_type = msg.get("type")

            # Responses-style function calls
            if msg_type in {ItemType.FUNCTION_CALL, ItemType.FUNCTION_TOOL_CALL}:
                call_id = msg.get("call_id")
                if call_id:
                    tool_call_ids.add(call_id)

            # Legacy assistant tool calls
            if msg.get("role") == MessageRole.ASSISTANT.value and msg.get("tool_calls"):
                for tool_call in msg.get("tool_calls", []):
                    if "id" in tool_call:
                        tool_call_ids.add(tool_call["id"])

            # Responses-style tool outputs
            if msg_type in {ItemType.FUNCTION_CALL_OUTPUT, ItemType.FUNCTION_TOOL_CALL_OUTPUT}:
                call_id = msg.get("call_id")
                if call_id:
                    tool_response_ids.add(call_id)

            # Legacy tool responses
            if msg.get("role") == MessageRole.TOOL.value and "tool_call_id" in msg:
                tool_response_ids.add(msg["tool_call_id"])
        
        # Find tool calls without responses
        orphaned_tool_calls = tool_call_ids - tool_response_ids
        resolved_count = 0
        
        if orphaned_tool_calls:
            # Collect all tool responses we need to add
            tool_responses_to_add = []
            
            # Second pass: collect error responses for orphaned tool calls
            for msg in list(self.messages):  # Convert to list to avoid modification during iteration
                msg_type = msg.get("type")

                if msg_type in {ItemType.FUNCTION_CALL, ItemType.FUNCTION_TOOL_CALL}:
                    call_id = msg.get("call_id")
                    if call_id in orphaned_tool_calls:
                        tool_response = build_function_call_output(
                            call_id=call_id,
                            output={
                                "status": "error",
                                "message": f"Error occurred: {error_message}. Try again.",
                            },
                        )
                        if msg.get("name"):
                            tool_response["name"] = msg.get("name")
                        tool_responses_to_add.append(tool_response)
                        resolved_count += 1

                if msg.get("role") == MessageRole.ASSISTANT.value and msg.get("tool_calls"):
                    for tool_call in msg.get("tool_calls", []):
                        if "id" in tool_call and tool_call["id"] in orphaned_tool_calls:
                            tool_response = build_function_call_output(
                                call_id=tool_call["id"],
                                output={
                                    "status": "error",
                                    "message": f"Error occurred: {error_message}. Try again.",
                                },
                            )
                            tool_name = tool_call.get("function", {}).get("name")
                            if tool_name:
                                tool_response["name"] = tool_name
                            tool_responses_to_add.append(tool_response)
                            resolved_count += 1
            
            # Now add all the tool responses after we've finished iterating
            for tool_response in tool_responses_to_add:
                self.store(tool_response)
        
        return resolved_count
    

    def _estimate_tokens(self, message: Dict[str, Any]) -> int:
        """
        Count tokens in a message using the shared token counting utility.
        
        Args:
            message: The message to estimate tokens for
            
        Returns:
            Token count
        """
        return count_message_tokens(
            message,
            encoding=self._encoding,
            char_to_token_ratio=self.char_to_token_ratio,
            cache=self._token_count_cache
        )

    def _calculate_tokens_for_indices(self, indices: List[int]) -> int:
        """Calculate total tokens for a list of message indices.

        Args:
            indices: List of message indices to calculate tokens for.

        Returns:
            Total number of tokens for all valid indices.
        """
        total = 0
        for idx in indices:
            if 0 <= idx < len(self.messages):
                total += self._estimate_tokens(self.messages[idx])
        return total


    def get_total_token_count(self) -> int:
        """
        Get the total token count of all messages in memory.
        
        Returns:
            Total token count
        """
        return self.token_count

    def migrate(self, migration_ctx: MemoryMigrationContext):
        """
        Migrate a memory in-place updating the encoding and migrating all existing messages if needed.

        Args:
            migration_ctx (MemoryMigrationContext): Context containing migration parameters.
        """
        if migration_ctx.encoding:
            if self._encoding is None or self._encoding.name != migration_ctx.encoding.name:
                self._encoding = migration_ctx.encoding
                existing_messages = self.retrieve()
                self.clear()
                for msg in existing_messages:
                    if msg.get("type") == ItemType.MESSAGE and msg.get("role") == MessageRole.SYSTEM.value:
                        content = msg.get("content", "")
                        if isinstance(content, list):
                            content = " ".join(
                                block.get("text", "")
                                for block in content
                                if isinstance(block, dict) and block.get("text")
                            )
                        elif content is None:
                            content = ""
                        elif not isinstance(content, str):
                            content = str(content)
                        self.upsert_system_message(content)
                    elif msg.get("role") == MessageRole.SYSTEM.value:
                        self.upsert_system_message(msg.get("content", ""))
                    else:
                        self.store(msg)

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize the memory to a dictionary for persistence.
        
        Returns:
            Dictionary representation of the memory
        """
        # Store encoding info if available
        encoding_name = None
        if self._encoding is not None:
            try:
                # Store the encoding name if possible
                encoding_name = self._encoding.name
            except Exception:
                # If we can't get the name, store a default
                encoding_name = DEFAULT_FALLBACK_ENCODING
        
        # Serialize the token count cache efficiently
        token_cache_b64 = None
        try:
            # Convert cache to a regular dict
            cache_dict = dict(self._token_count_cache.items())
            
            # Use msgpack for compact binary serialization
            binary_data = msgpack.packb(cache_dict)
            
            # Convert binary to base64 string (SQLite/JSON compatible)
            token_cache_b64 = base64.b64encode(binary_data).decode('ascii')
        except Exception as e:
            logger.warning(f"Error serializing token cache: {e}")
        
        # Create the base serialization data
        data = {
            "type": self.__class__.TYPE,
            "messages": list(self.messages),
            "token_count": self.token_count,
            "char_to_token_ratio": self.char_to_token_ratio,
            "encoding_name": encoding_name,
            "token_cache_b64": token_cache_b64
        }
        
        # Add condenser configuration if present
        if self._condenser is not None:
            data.update({
                "had_condenser": True,
                "condenser_config": self._condenser.to_dict()
            })
        else:
            data.update({
                "had_condenser": False
            })
            
        return data
    

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Memory':
        """
        Create a Memory instance from a dictionary.
        
        This method will instantiate the correct subclass based on the 'type' field.
        
        Args:
            data: Dictionary representation of a Memory
            
        Returns:
            New Memory instance of the appropriate type
        """
        memory_type = data.get("type", cls.TYPE)
        
        # If we're already the correct class, instantiate directly
        if memory_type == cls.TYPE:
            # Initialize memory with common parameters
            memory = cls(
                char_to_token_ratio=data.get("char_to_token_ratio", DEFAULT_CHAR_TO_TOKEN_RATIO)
            )
            
            # Apply common initialization
            memory = cls._initialize_from_dict(memory, data)
            return memory
        
        # Otherwise, find the appropriate class in the registry
        if memory_type in cls._registry:
            memory_class = cls._registry[memory_type]
            return memory_class.from_dict(data)
        
        raise ValueError(f"Unknown memory type: {memory_type}")


    @classmethod
    def _initialize_from_dict(cls, memory: 'Memory', data: Dict[str, Any]) -> 'Memory':
        """
        Initialize a Memory instance from a dictionary.
        
        This helper method is used by from_dict implementations to apply common initialization
        logic, including encoding initialization and token cache deserialization.
        
        Args:
            memory: The Memory instance to initialize
            data: Dictionary representation of a Memory
            
        Returns:
            The initialized Memory instance
        """
        # Try to recreate the encoding if encoding_name is available
        encoding_name = data.get("encoding_name")
        if encoding_name:
            try:
                # Try to use the encoding name directly
                memory._encoding = tiktoken.get_encoding(encoding_name)
            except Exception:
                # If that fails, try to get a model-specific encoding
                # This might happen if the encoding name is actually a model name
                try:
                    memory._encoding = get_encoding_for_model(encoding_name)
                except Exception as e:
                    logger.warning(f"Could not initialize tiktoken encoding: {e}")
        
        # Check if this is an older session (missing encoding_name or token_cache)
        is_older_session = "encoding_name" not in data or "token_cache_b64" not in data
        
        # For older sessions, ensure we have an encoding
        if is_older_session and memory._encoding is None:
            try:
                # Use the robust get_encoding_for_model function with the default fallback
                memory._encoding = get_encoding_for_model(DEFAULT_FALLBACK_ENCODING)
                logger.info(f"Using default encoding for older session")
            except Exception as e:
                logger.warning(f"Failed to initialize default encoding for older session: {e}")
        
        # Deserialize token count cache if available
        if "token_cache_b64" in data and data["token_cache_b64"]:
            try:
                # Decode base64 data
                binary_data = base64.b64decode(data["token_cache_b64"])
                
                # Unpack binary data to dict
                cache_dict = msgpack.unpackb(binary_data)
                
                # Create new LRUCache and populate it
                memory._token_count_cache = LRUCache(maxsize=DEFAULT_CACHE_SIZE)
                
                # Add all items to the cache
                for key, value in cache_dict.items():
                    memory._token_count_cache[key] = value
                
                logger.info(f"Restored token count cache with {len(cache_dict)} entries")
            except Exception as e:
                logger.warning(f"Error deserializing token cache: {e}")
        
        # Restore messages - this will automatically populate the token count cache
        # for older sessions that don't have cache data
        messages = data.get("messages", [])
        for message in messages:
            memory.store(message)
        
        # Initialize condenser if it was present in the serialized data
        if data.get("had_condenser", False):
            try:
                # Create a condenser with the serialized configuration
                condenser_config = data.get("condenser_config", {})
                condenser = MemoryCondenser.from_dict(condenser_config)
                
                # Set the condenser on the memory instance
                memory._condenser = condenser
                logger.info("Restored memory condenser from serialized data")
            except Exception as e:
                logger.warning(f"Failed to restore memory condenser: {e}")
            
        return memory
    

    def append(self, message: Dict[str, Any]) -> None:
        """
        Append a message to the memory.
        
        Args:
            message: The message to append
        """
        self.store(message)
        
    @property
    def condenser(self) -> Optional['MemoryCondenser']:
        """
        Get the current memory condenser.
        
        Returns:
            The MemoryCondenser instance if set, None otherwise
        """
        return self._condenser
        
    @condenser.setter
    def condenser(self, value: Optional['MemoryCondenser']) -> None:
        """
        Set or remove the memory condenser.
        
        Args:
            value: The MemoryCondenser instance to use, or None to remove
        """
        self._condenser = value

    
    @abstractmethod
    def _needs_condensing(self) -> bool:
        """
        Check if memory condensing is needed based on current usage.
        
        This is an abstract method that must be implemented by subclasses
        with type-specific logic.
        
        Returns:
            True if condensing is needed, False otherwise
        """
        pass


    @abstractmethod
    def _calculate_preserve_count(self) -> int:
        """
        Calculate how many messages to preserve based on the preserve_percentage.
        
        This is an abstract method that must be implemented by subclasses
        with type-specific logic.
        
        Returns:
            Number of messages to preserve
        """
        pass
    

    def _identify_messages_to_condense(self) -> Dict[str, List[int]]:
        """
        Identify which messages to condense (older messages) and which to preserve (newer messages).
        This method ensures that tool call chains are kept together to preserve conversation coherence.
        
        Returns:
            A dictionary with keys 'to_condense' and 'to_preserve', each containing a list of message indices
        """
        # Calculate how many messages to preserve using the subclass-specific implementation
        preserve_count = self._calculate_preserve_count()
        
        # Get list of messages
        messages_list = list(self.messages)
        
        # Find system messages and non-system indices
        all_indices = set()
        system_indices = set()
        non_system_indices = set()
        
        for i, msg in enumerate(messages_list):
            all_indices.add(i)
            if self.is_system_message(msg):
                system_indices.add(i)
            else:
                non_system_indices.add(i)
        
        # Calculate which messages to preserve (newest non-system messages)
        sorted_non_system = sorted(non_system_indices)
        recent_non_system = set(sorted_non_system[-preserve_count:]) if preserve_count > 0 else set()
        
        # Add system message indices to preserve
        to_preserve_indices = system_indices.union(recent_non_system)
        
        # Initial calculation of which messages to condense
        initial_to_condense = all_indices - to_preserve_indices
        
        # Get tool call units to ensure they stay together
        tool_call_units = self._build_tool_call_units()
        
        # Process tool call units to ensure they stay together
        for assistant_idx, tool_response_indices in tool_call_units.items():
            # Combine all indices in this tool call unit
            unit_indices = {assistant_idx}.union(tool_response_indices)
            
            # Check if there's a conflict (some messages in unit marked for preservation, others for condensing)
            preserve_overlap = unit_indices.intersection(to_preserve_indices)
            condense_overlap = unit_indices.intersection(initial_to_condense)
            
            if preserve_overlap and condense_overlap:
                # There's a conflict - some messages in unit are marked for preservation, others for condensing
                # Prioritize preservation - keep the entire unit
                to_preserve_indices.update(unit_indices)
            elif condense_overlap and len(condense_overlap) == len(unit_indices):
                # All messages in unit are marked for condensing
                # Keep them all marked for condensing (no action needed)
                pass
            elif preserve_overlap and len(preserve_overlap) == len(unit_indices):
                # All messages in unit are already marked for preservation
                # Keep them all marked for preservation (no action needed)
                pass
        
        # Recalculate which messages to condense after resolving conflicts
        to_condense_indices = all_indices - to_preserve_indices
        
        return {
            'to_condense': list(to_condense_indices),
            'to_preserve': list(to_preserve_indices)
        }


    def _backup_memory_state(self) -> Dict[str, Any]:
        """
        Create a backup of the current memory state.
        
        Returns:
            Dictionary containing the backed up memory state
            
        Note:
            This creates deep copies of mutable objects to ensure the backup
            is not affected by subsequent changes to the original objects.
        """
        try:
            # Create a proper copy of the deque
            messages_copy = copy.deepcopy(self.messages)
            
            # Create a deep copy of the tool_call_map to handle nested mutable objects (sets)
            tool_call_map_copy = {}
            for key, value in self.tool_call_map.items():
                tool_call_map_copy[key] = set(value)  # Create a new set with the same elements
            
            # Deep copy the token count cache
            token_cache_copy = copy.deepcopy(self._token_count_cache)
            
            return {
                "messages": messages_copy,
                "token_count": self.token_count,
                "tool_call_map": tool_call_map_copy,
                "token_count_cache": token_cache_copy
            }
        except Exception as e:
            logger.error(f"Error creating memory backup: {e}")
            logger.warning("Resetting memory state due to backup failure")
            # Reset memory state
            self._reset_memory_state()
            
            # Return the reset state as the backup
            return {
                "messages": self.messages,
                "token_count": self.token_count,
                "tool_call_map": self.tool_call_map,
                "token_count_cache": self._token_count_cache
            }
    

    def _restore_memory_state(self, backup: Dict[str, Any]) -> None:
        """
        Restore the memory state from a backup.
        
        Args:
            backup: Dictionary containing the backed up memory state
        """
        try:
            # Validate that the backup contains all required keys
            required_keys = ["messages", "token_count", "tool_call_map", "token_count_cache"]
            for key in required_keys:
                if key not in backup:
                    raise KeyError(f"Backup is missing required key: {key}")
            
            # Restore state from backup
            self.messages = backup["messages"]
            self.token_count = backup["token_count"]
            self.tool_call_map = backup["tool_call_map"]
            self._token_count_cache = backup["token_count_cache"]
            
            logger.info("Memory state restored from backup")
            
        except Exception as e:
            logger.error(f"Error restoring memory state from backup: {e}")
            logger.warning("Resetting memory state due to restore failure")
            # Reset to a clean state if restoration fails
            self._reset_memory_state()
    

    def _reset_memory_state(self) -> None:
        """
        Reset the memory state to empty.
        """
        self.messages = deque()
        self.token_count = 0
        self.tool_call_map = {}
        self._token_count_cache = create_token_cache(maxsize=DEFAULT_CACHE_SIZE)
    

    def _replace_with_summary(self, to_condense_indices: list[int], summary_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Replace messages to condense with a summary.
        
        Args:
            to_condense_indices: Indices of messages to condense
            summary_result: Result from the condenser
            
        Returns:
            Metadata about the operation
        """
        # Initialize result dictionary with all expected keys
        replacement_result = {
            "result": {
                "error": False,
                "error_dsc": None
            },
            "metadata": {
                "messages_condensed": 0,
                "tokens_removed": 0,
                "tokens_added": 0,
                "net_token_change": 0,
                "skipped": False,
                "reason": None,
                "usage": None
            }
        }
        
        # Get list of messages
        original_messages = list(self.messages)
        original_count = len(original_messages)
        logger.info(f"Replacing {len(to_condense_indices)} messages with summary. Original message count: {original_count}")
        
        # Extract summary content and metadata
        summary_content = summary_result["message"]
        summary_metadata = summary_result["metadata"]
        
        # Calculate tokens to be removed for reporting purposes only
        tokens_to_remove = sum(self._estimate_tokens(original_messages[i]) for i in to_condense_indices)
        logger.info(f"Tokens to be removed: {tokens_to_remove}")
        
        # Create a summary prefix to indicate this is a condensed message
        summary_prefix = "[Summary of previous messages]\n\n"
        full_summary_content = summary_prefix + summary_content
        
        # Create a message dict for token estimation
        summary_message = {
            "role": MessageRole.ASSISTANT.value,
            "content": full_summary_content
        }
        tokens_to_add = self._estimate_tokens(summary_message)
        logger.info(f"Tokens to be added by summary: {tokens_to_add}")
        
        # Check if condensing would actually save tokens
        if tokens_to_add >= tokens_to_remove:
            logger.warning(f"The condensed messages would increase token usage from {tokens_to_remove} to {tokens_to_add} tokens. Skipping replacement.")
            replacement_result["metadata"]["skipped"] = True
            replacement_result["metadata"]["reason"] = "Summary would be larger than original messages"
            
            return replacement_result
        
        # Create a backup of the current memory state
        backup = self._backup_memory_state()
        
        # Reset the memory state
        self._reset_memory_state()
        
        # Add system messages first
        for msg in original_messages:
            if self.is_system_message(msg):
                self.store(msg)
        
        # Add the summary as an assistant message
        self.add_assistant_message(full_summary_content)
        
        # Add remaining messages (those not in to_condense_indices)
        for i, msg in enumerate(original_messages):
            if i not in to_condense_indices and not self.is_system_message(msg):
                self.store(msg)
        
        # Log the final message count
        final_count = len(self.messages)
        logger.info(f"Replacement complete. New message count: {final_count} (was {original_count})")
        
        try:
            # If something went wrong, restore the backup
            if final_count == 0:
                self._restore_memory_state(backup)
                replacement_result["result"]["error"] = True
                replacement_result["result"]["error_dsc"] = "Memory state was empty after replacement"
                return replacement_result
        
        except Exception as e:
            # Restore backup on error
            self._restore_memory_state(backup)
            logger.error(f"Something went wrong while replacing with summary: {e}")
            replacement_result["result"]["error"] = True
            replacement_result["result"]["error_dsc"] = f"Error: {str(e)}"
            return replacement_result
        
        # Update metadata with operation details
        replacement_result["metadata"]["messages_condensed"] = len(to_condense_indices)
        replacement_result["metadata"]["tokens_removed"] = tokens_to_remove
        replacement_result["metadata"]["tokens_added"] = tokens_to_add
        replacement_result["metadata"]["net_token_change"] = tokens_to_add - tokens_to_remove
        
        # Add usage metadata if available
        if summary_metadata.get("usage"):
            replacement_result["metadata"]["usage"] = summary_metadata.get("usage")
        
        return replacement_result


    def check_and_condense(self, force: bool = False, metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Check if condensing is needed and perform it if necessary.
        
        This method checks if the memory is approaching capacity and, if so,
        condenses older messages into a summary to free up space.
        
        Args:
            force: If True, bypass threshold checks and force condensation.
            metadata: Optional metadata dictionary to pass to the LLM during condensing.
        
        Returns:
            A dictionary containing metadata about the condensing operation
            with a consistent structure in all cases
        """
        # Initialize a normalized result dictionary with all expected keys
        result = {
            "result": {
                "error": False,
                "error_dsc": None,
            },
            "metadata": {
                "messages_condensed": 0,
                "tokens_removed": 0,
                "tokens_added": 0,
                "net_token_change": 0,
                "skipped": False,
                "reason": None,
                "usage": None
            }
        }
        
        # If no condenser is set, return the base result
        if self._condenser is None:
            result["metadata"]["skipped"] = True
            result["metadata"]["reason"] = "No condenser configured"
            return result
            
        try:
            if not force and not self._needs_condensing():
                result["metadata"]["skipped"] = True
                result["metadata"]["reason"] = "Condensing not needed based on current memory usage"
                return result
                
            # Notify the user that condensing is starting
            current_token_percentage = self.token_count / self.capacity if hasattr(self, 'capacity') else 0
            logger.info(f"Starting memory condensing... Current token count: {self.token_count} ({current_token_percentage:.1%} of capacity)")
            if "on_memory_condensing_start" in self._condenser.callbacks:
                self._condenser.callbacks["on_memory_condensing_start"]("Condensing older messages to save memory space")
                
            # Identify which messages to condense and which to preserve
            message_indices = self._identify_messages_to_condense()
            to_condense_indices = message_indices['to_condense']
            to_preserve_indices = message_indices['to_preserve']
            
            logger.info(f"Memory condensing: {len(to_condense_indices)} messages to condense, {len(to_preserve_indices)} messages to preserve")
            
            # If there are no messages to condense, return
            if not to_condense_indices:
                logger.info("No messages to condense")
                result["metadata"]["skipped"] = True
                result["metadata"]["reason"] = "No messages eligible for condensing"

                if "on_memory_condensing_end" in self._condenser.callbacks:
                    self._condenser.callbacks["on_memory_condensing_end"](result)
                
                return result
                
            # Get the messages to condense
            messages_list = list(self.messages)
            to_condense_messages = [messages_list[i] for i in sorted(to_condense_indices)]
            
            # Check if condensing would be efficient
            should_condense_occur = self._should_condense(to_condense_messages, to_condense_indices)
            if not should_condense_occur["veredict"]:
                logger.warning(f"Skipping condensing: {should_condense_occur['reason']}")
                
                # Update result with skip information
                result["metadata"]["skipped"] = True
                result["metadata"]["reason"] = should_condense_occur["reason"]
                
                # Call the end callback with the skipped result
                if "on_memory_condensing_end" in self._condenser.callbacks:
                    self._condenser.callbacks["on_memory_condensing_end"](result)
                    
                return result
            
            # Generate a summary for the messages to condense
            logger.info(f"Generating summary for {len(to_condense_messages)} messages...")
            # Pass the same metadata dictionary that was received by check_and_condense
            summary_result = self._condenser.generate_summary(to_condense_messages, metadata=metadata)
            
            # If summary generation failed, return
            if summary_result is None:
                logger.warning("Failed to generate summary")
                result["result"]["error"] = True
                result["result"]["error_dsc"] = "Failed to generate summary"

                if "on_memory_condensing_end" in self._condenser.callbacks:
                    self._condenser.callbacks["on_memory_condensing_end"](result)

                return result
                
            logger.success(f"Summary generated successfully!")
                
            # Replace the messages to condense with the summary
            replacement_result = self._replace_with_summary(to_condense_indices, summary_result)
            
            # Update our result with the replacement result data
            result["result"]["error"] = replacement_result["result"]["error"]
            result["result"]["error_dsc"] = replacement_result["result"]["error_dsc"]
            result["metadata"] = replacement_result["metadata"]
            
            if not result["result"]["error"]:
                logger.info(
                    f"Memory condensing complete. Condensed {result['metadata']['messages_condensed']} messages, "
                    f"removed {result['metadata']['tokens_removed']} tokens, added {result['metadata']['tokens_added']} tokens, "
                    f"net change: {result['metadata']['net_token_change']} tokens."
                )
                
                # Log the new token count and percentage
                new_token_percentage = self.token_count / self.capacity if hasattr(self, 'capacity') else 0
                logger.info(f"New token count after condensing: {self.token_count} ({new_token_percentage:.1%} of capacity)")
                
                # Trigger condensation callback if registered
                if self._condensation_callback:
                    try:
                        self._condensation_callback()
                    except Exception as e:
                        logger.error(f"Error executing condensation callback: {e}")
            else:
                # Log error information
                logger.error(f"Memory condensing failed: {result['result']['error_dsc']}")
            
            # Always call the callback, which can handle both success and error cases
            if "on_memory_condensing_end" in self._condenser.callbacks:
                self._condenser.callbacks["on_memory_condensing_end"](result)
                
            return result
            
        except Exception as e:
            logger.error(f"Error in memory condensing: {e}")
            # Return error information
            result["result"]["error"] = True
            result["result"]["error_dsc"] = f"Exception during condensing: {str(e)}"

            if "on_memory_condensing_end" in self._condenser.callbacks:
                    self._condenser.callbacks["on_memory_condensing_end"](result)

            return result


    def _should_condense(self, to_condense_messages: List[Dict[str, Any]], to_condense_indices: List[int]) -> Dict[str, Any]:
        """
        Check if condensing would be efficient based on various heuristics.
        
        Uses a flexible approach that considers both message count and token count:
        - Either sufficient messages OR sufficient tokens can trigger condensing
        - For fewer messages, we require more tokens per message
        
        Args:
            to_condense_messages: List of messages to condense
            to_condense_indices: Indices of messages to condense
            
        Returns:
            Dictionary with:
            - veredict: Boolean indicating if condensing should proceed
            - reason: String explaining why condensing was skipped (if applicable)
            - tokens_to_remove: Number of tokens that would be removed (if calculated)
        """
        # Initialize result with default values
        result = {
            "veredict": True,
            "reason": "",
            "tokens_to_remove": 0
        }
        
        # Calculate tokens to be removed
        messages_list = list(self.messages)
        tokens_to_remove = sum(self._estimate_tokens(messages_list[i]) for i in to_condense_indices)
        result["tokens_to_remove"] = tokens_to_remove
        
        # Get message count
        message_count = len(to_condense_messages)
        
        # Use a more flexible approach with OR condition
        if message_count >= MEMORY_MIN_MESSAGES_TO_CONDENSE or tokens_to_remove >= MEMORY_MIN_TOKENS_TO_CONDENSE:
            # If we have enough messages or enough tokens, condense
            return result
        else:
            # Not enough messages AND not enough tokens
            result["veredict"] = False
            result["reason"] = f"Too few messages ({message_count}) and tokens ({tokens_to_remove}) to condense efficiently"
            return result


    def add_user_message(self, message: str, files: List[str] = None) -> None:
        """
        Add a user message to memory.
        
        Args:
            message: The user's message text
            files: Optional list of file paths relevant to the message
        """
        msg = build_input_message(MessageRole.USER, message)
        if files:
            msg["files"] = files
        self.store(msg)
    

    def add_assistant_message(self, message: Optional[str] = None, tool_calls: Optional[List[Dict[str, Any]]] = None) -> None:
        """
        Add an assistant message to memory, with optional tool calls.
        
        Args:
            message: The assistant's response text (optional if tool_calls is provided)
            tool_calls: Optional tool calls made by the assistant
        """
        # Store assistant message text (if any) as an input message item.
        if message is None and not tool_calls:
            message = "Agent provided no content."
        if message:
            msg = build_input_message(MessageRole.ASSISTANT, message)
            self.store(msg)

        # Store tool calls as separate function_call items to keep tool history structured.
        if tool_calls:
            for tool_call in tool_calls:
                arguments = tool_call.get("tool_args", {})
                arguments_str = json.dumps(arguments, ensure_ascii=False)
                item = build_function_call(
                    call_id=tool_call.get("tool_id"),
                    name=tool_call.get("tool_name"),
                    arguments=arguments_str,
                )
                self.store(item)
    

    def add_tool_message(self, tool_call: Dict[str, Any], tool_response: Any) -> None:
        """
        Add a tool response message to memory.
        
        Args:
            tool_call: A dictionary containing the tool call information,
                   including 'tool_call_id', 'name', and 'content'
        """
        response = copy.deepcopy(tool_response)
        for key in ["usage", "_usage"]:
            if key in response and is_completion_usage(response[key]):
                response[key] = response[key].to_dict(mode="json")
            elif key in response and hasattr(response[key], "model_dump"):
                response[key] = response[key].model_dump()

        msg = build_function_call_output(
            call_id=tool_call.get("tool_id"),
            output=response,
        )
        # Preserve tool name for logging/debugging if present
        if tool_call.get("tool_name"):
            msg["name"] = tool_call.get("tool_name")
        self.store(msg)


    def add_reasoning_items(self, reasoning_items: List[Dict[str, Any]]) -> None:
        """
        Add reasoning items to memory in canonical Responses-item format.

        Args:
            reasoning_items: List of reasoning item dictionaries extracted from
                model output.
        """
        for item in reasoning_items:
            if not isinstance(item, dict):
                continue

            summary = item.get("summary")
            normalized_summary: List[Dict[str, Any]] = []
            if isinstance(summary, list):
                for block in summary:
                    if not isinstance(block, dict):
                        continue
                    if block.get("type") != ItemType.SUMMARY_TEXT:
                        continue
                    normalized_summary.append({
                        "type": ItemType.SUMMARY_TEXT,
                        "text": block.get("text"),
                    })

            reasoning_item: Dict[str, Any] = {
                "type": ItemType.REASONING,
                "id": item.get("id"),
                "summary": normalized_summary,
            }

            encrypted_content = item.get("encrypted_content")
            if isinstance(encrypted_content, str) and encrypted_content:
                reasoning_item["encrypted_content"] = encrypted_content

            # Persist only items with meaningful reasoning payload.
            if not reasoning_item.get("summary") and not reasoning_item.get("encrypted_content"):
                continue
            if not isinstance(reasoning_item.get("id"), str) or not reasoning_item.get("id"):
                continue

            self.store(reasoning_item)

    def add_unknown_items(self, unknown_items: List[Dict[str, Any]]) -> None:
        """
        Add unknown provider output items to memory in canonical wrapper format.

        Args:
            unknown_items: List of unknown item dictionaries extracted from model output.
        """
        for item in unknown_items:
            if not isinstance(item, dict):
                continue

            raw = item.get("raw")
            if not isinstance(raw, dict) or not raw:
                continue

            unknown_item: Dict[str, Any] = {
                "type": ItemType.UNKNOWN,
                "raw": copy.deepcopy(raw),
            }

            original_type = item.get("original_type")
            if isinstance(original_type, str) and original_type:
                unknown_item["original_type"] = original_type

            self.store(unknown_item)


    def _update_tool_call_mapping(self, message: Dict[str, Any], index: int) -> None:
        """
        Update the mapping between tool call IDs and message indices.
        
        Args:
            message: The message to process
            index: The index of the message in the messages deque
        """
        msg_type = message.get("type")

        # Responses-style tool calls
        if msg_type in {ItemType.FUNCTION_CALL, ItemType.FUNCTION_TOOL_CALL}:
            tool_id = message.get("call_id")
            if tool_id:
                self.tool_call_map.setdefault(tool_id, set()).add(index)

        # Responses-style tool outputs
        if msg_type in {ItemType.FUNCTION_CALL_OUTPUT, ItemType.FUNCTION_TOOL_CALL_OUTPUT}:
            tool_id = message.get("call_id")
            if tool_id:
                self.tool_call_map.setdefault(tool_id, set()).add(index)

        # Legacy assistant messages with tool calls
        if message.get("role") == MessageRole.ASSISTANT.value and "tool_calls" in message:
            for tool_call in message.get("tool_calls", []):
                tool_id = tool_call.get("id")
                if tool_id:
                    self.tool_call_map.setdefault(tool_id, set()).add(index)

        # Legacy tool messages
        if message.get("role") == MessageRole.TOOL.value and "tool_call_id" in message:
            tool_id = message.get("tool_call_id")
            if tool_id:
                self.tool_call_map.setdefault(tool_id, set()).add(index)
    
    def _rebuild_tool_call_map(self) -> None:
        """Rebuild the tool call map from scratch based on current messages."""
        self.tool_call_map = {}
        
        for i, msg in enumerate(self.messages):
            msg_type = msg.get("type")

            if msg_type in {ItemType.FUNCTION_CALL, ItemType.FUNCTION_TOOL_CALL}:
                tool_id = msg.get("call_id")
                if tool_id:
                    self.tool_call_map.setdefault(tool_id, set()).add(i)

            if msg_type in {ItemType.FUNCTION_CALL_OUTPUT, ItemType.FUNCTION_TOOL_CALL_OUTPUT}:
                tool_id = msg.get("call_id")
                if tool_id:
                    self.tool_call_map.setdefault(tool_id, set()).add(i)

            # Legacy assistant message with tool calls
            if msg.get("role") == MessageRole.ASSISTANT.value and "tool_calls" in msg:
                for tool_call in msg.get("tool_calls", []):
                    tool_id = tool_call.get("id")
                    if tool_id:
                        self.tool_call_map.setdefault(tool_id, set()).add(i)

            # Legacy tool message
            if msg.get("role") == MessageRole.TOOL.value and "tool_call_id" in msg:
                tool_id = msg.get("tool_call_id")
                if tool_id:
                    self.tool_call_map.setdefault(tool_id, set()).add(i)


    def _build_tool_call_units(self) -> Dict[int, Set[int]]:
        """
        Build tool call units efficiently from the current messages.
        
        A tool call unit consists of an assistant message with tool calls and
        its corresponding tool response messages. This method identifies these
        relationships to ensure they stay together when removing messages.
        
        Returns:
            Dictionary mapping assistant message indices to sets of related tool response indices
        """
        # Pre-allocate dictionaries to avoid resizing
        assistant_to_tool_responses = {}
        tool_id_to_assistant_idx = {}
        
        # Single pass through messages to build all relationships
        for i, msg in enumerate(self.messages):
            msg_type = msg.get("type")

            # Responses-style function call
            if msg_type in {ItemType.FUNCTION_CALL, ItemType.FUNCTION_TOOL_CALL}:
                tool_id = msg.get("call_id")
                if tool_id:
                    assistant_to_tool_responses[i] = set()
                    tool_id_to_assistant_idx[tool_id] = i
                continue

            # Legacy assistant messages with tool calls
            if msg.get("role") == MessageRole.ASSISTANT.value and "tool_calls" in msg:
                tool_calls = msg.get("tool_calls", [])
                if tool_calls:
                    assistant_to_tool_responses[i] = set()
                    for tool_call in tool_calls:
                        tool_id = tool_call.get("id")
                        if tool_id:
                            tool_id_to_assistant_idx[tool_id] = i
                continue

            # Responses-style tool output
            if msg_type in {ItemType.FUNCTION_CALL_OUTPUT, ItemType.FUNCTION_TOOL_CALL_OUTPUT}:
                tool_id = msg.get("call_id")
                if tool_id and tool_id in tool_id_to_assistant_idx:
                    assistant_idx = tool_id_to_assistant_idx[tool_id]
                    assistant_to_tool_responses.setdefault(assistant_idx, set()).add(i)
                continue

            # Legacy tool message
            if msg.get("role") == MessageRole.TOOL.value and "tool_call_id" in msg:
                tool_id = msg.get("tool_call_id")
                if tool_id and tool_id in tool_id_to_assistant_idx:
                    assistant_idx = tool_id_to_assistant_idx[tool_id]
                    assistant_to_tool_responses.setdefault(assistant_idx, set()).add(i)
        
        return assistant_to_tool_responses


    def _remove_messages_safely(self, indices_to_remove: Set[int]) -> List[Dict[str, Any]]:
        """
        Remove messages by indices while preserving tool call units and the system message.
        
        If an assistant message with tool calls is in the indices to remove,
        this method will ensure all its tool responses are also removed.
        If a tool response is in the indices to remove, this method will ensure
        its parent assistant message is also removed.
        The system message (if present) is always preserved.
        
        Args:
            indices_to_remove: Set of message indices to remove
            
        Returns:
            List of removed messages
        """
        # Get tool call units efficiently
        assistant_to_tool_responses = self._build_tool_call_units()
        
        # Expand indices_to_remove to include complete tool call units
        expanded_indices = set(indices_to_remove)
        
        # If an assistant message is being removed, add all its tool responses
        for assistant_idx in indices_to_remove:
            if assistant_idx in assistant_to_tool_responses:
                expanded_indices.update(assistant_to_tool_responses[assistant_idx])
        
        # If a tool response is being removed, add its parent assistant message and all siblings
        for assistant_idx, tool_indices in assistant_to_tool_responses.items():
            if any(tool_idx in indices_to_remove for tool_idx in tool_indices):
                expanded_indices.add(assistant_idx)
                expanded_indices.update(tool_indices)
        
        # Get the messages to be removed (avoiding list comprehension for large lists)
        messages = list(self.messages)
        removed_messages = []
        
        # Preserve system message if it would be removed
        system_message = None
        system_message_index = None
        for i in expanded_indices:
            if i < len(messages) and self.is_system_message(messages[i]):
                system_message = messages[i]
                system_message_index = i
                break
        
        # Remove system message index from expanded_indices outside the loop
        if system_message_index is not None:
            expanded_indices.remove(system_message_index)
        
        # Also remove entries from token count cache
        for i in expanded_indices:
            if i < len(messages):
                msg = messages[i]
                removed_messages.append(msg)
                
                # Remove this message from the token count cache if it exists
                if hasattr(self, '_token_count_cache'):
                    cache_key = get_message_cache_key(msg)
                    if cache_key in self._token_count_cache:
                        del self._token_count_cache[cache_key]
        
        # Create a new message list without these messages
        # Use a more efficient approach for large message lists
        if len(expanded_indices) > len(messages) / 2:
            # If removing more than half the messages, build a new list of messages to keep
            keep_indices = set(range(len(messages))) - expanded_indices
            self.messages = deque(
                [messages[i] for i in sorted(keep_indices)]
            )
        else:
            # Otherwise, filter out the messages to remove
            self.messages = deque(
                [msg for i, msg in enumerate(messages) if i not in expanded_indices]
            )
        
        # Re-add system message if it was removed and there's no system message in the remaining messages
        if system_message is not None and not any(self.is_system_message(msg) for msg in self.messages):
            self.upsert_system_message(system_message["content"])
        
        return removed_messages


    def _get_next_removable_items(self, count: int = 1) -> List[Dict[str, Any]]:
        """
        Get the next set of removable items, preserving tool call units and system messages.
        
        This method returns individual messages and complete tool call units,
        prioritizing oldest messages first. System messages are never included in the
        returned items.
        
        Args:
            count: Number of items to return
            
        Returns:
            List of dictionaries with:
            - 'indices': Set of message indices in this item
            - 'messages': List of messages in this item
            - 'is_tool_call_unit': Boolean indicating if this is a tool call unit
        """
        # Get tool call units
        assistant_to_tool_responses = self._build_tool_call_units()
        
        # Flatten the tool call units for quick lookups
        tool_call_unit_indices = set()
        for assistant_idx, tool_indices in assistant_to_tool_responses.items():
            tool_call_unit_indices.add(assistant_idx)
            tool_call_unit_indices.update(tool_indices)
        
        # Build removable items efficiently
        items = []
        messages = list(self.messages)
        
        # First, build tool call units
        for assistant_idx, tool_indices in assistant_to_tool_responses.items():
            unit_messages = [messages[assistant_idx]]
            unit_indices = {assistant_idx}
            
            for tool_idx in tool_indices:
                if tool_idx < len(messages):
                    unit_messages.append(messages[tool_idx])
                    unit_indices.add(tool_idx)
            
            # Skip this unit if it contains a system message
            if any(self.is_system_message(msg) for msg in unit_messages):
                continue
                
            items.append({
                'indices': unit_indices,
                'messages': unit_messages,
                'is_tool_call_unit': True,
                'start_idx': assistant_idx  # For sorting
            })
        
        # Then, build individual items for all other messages
        # This is more efficient than checking each message individually
        for i, msg in enumerate(messages):
            if i not in tool_call_unit_indices:
                # Skip system messages
                if self.is_system_message(msg):
                    continue
                    
                items.append({
                    'indices': {i},
                    'messages': [msg],
                    'is_tool_call_unit': False,
                    'start_idx': i  # For sorting
                })
        
        # Sort by start index (oldest first)
        # Using key function is faster than lambda for large lists
        items.sort(key=lambda item: item.get('start_idx', float('inf')))
        
        # Return only the requested number of items
        return items[:count]
