from typing import Optional
from dataclasses import dataclass

from tiktoken.core import Encoding


@dataclass
class MemoryMigrationContext:
    """
    Data class used to manage memory migration parameters shared across all memories.

    Attributes:
        context_window (int): The context window size of the new model. Shared across all memories.
        encoding (Optional[Encoding]): The tiktoken encoding instance for the new model. Shared across all memories.
    """
    context_window: int
    encoding: Optional[Encoding] = None
