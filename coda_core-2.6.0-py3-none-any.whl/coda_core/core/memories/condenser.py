from typing import Any, Callable, Dict, List, Optional
from loguru import logger

from coda_core.config.settings import SETTINGS
from coda_core.core.memories.constants import MEMORY_DEFAULT_PRESERVE_RECENT_PERCENTAGE
from coda_core.config.env_config import EnvConfig
from coda_core.core.models.providers.geai_client_manager import GEAIClientManager
from coda_core.core.models.providers.geai_config import GEAIConfig
from coda_core.core.models.providers.geai_client import GEAIClient
from coda_core.core.utils.prompt_management import load_prompt
from coda_core.core.models.llms.chat import ChatLLM
from coda_core.core.models.utils import extract_response_text

class MemoryCondenser:
    # Define constants within the class
    MEMORY_CONDENSING_PROMPT_TEMPLATE = "summarization_prompt.hbs"
    """
    A class that provides memory condensing capabilities.
    
    This class is focused solely on generating summaries from a set of messages.
    It doesn't handle memory state management or modification.
    """
    
    def __init__(
        self,
        threshold: float,
        llm: Optional[ChatLLM] = None,
        preserve_percentage: float = None,
        callbacks: Optional[Dict[str, Callable]] = None
    ):
        """
        Initialize the MemoryCondenser.
        
        Args:
            llm: LLM to use for summarization (optional)
                 If not provided, a new LLM will be created using environment variables
            threshold: Threshold percentage that triggers summarization
                       When memory reaches this percentage of capacity, condensing is triggered.
            preserve_percentage: Percentage of most recent messages to preserve (default: 0.3)
                                When condensing is triggered, this percentage of the most recent
                                messages will be preserved, while older messages will be condensed.
           callbacks: Dictionary of callback functions for different events (optional)
               Supported callbacks:
               - on_memory_condensing_start(message): Called when condensing process starts
               - on_memory_condensing_end(result): Called when condensing process completes or is skipped
                 The result parameter contains metadata with LLM usage, condensing statistics,
                 and a "skipped" flag with reason if condensing was skipped
                
        Raises:
            ValueError: If threshold or preserve_percentage are invalid
        """
        # Store the LLM - will be created lazily if not provided
        self.llm = llm
        self._geai_client = None
             
        # Set threshold
        self.threshold = threshold

        # Set preserve_percentage, defaulting to MEMORY_DEFAULT_PRESERVE_RECENT_PERCENTAGE if not provided
        if preserve_percentage is None:
            # Use default preserve percentage, but ensure it's always less than threshold
            self.preserve_percentage = min(MEMORY_DEFAULT_PRESERVE_RECENT_PERCENTAGE, threshold * 0.8)
        else:
            # If explicitly provided, ensure it's less than threshold
            self.preserve_percentage = min(preserve_percentage, threshold * 0.8)
            
        # If preserve_percentage was adjusted, log a message
        if (preserve_percentage is None and self.preserve_percentage != MEMORY_DEFAULT_PRESERVE_RECENT_PERCENTAGE) or \
           (preserve_percentage is not None and self.preserve_percentage != preserve_percentage):
            logger.info(
                f"Adjusted preserve_percentage to {self.preserve_percentage:.2f} "
                f"to ensure it's less than threshold {threshold:.2f}"
            )
            
        # Validate threshold and preserve_percentage
        self._validate_parameters()
            
        # Initialize callbacks dictionary
        self.callbacks = callbacks or {}
        
        logger.info(
            f"MemoryCondenser initialized with threshold={self.threshold}, "
            f"preserve_percentage={self.preserve_percentage}"
        )
    
    def set_geai_client(self, geai_client: GEAIClient) -> None:
        """
        Set the GEAI client for lazy LLM creation.
        
        This allows the condenser to use the current session's credentials instead of
        trying to create credentials from environment variables or cached credentials.
        
        Args:
            geai_client: The GEAIClient instance from the current session
        """
        self._geai_client = geai_client
        if self.llm is not None:
            logger.debug("geai_client set, but LLM already initialized")

    def _get_or_create_llm(self) -> Optional[ChatLLM]:
        """
        Get the LLM, creating it lazily if needed using current session credentials.
        
        Returns:
            ChatLLM instance or None if creation fails
        """
        if self.llm is not None:
            return self.llm

        try:
            provider = SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_LLM_PROVIDER)
            model = SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_LLM_MODEL)
            system_prompt = load_prompt(template_name=self.MEMORY_CONDENSING_PROMPT_TEMPLATE)
        except Exception as e:
            logger.error(f"Failed to load environment variables and prompt for memory condensing LLM: {e}")
            return None

        try:
            if self._geai_client is not None:
                client = self._geai_client
            else:
                geai_config = GEAIConfig.from_env()
                client = GEAIClientManager.get_client(geai_config)
            
            self.llm = ChatLLM(
                client=client,
                provider_name=provider,
                model_name=model,
                system_prompt=system_prompt
            )
            logger.info(f"Created LLM for memory condensing: provider={provider}, model={model}")
            return self.llm
            
        except ValueError as e:
            logger.warning(f"Memory condensing LLM initialization failed - authentication not available: {e}")
            logger.info("Memory condensing will be disabled. Please authenticate to enable this feature.")
            return None
        except Exception as e:
            logger.error(f"Unexpected error initializing memory condensing LLM: {e}")
            logger.info("Memory condensing will be disabled. Please check your configuration.")
            return None

    def _create_default_llm(self) -> Optional[ChatLLM]:
        """
        Create a default LLM for summarization using environment variables.
        
        Returns:
            ChatLLM: A configured ChatLLM instance for summarization, or None if credentials are unavailable
            
        Note:
            If authentication credentials are not available, this method returns None and logs a warning.
            Memory condensing will be disabled in this case.
        """
        try:
            provider = SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_LLM_PROVIDER)
            model = SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_LLM_MODEL)

            # Load the prompt template to use as system prompt
            system_prompt = load_prompt(template_name=self.MEMORY_CONDENSING_PROMPT_TEMPLATE)

            # Create GEAI config from environment variables
            geai_config = GEAIConfig.from_env()

            # Retrieve GEAI client
            client = GEAIClientManager.get_client(geai_config)

            # Create the LLM with the system prompt
            llm = ChatLLM(
                client=client,
                provider_name=provider,
                model_name=model,
                system_prompt=system_prompt
            )

            logger.info(f"Created LLM for memory condensing: provider={provider}, model={model}")
            return llm

        except ValueError as e:
            # Authentication credentials not available
            logger.warning(f"Memory condensing LLM initialization failed - authentication not available: {e}")
            logger.info("Memory condensing will be disabled. Please authenticate to enable this feature.")
            return None
        except Exception as e:
            # Handle any other unexpected errors
            logger.error(f"Unexpected error initializing memory condensing LLM: {e}")
            logger.info("Memory condensing will be disabled. Please check your configuration.")
            return None


    def _validate_parameters(self) -> None:
        """
        Validate the threshold and preserve_percentage parameters.
        
        Raises:
            ValueError: If parameters are invalid
        """
        # Ensure threshold is between 0 and 1
        if not 0 < self.threshold < 1:
            raise ValueError(f"Invalid threshold {self.threshold}, must be between 0 and 1")
            
        # Ensure preserve_percentage is between 0 and 1
        if not 0 < self.preserve_percentage < 1:
            raise ValueError(f"Invalid preserve_percentage {self.preserve_percentage}, must be between 0 and 1")
            
        # Ensure preserve_percentage is less than threshold
        if self.preserve_percentage >= self.threshold:
            raise ValueError(
                f"preserve_percentage ({self.preserve_percentage}) must be less than threshold ({self.threshold})"
            )


    def _flatten_conversation(self, messages: List[Dict[str, Any]]) -> str:
        """
        Convert a list of message dictionaries into a flattened conversation text.
        
        This method handles various message formats and provides a consistent
        text representation of the conversation for summarization.
        
        Args:
            messages: List of message dictionaries to flatten
            
        Returns:
            str: A string representation of the conversation
        """
        if not messages:
            logger.warning("No messages provided. Cannot flatten conversation.")
            return ""
            
        conversation_parts = []
        
        for i, msg in enumerate(messages):
            try:
                # Validate message has required fields
                if not isinstance(msg, dict):
                    logger.warning(f"Skipping message {i}: not a dictionary")
                    continue
                    
                role = msg.get("role")
                if not role and msg.get("type") == "message":
                    role = msg.get("role")
                if not role:
                    logger.warning(f"Skipping message {i}: missing role")
                    continue
                
                # Handle different content formats
                content = msg.get("content", "")
                
                # Handle None content
                if content is None:
                    content = ""
                # Handle multi-modal content (list of content blocks)
                elif isinstance(content, list):
                    text_parts = []
                    for item in content:
                        if isinstance(item, dict):
                            if item.get("type") in {"text", "input_text", "output_text"}:
                                text_parts.append(item.get("text", ""))
                            elif item.get("type") == "refusal":
                                text_parts.append(item.get("refusal", ""))
                    content = " ".join(text_parts)
                # Handle non-string content
                elif not isinstance(content, str):
                    content = str(content)
                
                # Add formatted message to conversation
                conversation_parts.append(f"{role}: {content}")
                
            except Exception as e:
                logger.warning(f"Error processing message {i}: {e}")
                continue
                
        # Join all parts with double newlines for readability
        return "\n".join(conversation_parts)


    def generate_summary(self, messages: List[Dict[str, Any]], metadata: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Generate a summary of the provided messages using the LLM.
        
        This is the core functionality of the MemoryCondenser.
        
        Args:
            messages: List of messages to summarize
            metadata: Optional metadata dictionary to pass to the LLM during summarization.
            
         Returns:
             Optional[Dict[str, Any]]: A dictionary containing:
             - 'message': The summary message to add to memory
             - 'metadata': Metadata including usage/cost information
         Or None if summarization failed or LLM is not available
         """
        llm = self._get_or_create_llm()
        if llm is None:
            logger.warning("LLM not available for memory condensing. Skipping summarization.")
            return None
        
        try:
            # Flatten the conversation into a single text string
            conversation_text = self._flatten_conversation(messages)
            
            # Create a single user message with the entire conversation
            rendered_messages = [
               {"role": "user", "content": f"Here is the conversation to summarize:\n\n{conversation_text}"}
            ]
            
            # Generate the summary - the system prompt is already set in the LLM.
            # Pack metadata only when metadata forwarding is enabled.
            kwargs = {}
            if metadata and SETTINGS.get_env_var(EnvConfig.CODA_SEND_METADATA).lower() == 'true':
                kwargs['metadata'] = metadata

            llm_response = self.llm.generate_response(rendered_messages, **kwargs)

            summary_content = extract_response_text(llm_response) or ""

            # Extract usage information
            usage = getattr(llm_response, "usage", None)
            
            # Create metadata
            metadata = {
               "usage": usage
            }
            
            # Return the summary and metadata
            return {
               "message": summary_content,
               "metadata": metadata
            }
            
        except Exception as e:
            logger.error(f"Error generating summary: {e}")
            return None


    def to_dict(self) -> Dict[str, Any]:
        """Serialize the condenser to a dictionary for persistence."""
        return {
            "threshold": self.threshold,
            "preserve_percentage": self.preserve_percentage,
            "llm_provider": getattr(self.llm, "provider_name", None),
            "llm_model": getattr(self.llm, "model_name", None),
        }
    

    @classmethod
    def from_dict(cls, data: Dict[str, Any], llm: Optional[ChatLLM] = None) -> 'MemoryCondenser':
        """Create a MemoryCondenser instance from a dictionary."""
        # Get default values from environment variables
        default_threshold = float(SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_THRESHOLD))
        default_preserve_percentage = MEMORY_DEFAULT_PRESERVE_RECENT_PERCENTAGE
        
        # If LLM is not provided, it will be created in __init__
        return cls(
            llm=llm,
            threshold=data.get("threshold", default_threshold),
            preserve_percentage=data.get("preserve_percentage", default_preserve_percentage),
            callbacks=None  # Callbacks need to be re-attached separately
        )
