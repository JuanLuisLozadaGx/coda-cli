# Memory Module

## Overview

The Memory module provides a flexible and efficient way to store, retrieve, and manage conversation history in the CODA Core application. It offers different implementations to handle various memory constraints and requirements, allowing the application to:

- Store conversation messages with different roles (user, assistant, tool)
- Manage memory constraints based on message count or token count
- Maintain conversation coherence when removing older messages
- Track relationships between tool calls and their responses
- Serialize and deserialize memory for persistence
- Accurately count tokens with optimized methods and caching

## Architecture

The memory module is designed with a modular architecture that promotes extensibility while providing specialized implementations for different use cases:

```mermaid
classDiagram
    class Memory {
        <<abstract>>
        +messages: deque
        +tool_call_map: Dict
        +_token_count_cache: LRUCache
        +_encoding: Optional[Encoding]
        +_condenser: Optional[MemoryCondenser]
        +store(message): void
        +retrieve(query): List
        +clear(): void
        +pre_flight_memory_check(message): MemoryAssessment
        +force_memory_reduction(percentage): Dict
        +resolve_orphaned_tool_calls(error): int
        +to_dict(): Dict
        +from_dict(data): Memory
        -_initialize_from_dict(memory, data): Memory
        +add_user_message(message, files): void
        +add_assistant_message(message, tool_calls): void
        +add_tool_message(tool_call, tool_response): void
        -_estimate_tokens(message): int
        -_update_tool_call_mapping(message, index): void
        -_rebuild_tool_call_map(): void
        -_build_tool_call_units(): Dict
        -_remove_messages_safely(indices_to_remove): List
        -_get_next_removable_items(count): List
        +check_and_condense(): Dict
        -_needs_condensing(): bool
        -_calculate_preserve_count(): int
        -_identify_messages_to_condense(): Dict
        -_should_condense(): Dict
        -_replace_with_summary(): Dict
    }
    
    class MemoryCondenser {
        +threshold: float
        +preserve_percentage: float
        +llm: ChatLLM
        +callbacks: Dict
        +generate_summary(messages): Dict
        +to_dict(): Dict
        +from_dict(data): MemoryCondenser
    }
    
    Memory --> MemoryCondenser
    
    class TokenLimitedMemory {
        +capacity: int
        +char_to_token_ratio: int
        +token_count: int
        +target_tokens: int
        +store(message): void
        +retrieve(query): List
        +clear(): void
        +pre_flight_memory_check(message): MemoryAssessment
        +force_memory_reduction(percentage): Dict
        -_plan_eviction(tokens_needed): Tuple
        -_execute_eviction_plan(plan, tokens): int
        -_store_message_directly(message, tokens): void
    }
    
    class MemoryAssessment {
        +can_store: bool
        +action: AssessmentAction
        +message_tokens: int
        +current_tokens: int
        +capacity_limit: int
        +tokens_to_free: int
        +removable_tokens: int
        +reason_if_failed: str
    }
    
    class MemoryCapacityError {
        +assessment: MemoryAssessment
        +category: ErrorCategory
        +action: ErrorAction
        +severity: ErrorSeverity
        +to_dict(): Dict
    }
    
    class MemoryRegistry {
        +register(memory_type): function
        +create_memory(type, data): Memory
    }
    
    Memory <|-- TokenLimitedMemory
    Memory -- MemoryRegistry
    Memory --> MemoryAssessment
    MemoryCapacityError --> MemoryAssessment
    
    class Agent {
        +memory: Memory
        +process_message(message): void
    }
    
    Agent --> Memory
```

### Core Components

| Component | Responsibility | Key Features |
|-----------|----------------|--------------|
| **Memory** | Abstract base class for all memory implementations | • Common interface<br>• Message storage<br>• Type registry<br>• Serialization support with cache persistence<br>• Tool call coherence tracking<br>• Token counting with caching<br>• Memory condensing support<br>• Pre-flight memory assessment<br>• Force memory reduction<br>• Error handling integration<br>• Backward compatibility with older sessions |
| **TokenLimitedMemory** | Manages memory with a token count limit | • Accurate token estimation<br>• Token counting cache<br>• Context window enforcement<br>• Oversized message handling<br>• Tool call relationship mapping<br>• Coherent message removal<br>• Memory condensing support<br>• Advanced pre-flight assessment<br>• Eviction planning<br>• Low memory capacity warnings |
| **MemoryCondenser** | Provides memory condensing capabilities | • Generates summaries of older messages<br>• Configurable threshold and preserve percentage<br>• Uses specialized LLM for summarization<br>• Callback system for UI integration<br>• Serialization support for persistence |
| **MemoryRegistry** | Manages memory type registration and creation | • Type-based factory<br>• Dynamic instantiation<br>• Extensibility support |
| **Error Handling System** | Comprehensive error detection and classification | • Memory capacity error detection<br>• Assessment-based error classification<br>• Structured error reporting<br>• Recovery action recommendations<br>• Severity level classification |

## Design Patterns and Principles

The memory module implements several design patterns and principles to ensure maintainability, extensibility, and robustness:

| Pattern/Principle | Implementation | Benefit |
|-------------------|----------------|---------|
| **Abstract Factory** | Memory class with register method and type registry | Allows dynamic creation of appropriate memory implementations based on type |
| **Template Method** | Memory base class with abstract methods | Defines the skeleton of operations while allowing subclasses to override specific steps |
| **Strategy** | Different memory implementations | Encapsulates different algorithms for memory management (count vs. token) |
| **Decorator** | @Memory.register decorator | Simplifies registration of new memory types |
| **Caching** | LRUCache for token counting | Improves performance by avoiding redundant token calculations |
| **Serialization/Deserialization** | to_dict and from_dict methods | Consistent pattern for converting memory to/from persistent storage |
| **Composition over Inheritance** | Using collections (deque) | Leverages existing data structures rather than complex inheritance |
| **Single Responsibility** | Focused implementations | Each class has a clear, single responsibility |
| **Open/Closed** | Extensible registry | Open for extension (new memory types) but closed for modification |

## Key Features

### Type Registry

The memory module uses a type registry to support serialization and deserialization:

- Each memory implementation registers itself with a unique type identifier
- The Memory.from_dict method uses this registry to instantiate the correct implementation
- This allows for seamless addition of new memory types without modifying existing code

```python
@Memory.register(MEMORY_TYPE_TOKEN_LIMITED)
class TokenLimitedMemory(Memory):
    # Implementation...
```

### Token Management

The token management system provides sophisticated and accurate token counting:

- Uses two complementary methods for token counting:
  - **Tokenizer-based**: Uses the tiktoken library for accurate token counting based on actual model tokenizers
  - **Character-based**: Fallback method that estimates tokens based on character count with a configurable ratio
- Implements token calculation caching using LRUCache to improve performance
- Strictly enforces the inequality `input + max_output <= context limit` with improved safety margin calculations
- Dynamically adjusts target token counts based on conversation patterns and model capabilities
- Enforces maximum token limits with adaptive safety buffers
- Intelligently removes oldest messages when the limit is approached
- Preserves conversation coherence by maintaining tool call relationships
- Handles oversized messages that exceed the token limit
- Provides warnings when memory capacity is too low
- Automatically adjusts memory capacity when switching models with different context windows

### Token Counting Optimization

The token counting system has been optimized for both accuracy and performance:

- **Caching**: Implements an LRU cache to avoid recalculating tokens for the same messages
- **Cache Serialization**: Serializes and deserializes the token count cache using msgpack and base64 encoding for persistence across sessions
- **Cache Migration**: Handles backward compatibility with older sessions that don't have a token count cache
- **Batched Encoding**: Groups encoding operations for better performance
- **Special Case Handling**: Optimizes token counting for common message structures
- **Fallback Mechanism**: Gracefully degrades to character-based estimation if tokenizer fails
- **Minimum Token Guarantees**: Ensures every message gets at least a minimum token count
- **Differential Accuracy**: Recognizes and accounts for differences between tokenizer-based and character-based counting methods
- **Cache Invalidation**: Intelligently invalidates cache entries when tokenization parameters change

### Context Window Management

The system ensures that the total token count never exceeds the model's context window using a percentage-based allocation approach:

- Allocates context window using consistent (default) percentages:
  - 70% for conversation history (memory)
  - 20% for model output (max output tokens)
  - 10% as safety buffer
- Strictly enforces the inequality: `input_tokens + max_output_tokens <= context_window`
- Uses consistent percentage constants (`MEMORY_PERCENTAGE`, `OUTPUT_TOKENS_PERCENTAGE`, `SAFETY_BUFFER_PERCENTAGE`) across the codebase
- Automatically scales allocations based on model context window size
- Dynamically adjusts target token counts based on historical message sizes and frequency
- Caps max output tokens to 20% of context window to ensure sufficient memory capacity
- Provides detailed logging of allocations and migrations when switching models
- Intelligently migrates memory contents when switching to models with different context windows
- Handles extreme downgrade scenarios by prioritizing recent messages
- Implements preemptive memory cleanup to avoid context window violations

### Tool Call Coherence

To maintain conversation coherence, the Memory module tracks tool call relationships:

- The base Memory class provides tool call tracking functionality
- A tool call unit consists of an assistant message with tool calls and its corresponding tool responses
- When memory needs to be freed, complete tool call units are preserved or removed together
- This ensures that tool calls and their responses remain coherent
- Incomplete tool call units (where responses haven't arrived yet) are protected from removal

```mermaid
flowchart TD
    subgraph "Conversation Turn Structure"
        A[User Message] --> B[Assistant Response]
        B --> C[Tool Call Response 1]
        B --> D[Tool Call Response 2]
    end
    
    subgraph "Memory Management"
        E[New Message Exceeds Token Limit] --> F{Remove Messages}
        F --> G[Remove Entire Conversation Turn]
        F --> H[Remove Individual Messages]
        G --> I[Maintains Coherence]
        H --> J[Breaks Coherence]
    end
```

### Importance of Proper Message Removal

Proper handling of message removal from conversations is critical for several reasons:

1. **Conversation Coherence**: Removing individual messages can break the logical flow of a conversation. For example, removing a user question while keeping the assistant's answer would create a confusing context for both the LLM and the user.

2. **Message Ordering Requirements**: LLM providers require messages to be in a specific order, especially for tool calls. If an assistant message containing tool calls is removed but the tool response messages are kept, most providers will interpret this as an error because tool responses must be preceded by their corresponding tool calls.

3. **Context Preservation**: LLMs rely on conversation history to maintain context. Improper removal can lead to the LLM "forgetting" important information or making references to removed content.

4. **Tool Call Integrity**: Tool calls and their responses form a logical unit. Removing one without the other creates orphaned messages that lack proper context, leading to potential errors in LLM processing.

5. **Efficient Token Usage**: By removing complete conversation turns, we ensure that tokens are not wasted on partial or fragmented exchanges that provide limited value.

6. **User Experience**: A coherent conversation history improves user experience by maintaining a logical flow that can be reviewed and understood.

The TokenLimitedMemory implementation addresses these concerns by:

- Tracking relationships between messages in a conversation turn
- Building a complete map of conversation turns
- Removing entire turns rather than individual messages
- Preserving tool call relationships
- Prioritizing removal of oldest turns to maintain recency
- Protecting incomplete tool call units from removal
- Providing clear warnings about low memory capacity

### Tool Call Management

The memory module implements comprehensive tool call relationship tracking. For detailed information, see the [Tool Call Coherence](#tool-call-coherence) section below, which covers:

- Tool call unit formation and mapping
- Coherent removal strategies
- Orphaned tool call resolution
- Context preservation mechanisms

## Error Handling System

The memory module includes a comprehensive error handling system that provides structured error detection, classification, and recovery recommendations. This system ensures robust handling of memory capacity issues and provides clear feedback to agents and users.

### Pre-Flight Memory Assessment

Before attempting to store any message, the memory system performs a comprehensive assessment using the [`pre_flight_memory_check()`](base.py:176) method. This assessment determines:

- **Storage Feasibility**: Whether the message can be stored with current capacity
- **Required Actions**: What steps need to be taken (direct storage, eviction, condensing, or error reporting)
- **Token Analysis**: Detailed breakdown of current usage, message size, and capacity limits
- **Recovery Options**: Available mechanisms for handling capacity issues

The method returns a [`MemoryAssessment`](schemas.py:6) object containing:

| Field | Description | Purpose |
|-------|-------------|---------|
| `can_store` | Boolean indicating if storage is possible | Quick decision making |
| `action` | Recommended action from [`AssessmentAction`](errors/types.py) enum | Guidance for next steps |
| `message_tokens` | Token count for the incoming message | Caching and planning |
| `current_tokens` | Current memory token usage | Capacity analysis |
| `capacity_limit` | Maximum token capacity | Constraint awareness |
| `tokens_to_free` | Tokens needed to be freed | Eviction planning |
| `removable_tokens` | Tokens available for removal | Feasibility assessment |
| `reason_if_failed` | Detailed failure reason | Error classification |

### Assessment Actions and Error Classification

The [`AssessmentAction`](errors/types.py) enum defines possible recommendations from pre-flight assessment:

| Action | Description | When Used | Next Steps |
|--------|-------------|-----------|------------|
| `STORE_DIRECT` | Message can be stored immediately | Sufficient capacity available | Store message directly |
| `EVICT_THEN_STORE` | Remove old messages, then store | Capacity can be freed through eviction | Execute eviction plan, then store |
| `SUGGEST_CONDENSE` | Recommend memory condensing | Memory is fragmented, condensing would help | Trigger condensing if available, otherwise report error |
| `REPORT_TO_AGENT` | Cannot store, report error | Message too large or insufficient removable content | Create [`MemoryCapacityError`](errors/exceptions.py) with classification |

When storage fails (`REPORT_TO_AGENT`), the system uses [`classify_memory_error()`](errors/detection.py) to categorize the error:

#### Error Categories and Severity

| Category | Severity | Description | Typical Cause | Recovery Approach |
|----------|----------|-------------|---------------|-------------------|
| **OVERSIZED_MESSAGE** | **FATAL** | Message exceeds total memory capacity | Very large messages | Agent must implement chunking or summarization |
| **INSUFFICIENT_CAPACITY** | **RECOVERABLE** | Not enough removable content | Memory fragmentation, protected tool calls | Suggest condensing or user guidance |
| **INSUFFICIENT_CAPACITY** | **FATAL** | No removable content available | All messages protected or minimal history | Requires immediate attention |

#### Edge Cases

The error handling system gracefully manages several edge cases:

- **Zero-deficit scenarios** (`tokens_to_free = 0`): When the message fits exactly at capacity limits, the pre-flight assessment returns `STORE_DIRECT`, but in some agent flows this may surface as `insufficient_capacity_no_deficit` with retry behavior, depending on the specific storage context and previous operations
- **Boundary conditions**: Messages that exactly equal the memory capacity are treated as insufficient capacity (not oversized) to maintain consistent behavior
- **Protected content dominance**: When all or most messages are protected (incomplete tool calls), the system provides clear guidance about completing pending operations
- **Negative available capacity**: Handles cases where current usage already exceeds limits due to configuration changes or model switches

### Memory Assessment Flow

The following diagram illustrates the complete pre-flight assessment process:

```mermaid
flowchart TD
    A[store message] --> B[pre_flight_memory_check]
    B --> C{Fits directly?}
    C -->|Yes| D[STORE_DIRECT]
    C -->|No| E[Compute tokens_to_free]
    E --> F[Plan Eviction]
    F --> G{Eviction frees enough?}
    G -->|Yes| H[EVICT_THEN_STORE]
    G -->|No| I{Condenser available?}
    I -->|Yes| J[SUGGEST_CONDENSE]
    I -->|No| K[REPORT_TO_AGENT]
    
    J --> M{Auto-condense enabled?}
    M -->|Yes| N[Attempt Condensing]
    M -->|No| L[Raise MemoryCapacityError]
    N --> O{Condensing successful?}
    O -->|Yes| P[Retry Storage]
    O -->|No| L
    K --> L
    P --> B
    
    style D fill:#90EE90
    style H fill:#90EE90
    style P fill:#87CEEB
    style L fill:#FFB6C1
```

This flow ensures that:
- **Direct storage** is attempted first when capacity allows
- **Eviction planning** is performed to determine if older messages can be safely removed
- **Condensing suggestions** are made when eviction alone is insufficient but condensing is available
- **Error reporting** occurs when no automatic resolution is possible

### Force Memory Reduction

The [`force_memory_reduction()`](base.py) method provides a mechanism to forcibly reduce memory usage by a specified percentage:

- **Target Reduction**: Configurable percentage (default: 20%) where the target token count becomes `current_tokens * (1 - percentage)`
- **Coherent Removal**: Maintains tool call relationships during reduction
- **Metadata Tracking**: Returns detailed information about what was removed
- **Graceful Degradation**: Handles edge cases where target reduction cannot be achieved

This method is particularly useful for:
- Emergency memory cleanup
- Preparing for large message storage
- Implementing custom memory management policies
- Testing memory behavior under constrained conditions
- Proactive headroom management (keeping memory usage below soft watermarks)

## Memory Implementations

### Base Memory

The Memory abstract base class provides:

- **Common Interface**: Standardized methods for all memory implementations
- **Registration Mechanism**: Type registry for memory implementations using [`@Memory.register`](base.py:38) decorator
- **Message Storage**: Basic message storage and retrieval with coherence preservation
- **Pre-flight Assessment**: Abstract [`pre_flight_memory_check()`](base.py:176) method for storage feasibility analysis
- **Force Memory Reduction**: [`force_memory_reduction()`](base.py:197) method for emergency memory cleanup
- **Orphaned Tool Call Resolution**: [`resolve_orphaned_tool_calls()`](base.py:299) method for handling incomplete tool exchanges
- **Helper Methods**: Convenient methods for adding different message types ([`add_user_message()`](base.py:1089), [`add_assistant_message()`](base.py:1106), [`add_tool_message()`](base.py:1148))
- **Token Counting**: Optimized token estimation with LRU caching support
- **Tool Call Management**: Comprehensive tool call relationship tracking and coherence preservation
- **Memory Condensing**: Integration with [`MemoryCondenser`](condenser.py) for intelligent memory summarization
- **Serialization Support**: Complete serialization/deserialization with cache persistence
- **Backward Compatibility**: Support for loading older session formats without breaking changes

#### Methods in Base Memory

| Method | Purpose | Key Features |
|--------|---------|--------------|
| [`pre_flight_memory_check()`](base.py:176) | Assess storage feasibility before attempting to store | • Returns detailed [`MemoryAssessment`](schemas.py:6)<br>• Provides action recommendations<br>• Enables proactive error handling |
| [`force_memory_reduction()`](base.py:197) | Force memory reduction by specified percentage | • Configurable reduction percentage<br>• Maintains tool call coherence<br>• Returns detailed reduction metadata |
| [`resolve_orphaned_tool_calls()`](base.py:299) | Handle incomplete tool call exchanges | • Detects orphaned tool calls<br>• Adds appropriate error messages<br>• Maintains conversation coherence |
| [`count_by_role()`](base.py:113) | Count messages by role with optional filtering | • Supports role-based analysis<br>• Enables memory composition insights<br>• Useful for debugging and monitoring |
| [`is_system_message()`](base.py:215) | Check if message is a system message | • Identifies system-level messages<br>• Used in condensing and eviction logic<br>• Preserves critical system context |
| [`upsert_system_message()`](base.py:241) | Add or update system message | • Ensures single system message<br>• Updates existing or creates new<br>• Maintains system message positioning |

### Token-Limited Memory

TokenLimitedMemory provides a sophisticated memory implementation with advanced error handling and assessment capabilities:

- **Advanced Assessment**: Implements comprehensive [`pre_flight_memory_check()`](token_limited_memory.py:440) with detailed token analysis
- **Eviction Planning**: Uses [`_plan_eviction()`](token_limited_memory.py:281) to strategically plan message removal
- **Direct Storage**: Optimized [`_store_message_directly()`](token_limited_memory.py:172) method for efficient message storage
- **Token Tracking**: Tracks accurate token usage for each message using tiktoken with character-based fallback
- **Performance Optimization**: Caches token counts using LRU cache for improved performance
- **Context Window Enforcement**: Enforces maximum token limits with dynamic safety buffers
- **Conversation Coherence**: Preserves conversation coherence when removing messages through tool call unit management
- **Complex Tool Call Handling**: Manages complex tool call relationships and ensures coherent removal
- **Oversized Message Management**: Handles messages that exceed token limits with assessment-based storage and recovery
- **Capacity Warnings**: Issues warnings when memory capacity is too low for effective operation
- **Model Adaptation**: Automatically adjusts when switching between models with different context windows
- **Force Reduction**: Implements detailed [`force_memory_reduction()`](token_limited_memory.py:522) with comprehensive reporting

#### Advanced Features

| Feature | Description | Implementation |
|---------|-------------|----------------|
| **Eviction Planning** | Strategic planning of which messages to remove | [`_plan_eviction()`](token_limited_memory.py:281) analyzes tool call units and plans optimal removal |
| **Execution Planning** | Controlled execution of eviction plans | [`_execute_eviction_plan()`](token_limited_memory.py:384) safely removes planned messages |
| **Assessment Integration** | Detailed pre-flight assessment | Returns comprehensive [`MemoryAssessment`](schemas.py:6) with all assessment actions |
| **Error Classification** | Structured error handling | Creates [`MemoryCapacityError`](errors/exceptions.py:7) with proper classification |
| **Direct Storage** | Optimized storage path | [`_store_message_directly()`](token_limited_memory.py:172) bypasses assessment for known-good messages |

## Data Flow

```mermaid
sequenceDiagram
    participant Agent
    participant Memory
    participant Assessment
    participant ErrorHandler
    participant TokenCache
    
    Note over Agent,Memory: Modern assessment-based storage process
    Agent->>Memory: store(message)
    
    Memory->>Memory: pre_flight_memory_check(message)
    Memory->>TokenCache: Check cache for token count
    alt Cache Hit
        TokenCache-->>Memory: Return cached token count
    else Cache Miss
        Memory->>Memory: Estimate tokens (_estimate_tokens)
        Memory->>TokenCache: Store token count in cache
    end
    
    Memory->>Assessment: Create MemoryAssessment
    Assessment-->>Memory: Assessment with action recommendation
    
    alt Assessment: STORE_DIRECT
        Memory->>Memory: Store message immediately
    else Assessment: EVICT_THEN_STORE
        Memory->>Memory: Plan eviction (_plan_eviction)
        Memory->>Memory: Execute eviction (_execute_eviction_plan)
        Memory->>Memory: Store message (_store_message_directly)
    else Assessment: SUGGEST_CONDENSE
        Memory->>Memory: Check if condensing enabled
        alt Condensing enabled
            Memory->>Memory: Trigger condensing (check_and_condense)
            Memory->>Memory: Retry storage after condensing
        else Condensing disabled
            Memory->>ErrorHandler: Create MemoryCapacityError
            ErrorHandler-->>Agent: Report recoverable error
        end
    else Assessment: REPORT_TO_AGENT
        Memory->>ErrorHandler: Create MemoryCapacityError
        ErrorHandler->>ErrorHandler: Classify error (classify_memory_error)
        ErrorHandler-->>Agent: Report error with severity and category
    end
    
    Memory->>Memory: Update metadata (_update_tool_call_mapping)
    Memory-->>Agent: Result (success or error)
    
    Agent->>Memory: retrieve()
    Memory-->>Agent: Current messages
```

The memory lifecycle follows these steps:

1. **Message Creation**: A new message is created (user, assistant, or tool)
2. **Pre-flight Assessment**: The memory performs [`pre_flight_memory_check()`](base.py:176) to analyze storage feasibility
3. **Token Calculation**: The system checks the token cache or calculates tokens using tiktoken/character-based fallback
4. **Assessment Creation**: A [`MemoryAssessment`](schemas.py:6) object is created with detailed capacity analysis
5. **Action Determination**: Based on the assessment, one of four actions is recommended:
   - **STORE_DIRECT**: Immediate storage with sufficient capacity
   - **EVICT_THEN_STORE**: Plan and execute eviction, then store
   - **SUGGEST_CONDENSE**: Recommend memory condensing for fragmented memory
   - **REPORT_TO_AGENT**: Cannot store, create [`MemoryCapacityError`](errors/exceptions.py:7)
6. **Action Execution**: The recommended action is executed:
   - Direct storage or eviction planning and execution
   - Condensing trigger (if enabled) or error reporting
   - Error classification with severity and category assignment
7. **Message Storage**: If successful, the message is stored using [`_store_message_directly()`](token_limited_memory.py:172)
8. **Metadata Update**: Tool call relationships and token counts are updated
9. **Cache Management**: Token counts are cached for future reference
10. **Serialization Support**: Token cache is serialized with msgpack and base64 encoding for persistence
11. **Deserialization**: Cache is reconstructed from serialized data or recalculated for older sessions
12. **Error Handling**: Any failures are properly classified and reported with recovery recommendations

## Integration

### Agent Integration

The memory module integrates with the agents through a robust error handling system:

- **Storage Assessment**: Agents can use [`pre_flight_memory_check()`](base.py:176) to assess storage feasibility before attempting to store messages
- **Error Handling**: Agents receive structured [`MemoryCapacityError`](errors/exceptions.py:7) exceptions with detailed recovery information
- **Context Management**: Memory provides context for agent responses while ensuring token limits are respected
- **Adaptive Behavior**: Different agent types can use different memory implementations based on their requirements
- **Token Enforcement**: Token counting ensures the inequality `input + max_output <= context limit` is maintained

#### Error Handling Integration Example

```python
from coda_core.core.memories.token_limited_memory import TokenLimitedMemory
from coda_core.core.memories.errors.exceptions import MemoryCapacityError
from coda_core.core.memories.errors.types import ErrorSeverity, AssessmentAction

# Create memory instance
memory = TokenLimitedMemory(capacity=100000)

# Pre-flight check before storage
assessment = memory.pre_flight_memory_check(message)

if assessment.can_store:
    if assessment.action == AssessmentAction.STORE_DIRECT:
        memory.store(message)
    elif assessment.action == AssessmentAction.EVICT_THEN_STORE:
        # Memory will handle eviction automatically
        memory.store(message)
    elif assessment.action == AssessmentAction.SUGGEST_CONDENSE:
        # Trigger condensing if available
        condense_result = memory.check_and_condense(force=True)
        memory.store(message)
else:
    # Handle storage failure
    try:
        memory.store(message)
    except MemoryCapacityError as e:
        if e.severity == ErrorSeverity.RECOVERABLE:
            # Suggest user actions like condensing
            print(f"Memory capacity issue: {e.assessment.reason_if_failed}")
            print("Consider condensing memory or reducing message size")
        else:
            # Critical error requiring immediate attention
            print(f"Critical memory error: {e.assessment.reason_if_failed}")
            # Escalate to user or implement fallback strategy
```

### Model Integration

The memory module integrates with the model system:

- Automatically adjusts memory capacity based on model context window
- Enforces appropriate token limits for different models
- Migrates memory contents when switching between models
- Uses model-specific tokenizers when available
- Falls back to appropriate tokenizers for non-standard models

### Serialization Integration

The memory module supports serialization for persistence:

- Memory can be converted to/from dictionaries
- Memory can be saved to/loaded from JSON files
- Token count cache is serialized using msgpack and base64 encoding for efficient storage
- Backward compatibility ensures older sessions without token cache can still be loaded
- Handles differences in token counting methods between serialization and deserialization
- This allows for session persistence and recovery
- The type registry ensures proper instantiation of the correct memory implementation

## Extensibility

The system is designed to be extensible:

| Extension Point | Description | Implementation Approach |
|-----------------|-------------|-------------------------|
| **Memory Types** | Adding new memory implementations | Subclass Memory, implement abstract methods, and register with @Memory.register |
| **Assessment Logic** | Customizing pre-flight memory assessment | Override pre_flight_memory_check method in a subclass |
| **Error Classification** | Changing how errors are categorized | Extend classify_memory_error function or create custom error types |
| **Eviction Strategies** | Customizing message removal algorithms | Override _plan_eviction and _execute_eviction_plan methods |
| **Token Estimation** | Changing how tokens are estimated | Override _estimate_tokens method in a subclass |
| **Token Caching** | Customizing cache behavior | Provide custom cache implementation to memory constructor |
| **Force Reduction** | Customizing forced memory reduction | Override force_memory_reduction method with custom logic |
| **Serialization Format** | Changing the serialization format | Override to_dict and from_dict methods |
| **Message Types** | Supporting new message types | Add new helper methods (similar to add_user_message) |
| **Condensing Strategies** | Changing how memory condensing works | Override _needs_condensing, _calculate_preserve_count, and _identify_messages_to_condense methods |
| **Condensing Callbacks** | Customizing UI feedback during condensing | Provide custom callbacks to the MemoryCondenser constructor |
| **Error Recovery** | Adding custom error recovery mechanisms | Extend MemoryCapacityError or create custom exception handlers |

## Memory Condensing

The memory module includes a sophisticated memory condensing feature that optimizes token usage by intelligently summarizing older messages in conversation history:

```mermaid
flowchart TD
    A[Memory Reaches Threshold] --> B{Needs Condensing?}
    B -->|Yes| C[Identify Messages to Condense]
    B -->|No| Z[Continue Normal Operation]
    C --> D[Ensure Tool Call Coherence]
    D --> E[Generate Summary Using LLM]
    E --> F[Replace Condensed Messages with Summary]
    F --> G[Update Token Accounting]
    G --> H[Rebuild Tool Call Map]
    H --> Z
```

### Key Components

Component | Purpose | Features |
|-----------|---------|----------|
**MemoryCondenser** | Provides summarization capabilities | • Configurable threshold and preserve percentage<br>• LLM-based summarization<br>• Callback system for UI integration<br>• Serialization support |
**Memory Base Class** | Provides condensing infrastructure | • Abstract methods for condensing logic<br>• Smart message selection<br>• Tool call chain preservation<br>• Token accounting |
**Summarization Prompt** | Guides the LLM | • Structured, information-dense summaries<br>• Context preservation<br>• Token efficiency |

### Condensing Process

The memory condensing process follows these steps:

1. **Threshold Check**: When memory reaches a configurable threshold (default: 50% of capacity), condensing is triggered
2. **Message Selection**: The system identifies which messages to condense vs. preserve:
   - Recent messages are preserved (default: 20% of messages)
   - System messages are always preserved
   - Tool call chains are kept together (never split)
3. **Summary Generation**: A specialized LLM (default: gpt-4.1-mini) generates a summary of the messages to be condensed
4. **Message Replacement**: The condensed messages are replaced with a single summary message
5. **Token Accounting**: The token count is updated to reflect the new memory state
6. **Tool Call Map**: The tool call map is rebuilt to maintain conversation coherence

### Configuration

Memory condensing can be configured through several environment variables:

Variable | Purpose | Default |
|----------|---------|---------|
`CODA_MEMORY_CONDENSING_ENABLED` | Enable/disable memory condensing | `true` |
`CODA_MEMORY_CONDENSING_THRESHOLD` | Threshold percentage that triggers condensing | `0.5` |
`CODA_MEMORY_CONDENSING_LLM_PROVIDER` | Provider for condensing LLM | `openai` |
`CODA_MEMORY_CONDENSING_LLM_MODEL` | Model for condensing LLM | `gpt-4.1-mini` |

The feature can also be configured programmatically by setting the `condenser` property on a memory instance:

```python
from coda_core.core.memories.token_limited_memory import TokenLimitedMemory
from coda_core.core.memories.condenser import MemoryCondenser

# Create a memory instance
memory = TokenLimitedMemory(capacity=100000)

# Create and attach a condenser with custom settings
condenser = MemoryCondenser(
    threshold=0.7,  # Trigger at 70% capacity
    preserve_percentage=0.4,  # Preserve 40% of recent messages
    callbacks={
        "on_memory_condensing_start": lambda msg: print(f"Starting condensing: {msg}"),
        "on_memory_condensing_end": lambda meta: print(f"Condensing complete: {meta}")
    }
)
memory.condenser = condenser
```

### Tool Call Coherence

The memory condensing feature maintains conversation coherence by ensuring that tool call chains are never split during condensing:

- Assistant messages with tool calls and their corresponding tool responses are treated as a single unit
- These units are either fully preserved or fully condensed, never split
- This ensures that the conversation remains coherent and that tool calls always have their responses

### UI Integration

The system includes UI integration through a callback mechanism:

- `on_memory_condensing_start`: Called when condensing process starts
- `on_memory_condensing_end`: Called when condensing process completes with metadata
- `on_memory_condensing_skipped`: Called when condensing is skipped with the reason

These callbacks allow the UI to display progress indicators, notifications, and statistics about the condensing process.