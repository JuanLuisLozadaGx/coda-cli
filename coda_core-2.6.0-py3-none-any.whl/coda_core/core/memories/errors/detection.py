from typing import Tuple

from coda_core.core.memories.schemas import MemoryAssessment
from coda_core.core.memories.errors.types import (
    MemoryErrorCategory,
    MemoryErrorAction,
    MemoryErrorSeverity,
    MemoryFailureReason
)


def classify_memory_error(assessment: MemoryAssessment) -> Tuple[MemoryErrorCategory, MemoryErrorAction, MemoryErrorSeverity]:
    """Classify memory capacity error based on assessment details.
    
    Args:
        assessment: Memory assessment with failure details.
        
    Returns:
        Tuple containing error category, action, and severity.
    """
    if assessment.reason_if_failed == MemoryFailureReason.EXCEEDS_MEMORY_CAPACITY:
        return (
            MemoryErrorCategory.OVERSIZED_MESSAGE,
            MemoryErrorAction.REPORT_TO_AGENT,
            MemoryErrorSeverity.FATAL
        )
    elif assessment.reason_if_failed == MemoryFailureReason.CONDENSING_SUGGESTED:
        return (
            MemoryErrorCategory.INSUFFICIENT_CAPACITY,
            MemoryErrorAction.REPORT_TO_AGENT,
            MemoryErrorSeverity.RECOVERABLE
        )
    else:
        return (
            MemoryErrorCategory.INSUFFICIENT_CAPACITY,
            MemoryErrorAction.REPORT_TO_AGENT,
            MemoryErrorSeverity.FATAL
        )