from typing import Dict, Any

from coda_core.core.memories.schemas import MemoryAssessment
from coda_core.core.memories.errors.types import MemoryErrorCategory, MemoryErrorAction, MemoryErrorSeverity


class MemoryCapacityError(Exception):
    """Exception raised when memory cannot handle message with its available mechanisms.
    
    Attributes:
        assessment: The memory assessment that led to this error.
        category: The category of the error.
        action: The recommended action for recovery.
        severity: The severity level of the error.
    """
    
    def __init__(
        self,
        assessment: MemoryAssessment,
        category: MemoryErrorCategory,
        action: MemoryErrorAction,
        severity: MemoryErrorSeverity
    ) -> None:
        """Initialize MemoryCapacityError.
        
        Args:
            assessment: Memory assessment with failure details.
            category: Error category (OVERSIZED_MESSAGE, INSUFFICIENT_CAPACITY).
            action: Recovery action (REPORT_TO_AGENT).
            severity: Error severity (RECOVERABLE, FATAL).
        """
        self.assessment = assessment
        self.category = category
        self.action = action
        self.severity = severity
        
        super().__init__(f"Memory cannot store message: {assessment.reason_if_failed or 'unknown'}")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert error to dictionary for logging/serialization.
        
        Returns:
            Dictionary representation of the error with all details.
        """
        return {
            "error_type": self.__class__.__name__,
            "category": self.category.value,
            "action": self.action.value,
            "severity": self.severity.value,
            "assessment": {
                "can_store": self.assessment.can_store,
                "action": self.assessment.action.value,
                "message_tokens": self.assessment.message_tokens,
                "current_tokens": self.assessment.current_tokens,
                "capacity_limit": self.assessment.capacity_limit,
                "tokens_to_free": self.assessment.tokens_to_free,
                "removable_tokens": self.assessment.removable_tokens,
                "reason_if_failed": self.assessment.reason_if_failed
            }
        }