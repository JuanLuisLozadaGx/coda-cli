from enum import Enum


class MemoryAssessmentAction(Enum):
    """Actions that memory can recommend based on assessment."""
    STORE_DIRECT = "store_direct"
    EVICT_THEN_STORE = "evict_then_store"
    SUGGEST_CONDENSE = "suggest_condense"
    REPORT_TO_AGENT = "report_to_agent"


class MemoryErrorCategory(Enum):
    """Category of the memory error (actual failures only)."""
    OVERSIZED_MESSAGE = "oversized_message"
    INSUFFICIENT_CAPACITY = "insufficient_capacity"


class MemoryErrorAction(Enum):
    """Action for error recovery (failures only)."""
    REPORT_TO_AGENT = "report_to_agent"


class MemoryErrorSeverity(Enum):
    """Severity level of the memory error."""
    RECOVERABLE = "recoverable"
    FATAL = "fatal"


class MemoryFailureReason(Enum):
    """Specific reasons why memory storage failed."""
    EXCEEDS_MEMORY_CAPACITY = "exceeds_memory_capacity"
    INSUFFICIENT_REMOVABLE = "insufficient_removable"
    CONDENSING_SUGGESTED = "condensing_suggested"