from dataclasses import dataclass
from typing import Optional

from coda_core.core.memories.errors.types import MemoryAssessmentAction, MemoryFailureReason


@dataclass(frozen=True)
class MemoryAssessment:
    """Immutable assessment of memory's capacity to store a message.
    
    Attributes:
        can_store: Whether memory can handle the message with available mechanisms.
        action: The action memory recommends.
        message_tokens: Cached token count for the message (reuse in store()).
        current_tokens: Current token count in memory.
        capacity_limit: Maximum token capacity of the memory.
        tokens_to_free: Number of tokens that need to be freed (if applicable).
        removable_tokens: Number of tokens that can be removed via eviction.
        reason_if_failed: Specific enum reason why storage failed (if can_store is False).
    """
    can_store: bool
    action: MemoryAssessmentAction
    message_tokens: int
    current_tokens: int
    capacity_limit: int
    tokens_to_free: int = 0
    removable_tokens: int = 0
    reason_if_failed: Optional[MemoryFailureReason] = None