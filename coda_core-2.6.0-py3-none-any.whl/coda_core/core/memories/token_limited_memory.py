from typing import List, Dict, Any, Optional, Tuple, Callable
from loguru import logger
import math

from coda_core.core.memories.types import MemoryMigrationContext
from coda_core.core.memories.base import Memory
from coda_core.core.memories.constants import (
    MEMORY_DEFAULT_TOKEN_LIMIT,
    MEMORY_PERCENTAGE,
    MEMORY_SIZE_CHANGE_THRESHOLD,
    MEMORY_TARGET_TOKEN_RATIO,
    MEMORY_TYPE_TOKEN_LIMITED,
    MEMORY_MIN_MESSAGES_TO_LEAVE_BEHIND,
    MIN_SAFE_MAX_TOKENS
)
from coda_core.core.memories.schemas import MemoryAssessment
from coda_core.core.memories.errors.types import MemoryAssessmentAction, MemoryFailureReason
from coda_core.core.memories.errors.exceptions import MemoryCapacityError
from coda_core.core.memories.errors.detection import classify_memory_error
from coda_core.core.utils.constants import DEFAULT_CHAR_TO_TOKEN_RATIO

@Memory.register(MEMORY_TYPE_TOKEN_LIMITED)
class TokenLimitedMemory(Memory):
    """A memory system that maintains a sliding window of conversation messages.
    
    This class efficiently manages message history with token-awareness to prevent
    exceeding LLM context limits. It automatically removes oldest messages when
    the token limit is approached, ensuring conversation coherence by removing
    complete conversation turns.
    
    The memory system supports:
        - Automatic token counting with tiktoken integration
        - Intelligent message eviction preserving conversation coherence
        - Tool call unit preservation (assistant calls + tool responses)
        - System message protection
        - Pre-flight capacity assessment
        - Force reduction for emergency memory management
    """
    
    # Set the type identifier
    TYPE = MEMORY_TYPE_TOKEN_LIMITED
    
    def __init__(
        self,
        capacity: int = MEMORY_DEFAULT_TOKEN_LIMIT,
        char_to_token_ratio: int = DEFAULT_CHAR_TO_TOKEN_RATIO,  # Fallback if tiktoken fails
        messages: Optional[List[Dict[str, Any]]] = None,
        target_tokens: Optional[int] = None,
        encoding: Optional[Any] = None,  # tiktoken encoding instance
        on_condensation_callback: Optional[Callable[[], None]] = None
    ):
        """Initialize the token-limited memory system.
        
        Args:
            capacity (int): Maximum number of tokens to maintain in the memory.
                Defaults to 100000.
            char_to_token_ratio (int): Fallback approximate number of characters
                per token if tiktoken fails. Defaults to 4.
            messages (Optional[List[Dict[str, Any]]]): Optional initial list of
                messages to populate the memory.
            target_tokens (Optional[int]): Target token count after aggressive
                trimming. Defaults to 90% of capacity.
            encoding (Optional[Any]): Optional tiktoken encoding instance for
                accurate token counting.
            on_condensation_callback (Optional[Callable[[], None]]): Optional callback
                function to invoke when memory is condensed.
        """
        super().__init__(
            char_to_token_ratio=char_to_token_ratio, 
            encoding=encoding,
            on_condensation_callback=on_condensation_callback
        )
        self.capacity = capacity

        # Set target token count (used for aggressive trimming)
        self.target_tokens = target_tokens if target_tokens is not None else int(capacity * 0.9)
            
        # Add initial messages if provided
        if messages:
            for msg in messages:
                self.store(msg)

        logger.info(f"Initialized TokenLimitedMemory with capacity={self.capacity}")
 


    def clear(self) -> None:
        """Clear all messages from memory except the system message.
        
        Preserves the system message if it exists and re-adds it after clearing.
        Also clears token counts, tool call mappings, and token count cache.
        """
        # Preserve system message
        system_message = self.get_system_message()
        
        # Clear all messages
        self.messages.clear()
        self.token_count = 0
        self.tool_call_map.clear()
        self._token_count_cache.clear()
        
        # Re-add system message if it existed
        if system_message:
            content = system_message.get("content", "")
            if isinstance(content, list):
                content = " ".join(
                    block.get("text", "")
                    for block in content
                    if isinstance(block, dict) and block.get("text")
                )
            elif content is None:
                content = ""
            elif not isinstance(content, str):
                content = str(content)
            self.upsert_system_message(content)
            
        logger.info("Cleared messages from memory (preserving system message).")
    

    def retrieve(self, query: Any = None) -> List[Dict[str, Any]]:
        """Retrieve all messages in the conversation history.
        
        Args:
            query (Any, optional): Optional query parameter (not used in this
                implementation).
            
        Returns:
            List[Dict[str, Any]]: List of message dictionaries in chronological order.
        """
        return list(self.messages)
    

    def store(self, message: Dict[str, Any]) -> None:
        """Store a message in the conversation history with intelligent capacity management.
        
        Performs pre-flight assessment and executes the appropriate storage strategy:
        - Direct storage if message fits
        - Eviction followed by storage if space can be freed
        - Raises MemoryCapacityError if no viable storage action exists
        
        Args:
            message (Dict[str, Any]): A message dictionary with at least 'role' key.
                Common roles include 'system', 'user', 'assistant', and 'tool'.
            
        Raises:
            MemoryCapacityError: If memory cannot handle the message and no viable
                action exists (e.g., message is oversized or insufficient removable tokens).
        """
        # Perform pre-flight assessment
        assessment = self.pre_flight_memory_check(message)
        
        # Execute the recommended action
        if assessment.action == MemoryAssessmentAction.STORE_DIRECT:
            logger.info(
                "Storing message directly (fits): role={role} message_tokens={msg} "
                "current_tokens={current} new_total={new_total}/{cap} ({pct:.2%} usage)",
                role=message.get("role"),
                msg=assessment.message_tokens,
                current=assessment.current_tokens,
                new_total=assessment.current_tokens + assessment.message_tokens,
                cap=assessment.capacity_limit,
                pct=(assessment.current_tokens + assessment.message_tokens) / assessment.capacity_limit
            )
            self._store_message_directly(message=message, message_tokens=assessment.message_tokens)
            
        elif assessment.action == MemoryAssessmentAction.EVICT_THEN_STORE:
            # Calculate eviction plan and execute it
            tokens_to_free = assessment.tokens_to_free

            logger.warning(
                "Eviction required before storing: need_free={need} removable_tokens={removable} "
                "current_tokens={current} message_tokens={msg} capacity={cap}",
                need=tokens_to_free,
                removable=assessment.removable_tokens,
                current=assessment.current_tokens,
                msg=assessment.message_tokens,
                cap=assessment.capacity_limit
            )

            eviction_plan, _ = self._plan_eviction(tokens_needed=tokens_to_free)
            
            if not eviction_plan:
                # No messages can be evicted - report to agent
                logger.error(
                    "Eviction plan empty (cannot free required tokens). Escalating. "
                    "need_free={need} removable_tokens={removable} current_tokens={current} "
                    "message_tokens={msg} capacity={cap}",
                    need=tokens_to_free,
                    removable=assessment.removable_tokens,
                    current=assessment.current_tokens,
                    msg=assessment.message_tokens,
                    cap=assessment.capacity_limit
                )
                
                category, error_action, severity = classify_memory_error(assessment=assessment)
                raise MemoryCapacityError(
                    assessment=assessment,
                    category=category,
                    action=error_action,
                    severity=severity
                )
            
            logger.info(
                "Executing eviction plan: entries={entries} target_free={need} "
                "current_tokens={current} message_tokens={msg}",
                entries=len(eviction_plan),
                need=tokens_to_free,
                current=assessment.current_tokens,
                msg=assessment.message_tokens
            )
            actual_freed = self._execute_eviction_plan(eviction_plan=eviction_plan, tokens_needed=tokens_to_free)
            
            # Verify sufficient space was freed
            if self.token_count + assessment.message_tokens > self.capacity:
                logger.error(
                    "Eviction insufficient: {current_tokens} + {message_tokens} > {capacity} after freeing {actual_freed} tokens",
                    current_tokens=self.token_count,
                    message_tokens=assessment.message_tokens,
                    capacity=self.capacity,
                    actual_freed=actual_freed
                )
                category, error_action, severity = classify_memory_error(assessment=assessment)
                raise MemoryCapacityError(
                    assessment=assessment,
                    category=category,
                    action=error_action,
                    severity=severity
                )
            
            # Now store the message
            logger.info(
                "Eviction successful: freed={freed} storing message now (role={role})",
                freed=actual_freed,
                role=message.get("role")
            )
            self._store_message_directly(message=message, message_tokens=assessment.message_tokens)
            
        elif assessment.action in (MemoryAssessmentAction.SUGGEST_CONDENSE, MemoryAssessmentAction.REPORT_TO_AGENT):
            # Do NOT store the message - raise error for agent to handle
            logger.warning(
                "Cannot store message: escalation=agent action={action} reason={reason} "
                "current_tokens={current} message_tokens={msg} capacity={cap} "
                "tokens_to_free={to_free} removable_tokens={removable} condenser_present={has_condenser}",
                action=assessment.action.value,
                reason=getattr(assessment, "reason_if_failed", None),
                current=assessment.current_tokens,
                msg=assessment.message_tokens,
                cap=assessment.capacity_limit,
                to_free=getattr(assessment, "tokens_to_free", 0),
                removable=getattr(assessment, "removable_tokens", 0),
                has_condenser=bool(self.condenser)
            )
            
            category, error_action, severity = classify_memory_error(assessment=assessment)
            raise MemoryCapacityError(
                assessment=assessment,
                category=category,
                action=error_action,
                severity=severity
            )
        
        else:
            logger.error(
                "Unknown assessment action encountered: action={action} (escalating)",
                action=assessment.action
            )
            # Unknown action - should not happen
            raise ValueError(f"Unknown assessment action: {assessment.action}")


    def _store_message_directly(self, message: Dict[str, Any], message_tokens: int) -> None:
        """Store a message directly without any pre-processing.
        
        Args:
            message (Dict[str, Any]): The message to store.
            message_tokens (int): Pre-calculated token count for the message.
        """
        # Add the message
        message_index = len(self.messages)
        self.messages.append(message)
        self.token_count += message_tokens
        
        # Update tool call mapping
        self._update_tool_call_mapping(message, message_index)

        logger.info(
            "Stored message: role={role}, tokens={message_tokens}, total_token_count={total_token_count}",
            role=message.get("role"),
            message_tokens=message_tokens,
            total_token_count=self.token_count,
        )
    

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the memory to a dictionary for persistence.
        
        Returns:
            Dict[str, Any]: Dictionary representation of the memory including
                capacity, target_tokens, and base memory data.
        """
        data = super().to_dict()  # Get the base data with type and token info
        
        data.update({
            "capacity": self.capacity,
            "target_tokens": self.target_tokens
        })
        return data

    def _should_migrate(self, new_capacity: int) -> bool:
        """
        Verify if the memory should be migrated based on the provided context and the current capacity vs the new capacity.

        Args:
            new_capacity (int): The new capacity value to compare against the current one.

        Returns:
            bool: True if migration can be applied, False otherwise.
        """
        return (abs(self.capacity - new_capacity) / self.capacity) > MEMORY_SIZE_CHANGE_THRESHOLD

    def migrate(self, migration_ctx: MemoryMigrationContext):
        """
        Migrate the memory in-place updating the capacity and target_tokens based on the provided context.
        Encoding update and message re-evaluation is handled by the base class.

        Args:
            migration_ctx (MemoryMigrationContext): Context containing migration parameters.
        """
        safe_max_tokens = max(MIN_SAFE_MAX_TOKENS, int(migration_ctx.context_window * MEMORY_PERCENTAGE))
        logger.info(
            f"Memory allocation for '{self.TYPE}': {safe_max_tokens} tokens ({MEMORY_PERCENTAGE:.0%} of {migration_ctx.context_window})"
        )

        if not self._should_migrate(safe_max_tokens):
            logger.info(f"Memory '{self.TYPE}' capacity change is below threshold, skipping migration")
            return

        # Log memory size change
        change_percentage = abs(self.capacity - safe_max_tokens) / self.capacity * 100
        change_direction = "increased" if safe_max_tokens > self.capacity else "decreased"
        logger.info(
            f"Memory '{self.TYPE}' capacity {change_direction} by {change_percentage:.1f}%: "
            f"{self.capacity} → {safe_max_tokens} tokens"
        )

        # Update capacity and target_tokens
        self.capacity = safe_max_tokens
        self.target_tokens = int(safe_max_tokens * MEMORY_TARGET_TOKEN_RATIO)

        # Perform the migration of encoding and messages
        super().migrate(migration_ctx)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TokenLimitedMemory':
        """Create a TokenLimitedMemory instance from a dictionary.
        
        Args:
            data (Dict[str, Any]): Dictionary representation of a TokenLimitedMemory.
            
        Returns:
            TokenLimitedMemory: New TokenLimitedMemory instance with restored state.
        """
        # Create memory with specific parameters

        # Backwards compatibility with renamed field 'max_tokens' to 'capacity'
        capacity = data.get("capacity", None) or data.get("max_tokens", MEMORY_DEFAULT_TOKEN_LIMIT)

        memory = cls(
            capacity=capacity,
            char_to_token_ratio=data.get("char_to_token_ratio", DEFAULT_CHAR_TO_TOKEN_RATIO),
            target_tokens=data.get("target_tokens"),
            encoding=None  # Will be set by _initialize_from_dict if available
        )

        # Apply common initialization from base class
        memory = cls._initialize_from_dict(memory, data)

        return memory
    

    def _needs_condensing(self) -> bool:
        """Check if memory condensing is needed based on current usage.
        
        For token-limited memory, condensing is needed when the token count
        exceeds the threshold percentage of capacity.
        
        Returns:
            bool: True if condensing is needed, False otherwise.
        """
        if self.condenser is None:
            return False
            
        threshold_tokens = int(self.capacity * self.condenser.threshold)
        return self.token_count >= threshold_tokens
    
    
    def _calculate_preserve_count(self) -> int:
        """Calculate how many messages to preserve based on the preserve_percentage.
        
        For token-limited memory, we preserve a percentage of messages based on
        recency rather than trying to calculate a token-based preservation, which
        would be more complex and potentially less reliable.
        
        Returns:
            int: Number of messages to preserve (minimum 2, respects minimum leave-behind).
        """
        if self.condenser is None:
            return 0
            
        # Calculate preserve count based on percentage of total messages
        preserve_count = int(len(self.messages) * self.condenser.preserve_percentage)
        
        # Ensure we preserve at least 2 messages (to maintain some context)
        # but not more than the total number of messages minus MEMORY_MIN_MESSAGES_TO_LEAVE_BEHIND
        # (to ensure we have enough messages to condense)
        preserve_count = max(2, preserve_count)
        preserve_count = min(len(self.messages) - MEMORY_MIN_MESSAGES_TO_LEAVE_BEHIND, preserve_count) \
            if len(self.messages) > MEMORY_MIN_MESSAGES_TO_LEAVE_BEHIND else 0
        
        return preserve_count


    def _plan_eviction(self, tokens_needed: int) -> Tuple[List[int], int]:
        """Plan which messages to evict while maintaining conversation coherence.

        This method determines which messages should be removed to free up the required
        number of tokens while maintaining tool call unit coherence and protecting
        incomplete units.

        Args:
            tokens_needed (int): Number of tokens that need to be freed.

        Returns:
            Tuple[List[int], int]: A tuple containing:
                - List of message indices to remove (in chronological order)
                - Total number of tokens that would be freed

        Guarantees:
            - System messages are never evicted but do not shield adjacent removable messages
            - Assistant messages with tool calls and their direct tool responses are evicted atomically
            - Incomplete units (assistant with pending tool responses, orphan tool messages) are protected
            - At least one non-system message is always preserved
        """
        if tokens_needed <= 0:
            return [], 0

        system_indices = {i for i, m in enumerate(self.messages) if self.is_system_message(m)}

        # Build assistant -> tool response mapping
        assistant_to_tool_responses = self._build_tool_call_units()

        # Collect all tool unit members
        tool_units = {a_idx: {a_idx, *resp_idxs} for a_idx, resp_idxs in assistant_to_tool_responses.items()}
        index_to_unit = {}
        for unit in tool_units.values():
            for idx in unit:
                index_to_unit[idx] = unit

        # Detect incomplete tool units (assistant messages with tool calls but no responses yet)
        incomplete = set()
        for _, unit in tool_units.items():
            if len(unit) == 1:  # only assistant present
                incomplete.update(unit)

        # Orphan tool messages (tool role not mapped to any assistant)
        for i, msg in enumerate(self.messages):
            if msg.get("role") == "tool" and i not in index_to_unit:
                incomplete.add(i)

        candidates = self._get_next_removable_items(count=min(10, len(self.messages)))
        planned_set = set()
        tokens_freed = 0

        for item in candidates:
            if tokens_freed >= tokens_needed:
                break

            raw_indices = list(item.get("indices", []))
            if not raw_indices:
                continue

            # Remove system indices from candidate instead of skipping whole item
            filtered = [i for i in raw_indices if i not in system_indices]
            if not filtered:
                continue

            # Expand atomically: assistant or tool response pulls in its unit
            expanded = set()
            for idx in filtered:
                if idx in index_to_unit:
                    expanded.update(index_to_unit[idx])
                else:
                    expanded.add(idx)

            # Ensure no system indices remain
            expanded.difference_update(system_indices)
            if not expanded:
                continue

            # Protect incomplete units
            if any(idx in incomplete for idx in expanded):
                continue

            # New indices only (avoid duplicates + double counting)
            new_indices = [i for i in expanded if i not in planned_set]
            if not new_indices:
                continue

            # Leave at least one non-system message
            remaining = len(self.messages) - (len(planned_set) + len(new_indices))
            if remaining <= 1:
                break

            delta = self._calculate_tokens_for_indices(new_indices)
            planned_set.update(new_indices)
            tokens_freed += delta

        # Reconstruct chronological order (ascending index) from the set
        ordered = [i for i in range(len(self.messages)) if i in planned_set]

        return ordered, tokens_freed


    def _execute_eviction_plan(self, eviction_plan: List[int], tokens_needed: int) -> int:
        """Execute the planned eviction with state validation.
        
        Uses same helper as _plan_eviction to ensure consistency between
        planning and execution phases. Validates that the exact same plan
        would still be generated to ensure no state changes occurred.
        
        Args:
            eviction_plan (List[int]): List of message indices to remove.
            tokens_needed (int): Number of tokens that need to be freed (for validation).
            
        Returns:
            int: Actual number of tokens freed.
            
        Raises:
            RuntimeError: If eviction plan is no longer viable due to state changes.
            ValueError: If eviction plan is empty.
        """
        if not eviction_plan:
            raise ValueError("Cannot execute empty eviction plan")
            
        # Re-run full planning with same parameters and compare sorted sets
        current_plan, _ = self._plan_eviction(tokens_needed=tokens_needed)
        
        # Compare as sorted sets to ensure exact same indices would be selected
        if sorted(eviction_plan) != sorted(current_plan):
            raise RuntimeError(
                f"Eviction plan no longer viable - memory state changed. "
                f"Original plan: {sorted(eviction_plan)}, "
                f"Current plan: {sorted(current_plan)}"
            )
        
        # Use _remove_messages_safely to maintain atomic tool-call group integrity
        # and properly handle token cache updates
        indices_to_remove = set(eviction_plan)
        removed_messages = self._remove_messages_safely(indices_to_remove)
        
        # Update token count (_remove_messages_safely does NOT modify token_count)
        actual_tokens_freed = 0
        for msg in removed_messages:
            msg_tokens = self._estimate_tokens(message=msg)
            self.token_count -= msg_tokens
            actual_tokens_freed += msg_tokens
        
        # Update tool call mapping (already done by _remove_messages_safely, but ensure consistency)
        self._rebuild_tool_call_map()
        
        # Check if we actually freed enough tokens and warn if not
        if actual_tokens_freed < tokens_needed:
            logger.warning(
                f"Eviction freed {actual_tokens_freed} tokens but {tokens_needed} were needed. "
                f"Shortfall: {tokens_needed - actual_tokens_freed} tokens."
            )
        
        return actual_tokens_freed


    def pre_flight_memory_check(self, message: Dict[str, Any]) -> MemoryAssessment:
        """Assess memory's internal capabilities for storing a message.
        
        Performs comprehensive capacity analysis to determine the best storage strategy:
        - Direct storage if message fits within current capacity
        - Eviction planning if space can be freed through message removal
        - Error reporting if message is oversized or insufficient removable tokens
        
        Args:
            message (Dict[str, Any]): The message to assess for storage.
            
        Returns:
            MemoryAssessment: Comprehensive assessment with capacity analysis and
                recommended action (STORE_DIRECT, EVICT_THEN_STORE, or REPORT_TO_AGENT).
        """
        # Single token estimation - cache for reuse in store()
        message_tokens = self._estimate_tokens(message=message)
        current_tokens = self.token_count
        capacity_limit = self.capacity
        total_after_adding = current_tokens + message_tokens
        
        # Check if single message exceeds capacity
        if message_tokens > capacity_limit:
            # No internal mechanism can make an oversized single message fit
            return MemoryAssessment(
                can_store=False,
                action=MemoryAssessmentAction.REPORT_TO_AGENT,
                message_tokens=message_tokens,
                current_tokens=current_tokens,
                capacity_limit=capacity_limit,
                tokens_to_free=0,  # Not applicable for oversized messages
                removable_tokens=0,  # Irrelevant for oversized messages
                reason_if_failed=MemoryFailureReason.EXCEEDS_MEMORY_CAPACITY
            )
        
        # Check if message fits directly
        if total_after_adding <= capacity_limit:
            return MemoryAssessment(
                can_store=True,
                action=MemoryAssessmentAction.STORE_DIRECT,
                message_tokens=message_tokens,
                current_tokens=current_tokens,
                capacity_limit=capacity_limit
            )
        
        # Calculate how many tokens we need to free
        tokens_to_free = total_after_adding - capacity_limit
        
        # Plan eviction using helper to ensure parity
        _, removable_tokens = self._plan_eviction(tokens_needed=tokens_to_free)
        
        if removable_tokens >= tokens_to_free:
            return MemoryAssessment(
                can_store=True,
                action=MemoryAssessmentAction.EVICT_THEN_STORE,
                message_tokens=message_tokens,
                current_tokens=current_tokens,
                capacity_limit=capacity_limit,
                tokens_to_free=tokens_to_free,
                removable_tokens=removable_tokens
            )
        
        # If eviction insufficient, suggest condensing
        if self.condenser:
            return MemoryAssessment(
                can_store=False,
                action=MemoryAssessmentAction.SUGGEST_CONDENSE,
                message_tokens=message_tokens,
                current_tokens=current_tokens,
                capacity_limit=capacity_limit,
                tokens_to_free=tokens_to_free,
                removable_tokens=removable_tokens,
                reason_if_failed=MemoryFailureReason.CONDENSING_SUGGESTED
            )
        
        # Memory cannot handle this with its available mechanisms
        return MemoryAssessment(
            can_store=False,
            action=MemoryAssessmentAction.REPORT_TO_AGENT,
            message_tokens=message_tokens,
            current_tokens=current_tokens,
            capacity_limit=capacity_limit,
            tokens_to_free=tokens_to_free,
            removable_tokens=removable_tokens,
            reason_if_failed=MemoryFailureReason.INSUFFICIENT_REMOVABLE
        )
    

    @staticmethod
    def _reduction_result_dict(
        initial_tokens: int,
        final_tokens: int,
        requested_percentage: float,
        tokens_reduced: int = 0,
        requested_tokens: int = 0,
        actual_percentage: float = 0.0,
        messages_removed: int = 0,
        plan_tokens_available: int = 0
    ) -> Dict[str, Any]:
        """Build a standardized reduction result dictionary.

        Args:
            initial_tokens (int): Number of tokens before reduction.
            final_tokens (int): Number of tokens after reduction.
            requested_percentage (float): Percentage requested for reduction.
            tokens_reduced (int): Number of tokens actually reduced. Defaults to 0.
            requested_tokens (int): Number of tokens requested to be reduced. Defaults to 0.
            actual_percentage (float): Actual percentage reduced. Defaults to 0.0.
            messages_removed (int): Number of messages removed. Defaults to 0.
            plan_tokens_available (int): Number of tokens available for planning. Defaults to 0.

        Returns:
            Dict[str, Any]: Standardized reduction result containing all metrics:
                - initial_tokens: Starting token count
                - final_tokens: Ending token count
                - tokens_reduced: Actual tokens freed
                - requested_tokens: Target tokens to free
                - requested_percentage: Target percentage
                - actual_percentage: Actual percentage freed
                - messages_removed: Number of messages evicted
                - plan_tokens_available: Tokens identified as removable
        """
        return {
            "initial_tokens": initial_tokens,
            "final_tokens": final_tokens,
            "tokens_reduced": tokens_reduced,
            "requested_tokens": requested_tokens,
            "requested_percentage": requested_percentage,
            "actual_percentage": actual_percentage,
            "messages_removed": messages_removed,
            "plan_tokens_available": plan_tokens_available
        }


    def force_memory_reduction(self, target_reduction_percentage: float = 0.20) -> Dict[str, Any]:
        """Force memory reduction while honoring eviction protection rules.

        Implements intelligent memory reduction strategy that preserves conversation
        coherence and critical message units while attempting to free the requested
        percentage of tokens. The actual amount freed may differ from the target due
        to protection rules and message boundaries.

        Strategy:
            - Calculate target tokens to free = current_tokens * percentage
            - Use the eviction planner which preserves:
                * System message
                * Incomplete tool units
                * Atomic assistant+tool response units
                * Leaves at least one non-system message
            - If planner yields no removable messages, raise MemoryCapacityError
            - Execute the planned eviction (actual reduction may vary from target)

        Args:
            target_reduction_percentage (float): The percentage of current tokens to
                attempt to free. Must be between 0.0 and 1.0. Defaults to 0.20 (20%).
                Note: Actual reduction may be higher or lower due to message boundaries
                and protection rules.
        
        Returns:
            Dict[str, Any]: Standardized reduction result from `_reduction_result_dict`
                containing all reduction metrics. See that method's docstring for
                complete field descriptions.

        Raises:
            MemoryCapacityError: If nothing can be removed (all content protected).
            ValueError: If target_reduction_percentage is not between 0.0 and 1.0.
        """
        if not (0.0 <= target_reduction_percentage <= 1.0):
            raise ValueError("target_reduction_percentage must be between 0.0 and 1.0")

        initial_tokens = self.token_count
        initial_count = len(self.messages)

        if initial_tokens == 0 or initial_count == 0:
            return self._reduction_result_dict(
                initial_tokens=initial_tokens,
                final_tokens=initial_tokens,
                requested_percentage=target_reduction_percentage
            )

        requested_tokens = math.ceil(initial_tokens * target_reduction_percentage)
        if requested_tokens <= 0:
            return self._reduction_result_dict(
                initial_tokens=initial_tokens,
                final_tokens=initial_tokens,
                requested_percentage=target_reduction_percentage,
                requested_tokens=requested_tokens
            )

        # Plan eviction using existing protection logic
        eviction_plan, plan_tokens = self._plan_eviction(tokens_needed=requested_tokens)

        if not eviction_plan or plan_tokens == 0:
            # Build a synthetic assessment for classification
            assessment = MemoryAssessment(
                can_store=False,
                action=MemoryAssessmentAction.REPORT_TO_AGENT,
                message_tokens=0,
                current_tokens=initial_tokens,
                capacity_limit=self.capacity,
                tokens_to_free=requested_tokens,
                removable_tokens=0,
                reason_if_failed=MemoryFailureReason.INSUFFICIENT_REMOVABLE
            )
            category, error_action, severity = classify_memory_error(assessment)
            logger.error(
                "Force reduction aborted: no removable messages (all protected). "
                "requested_tokens={req}, current_tokens={cur}",
                req=requested_tokens,
                cur=initial_tokens
            )
            raise MemoryCapacityError(assessment=assessment, category=category, action=error_action, severity=severity)

        # NOTE: We intentionally do NOT trim the plan to a subset because
        # _execute_eviction_plan validates the plan matches a fresh plan
        # for the same tokens_needed. Trimming would cause a mismatch.
        logger.warning(
            "Force reduction executing eviction plan: requested={req} tokens "
            "(~{pct:.1%}); plan_tokens_available={avail}; messages_in_plan={count}",
            req=requested_tokens,
            pct=target_reduction_percentage,
            avail=plan_tokens,
            count=len(eviction_plan)
        )

        self._execute_eviction_plan(eviction_plan=eviction_plan, tokens_needed=requested_tokens)

        final_tokens = self.token_count
        final_count = len(self.messages)
        tokens_reduced = initial_tokens - final_tokens
        actual_pct = (tokens_reduced / initial_tokens) if initial_tokens else 0.0

        logger.info(
            "Force reduction complete: reduced={reduced} (requested={requested}, "
            "actual_pct={actual:.1%}, requested_pct={req_pct:.1%}, final_tokens={final})",
            reduced=tokens_reduced,
            requested=requested_tokens,
            actual=actual_pct,
            req_pct=target_reduction_percentage,
            final=final_tokens
        )

        return self._reduction_result_dict(
            initial_tokens=initial_tokens,
            final_tokens=final_tokens,
            requested_percentage=target_reduction_percentage,
            tokens_reduced=tokens_reduced,
            requested_tokens=requested_tokens,
            actual_percentage=actual_pct,
            messages_removed=initial_count - final_count,
            plan_tokens_available=plan_tokens
        )

