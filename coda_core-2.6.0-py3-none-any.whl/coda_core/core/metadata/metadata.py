import getpass
from typing import Any, Dict, Optional

from loguru import logger

from coda_core.config.constants import CODA_AGENT_NAME
from coda_core.core.metadata.schemas import SessionMetadata


def _get_username() -> Optional[str]:
    """Get the current OS username.

    Returns:
        Username when it can be resolved, otherwise None.
    """
    try:
        return getpass.getuser()
    except Exception as e:
        logger.warning(f"Could not retrieve username from operating system: {e}")
        return None


def extract_metadata(metadata: SessionMetadata) -> Dict[str, Any]:
    """Convert validated session metadata into the payload sent to the LLM layer.

    Args:
        metadata: Session metadata model already validated with `SessionMetadata`.

    Returns:
        Dictionary with normalized metadata fields:
        - `task_name` is aligned with `task_id`.
        - `user_name` falls back to the OS username when missing.
        - `agent` is forced to `CODA_AGENT_NAME`.

    Raises:
        Exception: Propagates unexpected errors while preparing metadata.
    """
    try:
        # Convert Pydantic object to dictionary
        metadata_dict = metadata.model_dump()

        # Apply transformations
        metadata_dict["task_name"] = metadata.task_id

        # Override user_name with OS value
        metadata_dict["user_name"] = metadata_dict["user_name"] if metadata_dict["user_name"] else _get_username()

        # Override agent with constant value
        metadata_dict["agent"] = CODA_AGENT_NAME

        return metadata_dict
    except Exception as e:
        logger.error(f"Error extracting metadata: {e}")
        raise
