from pydantic import BaseModel, Field
from typing import Optional

class SessionMetadata(BaseModel):
    """Pydantic model for session metadata validation"""
    session_id: str = Field(..., description="Unique identifier for the session")
    task_id: str = Field(..., description="Unique identifier for the task")
    task_name: Optional[str] = Field(None, description="Name of the task")
    user_name: Optional[str] = Field(None, description="User Name associated with the session")
    agent: Optional[str] = Field(None, description="Agent used for sending metadata to the LLM")
    client: str = Field(..., description="Client used for calling coda-core")