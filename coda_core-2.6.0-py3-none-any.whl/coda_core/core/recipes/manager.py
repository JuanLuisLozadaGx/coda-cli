"""
Recipe management functionality for CODA Core.
"""

import os
import shutil
import importlib.resources
from typing import Dict, List, Optional, Tuple, Union
from loguru import logger
from pydantic import ValidationError

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.core.recipes.schemas import Recipe, RecipeMetadata


class RecipeManager:
    """
    Manages recipe files and provides functionality to load, list, and initialize recipes.
    """

    def __init__(self):
        """
        Initialize the RecipeManager.
        
        The recipes directory is determined from the environment configuration.
        """
        self.recipes_dir = SETTINGS.get_env_var(EnvConfig.CODA_RECIPES_DIR_PATH)

    def _parse_frontmatter(self, content: str, recipe_name: str = "") -> Tuple[Dict[str, str], str]:
        """
        Parse frontmatter from markdown content.
        
        Args:
            content: String content to parse
            recipe_name: Name of the recipe for default metadata
            
        Returns:
            Tuple[Dict[str, str], str]: (metadata dictionary, content without frontmatter)
        """
        # Default metadata as fallback
        metadata_dict = {"name": recipe_name, "description": "", "user_instructions": ""}
        recipe_content = content
        
        # Check if content has frontmatter
        if content.startswith('---'):
            parts = content.split('---', 2)
            if len(parts) >= 3:
                metadata_text = parts[1].strip()
                # Extract the actual content (after the second ---)
                recipe_content = parts[2].strip()
                
                # Parse metadata
                for line in metadata_text.splitlines():
                    if ':' in line:
                        key, value = line.split(':', 1)
                        key = key.strip()
                        value = value.strip()
                        metadata_dict[key] = value
        
        # Ensure name is set
        if "name" not in metadata_dict and recipe_name:
            metadata_dict["name"] = recipe_name
            
        return metadata_dict, recipe_content

    def initialize_default_recipes(self) -> bool:
        """
        Copy default recipe files to the user's recipes directory if they don't exist.
        
        Returns:
            bool: True if initialization was successful
        """
        try:
            # Check if we can access the default recipes package
            defaults_dir = importlib.resources.files('coda_core.config.prompts.recipes')

            if not defaults_dir.exists():
                logger.warning("Default recipes directory not found in package")
                return False

            # list files in defaults_dir
            DEFAULT_RECIPE_FILES = [file for file in defaults_dir.iterdir() if file.is_file() and file.name.endswith('.md')]

            success_count = 0
            for source_file in DEFAULT_RECIPE_FILES:
                dest_file = os.path.join(self.recipes_dir, source_file.name)
                
                # Only copy if destination doesn't exist
                if not os.path.exists(dest_file) and source_file.exists():
                    try:
                        shutil.copy2(source_file, dest_file)
                        success_count += 1
                        logger.info(f"Installed default recipe: {source_file.name}")
                    except Exception as e:
                        logger.warning(f"Failed to copy {source_file.name}: {e}")

            logger.info(f"Initialized {success_count} default recipes")
            return True
                
        except (ImportError, FileNotFoundError) as e:
            logger.warning(f"Could not initialize default recipes: {e}")
            return False

    def get_recipe_metadata(self, recipe_name: str) -> RecipeMetadata:
        """
        Extract metadata from a recipe file and validate using Pydantic.
        
        Args:
            recipe_name: Name of the recipe (without .md extension)
            
        Returns:
            RecipeMetadata: Validated recipe metadata
        """
        recipe_file = os.path.join(self.recipes_dir, f"{recipe_name}.md")
        
        # Default metadata for when file doesn't exist or has errors
        default_metadata = RecipeMetadata(name=recipe_name, description="", user_instructions="")
        
        if not os.path.exists(recipe_file):
            return default_metadata
            
        try:
            with open(recipe_file, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                
                # Parse frontmatter
                metadata_dict, _ = self._parse_frontmatter(content, recipe_name)
                
                # Try to validate with Pydantic
                try:
                    return RecipeMetadata(**metadata_dict)
                except ValidationError as e:
                    logger.warning(f"Recipe metadata validation failed: {e}")
                    return default_metadata
                    
        except Exception as e:
            logger.error(f"Error reading recipe metadata {recipe_file}: {e}")
            return default_metadata

    def list_recipes(self, return_objects: bool = False) -> Union[List[Recipe], List[str]]:
        """
        List all available recipe files in the recipes directory.
        
        Args:
            return_objects: If True, return Recipe objects; otherwise return recipe names
            
        Returns:
            List[Recipe] or List[str]: List of Recipe objects or recipe names
        """
        if not os.path.exists(self.recipes_dir):
            return []

        recipes = []
        recipe_objects = []
        
        try:
            for file in os.listdir(self.recipes_dir):
                if file.endswith('.md'):
                    # Remove .md extension for display
                    recipe_name = file[:-3]
                    recipes.append(recipe_name)
                    
                    # If objects are requested, load each recipe
                    if return_objects:
                        recipe_obj = self.load_recipe(recipe_name)
                        if recipe_obj:
                            recipe_objects.append(recipe_obj)
                        
        except Exception as e:
            logger.error(f"Error listing recipes: {e}")
        
        # Return either the list of names or the list of objects
        if return_objects:
            return recipe_objects
        else:
            return sorted(recipes)

    def load_recipe(self, recipe_name: str) -> Optional[Recipe]:
        """
        Load the content of a specific recipe file and validate with Pydantic.
        
        Args:
            recipe_name: Name of the recipe (without .md extension)
            
        Returns:
            Optional[Recipe]: Recipe object containing metadata and content, or None if not found
        """
        if not recipe_name:
            return None
            
        recipe_file = os.path.join(self.recipes_dir, f"{recipe_name}.md")
        file_path = os.path.abspath(recipe_file)
        
        if not os.path.exists(recipe_file):
            logger.warning(f"Recipe file not found: {recipe_file}")
            return None

        try:
            with open(recipe_file, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                
                # Parse frontmatter and content
                metadata_dict, recipe_content = self._parse_frontmatter(content, recipe_name)
                
                try:
                    # Create Recipe object with validated metadata
                    recipe = Recipe(
                        metadata=RecipeMetadata(**metadata_dict),
                        content=recipe_content,
                        file_path=file_path
                    )
                    logger.debug(f"Loaded recipe: {recipe_name}")
                    return recipe
                except ValidationError as e:
                    logger.warning(f"Recipe validation failed for {recipe_name}: {e}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error reading recipe file {recipe_file}: {e}")
            return None