from typing import Dict, Optional
from pydantic import BaseModel, ConfigDict, Field


class RecipeMetadata(BaseModel):
    """
    Validates recipe metadata from frontmatter
    """
    name: str = Field(..., description="Name of the recipe")
    description: str = Field(..., description="Description of what the recipe does")
    user_instructions: str = Field("", description="Instructions to guide users on expected input")
    
    model_config = ConfigDict(extra="ignore")


class Recipe(BaseModel):
    """
    Represents a complete recipe with metadata and content
    """
    metadata: RecipeMetadata = Field(..., description="Recipe metadata from frontmatter")
    content: str = Field(..., description="Content of the recipe")
    file_path: Optional[str] = Field(None, description="Path to the recipe file")
    
    @property
    def name(self) -> str:
        """
        Shortcut to access the recipe name
        """
        return self.metadata.name
    
    @property
    def description(self) -> str:
        """
        Shortcut to access the recipe description
        """
        return self.metadata.description
    
    @property
    def user_instructions(self) -> str:
        """
        Shortcut to access the recipe user instructions
        """
        return self.metadata.user_instructions
    
    def to_dict(self) -> Dict[str, str]:
        """
        Convert to a simple dictionary format for backward compatibility
        
        Returns:
            Dict[str, str]: Dictionary with name, description, and user_instructions
        """
        return {
            "name": self.name,
            "description": self.description,
            "user_instructions": self.user_instructions
        }