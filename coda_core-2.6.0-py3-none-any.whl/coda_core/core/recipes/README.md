# Recipes Module

The Recipes module provides functionality for managing, accessing, and applying pre-defined recipe templates to CODA conversations.

## Overview

Recipes are pre-defined templates or prompts that can be selected and applied to user conversations. They provide structured guidance for common tasks like bug diagnosis, creating unit tests, or security checks.

## Components

- **manager.py**: Contains the `RecipeManager` class that manages recipe files and provides functionality to load, list, and initialize recipes.
- **schemas.py**: Defines the data models for recipe metadata and content using Pydantic.

### RecipeManager (manager.py)

The `RecipeManager` class handles all recipe-related operations:

- `__init__()`: Initializes the RecipeManager with the recipes directory from environment settings
- `initialize_default_recipes()`: Copies default recipe files to the user's recipes directory
- `list_recipes()`: Lists all available recipe files in the recipes directory
- `load_recipe()`: Loads the content of a specific recipe file and validates it
- `get_recipe_metadata()`: Extracts metadata from a recipe file
- `_parse_frontmatter()`: Parses frontmatter from markdown content

### Recipe Models (schemas.py)

The module defines two main Pydantic models:

- `RecipeMetadata`: Validates recipe metadata from frontmatter
  - `name`: Name of the recipe
  - `description`: Description of what the recipe does
  - `user_instructions`: Instructions to guide users on expected input

- `Recipe`: Represents a complete recipe with metadata and content
  - `metadata`: Recipe metadata from frontmatter
  - `content`: Content of the recipe
  - `file_path`: Path to the recipe file
  - Helper properties: `name`, `description`, `user_instructions`
  - `to_dict()`: Converts to a simple dictionary format for backward compatibility

## Usage

Recipes are stored as markdown files in the user's `~/.coda/recipes` directory. Default recipes are installed automatically from the package's recipe templates.

```python
from coda_core.core.recipes import RecipeManager

# Initialize recipe manager
recipe_manager = RecipeManager()

# List available recipes
recipes = recipe_manager.list_recipes()

# Load a specific recipe
recipe_content = recipe_manager.load_recipe("security-check")

# Get recipe metadata
metadata = recipe_manager.get_recipe_metadata("security-check")
```

## Default Recipes

The module comes with several default recipes for common tasks:

- `create-tasks.md` - Explore the codebase, create a plan and break down in tasks
- `diagnose-bug.md` - Explore the codebase, analyze a bug and write a diagnostic report
- `explore-plan.md` - Framework for exploring and planning code changes
- `fix-bug.md` - Guidelines for fixing identified bugs
- `reproduce-bug.md` - Steps to reproduce and verify bugs
- `security-check.md` - Security review checklist
- `unit-tests-report.md` - Create a report that implements a plan to increase unit test coverage
- `upgrade.md` - Define notes and a plan to upgrade an application