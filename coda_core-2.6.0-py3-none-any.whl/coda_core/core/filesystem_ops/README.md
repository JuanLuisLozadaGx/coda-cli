# Filesystem Operations Module

## Overview

The Filesystem Operations Module provides a robust framework for managing file operations within the CODA Core application. This module enables safe and efficient file manipulation. Key capabilities include:

- File operations management for viewing, creating, replacing, and editing
- Safe handling of large files through chunked reading/writing
- Text manipulation with string replacement and line insertion
- Robust error handling and path validation

The module is designed to be reliable, efficient, and secure, with careful validation of all operations to prevent accidental file corruption or data loss.

## Architecture

The filesystem_ops module is designed with a modular architecture that separates concerns and provides clear responsibilities for each component:

```mermaid
flowchart TD
    A[FileEditor] --> D[Utils]
    D --> E[read_file]
    D --> F[write_file]
    D --> G[list_directory_contents]
    D --> H[lines_match]
    D --> J[make_output]
```

### Core Components

| Component | Responsibility | Key Features |
|-----------|----------------|--------------|
| **FileEditor** | Main entry point for file operations | • File viewing<br>• File creation<br>• File replacement<br>• Text editing<br>• Path validation |
| **Utils** | Provides utility functions | • Chunked file reading/writing<br>• Directory listing<br>• Line comparison<br>• Output formatting<br>• Error handling |

## Key Features

### File Operations

The module provides several core file operations:

| Operation | Description | Implementation |
|-----------|-------------|----------------|
| **View** | View file or directory contents | • Support for files and directories<br>• Line range selection<br>• Formatted output with line numbers<br>• Directory listing with nested structure |
| **Create** | Create new files | • Path validation<br>• Error handling<br>• Prevents accidental overwrites |
| **Replace** | Replace or create files | • Path validation<br>• Handles existing and new files |

### Text Editing

The module provides precise text editing capabilities:

| Feature | Description | Implementation |
|---------|-------------|----------------|
| **String Replacement** | Replace text in files | • Exact matching with whitespace normalization<br>• Context-aware replacement<br>• Error handling for ambiguous matches |
| **Line Insertion** | Insert text at specific lines | • Line-specific insertion<br>• Multi-line content support<br>• Boundary validation |

### Edit History and Undo Functionality

This functionality has been removed. The editor no longer tracks edit history or provides undo.

### Large File Handling

The module is designed to efficiently handle large files:

| Feature | Description | Implementation |
|---------|-------------|----------------|
| **Chunked Reading** | Read large files efficiently | • Memory-efficient chunk processing<br>• Configurable chunk size<br>• Error handling |
| **Chunked Writing** | Write large files efficiently | • Memory-efficient chunk processing<br>• Configurable chunk size<br>• Error handling |
| **Output Truncation** | Handle large outputs gracefully | • Line limit enforcement<br>• Truncation notices<br>• View range support |

### Error Handling and Validation

The module includes comprehensive error handling and validation:

| Feature | Description | Implementation |
|---------|-------------|----------------|
| **Path Validation** | Ensure valid file paths | • Absolute path checking<br>• Existence validation<br>• File vs. directory validation<br>• Command-specific validation |
| **Operation Validation** | Ensure valid operations | • Line range validation<br>• Insert position validation<br>• Replacement validation |
| **Error Reporting** | Provide clear error messages | • Detailed error messages<br>• Error categorization<br>• User-friendly feedback |

## Data Flow

The typical flow of operations in the filesystem_ops module follows this pattern:

```mermaid
flowchart TD
    A[User Request] --> B[FileEditor Method]
    B --> C[Path Validation]
    C -->|Valid| D[Read or Prepare Operation]
    C -->|Invalid| E[Error Response]
    D --> F[Process Operation]
    F --> G[Write Changes]
    G --> H[Format Response]
    H --> I[Return Result]
```

The filesystem operations follow these steps:

1. A user or component requests a file operation through the FileEditor
2. The FileEditor validates the file path and operation parameters
3. If validation fails, an error response is returned
4. If validation succeeds, the operation is processed:
   - For view operations: The file or directory contents are read and formatted
   - For create operations: The file is created with the provided content
   - For replace operations: The file is replaced or created with the provided content
   - For text editing operations: The file is read, modified, and written back
5. The result of the operation is returned with appropriate status and messages

## Integration

### Tool Integration

The filesystem_ops module is integrated with the CODA Core tool system:

- The view_tool uses the FileEditor's view method to display file and directory contents
- The edit_tool uses the FileEditor's text editing methods to modify files
- The replace_tool uses the FileEditor's replace method to create or replace files

### Error Handling and Reporting

The module provides consistent error handling and reporting:

- All methods return a dictionary with status information
- Error messages are detailed and user-friendly
- Errors are categorized by type (file not found, permission denied, validation error, etc.)
- The error reporting is designed to be easily consumed by tools and UIs

This consistent error handling allows tools to provide appropriate feedback to users and take corrective actions when possible.

## File Viewing Semantics and Metadata

This module provides a consistent, safe, and LLM-friendly contract for reading files and directories.

- Per-request safety cap
  - All reads (full or ranged) are capped per request by FILE_VIEW_MAX_LINES_CAP.
  - Use offset + limit pagination for large files.

- Range semantics
  1. No offset & no limit  -> return the entire file, capped at FILE_VIEW_MAX_LINES_CAP
  2. limit only            -> lines 1 .. min(limit, FILE_VIEW_MAX_LINES_CAP)
  3. offset only           -> lines offset .. end of file (subject to FILE_VIEW_MAX_LINES_CAP)
  4. offset + limit        -> at most min(limit, FILE_VIEW_MAX_LINES_CAP) lines starting at offset (may be fewer at EOF)

- Line numbering in output
  - File content is returned in “cat -n” style (e.g., “101: …”) preserving original numbering.
  - When using offset, line numbers start from offset. When no offset is provided, numbering starts at 1.

- Response schema (files vs directories)
  - Files return content and a metadata object:
    - start_line (int): starting 1-based line for the returned slice
    - end_line (int): last 1-based line for the returned slice
    - returned_lines (int): number of lines returned
    - has_more (bool): True if additional content exists beyond this slice
    - eof_reached (bool): True if EOF was reached within or exactly at this slice
    - truncated (bool): True only when the per-request cap engaged
  - Directories return a formatted listing and omit the metadata field entirely.

- Full-file reads (no offset/limit)
  - start_line is always 1
  - end_line equals returned_lines (0 for empty files)
  - truncated is True if and only if the per-request cap engaged
  - has_more is True if truncated; otherwise False
  - eof_reached is False if truncated; otherwise True

- Pagination guidance
  - If has_more is True, request the next slice with offset = end_line + 1 (keep limit unless you need to adjust).
  - If eof_reached is True or returned_lines == 0, you have reached the end of file.

- Error handling
  - If offset is beyond EOF, the operation succeeds with returned_lines == 0 (empty content).
  - If limit extends beyond EOF, fewer lines are returned and the result is not considered truncated.