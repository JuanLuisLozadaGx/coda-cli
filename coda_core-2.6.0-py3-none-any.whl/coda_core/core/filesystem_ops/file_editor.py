from pathlib import Path
from typing import List, Optional
import difflib
from loguru import logger

from coda_core.core.filesystem_ops.utils import (
    list_directory_contents, read_file, write_file, make_output, lines_match,
    detect_and_validate_encoding, detect_bom
)
from coda_core.core.filesystem_ops.constants import FILE_VIEW_MAX_LINES_CAP, TRUNCATION_FOOTER_TEMPLATE
from coda_core.core.filesystem_ops.file_reader import FileReader
from coda_core.core.filesystem_ops.types import MetadataResult, FileViewResult


class FileEditor:
    """
    High-level editor for viewing and modifying files and directories.

    - View operations return FileViewResult with numbered content for files or a directory listing for directories.
    - All reads are safety-capped per request (FILE_VIEW_MAX_LINES_CAP).
    - When the cap engages (full-file or ranged), a truncation footer line is appended to the content.
    - For files, metadata always includes integer start_line and end_line; directories omit metadata.
    """
    def __init__(self, reader: Optional[FileReader] = None):
        self.reader = reader or FileReader()


    def _validate_path(self, command: str, file_path: str) -> None:
        """
        Validate a file path based on the specified command.

        Args:
            command (str): The command being executed (e.g., 'create', 'replace', 'view').
            file_path (str): The path to the file being validated.

        Raises:
            ValueError: If the file path is invalid for the given command.
        """
        path = Path(file_path).resolve()

        if not path.is_absolute():
            logger.debug(f"The path {file_path} is not absolute.")
            raise ValueError(f"The path {file_path} is not an absolute path; it should start with `/`.")

        if command == 'create':
            if path.exists():
                logger.debug(f"File already exists at: {file_path}. Cannot overwrite files using command `create`.")
                raise ValueError(f"File already exists at: {file_path}. Cannot overwrite files using command `create`. Use `replace` instead.")
        elif command == 'replace':
            pass  # Allow creating new files and overwriting existing ones
        elif not path.exists():
            logger.debug(f"The path {file_path} does not exist.")
            raise ValueError(f"The path {file_path} does not exist. Please provide a valid path or use the `create` command to create a new file.")

        if path.is_dir() and command != 'view':
            logger.debug(f"The path {file_path} is a directory and only the `view` command can be used on directories.")
            raise ValueError(f"The path {file_path} is a directory and only the `view` command can be used on directories.")


    def _process_file_content(self, content: str, view_range: Optional[List[int]]) -> str:
        """
        Process the file content and apply the view range if specified.

        Args:
            content (str): The content of the file.
            view_range (Optional[List[int]]): A list of two integers specifying the range of lines to view.

        Returns:
            str: The processed content with line numbers.
        """
        lines = content.splitlines()
        init_line = 1

        if view_range:
            if len(view_range) != 2:
                logger.debug(f"Invalid `view_range`: {view_range}. It should be a list of two integers.")
                raise ValueError('Invalid `view_range`. It should be a list of two integers.')

            n_lines = len(lines)
            start_line, end_line = view_range

            # None or legacy -1 means "to EOF"
            if end_line in (None, -1):
                end_line = n_lines
            
            # Ensure start and end lines are within bounds
            start_line = max(1, start_line)
            end_line = min(n_lines, end_line)

            # Handle offset beyond EOF gracefully (return empty content)
            # This is better than an error for pagination semantics because:
            # - It isn't an invalid parameter (offset is positive); it just points past available data
            # - Mimics common APIs (e.g. SQL OFFSET beyond row count → empty set)
            # - Lets the caller (LLM) infer "no more content" without triggering error handling paths
            # - Prevents wasteful retry loops or misclassification as a tool failure
            # - Enables simple continuation logic: while content != "" keep paging
            if start_line > n_lines:
                lines = []
                init_line = start_line
            else:
                # Validate end_line relationship
                if end_line < start_line:
                    logger.debug(f"Invalid `view_range`: {view_range}. End line `{end_line}` should be greater than or equal to start line `{start_line}`.")
                    raise ValueError(f"Invalid `view_range`: {view_range}. End line `{end_line}` should be greater than or equal to start line `{start_line}`.")

                # Select the lines based on the specified range
                lines = lines[start_line - 1:end_line]
                init_line = start_line

        # Return content with line numbers
        return '\n'.join(f"{i + init_line}: {line}" for i, line in enumerate(lines))


    def _text_replace_or_insert(self, file_path: str, old_str: str = None, new_str: str = "", insert_line: int = None, snippet_lines: int = 4) -> dict:
        """
        Private method to modify a file by replacing a specified string with a new string or inserting a string at a specific line.

        Args:
            file_path (str): The path to the file to be modified.
            old_str (str, optional): The string to be replaced in the file. If empty, `insert_line` must be provided.
            new_str (str): The new string to insert or replace with.
            insert_line (int, optional): The line number at which to insert the string. Required if `old_str` is empty.
            snippet_lines (int, optional): The number of lines before and after the edit to include in the snippet. Default is 4.

        Returns:
            dict: A dictionary containing the operation status with the following keys:
                - "status" (str): "success" if the modification was performed, otherwise "error".
                - "file" (str): The path of the file that was processed.
                - "message" (str): A detailed message regarding the operation's outcome.
        """
        try:
            self._validate_path('text_replace_or_insert', file_path)                   # "replace_or_insert" is not a command, but we just need this function to validate the path's existence
            
            # Detect original encoding to preserve it when writing back
            bom_encoding = detect_bom(file_path)
            if bom_encoding:
                original_encoding = bom_encoding
            else:
                original_encoding = detect_and_validate_encoding(file_path)
            
            # Read file using the previously detected encoding to avoid duplicate detection
            file_content = read_file(file_path, encoding=original_encoding).expandtabs()
            new_str = new_str.expandtabs()

            file_lines = file_content.split('\n')

            # str_replace operation
            if old_str is not None:
                old_str = old_str.expandtabs()
                old_lines = old_str.split('\n')
                n = len(old_lines)
                found_indices = []

                # Find occurrences of old_str
                for i in range(len(file_lines) - n + 1):
                    segment = file_lines[i:i + n]
                    if all(lines_match(a, b) for a, b in zip(segment, old_lines)):
                        found_indices.append(i)

                if not found_indices:
                    logger.debug(f'No replacement was performed; `old_str` did not match any lines in {file_path}.')
                    raise ValueError(
                        f'No replacement was performed; `old_str` did not match any consecutive lines in {file_path}.'
                    )
                elif len(found_indices) > 1:
                    line_numbers = [idx + 1 for idx in found_indices]
                    logger.debug(f'No replacement was performed; `old_str` matched multiple occurrences at lines {line_numbers}.')
                    raise ValueError(
                        f'No replacement was performed. `old_str` matched multiple occurrences at lines {line_numbers}. '
                        'Please provide more context to make it unique.'
                    )

                # Perform replacement
                index = found_indices[0]
                new_lines = new_str.split('\n')
                new_file_lines = file_lines[:index] + new_lines + file_lines[index + n:]
            
            # insert operation
            elif insert_line is not None:
                n_lines_file = len(file_lines)
                if insert_line < 0 or insert_line > n_lines_file:
                    logger.debug(f'Invalid `insert_line` parameter: {insert_line}. It should be within the range [0, {n_lines_file}].')
                    raise ValueError(
                        f'Invalid `insert_line` parameter: {insert_line}. It should be within the range [0, {n_lines_file}].'
                    )

                # Perform insertion
                new_lines = new_str.split('\n')
                new_file_lines = file_lines[:insert_line] + new_lines + file_lines[insert_line:]
            else:
                logger.debug('Either `old_str` or `insert_line` must be specified.')
                raise ValueError('Either `old_str` or `insert_line` must be specified.')

            new_file_content = '\n'.join(new_file_lines)

            # Write changes back using the same encoding
            write_file(file_path, new_file_content, encoding=original_encoding)

            # Generate diff lines for the edit and prefix for display
            old_lines = file_content.splitlines(keepends=True)
            new_lines = new_file_content.splitlines(keepends=True)
            raw_diff = difflib.unified_diff(
                old_lines, new_lines,
                fromfile=f'before {file_path}', tofile=f'after {file_path}',
                lineterm=''  # Set lineterm to empty to avoid extra newlines
            )
            # Strip newlines from raw diff lines and add our prefix
            diff_lines = [f"│ {line}" for line in raw_diff]

            # Create a snippet of the edited section
            start_line = max(0, (insert_line if insert_line is not None else index) - snippet_lines)
            end_line = (insert_line if insert_line is not None else index) + len(new_lines) + snippet_lines
            snippet_lines_content = new_file_lines[start_line:end_line]
            snippet = '\n'.join(snippet_lines_content)
            content_with_line_numbers = make_output(snippet, f'a snippet of {file_path}', start_line + 1)

            success_msg = f'The file {file_path} has been edited.\n{content_with_line_numbers}'
            success_msg += ' Review the changes and make sure they are as expected. Edit the file again if necessary.'

            return {
                "status": "success",
                "file": file_path,
                "message": success_msg,
                "diff": diff_lines
            }

        except Exception as e:
            logger.debug(f"Error modifying file {file_path}: {e}")
            return {"status": "error", "file": file_path, "message": str(e)}


    def view(self, file_path: str, view_range: Optional[List[int]] = None) -> FileViewResult:
        """
        View the contents of a file or directory.

        Behavior:
        - Directory path:
          - Returns a directory listing string. `view_range` is not allowed for directories.
        - File path, no view_range (full-file request):
          - Uses FileReader.read_with_safety_cap(file_path=file_path, max_lines=FILE_VIEW_MAX_LINES_CAP) to avoid loading huge files.
          - Applies presentation (line numbering starting at 1) via _process_file_content().
          - If the safety cap engages, a truncation footer is appended using TRUNCATION_FOOTER_TEMPLATE.
          - Metadata: start_line=1, end_line=returned_lines, truncated=bool(capped), has_more=bool(capped), eof_reached=not capped.
        - File path, ranged request (view_range=[start_line, end_line]):
          - end_line may be None or -1 to indicate "to EOF".
          - Uses FileReader.read_line_range_streaming(file_path=file_path, start_line=start_line, end_line=end_line|None) to stream only the requested lines (cap enforced per request).
          - Presentation (line numbering) is applied here, starting at start_line (cat -n style).
          - If the per-request cap engages, a truncation footer is appended.
          - Metadata: start_line=start_line, end_line=returned end line (1-based), truncated=True only when the cap engaged.

        Args:
            file_path (str): Absolute path to a file or directory (must be absolute).
            view_range (Optional[List[int]]): [start_line, end_line] (1-based, inclusive). For files only.
                - end_line=None or -1 means "to EOF".

        Returns:
            FileViewResult: On success for files, includes:
                - status: "success"
                - file: absolute file path
                - content: numbered content string
                - metadata:
                    - start_line (int): starting 1-based line for the returned slice
                    - end_line (int): last 1-based line for the returned slice
                    - returned_lines (int): number of lines returned
                    - has_more (bool): True if content exists beyond the slice
                    - eof_reached (bool): True if EOF was reached within or at the slice
                    - truncated (bool): True only when the per-request cap engaged
            On success for directories:
                - status: "success"
                - file: absolute directory path
                - content: directory listing string
                - metadata: omitted
            On error:
                - status: "error"
                - file: absolute path
                - message: error details
        """
        try:
            self._validate_path('view', file_path)
            path = Path(file_path)

            if path.is_dir():
                if view_range:
                    logger.debug('The `view_range` parameter is not allowed when `path` points to a directory.')
                    raise ValueError('The `view_range` parameter is not allowed when `path` points to a directory.')

                content = list_directory_contents(path)
                return FileViewResult(status="success", file=file_path, content=content)

            else:
                capped = False
                metadata: MetadataResult

                if view_range is None:
                    # No-params path (full-file view with safety cap):
                    # - Stream up to FILE_VIEW_MAX_LINES_CAP lines via FileReader to avoid full-file load
                    # - Then apply numbering starting at 1 via _process_file_content (presentation kept here)
                    content, capped = self.reader.read_with_safety_cap(file_path=file_path, max_lines=FILE_VIEW_MAX_LINES_CAP)
                    content_with_line_numbers = self._process_file_content(content=content, view_range=view_range)

                    returned_lines = 0 if content == "" else len(content.split('\n'))
                    # For full-file views, always report explicit bounds for the returned slice:
                    # - start_line is 1
                    # - end_line equals returned_lines (0 when the file is empty)
                    metadata = MetadataResult(
                        start_line=1,
                        end_line=returned_lines,
                        returned_lines=returned_lines,
                        has_more=bool(capped),
                        eof_reached=not capped,
                        truncated=bool(capped),
                    )
                else:
                    # Ranged request (offset/limit style): stream only requested window, no full-file read
                    if len(view_range) != 2:
                        logger.debug(f"Invalid `view_range`: {view_range}. It should be a list of two integers.")
                        raise ValueError('Invalid `view_range`. It should be a list of two integers.')
                    start_line_req, end_line_req = view_range
                    # Normalize legacy end=-1/None to "to EOF"
                    end_line_norm = None if end_line_req in (None, -1) else end_line_req

                    rr = self.reader.read_line_range_streaming(
                        file_path=file_path,
                        start_line=start_line_req,
                        end_line=end_line_norm
                    )

                    if rr.returned_lines > 0:
                        lines = rr.content_text.split('\n')
                        # Numbering starts at the requested start_line (cat -n style), preserving raw content
                        content_with_line_numbers = '\n'.join(
                            f"{start_line_req + i}: {line}" for i, line in enumerate(lines)
                        )
                    else:
                        content_with_line_numbers = ""

                    # Truncation indicates safety cap engagement
                    truncated_by_cap = (rr.returned_lines == FILE_VIEW_MAX_LINES_CAP and not rr.eof_reached)
 
                    metadata = MetadataResult(
                        start_line=start_line_req,
                        end_line=rr.end_line,
                        returned_lines=rr.returned_lines,
                        has_more=rr.has_more,
                        eof_reached=rr.eof_reached,
                        truncated=truncated_by_cap,
                    )

                # Append truncation footer whenever the per-request cap engages (full-file or ranged)
                if (view_range is None and capped) or (view_range is not None and metadata.truncated):
                    content_with_line_numbers += "\n\n" + TRUNCATION_FOOTER_TEMPLATE.format(max_lines=FILE_VIEW_MAX_LINES_CAP)

                return FileViewResult(
                    status="success",
                    file=file_path,
                    content=content_with_line_numbers,
                    metadata=metadata
                )

        except (FileNotFoundError, PermissionError, ValueError) as e:
            logger.debug(f"Error viewing file {file_path}: {e}")
            return FileViewResult(status="error", file=file_path, message=str(e))
        except Exception as e:
            logger.debug(f"An unexpected error occurred while viewing file {file_path}: {e}")
            return FileViewResult(status="error", file=file_path, message=f"An unexpected error occurred: {e}")


    def create(self, file_path: str, file_content: str) -> dict:
        """
        Create a new file with the specified content.

        This method validates the file path, writes the provided content to the file, and returns a status dictionary reflecting the outcome.

        Args:
            file_path (str): The path to the file to be created. The path should be valid and writable.
            file_content (str): The content to write to the file. Can be a large string handled in chunks.

        Returns:
            dict: A dictionary with the following keys:
                - "status" (str): "success" if the file was created successfully, otherwise "error".
                - "file" (str): The path of the file that was to be created.
                - "message" (str, optional): An error message if the creation failed.
        """
        try:
            self._validate_path('create', file_path)
            write_file(file_path, file_content)
            return {"status": "success", "file": file_path}
        except ValueError as e:
            logger.debug(f"Error creating file {file_path}: {e}")
            return {"status": "error", "file": file_path, "message": str(e)}
        except Exception as e:
            logger.debug(f"Unexpected error creating file {file_path}: {e}")
            return {"status": "error", "file": file_path, "message": f"Unexpected error: {str(e)}"}


    def replace(self, file_path: str, file_content: str) -> dict:
        """
        Replace or create a file with the provided content, allowing overwrites.

        This method validates the file path and writes new content to the file.
        For existing files, it attempts to preserve the original encoding if the new
        content is compatible. For new files, it uses UTF-8.

        Args:
            file_path (str): The path to the file to be replaced or created.
            file_content (str): The content to write to the file.

        Returns:
            dict: A dictionary containing the operation status with the following keys:
                - "status" (str): "success" if the file was replaced/created successfully, otherwise "error".
                - "file" (str): The path of the file that was processed.
                - "message" (str, optional): An error message if the operation failed.
        """
        try:
            self._validate_path('replace', file_path)
            
            path = Path(file_path)
            encoding_to_use = 'utf-8'  # Default for new files
            
            # If file exists, try to preserve original encoding
            if path.exists() and path.is_file():
                # Detect original encoding
                bom_encoding = detect_bom(file_path)
                if bom_encoding:
                    original_encoding = bom_encoding
                else:
                    original_encoding = detect_and_validate_encoding(file_path)
                
                # Try to encode new content with original encoding
                try:
                    file_content.encode(original_encoding)
                    # Content is compatible with original encoding, use it
                    encoding_to_use = original_encoding
                except (UnicodeEncodeError, LookupError):
                    # Content not compatible, fall back to UTF-8
                    encoding_to_use = 'utf-8'
            
            # Write the new content to the file with chosen encoding
            write_file(file_path, file_content, encoding=encoding_to_use)
            return {"status": "success", "file": file_path}
            
        except Exception as e:
            logger.debug(f"Error replacing file {file_path}: {e}")
            return {"status": "error", "file": file_path, "message": str(e)}


    def str_replace(self, file_path: str, old_str: str, new_str: str, snippet_lines: int = 4) -> dict:
        """
        Replace a specified string in the file with a new string.

        Args:
            file_path (str): The path to the file to be modified.
            old_str (str): The string to be replaced in the file.
            new_str (str): The new string to insert in place of the old string.
            snippet_lines (int, optional): The number of lines before and after the edit to include in the snippet. Default is 4.

        Returns:
            dict: A dictionary containing the operation status with the following keys:
                - "status" (str): "success" if the replacement was performed, otherwise "error".
                - "file" (str): The path of the file that was processed.
                - "message" (str): A detailed message regarding the operation's outcome.
        """
        return self._text_replace_or_insert(file_path, old_str=old_str, new_str=new_str, snippet_lines=snippet_lines)


    def insert(self, file_path: str, insert_line: int, new_str: str, snippet_lines: int = 4) -> dict:
        """
        Insert a string at a specific line in the file.

        Args:
            file_path (str): The path to the file where the string will be inserted.
            insert_line (int): The line number at which to insert the string. 
            new_str (str): The string to be inserted, which can span multiple lines.
            snippet_lines (int, optional): The number of lines before and after the inserted text to include in the snippet. Default is 4.

        Returns:
            dict: A dictionary containing the operation status with the following keys:
                - "status" (str): "success" if the insertion was performed, otherwise "error".
                - "file" (str): The path of the file that was processed.
                - "message" (str): A detailed message regarding the operation's outcome.
        """
        return self._text_replace_or_insert(file_path, new_str=new_str, insert_line=insert_line, snippet_lines=snippet_lines)
