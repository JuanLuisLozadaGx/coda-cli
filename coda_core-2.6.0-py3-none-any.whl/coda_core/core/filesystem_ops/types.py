from dataclasses import dataclass, asdict
from typing import Dict, Optional


@dataclass(slots=True)
class RangeReadResult:
    """Result of a streaming ranged read.

    Attributes:
        content_text (str): The concatenated text for the requested window.
        returned_lines (int): Number of lines included in content_text.
        eof_reached (bool): True if EOF was reached within the requested window.
        has_more (bool): True if there is at least one more line beyond the requested end.
        end_line (int): The 1-based last line included in the returned window.
                        When no lines are returned (offset beyond EOF), this is start_line - 1.
    """
    content_text: str
    returned_lines: int
    eof_reached: bool
    has_more: bool
    end_line: int

@dataclass(slots=True)
class MetadataResult:
    """Metadata for file reading results.

    Attributes:
        start_line (int): Starting 1-based line for the returned slice.
            - For full-file views this is 1.
        end_line (int): Ending 1-based line for the returned slice.
            - For full-file views this equals returned_lines (0 when file is empty).
        returned_lines (int): Number of lines returned in this response window.
        has_more (bool): True if additional content exists beyond the returned slice.
        eof_reached (bool): True only when EOF was actually reached within or exactly at the returned slice.
        truncated (bool): True only when the per-request safety cap limited the result.
    """
    start_line: int
    end_line: int
    returned_lines: int
    has_more: bool
    eof_reached: bool
    truncated: bool

@dataclass(slots=True)
class FileViewResult:
    """Result container.

    Attributes:
        status (str): "success" or "error".
        file (str): Absolute file or directory path.
        content (Optional[str]): Numbered content (for files) or directory listing. None on errors.
        message (Optional[str]): Error details when status == "error".
        metadata (Optional[MetadataResult]): Neutral metadata for file reads (None for directories or errors).
    """
    status: str
    file: str
    content: Optional[str] = None
    message: Optional[str] = None
    metadata: Optional[MetadataResult] = None

    def to_dict(self) -> Dict[str, object]:
        """Convert the result into a dictionary while omitting None fields.

        Returns:
            Dict[str, object]: A dictionary representation suitable for external consumers.
        """
        data: Dict[str, object] = {"status": self.status, "file": self.file}
        if self.content is not None:
            data["content"] = self.content
        if self.message is not None:
            data["message"] = self.message
        if self.metadata is not None:
            # Use asdict to support slotted dataclasses
            data["metadata"] = asdict(self.metadata)
        return data