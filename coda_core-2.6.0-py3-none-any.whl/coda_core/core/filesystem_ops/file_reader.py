from typing import Optional, List, Tuple
import itertools

from coda_core.core.filesystem_ops.utils import iter_text_lines
from coda_core.core.filesystem_ops.types import RangeReadResult
from coda_core.core.filesystem_ops.constants import FILE_VIEW_MAX_LINES_CAP


class FileReader:
    """Read-only filesystem helper for streaming text lines with robust encoding handling.

    Overview:
    - Neutral component: does not perform any presentation (no line-number prefixing, no footers).
    - Backed by iter_text_lines(), which detects text encodings and falls back to UTF‑8 with replacement.
    - Optimized for large files: supports safety-capped reads and inclusive ranged reads without loading the entire file.

    When to use:
    - Use read_with_safety_cap() for the "no-params" view path to guard against huge files.
    - Use read_line_range_streaming() for pagination (offset/limit style consumption).

    Notes:
    - All line numbers are 1-based.
    - Newline normalization is handled by iter_text_lines(); consumers receive text joined with '\\n'.
    - This class should not import any tool-layer types or constants to keep filesystem_ops decoupled.
    """

    def read_with_safety_cap(self, file_path: str, max_lines: int) -> Tuple[str, bool]:
        """Read up to max_lines lines from a text file, streaming without pre-counting.

        Purpose:
        - Used by the full-file "no-params" view path to avoid loading very large files.

        Behavior:
        - Iterates lines using iter_text_lines(file_path=...), which:
          - Detects encoding (via chardet) on a sample and decodes accordingly.
          - Falls back to UTF-8 with errors="replace" for robustness.
        - Stops after max_lines, returning (content, was_capped).
          - was_capped=True indicates more content exists beyond max_lines.

        Args:
            file_path: Absolute path to the file to read.
            max_lines: Safety cap line count (1-based sequential lines).

        Returns:
            Tuple[str, bool]: (content_text, was_capped)

        Examples:
            content, capped = reader.read_with_safety_cap("/path/to/file.txt", 1000)
            if capped:
                # Consider reissuing a ranged request via read_line_range_streaming()
                ...

        """
        lines: List[str] = []
        capped = False

        # Stream lines and enforce the safety cap without pre-scanning the file
        for i, line in enumerate(iter_text_lines(file_path=file_path), 1):
            if i > max_lines:
                capped = True
                break
            lines.append(line)

        return "\n".join(lines), capped

    def read_line_range_streaming(self, file_path: str, start_line: int, end_line: Optional[int]) -> RangeReadResult:
        """Stream a 1-based inclusive line range from a text file without full-file loading.

        Purpose:
        - Supports pagination and targeted reads for large files.

        Semantics:
        - start_line: first line to include (1-based, must be >= 1).
        - end_line:
          - None → read from start_line forward (subject to FILE_VIEW_MAX_LINES_CAP per request).
          - N (>= start_line) → read [start_line, N] inclusive (subject to FILE_VIEW_MAX_LINES_CAP per request).
        - If start_line is beyond EOF:
          - Returns RangeReadResult(content_text="", returned_lines=0, eof_reached=True, has_more=False).
        - This method performs no presentation and appends no footers; callers may append a footer if the cap engaged.

        Encoding and normalization:
        - Uses iter_text_lines(file_path=...) for encoding detection and UTF-8 replacement fallback.
        - Lines are returned joined by '\\n' without a trailing newline.

        Returns:
        - RangeReadResult:
          - content_text: concatenated lines within the returned slice.
          - returned_lines: number of lines returned.
          - eof_reached: True only when EOF was actually reached; False if we stopped due to cap or window end with more content.
          - has_more: True if additional content exists beyond the returned slice.
          - end_line: last 1-based line included; when start_line is beyond EOF, this is start_line - 1.

        Unified logic:
        - Single pass skips until start_line.
        - Collects while within requested window (if any) and under FILE_VIEW_MAX_LINES_CAP.
        - After stopping, probes one extra line (if available) to set has_more/eof_reached consistently.
        """
        lines: List[str] = []
        returned_lines = 0
        eof_reached = False
        has_more = False

        it = iter_text_lines(file_path=file_path)

        # Skip prefix lines efficiently. Still consumes/decodes the skipped lines (streaming iterator),
        # but avoids Python-level branch/continue overhead for large start_line.
        it = itertools.islice(it, start_line - 1, None)

        collected = False
        last_idx = start_line - 1
        capped = False

        try:
            for idx, line in enumerate(it, start=start_line):
                # If a bounded window was requested, stop when we step past it
                if end_line is not None and idx > end_line:
                    break

                # Include this line
                collected = True
                lines.append(line)
                returned_lines += 1
                last_idx = idx

                # Enforce per-request cap
                if returned_lines >= FILE_VIEW_MAX_LINES_CAP:
                    capped = True
                    break

                # Stop at window end (bounded request)
                if end_line is not None and idx == end_line:
                    break
        except StopIteration:
            pass

        if not collected:
            # start_line beyond EOF → explicit empty window
            return RangeReadResult(
                content_text="",
                returned_lines=0,
                eof_reached=True,
                has_more=False,
                end_line=start_line - 1,
            )

        # Probe one additional line to determine continuation if needed:
        # - Always probe when capped.
        # - Probe when bounded window ended exactly at end_line.
        # - For offset-only (end_line None) and not capped, if the loop ended without StopIteration, we need to
        #   determine whether we hit EOF or just stopped; probing clarifies that.
        need_probe = capped or (end_line is not None and last_idx >= end_line) or (end_line is None and not capped)

        if need_probe:
            try:
                _ = next(it)
                has_more = True
                eof_reached = False
            except StopIteration:
                has_more = False
                eof_reached = True

        end_line_resp = last_idx if returned_lines > 0 else start_line - 1

        return RangeReadResult(
            content_text="\n".join(lines),
            returned_lines=returned_lines,
            eof_reached=eof_reached,
            has_more=has_more,
            end_line=end_line_resp,
        )