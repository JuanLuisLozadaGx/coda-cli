from typing import Final


ENCODING_DETECT_SAMPLE_BYTES: Final[int] = 8192
CHUNK_SIZE: Final[int] = 65536  # 64KB chunks - balance between memory and I/O efficiency

# File viewing safety defaults
FILE_VIEW_MAX_LINES_CAP: Final[int] = 500
TRUNCATION_FOOTER_TEMPLATE: Final[str] = "[File truncated at {max_lines} lines for safety. Use offset/limit to paginate.]"