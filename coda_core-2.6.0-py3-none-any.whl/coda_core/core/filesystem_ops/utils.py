import os
import re
import codecs
from typing import List, Optional, Iterator
from pathlib import Path
import chardet

from coda_core.config.constants import FILE_EXTENSIONS, FILE_PATH_PATTERN
from coda_core.core.filesystem_ops.constants import ENCODING_DETECT_SAMPLE_BYTES, CHUNK_SIZE


def read_file(file_path: str, encoding: Optional[str] = 'utf-8', chunk_size: int = 1024 * 1024, detect_encoding: bool = False) -> str:
    """
    Read the content of a file in chunks to handle large files.

    Args:
        file_path (str): The path to the file to be read.
        encoding (Optional[str]): The encoding to use when reading the file. Default is 'utf-8'.
                                   If detect_encoding=True, this parameter is ignored.
        chunk_size (int): The size of each chunk to read in bytes (default is 1 MB).
        detect_encoding (bool): If True, auto-detect file encoding and use it for reading.
                                Preserves BOM if present. Default is False for backward compatibility.

    Returns:
        str: The content of the file.

    Raises:
        ValueError: If the file cannot be read due to a specific error.
        
    Note:
        When detect_encoding=True, the function uses the same encoding detection logic
        as the VIEW tool (detect_and_validate_encoding) to ensure consistency.
    """
    # Auto-detect encoding if requested
    if detect_encoding:
        # Check for BOM first
        bom_encoding = detect_bom(file_path)
        if bom_encoding:
            encoding = bom_encoding
        else:
            encoding = detect_and_validate_encoding(file_path)
    
    content = []
    try:
        # Use errors='replace' as fallback when auto-detecting to handle edge cases gracefully
        errors_mode = 'replace' if detect_encoding else 'strict'
        
        with open(file_path, 'r', encoding=encoding, errors=errors_mode) as file:
            while chunk := file.read(chunk_size):   # Reading in chunks improves performance for large files
                content.append(chunk)
        return ''.join(content)
    except FileNotFoundError:
        raise ValueError(f"File not found: {file_path}")
    except PermissionError:
        raise ValueError(f"Permission denied: {file_path}")
    except OSError as e:
        raise ValueError(f"OS error reading file {file_path}: {e}")


def write_file(file_path: str, content: str, encoding: Optional[str] = 'utf-8', chunk_size: int = 1024 * 1024, errors: str = 'strict') -> None:
    """
    Write content to a file in chunks to handle large content.

    Args:
        file_path (str): The path to the file to be written.
        content (str): The content to write to the file.
        encoding (Optional[str]): The encoding to use when writing the file.
        chunk_size (int): The size of each chunk to write in bytes (default is 1 MB).
        errors (str): Error handling strategy for encoding errors. Default is 'strict'.

    Raises:
        ValueError: If the file cannot be written to due to a specific error.
    """
    try:
        with open(file_path, 'w', encoding=encoding, errors=errors) as file:
            for i in range(0, len(content), chunk_size):    # Writing in chunks improves performance for large files
                file.write(content[i:i + chunk_size])
    except FileNotFoundError:
        raise ValueError(f"File not found when trying to write: {file_path}")
    except PermissionError:
        raise ValueError(f"Permission denied: {file_path}")
    except OSError as e:
        raise ValueError(f"OS error writing to file {file_path}: {e}")
    

def list_directory_contents(path: Path) -> str:
    """
    List the contents of a directory up to two levels deep.

    Args:
        path (Path): The path to the directory.

    Returns:
        str: A string representation of the directory contents.
    """
    entries = []
    
    # Iterate over the first level of directory contents
    for child in sorted(path.iterdir()):
        if child.name.startswith('.'):
            continue  # Skip hidden files and directories

        if child.is_dir():
            entries.append(f"{child.name}/")
            # Iterate over the second level of directory contents
            try:
                for subchild in sorted(child.iterdir()):
                    if subchild.name.startswith('.'):
                        continue  # Skip hidden files and directories

                    if subchild.is_dir():
                        entries.append(f"{child.name}/{subchild.name}/")
                    else:
                        entries.append(f"{child.name}/{subchild.name}")
            except PermissionError:
                # Handle cases where access to a subdirectory is denied
                entries.append(f"{child.name}/ (access denied)")
        else:
            entries.append(child.name)

    return '\n'.join(entries)


def lines_match(line1: str, line2: str) -> bool:
    """
    Helper method to compare two lines, ignoring differences in whitespace.

    This method considers two lines as matching if they contain the same characters in the same order, 
    disregarding any differences in whitespace such as spaces, tabs, or newlines.

    Args:
        line1 (str): The first line to compare.
        line2 (str): The second line to compare.

    Returns:
        bool: True if the lines match when ignoring whitespace, otherwise False.
    """
    # Remove all whitespace characters and compare the resulting strings
    normalized_line1 = ''.join(line1.split())
    normalized_line2 = ''.join(line2.split())
    return normalized_line1 == normalized_line2


def truncate_output(content: str, max_output_lines: int = 800) -> str:
    """
    Truncate the output if it exceeds the maximum allowed lines.

    Args:
        content (str): The content to potentially truncate.
        max_output_lines (int, optional): The maximum number of lines allowed in the output. Default is 800.

    Returns:
        str: The truncated content with a notice if it was truncated.
    """
    lines = content.split('\n')
    if len(lines) > max_output_lines:
        truncated_content = '\n'.join(lines[:max_output_lines])
        truncated_content += (
            '\n<response clipped: content exceeds maximum allowed lines>'
            '\nTo view more, please specify a `view_range` parameter.'
        )
        return truncated_content
    return content


def make_output(content: str, description: str, init_line: int = 1, max_output_lines: int = 800) -> str:
    """
    Generate output with line numbers and handle truncation.

    Args:
        content (str): The content to format with line numbers.
        description (str): A description of the file or content being processed.
        init_line (int, optional): The initial line number for numbering. Default is 1.
        max_output_lines (int, optional): The maximum number of lines allowed in the output. Default is 800.

    Returns:
        str: The formatted content with line numbers and truncation handled.
    """
    content = content.expandtabs()
    lines = content.split('\n')
    content_with_line_numbers = '\n'.join(f"{i + init_line:6}\t{line}" for i, line in enumerate(lines))
    content_with_line_numbers = truncate_output(content_with_line_numbers, max_output_lines)
    return (
        f"Here's the result of running `cat -n` on {description}:\n"
        f"{content_with_line_numbers}\n"
    )


def extract_file_paths(text: str) -> List[str]:
    """Extract image file paths from input text without modifying the original text.

    Returns a list of absolute image paths found in the input.
    
    This function handles multiple paths that might be concatenated without spaces
    and text that immediately follows a path without a space.
    
    Returns:
        List[str]: List of absolute file paths found
    """
    # Find all potential paths using the pattern from constants
    matches = re.finditer(FILE_PATH_PATTERN, text, re.VERBOSE)
    
    found_paths = []
    
    for match in matches:
        # Get the actual path from whichever group matched
        path = next(group for group in match.groups() if group is not None)
        
        # Expand user directory if needed
        expanded_path = os.path.expanduser(path)
        
        # Check if it's a valid image file
        ext = os.path.splitext(expanded_path)[1].lower()
        if os.path.isfile(expanded_path) and ext in FILE_EXTENSIONS:
            abs_path = os.path.abspath(expanded_path)
            found_paths.append(abs_path)

    # Return original text unchanged
    return found_paths


def detect_text_encoding(file_path: str, sample_bytes: int = ENCODING_DETECT_SAMPLE_BYTES) -> str:
    """Detect a text file's encoding using a small binary sample and chardet.

    Args:
        file_path (str): Path to the file to inspect.
        sample_bytes (int): Number of leading bytes to sample for detection.

    Returns:
        str: Best-guess encoding label. Falls back to 'utf-8' if undetected.

    Raises:
        ValueError: If the file cannot be opened due to not found, permission, or OS error.
    """
    try:
        with open(file_path, 'rb') as fbin:
            raw = fbin.read(sample_bytes)
    except FileNotFoundError:
        raise ValueError(f"File not found: {file_path}")
    except PermissionError:
        raise ValueError(f"Permission denied: {file_path}")
    except OSError as e:
        raise ValueError(f"OS error reading file {file_path}: {e}")

    detected = chardet.detect(raw) or {}
    encoding = detected.get('encoding') or 'utf-8'
    return encoding


def detect_and_validate_encoding(file_path: str) -> str:
    """Detect and validate a file's text encoding with robust fallback.

    Uses the same detection and validation logic as iter_text_lines() to ensure
    consistency across VIEW, EDIT, and REPLACE tools.

    Detection strategy:
    1. Use chardet on a sample of bytes (detect_text_encoding)
    2. Validate by attempting to decode the entire file in chunks
    3. Fall back to 'utf-8' with errors='replace' if validation fails

    Args:
        file_path (str): Path to the file to inspect.

    Returns:
        str: Validated encoding name. Returns 'utf-8' as fallback if detection/validation fails.

    Raises:
        ValueError: If the file cannot be opened due to not found, permission, or OS errors.
    """
    encoding = detect_text_encoding(file_path=file_path)
    
    # Validate encoding by reading file in chunks to avoid loading massive files into memory
    encoding_valid = False
    
    try:
        decoder = codecs.getincrementaldecoder(encoding)(errors='strict')
        with open(file_path, 'rb') as f:
            while True:
                chunk = f.read(CHUNK_SIZE)
                if not chunk:
                    break  # End of file reached
                decoder.decode(chunk, False)  # State preserved between calls
            decoder.decode(b'', True)  # Final flush to catch incomplete sequences at EOF
        encoding_valid = True
    except (UnicodeError, LookupError):
        # Detected encoding is invalid, will use UTF-8 fallback
        # Note: UnicodeError catches both UnicodeDecodeError and UnicodeError (e.g., UTF-16 BOM issues)
        encoding_valid = False
    except FileNotFoundError:
        raise ValueError(f"File not found: {file_path}")
    except PermissionError:
        raise ValueError(f"Permission denied: {file_path}")
    except OSError as e:
        raise ValueError(f"OS error reading file {file_path}: {e}")
    
    return encoding if encoding_valid else 'utf-8'


def detect_bom(file_path: str) -> Optional[str]:
    """Detect if a file has a BOM (Byte Order Mark) and return the BOM type.

    Args:
        file_path (str): Path to the file to inspect.

    Returns:
        Optional[str]: 'utf-8-sig' if UTF-8 BOM is present, None otherwise.
                      This matches Python's encoding name for UTF-8 with BOM.

    Raises:
        ValueError: If the file cannot be opened.
    """
    try:
        with open(file_path, 'rb') as f:
            header = f.read(3)
            # Check for UTF-8 BOM (0xEF 0xBB 0xBF)
            if header.startswith(b'\xef\xbb\xbf'):
                return 'utf-8-sig'
            return None
    except FileNotFoundError:
        raise ValueError(f"File not found: {file_path}")
    except PermissionError:
        raise ValueError(f"Permission denied: {file_path}")
    except OSError as e:
        raise ValueError(f"OS error reading file {file_path}: {e}")


def iter_text_lines(file_path: str) -> Iterator[str]:
    """Yield text lines from a file with encoding detection and robust fallback.

    This iterator:
    - Detects and validates encoding via detect_and_validate_encoding(file_path).
    - Falls back to UTF-8 with replacement if decoding fails.
    - Yields each line with trailing newline characters removed, preserving other whitespace.
    - Uses chunked validation for memory-safe handling of large files.

    Args:
        file_path (str): Path to the file to iterate.

    Yields:
        Iterator[str]: Each line with trailing newline characters stripped.

    Raises:
        ValueError: If the file cannot be opened due to not found, permission, or OS errors.
    """
    # Use the same detection and validation logic as detect_and_validate_encoding
    encoding = detect_and_validate_encoding(file_path)
    
    # encoding is already validated; utf-8 fallback is handled by detect_and_validate_encoding
    # Use errors='replace' for additional safety in case of edge cases
    with open(file_path, 'r', encoding=encoding, errors='replace') as f:
        for line in f:
            yield line.rstrip('\n\r')