import os
import time
import threading
import psutil
from datetime import datetime, timedelta
from tinydb import Query

from typing import Dict, List, Optional

from loguru import logger

from coda_core.config.settings import SETTINGS, EnvConfig
from coda_core.config.logging.context import set_session_context, clear_session_context, capture_session_context, restore_session_context

from coda_core.core.session.session import Session
from coda_core.core.session.states.shared_state import SharedState
from coda_core.core.session.states.client_state import ClientState
from coda_core.core.session.database.database_manager import DatabaseManager
from coda_core.core.session.utils import extract_user_messages_with_metadata, generate_session_name
from coda_core.core.session.constants import MEMORY_KEY_MAIN



class SessionManager:
    """
    Manages session operations such as creation, saving, loading, listing, deletion,
    renaming, and locking.

    This class uses TinyDB with SQLite storage for persistent storage of session data,
    leveraging SQLite's built-in concurrency handling to prevent conflicts between
    multiple clients. It also provides features like auto-saving and lock monitoring
    to ensure session consistency and recovery.

    Attributes:
        db_path (str): Path to the SQLite database file
        table_name (str): Name of the table in the database for storing sessions
        small_model_name (str): Default small model name for LLM operations
        small_provider_name (str): Default small provider name for LLM operations
        db_manager (DatabaseManager): Manager for database operations with SQLite backend
        current_session (Session): The currently active session
        auto_save_interval (int): Interval in seconds between automatic session saves
        auto_save_thread (Thread): Background thread for periodic auto-saving
        auto_save_running (bool): Flag indicating if the auto-save thread is running
        lock_monitor_thread (Thread): Background thread for monitoring session locks
        lock_monitor_running (bool): Flag indicating if the lock monitor thread is running
        lock_monitor_interval (int): Interval in seconds between lock monitoring checks
        last_rename_info (dict): Information about the last session rename operation
        process_id (int): Current process ID used for session locking
        exit_handler_registered (bool): Flag indicating if the exit handler is registered
        rename_thread (Thread): Thread for renaming sessions using LLM calls
    """
    
    def __init__(self, auto_save_interval: int = 300) -> None:
        """
        Initialize the session manager.
        
        Args:
            auto_save_interval (int): Interval in seconds between auto-saves (default: 5 minutes)
        """
        self.db_path = SETTINGS.get_env_var(EnvConfig.CODA_SESSION_DB_FILE_PATH)
        self.table_name = SETTINGS.get_env_var(EnvConfig.CODA_SESSION_DB_TABLE_NAME)
        self.small_model_name = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SMALL_MODEL_NAME)
        self.small_provider_name = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SMALL_PROVIDER_NAME)

        # Create the database manager
        self.db_manager = DatabaseManager(self.db_path, self.table_name)
        
        self.current_session = None
        self.auto_save_interval = auto_save_interval
        self.auto_save_thread = None
        self.auto_save_running = False
        
        # Lock monitoring attributes
        self.lock_monitor_thread = None
        self.lock_monitor_running = False
        self.lock_monitor_interval = 300  # 5 minutes default
        
        # Store info about the last rename operation
        self.last_rename_info = {
            "old_name": None,
            "new_name": None,
            "rename_method": None
        }
        self.process_id = os.getpid()
        self.exit_handler_registered = False
        
        # Thread for session renaming
        self.rename_thread = None
        
        
        
    def initialize(self) -> None:
        """
        Initialize the session manager and ensure DB exists.
        
        This method initializes the database manager and cleans up any stale locks.
        """
        # Initialize the database
        self.db_manager.initialize()
        
        # Clean up any stale locks
        self.check_and_clean_locks()
        
        # Run garbage collection for old sessions
        self.cleanup_old_sessions()
        
        logger.info("Session manager initialized successfully")

    def create_session(self, name: Optional[str] = None, id: Optional[str] = None) -> Session:
        """
        Create a new session.
        
        This method creates a new session, locks it with the current process ID,
        and starts auto-save for the new session.
        
        Args:
            name: Optional name for the session. If not provided, a default name will be used.
            id: Optional ID for the session. If not provided, `Session` constructor will assign one .
        Returns:
            The created Session object
        """
        # Stop auto-save for previous session
        self.stop_auto_save()
        
        # Unlock previous session if any
        if self.current_session:
            self.unlock_session(self.current_session.id)
            # Clear previous session context
            clear_session_context()
        
        # Create new session with id cast to string if provided
        if id is not None: 
            id = str(id)
        self.current_session = Session(name=name, id=id)
        
        # Lock the new session with the current process ID
        self.current_session.lock(self.process_id)
        
        # Set session context for logging
        set_session_context(
            session_id=self.current_session.id,
            session_name=self.current_session.name
        )
        
        # Start auto-save for new session
        self.start_auto_save()
        
        return self.current_session


    def save_session(
        self,
        shared_state: Optional['SharedState'] = None,
        client_state: Optional['ClientState'] = None,
        client_type: Optional[str] = None,
        session: Optional[Session] = None
    ) -> str:
        """
        Save the current session or a provided session with updated state.

        This method saves the current session or a provided session with updated shared and client state.
        If no current session exists and no session is provided, a new session will be created.

        Args:
            shared_state (Optional[SharedState]): SharedState instance to save.
            client_state (Optional[ClientState]): ClientState instance to save.
            client_type (Optional[str]): Type of client.
            session (Optional[Session]): Specific Session instance to save. If None, saves current session or creates a new one.

        Returns:
            (str): ID of the saved session.
        """
        # If a specific session is provided, prioritize saving that one
        session_to_save = session or self.current_session

        if not session_to_save:
            # Only create a new session if none is provided and no current session exists
            self.current_session = self.create_session()
            session_to_save = self.current_session

        # Update session timestamp
        session_to_save.updated_at = datetime.now()

        # Update shared state if provided
        if shared_state:
            session_to_save.shared_state = shared_state.to_dict()

        # Update client state if provided
        if client_state and client_type:
            session_to_save.set_client_state(client_type, client_state.to_dict())

        # Save to database with timestamp-based conflict resolution
        session_data = session_to_save.to_dict()

        # SQLite handles concurrency internally, so we don't need to worry about locking
        with self.db_manager.get_db() as (db, sessions_table):
            # Use upsert with Query to handle potential conflicts
            existing = sessions_table.get(Query().id == session_to_save.id)
            if existing:
                existing_updated = datetime.fromisoformat(existing.get("updated_at"))
                current_updated = session_to_save.updated_at

                # Only update if current session is newer
                if current_updated > existing_updated:
                    sessions_table.update(session_data, Query().id == session_to_save.id)
            else:
                # New session, just insert
                sessions_table.insert(session_data)

        return session_to_save.id
    
    
    def load_session(self, session_id: str) -> Session:
        """
        Load a session by ID.
        
        Args:
            session_id (str): ID of the session to load
            
        Returns:
            The loaded Session object
            
        Raises:
            ValueError: If session with given ID is not found or is locked
        """
        # Stop auto-save for previous session
        self.stop_auto_save()
        
        # Unlock previous session if any
        if self.current_session:
            self.unlock_session(self.current_session.id)
            # Clear previous session context
            clear_session_context()
        
        # Get session data
        with self.db_manager.get_db() as (db, sessions_table):
            session_data = sessions_table.get(Query().id == session_id)
            
        if not session_data:
            raise ValueError(f"Session with ID {session_id} not found")
        
        # Create session object
        session = Session.from_dict(session_data)
        
        # Try to lock the session
        if not self.lock_session(session_id):
            raise ValueError(f"Session '{session.name}' is currently in use by another client")
        
        # Set as current session
        self.current_session = session
        
        # Set session context for logging
        set_session_context(
            session_id=session.id,
            session_name=session.name
        )
        
        # Start auto-save for loaded session
        self.start_auto_save()
        
        return self.current_session
    

    def list_sessions(self, include_locked: bool = True) -> list[dict]:
        """
        List all available sessions.
        
        Args:
            include_locked (bool): Whether to include locked sessions in the list
            
        Returns:
            List of session data dictionaries, sorted by updated_at (newest first)
        """
        # Clean up any stale locks first
        self.check_and_clean_locks()
        
        # Always query directly from the database to get fresh data
        with self.db_manager.get_db() as (db, sessions_table):
            sessions = sessions_table.all()
        
        # Filter out locked sessions if requested
        if not include_locked:
            sessions = [s for s in sessions if not Session.from_dict(s).is_locked()]
        
        return sorted(sessions, key=lambda x: x.get("updated_at"), reverse=True)
    

    def get_session_by_index(self, index: int, include_locked: bool = True) -> Optional[dict]:
        """
        Get a session dictionary by its display index.
        
        Args:
            index (int): The 1-based display index
            include_locked (bool): Whether to include locked sessions in the list
            
        Returns:
            dict: The session dictionary, or None if not found
        """
        # Get sorted sessions using existing method
        sessions = self.list_sessions(include_locked=include_locked)
        
        # Convert 1-based index to 0-based
        idx = index - 1
        
        if 0 <= idx < len(sessions):
            return sessions[idx]
        
        return None

    def delete_session(self, session_id: str) -> bool:
        """
        Delete a session by ID.
        
        Args:
            session_id (str): ID of the session to delete
            
        Returns:
            bool: True if session was deleted, False if it's locked by another process
        """
        # Check if session is locked by another process
        with self.db_manager.get_db() as (db, sessions_table):
            session_data = sessions_table.get(Query().id == session_id)
            
        if session_data:
            session = Session.from_dict(session_data)
            if session.is_locked() and not session.is_locked_by(self.process_id):
                return False
        
        # Delete the session
        with self.db_manager.get_db() as (db, sessions_table):
            sessions_table.remove(Query().id == session_id)
        
        # Delete related files
        self._delete_related_files(session_data)
        
        # If this was the current session, clear it
        if self.current_session and self.current_session.id == session_id:
            self.stop_auto_save()
            self.current_session = None
            
            # Clear session context for logging
            clear_session_context()
            logger.info("Session context cleared after session deletion")
        
        logger.info(f"Deleted session '{session.name}': {session.id}")

        return True
        
        
    def _delete_related_files(self, session_data: Dict) -> None:
        """
        Delete files related to a session, such as command history and tools files.
        
        Args:
            session_data: Dictionary containing session data
        """
        if not session_data:
            return
            
        try:
            # Get client states from session data
            client_states = session_data.get("client_states", {})
            
            # Delete command history file if CLI client state exists
            cli_state_data = client_states.get("cli")
            if cli_state_data and "command_history_id" in cli_state_data:
                command_history_id = cli_state_data["command_history_id"]
                command_history_path = os.path.join(SETTINGS.get_env_var(EnvConfig.CODA_COMMAND_HISTORY_DIR), f"{command_history_id}_command-history")
                
                if os.path.exists(command_history_path):
                    os.remove(command_history_path)
                    logger.info(f"Deleted command history file: {command_history_path}")
            
            # Delete tools configuration file
            tool_manager_config_id = session_data.get("shared_state", {}).get("tool_manager_config_id")
            if tool_manager_config_id:
                tools_config_path = os.path.join(SETTINGS.get_env_var(EnvConfig.CODA_TOOLS_DIR_PATH), f"{tool_manager_config_id}_tools.json")
                
                if os.path.exists(tools_config_path):
                    os.remove(tools_config_path)
                    logger.info(f"Deleted tools configuration file: {tools_config_path}")
                    
        except Exception as e:
            logger.error(f"Error deleting related files for session: {e}")
    

    def rename_session(self, session_id: str, new_name: str, rename_method: str = "manual") -> bool:
        """
        Rename a session.
        
        Args:
            session_id (str): ID of the session to rename
            new_name (str): New name for the session
            rename_method (str): How the rename was performed ('manual' or 'auto')
            
        Returns:
            bool: True if session was renamed, False if it couldn't be renamed
        """
        # Check if session exists and is not locked by another process
        with self.db_manager.get_db() as (db, sessions_table):
            session_data = sessions_table.get(Query().id == session_id)
            
        if not session_data:
            return False
            
        session = Session.from_dict(session_data)
        
        # Check if session is locked by another process
        if session.is_locked() and not session.is_locked_by(self.process_id):
            return False
            
        # For auto-renames, don't override manual renames
        if rename_method == "auto" and session.has_been_renamed(by_method="manual"):
            return False
        
        # Store old name for rename info
        old_name = session.name
        
        # Update the session name using the set_name method with rename method
        rename_success = session.set_name(new_name, rename_method)
        
        # If rename failed, return False
        if not rename_success:
            return False
        
        # Update the full session object in the database
        with self.db_manager.get_db() as (db, sessions_table):
            # Update the session in the database
            sessions_table.update(session.to_dict(), Query().id == session_id)
        
        # Update current session if this is the one being renamed
        if self.current_session and self.current_session.id == session_id:
            # Important: Use the already updated session object to avoid race conditions
            self.current_session.name_info = dict(session.name_info)
        
        # Store the rename info for later reference
        self.last_rename_info = {
            "old_name": old_name,
            "new_name": new_name,
            "rename_method": rename_method
        }
        
        return True


    def get_last_rename_info(self) -> dict:
        """
        Get information about the last session rename operation.
        
        Returns:
            dict: A dictionary with 'old_name', 'new_name', and 'rename_method' keys.
                 The 'rename_method' will be either 'manual' or 'auto' depending on
                 how the rename was performed.
        """
        return dict(self.last_rename_info)


    def rename_session_by_llm_call(self, session_id: str, shared_state: 'SharedState') -> bool:
        """
        Rename a session using an LLM call when there are enough user messages.
        
        This method checks if the main memory has at least two
        user messages. If it does, it makes an LLM call to generate a new session name.
        
        This method runs in a separate thread to avoid blocking the main thread.
        The old and new session names are stored in self.last_rename_info after completion.
        
        Args:
            session_id (str): ID of the session to rename
            shared_state: SharedState object containing memories
            
        Returns:
            bool: True if thread for renaming session was started, False otherwise
        """
        # Check if a rename thread is already running
        if hasattr(self, 'rename_thread') and self.rename_thread and self.rename_thread.is_alive():
            logger.info(f"Session rename thread is already running, skipping new rename request")
            return False
            
        # Additional validation before starting thread
        with self.db_manager.get_db() as (db, sessions_table):
            session_data = sessions_table.get(Query().id == session_id)
            
        if not session_data:
            logger.warning(f"Session data not found for ID: {session_id}")
            return False
            
        session = Session.from_dict(session_data)
        
        # Check if session is locked by another process
        if session.is_locked() and not session.is_locked_by(self.process_id):
            logger.warning(f"Session '{session_id}' is locked by another process")
            return False
            
        # Check if session has already been manually renamed
        if session.has_been_renamed(by_method="manual"):
            logger.info(f"Session '{session_id}' has already been manually renamed, skipping auto-rename")
            return False
        
        # Capture the current session context to pass to the background thread
        session_context = capture_session_context()
        
        # Start a new thread for renaming the session
        self.rename_thread = threading.Thread(
            target=self._session_rename_worker,
            args=(session_id, shared_state, session_context),
            daemon=True,
            name=f"SessionRenameThread-{session_id[:8]}"
        )
        
        # Start the rename thread
        self.rename_thread.start()

        return True


    def _session_rename_worker(self, session_id: str, shared_state: 'SharedState', session_context: Dict[str, Optional[str]]) -> None:
        """
        Worker thread for renaming a session using LLM.
        
        This worker thread handles the actual process of renaming a session:
        1. Fetches session data and verifies locking
        2. Gets message history from memory
        3. Calls LLM to generate a new name
        4. Renames the session and stores the old and new names in self.last_rename_info
        
        Args:
            session_id (str): ID of the session to rename
            shared_state: SharedState object containing memories
            session_context: The captured session context from the parent thread
        """
        try:
            # Restore the session context in this thread
            restore_session_context(session_context)
            
            logger.info(f"Session rename thread started")
            new_name = None

            # Re-validate conditions within the thread
            with self.db_manager.get_db() as (db, sessions_table):
                session_data = sessions_table.get(Query().id == session_id)
                
                # If session data is not found, return
                if not session_data:
                    logger.warning(f"Session data not found for ID: {session_id}")
                    return
                    
                session = Session.from_dict(session_data)
                
                # Re-check if session is locked by another process
                if session.is_locked() and not session.is_locked_by(self.process_id):
                    logger.warning(f"Session is locked by another process")
                    return
                
                # Re-check if session has already been manually renamed
                if session.has_been_renamed(by_method="manual"):
                    logger.info(f"Session has already been manually renamed, skipping auto-rename")
                    return
            
            # Get the main memory from shared state
            main_memory = shared_state.memories.get(MEMORY_KEY_MAIN)
            
            # Initialize combined_messages
            combined_messages = []
            
            # Add messages from main_memory if it exists
            if main_memory:
                combined_messages.extend(main_memory.retrieve())
            
            # If no memories are available, log and return
            if not combined_messages:
                logger.warning("No messages found in any memory for session name generation. Skipping rename.")
                return
            
            user_messages = extract_user_messages_with_metadata(combined_messages)
            if not user_messages:
                logger.warning("No user messages found for session name generation")
                return
            
            # Use the utility function to generate a session name
            result = generate_session_name(
                user_messages=user_messages,
                geai_client=shared_state.geai_client,
                model_name=self.small_model_name,
                provider_name=self.small_provider_name
            )
            
            # Add usage statistics to shared state
            if "usage" in result:
                shared_state.add_usage(result["usage"])
                logger.info(f"Added LLM usage from session name generation to usage statistics: {result['usage']}")
            
            # Check if generation was successful
            if result["status"] == "success":
                new_name = result["name"]
                logger.info(f"Generated session name: {new_name}")
            else:
                # Use a fallback name if generation failed
                logger.warning(f"Failed to generate session name: {result.get('error')}")
                
                client_states = self.current_session.client_states
                cli_state = client_states.get("cli", {})
                session_directory = cli_state.get("current_directory", "Unknown")
                new_name = f"session-{session_directory.replace('/', '-')}"
                logger.info(f"Using fallback session name: {new_name}")
                
            # Store original name before renaming
            old_name = session.name
            
            # Try to rename the session
            success = self.rename_session(session_id, new_name, rename_method="auto")
            
            if not success:
                logger.warning(f"Failed to auto-rename session - the session may have already been renamed")
                return
                
            logger.info(f"Session auto-renamed from '{old_name}' to '{new_name}' successfully")
            
        except Exception as e:
            logger.error(f"Error in session rename worker: {e}")


    def lock_session(self, session_id: str) -> bool:
        """
        Lock a session for exclusive use by this process.
        
        Args:
            session_id (str): ID of the session to lock
            
        Returns:
            bool: True if lock was acquired, False if already locked by another process
        """
        with self.db_manager.get_db() as (db, sessions_table):
            session_data = sessions_table.get(Query().id == session_id)
            
        if not session_data:
            return False
            
        session = Session.from_dict(session_data)
        
        # Try to lock the session
        if not session.lock(self.process_id):
            return False
        
        # Update the session in the database
        with self.db_manager.get_db() as (db, sessions_table):
            sessions_table.update(session.to_dict(), Query().id == session_id)
        return True
    

    def unlock_session(self, session_id: str) -> bool:
        """
        Unlock a session if locked by this process.
        
        Args:
            session_id (str): ID of the session to unlock
            
        Returns:
            bool: True if unlock was successful, False if locked by another process
        """
        with self.db_manager.get_db() as (db, sessions_table):
            session_data = sessions_table.get(Query().id == session_id)
            
        if not session_data:
            return False
            
        session = Session.from_dict(session_data)
        
        # Try to unlock the session
        if not session.unlock(self.process_id):
            return False
        
        # Update the session in the database
        with self.db_manager.get_db() as (db, sessions_table):
            sessions_table.update(session.to_dict(), Query().id == session_id)
        return True
    
    def renew_session_lock(self) -> bool:
        """
        Renew the lock on the current session.
        
        This method should be called periodically during user activity
        to ensure the session lock doesn't expire while in use.
        
        Returns:
            bool: True if renewal was successful, False otherwise
        """
        if not self.current_session:
            return False
            
        # Try to renew the lock in memory
        if not self.current_session.renew_lock(self.process_id):
            return False
        
        # Update the session in the database
        with self.db_manager.get_db() as (db, sessions_table):
            sessions_table.update(
                {"locked_at": self.current_session.locked_at.isoformat()},
                Query().id == self.current_session.id
            )
        return True
    
    def is_process_alive(self, pid: int) -> bool:
        """
        Check if a process is still alive.
        
        Args:
            pid (int): Process ID to check
            
        Returns:
            bool: True if process is alive, False otherwise
        """
        try:
            # Check if process exists and is running
            process = psutil.Process(pid)
            return process.is_running() and process.status() != psutil.STATUS_ZOMBIE
        except psutil.NoSuchProcess:
            return False
        except Exception as e:
            logger.warning(f"Error checking process {pid}: {e}")
            # Fallback to basic check if psutil fails
            try:
                # Send signal 0 to the process - this doesn't actually send a signal
                # but does error checking to see if the process exists
                os.kill(pid, 0)
                return True
            except OSError:
                # Process is not running or we don't have permission
                return False

    def check_and_clean_locks(self) -> List[str]:
        """
        Check all locked sessions and force unlock those with dead processes.
        
        This method scans all sessions in the database, checks if the
        locking process is still alive, and unlocks sessions whose
        locking processes have terminated.
        
        Returns:
            List of session IDs that were force-unlocked
        """
        # Get all sessions
        with self.db_manager.get_db() as (db, sessions_table):
            sessions = sessions_table.all()
            
        unlocked_sessions = []
        
        for session_data in sessions:
            locked_by = session_data.get("locked_by")
            
            # Skip unlocked sessions
            if not locked_by:
                continue
                
            # Check if the locking process is still alive
            if not self.is_process_alive(locked_by):
                # Process is dead, force unlock the session
                session_id = session_data.get("id")
                
                # Update in database
                with self.db_manager.get_db() as (db, sessions_table):
                    sessions_table.update({
                        "locked_by": None,
                        "locked_at": None
                    }, Query().id == session_id)
                
                unlocked_sessions.append(session_id)
                
                # Log the action
                # Get name from name_info if available, otherwise fall back to name
                if "name_info" in session_data:
                    session_name = session_data["name_info"].get("current", "Unnamed")
                else:
                    session_name = session_data.get("name", "Unnamed")
                logger.info(f"Force unlocked session '{session_name}' (ID: {session_id}) from dead process {locked_by}")
        
        return unlocked_sessions
        
    def is_session_locked_by_other(self, session_id: str) -> bool:
        """
        Check if a session is locked by another process.
        
        Args:
            session_id (str): ID of the session to check
            
        Returns:
            bool: True if locked by another process, False otherwise
        """
        with self.db_manager.get_db() as (db, sessions_table):
            session_data = sessions_table.get(Query().id == session_id)
            
        if not session_data:
            return False
            
        locked_by = session_data.get("locked_by")
        locked_at = session_data.get("locked_at")
        
        # If not locked at all
        if not locked_by:
            return False
            
        # If locked by this process
        if locked_by == self.process_id:
            return False
            
        # If locked by another process, check if lock has expired (30 minutes)
        if locked_at:
            try:
                locked_time = datetime.fromisoformat(locked_at)
                # If lock has expired, it's not considered locked
                if (datetime.now() - locked_time).total_seconds() > 1800:
                    return False
            except (ValueError, TypeError):
                # If there's an error parsing the timestamp, assume it's locked
                pass
                
        # If we get here, the session is locked by another process
        return True

    def cleanup_old_sessions(self) -> None:
        """
        Delete sessions that haven't been updated for an specified amount of time.
        
        The threshold is set by the environment variable ``CODA_SESSION_MAX_AGE_DAYS``.
        It defaults to 30 days, but can be overridden by the user. If an invalid value is provided,
        no cleanup will be performed.
        """
        sessions_max_age = SETTINGS.get_env_var(EnvConfig.CODA_SESSION_MAX_AGE_DAYS)
        try:
            sessions_max_age = int(sessions_max_age)
            if sessions_max_age <= 0:
                raise ValueError("CODA sessions max age cannot be zero or negative")
        except ValueError as e:
            logger.warning(f"Invalid days threshold '{sessions_max_age}': {e}. Interrupting sessions cleanup.")
            return []

        logger.info(f"Starting session garbage collection for sessions older than {sessions_max_age} days")
        
        # Calculate the expiration limit
        expiration_limit = (datetime.now() - timedelta(days=sessions_max_age)).isoformat()
        
        # Filter the expired sessions
        with self.db_manager.get_db() as (db, sessions_table):
            expired_sessions = sessions_table.search(Query().updated_at < expiration_limit)
        
        if not expired_sessions:
            logger.info("No sessions found for deletion")
            return []
        
        deleted_sessions: List[str] = []
        for session_data in expired_sessions:
            session_id = "unknown" # Initialize to avoid reference before assignment, in case of db corruption
            try:
                session_id = session_data.get("id")
                if self.delete_session(session_id):
                    deleted_sessions.append(session_id)
            except Exception as e:
                logger.error(f"Error deleting expired session '{session_id}': {e}")
                continue
        
        if deleted_sessions:
            logger.info(f"Deleted {len(deleted_sessions)} sessions older than {sessions_max_age} days: {', '.join(deleted_sessions)}")

    def start_auto_save(self) -> None:
        """
        Start the auto-save thread for periodic saving.
        
        Captures the current session context and passes it to the worker thread
        to ensure proper logging attribution.
        """
        if self.auto_save_thread and self.auto_save_thread.is_alive():
            return  # Already running
            
        # Capture the current session context to pass to the background thread
        session_context = capture_session_context()
        
        # Validate the captured session context
        if not session_context:
            logger.warning(
                "Captured session context is invalid. It is either None, empty, or missing required keys. Proceeding with caution."
            )
        self.auto_save_running = True
        self.auto_save_thread = threading.Thread(
            target=self._auto_save_worker,
            args=(session_context,),
            daemon=True
        )
        self.auto_save_thread.start()
    

    def stop_auto_save(self) -> None:
        """Stop the auto-save thread."""
        self.auto_save_running = False
        if self.auto_save_thread:
            # Wait for thread to terminate (with timeout)
            if self.auto_save_thread.is_alive():
                self.auto_save_thread.join(timeout=1.0)
            self.auto_save_thread = None
    
    def start_lock_monitor(self, check_interval: int = 300) -> None:
        """
        Start a background thread to monitor session locks.
        
        This thread periodically checks for stale locks from dead processes
        and cleans them up.
        
        Captures the current session context and passes it to the worker thread
        to ensure proper logging attribution.
        
        Args:
            check_interval (int): Interval in seconds between checks (default: 5 minutes)
        """
        self.lock_monitor_interval = check_interval
        
        if self.lock_monitor_thread and self.lock_monitor_thread.is_alive():
            return  # Already running
        
        # Capture the current session context to pass to the background thread
        session_context = capture_session_context()
            
        self.lock_monitor_running = True
        self.lock_monitor_thread = threading.Thread(
            target=self._lock_monitor_worker,
            args=(session_context,),
            daemon=True
        )
        self.lock_monitor_thread.start()
        logger.info(f"Lock monitor started with interval {check_interval} seconds")

    def stop_lock_monitor(self) -> None:
        """Stop the lock monitor thread."""
        self.lock_monitor_running = False
        if self.lock_monitor_thread:
            # Wait for thread to terminate (with timeout)
            if self.lock_monitor_thread.is_alive():
                self.lock_monitor_thread.join(timeout=1.0)
            self.lock_monitor_thread = None
            logger.info("Lock monitor stopped")

    def _lock_monitor_worker(self, session_context: Dict[str, Optional[str]]) -> None:
        """
        Worker thread for monitoring session locks.
        
        Args:
            session_context: The captured session context from the parent thread
        """
        # Restore the session context in this thread
        restore_session_context(session_context)
        
        logger.info("Lock monitor thread started")
        while self.lock_monitor_running:
            # Sleep for a while
            for _ in range(self.lock_monitor_interval):
                if not self.lock_monitor_running:
                    return
                time.sleep(1)
            
            # Check and clean locks
            try:
                unlocked_sessions = self.check_and_clean_locks()
                if unlocked_sessions:
                    logger.info(f"Lock monitor unlocked {len(unlocked_sessions)} sessions")
            except Exception as e:
                # Log error but continue
                logger.error(f"Lock monitor error: {e}")
    

    def _auto_save_worker(self, session_context: Dict[str, Optional[str]]) -> None:
        """
        Worker thread for auto-saving the current session.
        
        Args:
            session_context: The captured session context from the parent thread
        """
        # Restore the session context in this thread
        restore_session_context(session_context)
        
        logger.info("Auto-save thread started")
        while self.auto_save_running:
            # Sleep for a while
            for _ in range(self.auto_save_interval):
                if not self.auto_save_running:
                    return
                time.sleep(1)
            
            # Auto-save if we have a current session
            if self.current_session:
                try:
                    # Renew the lock first
                    self.renew_session_lock()
                    
                    # Then save the session
                    self.save_session()
                    logger.debug(f"Auto-saved session: {self.current_session.name}")
                except Exception as e:
                    # Log error but continue
                    logger.error(f"Auto-save error: {e}")


    def close(self) -> None:
        """
        Close the session manager and perform cleanup.
        
        This method should be called before the application exits to ensure
        proper cleanup of resources. It:
        1. Stops background threads (auto-save and lock monitor)
        2. Unlocks the current session if any
        3. Closes the database connection
        """
        try:
            # Stop auto-save after final save
            self.stop_auto_save()
            
            # Stop lock monitor
            self.stop_lock_monitor()
            logger.info("Lock monitor stopped")
            
            # Wait for rename thread to complete if it's running (with timeout)
            if self.rename_thread and self.rename_thread.is_alive():
                logger.info("Waiting for rename thread to complete before closing...")
                self.rename_thread.join(timeout=2.0)
                if self.rename_thread.is_alive():
                    logger.warning("Rename thread did not complete in time")
            
            # Unlock current session if any
            if self.current_session:
                self.unlock_session(self.current_session.id)
                logger.info(f"Session unlocked: {self.current_session.name}")
            
            # Close the database connection
            self.db_manager.close()
            logger.info("Database connection closed")
            
            logger.info("Session manager closed")
        except Exception as e:
            logger.error(f"Error closing session manager: {e}")