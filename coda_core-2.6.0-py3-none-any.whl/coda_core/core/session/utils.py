import json
import re
from typing import Optional, Dict
from pydantic import BaseModel, field_validator, ValidationError

from coda_core.core.models.llms.chat import ChatLLM
from coda_core.core.models.utils import load_prompt, extract_response_text


class TagResponse(BaseModel):
    """Pydantic model for LLM tag response"""
    tag: str
    
    @field_validator('tag')
    def validate_kebab_case(cls, v):
        if not v:
            raise ValueError("Tag cannot be empty")
        
        # Check kebab-case format
        if not re.match(r'^[a-z0-9]+(-[a-z0-9]+)*$', v):
            raise ValueError("Tag must be kebab-case (lowercase, hyphens only)")
        
        return v


class LLMJsonParser:
    """Basic parser using Pydantic for validation"""
    
    def clean_json_string(self, output: str) -> str:
        """Remove markdown code blocks and extra whitespace"""
        cleaned = output.strip()
        # Remove ```json and ```
        cleaned = re.sub(r'^```json\s*', '', cleaned, flags=re.MULTILINE)
        cleaned = re.sub(r'\s*```$', '', cleaned, flags=re.MULTILINE)
        return cleaned.strip()
    
    def extract_json_from_text(self, text: str) -> Optional[str]:
        """Find JSON object with 'tag' field in text"""
        # Look for {"tag": "value"} pattern
        match = re.search(r'\{[^{}]*"tag"\s*:\s*"[^"]*"[^{}]*\}', text)
        return match.group(0) if match else None
    
    def parse_tag_from_output(self, output_string: str) -> Dict:
        """
        Parse LLM output and extract validated tag
        
        Returns:
            Dict with 'success', 'tag', 'error' keys
        """
        if not output_string:
            return {"success": False, "error": "Empty input"}
        
        try:
            # Clean the string
            cleaned = self.clean_json_string(output_string)
            
            # Extract JSON
            json_str = self.extract_json_from_text(cleaned) or cleaned
            
            # Parse JSON
            try:
                json_data = json.loads(json_str)
            except json.JSONDecodeError:
                return {"success": False, "error": "Invalid JSON format"}
            
            # Validate with Pydantic
            try:
                validated = TagResponse(**json_data)
                return {"success": True, "tag": validated.tag}
            except ValidationError as e:
                error_msg = e.errors()[0]['msg']  # Get first error message
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
        

def extract_user_messages_with_metadata(messages):
    """
    Extract user messages with their full dictionary structure.
    
    Args:
        messages (list): List of dictionaries with 'role' and 'content' keys
        
    Returns:
        list: List of dictionaries containing only user messages
    """
    return [msg for msg in messages if msg.get('role') == 'user']


def generate_session_name(user_messages, geai_client, model_name, provider_name) -> dict:
    """
    Generate a session name using an LLM based on user messages.
    
    This function properly formats the user messages for the Handlebars template,
    passes them as context to the template renderer, and then calls the LLM
    to generate a session name.
    
    Args:
        user_messages (list): List of user message dictionaries
        geai_client: The client to use for LLM calls
        model_name (str): Name of the model to use
        provider_name (str): Name of the provider to use
        
    Returns:
        dict: A dictionary with keys:
            - "status": "success" or "error"
            - "name": The generated name (if successful)
            - "error": Error message (if status is "error")
    """
    if not user_messages:
        return {
            "status": "error",
            "error": "No user messages provided",
            "usage": None
        }
    
    try:
        # Format user messages for the template
        formatted_messages = []
        for msg in user_messages:
            content = msg.get('content', '')
            if content:
                formatted_messages.append(content)
        
        # Join messages with newlines for readability in the prompt
        messages_text = "\n\n".join(formatted_messages)
        
        # Load the prompt template with user messages as context
        context = {"user_messages": messages_text}
        system_prompt = load_prompt(template_name="session_rename_prompt.hbs", context=context)
        
        # Create the LLM instance
        llm = ChatLLM(
            client=geai_client,
            model_name=model_name,
            provider_name=provider_name,
            system_prompt=system_prompt,
        )
        
        # Call the LLM with an empty user message since context is in the system prompt
        response = llm.generate_response([{"role": "user", "content": ""}])
        content = extract_response_text(response) or ""
        
        # Extract usage information directly from the response
        usage = getattr(response, "usage", None)
        
        # Parse the response
        parser = LLMJsonParser()
        result = parser.parse_tag_from_output(content)
        
        # Check if we got a valid tag
        if "tag" in result:
            name = result["tag"]
            # Validate the name
            if len(name) < 4 or len(name) > 30:
                return {
                    "status": "error",
                    "error": f"Generated name has invalid length: {name}",
                    "usage": usage  # Include usage even in error case
                }
            return {
                "status": "success",
                "name": name,
                "usage": usage  # Include usage in the return value
            }
        else:
            return {
                "status": "error",
                "error": result.get("error", "Failed to parse tag from LLM response"),
                "usage": usage  # Include usage even in error case
            }
            
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "usage": None
        }
