import uuid
from datetime import datetime
from loguru import logger

class Session:
    """
    Represents a saved session with shared and client-specific state.
    
    A session contains both shared state (memory, model preferences) that is common
    across all clients, and client-specific state that varies by client type.
    
    Attributes:
        id: Unique identifier for the session
        name_info: Dictionary containing name information and history:
            - original: The original name of the session
            - current: The current name of the session
            - last_changed: Timestamp when the name was last changed, or None if it hasn't been renamed
            - rename_method: How the session was renamed ('manual' or 'auto'), or None if not renamed
        created_at: Timestamp when the session was created
        updated_at: Timestamp when the session was last updated
        metadata: Additional metadata about the session (description, tags, summary, etc.)
        shared_state: Dictionary containing shared state data
        client_states: Dictionary of client-specific state data by client_type
        locked_by: Process ID of the client that has locked this session, or None if unlocked
        locked_at: Timestamp when the session was locked, or None if unlocked
    """
    
    def __init__(self, name: str = None, id: str = None):
        """
        Initialize a new session.
        
        Args:
            name (str): Optional name for the session (auto-generated if not provided)
            id (str): Optional ID for the session (auto-generated if not provided)
        """
        self.id = id or str(uuid.uuid4())
        initial_name = name or f"Session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.name_info = {
            "original": initial_name,
            "current": initial_name,
            "last_changed": None,
            "rename_method": None
        }
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
        self.metadata = {
            "description": "",
            "tags": [],
            "summary": ""
        }
        self.shared_state = {}
        self.client_states = {}
        self.locked_by = None
        self.locked_at = None


    def get_client_state(self, client_type: str) -> dict:
        """
        Get state for a specific client type.
        
        Args:
            client_type (str): The client type identifier. Only 'cli' is supported.
            
        Returns:
            Dict containing the client state, or empty dict if not found
        """
        return self.client_states.get(client_type, {})


    def set_client_state(self, client_type: str, state: dict) -> None:
        """
        Set state for a specific client type.
        
        Args:
            client_type (str): The client type identifier (e.g., 'cli', 'web')
            state (dict): Dictionary of state data for the client
        """
        self.client_states[client_type] = state
        self.updated_at = datetime.now()


    def set_summary(self, summary: str) -> None:
        """
        Set the LLM-generated summary for this session.
        
        Args:
            summary (str): A string containing the summary of what was done in the session
        """
        self.metadata["summary"] = summary
        self.updated_at = datetime.now()


    def lock(self, process_id: int) -> bool:
        """
        Lock the session for exclusive use by a client.
        
        Args:
            process_id (int): Process ID of the client locking the session
            
        Returns:
            bool: True if lock was acquired, False if already locked by another process
        """
        # If already locked by another process
        if self.locked_by is not None and self.locked_by != process_id:
            # Check if lock has expired (30 minutes)
            if self.locked_at and (datetime.now() - self.locked_at).total_seconds() > 1800:
                # Lock has expired, force unlock
                self.locked_by = None
                self.locked_at = None
            else:
                # Lock is still valid
                return False
                
        # Lock the session
        self.locked_by = process_id
        self.locked_at = datetime.now()
        return True
    

    def unlock(self, process_id: int) -> bool:
        """
        Unlock the session if locked by the specified process.
        
        Args:
            process_id (int): Process ID of the client unlocking the session
            
        Returns:
            bool: True if unlock was successful, False if locked by another process
        """
        # Only the process that locked the session can unlock it
        if self.locked_by is None or self.locked_by == process_id:
            self.locked_by = None
            self.locked_at = None
            return True
        return False


    def renew_lock(self, process_id: int) -> bool:
        """
        Renew the lock if it's held by the specified process.
        
        This method updates the lock timestamp to the current time
        if the session is already locked by the given process.
        
        Args:
            process_id (int): Process ID of the client renewing the lock
            
        Returns:
            bool: True if renewal was successful, False if locked by another process
        """
        # Only the process that locked the session can renew it
        if self.locked_by is None or self.locked_by == process_id:
            self.locked_by = process_id  # Ensure it's set (in case it was None)
            self.locked_at = datetime.now()
            return True
        return False
    

    def is_locked(self) -> bool:
        """
        Check if the session is currently locked.
        
        Returns:
            bool: True if locked, False otherwise
        """
        if self.locked_by is None:
            return False
            
        # Check if lock has expired (30 minutes)
        if self.locked_at and (datetime.now() - self.locked_at).total_seconds() > 1800:
            # Lock has expired
            self.locked_by = None
            self.locked_at = None
            return False
            
        return True
    

    def is_locked_by(self, process_id: int) -> bool:
        """
        Check if the session is locked by the specified process.
        
        Args:
            process_id: Process ID to check
            
        Returns:
            bool: True if locked by the specified process, False otherwise
        """
        return self.locked_by == process_id


    @property
    def name(self) -> str:
        """
        Get the current name of the session.
        
        Returns:
            str: The current name of the session
        """
        return self.name_info["current"]


    def set_name(self, new_name: str, rename_method: str = "manual") -> bool:
        """
        Set the name of the session, tracking name change history and method.
        
        This method updates the name_info dictionary to track the name change.
        The session can be renamed if:
        1. Manual renames are always allowed
        2. Auto renames are only allowed if the session hasn't been renamed before (by any method)
        
        Args:
            new_name (str): The new name for the session
            rename_method (str): How the rename was performed ('manual' or 'auto')
            
        Returns:
            bool: True if the rename was successful, False otherwise
        """
        # If the name is the same as current, no need to rename
        if new_name == self.name_info["current"]:
            logger.warning(f"Rename ignored: the new name is the same as the current name: {new_name}")
            return False
        
        # Determine if we can rename based on rename history and method
        if rename_method == "manual":
            # Manual renames are always allowed
            can_rename = True
        else:
            # Auto renames are only allowed if the session hasn't been renamed before
            can_rename = not self.has_been_renamed()
        
        if not can_rename:
            logger.warning(f"Rename failed: session has already been renamed using {self.name_info['rename_method']} method on {self.name_info['last_changed']}")
            return False
        
        # Perform the rename
        self.name_info["current"] = new_name
        self.name_info["last_changed"] = datetime.now().isoformat()
        self.name_info["rename_method"] = rename_method
        self.updated_at = datetime.now()
        return True


    def has_been_renamed(self, by_method: str = None) -> bool:
        """
        Check if this session has already been renamed.
        
        Args:
            by_method (str, optional): Check if renamed by a specific method ('manual' or 'auto')
            
        Returns:
            bool: True if the session has been renamed (by the specified method if provided),
                  False otherwise
        """
        if by_method:
            return (self.name_info["last_changed"] is not None and
                    self.name_info["rename_method"] == by_method)
        return self.name_info["last_changed"] is not None
    

    def to_dict(self) -> dict:
        """
        Serialize session to dictionary.
        
        Returns:
            Dict containing all session data
        """
        return {
            "id": self.id,
            "name_info": self.name_info,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "metadata": self.metadata,
            "shared_state": self.shared_state,
            "client_states": self.client_states,
            "locked_by": self.locked_by,
            "locked_at": self.locked_at.isoformat() if self.locked_at else None
        }
    

    @classmethod
    def from_dict(cls, data: dict) -> "Session":
        """
        Create session from dictionary.
        
        Args:
            data (dict): Dictionary containing session data
            
        Returns:
            New Session instance
        """
        session = cls()
        session.id = data.get("id")
        
        # Handle name_info structure or create it from legacy data
        if data.get("name_info"):
            # Use existing name_info structure
            session.name_info = data.get("name_info")
            
            # Ensure rename_method exists in older name_info structures
            if "rename_method" not in session.name_info:
                session.name_info["rename_method"] = "manual" if session.name_info["last_changed"] else None
                
            # Ensure all required fields exist in name_info
            if "original" not in session.name_info:
                session.name_info["original"] = session.name_info.get("current", "Unknown")
            if "current" not in session.name_info:
                session.name_info["current"] = session.name_info.get("original", "Unknown")
            if "last_changed" not in session.name_info:
                session.name_info["last_changed"] = None
        else:
            # DEPRECATED: Handle legacy data format with only 'name' field
            # The 'name' field is deprecated and will be removed in a future version.
            # New sessions should use the 'name_info' structure instead.
            legacy_name = data.get("name")
            
            # If name is also missing, use a default name
            if not legacy_name:
                legacy_name = f"Session_{datetime.now().strftime('%Y%m%d_%H%M%S')}_recovered"
    
            # Create new name_info structure from legacy name
            session.name_info = {
                "original": legacy_name,
                "current": legacy_name,
                "last_changed": None,
                "rename_method": None
            }
        
        session.created_at = datetime.fromisoformat(data.get("created_at"))
        session.updated_at = datetime.fromisoformat(data.get("updated_at"))
        session.metadata = data.get("metadata", {})

        # Ensure metadata has all required keys
        if "description" not in session.metadata:
            session.metadata["description"] = ""
        if "tags" not in session.metadata:
            session.metadata["tags"] = []
        if "summary" not in session.metadata:
            session.metadata["summary"] = ""

        session.shared_state = data.get("shared_state", {})
        session.client_states = data.get("client_states", {})
        session.locked_by = data.get("locked_by")
        
        if data.get("locked_at"):
            session.locked_at = datetime.fromisoformat(data.get("locked_at"))
        else:
            session.locked_at = None
            
        return session