# Memory key identifiers
MEMORY_KEY_MAIN = "main"
# Memory defaults
MEMORY_DEFAULT_CONTEXT_WINDOW = 200000          # Claude 3.7 Sonnet specs
MEMORY_DEFAULT_MAX_TOKENS = 64000               # Claude 3.7 Sonnet specs