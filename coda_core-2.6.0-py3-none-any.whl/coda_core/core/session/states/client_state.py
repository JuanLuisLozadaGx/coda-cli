from abc import ABC, abstractmethod
from typing import Dict, Any

class ClientState(ABC):
    """
    Abstract base class for client-specific state.
    
    This class defines the interface that all client-specific state classes
    must implement, and provides common functionality.
    """
    
    CLIENT_TYPE = "base"  # Override in subclasses
    
    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize to dictionary.
        
        Returns:
            Dict containing all client state data
        """
        pass
    
    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ClientState":
        """
        Create from dictionary.
        
        Args:
            data: Dictionary containing client state data
            
        Returns:
            New ClientState instance
        """
        pass