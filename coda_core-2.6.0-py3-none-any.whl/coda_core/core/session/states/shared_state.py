from typing import Dict, Any, Optional, List
from datetime import datetime

from loguru import logger

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.config.context.schemas import WorkspaceContext

from coda_core.core.models.providers.geai_client_manager import GEAIClientManager
from coda_core.core.models.providers.geai_config import GEAIConfig
from coda_core.core.utils.token_counting import get_encoding_for_model
from coda_core.core.memories.condenser import MemoryCondenser
from coda_core.core.tools.manager import ToolManager
from coda_core.core.memories import Memory, TokenLimitedMemory
from coda_core.core.mcp.service import MCPService
from coda_core.core.memories.utils import migrate_memories
from coda_core.core.memories.constants import (
    MIN_SAFE_MAX_TOKENS,
    OUTPUT_TOKENS_PERCENTAGE,
    MEMORY_PERCENTAGE
)
from coda_core.core.agents.single_agent import SingleAgent
from coda_core.core.models.llms.chat import ChatLLM
from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.core.utils.prompt_management import create_system_prompt, create_agent_prompt
from coda_core.core.tools.constants import GEAI_CLIENT_DEPENDENT_TOOLS
from coda_core.core.tools.run_skill.run_skill_tool import RunSkillTool
from coda_core.core.session.constants import MEMORY_DEFAULT_CONTEXT_WINDOW, MEMORY_DEFAULT_MAX_TOKENS, MEMORY_KEY_MAIN
from coda_core.core.rules.loader import read_user_defined_rules, read_and_concatenate_files
from coda_core.core.rules.constants import DEFAULT_MAX_CHARS, DEFAULT_MAX_LINES
from coda_core.core.utils.usage_parsing import (
    get_usage_value,
    parse_int_safe,
    parse_float_safe,
)


GEAI_CLIENT_DEPENDENT_TOOLS = ["web_search", "examine_images", "omni_parser"]


class SharedState:
    """
    Represents state shared across all clients.

    This includes conversation memories, model/provider preferences,
    and usage statistics that are common across all clients.

    Attributes:
        memories: Dictionary of conversation memories
        provider_name: The name of the model provider
        model_name: The name of the model
        preferences: Dictionary of general preferences
        total_cost: Total cost of LLM usage
        total_tokens: Total number of tokens used
        completion_tokens: Number of completion tokens used
        prompt_tokens: Number of prompt tokens used
        last_auto_save: Timestamp of the last auto-save
    """
    
    def __init__(self, geai_config: Optional[GEAIConfig] = None):
        """
        Initialize shared state with default values.
        
        Args:
            geai_config: Optional GEAI configuration. If None, will fall back
                        to environment variables when geai_client is first accessed.
        """
        # Persistent main agent reference (preserved across modes)
        self.main_agent = None

        # Initialize memories dictionary with keys but no instances yet
        # Memories will be lazily initialized when accessed
        self._memories = {
            MEMORY_KEY_MAIN: None,
        }

        # Model/provider preferences with default values
        self.provider_name = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_PROVIDER_NAME)
        self.model_name = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SYSTEM_MODEL_NAME)
        self.single_agent_provider_name = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SINGLE_AGENT_PROVIDER_NAME)
        self.single_agent_model_name = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_SINGLE_AGENT_MODEL_NAME)

        # User-defined rules
        self.user_defined_rules = {
            'content': None,              # The actual rules content
            'path': None,                 # Primary path to the rules file
            'paths': [],                  # All paths that contributed to the content
            'vcs_root': None,             # Version-control root used for discovery
            'vcs_type': None,             # Version-control type for discovery (e.g., git)
            'discovery_mode': None,       # 'hierarchical' or 'single_file'
            'last_reload_timestamp': None,  # When rules were last reloaded
            'char_count': 0,              # Character count before truncation
            'truncated_char_count': 0,    # Character count after truncation
            'line_count': 0,              # Line count before truncation
            'truncated_line_count': 0,    # Line count after truncation
            'was_truncated': False,       # Whether the rules were truncated
            'warnings': [],               # Non-fatal loading warnings (e.g., migrations)
            'status': 'not_found',        # Status of the last load operation
            'error': None,                # Error message if loading failed
        }

        # General preferences that apply across clients
        self.preferences = {}
        # Initialize default preferences
        self._initialize_bash_security_preferences()
        self._initialize_omni_upload_preferences()

        # Usage tracking
        self.total_cost = 0.0
        self.total_tokens = 0
        self.completion_tokens = 0
        self.prompt_tokens = 0

        # Auto-save tracking
        self.last_auto_save = datetime.now()

        # Persisted Responses chain state keyed by scope/provider/model.
        self.responses_chain_states: Dict[str, Dict[str, Any]] = {}

        # Store GEAI config for lazy initialization
        self._geai_config = geai_config

        # Not initialized yet - will be lazy loaded
        self._geai_client = None

        # Tool manager will be lazily initialized
        self._tool_manager = None

        # MCP service will be lazily initialized
        self._mcp_service = None

    def _initialize_memory(self, key: str) -> None:
        """
        Initialize a memory instance if it doesn't exist yet.

        Args:
            key: The memory key to initialize
        """
        if key not in self._memories or self._memories[key] is None:
            # Select appropriate model based on memory key
            # Use single agent model for main memory, system model for ask memory
            model_provider = self.single_agent_provider_name if key == MEMORY_KEY_MAIN else self.provider_name
            model_name = self.single_agent_model_name if key == MEMORY_KEY_MAIN else self.model_name
            
            # Default values if we can't determine model specs. Using Claude 3.7 Sonnet specs
            context_window = MEMORY_DEFAULT_CONTEXT_WINDOW  # Default context window
            max_output_tokens = MEMORY_DEFAULT_MAX_TOKENS  # Default max output tokens

            try:
                # Try to get actual model specs using the geai_client property
                model = self.geai_client.check_model_availability(
                    provider_name=model_provider,
                    model_name=model_name
                )

                if model:
                    context_window = model.context_window
                    max_output_tokens = model.max_output_tokens
                    logger.info(
                        f"Using model {model_provider}/{model_name} for memory '{key}' "
                        f"with context_window={context_window}, "
                        f"max_output_tokens={max_output_tokens}"
                    )
            except Exception as e:
                logger.warning(f"Could not get model specs for memory '{key}', using defaults: {e}")

            # The following inequality must hold: input + max_output <= context limit
            # Apply percentage-based allocation for context window
            # Cap max output tokens to the defined percentage (20% of context window)
            max_output_tokens_limit = int(context_window * OUTPUT_TOKENS_PERCENTAGE)
            if max_output_tokens > max_output_tokens_limit:
                logger.info(
                    f"Capping max output tokens from {max_output_tokens} to {max_output_tokens_limit} " 
                    f"({OUTPUT_TOKENS_PERCENTAGE:.0%} of context window)"
                )
                max_output_tokens = max_output_tokens_limit

            # Allocate memory tokens based on the defined percentage (70% of context window)
            memory_tokens = int(context_window * MEMORY_PERCENTAGE)
            safe_max_tokens = max(MIN_SAFE_MAX_TOKENS, memory_tokens)

            logger.info(
                f"Memory allocation for '{key}': {safe_max_tokens} tokens ({MEMORY_PERCENTAGE:.0%} of {context_window})"
            )

            # Create a tiktoken encoding for accurate token counting
            encoding = None
            try:
                # Use the robust get_encoding_for_model function from token_counting.py
                encoding = get_encoding_for_model(model_name)
            except Exception as e:
                logger.warning(f"Could not initialize tiktoken encoding: {e}. Will use character-based estimation.")

            # Initialize memory with the encoding
            self._memories[key] = TokenLimitedMemory(
                capacity=safe_max_tokens,
                encoding=encoding
            )

            # Initialize the memory condenser if needed
            self._initialize_memory_condenser(self._memories[key])

    @property
    def memories(self) -> Dict[str, Memory]:
        """
        Get the memories dictionary, initializing any missing memories.

        Returns:
            Dict containing all memory instances
        """
        # Initialize any uninitialized memories
        for key in self._memories:
            if self._memories[key] is None:
                self._initialize_memory(key)

        return self._memories

    @memories.setter
    def memories(self, value: Dict[str, Memory]) -> None:
        """
        Set the memories dictionary.

        Args:
            value: Dictionary of memory instances
        """
        self._memories = value

    def add_usage(self, usage: Optional[Any]) -> None:
        """
        Add usage statistics.

        Args:
            usage: Usage object with cost and token information
        """
        if not usage:
            return
        
        # Extract totals, handling both object attributes and dict-style usage payloads
        total_cost = get_usage_value(usage, "total_cost")
        if total_cost is None:
            # Some providers (e.g., GEAI omni-parser) may return a nested cost object
            cost_container = get_usage_value(usage, "cost") or get_usage_value(usage, "costs")
            if isinstance(cost_container, dict):
                total_cost = (
                    cost_container.get("total")
                    or cost_container.get("total_cost")
                    or cost_container.get("amount")
                )
                if total_cost is None:
                    nested_prompt_cost = (
                        cost_container.get("prompt")
                        or cost_container.get("prompt_cost")
                        or cost_container.get("input")
                        or cost_container.get("input_cost")
                    )
                    nested_completion_cost = (
                        cost_container.get("completion")
                        or cost_container.get("completion_cost")
                        or cost_container.get("output")
                        or cost_container.get("output_cost")
                    )
                    if isinstance(nested_prompt_cost, bool) or not isinstance(nested_prompt_cost, (int, float, str)):
                        nested_prompt_cost = None
                    if isinstance(nested_completion_cost, bool) or not isinstance(nested_completion_cost, (int, float, str)):
                        nested_completion_cost = None
                    if nested_prompt_cost is not None or nested_completion_cost is not None:
                        total_cost = (
                            parse_float_safe(nested_prompt_cost, 0.0)
                            + parse_float_safe(nested_completion_cost, 0.0)
                        )
        if total_cost is None:
            # Fallback for providers that emit split component costs only.
            prompt_cost = get_usage_value(usage, "prompt_cost")
            completion_cost = get_usage_value(usage, "completion_cost")
            if isinstance(prompt_cost, bool) or not isinstance(prompt_cost, (int, float, str)):
                prompt_cost = None
            if isinstance(completion_cost, bool) or not isinstance(completion_cost, (int, float, str)):
                completion_cost = None
            if prompt_cost is not None or completion_cost is not None:
                total_cost = parse_float_safe(prompt_cost, 0.0) + parse_float_safe(completion_cost, 0.0)
        total_cost = parse_float_safe(total_cost, 0.0)

        total_tokens = get_usage_value(usage, "total_tokens")
        total_tokens = parse_int_safe(total_tokens, 0)

        completion_tokens = get_usage_value(usage, "completion_tokens")
        completion_tokens = parse_int_safe(completion_tokens, 0)
        output_tokens_raw = get_usage_value(usage, "output_tokens")
        if isinstance(output_tokens_raw, bool) or not isinstance(output_tokens_raw, (int, float, str)):
            output_tokens_raw = None
        output_tokens = parse_int_safe(output_tokens_raw, 0)
        if completion_tokens <= 0 and output_tokens > 0:
            completion_tokens = output_tokens

        prompt_tokens = get_usage_value(usage, "prompt_tokens")
        prompt_tokens = parse_int_safe(prompt_tokens, 0)
        input_tokens_raw = get_usage_value(usage, "input_tokens")
        if isinstance(input_tokens_raw, bool) or not isinstance(input_tokens_raw, (int, float, str)):
            input_tokens_raw = None
        input_tokens = parse_int_safe(input_tokens_raw, 0)
        if prompt_tokens <= 0 and input_tokens > 0:
            prompt_tokens = input_tokens

        if total_tokens <= 0 and (prompt_tokens > 0 or completion_tokens > 0):
            total_tokens = prompt_tokens + completion_tokens

        # Add to running totals
        self.total_cost += total_cost
        self.total_tokens += total_tokens
        self.completion_tokens += completion_tokens
        self.prompt_tokens += prompt_tokens
    
    def get_context_window_usage(self) -> Dict[str, Any]:
        """
        Calculate and return the context window usage statistics.

        Returns:
                dict: Dictionary with keys:
                - 'context_window' (int): The context window size for the model.
                - 'total_usage_percentage' (float): The percentage of the context window currently used (capped at 1.0).
        """
        # Get model info
        context_window = MEMORY_DEFAULT_CONTEXT_WINDOW  # Default value

        try:
            # Try to get model specs for the current model
            model = self.geai_client.check_model_availability(
                provider_name=self.provider_name,
                model_name=self.model_name
            )

            if model:
                context_window = model.context_window
        except Exception as e:
            logger.warning(f"Could not get model specs: {e} using default context window {context_window}")

        # Calculate memory usage
        memory_usage = 0

        for _, memory in self.memories.items():
            memory_usage += memory.token_count

        # Calculate total usage percentage
        # Reserve space for output (20%) 
        reserved_space = int(context_window * (OUTPUT_TOKENS_PERCENTAGE))
        if context_window > 0 and (context_window - reserved_space) > 0 :
            total_usage_percentage = memory_usage / (context_window - reserved_space)
            if total_usage_percentage > 1.0:
                total_usage_percentage = 1.0
        else:
            # Assume full usage if context window is invalid
            logger.info(f"Invalid context window {context_window}, assuming full usage")
            total_usage_percentage = 1.0

        return {
            "context_window": context_window,
            "total_usage_percentage": min(1.0, total_usage_percentage)
        }

    def get_usage_summary(self) -> Dict[str, Any]:
        """
        Get usage summary.

        Returns:
            Dict containing usage statistics
        """
        return {
            "total_cost": round(self.total_cost, 6),
            "total_tokens": self.total_tokens,
            "completion_tokens": self.completion_tokens,
            "prompt_tokens": self.prompt_tokens,
            "currency": "USD"
        }
        
    def sync_usage_from(self, other_shared_state: Optional['SharedState']) -> Dict[str, Any]:
        """
        Synchronize usage statistics from another shared state.

        Args:
            other_shared_state: Another SharedState instance to sync from

        Returns:
            dict: The usage delta that was transferred
        """
        if not other_shared_state:
            return {"total_cost": 0, "total_tokens": 0, "completion_tokens": 0, "prompt_tokens": 0}

        # Calculate delta for logging
        delta = {
            "total_cost": other_shared_state.total_cost - self.total_cost,
            "total_tokens": other_shared_state.total_tokens - self.total_tokens,
            "completion_tokens": other_shared_state.completion_tokens - self.completion_tokens,
            "prompt_tokens": other_shared_state.prompt_tokens - self.prompt_tokens
        }

        # Copy usage statistics - REPLACE not add to avoid double-counting
        self.total_cost = other_shared_state.total_cost
        self.total_tokens = other_shared_state.total_tokens
        self.completion_tokens = other_shared_state.completion_tokens
        self.prompt_tokens = other_shared_state.prompt_tokens

        return delta

    def update_model_settings(self, provider_name: str, model_name: str, context_window: int = None, max_output_tokens: int = None, single_agent: Optional['SingleAgent'] = None) -> bool:
        """
        Update model settings for both system and single agent.

        This method first tries to update the single agent's LLM if provided,
        and only updates the config settings if that succeeds or if no agent is provided.

        Args:
            provider_name: The provider name to use
            model_name: The model name to use
            context_window: Optional context window size of the model
            max_output_tokens: Optional maximum output tokens of the model
            single_agent: Optional SingleAgent instance to update

        Returns:
            bool: True if all updates were successful, False otherwise
        """
        # Store old model settings for logging
        old_provider = self.provider_name
        old_model = self.model_name

        # Log model change request
        logger.info(f"Model change requested: {old_provider}/{old_model} → {provider_name}/{model_name}")
        if context_window is not None:
            logger.info(f"New context window: {context_window} tokens")
        if max_output_tokens is not None:
            logger.info(f"New max output tokens: {max_output_tokens} tokens")

        # If a single agent is provided, try to update its LLM first
        if single_agent is not None:
            logger.info(f"Updating existing LLMs to '{provider_name}/{model_name}'")
            llm_update_success = single_agent.llm.update_model(provider_name, model_name)

            if not llm_update_success:
                logger.warning(f"Failed to update SingleAgent LLM to '{provider_name}/{model_name}', aborting config update")
                return False

            logger.info(f"Successfully updated SingleAgent LLM to '{provider_name}/{model_name}'")

        # Update model settings
        self.provider_name = provider_name
        self.model_name = model_name
        self.single_agent_provider_name = provider_name
        self.single_agent_model_name = model_name

        # Migrate memories if context window and max output tokens are provided
        if context_window is not None and max_output_tokens is not None:
            self.migrate_memories_for_model_change(
                old_provider, old_model,
                provider_name, model_name,
                context_window, max_output_tokens
            )

            if single_agent is not None:
                # Update agent's memory to point to the migrated main memory from shared state
                single_agent.memory = self._memories[MEMORY_KEY_MAIN]
                logger.info(f"Updated agent memory reference to migrated memory with capacity={single_agent.memory.capacity}")
        
        return True

    def migrate_memories_for_model_change(
        self,
        old_provider: str,
        old_model: str,
        new_provider: str,
        new_model: str,
        context_window: int,
        max_output_tokens: int
    ) -> None:
        """
        Migrate memories when the model is changed, especially if context window or max tokens differ.

        This method:
        1. Checks if the context window or max tokens differ between the old and new model
        2. If they differ, creates new memory instances with appropriate settings
        3. Copies messages from old memories to new memories, which will handle trimming if needed

        Args:
            old_provider: The previous provider name
            old_model: The previous model name
            new_provider: The new provider name
            new_model: The new model name
            context_window: The context window size of the new model
            max_output_tokens: The maximum output tokens of the new model
        """
        migrate_memories(
            memories=self._memories,
            old_provider=old_provider,
            old_model=old_model,
            new_provider=new_provider,
            new_model=new_model,
            context_window=context_window,
            max_output_tokens=max_output_tokens
        )

    def should_auto_save(self, auto_save_interval: int = 300) -> bool:
        """
        Check if it's time to auto-save based on the interval.

        Args:
            auto_save_interval (int): Interval in seconds between auto-saves (default: 5 minutes)

        Returns:
            bool: True if it's time to auto-save, False otherwise
        """
        elapsed = (datetime.now() - self.last_auto_save).total_seconds()
        return elapsed >= auto_save_interval

    def update_auto_save_timestamp(self) -> None:
        """Update the last auto-save timestamp to now."""
        self.last_auto_save = datetime.now()

    @property
    def geai_client(self):
        """
        Lazy initialization of the GEAI client via GEAIClientManager.

        This property ensures that the GEAI client is only initialized when first
        accessed, which allows the application to prompt for missing environment
        variables before attempting to create it.

        Returns:
            The initialized GEAIClient provided by GEAIClientManager
        
        See Also:
            refresh_geai_config(): Use this method to change authentication credentials
        """
        if self._geai_client is None:
            self._initialize_geai_client()
        return self._geai_client

    @property
    def tool_manager(self):
        """
        Lazy initialization of ToolManager.

        This property ensures that ToolManager is only initialized when first accessed.
        The ToolManager will generate its own unique config_id if none is provided.

        Returns:
            ToolManager: The initialized ToolManager instance
        """
        if self._tool_manager is None:
            self._initialize_tool_manager()
        return self._tool_manager

    @property
    def mcp_service(self):
        """
        Lazy initialization of MCPService.

        This property ensures that MCPService is only initialized when first accessed,
        providing MCP functionality for tools and other components that need it.

        Returns:
            MCPService: The initialized MCPService singleton instance
        """
        if self._mcp_service is None:
            self._initialize_mcp_service()
        return self._mcp_service

    def _initialize_tool_manager(self):
        """
        Initialize the ToolManager with a unique config_id.

        This method is called lazily when the tool_manager property is first accessed.
        It creates a new ToolManager instance which automatically loads its configuration
        from a file if it exists. It doesn't register default tools to respect any
        existing configuration.
        """
        try:
            # Create a new ToolManager with a new config_id
            # The ToolManager constructor will load the configuration from the file if it exists
            self._tool_manager = ToolManager()

            # Check if the config file exists
            config_file_exists = self._tool_manager.config_file_path.exists()

            # If the file doesn't exist, we need to register default tools and save the config
            if not config_file_exists:
                # Register default tools for new configurations
                self._tool_manager.register_default_tools()

                # Save the configuration to disk
                self._tool_manager._save_config()
                logger.info(f"Created new tool configuration file at {self._tool_manager.config_file_path}")

            logger.info("ToolManager initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing ToolManager: {e}")
            raise

    def _initialize_mcp_service(self):
        """
        Initialize the MCPService singleton.

        This method is called lazily when the mcp_service property is first accessed.
        It gets the MCPService singleton and ensures it's properly initialized.
        """
        try:
            # Get the singleton instance
            self._mcp_service = MCPService.get()

            # Ensure it's initialized
            initialization_success = self._mcp_service.initialize()

            if initialization_success:
                logger.info("MCPService initialized successfully")
            else:
                logger.warning("MCPService initialization returned False, but service is available")

        except Exception as e:
            logger.error(f"Error initializing MCPService: {e}")
            # Don't raise - MCP service is optional and should fail gracefully
            # Set to None so it can be retried later
            self._mcp_service = None

    def _initialize_geai_client(self):
        """
        Initialize the GEAIClient with explicit config or fall back to environment variables.

        This method is called lazily when the geai_client property is first accessed.
        """
        try:
            if self._geai_config is not None:
                # Use explicit configuration
                logger.debug("Initializing GEAIClient with explicit authentication")
                config = self._geai_config
            else:
                # Fall back to environment variables
                logger.debug("Initializing GEAIClient from environment variables")
                config = GEAIConfig.from_env()

            self._geai_client = GEAIClientManager.get_client(config)
            logger.info("GEAIClient initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing GEAIClient: {e}")
            raise

    def refresh_geai_config(self, new_geai_config: Optional[GEAIConfig] = None) -> None:
        """
        Refresh the GEAI configuration and clear cached client.
        
        This is the primary method for updating authentication credentials or project 
        settings in SharedState. Call this method when:
        - User logs in (/login command)
        - User logs out (/logout command)
        - Project selection changes (/project command)
        - Any other authentication-related changes
        
        The method updates the stored configuration and clears the cached GEAIClient,
        forcing it to be re-initialized on next access with the new configuration.
        
        Args:
            new_geai_config: New GEAIConfig instance to use. If None, clears the config
                            so environment variables will be used on next access.
        
        Note:
            Direct assignment to the internal _geai_config attribute should be avoided.
            Always use this method to ensure the cached client is properly cleared.
        
        Example:
            >>> state = SharedState()
            >>> config = GEAIConfig.from_api_key(base_url="...", api_key="...")
            >>> state.refresh_geai_config(config)  # Updates config and clears cache
        """
        self._geai_config = new_geai_config
        self._geai_client = None
        logger.info(f"GEAI configuration refreshed. Next access will use new {'explicit' if new_geai_config else 'environment'} configuration")

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the shared state to a dictionary."""
        # Ensure all memories are initialized before serializing
        memories = self.memories

        # Serialize all memories
        memories_dict = {}
        for key, memory in memories.items():
            memories_dict[key] = memory.to_dict()

        # Create a copy of user_defined_rules without the content for serialization
        # Content is avoided since it could be too large
        rules_metadata = None
        if self.user_defined_rules:
            rules_metadata = self.user_defined_rules.copy()
            rules_metadata.pop('content', None)

        # Get the tool_manager's config_id if it's initialized
        tool_manager_config_id = None
        if self._tool_manager is not None:
            tool_manager_config_id = self._tool_manager.config_id

        return {
            "memories": memories_dict,
            "provider_name": self.provider_name,
            "model_name": self.model_name,
            "single_agent_provider_name": self.single_agent_provider_name,
            "single_agent_model_name": self.single_agent_model_name,
            "preferences": self.preferences,
            "usage": self.get_usage_summary(),
            "last_auto_save": self.last_auto_save.isoformat(),
            "user_defined_rules": rules_metadata,
            "tool_manager_config_id": tool_manager_config_id,
            "responses_chain_states": self.responses_chain_states,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any], geai_config: Optional[GEAIConfig] = None) -> "SharedState":
        """
        Create a SharedState instance from a dictionary.
        
        Args:
            data: Serialized state data
            geai_config: Optional GEAI configuration. If None, will use environment variables.
        
        Returns:
            SharedState instance with restored state
        """
        state = cls(geai_config=geai_config)

        # Load memories using type-aware deserialization
        memories_data = data.get("memories", {})
        for key, memory_data in memories_data.items():
            state._memories[key] = Memory.from_dict(memory_data)

        # Restore model/provider settings (with fallback to environment defaults)
        state.provider_name = data.get("provider_name", state.provider_name)
        state.model_name = data.get("model_name", state.model_name)
        state.single_agent_provider_name = data.get("single_agent_provider_name", state.single_agent_provider_name)
        state.single_agent_model_name = data.get("single_agent_model_name", state.single_agent_model_name)

        # Restore preferences
        state.preferences = data.get("preferences", {})

        # Ensure bash security preferences are initialized for existing sessions
        if "bash_security" not in state.preferences:
            state._initialize_bash_security_preferences()
        # Ensure omni upload preferences are initialized for existing sessions
        if "omni_upload" not in state.preferences:
            state._initialize_omni_upload_preferences()

        # Restore usage tracking
        usage = data.get("usage", {})
        state.total_cost = usage.get("total_cost", 0.0)
        state.total_tokens = usage.get("total_tokens", 0)
        state.completion_tokens = usage.get("completion_tokens", 0)
        state.prompt_tokens = usage.get("prompt_tokens", 0)
        responses_chain_states = data.get("responses_chain_states", {})
        if isinstance(responses_chain_states, dict):
            state.responses_chain_states = responses_chain_states
        else:
            state.responses_chain_states = {}

        # Restore auto-save timestamp
        if data.get("last_auto_save"):
            state.last_auto_save = datetime.fromisoformat(data.get("last_auto_save"))
        else:
            state.last_auto_save = datetime.now()

        # Restore tool_manager config_id if available
        tool_manager_config_id = data.get("tool_manager_config_id")
        if tool_manager_config_id:
            # Initialize tool_manager with the saved config_id
            # This will load the existing configuration file without modifying it
            state._tool_manager = ToolManager(config_id=tool_manager_config_id)

        # Restore user-defined rules metadata
        rules_metadata = data.get("user_defined_rules")
        if rules_metadata:
            state.user_defined_rules = rules_metadata.copy()

            # Backward compatibility for sessions that still persist git_root.
            if "vcs_root" not in state.user_defined_rules and state.user_defined_rules.get("git_root"):
                state.user_defined_rules["vcs_root"] = state.user_defined_rules.get("git_root")
            if "vcs_type" not in state.user_defined_rules and state.user_defined_rules.get("vcs_root"):
                state.user_defined_rules["vcs_type"] = "git"
            state.user_defined_rules.pop("git_root", None)
            state.user_defined_rules.setdefault("warnings", [])

            # If path metadata exists, try to reload the rules content.
            rules_multi_paths = state.user_defined_rules.get('paths') or []
            rules_single_path = state.user_defined_rules.get('path')
            if rules_multi_paths:
                try:
                    rules_result = read_and_concatenate_files(
                        rules_multi_paths,
                        max_chars=DEFAULT_MAX_CHARS,
                        max_lines=DEFAULT_MAX_LINES,
                    )
                    if rules_result['status'] in ['success', 'truncated']:
                        state.user_defined_rules['content'] = rules_result['content']
                    else:
                        state.user_defined_rules['content'] = None

                    state.user_defined_rules['char_count'] = rules_result.get('char_count', 0)
                    state.user_defined_rules['was_truncated'] = rules_result.get('was_truncated', False)
                    state.user_defined_rules['truncated_char_count'] = rules_result.get('truncated_char_count', 0)
                    state.user_defined_rules['line_count'] = rules_result.get('line_count', 0)
                    state.user_defined_rules['truncated_line_count'] = rules_result.get('truncated_line_count', 0)
                    state.user_defined_rules['status'] = rules_result.get('status')
                    state.user_defined_rules['error'] = rules_result.get('error')
                    state.user_defined_rules['warnings'] = rules_result.get('warnings', [])
                    state.user_defined_rules['last_reload_timestamp'] = datetime.now().isoformat()
                except Exception as e:
                    logger.error(f"Error loading user-defined rules: {e}")
                    state.user_defined_rules['content'] = None
                    state.user_defined_rules['status'] = 'error'
                    state.user_defined_rules['error'] = str(e)
                    state.user_defined_rules.setdefault('warnings', []).append(str(e))
            elif rules_single_path:
                try:
                    rules_result = read_user_defined_rules(path=rules_single_path)
                    if rules_result['status'] in ['success', 'truncated']:
                        state.user_defined_rules['content'] = rules_result['content']
                    else:
                        state.user_defined_rules['content'] = None

                    state.user_defined_rules['char_count'] = rules_result.get('char_count', 0)
                    state.user_defined_rules['was_truncated'] = rules_result.get('was_truncated', False)
                    state.user_defined_rules['truncated_char_count'] = rules_result.get('truncated_char_count', 0)
                    state.user_defined_rules['line_count'] = rules_result.get('line_count', 0)
                    state.user_defined_rules['truncated_line_count'] = rules_result.get('truncated_line_count', 0)
                    state.user_defined_rules['status'] = rules_result.get('status')
                    state.user_defined_rules['paths'] = rules_result.get('paths', [])
                    state.user_defined_rules['vcs_root'] = rules_result.get('vcs_root')
                    state.user_defined_rules['vcs_type'] = rules_result.get('vcs_type')
                    state.user_defined_rules['discovery_mode'] = rules_result.get('discovery_mode')
                    state.user_defined_rules['warnings'] = rules_result.get('warnings', [])
                    state.user_defined_rules['error'] = rules_result.get('error')
                    state.user_defined_rules['last_reload_timestamp'] = datetime.now().isoformat()
                except Exception as e:
                    logger.error(f"Error loading user-defined rules: {e}")
                    state.user_defined_rules['content'] = None
                    state.user_defined_rules['status'] = 'error'
                    state.user_defined_rules['error'] = str(e)
                    state.user_defined_rules.setdefault('warnings', []).append(str(e))

        return state

    def _initialize_memory_condenser(self, memory: Memory) -> None:
        """
        Initialize and attach a memory condenser to a memory instance if enabled.

        Args:
            memory: The memory instance to attach a condenser to
        """
        # Check if memory condensing is enabled
        condensing_enabled = SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_ENABLED).lower() == "true"

        if not condensing_enabled:
            # If not enabled, ensure no condenser is attached
            memory.condenser = None
            logger.info("Memory condensing is disabled, no condenser attached")
            return

        # Get condenser settings from environment variables
        threshold = float(SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_THRESHOLD))

        # Create the condenser without callbacks (these will be added by SingleAgent)
        condenser = MemoryCondenser(threshold=threshold)
        
        # Set the geai_client so the condenser uses current session credentials
        condenser.set_geai_client(self.geai_client)

        # Attach the condenser to the memory
        memory.condenser = condenser
        logger.info(f"Memory condenser attached with threshold={threshold}")

    def _resolve_responses_chain_scope(self, memory: Optional[Memory]) -> str:
        """
        Resolve the logical scope key used for persisted Responses chain state.

        Args:
            memory: Memory instance associated with the active agent.

        Returns:
            Scope key identifying where chain state should be stored.
        """
        if memory is self._memories.get(MEMORY_KEY_MAIN):
            return MEMORY_KEY_MAIN

        for key, candidate in self._memories.items():
            if candidate is not None and memory is candidate:
                return key

        return MEMORY_KEY_MAIN

    def _initialize_bash_security_preferences(self) -> None:
        """
        Initialize bash security preferences with default values from environment variables.

        This method is called during SharedState initialization to ensure bash security
        preferences are properly set up before any bash commands are executed.
        """
        # Get default security level from environment variable
        default_level = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_BASH_SECURITY_LEVEL)

        self.preferences["bash_security"] = {
            "max_auto_approve_level": default_level or "low",
            "disable_all_checks": False,
        }
        logger.info(f"Initialized bash security with level: {default_level}")

    def _initialize_omni_upload_preferences(self) -> None:
        """
        Initialize omni-parser upload preferences.

        Currently supports future auto-approval toggles without enforcing them here.
        """
        if "omni_upload" not in self.preferences:
            self.preferences["omni_upload"] = {
                # Reserved for future UI-driven auto-approval toggles
                "allow_all_over_limit": False,
            }
        logger.info("Initialized omni upload preferences")

    def create_configured_single_agent(
        self,
        provider_name: str = None,
        model_name: str = None,
        memory: Optional[Memory] = None,
        file_editor: Optional[FileEditor] = None,
        user_defined_rules: Optional[Dict[str, Any]] = None,
        agent_prompt: Optional[str] = None,
        agent_tools: Optional[List[str]] = None,
        excluded_tools: Optional[List[str]] = None,
        workspace_context: Optional[WorkspaceContext] = None,
        # Extensions for remote/customized agents
        llm_params: Optional[Dict[str, Any]] = None,
        use_coda_system_prompt: bool = True,
    ) -> SingleAgent:
        """
        Creates and configures a SingleAgent instance with all required dependencies and tools.

        This method uses the SharedState's geai_client and tool_manager to create the agent.
        It sets up the agent's memory, file editor, tool dependencies, and system prompt.

        Args:
            provider_name (str, optional): The name of the LLM provider.
                Defaults to self.single_agent_provider_name.
            model_name (str, optional): The name of the LLM model to use.
                Defaults to self.single_agent_model_name.
            memory (Optional[Memory], optional): The memory object for the agent.
                Defaults to shared state's main memory.
            file_editor (Optional[FileEditor], optional): The file editor instance.
                Defaults to a new FileEditor.
            user_defined_rules (Optional[Dict[str, Any]], optional): Additional user-defined rules.
                Defaults to shared state's rules.
            agent_prompt (Optional[str], optional): Additional prompt for the agent.
                Defaults to None.
            agent_tools (Optional[List[str]], optional): List of tool names for the agent.
                Defaults to None.
            excluded_tools (Optional[List[str]], optional): List of tool names to exclude from
                the agent's available tools. These exclusions are applied after the agent_tools
                filter.
            workspace_context (Optional[WorkspaceContext]): Metadata about the
                workspace environment.

        Returns:
            SingleAgent: A fully configured SingleAgent instance ready for use.
        """
        # Use default provider/model settings if not provided
        if provider_name is None:
            provider_name = self.single_agent_provider_name
        if model_name is None:
            model_name = self.single_agent_model_name

        # Use main memory if not provided
        if memory is None:
            # Ensure the main memory is initialized
            if MEMORY_KEY_MAIN not in self._memories or self._memories[MEMORY_KEY_MAIN] is None:
                self._initialize_memory(MEMORY_KEY_MAIN)
            memory = self._memories[MEMORY_KEY_MAIN]

        # Create defaults if not provided
        if file_editor is None:
            file_editor = FileEditor()

        # Use the shared state's tool manager
        # Register tool dependencies (only for enabled tools)
        enabled_tool_names = self.tool_manager.get_enabled_tool_names()
        for tool_name in enabled_tool_names:
            # File operations tools need the file editor
            if tool_name in ["edit", "view", "replace"]:
                self.tool_manager.register_tool_dependency(tool_name, "editor", file_editor)

            # External tools need the client
            if tool_name in GEAI_CLIENT_DEPENDENT_TOOLS:
                self.tool_manager.register_tool_dependency(tool_name, "client", self.geai_client)

        # Get enabled tools (dependencies will be injected automatically)
        # Resolve tools with explicit semantics:
        # - agent_tools is None: use all enabled tools
        # - agent_tools is []: disable tools
        # - agent_tools is a list of names: filter
        tools = self.tool_manager.get_enabled_tools()
        if agent_tools is not None:
            if len(agent_tools) == 0:
                tools = []
            else:
                tools = [tool for tool in tools if tool.name in agent_tools]

        # Apply excluded tools filter
        if excluded_tools:
            tools = [tool for tool in tools if tool.name not in excluded_tools]
            
        # Wire condensation callback from RunSkillTool to memory
        # This ensures the skill state tracker is notified when memory is condensed
        for tool in tools:
            if isinstance(tool, RunSkillTool):
                memory.set_condensation_callback(tool.on_memory_condensed)
                break

        # Build system prompt if requested
        system_prompt = None
        if use_coda_system_prompt:
            # Prepare additional context for system prompt
            additional_context: Dict[str, Any] = {}

            # Use provided user_defined_rules or fall back to shared state's rules if available
            rules_content = None
            if user_defined_rules and user_defined_rules.get('content'):
                rules_content = user_defined_rules.get('content')
            elif self.user_defined_rules and self.user_defined_rules.get('content'):
                rules_content = self.user_defined_rules.get('content')

            if rules_content:
                additional_context['user_defined_rules'] = rules_content

            # Create the system prompt with tools, workspace context and additional context
            system_prompt = create_system_prompt(
                tools=tools,
                workspace_context=workspace_context,
                additional_context=additional_context
            )

            if agent_prompt:
                system_prompt = create_agent_prompt(system_prompt, agent_prompt)

        # Create the LLM. Only pass params when explicitly provided to maintain
        # backwards-compat behavior expected by tests and existing callers.
        chatllm_kwargs = {
            "client": self.geai_client,
            "provider_name": provider_name,
            "model_name": model_name,
            "system_prompt": system_prompt,
            "responses_chain_state_store": self.responses_chain_states,
            "responses_chain_scope": self._resolve_responses_chain_scope(memory),
        }
        if llm_params is not None:
            chatllm_kwargs["params"] = llm_params

        llm = ChatLLM(**chatllm_kwargs)

        # Add system message to memory when in use to ensure consistency
        # This ensures token accounting and caching are properly initialized
        if system_prompt and memory is not None:
            memory.upsert_system_message(system_prompt)

        # Create and return the agent
        return SingleAgent(llm=llm, tools=tools, memory=memory, agent_prompt=agent_prompt)

    def record_agent_interaction(
        self,
        agent_name: str,
        user_input: str,
        result: Optional[Dict[str, Any]] = None,
        *,
        remote: bool = False
    ) -> None:
        """
        Append standardized interaction messages to the main memory for local or remote agents.

        Args:
            agent_name: The agent's name that was invoked.
            user_input: The user input sent to the agent.
            result: Optional result payload. If dict with 'content', that content is recorded.
            remote: Whether the agent was a remote GEAI agent.
        """
        try:
            main_memory = self.memories.get(MEMORY_KEY_MAIN)
            if not main_memory:
                logger.debug("No main memory available to record agent interaction")
                return

            if remote:
                user_msg = f"Remote GEAI agent {agent_name} processed this input: {user_input}"
            else:
                user_msg = f"Subagent called {agent_name} processed this input: {user_input}"

            main_memory.add_user_message(user_msg)

            content = None
            if isinstance(result, dict) and result.get('content'):
                content = result.get('content')
            elif isinstance(result, str):
                content = result

            if content:
                if remote:
                    assistant_msg = f"Remote GEAI agent {agent_name} returned this result: {content}"
                else:
                    assistant_msg = f"Subagent called {agent_name} Returned this result: {content}"
                main_memory.add_assistant_message(assistant_msg)
            else:
                main_memory.add_assistant_message("No response from remote GEAI agent" if remote else "No response from subagent")
        except Exception as exc:
            logger.debug(f"Failed to record agent interaction for {agent_name}: {exc}")

    def load_user_defined_rules(
        self,
        path: Optional[str] = None,
        cwd: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Load and persist AGENTS.md rules metadata in shared state.

        Args:
            path: Optional explicit rules file path to load.
            cwd: Optional working directory used to resolve relative paths.

        Returns:
            Updated `user_defined_rules` dictionary with content, counters, warnings, and status.
        """
        rules_result = read_user_defined_rules(
            path=path,
            cwd=cwd,
        )

        content = rules_result['content'] if rules_result['status'] in ['success', 'truncated'] else None
        self.user_defined_rules = {
            'content': content,
            'path': rules_result['path'],
            'paths': rules_result.get('paths', []),
            'vcs_root': rules_result.get('vcs_root'),
            'vcs_type': rules_result.get('vcs_type'),
            'discovery_mode': rules_result.get('discovery_mode'),
            'last_reload_timestamp': datetime.now().isoformat(),
            'char_count': rules_result.get('char_count', 0) if content else 0,
            'was_truncated': rules_result.get('was_truncated', False) if content else False,
            'truncated_char_count': rules_result.get('truncated_char_count', 0) if content else 0,
            'line_count': rules_result.get('line_count', 0) if content else 0,
            'truncated_line_count': rules_result.get('truncated_line_count', 0) if content else 0,
            'warnings': rules_result.get('warnings', []),
            'status': rules_result['status'],
            'error': rules_result.get('error')
        }

        for warning in self.user_defined_rules.get('warnings', []):
            logger.warning(warning)

        if rules_result['status'] == 'success':
            logger.info(f"Loaded user-defined rules from {rules_result['path']} ({rules_result['char_count']} characters)")
        elif rules_result['status'] == 'truncated':
            logger.warning(f"Loaded truncated user-defined rules from {rules_result['path']} ({rules_result['truncated_char_count']} characters)")
        elif rules_result['status'] == 'empty':
            logger.info(f"Rules file at {rules_result['path']} is empty")
        elif rules_result['status'] == 'not_found':
            logger.info(f"No user-defined rules found at {rules_result['path']}")
        else:
            logger.error(f"Error loading rules from {rules_result['path']}: {rules_result.get('error', 'Unknown error')}")

        return self.user_defined_rules
