import os
import json
import threading
import datetime
from contextlib import contextmanager
from typing import Tuple, Any, Generator
import portalocker
import chardet

from tinydb import TinyDB
from tinydb.table import Table
from tinydb_sqlite import SQLiteStorage

from loguru import logger

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig


class DatabaseManager:
    """
    Thread-safe database manager using SQLite storage backend.
    
    This class provides a thread-safe interface to TinyDB with SQLite storage.
    Each database operation opens a fresh per-thread connection and closes it
    afterwards so TinyDB table metadata never goes stale across the auto-save
    thread and the main thread.
    
    It also handles automatic migration from the legacy JSON format to SQLite
    when needed, ensuring a seamless transition for users.
    """
    
    # Thread-local storage for the connection used by the current operation.
    _thread_local = threading.local()

    def __init__(self, db_path: str, table_name: str) -> None:
        """
        Initialize the database manager.
        
        Args:
            db_path: Path to the database file
            table_name: Name of the table to use for storing sessions
            
        Note:
            This constructor only sets up the instance variables.
            The actual database connections are created lazily per-thread
            when get_db() is called.
        """
        self.db_path: str = db_path
        self.table_name: str = table_name
        self.initialized: bool = False


    def initialize(self) -> None:
        """
        Initialize the database connection with SQLite storage.
        
        This method:
        1. Checks if migration from JSON to SQLite is needed
        2. Performs migration if necessary, with proper locking
        3. Initializes the TinyDB connection with SQLite storage
        
        If migration fails, a new empty database will still be created to ensure
        the application can start. A warning will be logged in this case.
        
        Raises:
            RuntimeError: Only if database initialization completely fails
        """
        if not self.initialized:
            migration_failed = False
            sessions = None
            
            try:
                # Check if migration is needed
                if self._needs_migration():
                    # Acquire a lock file to prevent concurrent migrations
                    with self._migration_lock():
                        # Check again after acquiring the lock (another process might have migrated)
                        if self._needs_migration():
                            try:
                                logger.info(f"Starting migration for {self.db_path}")
                                # Get data from old database
                                sessions = self._get_json_data()
                                # Rename the old database
                                self._rename_json_database()
                            except Exception as migration_error:
                                # Log the error but continue with initialization
                                logger.error(f"Migration failed: {migration_error}")
                                logger.warning("Creating a new empty database instead")
                                migration_failed = True
                                
                                # If the original file still exists and we failed, move it aside
                                if os.path.exists(self.db_path):
                                    try:
                                        error_backup = f"{self.db_path}.error.bak"
                                        os.rename(self.db_path, error_backup)
                                        logger.warning(f"Moved problematic database to {error_backup}")
                                    except Exception as rename_error:
                                        logger.error(f"Failed to move problematic database: {rename_error}")
                        else:
                            logger.info(f"Another process completed migration for {self.db_path}")
                
                # Mark as initialized - connections will be created per-thread when needed
                self.initialized = True
                
                # Insert old sessions if we migrated successfully
                if sessions and not migration_failed:
                    try:
                        self._insert_migrated_sessions(sessions)
                    except Exception as insert_error:
                        logger.error(f"Failed to insert migrated sessions: {insert_error}")
                        logger.warning("Continuing with empty database")
                    
                logger.info(f"Initialized database manager for {self.db_path}")
            except Exception as e:
                logger.error(f"Failed to initialize database: {e}")
                # Clean up any thread-local resources that might have been created
                if hasattr(self._thread_local, 'db') and self._thread_local.db is not None:
                    try:
                        self._thread_local.db.close()
                    except:
                        pass
                    self._thread_local.db = None
                    self._thread_local.table = None
                
                # Instead of failing, create a new empty database with a different name
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                original_path = self.db_path
                self.db_path = f"{original_path}.{timestamp}.new"
                logger.warning(f"Using new database path after initialization failure: {self.db_path}")
                
                # Update the environment variable to persist the new database path
                try:
                    SETTINGS.set_env_var(EnvConfig.CODA_SESSION_DB_FILE_PATH, self.db_path)
                    logger.info(f"Updated 'CODA_SESSION_DB_FILE_PATH' environment variable to {self.db_path}")
                except Exception as env_error:
                    logger.error(f"Failed to update environment variable: {env_error}")
                    logger.warning("The new database path will not persist across CODA restarts")
                
                # Mark as initialized anyway to allow the application to continue
                self.initialized = True


    def close(self) -> None:
        """
        Close the database connection for the current thread and release resources.
        
        This method should be called when the database is no longer needed
        to ensure proper cleanup of resources.
        """
        if hasattr(self._thread_local, 'db') and self._thread_local.db is not None:
            # Close the database for this thread
            self._thread_local.db.close()
            self._thread_local.db = None
            self._thread_local.table = None
            logger.info(f"Closed database connection for {self.db_path} in thread {threading.current_thread().name}")
        
        # Only set initialized to False if we're in the main thread
        # This allows background threads to re-initialize if needed
        if threading.current_thread() is threading.main_thread():
            self.initialized = False


    @contextmanager
    def get_db(self) -> Generator[Tuple[TinyDB, Table], None, None]:
        """
        Context manager for thread-safe database operations.
        
        This method ensures each thread gets its own fresh database connection for
        the duration of a single operation. Reopening the connection each time keeps
        TinyDB's internal document-id bookkeeping in sync across threads.
        
        Yields:
            Tuple containing (TinyDB instance, Table instance) for the current thread
            
        Raises:
            Exception: Any exception that occurs during database operations
        """
        # Ensure database manager is initialized
        self.initialize()
        
        # Drop any leftover connection for this thread before creating a fresh one.
        if hasattr(self._thread_local, 'db') and self._thread_local.db is not None:
            try:
                self._thread_local.db.close()
            finally:
                self._thread_local.db = None
                self._thread_local.table = None

        thread_name = threading.current_thread().name
        logger.debug(f"Creating new database connection in thread {thread_name} for {self.db_path}")
        self._thread_local.db = TinyDB(storage=SQLiteStorage, connection=self.db_path)
        self._thread_local.table = self._thread_local.db.table(self.table_name)
        
        try:
            # Yield the thread-local database and table
            yield (self._thread_local.db, self._thread_local.table)
        except Exception as e:
            logger.error(f"Error during database operation: {e}")
            raise
        finally:
            if hasattr(self._thread_local, 'db') and self._thread_local.db is not None:
                self._thread_local.db.close()
                self._thread_local.db = None
                self._thread_local.table = None


    @contextmanager
    def _migration_lock(self) -> Generator[None, None, None]:
        """
        Context manager for acquiring a lock during migration.
        
        This prevents multiple processes from migrating simultaneously by
        using portalocker to create an exclusive lock on a temporary file.
        
        Yields:
            None
            
        Raises:
            RuntimeError: If unable to acquire the lock after multiple attempts
        """
        lock_path = f"{self.db_path}.lock"
        lock_file = None
        
        try:
            # Create or open the lock file
            lock_file = open(lock_path, 'w')
            
            # Try to acquire an exclusive lock
            portalocker.lock(lock_file, portalocker.LOCK_EX)
            logger.debug(f"Acquired migration lock: {lock_path}")
            yield
            
        finally:
            # Release the lock and close/remove the file
            if lock_file:
                try:
                    portalocker.unlock(lock_file)
                    lock_file.close()
                    os.unlink(lock_path)
                    logger.debug(f"Released migration lock: {lock_path}")
                except Exception as e:
                    logger.warning(f"Error releasing migration lock: {e}")


    def _needs_migration(self) -> bool:
        """
        Check if the database needs migration from JSON to SQLite.
        
        This method checks if the database file exists and is not already
        in SQLite format.
        
        Returns:
            True if migration is needed, False otherwise
        """
        try:
            return os.path.exists(self.db_path) and not self._is_sqlite_database(self.db_path)
        except Exception as e:
            logger.error(f"Error checking if migration is needed: {e}")
            return False


    def _is_sqlite_database(self, file_path: str) -> bool:
        """
        Check if the file is an SQLite database.
        
        This method examines the file header to determine if it's an SQLite database.
        SQLite database files always begin with the string "SQLite format 3\0".
        
        Args:
            file_path: Path to the file to check
            
        Returns:
            True if the file is an SQLite database, False otherwise
        """
        # SQLite database file header is always "SQLite format 3\0"
        header = b'SQLite format 3\0'
        
        try:
            with open(file_path, 'rb') as f:
                file_header = f.read(len(header))
                return file_header == header
        except Exception as e:
            logger.error(f"Error checking if file is SQLite database: {e}")
            return False


    def _get_json_data(self) -> Any:
        """
        Get data from JSON database.
        
        This method reads the JSON database file and extracts the sessions
        from the specified table. It uses chardet to detect the file encoding.
        
        Returns:
            List of sessions from the JSON database
            
        Raises:
            RuntimeError: If unable to read the JSON database
        """
        logger.info(f"Detected old JSON database. Migrating to SQLite backend: {self.db_path}")
        
        try:
            # Read the file in binary mode first
            with open(self.db_path, 'rb') as f:
                raw_data = f.read()
            
            # Use chardet to detect the encoding
            detection_result = chardet.detect(raw_data)
            detected_encoding = detection_result['encoding']
            confidence = detection_result['confidence']
            
            logger.info(f"Detected {detected_encoding} encoding with confidence {confidence} for {self.db_path}")
            
            # If confidence is too low or encoding is None, fall back to utf-8
            if not detected_encoding or confidence < 0.7:
                logger.warning(f"Low confidence encoding detection ({confidence}) for {self.db_path}. Falling back to utf-8")
                detected_encoding = 'utf-8'
            
            # Decode the raw data with the detected encoding
            try:
                decoded_data = raw_data.decode(detected_encoding)
                json_data = json.loads(decoded_data)
                logger.info(f"Successfully read {self.db_path} JSON with {detected_encoding} encoding")
            except (UnicodeDecodeError, json.JSONDecodeError) as e:
                # If the detected encoding fails, try latin-1 as a fallback
                # (latin-1 never fails to decode but might produce garbage)
                logger.warning(f"Failed with {detected_encoding} encoding for {self.db_path}: {e}, trying latin-1 fallback")
                decoded_data = raw_data.decode('latin-1')
                json_data = json.loads(decoded_data)
                logger.warning("Successfully read with latin-1 fallback, but data might be corrupted")
            
            # Extract sessions from the JSON data
            sessions = []
            if self.table_name in json_data:
                raw_sessions = json_data[self.table_name]
                
                # Ensure sessions is a list of dictionaries
                if isinstance(raw_sessions, list):
                    for item in raw_sessions:
                        if isinstance(item, dict):
                            sessions.append(item)
                        else:
                            # Convert non-dict items to dict if possible
                            logger.warning(f"Converting non-dictionary session to dictionary: {type(item)}")
                            try:
                                if hasattr(item, '__dict__'):
                                    sessions.append(item.__dict__)
                                else:
                                    sessions.append({"value": str(item)})
                            except Exception as conv_error:
                                logger.error(f"Failed to convert session to dictionary: {conv_error}")
                elif isinstance(raw_sessions, dict):
                    # If it's a dict of dicts, convert to list of dicts
                    for key, value in raw_sessions.items():
                        if isinstance(value, dict):
                            value['_id'] = key  # Add the key as _id
                            sessions.append(value)
                        else:
                            sessions.append({"_id": key, "value": value})
            
            logger.info(f"Found {len(sessions)} sessions in JSON database")
            return sessions
        except Exception as e:
            logger.error(f"Failed to read JSON database: {e}")
            raise RuntimeError(f"Failed to read JSON database: {e}")


    def _rename_json_database(self) -> bool:
        """
        Rename the JSON database file to make way for the SQLite database.
        
        This method renames the JSON database file to create a backup with
        the .json.bak extension, making way for the new SQLite database file.
        
        Returns:
            True if successful
            
        Raises:
            RuntimeError: If unable to rename the database file
        """
        backup_path = f"{self.db_path}.json.bak"
        
        try:
            # Use atomic rename operation
            os.rename(self.db_path, backup_path)
            logger.info(f"Renamed JSON database to {backup_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to rename JSON database: {e}")
            raise RuntimeError(f"Failed to rename JSON database: {e}")


    def _insert_migrated_sessions(self, sessions: Any) -> bool:
        """
        Insert migrated sessions into the SQLite database.
        
        This method inserts the sessions extracted from the JSON database
        into the newly created SQLite database. It creates a thread-local
        temporary connection specifically for migration.
        
        Args:
            sessions: List of session dictionaries to insert
            
        Returns:
            True if successful
            
        Raises:
            RuntimeError: If unable to insert sessions
        """
        if not sessions:
            logger.info("No sessions to migrate")
            return True
        
        # Save existing thread-local connection if any
        original_db = None
        original_table = None
        if hasattr(self._thread_local, 'db') and self._thread_local.db is not None:
            original_db = self._thread_local.db
            original_table = self._thread_local.table
            
        try:
            # Create a thread-local temporary connection just for migration
            thread_name = threading.current_thread().name
            logger.debug(f"Creating temporary migration connection in thread {thread_name} for {self.db_path}")
            self._thread_local.db = TinyDB(storage=SQLiteStorage, connection=self.db_path)
            self._thread_local.table = self._thread_local.db.table(self.table_name)
            
            # Insert all sessions
            successful_inserts = 0
            failed_inserts = 0
            
            for session in sessions:
                try:
                    # Final check to ensure session is a dictionary
                    if not isinstance(session, dict):
                        logger.warning(f"Skipping non-dictionary session during insert: {type(session)}")
                        failed_inserts += 1
                        continue
                        
                    self._thread_local.table.insert(session)
                    successful_inserts += 1
                except Exception as insert_error:
                    logger.warning(f"Failed to insert individual session: {insert_error}")
                    failed_inserts += 1
            
            # Close the temporary connection
            self._thread_local.db.close()
            
            if failed_inserts > 0:
                logger.warning(f"Some sessions could not be migrated: {failed_inserts} failed, {successful_inserts} succeeded")
            
            logger.info(f"Successfully migrated {successful_inserts} sessions to SQLite database")
            return True
        except Exception as e:
            logger.error(f"Failed to insert migrated sessions: {e}")
            # This is a critical error during migration
            raise RuntimeError(f"Failed to insert migrated sessions: {e}")
        finally:
            # Restore original connection if there was one
            if original_db is not None:
                self._thread_local.db = original_db
                self._thread_local.table = original_table
            else:
                # Clean up thread-local storage
                self._thread_local.db = None
                self._thread_local.table = None
