# Session Management System

## Overview

The Session Management System allows the CODA Core application to save and load application state across multiple sessions. This enables users to:

- Save their current state (selected files, conversation history, model preferences)
- Load previously saved sessions
- Switch between different sessions
- Manage sessions (rename, delete)
- Automatically rename sessions based on conversation content

## Architecture

The session management system is designed with a modular architecture that separates concerns and supports multiple client types:

```mermaid
flowchart TD
    A[SessionManager] --> B[Session]
    B --> C[SharedState]
    B --> D[ClientState]
    A --> H[DatabaseManager]
    H --> I[SQLite Storage]
    A --> J[Context Management]
    J --> K[Session Context]
    A --> L[Background Threads]
    L --> M[Auto-Save Thread]
    L --> N[Lock Monitor Thread]
```

### Core Components

| Component | Responsibility | Key Features |
|-----------|----------------|--------------|
| **Session** | Represents a single session | • Metadata and state storage<br>• Session locking<br>• Shared and client-specific state<br>• Auto-renaming based on conversation content |
| **SharedState** | Manages shared state | • Conversation memory<br>• Model preferences<br>• Security preferences<br>• Usage tracking<br>• GEAIClient (lazily initialized)<br>• ToolManager (lazily initialized)<br>• Token counting settings with cache serialization<br>• Memory condenser configuration and persistence<br>• Context window management with standardized buffers<br>• Serialization support (excluding sensitive data) |
| **ClientState** | Interface for client-specific state | • Abstract base class<br>• Defines common interface<br>• Extensible for new client types |
| **SessionManager** | Manages session lifecycle | • CRUD operations<br>• Session locking<br>• Auto-saving<br>• Lock monitoring<br>• Context management<br>• Background threads<br>• Model switching support<br>• Session auto-renaming<br>• LLM usage tracking |
| **DatabaseManager** | Manages database operations | • SQLite backend<br>• Migration from JSON<br>• Thread-safe operations<br>• Connection management<br>• Error handling and recovery |

### Key Features

#### Session Locking

Sessions can be locked to prevent conflicts when multiple clients try to access the same session. The locking system ensures data integrity in multi-process environments.

| Feature | Description | Implementation |
|---------|-------------|----------------|
| **Basic Locking** | Exclusive access control | • Session locked with process ID<br>• Lock denied for other processes<br>• Automatic unlock on session close |
| **Activity-Based Renewal** | Prevents expiration during use | • Refreshed on user activity<br>• Auto-save renews locks<br>• Prevents timeouts during active use |
| **Process Health Monitoring** | Handles unexpected terminations | • Monitors lock-holding processes<br>• Auto-releases locks from dead processes<br>• Background thread for cleanup |
| **Lock Expiration** | Handles stale locks | • Locks expire after 30 minutes of inactivity<br>• Allows recovery from crashed processes<br>• Checked during session listing |
| **Lock Status Checking** | Validates lock state | • API to check if a session is locked<br>• Determines if locked by current process<br>• Used for UI feedback |

```mermaid
sequenceDiagram
    participant User
    participant SessionManager
    participant Session
    participant LockMonitor
    
    User->>SessionManager: Load session
    SessionManager->>Session: Acquire lock
    Session-->>SessionManager: Lock acquired
    SessionManager->>LockMonitor: Start monitoring
    
    loop User Activity
        User->>SessionManager: Perform action
        SessionManager->>Session: Renew lock
    end
    
    loop Every 5 minutes
        LockMonitor->>SessionManager: Check for stale locks
        SessionManager->>SessionManager: Clean up dead process locks
    end
    
    User->>SessionManager: Close session
    SessionManager->>Session: Release lock
    SessionManager->>LockMonitor: Stop monitoring
```

#### Auto-Saving

The system supports automatic saving of sessions at regular intervals:

- The SharedState class tracks the last auto-save timestamp
- The SessionManager periodically checks if auto-save should be triggered
- If enough time has elapsed since the last auto-save, the session is saved automatically

#### Client-Specific State

The system supports different types of clients with their own state:

- The Session class stores a dictionary of client states by client type
- Each client type has its own ClientState implementation
- This allows for seamless addition of new client types (e.g., web, GUI)

## Data Flow

```mermaid
flowchart TD
    A[User Starts Application] --> B[SessionManager Initializes]
    B --> C[Clean Stale Locks]
    B --> D[List Available Sessions]
    D --> E{User Selection}
    
    E -->|Create New| F[Create Session]
    E -->|Load Existing| G[Load Session]
    
    F --> H[Set Session Context]
    G --> H
    H --> I[Start Background Threads]
    
    I --> J[Auto-Save Thread]
    I --> K[Lock Monitor Thread]
    
    L[User Interaction] --> M[Renew Session Lock]
    L --> N[Update State]
    
    J --> O[Periodic Auto-Save]
    K --> P[Check for Dead Processes]
    
    Q[User Exits] --> R[Stop Background Threads]
    R --> S[Unlock Session]
    S --> T[Clear Session Context]
```

The session lifecycle follows these steps:

1. User starts the application
2. SessionManager initializes and cleans any stale locks
3. Application presents a list of available sessions
4. User selects a session or creates a new one
5. SessionManager loads the selected session, restores state, and locks the session
6. SessionManager sets the session context for logging with session ID and name
7. SessionManager starts background threads for auto-saving and lock monitoring, passing the session context
8. User interacts with the application
9. Session locks are renewed with each user interaction
10. Changes to state are auto-saved periodically by background threads (with proper session context)
11. User can explicitly save, load, rename, or delete sessions
12. When the application exits, background threads are stopped, sessions are unlocked, and session context is cleared

### Session Auto-Renaming

The system includes an intelligent session auto-renaming feature:

- **Automatic Session Naming**: Sessions are automatically renamed based on the content of the conversation
- **Efficient Model Usage**: Uses a smaller, cost-effective model (gpt-4o-mini by default) for generating session names
- **Consistent Naming Format**: Names are generated in kebab-case format (e.g., "stock-trading-app")
- **Usage Tracking**: LLM usage for session renaming is properly tracked and included in overall usage statistics
- **Intelligent Triggers**: Auto-renaming is triggered after sufficient conversation context is available
- **Fallback Mechanisms**: If renaming fails, the system falls back to directory-based naming
- **Manual Override**: Users can still manually rename sessions, which disables auto-renaming for that session
- **Background Processing**: Renaming happens in a background thread to avoid blocking the main application

The auto-renaming process follows these steps:

1. User interacts with CODA and adds messages to the conversation
2. After sufficient context is available (at least 2 user messages), auto-renaming is triggered
3. A background thread extracts user messages and sends them to a small LLM model
4. The LLM generates a descriptive name based on the conversation content
5. The name is validated for format (kebab-case) and length (4-30 characters)
6. If valid, the session is renamed with the generated name
7. Usage statistics from the LLM call are tracked and added to overall usage
8. If the process fails at any point, a fallback name based on the current directory is used

## Persistence

Sessions are persisted using a robust database implementation:

| Aspect | Implementation |
|--------|----------------|
| **Storage Engine** | SQLite via TinyDB with SQLiteStorage |
| **Database Location** | CODA Core configuration directory (`~/.coda/sessions.db`) |
| **Migration Support** | Automatic migration from legacy JSON format |
| **Document Structure** | • Session metadata (ID, name, creation time, etc.)<br>• Shared state (conversation history, preferences, token count cache)<br>• Client-specific state (by client type) |
| **Concurrency** | SQLite's transaction management with thread-local storage for connections |
| **Performance** | Optimized for concurrent access with proper connection handling |
| **Backup Strategy** | Automatic backups before migration operations and during recovery |
| **Encoding Support** | Smart encoding detection for international character sets |
| **Recovery Mechanism** | Environment variable persistence for database path changes |

### Database Manager

The `DatabaseManager` class provides a centralized interface for database operations:

- **Initialization**: Sets up the SQLite database with proper connection handling
- **Migration**: Automatically migrates from legacy JSON format to SQLite
- **Session CRUD**: Complete Create, Read, Update, Delete operations for sessions
- **Concurrency Control**: Thread-safe operations with thread-local storage for SQLite connections
- **Error Handling**: Robust error recovery and graceful degradation
- **Testing Tools**: Comprehensive stress testing and validation tools
- **Thread Safety**: Thread-local storage for SQLite connections to prevent "SQLite objects created in a thread can only be used in that same thread" errors
- **Encoding Detection**: Automatic detection of file encoding using chardet when reading JSON databases
- **Self-Healing**: Automatic recovery from database corruption with environment variable persistence
- **Fallback Mechanisms**: Multiple encoding fallback options to handle various international character sets

The database implementation has been thoroughly tested for concurrent access scenarios using dedicated stress testing tools (`database_stress_test.py` and `database_manager_test.py`).

## Integration

### Client Integration

The session management system can integrate with any client that extends the ClientState class.

### Memory and Model Integration

The session management system integrates with the memory and model systems:

- Persists token counting settings and cache across sessions for improved performance
- Uses standardized constants for context window management across the codebase
- Manages model preferences that affect context window limits
- Preserves memory state when switching between models with different context windows
- Ensures the inequality `input + max_output <= context limit` is consistently enforced
- Stores conversation patterns for optimizing token usage
- Supports seamless model switching with appropriate memory adjustments

#### Memory Migration

The system includes a sophisticated memory migration capability with percentage-based allocation:

- **Percentage-Based Allocation**: Uses consistent (default) percentages to allocate the context window:
  - 70% for conversation history (memory)
  - 20% for model output (max output tokens)
  - 10% as safety buffer
- **Context Window Adaptation**: When switching between models with different context window sizes, the system automatically adapts the memory content to fit within the new constraints
- **Proportional Scaling**: Memory allocation scales proportionally with context window size, maintaining the same percentage allocations
- **Intelligent Message Removal**: During migration to a model with a smaller context window, the system intelligently removes older messages while preserving conversation coherence
- **Extreme Downgrade Handling**: Handles cases where the new memory capacity is smaller than the current usage by prioritizing recent messages
- **Token Limit Adjustment**: Adjusts the maximum token limit based on the new model's context window size using percentage constants
- **Cache Migration**: Preserves and migrates token count cache during model switching for performance
- **Cache Invalidation**: Selectively clears token count cache entries for removed messages
- **Preservation of Critical Context**: Prioritizes keeping recent and contextually important messages during migration
- **Enhanced Migration Logging**: Provides detailed logs of the migration process, including model changes, context window sizes, and memory allocations
- **Seamless User Experience**: Handles all migration complexities transparently to provide a smooth user experience when switching models

The memory migration process follows these steps:

1. User selects a new model with a different context window size
2. SessionManager identifies the change in context window size and logs the model change request
3. Memory migration is initiated with detailed logging of the process
4. Max output tokens are capped to 20% of the new context window
5. Memory allocation is set to 70% of the new context window
6. Memory content is evaluated against the new context window constraints
7. If necessary, older messages are intelligently removed to fit within the new constraints
8. Token count cache entries for removed messages are selectively invalidated
9. Remaining token count cache is preserved for performance
10. Migration results are logged, including token counts and capacity percentages
11. Updated memory state with cache is persisted in the session
12. User can continue the conversation with the new model without disruption

### Logging Integration

The session management system integrates with the logging system through session context:

- When a session is created or loaded, the SessionManager sets the session context for logging
- Session context includes the session ID and name, which appear in all log entries
- When a session ends or is unloaded, the session context is cleared
- Background threads (auto-save, lock monitoring) capture and restore the session context
- This ensures all log entries are properly attributed to the correct session

The session context propagation mechanism ensures that even operations in background threads are properly attributed to the originating session in the logs. This provides several benefits:

- Clear traceability of operations across the application
- Ability to filter logs by session ID or name
- Distinction between session-specific and system-level operations
- Proper attribution of background operations like auto-saving

For example, when the auto-save thread runs, it includes the session ID and name in its log entries, making it clear which session is being auto-saved. Similarly, when the lock monitor thread runs, it includes the session context in its log entries.

## Extensibility

The system is designed to be extensible:

| Extension Point | Description | Implementation Approach |
|-----------------|-------------|-------------------------|
| **Client Types** | Adding support for new client interfaces | Implement the ClientState abstract class and register the new client type with SessionManager |
| **Shared State** | Extending the shared state model | Add new fields to SharedState with appropriate serialization/deserialization support |
| **Session Operations** | Adding new session management operations | Extend SessionManager with new methods that maintain the locking and context propagation patterns |
| **Persistence Model** | Changing how sessions are stored | Replace or extend the TinyDB implementation while maintaining the same interface |
| **Background Tasks** | Adding new background processing | Follow the thread context propagation pattern used by auto-save and lock monitoring |

## Session Preferences

The session management system supports storing and managing user preferences that persist across sessions. These preferences allow users to customize their experience and configure security settings.

### Security Preferences

The system includes security preferences for bash command execution:

| Preference | Description | Options |
|------------|-------------|---------|
| **Bash Security** | Controls the auto-approval level for bash commands | • LOW (default): Auto-approves SAFE and LOW risk commands<br>• MEDIUM: Auto-approves SAFE, LOW, and MEDIUM risk commands<br>• HIGH: Auto-approves all except CRITICAL risk commands |

### Memory Condensing Preferences

The system includes preferences for memory condensing:

| Preference | Description | Options |
|------------|-------------|---------|
| **Memory Condensing** | Controls whether memory condensing is enabled | • Enabled (default): Automatically condenses older messages when threshold is reached<br>• Disabled: No automatic condensing of messages |
| **Condensing Threshold** | The memory usage percentage that triggers condensing | • Range: 30-90% (default: 50%)<br>• Higher values preserve more context but save fewer tokens<br>• Lower values save more tokens but condense more frequently |

#### Managing Preferences

Preferences can be managed through the CLI using the `/prefs` command:

```mermaid
flowchart TD
    A["'/prefs' command"] --> B["Session Preferences Menu"]
    B --> C["Bash Command Security"]
    C --> D["Set Maximum Auto-approve Level"]
    C --> E["Reset to Defaults"]
    D --> F["LOW"]
    D --> G["MEDIUM"]
    D --> H["HIGH"]
    C --> I["Back to Main Menu"]
```
The preferences are stored in the SharedState and are automatically saved with the session. This allows users to have different security settings for different sessions, providing flexibility while maintaining security.

### Tool Management

The system includes a robust tool management system through the `ToolManager` property in `SharedState`:

Feature | Description | Implementation |
|---------|-------------|----------------|
**Lazy Initialization** | ToolManager is only initialized when first accessed | • Created on first access to the `tool_manager` property<br>• Automatically loads configuration from file if it exists<br>• Registers default tools for new configurations |
**Configuration Persistence** | Tool settings are stored in JSON | • Each ToolManager has a unique config_id<br>• Configuration is saved to `~/.coda/.tools/{config_id}_tools.json`<br>• Includes tool metadata, enabled status, and categories |
**Tool Categories** | Tools are organized by type and category | • Types: BASIC, EXTENDED, EXPERIMENTAL<br>• Categories: SYSTEM, FILE_OPERATIONS, etc.<br>• BASIC tools cannot be disabled or removed |
**Dependency Injection** | Tools can have dependencies injected | • Dependencies registered with the ToolManager<br>• Injected during tool instantiation<br>• Only registered for enabled tools |
**Performance Optimization** | Efficient configuration management | • Batch registration without saving after each tool<br>• Configuration saved once after all tools are registered<br>• Reduces disk I/O during initialization |
**Dynamic Tool Management** | Tools can be enabled/disabled during a session | • CLI `/tools` command provides user interface<br>• Tools can be listed, enabled, and disabled<br>• Changes are persisted to configuration files<br>• Tool transition messages inform the LLM about changes |
**Tool Registry Integration** | Centralized tool registration | • ToolRegistry handles tool class registration<br>• ToolManager uses registry for instantiation<br>• Consistent tool access across the system |

The tool management system integrates with the agent creation process:

```mermaid
flowchart TD
    A[User starts application] --> B[SharedState initializes]
    B --> C[Session loaded]
    C --> D[CLI requests single agent]
    D --> E[tool_manager lazily initialized]
    E --> F[Configuration loaded from file]
    G[create_single_agent called] --> H[Get enabled tool names]
    H --> I[Register dependencies for enabled tools]
    I --> J[Get enabled tools with dependencies]
    J --> K[SingleAgent created with tools]
```

This architecture ensures that:
1. Tool configuration is persisted across sessions
2. Basic tools are always available
3. Tool dependencies are only registered when needed
4. Configuration changes are properly saved
5. Tools are consistently available to all components that need them

### User-Defined Rules

The system supports user-defined rules that can be loaded from a file and applied to the system prompt for the single agent:

| Feature | Description | Implementation |
|---------|-------------|----------------|
| **Rule Source** | Rules are read from `AGENTS.md` files discovered from VCS root to the current working directory | • Automatically loaded at startup<br>• Can be reloaded with the `/rr` command<br>• Path can be customized when reloading |
| **Rule Storage** | Rules are stored in SharedState | • Content is stored in memory<br>• Metadata is serialized (path, status, etc.)<br>• Content is reloaded when session is loaded |
| **Rule Application** | Rules are applied to system prompts | • Integrated into the SingleAgent system prompt<br>• Applied immediately when reloaded |
| **Status Handling** | Different statuses are tracked | • Success: Rules loaded successfully<br>• Truncated: Rules were too large and truncated<br>• Empty: Rules file exists but is empty<br>• Not Found: Rules file doesn't exist<br>• Error: Error occurred while loading rules |
| **Path Handling** | Support for various path formats | • Relative paths from current directory<br>• Absolute paths<br>• Drag-and-drop support (quotes are stripped) |

Rules are loaded when CODA starts, and can be reloaded at any time using the `/rr` command. When rules are reloaded, they are immediately applied to the system prompt of any existing single agent.

```mermaid
flowchart TD
    A[CODA Starts] --> B[Load AGENTS.md]
    B --> C{File exists?}
    C -->|Yes| D[Store in SharedState]
    C -->|No| E[Log file not found]
    D --> F[Apply to system prompts]
    
    G[User runs /rr] --> H[Reload rules]
    H --> I{File exists?}
    I -->|Yes| J[Update SharedState]
    I -->|No| K[Clear rules from SharedState]
    J --> L[Update system prompts]
    K --> L
```

The rules files (`AGENTS.md`) should contain custom instructions that will be added to the system prompt. Legacy `codarules.md` files are automatically migrated to `AGENTS.md` with a warning for transparency.


## Database Testing Tools

The system includes specialized tools for testing database performance and reliability:

| Tool | Purpose | Features |
|------|---------|----------|
| **database_manager_test.py** | Direct testing of DatabaseManager | • Tests concurrent database access<br>• Validates migration functionality<br>• Tests error handling and recovery<br>• Verifies proper resource cleanup |
| **database_stress_test.py** | High-level session testing | • Tests through SessionManager interface<br>• Simulates concurrent session operations<br>• Measures locking issues and performance<br>• Validates robustness under load |

### Test Parameters

Both test scripts accept the same parameters:

```bash
--processes N    Number of concurrent processes to run (default: 10)
--iterations N   Number of iterations per process (default: 20)
--delay N        Delay between operations in ms (default: 100)
--output FILE    Output file for results (default varies by script)
--verbose        Enable verbose output
```

For example, to run a standard test:

```bash
python scripts/database/database_stress_test.py --processes 10 --iterations 20 --delay 100 --verbose
```

These tools are essential for ensuring database reliability in concurrent environments.
