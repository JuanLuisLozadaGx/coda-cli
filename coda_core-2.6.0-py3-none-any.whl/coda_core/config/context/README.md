# Context

This module defines all schemas and logic related to the management of the Context needed for the CODA agents.

## Module Components
- **schemas**: This file contains all schemas used to represent different types of Contexts.

## Module Logic
This module is vital for the CODA agents to work properly.

The idea behind this module is to provide a clear format on what Context data is expected from the different agents defined at CODA and provide the different `coda-core` users a way to use them to further customize our agents to their needs.

## Key Entities
The principal entity here is the `Context` itself, which is just an object containing information for the agents to use.

## Context DTO's
Each Context has its own schema represented as a Pydantic model that encapsulates all the properties and data it uses. To further read on what data they contain check their definition in the [schemas file](/coda_core/config/context/schemas.py).

### EnvironmentContext
The `EnvironmentContext` is used to encapsulate all data related to environment information of the place where the client is working.

### CodebaseContext
The `CodebaseContext` is used to encapsulate all data related to the codebase of the place where the client is working.

### VCSContext
The `VCSContext` is used to encapsulate all data related to version control systems of the place where the client is working

### WorkspaceContext
The `WorkspaceContext` is used to encapsulate all Context data. This schema is a composite of the previous Contexts, meaning it has all
information needed for the CODA Agent to operate correctly.
