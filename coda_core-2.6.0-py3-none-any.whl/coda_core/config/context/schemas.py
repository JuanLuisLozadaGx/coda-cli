from typing import Dict, Optional

from pydantic import BaseModel


class EnvironmentContext(BaseModel):
    """
    EnvironmentContext schema to receive environment-related information used to generate context for agents.

    The information contained in this schema is used to generate the `env_info` section of the
    CODA Agent system prompt.

    Attributes:
        workspace_path (str): Path to the workspace directory.
        current_date (str): Current date in `YYYY-MM-DD` format.
        os_name (str): Name of the operating system of the client.
        os_release (str): Release version of the operating system.
    """
    workspace_path: str
    current_date: str
    os_name: str
    os_release: str

    def __str__(self) -> str:
        """
        String representation of the EnvironmentContext.

        The generated message is injected in the CODA Agent system prompt under the `env_info` section.

        Returns:
            str: Formatted string containing environment details.
        """
        return f"Working directory: {self.workspace_path}\n" \
            f"Today's date: {self.current_date}\n" \
            f"Platform: {self.os_name}\n" \
            f"OS release: {self.os_release}"


class CodebaseContext(BaseModel):
    """
    CodebaseContext schema to receive codebase-related information used to generate context for agents.

    The information contained in this schema is used to generate the `dir_info` section of the
    CODA Agent system prompt.

    Attributes:
        workspace_tree (str): The file tree structure of the workspace.
    """
    workspace_tree: str

    def __str__(self) -> str:
        """
        String representation of the CodebaseContext.

        The generated message is injected in the CODA Agent system prompt under the `dir_info` section.

        Returns:
            str: Formatted string containing the directory structure.
        """
        return self.workspace_tree


class VCSContext(BaseModel):
    """
    VCSContext schema to receive version control system-related information used to generate context for agents.

    The information contained in this schema is used to generate the `git_info` section of the
    CODA Agent system prompt.

    Attributes:
        repo_name (Optional[str]): Optional name of the repository.
        repo_branch (Optional[str]): Optional current branch of the repository.
    """
    repo_name: Optional[str] = None
    repo_branch: Optional[str] = None

    def __str__(self) -> str:
        """
        String representation of the VCSContext.

        The generated message is injected in the CODA Agent system prompt under the `git_info` section.

        Returns:
            str: Formatted string containing VCS details.
        """
        if not self.repo_name:
            return "Not a repository"

        return f"Repository: {self.repo_name}\n" \
            f"Branch: {self.repo_branch or 'branch info not available'}"


class WorkspaceContext(BaseModel):
    """
    Workspace context schema. This will contain information to provide context to
    different agents defined in the CODA system.

    **Note**: this is an initial version of a Context definition. It can be further enhanced with more
    schemas and validations, but for now it'll serve as a way to work backwards with the existing
    system prompt initialization logic.

    Attributes:
        environment_context (EnvironmentContext): The environment context information.
        codebase_context (CodebaseContext): The codebase context information.
        vcs_context (Optional[VCSContext]): Optional version control system context information.
    """
    environment_context: EnvironmentContext
    codebase_context: CodebaseContext
    vcs_context: Optional[VCSContext] = None


    def to_dict(self) -> Dict[str, str]:
        """
        Generate a dictionary representation of the WorkspaceContext, used to initialize system prompt of
        the CODA agent.

        Returns:
            (Dict[str, str]): Dictionary with keys:
                - env_info: String representation of the environment context.
                - dir_info: Directory structure of the codebase.
                - git_info: String representation of the VCS context or a default message if not available.
        """
        return {
            "env_info": str(self.environment_context),
            "dir_info": str(self.codebase_context),
            "git_info": str(self.vcs_context) if self.vcs_context else "No VCS information available"
        }
