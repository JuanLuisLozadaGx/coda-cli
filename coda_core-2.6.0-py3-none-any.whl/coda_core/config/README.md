# Configuration Module

The configuration module provides a centralized system for managing application settings, environment variables, logging, system information, and upgrade management in the CODA Core application.

## Overview

This module handles various aspects of application configuration:

- **Environment Variables Management**: Loading, storing, and accessing environment variables
- **Logging Configuration**: Setting up structured logging with session context support
- **System Information**: Gathering and formatting system and project details
- **Context Module**: Gathering and formatting information provided by different clients
- **Constants and Utilities**: Shared constants and utility functions
- **Upgrade Management**: Secure application upgrades with backup and rollback capabilities

## Design Architecture

The configuration module is designed around several key architectural principles:

### 1. Singleton Pattern for Global Settings

The `Settings` class implements the Singleton pattern to ensure a single, globally accessible configuration instance throughout the application. This prevents configuration inconsistencies and provides a central point for managing environment variables.

#### Key Components

| Component | Purpose |
|-----------|---------|
| `_instance` | Stores the single instance of the Settings class |
| `DEFAULT_VALUES` | Defines default values for all environment variables |
| `get_env_var()` | Retrieves an environment variable value |
| `set_env_var()` | Updates an environment variable and persists it to the .env file |

The Singleton pattern is implemented by overriding the `__new__` method to return the existing instance if one exists, or create a new instance if none exists yet. This ensures that all parts of the application use the same configuration instance, preventing inconsistencies.

#### Unified Configuration System

The Settings class supports both core and client-specific configurations through a unified API. This allows different clients (CLI, REST API, etc.) to register their own configuration schemas while maintaining backward compatibility with existing core settings.

**Core Settings (Backward Compatible):**
```python
# Existing core settings continue to work unchanged
SETTINGS.get_env_var(EnvConfig.CODA_LOG_LEVEL)
SETTINGS.set_env_var(EnvConfig.CODA_LOG_LEVEL, "DEBUG")
```

**Client Configuration Registration:**
```python
from enum import Enum

class CLIConfig(Enum):
    VERBOSITY = 'VERBOSITY'
    COLORS = 'COLORS'
    OUTPUT_FORMAT = 'OUTPUT_FORMAT'

# Register client configuration with defaults
SETTINGS.register_client_config("cli", CLIConfig, {
    CLIConfig.VERBOSITY: "INFO",
    CLIConfig.COLORS: "true",
    CLIConfig.OUTPUT_FORMAT: "table"
})
```

**Client Settings Management:**
```python
# Get client settings
verbosity = SETTINGS.get_env_var(CLIConfig.VERBOSITY, client_name="cli")

# Set client settings
SETTINGS.set_env_var(CLIConfig.VERBOSITY, "DEBUG", client_name="cli")
```

**Key Features:**
- **Environment Variable Precedence**: Client-prefixed environment variables (e.g., `CLI_VERBOSITY`) override file settings
- **File Persistence**: Client settings are stored in `.env.[client]` files (e.g., `.env.cli`, `.env.rest-api`)
- **Conflict Detection**: Prevents configuration key conflicts between core and client settings
- **Duplicate Prevention**: Prevents registering the same client name twice
- **Type Safety**: Enum-based configuration keys prevent typos and errors

#### Core Environment Variables

The `EnvConfig` enum defines all environment variables used by the core application:

| Variable | Purpose | Default Value |
|----------|---------|---------------|
| `CODA_SYSTEM_DIR` | Base directory for the CODA Core system files | `~/.coda` |
| `CODA_LOG_LEVEL` | Logging verbosity level | `INFO` |
| `CODA_LOG_DIR` | Directory for log files | `~/.coda/.logs` |
| `CODA_COMMAND_HISTORY_DIR` | Directory for command history | `~/.coda/.command_history` |
| `CODA_DEFAULT_SYSTEM_PROVIDER_NAME` | Default AI provider for system | `vertex_ai` |
| `CODA_DEFAULT_SYSTEM_MODEL_NAME` | Default AI model for system | `claude-sonnet-4-5` |
| `CODA_UPGRADE_BACKUP_DIR` | Directory for upgrade backups | `~/.coda/.backups` |
| `CODA_SESSION_DB_FILE_PATH` | Path to session database | `~/.coda/sessions.db` |
| `CODA_RECIPES_DIR_PATH` | Directory for recipe files | `~/.coda/recipes` |
| `CODA_SESSION_DB_TABLE_NAME` | Table name for sessions | `sessions` |
| `CODA_SESSION_MAX_AGE_DAYS` | Time limit to retain sessions in days | `30` |
| `CODA_GEAI_API_KEY` | API key for GenAI services | `""` (empty string) |
| `CODA_GEAI_BASE_URL` | Base URL for GenAI services | `""` (empty string) |
| `CODA_PYPI_REPO_URL` | Full URL to the PyPI repository (alternative to individual components) | `""` (empty string) |
| `CODA_PYPI_REPO_HOST` | Host for PyPI repository | `pkgs.dev.azure.com` |
| `CODA_PYPI_REPO_ORG` | Organization for PyPI repository | `genexuslabs` |
| `CODA_PYPI_REPO_PROJECT` | Project for PyPI repository | `gxeai-agents` |
| `CODA_PYPI_REPO_FEED` | Feed for PyPI repository | `coda-neo-prod` |
| `CODA_PYPI_REPO_USERNAME` | Username for PyPI repository | `gxazure` |
| `CODA_PYPI_REPO_TOKEN` | Token for PyPI repository | `""` (empty string) |
| `CODA_PYPI_REPO_INCLUDE_PRERELEASE` | Include prerelease versions in upgrades | `false` |
| `CODA_USE_LANGFUSE` | Whether to use Langfuse for telemetry | `false` |
| `CODA_DEFAULT_SINGLE_AGENT_PROVIDER_NAME` | Default AI provider for single agent | `vertex_ai` |
| `CODA_DEFAULT_SINGLE_AGENT_MODEL_NAME` | Default AI model for single agent | `claude-sonnet-4-5` |
| `CODA_DEFAULT_SMALL_PROVIDER_NAME` | Default AI provider for small models | `openai` |
| `CODA_DEFAULT_SMALL_MODEL_NAME` | Default small AI model | `gpt-4o-mini` |
| `CODA_VISION_MODEL_PROVIDER` | Provider for vision models | `openai` |
| `CODA_VISION_MODEL_NAME` | Vision model name | `o4-mini` |
| `CODA_TOOLS_DIR_PATH` | Directory for tools | `~/.coda/.tools` |
| `CODA_MCP_SERVERS_DIR` | Directory for MCP servers | `~/.coda/.tools/mcp/servers.d` |
| `CODA_MCP_GLOBAL_DEFAULTS_FILE` | Global MCP defaults file | `~/.coda/.tools/mcp/global_default_mcp.json` |
| `CODA_MCP_SESSION_CONFIG_DIR` | MCP session configuration directory | `~/.coda/.tools/mcp/sessions` |
| `CODA_DEFAULT_BASH_SECURITY_LEVEL` | Default bash security level | `low` |
| `CODA_DEFAULT_REASONING_EFFORT` | Default reasoning effort for reasoning-capable models | `default` |
| `CODA_MEMORY_CONDENSING_ENABLED` | Enable/disable memory condensing | `true` |
| `CODA_MEMORY_CONDENSING_THRESHOLD` | Threshold percentage that triggers memory condensing | `0.5` |
| `CODA_MEMORY_CONDENSING_LLM_PROVIDER` | Provider for memory condensing LLM | `openai` |
| `CODA_MEMORY_CONDENSING_LLM_MODEL` | Model for memory condensing LLM | `gpt-4.1-mini` |

Using an enum for environment variables provides type safety and centralized definition of configuration keys, making it easier to manage and update the application's configuration.

### 2. Context-Aware Logging Architecture

The logging system is designed to maintain context across different execution environments, including background threads. It uses Python's `contextvars` module to store session information in a thread-safe manner.

#### Context-Local States

The system leverages Python's `contextvars` module, which provides context-local state management. Context-local states are similar to thread-local states but are designed specifically for modern concurrency patterns:

- **Thread Safety**: Unlike global variables, context variables are thread-safe and don't leak between threads
- **Context Inheritance**: Child contexts (like those in async tasks) inherit values from parent contexts
- **Immutability**: Context changes in one execution context don't affect other contexts
- **Explicit Propagation**: Context must be explicitly passed between threads, ensuring intentional sharing

In our implementation, session information (ID and name) is stored in context variables:
```python
session_id_var = contextvars.ContextVar("session_id", default=None)
session_name_var = contextvars.ContextVar("session_name", default=None)
```

When a log message is generated, the session context filter retrieves these values from the current execution context and adds them to the log record. This ensures that each log entry is properly attributed to the session that generated it, even in complex multi-threaded scenarios.

For background threads, which don't automatically inherit context variables, we provide:
1. A `capture_session_context()` function to capture the current context as a dictionary
2. A `restore_session_context()` function to restore the context in the new thread

This architecture ensures that logs generated in background threads (like auto-save or file indexing) are properly attributed to the originating session.

The context propagation system allows for:
- Tracking which session generated each log entry
- Maintaining context across thread boundaries
- Proper attribution of logs in asynchronous operations
- Clear identification of system-level vs. session-specific operations

### 3. Unified Configuration Management

The configuration system manages both core and client-specific settings through a unified enum-based system that provides type safety and centralized definition of configuration keys.

```mermaid
flowchart LR
    subgraph "Core Configuration"
        A[EnvConfig Enum] -->|defines keys| B[.env File]
    end
    
    subgraph "Client Configuration"
        F[Client Enum] -->|registered with| G[Settings Registry]
        G -->|creates| H[.env.client Files]
    end
    
    B -->|loaded by| C[Settings Singleton]
    H -->|loaded by| C
    C -->|provides| D[get_env_var/set_env_var]
    D -->|used by| E[Application Code]
    
    I[Environment Variables] -->|override| C
```

Key design aspects:
- Environment variables are defined as enum values for type safety
- Default values are provided for required settings
- The .env file is automatically created with defaults if not present
- File locking prevents concurrent modifications
- Automatic synchronization of environment variables during application startup
- Seamless addition of new variables and removal of deprecated ones

The Settings class includes an environment variable synchronization system that:
- Preserves existing user-configured values
- Adds any new environment variables introduced in newer versions
- Removes deprecated environment variables no longer in DEFAULT_VALUES
- Runs automatically on application startup

This ensures that when new versions introduce new configuration options, users don't need to manually update their .env files or delete and regenerate them.

#### Client Configuration Architecture

The client configuration system extends the core environment variable management to support multiple clients with isolated configurations:

**Registration Process:**
1. **Client Registration**: Clients register their configuration schema using `register_client_config()`
2. **Validation**: The system validates enum keys and checks for conflicts with existing configurations
3. **File Creation**: Client-specific `.env.[client]` files are created with default values
4. **Runtime Access**: Clients access their settings using the same `get_env_var`/`set_env_var` API with the `client_name` parameter

**Conflict Prevention:**
- **Duplicate Client Names**: Prevents registering the same client name twice
- **Configuration Key Conflicts**: Detects conflicts between core settings and client settings
- **Enum Validation**: Ensures all configuration keys are valid enum members

**Environment Variable Precedence:**
1. **Client-Prefixed Environment Variables**: `CLIENT_KEY` (highest priority)
2. **Client .env File**: `.env.[client]` file values
3. **Registered Defaults**: Default values provided during registration (lowest priority)

This architecture allows multiple clients to coexist with their own configuration spaces while maintaining a unified API and preventing configuration conflicts.

### 4. Layered Configuration Architecture

The configuration system is designed in layers, with each layer building on the previous one:

| Layer | Components | Purpose |
|-------|------------|---------|
| **Utility Layer** | • System Information<br>• Helper Utilities | High-level utilities and system information gathering |
| **Core Services Layer** | • Unified Settings Management<br>• Logging Infrastructure<br>• Upgrade Management | Core application services and configuration management |
| **Foundation Layer** | • Core Environment Variables<br>• Constants<br>• Client Configuration Registry | Base configuration data and registry systems |

This layered approach ensures:
- Clear separation of concerns
- Proper initialization order
- Dependency management between components

### 5. Session Context Design

The session context system is designed to track the current session across different parts of the application, including background threads. This system is critical for maintaining proper attribution of operations to the correct session, especially in a multi-session environment.

#### Core Components

The session context system consists of three main components:

1. **Context Variables**: Thread-safe storage for session information
   - `session_id_var`: Stores the current session ID
   - `session_name_var`: Stores the current session name
   
2. **Context Management Functions**: Manipulate the context variables
   - `set_session_context()`: Sets the session ID and name for the current thread
   - `clear_session_context()`: Clears the session context when a session ends
   - `capture_session_context()`: Creates a portable representation of the current context
   - `restore_session_context()`: Restores a previously captured context in a new thread
   
3. **Session Context Filter**: Integrates with the logging system
   - Retrieves session information from context variables
   - Adds session context to log records
   - Provides default values for system-level logs

#### Context Flow

When a user starts or loads a session, the session manager calls `set_session_context()` with the session ID and name. This information is stored in thread-local context variables that are accessible throughout the application. When the session ends or the user switches sessions, `clear_session_context()` is called to reset the context.

For background operations (like auto-save or file indexing), the parent thread captures its context before starting the background thread, then passes this context to the background thread, which restores it. This ensures that all operations, even those in background threads, are properly attributed to the correct session.

The session context design provides:
- Thread-safe storage of session information
- Context propagation across thread boundaries
- Consistent log formatting with session attribution
- Default values for system-level logs
- Clear distinction between session-specific and system-level operations

### 6. Upgrade Management Architecture

The upgrade management system provides a robust, fault-tolerant mechanism for upgrading the CODA Core application. It ensures that upgrades are performed safely, with automatic backup and rollback capabilities to prevent system corruption or data loss.

```mermaid
flowchart TD
    A[Executor] --> B[Backup]
    A --> C[Repository]
    A --> D[Verification]
    A --> E[Version]
    B --> F[Filesystem Operations]
    C --> G[Authentication]
    D --> H[Subprocess Verification]
    D --> I[Module Checks]
    E --> J[Version Comparison]
```

#### Core Components

| Component | Responsibility | Key Features |
|-----------|----------------|--------------|
| **Executor** | Orchestrates the upgrade process | • Upgrade execution<br>• Process coordination<br>• Error handling<br>• Result reporting |
| **Backup** | Manages system backups | • Backup creation<br>• Backup listing<br>• Backup restoration<br>• Manifest management |
| **Repository** | Handles repository access | • URL construction<br>• Credential management<br>• Authentication validation<br>• Update checking |
| **Verification** | Verifies upgrade success | • Subprocess verification<br>• Module import checks<br>• Class validation<br>• Version validation |
| **Version** | Manages version information | • Current version retrieval<br>• Version comparison<br>• Semantic versioning support |

#### Upgrade Process Flow

The upgrade process follows a carefully designed workflow to ensure safety and reliability:

```mermaid
sequenceDiagram
    participant User
    participant Executor
    participant Backup
    participant Repository
    participant Verification
    
    User->>Executor: execute_upgrade_with_backup()
    Executor->>Backup: create_backup()
    Backup-->>Executor: Backup result
    
    alt Backup Success
        Executor->>Repository: get_credentials()
        Repository-->>Executor: Credentials
        Executor->>Repository: validate_credentials()
        Repository-->>Executor: Validation result
        
        alt Valid Credentials
            Executor->>Executor: execute_upgrade()
            
            alt Upgrade Success
                Executor->>Verification: verify_upgrade()
                Verification-->>Executor: Verification result
                
                alt Verification Success
                    Executor-->>User: Success result
                else Verification Failure
                    Executor->>Backup: restore_from_backup()
                    Backup-->>Executor: Restore result
                    Executor-->>User: Failure with restore info
                end
            else Upgrade Failure
                Executor->>Backup: restore_from_backup()
                Backup-->>Executor: Restore result
                Executor-->>User: Failure with restore info
            end
        else Invalid Credentials
            Executor-->>User: Credential error
        end
    else Backup Failure
        Executor-->>User: Backup error
    end
```

The upgrade system provides several key features:

1. **Automatic Backup**: Creates a comprehensive backup of the application before attempting an upgrade
2. **Secure Authentication**: Validates repository credentials before proceeding with the upgrade
3. **Verification**: Checks that the upgrade was successful by testing critical functionality
4. **Automatic Rollback**: Restores from backup if the upgrade fails or verification fails
5. **Comprehensive Error Handling**: Handles various error scenarios with appropriate recovery actions

## System Information Architecture

The `SystemInfo` class is designed to gather and provide formatted information about the system and project environment. It serves as a utility for diagnostics, debugging, and providing context to users and AI agents.

#### Information Categories

| Category | Description | Key Properties |
|----------|-------------|----------------|
| **Environment Information** | Basic system and environment details | `working_dir`, `home_dir`, `current_date`, `os_name`, `os_version`, `os_release`, `python_version` |
| **Git Repository Information** | Details about the Git repository if present | `is_git_repo`, `git_info` (branch, commit, remote, status, recent commits) |
| **Directory Structure** | Tree representation of the project structure | `directory_structure` (respects .gitignore rules) |

#### Design Principles

The system information component follows several key design principles:

1. **Lazy Loading**: Information is gathered only when needed, not all at initialization time
2. **Error Resilience**: Each information gathering method has robust error handling
3. **Fallback Mechanisms**: If specific information can't be retrieved, fallback values are provided
4. **Formatting Flexibility**: Raw data is stored internally, with separate methods for formatted output
5. **Respect for Exclusions**: Directory scanning respects .gitignore rules and common exclusion patterns

#### Use Cases

The SystemInfo class supports several important use cases:

- **Diagnostics**: Providing system information for troubleshooting
- **Context Awareness**: Giving AI agents awareness of the project environment
- **Git Integration**: Understanding the state of the Git repository
- **Project Navigation**: Mapping the project structure for exploration

This architecture ensures that system information is gathered efficiently and presented in a useful format, while being resilient to errors and respecting user privacy and project configuration.
