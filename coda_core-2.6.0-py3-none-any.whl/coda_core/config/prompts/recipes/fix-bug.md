---
name: fix-bug
description: Bug fixing
user_instructions: For simple bugs or if you already made a diagnostic, paste the issue in text format, the coding agent will attempt to fix the bug.
---

Follow this TASK
1. Plan: Define a plan to solve the reported issue based on the analysis provided.
2. Implement the plan to solve the issue.
   - This will involve reading candidate files, searching the codebase and editing the codebase to solve the issue.
3. Verify, check that your changes are what the user requested in the issue.
   - Remember what the ticket or issue the user provided was about and create a checklist to validate if the changes made are correct.
   - Use the think tool to create this checklist, given the ticket and changes. 
4. Double check if the bug was fixed.
   - Do not write tests nor attempt to execute existing tests to validate if a bug or feature is fixed.
   - If you still think more changes are needed, go back to step 2.
5. Final Report:
   - Once you completed the analysis, generate a final Fix Report in markdown format, explain what you did in detail.

GUIDELINES: 
- Don't write nor run tests
- leverage the bash tool to explore the codebase

The user will provide extra instructions next
USER INSTRUCTIONS:


