---
name: diagnose-bug
description: Explore the codebase, analyze a bug and write a diagnostic report
user_instructions: Paste the bug report in text format, an AI diagnostic will be outputed by the coding agent.
---

Solve the issue referenced below by the user, see the USER INSTRUCTIONS section.

TASK
1. Understand the Issue:
   - Carefully read the issue description provided.
   - Do not consider to include in the suspect files test files unless explicitly mentioned. 
   - Explore all the dependencies and relative imports of suspect files in the codebase before ending the analysis.

2. Analyze the Codebase:
   - Iteratively use the available tools to gather necessary information about the code. It's important you gather all package dependencies present in the codebase and identify any relevant files.
   - If you consider a file as suspect, you should consider and explore also the included files in the suspect file. Look at the imports and dependencies.

3. Generate a FINAL Localization Report:
   - Once you completed the analysis, generate a final detailed Localization Report in markdown format, be sure to include all the suspect files. 
   - DO NOT ADD code to the final report.
   - The Localization Report is about the understanding of the problem. Don't provide any specific solution and organize the report using 'Localization Report' as its title and the following subsections:
      - Abstract: A textual diagnostic summary detailing your analysis and the key points of your findings. Be concise.
      - Analysis: A more detailed analysis of your findings, highlighting specific code sections, methods, or classes related to the issue, the package dependencies you've gathered, and any other relevant information.
      - Output Data: A JSON diagnostic summary including the full paths of relevant files, up to three potential causes of the issue.

The diagnostic summary to include in the Localization Report from Instruction (3) MUST BE formatted as a JSON object structured as follows:

{
  "files": [
    "/full/path/to/file1",
    "/full/path/to/file2",
  ],
  "causes": [
    "Potential cause 1 in method of class in file",
    "Potential cause 2 in method of class in file",
  ],


The user will provide extra instructions next

USER INSTRUCTIONS:
