---
name: explore-plan
description: Explore codebase, create a plan to solve a task
user_instructions: Write the task you want to solve, this recipe will explore the codebase and create a plan to solve the task. The plan will be implemented in the .coda/docs/ folder.
---

Explore the codebase to understand the current structure and create a plan to solve the user query. 

TASK
- Analyze the existing code architecture and patterns. 
- If the codebase is OOP search for related classes and write a brief description of the functionality of each class, module. Search for class or BaseClass, etc and then write a brief description of each are good ideas to understand quickly how the codebase is structured.
- Create a plan based on the existing codebase structure in relation to the issue
- Search for README files if available, read them and analyze them.
- Write a plan that solves the user tasks in .coda/docs/ folder

Use the available tools to explore files and understand the system before creating your implementation plan.

The user will provide extra instructions next

USER INSTRUCTIONS:

