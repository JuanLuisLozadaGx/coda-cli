---
name: reproduce-bug
description: Reproduce a bug and fix it using TDD.
user_instructions: Paste the bug report in text format, the coding agent will attempt to fix the bug using a test to reproduce it.
---

Reproduce the reported bug to understand and plan how to fix the issue or add a feature:
Help me implement the necessary changes to the current working directory so that the requirements decribed in USER INSTRUCTIONS are met?

TASK
1. Explore the repo to familiarize yourself with its structure, then describe the functionality to be reproduced
2. Search for existing and related tests associated to the USER INSTRUCTIONS mentioned below.
4. Create a script to reproduce the error and execute it with using the Bash Tool, to confirm the error. 
3. Edit the sourcecode of the repo to resolve the issue
4. Rerun your reproduce script and confirm that the error is fixed!
5. Think about edgecases and make sure your fix handles them as well

The user will provide extra instructions next

GUIDELINES:
- Do not modify test files directly, use them as inspiration.
- This means you DON'T have to modify the testing logic or any of the tests in any way!
- Your task is to make the minimal changes to non-tests files in the current directory to ensure the USER INSTRUCTIONS is satisfied.


USER INSTRUCTIONS:
