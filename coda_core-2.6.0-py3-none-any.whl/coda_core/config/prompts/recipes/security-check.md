---
name: security-check
description: Perform a security review of a codebase
user_instructions: Add any relevant information that may help the coding agent.
---

Perform a security review of the code or implementation. 

When analyzing the code, look for common security issues like:
- Input validation vulnerabilities 
- Weak authentication or authorization
- Insecure handling of sensitive data
- Injection flaws (SQL injection, command injection, etc)
- Cross-site scripting (XSS)
- Insecure configuration settings
- Outdated or vulnerable dependencies

For each vulnerability you find, provide:
1) The file path and line number(s) 
2) A description of the issue and why it's a vulnerability
3) The potential impact if the vulnerability was exploited
4) Recommendations on how to fix or mitigate the vulnerability

Be as thorough and detailed as possible in your analysis. The security of this codebase is critical. Let me know if you have any other questions!
Provide actionable security recommendations with code examples where appropriate.

The user will provide extra instructions next
USER INSTRUCTIONS: