---
name: unit-tests-report
description: Unit test coverage analysis
user_instructions: Guide the coding agent to a particular module, component to create a plan to increase unit test coverage. You will be provided with a report that implements a plan to increase unit test coverage.
---

TASK
Analyze the codebase and propose which tests are needed to expand coverage.

Follow these guidelines:
1. Create a plan to solve the user query.
2. Search for existing and related tests associated to the user instruccions
3. Explore the codebase associated to the test you want to write
4. Write a detailed report with the new proposed functionality and ask the user to move forward or to continue iterating on the plan.

The user will provide extra instructions next

USER INSTRUCTIONS: