---
name: upgrade
description: Define notes and a plan to upgrade an application, version TBD.
user_instructions: Describe in detail the current and target version of the upgrade. You will be provided with a file in .coda/docs/notes.md that keeps track of the tasks needed to implement the upgrade. Also, there will be a detailed plan.md file as output. e.g. Upgrade to python3.13 we are using python3.12 currently.
---

TASK
I need to come up with a plan to upgrade this app to a specified version to be defined by the user.
In some case we anticipate breaking changes.
If the user doesn't clarify this, ask him for clarity.

### Take notes
- Explore the codebase and take notes of what needs to be done to upgrade the app in a file called .coda/docs/notes.md.
- Whenever you find something new, add it to the notes.md file.
- Continue exploring the codebase iteratively until you have a complete plan and the notes are finished.

### Create a plan
- Explore the codebase and come up with a plan to describe what would need to modified to perform an upgrade
- Write a file called .coda/docs/plan.md that contains the high level plan to perform an upgrade

### Validation
- Continue exploring the codebase and make sure nothing was missed in the notes.md and plan.md files.
- Do a websearch to validate best practices for this migration.

# IMPORTANT: Request user for information if not provided.
- The user should provide the target version and software for this update.
- If it isn't clear, ask the user for more information.

USER INSTRUCTIONS

