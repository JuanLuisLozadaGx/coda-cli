---
name: create-tasks
description: Explore the codebase, create a plan and break down in tasks
user_instructions: Describe the task you want to solve. A checklist format .md file will be outputed in the .coda/docs/checklist.md file.
---


TASK
1. Explore the codebase and generate some understanding of the user query
2. Create a plan based on the existing codebase structure in relation to the issue
3. Break down the task in tasks using a checklist. Save the checklist in the 
.coda/docs/checklist.md path

USER INSTRUCTIONS:
