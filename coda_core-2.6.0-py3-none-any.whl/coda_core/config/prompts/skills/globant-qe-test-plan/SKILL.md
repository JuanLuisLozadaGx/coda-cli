---
name: globant-qe-test-plan
description: "Generate an ISTQB-compliant test plan from a list of user stories. Works for any scope -- sprint, release, feature, hotfix, or ad-hoc. Produces a professional, stakeholder-ready document covering test scope, approach, ISTQB test design techniques per story, entry/exit criteria, risk register (with probability x impact scoring), RACI, schedule, and metrics -- following IEEE 829 and ISTQB Foundation Level syllabus Section5.2. Use when you need a formal test plan -- not just test cases or scenarios."
compatibility: Designed for CODA. No external tools required -- pure document analysis and generation.
metadata:
 author: coda-testing
 version: "1.1.0"
---

# Test Plan Generator

Generate an ISTQB-compliant, IEEE 829-structured test plan from a list of user stories. Works for any scope: sprint, release, feature, hotfix, or ad-hoc testing. Produces a professional, stakeholder-ready document -- not just a list of test cases.

This skill works from **user stories** and produces a **formal test plan** following ISTQB Foundation Level structure -- with RACI, risk scoring, design technique assignments, and entry/exit criteria suitable for governance or audit.

## Instructions

### Step 1: Validate Parameters

Extract from the current message:

| Parameter | Required | How to Recognize | Default |
|-----------|----------|------------------|---------|
| **Scope name** | Optional | "Sprint 42", "Release 2.1", "Login Feature", "Hotfix 3.4.1", version number | "TBD" (user can fill in later) |
| **User stories** | Yes (but auto-discoverable) | Inline list, file path (.md/.txt/.csv), or pasted text | Auto-scan local folder (see Step 1b) |
| **Application / product name** | Recommended | App name, system name, or URL | "The Application" |
| **Test period dates (start / end)** | Optional | "April 7-18", ISO dates, "2-week sprint" | TBD |
| **Team members** | Optional | List of names + roles | Generic roles |
| **Environment** | Optional | "staging", "QA env", URL | "Test Environment" |
| **Output path** | Optional | File path starting with `/`, `./`, `~/` | `./output/test-plan/` |

If user stories are **not provided explicitly**, proceed to Step 1b before failing.

### Step 1b: Auto-Discover Local Context

When user stories are not provided directly, scan the local working directory for relevant material. Search in order (stop as soon as usable content is found):

1. **Requirements / user story files** -- scan for files matching these patterns:
 - `**/user-stories*`, `**/user_stories*`, `**/stories*`
 - `**/requirements*`, `**/backlog*`, `**/sprint*`, `**/release*`
 - `**/features/**/*.feature` (Gherkin feature files)
 - `**/jira-export*`, `**/tickets*`

2. **Existing FRD documents** -- look for upstream skill output:
 - `**/flows/**/flow-requirements*.md`
 - `**/output/**/frd*`, `**/output/**/*requirements*`

2b. **Exploration notes** (pipeline input from `globant-qe-web-explorer`):
 - `./output/exploration/**/*.md`
 - When found, extract: Application URL (for Section 1 / Section 10 Environment), discovered features/areas (for Section 4 Scope as in-scope items tagged "discovered from exploration, confirm with PO"), blocking/dynamic elements (for Section 12 Risk Register as technical risks)
 - Exploration notes SUPPLEMENT user stories -- they do not replace them. If no user stories are found elsewhere, still require the user to provide them.

3. **README / docs** -- extract feature descriptions from:
 - `README.md`, `docs/**/*.md`
 - `CHANGELOG.md`, `RELEASE_NOTES.md` (recent entries)

4. **Test artifacts** -- infer features from existing test files:
 - `**/test*/**/*.spec.*`, `**/test*/**/*.test.*`
 - `**/features/**/*.feature`

For each discovered file, read it and extract anything resembling user stories, acceptance criteria, feature descriptions, or requirements. Synthesize them into a user story list (assign auto-IDs like US-001, US-002... if no IDs exist).

**If content is found**: proceed with the discovered material. Add a note in the test plan footer: _"User stories were auto-discovered from local project files: {list of source files}. Review for completeness."_

**If no content is found**: output error and STOP:
```
ERROR: No user stories provided and no requirements found in the local directory.
Usage: /globant-qe-test-plan "[user stories or file path]"
Example: /globant-qe-test-plan "US-001: Login, US-002: Checkout"
Tip: Place user story files (.md, .txt, .csv, .feature) in your working directory and re-run.
```

### Step 2: Parse User Stories

Load user stories from the provided source:

- **Inline text**: Split by line, comma, or numbered list -- extract ID, title, and any acceptance criteria present
- **File path**: Read the file and extract all US entries
- **Pasted markdown table**: Parse columns (ID, Title, ACs, Priority, Story Points)

For each user story, capture:

| Field | How to Derive |
|-------|--------------|
| ID | Explicit (US-001) or auto-assign (US-001, US-002...) |
| Title | Story title or "As a [role], I want [action]" |
| ACs count | Count explicit ACs, or estimate from story complexity |
| Priority | Explicit (P0/P1/P2, High/Med/Low) or infer from keywords |
| Story points | Explicit or omit if not provided |
| Keywords | Extract domain keywords: "login", "payment", "auth", "data", "admin", "notification" |

### Step 3: Derive Test Scope

**In-scope** -- features to be tested in this cycle:
- List functional areas derived from the user stories
- Group by domain (e.g. Authentication, Checkout, User Profile)
- Mark each area as new feature / modified / regression

**Out-of-scope** -- explicit exclusions:
- Features not covered by the user stories in scope
- Third-party integrations (unless a story specifically covers them)
- Performance and load testing (unless explicitly requested)
- Environments other than the target environment

**Assumptions & dependencies**:
- Build deployed to test environment before testing begins
- Test data available and seeded
- Any cross-team dependencies (API team, backend, DevOps)

### Step 4: Assign Test Approach per Story

> **Scope-aware language**: Throughout the test plan, use the scope name provided by the user (e.g., "Sprint 12", "Release 2.1", "Login Feature") instead of hardcoding "Sprint". If the scope name is TBD, use generic terms like "this test cycle" or "the testing period". Never default to "Sprint" terminology.

For each user story, assign:

**Test levels** (which levels apply to this story):
- Unit: Dev responsibility -- note but do not plan QA effort here
- Integration: API contracts, service interactions
- System: End-to-end user flow on the full system
- UAT: Business acceptance -- note if PO sign-off needed

**Test types per story** (check all that apply):

| Type | Apply when story involves... |
|------|------------------------------|
| Functional | Any UI interaction, form submission, data operation |
| Regression | Any change to existing functionality |
| Exploratory | Complex or ambiguous behavior, new workflows |
| Security | Auth, permissions, payments, sensitive data |
| Accessibility | Any new UI component, form, or interactive element |
| Usability | New user flows, onboarding, help content |
| Data validation | Input fields, business rules, calculated values |
| Error handling | Error states, edge cases, failure recovery |

**ISTQB test design techniques** -- assign the most relevant per story (at least one per story):

| Technique | Apply when story has... |
|-----------|------------------------|
| Equivalence Partitioning (EP) | Input fields with valid/invalid ranges; reduces test cases while maintaining coverage |
| Boundary Value Analysis (BVA) | Numeric limits, string lengths, date ranges -- test at min, min+1, max-1, max |
| Decision Table Testing (DT) | Multiple conditions with different outcomes; business rules with combinations |
| State Transition Testing (ST) | Workflow states (draft->submitted->approved), session states, multi-step flows |
| Use Case Testing (UC) | End-to-end user journeys, actor-system interactions; derive test cases from each main/alternate/exception flow |
| Error Guessing (EG) | Complex logic, historically buggy areas, third-party integrations |
| Checklist-Based Testing (CB) | Repetitive UI patterns, standards compliance (a11y, security headers) |

Record the assignment as: `US-001: EP + BVA` -- this feeds directly into test case design (downstream).

### Step 5: Build Risk Register

Identify risks at two levels:

#### 5a. Per-Story Risk Scoring

For each user story, score using a **3x3 probability x impact matrix**:

**Probability drivers** (raise probability score if any apply):
- H: Integration with external system, payment flow, auth/session, new third-party dependency, story has >5 ACs
- M: Modified existing feature, cross-browser requirement, data migration involved
- L: Simple UI change, copy/label update, behind feature flag with no behavior change

**Impact drivers** (raise impact score if any apply):
- H: Revenue-critical, data loss risk, security-sensitive, blocks all other features, regulatory requirement
- M: Degrades UX for most users, workaround exists but is painful, affects reporting/metrics
- L: Edge case, affects few users, cosmetic issue

**Risk score matrix**:

| Probability \ Impact | High | Medium | Low |
|----------------------|------|--------|-----|
| **High** | Critical | High | Medium |
| **Medium** | High | Medium | Low |
| **Low** | Medium | Low | Low |

For each US risk entry:
```
RISK-US-{id}: {description}
 Probability: H / M / L -- {reason}
 Impact: H / M / L -- {reason}
 Score: Critical / High / Medium / Low
 Mitigation: {concrete action}
 Owner: {QA Lead / Dev / PO}
```

#### 5b. General Risks

Always include these scope-wide risk categories (fill in specifics from context):

| Risk Area | Description Template |
|-----------|---------------------|
| Scope creep | Late story additions or AC changes during the test cycle |
| Environment stability | Test environment downtime or configuration drift |
| Test data | Missing or stale test data blocking test execution |
| Timeline | Compressed schedule reducing QA time |
| Knowledge gaps | New technology, unfamiliar domain, team member absence |
| Dependency | Blocked by another team's deliverable |

### Step 6: Define Entry & Exit Criteria

**Entry Criteria** (Definition of Ready for QA -- all must be met before testing begins):
- Build successfully deployed to test environment with release notes
- All US acceptance criteria documented and reviewed by PO
- Test data seeded and test accounts configured
- No Critical/P0 blockers open from prior test cycle
- Test plan reviewed and approved by QA Lead

**Exit Criteria** (Definition of Done for QA -- all must be met before release):
- 100% of P0 test cases executed
- 100% of P1 test cases executed
- >=95% overall test case pass rate
- Zero open Critical bugs; all High bugs documented with workaround or fix ETA
- Regression suite green (no new failures introduced)
- Test execution report approved by QA Lead and PO

**Suspension Criteria** (pause testing if any occur):
- >30% of test cases blocked by a single defect or environment issue
- Test environment down for >2 hours with no ETA
- Critical blocker found that invalidates core user flows

**Resumption Criteria** (resume testing when):
- Blocker resolved and verified by developer
- Environment restored and smoke test passed
- Hotfix deployed and regression re-run on affected areas

### Step 7: Define Test Deliverables

| Deliverable | Owner | Target Date | Destination |
|-------------|-------|-------------|-------------|
| Test Plan (this document) | QA Lead | Cycle start | Shared repo / confluence |
| Test Cases | QA Engineer | Day 2-3 | Test management tool |
| Test Execution Report | QA Lead | Cycle end | Shared repo / stakeholders |
| Bug Reports | QA Engineer | Ongoing | Bug tracker |
| Regression Suite Update | QA Engineer | Cycle end | Test automation repo |

### Step 8: Define Environmental Needs

| Requirement | Details |
|-------------|---------|
| Environment | {Test/Staging/QA environment name and URL} |
| Browsers | {Chromium + Firefox minimum; add Safari/mobile if story mentions it} |
| OS | {Desktop: Windows + macOS; Mobile: iOS + Android if applicable} |
| Test data | {User accounts, seed data, fixtures needed per story} |
| Credentials | {Test account roles: admin, standard user, read-only -- no real passwords in this document} |
| Tools | {Test management tool, bug tracker, CI/CD pipeline, this skill's output} |
| Access | {VPN, environment-specific auth, IP allowlisting} |

### Step 9: Build RACI Matrix

Standard QA activities x team roles:

| Activity | QA Lead | QA Engineer | Developer | Product Owner | DevOps |
|----------|---------|-------------|-----------|---------------|--------|
| Test plan authoring | **R/A** | C | C | C | -- |
| Test case design | A | **R** | C | C | -- |
| Test data setup | A | **R** | C | -- | C |
| Test execution | A | **R** | I | I | -- |
| Bug reporting | A | **R** | I | I | -- |
| Bug triage | **R/A** | C | **R** | C | -- |
| Environment setup | I | I | C | -- | **R/A** |
| Regression execution | A | **R** | I | I | -- |
| Test sign-off | **R/A** | C | C | **R** | -- |
| Release approval | I | I | C | **R/A** | C |

R = Responsible, A = Accountable, C = Consulted, I = Informed

If team names were provided, substitute generic roles with actual names.

### Step 10: Build Test Schedule

| Milestone | Target Date | Owner | Notes |
|-----------|-------------|-------|-------|
| Kickoff | {start date} | QA Lead | Test plan reviewed |
| Test environment ready | {start + 1 day} | DevOps | Smoke test passed |
| Test case design complete | {start + 2 days} | QA Engineer | Reviewed by QA Lead |
| Test execution -- P0/P1 | {midpoint} | QA Engineer | Entry criteria met |
| Bug triage review | {midpoint} | QA Lead + Dev | Triage & prioritize |
| Test execution -- P2/P3 | {end - 2 days} | QA Engineer | P0/P1 pass rate >=95% |
| Regression run | {end - 1 day} | QA Engineer | Full suite |
| Test sign-off | {end date} | QA Lead + PO | Exit criteria verified |
| Retrospective | {end + 1 day} | Team | QA lessons learned |

If test period dates were provided, compute actual dates from them.

### Step 11: Define Metrics & KPIs

| Metric | Target | Measurement |
|--------|--------|-------------|
| Test execution rate | 100% of planned TCs executed | TCs executed / TCs planned |
| Pass rate -- P0 | 100% | P0 passes / P0 total |
| Pass rate -- overall | >=95% | All passes / all executed |
| Defect detection rate | >80% found in QA (not production) | Bugs in QA / total bugs |
| Defect fix rate | >90% of Critical+High fixed before release | Fixed / total C+H |
| Automation coverage | Track current cycle contribution | New automated TCs / total TCs |
| Escaped defects | 0 Critical escaped to production | Post-release Critical bugs |

### Step 12: Write the Test Plan to Disk

Ensure the output directory exists. Write to `{output-path}/{slug}-test-plan.md` where `{slug}` = scope name lowercased, spaces -> hyphens (e.g., "Sprint 12" -> `sprint-12-test-plan.md`, "Release 2.1" -> `release-2.1-test-plan.md`). If scope name was not provided, use `test-plan.md` -- the user can rename the file later.

See [references/test-plan-template.md](references/test-plan-template.md) for the full document structure.

The document must include all 16 sections:
1. Test Plan Identifier & Metadata (ID, version, scope, dates, product, author)
2. Introduction (testing goal, objectives, references to US and DoD)
3. Test Items (table of US in scope: ID, title, story points, priority, ACs count)
4. Scope (in-scope features, out-of-scope, assumptions & dependencies)
5. Test Approach (test levels per story, test types, ISTQB design techniques table)
6. Entry Criteria
7. Exit Criteria
8. Suspension & Resumption Criteria
9. Test Deliverables
10. Environmental Needs
11. Responsibilities -- RACI Matrix
12. Risk Register (per-story risks + general risks with probability x impact scores)
13. Test Schedule (milestone table with dates and owners)
14. Metrics & KPIs
15. Assumptions & Dependencies
16. Approvals (signature block: QA Lead, PO, Dev Lead)

**VERIFICATION**: After writing, confirm:
- File written to `{output-path}/{slug}-test-plan.md`
- All 16 sections present -- no omissions
- Risk register has at least one entry per user story
- ISTQB technique assigned to every user story
- Exit criteria are measurable (numbers, not vague statements)

### Step 13: Deliver Summary

Print ONLY this to the conversation:
```
Test Plan generated -- {date}

Scope: {scope name or "TBD"} | Product: {app name}
User stories: {count} in scope {" (auto-discovered from local files)" if auto-discovered}
Test approach: {techniques list, e.g., EP, BVA, ST, UC}
Risks: {count} identified ({critical} critical, {high} high, {medium} medium, {low} low)
Metrics target: {overall pass rate}% pass rate, {escaped} escaped defects
Source: {list of files used if auto-discovered, or "provided by user"}

Output: {output-path}/{slug}-test-plan.md
```

## Context Efficiency

All content MUST be written to disk. Print ONLY the 6-line summary above to the conversation.

## Key Rules

- ALWAYS produce all 16 sections -- use "N/A -- [reason]" if a section genuinely doesn't apply, never omit it
- ALWAYS assign at least one ISTQB test design technique to every user story -- this is the core ISTQB value-add
- ALWAYS derive at least one risk per user story -- no story is zero-risk
- ALWAYS make exit criteria measurable (numbers and percentages, not "all tests pass")
- ALWAYS write output to disk -- never dump the full document to the conversation
- NEVER invent acceptance criteria not present in the user stories
- NEVER use real credentials, PII, or production data in test data sections
- NEVER produce a generic template with unfilled placeholders -- every section must be completed from the inputs
- NEVER skip the RACI -- it is the primary communication tool for stakeholder alignment
