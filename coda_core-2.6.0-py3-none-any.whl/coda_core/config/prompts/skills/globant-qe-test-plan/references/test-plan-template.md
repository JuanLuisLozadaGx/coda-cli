# Test Plan: {Product Name} -- {Scope Name}

> **Plan ID**: TP-{YYYY}-{NNN} | **Version**: 1.0 | **Status**: Draft / Approved
> **Scope**: {Scope Name} | **Dates**: {Start Date} - {End Date}
> **Product**: {Application / System Name} | **Environment**: {Test Environment URL}
> **Author**: {QA Lead Name} | **Created**: {Date} | **Last Updated**: {Date}

---

## 1. Introduction

### 1.1 Testing Goal
{One paragraph describing the business objective of this test cycle and what is being validated.}

### 1.2 Testing Objectives
- Validate that all user stories meet their defined acceptance criteria
- Identify defects before they reach production
- Ensure no regression is introduced to existing functionality
- Verify non-functional requirements (security, accessibility) where applicable

### 1.3 References

| Document | Location |
|----------|----------|
| Backlog / Requirements | {link or path} |
| Definition of Done | {link or path} |
| User Stories (in scope) | {link or path} |
| Previous Test Report | {link or path} |
| FRD / Requirements | {link or path} |

---

## 2. Introduction -- Scope & Objectives

### 2.1 In-Scope

| Functional Area | User Stories | Type |
|----------------|-------------|------|
| {Area 1} | {US-001, US-002} | New Feature |
| {Area 2} | {US-003} | Modified |
| {Area 3} | {US-004, US-005} | Regression |

### 2.2 Out-of-Scope

- {Feature or area not in scope -- reason}
- {Third-party integration X -- not changed in this cycle}
- {Performance / load testing -- not in scope}

### 2.3 Assumptions & Dependencies

| Type | Description |
|------|-------------|
| Assumption | {e.g., Build deployed to test env by Day 1} |
| Dependency | {e.g., API team delivers endpoint X by Day 3} |
| Constraint | {e.g., Testing limited to Chrome + Firefox} |

---

## 3. Test Items

| US ID | Title | ACs | Priority | Story Points | Domain |
|-------|-------|-----|----------|-------------|--------|
| US-001 | {Title} | {count} | P0 | {pts} | {Auth / Checkout / etc.} |
| US-002 | {Title} | {count} | P1 | {pts} | |
| US-003 | {Title} | {count} | P2 | {pts} | |

**Total**: {N} user stories | {N} acceptance criteria | {N} story points

---

## 4. Scope

*(See Section 2 above for the detailed scope table.)*

---

## 5. Test Approach

### 5.1 Test Levels

| Level | Owner | Applies To |
|-------|-------|-----------|
| Unit | Developer | All stories -- not part of QA scope |
| Integration | QA + Dev | US-{ids with integration/API AC} |
| System | QA | All stories |
| UAT | Product Owner | All P0 stories -- sign-off required |

### 5.2 Test Types per Story

| US ID | Functional | Regression | Security | A11y | Exploratory | Data Validation |
|-------|-----------|-----------|---------|------|-------------|----------------|
| US-001 | | | | | -- | -- |
| US-002 | | | -- | | | |

### 5.3 ISTQB Test Design Techniques

| US ID | Technique(s) | Rationale |
|-------|-------------|-----------|
| US-001 | EP + BVA | Input form with valid/invalid ranges and length limits |
| US-002 | State Transition + UC | Multi-step workflow: draft -> submitted -> approved |
| US-003 | Decision Table | Business rules with multiple condition combinations |
| US-004 | Use Case Testing | End-to-end user journey with alternate flows |
| US-005 | Error Guessing | Integration with third-party service; historically unstable |

**Technique Key**:
- **EP** -- Equivalence Partitioning
- **BVA** -- Boundary Value Analysis
- **DT** -- Decision Table Testing
- **ST** -- State Transition Testing
- **UC** -- Use Case Testing
- **EG** -- Error Guessing
- **CB** -- Checklist-Based Testing

---

## 6. Entry Criteria

All of the following must be satisfied before QA testing begins:

- [ ] Build successfully deployed to `{environment}` with release notes
- [ ] All user story acceptance criteria documented and reviewed by Product Owner
- [ ] Test data seeded: test accounts, fixtures, and reference data available
- [ ] No open Critical (P0) blockers from the previous test cycle
- [ ] This test plan reviewed and approved by QA Lead
- [ ] Test cases designed and reviewed

---

## 7. Exit Criteria

All of the following must be satisfied before the test cycle is declared QA-complete:

- [ ] 100% of P0 test cases executed
- [ ] 100% of P1 test cases executed
- [ ] Overall test case pass rate >= 95%
- [ ] Zero open Critical (P0) bugs -- all closed or deferred with PO approval
- [ ] All High (P1) bugs: either resolved, have a documented workaround, or deferred with PO sign-off
- [ ] Regression suite green -- no new failures introduced
- [ ] Test Execution Report reviewed and approved by QA Lead
- [ ] Product Owner sign-off received

---

## 8. Suspension & Resumption Criteria

### Suspension (pause testing if any of the following occur)
- >30% of test cases blocked by a single defect or environment issue for >4 hours
- Test environment unavailable for >2 consecutive hours with no ETA for recovery
- Critical (P0) blocker found that invalidates the core user flow under test
- Build deployed to wrong environment or build version mismatch detected

### Resumption (resume testing when all of the following are true)
- Root cause identified and fix deployed to test environment
- Environment verified via smoke test (>=3 P0 test cases pass)
- Hotfix regression verified against previously passing test cases
- QA Lead confirms resumption in writing (comment on project board or Slack)

---

## 9. Test Deliverables

| Deliverable | Owner | Target Date | Format | Location |
|-------------|-------|-------------|--------|----------|
| Test Plan | QA Lead | {Day 1} | Markdown / PDF | {repo path} |
| Test Cases | QA Engineer | {Day 2-3} | {Test management tool} | {link} |
| Daily Execution Status | QA Engineer | Daily during execution | Comment / Slack | {channel} |
| Bug Reports | QA Engineer | Ongoing | {Bug tracker} | {project link} |
| Test Execution Report | QA Lead | {End date} | Markdown | {repo path} |
| Regression Suite Update | QA Engineer | {End date} | Code commit | {repo link} |

---

## 10. Environmental Needs

| Requirement | Details |
|-------------|---------|
| Test environment | {URL or name, e.g., staging.myapp.com} |
| Browsers | Chromium (latest), Firefox (latest){, Safari 17+, Mobile Chrome if applicable} |
| OS | Windows 11, macOS 14{, iOS 17, Android 14 if mobile stories present} |
| Test data | {List: admin account, standard user account, read-only account, seed dataset name} |
| Credentials | Test accounts only -- stored in {password manager / secrets vault}. No production credentials. |
| Tools | {Playwright MCP / test management tool / bug tracker / CI link} |
| Access | {VPN required Y/N, IP allowlisting, environment-specific auth tokens} |
| Data privacy | All test data must be synthetic or anonymized -- no real PII |

---

## 11. Responsibilities -- RACI Matrix

| Activity | QA Lead | QA Engineer | Developer | Product Owner | DevOps |
|----------|---------|-------------|-----------|---------------|--------|
| Test plan authoring | **R/A** | C | C | C | -- |
| Test case design | A | **R** | C | C | -- |
| Test data setup | A | **R** | C | -- | C |
| Test execution | A | **R** | I | I | -- |
| Bug reporting | A | **R** | I | I | -- |
| Bug triage | **R/A** | C | **R** | C | -- |
| Environment setup | I | I | C | -- | **R/A** |
| Regression execution | A | **R** | I | I | -- |
| Test sign-off | **R/A** | C | C | **R** | -- |
| Release approval | I | I | C | **R/A** | C |

> R = Responsible | A = Accountable | C = Consulted | I = Informed

---

## 12. Risk Register

### 12.1 Per-Story Risks

| Risk ID | User Story | Description | Probability | Impact | Score | Mitigation | Owner |
|---------|-----------|-------------|------------|--------|-------|-----------|-------|
| RISK-US-001 | US-001 | {e.g., Auth flow touches session management -- historically flaky} | H | H | Critical | Prioritize in Day 1 execution; pair with Dev for environment verification | QA Lead |
| RISK-US-002 | US-002 | {e.g., Payment integration -- third-party sandbox availability} | M | H | High | Confirm sandbox credentials before testing begins; prepare manual fallback | QA Engineer |

### 12.2 General Risks

| Risk ID | Description | Probability | Impact | Score | Mitigation | Owner |
|---------|-------------|------------|--------|-------|-----------|-------|
| RISK-GEN-001 | Scope creep -- late AC changes during test cycle | M | M | Medium | Freeze ACs by Day 2; change requests deferred to next cycle | PO |
| RISK-GEN-002 | Environment instability | M | H | High | Daily smoke test at cycle start; DevOps on-call during execution | DevOps |
| RISK-GEN-003 | Test data availability | L | M | Low | Data scripts prepared before testing begins; QA owns data setup | QA Engineer |
| RISK-GEN-004 | Compressed QA timeline | M | M | Medium | Prioritize P0/P1; defer P2/P3 if time-constrained | QA Lead |

> Critical = HxH | High = HxM or MxH | Medium = MxM or HxL | Low = Lxany

---

## 13. Test Schedule

| Milestone | Target Date | Owner | Success Signal |
|-----------|-------------|-------|----------------|
| Test environment ready + smoke pass | {start + 1 day} | DevOps | 3+ P0 TCs pass |
| Test plan approved | {start + 1 day} | QA Lead | All stakeholders signed |
| Test cases designed + reviewed | {start + 2 days} | QA Engineer | QA Lead approval |
| Test execution begins -- P0/P1 | {start + 3 days} | QA Engineer | Entry criteria met |
| Bug triage review | {midpoint} | QA Lead + Dev | All Critical bugs triaged |
| Test execution -- P2/P3 | {end - 2 days} | QA Engineer | P0/P1 >=95% pass |
| Regression suite execution | {end - 1 day} | QA Engineer | No new failures |
| Test Execution Report delivered | {end date} | QA Lead | Report reviewed |
| QA sign-off | {end date} | QA Lead + PO | Exit criteria verified |

---

## 14. Metrics & KPIs

| Metric | Target | How Measured |
|--------|--------|-------------|
| Test execution rate | 100% | TCs executed / TCs planned |
| P0 pass rate | 100% | P0 passes / P0 total |
| Overall pass rate | >=95% | All passes / all executed |
| Defect detection rate | >80% found in QA | QA bugs / (QA bugs + prod bugs) |
| Critical + High fix rate | >90% before release | Fixed C/H / total C/H found |
| Escaped defects | 0 Critical | Post-release Critical issues |
| Automation coverage delta | +{N} TCs this cycle | New automated TCs added |

---

## 15. Assumptions & Dependencies

### Assumptions
- The test environment is functionally equivalent to production for all in-scope user stories
- Test data will not be modified by other teams during the execution window
- All acceptance criteria are frozen by Day 2 -- no mid-cycle changes
- Developers are available for same-day clarification and bug fixes during execution
- The Definition of Done includes QA sign-off before any story is moved to Done

### Dependencies

| Dependency | Team | Due Date | Risk if Late |
|------------|------|----------|-------------|
| {API endpoint X available} | Backend | {date} | Blocks US-{id} testing |
| {Design assets for screen Y} | Design | {date} | Blocks UI validation |
| {Environment credentials} | DevOps | Start date | Blocks all testing |

---

## 16. Approvals

This test plan is approved when all signatories below have reviewed and accepted the scope, approach, risks, and criteria defined above.

| Role | Name | Signature | Date |
|------|------|-----------|------|
| QA Lead | | | |
| Product Owner | | | |
| Dev Lead | | | |
| Scrum Master (if applicable) | | | |

> **Notes**: Any deviation from this plan after approval requires a documented change request and re-approval from QA Lead and Product Owner.

---

*Generated by `/globant-qe-test-plan` -- ISTQB Foundation Level Section 5.2 / IEEE 829 structure*
