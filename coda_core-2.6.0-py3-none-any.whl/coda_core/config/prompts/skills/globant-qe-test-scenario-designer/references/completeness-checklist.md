# Test Case Completeness Checklist

This reference defines the minimum quality bar for every test case produced by this skill. Apply this checklist AFTER generating test cases and BEFORE writing the output file. Any test case that fails a mandatory item must be fixed before delivery.

## Per-Test-Case Quality Gate

### 1. Identity (mandatory)

- [ ] Unique ID following the format convention (TC-001, DT-001, ST-001, etc.)
- [ ] Descriptive name that tells you WHAT is being tested without reading the steps (bad: "Test login"; good: "Login with valid credentials redirects to dashboard")
- [ ] Type: Positive / Negative / Edge Case / Destructive
- [ ] Priority: P0 / P1 / P2 / P3 with rationale tied to risk
- [ ] Automation feasibility: Automatable / Partial / Manual-only
- [ ] Complexity: Simple / Medium / Complex

### 2. Preconditions (mandatory)

Every test case MUST state what must be true BEFORE the test starts:
- [ ] System state (page loaded, user logged in, data exists)
- [ ] User role and permissions (not just "logged in" -- specify role: admin, viewer, guest)
- [ ] Test data already in place (existing records, configuration settings)
- [ ] Environment requirements (browser, viewport, feature flags)

Bad: "User is logged in"
Good: "User is logged in as `qa-user@example.com` (role: `editor`) on the 'Documents' page. At least 3 documents exist in the user's library."

### 3. Steps (mandatory)

- [ ] Each step has exactly ONE action (never "enter email and click submit")
- [ ] Steps use specific element references (button name, field label, link text)
- [ ] Steps include exact test data values (not "enter valid email" -- instead `john.doe@example.com`)
- [ ] Steps are ordered -- executing them out of order would not work
- [ ] No assumed knowledge -- a new team member could execute these steps without asking questions

### 4. Expected Results (mandatory)

Every step that changes state MUST have an expected result. Expected results must be:
- [ ] Observable (something you can see, read, or measure in the UI)
- [ ] Specific (exact text, exact element, exact state)
- [ ] Verifiable (a pass/fail judgment can be made unambiguously)

Bad: "Page loads successfully"
Good: "Dashboard page loads. Page title is 'My Dashboard'. Left sidebar shows navigation menu with items: 'Home', 'Projects', 'Settings'. Welcome message displays 'Welcome back, John'."

Bad: "Error is shown"
Good: "Red error banner appears below the email field with text 'Please enter a valid email address'. The email field border turns red. The Submit button remains enabled."

### 5. Test Data (mandatory for any test involving input)

- [ ] Exact values specified (not categories -- actual values)
- [ ] Rationale for each value in parentheses: `john.doe@example.com` (valid standard format)
- [ ] Equivalence partitions covered: at least one valid and one invalid representative per field
- [ ] Boundary values included for numeric/length constraints (at min, max, min-1, max+1)
- [ ] Security test data for text fields: SQL injection, XSS, path traversal patterns included as negative cases

### 6. Validation Points (mandatory)

Each test case must list what to verify after ALL steps are executed:
- [ ] UI state (elements visible/hidden, text content, styling cues)
- [ ] Data state (values persisted, calculations correct, counters updated)
- [ ] Navigation state (URL changed, breadcrumb updated, page title changed)
- [ ] Side effects (email sent, notification created, audit log entry) -- if verifiable

### 7. Postconditions (recommended)

- [ ] System state after the test completes (for cleanup or as precondition for the next test)
- [ ] Data created/modified during the test (for teardown reference)

---

## Per-Feature Quality Gate

After generating all test cases for a feature, verify:

### Coverage Completeness

- [ ] Every acceptance criterion has at least one test case
- [ ] Happy path covered (at least one P0 positive scenario per AC)
- [ ] Error handling covered (at least one negative scenario per input field and per action that can fail)
- [ ] Edge cases covered (boundary values, empty states, special characters, max-length inputs)
- [ ] Security basics covered (injection patterns in text fields, unauthorized access attempts)
- [ ] Accessibility basics covered (keyboard navigation, screen reader text -- if UI feature)

### Scenario Type Distribution

A well-designed test suite should have roughly this distribution:

| Type | Expected % | If Missing |
|------|-----------|------------|
| Positive (happy path) | 30-40% | Core user journeys are untested |
| Negative (error handling) | 30-40% | Bugs in validation and error handling will ship |
| Edge cases | 15-25% | Boundary conditions and unusual inputs are untested |
| Destructive / Security | 5-10% | Security vulnerabilities may go undetected |

If the distribution is skewed (e.g., 80% positive, 10% negative, 10% edge), flag it in the Gap Analysis and add missing scenario types.

### Priority Distribution

| Priority | Expected % | If Missing |
|----------|-----------|------------|
| P0 (Critical) | 15-25% | Not everything is critical -- review for inflation |
| P1 (High) | 30-40% | Main workhorse of the suite |
| P2 (Medium) | 25-35% | Edge cases and secondary paths |
| P3 (Low) | 5-15% | Cosmetic and rare scenarios |

If >50% of test cases are P0, priorities are inflated and need recalibration.

---

## Negative Scenario Mandatory Categories

For EVERY feature, these negative scenario categories MUST be considered. Skip only if the category genuinely does not apply, and document why.

### Input Validation Negatives

| Category | What to Test | Example |
|----------|-------------|---------|
| Required fields empty | Submit with each required field empty, one at a time | Leave "Email" blank, fill everything else, submit |
| Invalid format | Wrong format for typed fields (email, phone, date, URL) | Enter `not-an-email` in email field |
| Boundary violations | Values outside allowed range (min-1, max+1) | Enter 0 in "quantity" field (min=1) |
| Type mismatch | Letters in numeric fields, numbers in name fields | Enter `abc` in "age" field |
| Special characters | `<>'"&\` and unicode in text fields | Enter `O'Brien` in last name field |
| Injection patterns | SQL: `' OR 1=1 --`, XSS: `<script>alert(1)</script>` | Enter injection string in search field |
| Excessive length | Input longer than max allowed | Enter 10,000 characters in "bio" field (max 500) |
| Whitespace only | Only spaces, tabs, or newlines | Enter `"   "` in required field |

### Action/Flow Negatives

| Category | What to Test | Example |
|----------|-------------|---------|
| Unauthorized access | Perform action without required role/permission | Non-admin user tries to access admin panel via direct URL |
| Invalid state transition | Perform action that's not allowed in current state | Try to "approve" an already-archived document |
| Double submission | Click submit twice rapidly | Double-click "Place Order" button |
| Back-button after action | Navigate back after a state-changing action | Click "Back" after successful form submission |
| Session expired | Perform action after session timeout | Submit form after 30 min idle |
| Concurrent modification | Same entity edited by two users simultaneously | Two users edit the same document, both save |

### UI/UX Negatives

| Category | What to Test | Example |
|----------|-------------|---------|
| Empty state | Page/component with no data | Dashboard with no projects, search with no results |
| Loading state | Behavior during data fetch | Slow network -- are spinners/skeletons shown? |
| Error state | Behavior after a server error | API returns 500 -- does the UI show a user-friendly error? |
| Offline state | Behavior when network is lost | Disconnect during form submission |

---

## Anti-Patterns to Reject

If you find yourself writing any of these, stop and rewrite:

| Anti-Pattern | Problem | Fix |
|-------------|---------|-----|
| "Verify it works" | Not verifiable | Specify what "works" means: element, text, state |
| "Enter valid data" | Not reproducible | Specify exact values |
| "Check the page" | No success criteria | List specific elements and their expected states |
| "Test login functionality" as a single test case | Too broad | Split into: valid login, invalid password, empty fields, locked account, etc. |
| All test cases are P0 | Priority inflation | Recalibrate: only core revenue/security flows are P0 |
| No negative scenarios | Incomplete coverage | Add at least one negative per input and per action |
| Steps assume context | Not standalone | Each test case must be executable independently |
| "Repeat steps 1-5 from TC-001" | Fragile dependency | Copy the steps -- each test case is self-contained |
