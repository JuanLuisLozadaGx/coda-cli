# Test Case Writing Formats

This reference defines the five supported test case output formats. The user selects a format (or the skill picks the best fit). Every format must produce test cases that are **complete** -- no shortcuts, no vague steps, no missing validations.

## Format Selection Guide

| Format | Best For | When to Recommend |
|--------|----------|-------------------|
| Step-by-step | General-purpose UI testing, manual QA handoff | Default when no format is specified. Works for any scenario type. Most teams understand it immediately |
| Gherkin (BDD) | Teams using Cucumber/SpecFlow/Behave, living documentation | User mentions BDD, Gherkin, Given/When/Then, .feature files, or the team uses Cucumber-style frameworks |
| Decision table | Forms with multiple inputs, validation rules, combinatorial logic | Feature has 3+ input fields with distinct valid/invalid ranges, conditional business rules, or truth-table-style requirements |
| State transition | Workflows with clear states (order lifecycle, approval flows, wizard steps) | Feature describes a multi-step process where the entity moves through named states (draft -> submitted -> approved -> rejected) |
| Hybrid | Complex features needing multiple perspectives | Feature is large enough that one format alone would miss coverage. Combine step-by-step for happy paths, decision table for input validation, state transition for workflow states |

---

## 1. Step-by-Step (Procedural)

The most common format. Each test case is a numbered sequence of actions and expected results. Used for manual QA execution and as input to automation code generators.

### Structure

```markdown
### TC-{ID}: {Descriptive Name}

- **Type**: Positive / Negative / Edge Case / Destructive
- **Priority**: P0 / P1 / P2 / P3
- **Automation**: Automatable / Partial / Manual-only
- **Complexity**: Simple / Medium / Complex

**Preconditions**:
1. {State the system must be in before the test starts}
2. {Required test data or configuration}

**Test Steps**:

| # | Action | Test Data | Expected Result |
|---|--------|-----------|-----------------|
| 1 | Navigate to {URL/page} | -- | {Page title} is displayed, {key element} is visible |
| 2 | Enter {value} in the {field name} field | `{exact value}` | Field accepts input, no validation error shown |
| 3 | Click the {button/link name} | -- | {Specific observable outcome: redirect, message, state change} |
| 4 | Verify {specific element or text} | -- | {Element} displays "{exact expected text}" |

**Validation Points**:
- {UI validation: element visible, text correct, state changed}
- {Data validation: value saved, calculation correct}
- {Navigation validation: URL changed, page transitioned}

**Test Data**:
- {Field 1}: `{exact value}` ({why this value -- e.g., "valid email format"})
- {Field 2}: `{exact value}` ({rationale})

**Postconditions**:
- {State the system should be in after the test completes}
```

### Completeness Checklist

Every step-by-step test case MUST have:
- [ ] A descriptive name that tells you what is being tested without reading the steps
- [ ] Type classification (positive/negative/edge)
- [ ] Priority based on risk, not gut feeling
- [ ] Preconditions that are specific and verifiable (not "user is logged in" -- instead "user is logged in as `testuser@example.com` with role `admin`")
- [ ] Numbered steps where each step has exactly ONE action (never "click X and enter Y")
- [ ] Test data column with EXACT values (not "valid email" -- instead `john.doe@example.com`)
- [ ] Expected results that are observable and verifiable (not "page works" -- instead "success toast with text 'Profile updated' appears within 3 seconds")
- [ ] Validation points that specify WHAT to check and WHERE (element name, text content, URL)
- [ ] Postconditions describing the final system state

### Common Mistakes to Avoid

- "Verify the page loads correctly" -- instead: "Page title is 'Dashboard', sidebar navigation is visible, welcome message displays 'Hello, {username}'"
- "Enter valid data" -- instead: specify the exact values in the Test Data column
- "System shows error" -- instead: "Error banner with text 'Invalid email format' appears below the email field"
- Combining multiple actions in one step -- split into separate rows
- Missing the "why" for test data choices -- add rationale in parentheses

---

## 2. Gherkin (BDD)

Behavior-Driven Development format using Given/When/Then. Best when the team uses Cucumber, SpecFlow, Behave, or wants living documentation that non-technical stakeholders can read.

### Structure

```gherkin
Feature: {Feature Name}
  {One-line description of the feature's business value}

  Background:
    Given the user is on the "{page name}" page at "{URL}"
    And the user is logged in as "{role}" with credentials "{username}" / "{password}"

  @{tag} @priority-{p0|p1|p2|p3} @{positive|negative|edge}
  Scenario: {Descriptive name -- what behavior is being verified}
    Given {specific initial state or precondition}
    And {additional precondition if needed}
    When the user {performs specific action} with "{exact value}"
    And the user {performs additional action if needed}
    Then {specific observable outcome}
    And {additional assertion}
    But {something that should NOT happen -- optional}

  @{tag} @priority-p1 @negative
  Scenario Outline: {Name} with <description>
    Given {initial state}
    When the user enters "<input>" in the "{field}" field
    And the user clicks the "Submit" button
    Then the error message "<error>" is displayed below the "{field}" field

    Examples:
      | description          | input              | error                          |
      | empty value          |                    | This field is required          |
      | invalid email format | not-an-email       | Please enter a valid email      |
      | SQL injection        | ' OR 1=1 --        | Please enter a valid email      |
      | exceeds max length   | {251 char string}  | Maximum 250 characters allowed  |
```

### Completeness Checklist

Every Gherkin scenario MUST have:
- [ ] A `Feature:` header with business-value description
- [ ] `Background:` for shared preconditions (DRY -- don't repeat in every scenario)
- [ ] Tags: at least `@priority-{level}` and `@{type}` (positive/negative/edge)
- [ ] `Given` steps that are specific and verifiable (include exact user role, page, state)
- [ ] `When` steps with ONE user action each (not "enters email and clicks submit")
- [ ] `Then` steps with observable outcomes (not "it works" -- instead "success message 'Saved' is visible")
- [ ] `Scenario Outline` + `Examples` table for data-driven scenarios (when 3+ input variations test the same flow)
- [ ] Each `Examples` row with a `description` column explaining the intent of that variation
- [ ] `But` for explicit negative assertions when relevant ("But the 'Delete' button is not visible")

### Best Practices

- **One behavior per scenario**: "Login with valid credentials" is one scenario. "Login with valid credentials and navigate to dashboard and update profile" is three.
- **Declarative over imperative**: Prefer "Given the user is logged in" over "Given the user enters 'admin' in username and 'pass' in password and clicks Login"... UNLESS the login flow IS the thing being tested.
- **Use Scenario Outline for input variations**: If the same flow is tested with 3+ different inputs, always use Scenario Outline instead of copying the scenario.
- **Tag taxonomy**: Use consistent tags -- `@smoke`, `@regression`, `@priority-p0`, `@positive`, `@negative`, `@edge`, `@wip`, `@skip`, `@data-driven`.
- **Background for shared setup only**: If even ONE scenario doesn't need a Given, it doesn't belong in Background.

---

## 3. Decision Table

A matrix of input conditions vs expected outcomes. Excellent for testing business rules, form validation, access control, and any feature with combinatorial logic.

### Structure

```markdown
### DT-{ID}: {Feature/Rule Being Tested}

- **Priority**: P0 / P1 / P2 / P3
- **Rule**: {Business rule being validated -- e.g., "Discount calculation based on membership tier and cart total"}

**Preconditions**:
1. {System state required before running any row}

**Decision Table**:

| # | {Condition 1} | {Condition 2} | {Condition 3} | Expected Result | Expected Message | Priority |
|---|--------------|--------------|--------------|-----------------|------------------|----------|
| 1 | {value/state} | {value/state} | {value/state} | {outcome} | "{exact text}" | P0 |
| 2 | {value/state} | {value/state} | {value/state} | {outcome} | "{exact text}" | P1 |
| 3 | {value/state} | {value/state} | {value/state} | {outcome} | "{exact text}" | P2 |

**Execution Notes**:
- For each row: set conditions in order, trigger the action, verify the expected result and message
- Row {N} tests the boundary between {rule A} and {rule B}
- Rows {X-Y} can be automated as a parameterized test

**Coverage Analysis**:
- Total combinations possible: {N}
- Rows in table: {M}
- Coverage strategy: {All-pairs / exhaustive / risk-based sampling}
- Uncovered combinations: {list or "none -- exhaustive"}
```

### When to Use

- **Form validation**: 3+ fields with distinct valid/invalid ranges -> decision table with one column per field
- **Access control**: role x resource x action -> decision table
- **Pricing/discount logic**: tier x amount x coupon -> decision table
- **Conditional display**: feature flags, user attributes, data state -> decision table

### Completeness Checklist

Every decision table MUST have:
- [ ] The business rule stated explicitly above the table
- [ ] One column per input condition (not combined -- "role=admin AND plan=pro" is two columns)
- [ ] One row per meaningful combination (not exhaustive if combinatorial explosion -- use all-pairs or risk-based sampling and state the strategy)
- [ ] Expected Result column with specific outcomes (not "success/failure" -- instead "order placed, confirmation email sent" / "error: insufficient funds")
- [ ] Expected Message column with exact UI text where applicable
- [ ] Priority per row (some combinations are P0, others P3)
- [ ] Coverage analysis: how many total combinations exist, how many are covered, what strategy was used, what was deliberately excluded and why
- [ ] Boundary rows: for numeric conditions, always include the boundary value and boundary+1/boundary-1

### Deriving Test Cases from Decision Tables

Each row in a decision table becomes one executable test case. When the downstream consumer needs step-by-step format:

```markdown
### TC-{DT-ID}-R{row}: {Rule} -- {row description}
Steps:
1. Set {Condition 1} to {value}
2. Set {Condition 2} to {value}
3. Trigger {action}
4. Verify: {Expected Result}
5. Verify: message "{Expected Message}" is displayed
```

---

## 4. State Transition

For features where an entity moves through distinct states based on actions. Captures the full lifecycle including invalid transitions.

### Structure

```markdown
### ST-{ID}: {Entity} State Transitions

- **Entity**: {What moves through states -- order, ticket, user account, document}
- **Priority**: P0 / P1 / P2 / P3

**States**: {Draft} -> {Submitted} -> {Under Review} -> {Approved | Rejected} -> {Archived}

**State Transition Table**:

| # | Current State | Event/Action | Next State | Guard Condition | Expected Behavior | Priority |
|---|--------------|-------------|------------|-----------------|-------------------|----------|
| 1 | Draft | User clicks "Submit" | Submitted | All required fields filled | Status badge changes to "Submitted", submit button becomes disabled, notification sent | P0 |
| 2 | Draft | User clicks "Submit" | Draft (no change) | Required field missing | Validation error on missing field, status remains "Draft" | P0 |
| 3 | Submitted | Reviewer clicks "Approve" | Approved | Reviewer has permission | Status badge changes to "Approved", approval timestamp recorded | P0 |
| 4 | Submitted | Reviewer clicks "Reject" | Rejected | Reviewer provides reason | Status changes to "Rejected", rejection reason visible, "Resubmit" button appears | P1 |
| 5 | Approved | Any user clicks "Submit" | Approved (no change) | -- | Submit button not visible on approved items (invalid transition blocked by UI) | P1 |
| 6 | Rejected | User clicks "Resubmit" | Submitted | Changes made after rejection | Status returns to "Submitted", revision counter incremented | P1 |

**Invalid Transitions (must be blocked)**:

| # | Current State | Attempted Action | Expected Behavior | Priority |
|---|--------------|-----------------|-------------------|----------|
| 1 | Archived | Any edit action | Edit controls disabled, "This item is archived" message | P1 |
| 2 | Approved | User clicks "Reject" | Reject button not visible to non-reviewers | P2 |

**State Diagram** (for documentation):
```
[Draft] --submit(valid)--> [Submitted] --approve--> [Approved] --archive--> [Archived]
                                |                        |
                                +--reject--> [Rejected] --resubmit--> [Submitted]
```

### Completeness Checklist

Every state transition test set MUST have:
- [ ] All states listed explicitly
- [ ] Every valid transition covered (state + action -> new state)
- [ ] Guard conditions for conditional transitions
- [ ] Invalid transitions explicitly tested (what happens when you try a disallowed action?)
- [ ] Expected behavior for EACH transition (not just the resulting state -- what does the UI show?)
- [ ] Priority per transition (core workflow transitions are P0, edge-case transitions are P2-P3)
- [ ] A state diagram for visual reference
- [ ] Entry/exit conditions for each state (what must be true to enter; what happens on exit)

### When to Use

- Order lifecycle (cart -> checkout -> payment -> shipped -> delivered -> returned)
- Approval workflows (draft -> submitted -> review -> approved/rejected)
- Account states (active -> suspended -> deactivated -> reactivated)
- Wizard/multi-step forms (step 1 -> step 2 -> ... -> confirmation)
- Document versioning (draft -> published -> archived)

---

## 5. Equivalence Partitioning & Boundary Value Analysis

Not a standalone format but a **technique applied within any format** to systematically design test data. Every test case that involves input validation MUST use this technique.

### Equivalence Partitioning

Divide input space into classes where all values in a class are expected to behave the same. Test ONE representative from each class.

```markdown
### EP-{ID}: {Field Name} Input Partitions

**Field**: {field name} ({type: text / number / date / dropdown / etc.})
**Rules**: {validation rules from requirements -- min/max, format, allowed characters}

| Partition | Class | Representative Value | Expected Result |
|-----------|-------|---------------------|-----------------|
| Valid: standard | Valid | `john.doe@example.com` | Accepted, no error |
| Valid: edge format | Valid | `a@b.co` | Accepted (minimum valid email) |
| Invalid: empty | Invalid | `` (empty) | "Email is required" |
| Invalid: no @ | Invalid | `johndoe.example.com` | "Invalid email format" |
| Invalid: no domain | Invalid | `john@` | "Invalid email format" |
| Invalid: special chars | Invalid | `john<script>@evil.com` | "Invalid email format" |
| Invalid: spaces | Invalid | `john doe@example.com` | "Invalid email format" |
| Invalid: too long | Invalid | `{256 chars}@example.com` | "Maximum 255 characters" |
```

### Boundary Value Analysis

For every numeric or length constraint, test the boundary, boundary-1, and boundary+1.

```markdown
### BVA-{ID}: {Field Name} Boundaries

**Field**: {field name}
**Constraint**: {min}-{max} ({type: characters / value / items})

| # | Boundary | Test Value | Expected Result | Priority |
|---|----------|-----------|-----------------|----------|
| 1 | Below min (min-1) | `{min-1}` | {rejection behavior + message} | P1 |
| 2 | At min | `{min}` | {acceptance behavior} | P0 |
| 3 | Above min (min+1) | `{min+1}` | {acceptance behavior} | P2 |
| 4 | Below max (max-1) | `{max-1}` | {acceptance behavior} | P2 |
| 5 | At max | `{max}` | {acceptance behavior} | P0 |
| 6 | Above max (max+1) | `{max+1}` | {rejection behavior + message} | P1 |
| 7 | Zero | `0` | {depends on constraint} | P1 |
| 8 | Negative (if numeric) | `-1` | {rejection behavior + message} | P1 |
```

### How to Apply

1. For EVERY input field in the feature, create an EP table (identify all partitions)
2. For EVERY numeric or length constraint, create a BVA table (test boundaries)
3. Feed the representative values and boundary values into the test cases (any format):
 - Step-by-step: use them in the "Test Data" column
 - Gherkin: use them in `Scenario Outline` > `Examples` tables
 - Decision table: use them as condition values in table rows
 - State transition: use them as guard condition edge cases

### Completeness Checklist

- [ ] Every input field has an EP table
- [ ] Every numeric/length constraint has a BVA table with all 6+ boundary values
- [ ] Both valid AND invalid partitions are listed (not just the happy path)
- [ ] Special characters, empty inputs, and type mismatches are always included as invalid partitions
- [ ] Security-relevant partitions: SQL injection (`' OR 1=1 --`), XSS (`<script>alert(1)</script>`), path traversal (`../../etc/passwd`) are included for text fields
- [ ] Exact expected error messages are specified for every invalid partition

---

## Combining Formats (Hybrid Approach)

For complex features, use multiple formats together:

1. **Step-by-step** for the main happy-path scenarios (P0 core journeys)
2. **Decision table** for input validation rules (field combinations)
3. **State transition** for workflow/lifecycle coverage
4. **EP + BVA tables** embedded in any format for test data completeness
5. **Gherkin** if the team uses BDD tools or wants stakeholder-readable specs

Example output structure for a complex feature:

```markdown
## Test Cases: Checkout Flow

### Happy Path Scenarios (Step-by-Step)
TC-001: Complete checkout with credit card
TC-002: Complete checkout with PayPal
TC-003: Complete checkout as guest user

### Input Validation (Decision Table)
DT-001: Shipping address field validation
DT-002: Payment information validation

### Order State Transitions
ST-001: Order lifecycle (cart -> placed -> paid -> shipped -> delivered)

### Boundary Values
BVA-001: Cart quantity limits (1-99)
BVA-002: Coupon code length (4-20 characters)
BVA-003: Shipping address fields (min/max lengths)

### Equivalence Partitions
EP-001: Email field partitions
EP-002: Phone number partitions
EP-003: ZIP code partitions
```
