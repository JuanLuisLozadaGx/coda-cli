---
name: globant-qe-test-scenario-designer
description: Design comprehensive UI test scenarios from user stories with positive, negative, and edge cases, test data strategies, validation points, and priority assignment. Use when you need to create test cases from requirements before automation
compatibility: Designed for CODA. No external tools required
metadata:
 author: coda-testing
 version: "1.0.0"
---

# UI Test Scenario Designer

Design comprehensive UI test scenarios from user stories. Creates structured test cases with positive, negative, and edge cases, test data, validation points, and priority assignments. Supports multiple output formats (step-by-step, Gherkin, decision table, state transition, or hybrid).

**Different from `globant-qe-testcase-analyzer`**: The analyzer evaluates EXISTING test cases for coverage gaps. This skill CREATES new scenarios from requirements.

**References** (read these before generating output):
- [references/test-case-formats.md](references/test-case-formats.md) -- the five supported formats with structure templates, completeness checklists, and selection guide
- [references/completeness-checklist.md](references/completeness-checklist.md) -- mandatory quality gates, negative scenario categories, anti-patterns to reject

## Instructions

### Step 1: Capture User Story

1. Store the user story VERBATIM -- do not paraphrase
2. Extract acceptance criteria
3. Parse the user story structure: Who (user type), What (action/functionality), Why (benefit/goal)
4. If no formal user story is provided inline, proceed to Step 1b before asking the user

### Step 1b: Auto-Discover Local Context

When a user story is not provided directly, scan the local working directory for material. Search in priority order (stop as soon as usable content is found):

1. **Test-plan output** (pipeline input from `globant-qe-test-plan`):
 - `./output/test-plan/*-test-plan.md`
 - Extract user stories from the Section 3 "Test Items" table (ID, title, priority, ACs count). If the plan includes verbatim AC text, use that. Otherwise reconstruct the story from title + priority + scope description.

2. **Raw user stories / requirements**:
 - `**/user-stories*`, `**/user_stories*`, `**/stories*`
 - `**/requirements*`, `**/backlog*`, `**/sprint*`, `**/release*`
 - `**/features/**/*.feature` (Gherkin feature files)
 - `**/jira-export*`, `**/tickets*`

3. **Exploration notes** (pipeline input from `globant-qe-web-explorer`):
 - `./output/exploration/**/*.md`
 - When found, extract: **Application URL** (to populate the "Application URL" context), **validated selectors** (to inject into the "Validation Points" column of each generated test case -- e.g., "click login button (`[data-testid='login-btn']`)"), **wait strategies** and **blocking elements** (to include in "Preconditions")

4. **README / docs** -- extract feature descriptions from:
 - `README.md`, `docs/**/*.md`

For each discovered file, read it and extract anything resembling user stories, acceptance criteria, or feature descriptions. Assign auto-IDs (US-001, US-002...) if no IDs exist.

**If content is found**: proceed with the discovered material. Add a note in the output footer: _"User story and/or selectors were auto-discovered from local project files: {list of source files}. Review for completeness."_

**If no content is found and no user story was provided inline**: output error and STOP:
```
ERROR: No user story provided and no requirements found in the local directory.
Usage: /globant-qe-test-scenario-designer "[user story or file path]" [optional: URL]
Example: /globant-qe-test-scenario-designer "As a user, I want to log in so that I can access my account"
Tip: Run /globant-qe-test-plan or /globant-qe-web-explorer first to populate upstream context.
```

### Step 2: Gather Context

Ask for missing information:

| Parameter | Required | Default |
|-----------|----------|---------|
| User story / requirements | Yes (auto-discoverable) | See Step 1b |
| Application URL | If MCP validation planned | Auto-discovered from exploration notes |
| Output format | No | `step-by-step` (see below) |
| Test strategy document | No | -- |
| Priority guidance | No | Based on risk analysis |
| Test data constraints | No | Generate realistic data |

**Output format**: If the user specifies a format, use it. If not, select the best fit based on the feature -- see [references/test-case-formats.md](references/test-case-formats.md) for the selection guide. Supported formats:
- `step-by-step` -- numbered actions + expected results in a table (default, most universal)
- `gherkin` -- Given/When/Then BDD scenarios with tags and Scenario Outline for data-driven cases
- `decision-table` -- condition x outcome matrix for combinatorial/validation logic
- `state-transition` -- state + event -> next state table for workflows with named states
- `hybrid` -- combine multiple formats for complex features (e.g., step-by-step for happy paths + decision table for validation + state transition for workflows)

When using `hybrid`, the output file contains sections for each format type used. Always apply **Equivalence Partitioning and Boundary Value Analysis** to input fields regardless of the chosen format -- see [references/test-case-formats.md](references/test-case-formats.md) section 5.

### Step 3: Design Scenario Matrix

**Positive Scenarios (Happy Path)**:
- One scenario per acceptance criterion
- Use valid, realistic test data
- Expected outcome: successful completion
- Priority: Based on user value and frequency

**Negative Scenarios (Error Handling)** -- see [references/completeness-checklist.md](references/completeness-checklist.md) "Negative Scenario Mandatory Categories" for the full list:
- **Input validation**: empty fields, invalid format, boundary violations, special characters, injection patterns (SQL, XSS), excessive length, whitespace-only
- **Action/flow**: unauthorized access, invalid state transitions, double submission, back-button after action, session expiry, concurrent modification
- **UI/UX**: empty states (no data), loading states, error states (server errors), offline behavior
- Expected outcome: appropriate error messages with exact text specified

**Edge Cases**:
- Boundary values (min, max, min-1, max+1) -- always apply Boundary Value Analysis per [references/test-case-formats.md](references/test-case-formats.md) section 5
- Special characters in text fields (`<>'"&`, unicode)
- Very long inputs (beyond expected length)
- Concurrent operations
- Empty states (no data available)
- Network delays/failures (if relevant)

### Step 4: Design Test Data Strategy

For EVERY input field in the feature, apply **Equivalence Partitioning** (identify all valid and invalid classes, pick one representative per class) and **Boundary Value Analysis** (test at min, max, min-1, max+1). See [references/test-case-formats.md](references/test-case-formats.md) section 5 for the EP and BVA table templates.

| Data Type | Examples |
|-----------|----------|
| Valid data | Realistic examples covering all positive scenarios -- one per valid equivalence class |
| Invalid data | Empty strings, special characters, SQL injection patterns, XSS payloads -- one per invalid class |
| Boundary data | Min/max lengths, min/max values, zero, negative, null -- all 6 boundary points per constraint |

Include exact values (not "valid email" -- instead `john.doe@example.com`) with rationale in parentheses.

### Step 5: Define Validation Points

For each scenario:
- UI validations: elements visible, text correct, state changes
- Data validations: values saved correctly, calculations accurate
- Negative validations: error messages appear with correct text
- State validations: URL changed, page transitioned, data persisted

### Step 6: Assign Priority and Classification

| Priority | Criteria |
|----------|----------|
| P0 (Critical) | Core user journeys, revenue-impacting, security-critical |
| P1 (High) | Common user actions, important features, error handling |
| P2 (Medium) | Edge cases, less common paths, nice-to-have validations |
| P3 (Low) | Cosmetic validations, rare scenarios |

**Automation feasibility** per scenario:
- **Automatable**: Can be fully automated with UI tools
- **Partial**: Some steps require manual intervention
- **Manual-only**: Cannot be automated (visual inspection, complex judgment)

**Complexity** per scenario: Simple, Medium, Complex

### Step 7: Create Traceability Matrix

Map requirements to test scenarios:

| Requirement | Acceptance Criteria | Scenarios | Coverage |
|-------------|--------------------|-----------|-----------|
| REQ-001 | User can log in | TC-001, TC-002, TC-003 | Full |

### Step 8: Write Output to Disk (MANDATORY)

Write `./output/test-scenarios/test-cases-{slug}.md` to disk, where `{slug}` = story ID or scope name lowercased, spaces -> hyphens. Create the `./output/test-scenarios/` directory if it doesn't exist. Verify the file exists after writing. This is the ONLY output location -- there are no legacy copies in `coda-testing-docs/`.

If selectors were auto-discovered from exploration notes, inject them into the "Validation Points" column inline (e.g., `click submit button (validated: [data-testid='submit'])`) so the executor can reuse them without re-discovery.

Before writing the output file, validate ALL test cases against [references/completeness-checklist.md](references/completeness-checklist.md). Fix any test case that fails a mandatory quality gate item. Verify scenario type distribution (30-40% positive, 30-40% negative, 15-25% edge) and priority distribution (15-25% P0, 30-40% P1, 25-35% P2, 5-15% P3). Flag imbalances in the Gap Analysis section.

Contents:

1. **Original User Story** (verbatim)
2. **Scenario Summary** (total count by type, priority, and format used)
3. **Test Scenarios** -- structured per the chosen format from [references/test-case-formats.md](references/test-case-formats.md):
 - **Step-by-step**: ID, name, type, priority, preconditions, steps table (# / Action / Test Data / Expected Result), validation points, test data with rationale, postconditions, automation feasibility, complexity
 - **Gherkin**: Feature header, Background, tagged Scenarios with Given/When/Then, Scenario Outlines with Examples tables for data-driven cases
 - **Decision table**: Rule statement, preconditions, condition x outcome matrix with priority per row, coverage analysis
 - **State transition**: Entity, states list, transition table (current state / event / next state / guard / expected behavior), invalid transitions table, state diagram
 - **Hybrid**: sections for each format type used, with cross-references between them
4. **Equivalence Partitions & Boundary Values** -- EP table per input field, BVA table per numeric/length constraint (mandatory for all formats)
5. **Test Data Matrix** (valid, invalid, boundary data with exact values and rationale)
6. **Traceability Matrix**
7. **Gap Analysis** (uncovered requirements, missing scenarios, type/priority distribution check)
8. **Questions for User** (if clarifications needed)

### Step 9: Request Approval

If significant additions or changes are recommended:
- Present additions with rationale
- Ask which to include
- Update the document with user decisions

## Context Efficiency

All detailed output MUST be written to files on disk, NOT printed to the conversation. This keeps the context window small and reduces token consumption.

**To the conversation, print ONLY a brief completion summary** (max 5-10 lines):
- What was completed
- Output file path(s)
- Key metrics (counts, scores, pass rates)
- Any questions or decisions needed from the user

**In output files**, start with a `## Summary` block containing pre-computed aggregate statistics so downstream skills (or the user) can read just the summary instead of the full document.

**Use grep-friendly format** for errors and warnings in output files:
- `ERROR <identifier>: <reason on same line>`
- `WARNING <identifier>: <reason on same line>`

**Context output** (print ONLY this when done):
`"Wrote ./output/test-scenarios/test-cases-{slug}.md (X scenarios: Y P0, Z P1, W P2. Coverage: [features covered]. Gaps: [count])."`

Write the full document to disk. Only print questions for the user if clarification is needed.

## Key Rules

- ALWAYS ensure `./output/test-scenarios/` directory exists before writing output files
- ALWAYS write output to `./output/test-scenarios/test-cases-{slug}.md` on disk -- downstream skills auto-discover this path
- ALWAYS capture user stories VERBATIM -- never paraphrase
- ALWAYS include positive, negative, AND edge case scenarios
- ALWAYS assign priority (P0-P3) and automation feasibility to each scenario
- ALWAYS create specific, testable steps (not vague descriptions)
- ALWAYS define validation points for each scenario
- NEVER proceed without the user story or requirements -- run Step 1b auto-discovery first, then fail fast if nothing is found
- NEVER skip negative scenarios -- they catch the most bugs. See [references/completeness-checklist.md](references/completeness-checklist.md) for mandatory negative categories
- NEVER create vague test cases like "verify it works" -- be specific. See anti-patterns in [references/completeness-checklist.md](references/completeness-checklist.md)
- ALWAYS apply Equivalence Partitioning and Boundary Value Analysis to every input field -- see [references/test-case-formats.md](references/test-case-formats.md) section 5
- ALWAYS use the format templates from [references/test-case-formats.md](references/test-case-formats.md) -- follow the structure exactly, do not invent ad-hoc formats
- ALWAYS validate all test cases against the completeness checklist before writing the output file
- ALWAYS create the `./output/test-scenarios/` directory if missing before writing -- never assume it exists
