---
name: globant-qe-bug-report-writer
description: "Parse upstream test result files (TCE, A11y, or Regression) into normalized, structured bug reports, or consolidate multiple bug reports into a deduplicated bug tracker. Two modes: write (default) converts raw results to bug entries; consolidate (--consolidate) aggregates bug reports into a prioritized BUG-001..n inventory."
compatibility: Designed for CODA. No external tools required
metadata:
 author: coda-testing
 version: "2.0.0"
---

# Bug Report Writer

Parse upstream test result files into structured, normalized bug reports. No browser tools -- pure text analysis. Handles TCE, A11y, and Regression result formats.

## Stateless Behavior

This skill is STATELESS -- each invocation is a fresh start. Only use files from the CURRENT message or task.

## Instructions

### Step 1: Determine Mode and Parse Parameters

Read [references/bug-report-template.md](references/bug-report-template.md) for the HSS rubric and bug entry template. This is the authoritative template for both modes.

**Pipeline mode**: If the message contains a task file path matching `.harness/tasks/` (e.g., `Your assigned task: .harness/tasks/.../locked/bugs-*.md`):
- Read the task file to extract: source plugin type (`tce`, `a11y`, `regression`, or `api`) and source file path
- Read `templates/business-context.md` if it exists -- extract app name and URL (optional context, not required)
- Read the source result file at the extracted path
- If a harness-specific template exists at `workers/detective/templates/bug-report-template.md`, read it (it may contain project-specific HSS calibration). Otherwise fall back to [references/bug-report-template.md](references/bug-report-template.md)
- Auto-discover FRDs (see Step 1b)
- Output: `output/bugs/detective-{task-name}.md`

**Standalone mode**: Parse from the current message:

| Parameter | Required | How to Recognize | Default |
|-----------|----------|------------------|---------|
| **Source file(s)** | Yes | Path(s) to result files, or inline content | -- |
| **Source type** | No | "tce", "a11y", "regression", "api", or auto-detected | Auto-detect |
| **FRD path** | No | Path to FRD markdown file for cross-referencing | Auto-discover (see Step 1b) |
| **Output path** | No | Paths starting with `/`, `./`, `~/` | `./output/bugs/` |

If no source file is provided in standalone mode, output error and STOP:
```
ERROR: Missing required parameter. Usage: /globant-qe-bug-report-writer [result-file-path] [optional: --type tce|a11y|regression|api] [optional: --frd path] [optional: output-path]
```

### Step 1b: Auto-Discover FRDs

When no `--frd` path is provided explicitly, scan for FRD files to use for expected-behavior cross-referencing. Search in priority order (use the first location that has files):

1. `output/flows/` -- qe-pipeline layout (FRD files written by the frd-writer worker)
2. `./output/frd/` -- consolidated coda-skills layout
3. `**/frd/**/*.md`, `**/functional-requirements*` -- broader fallback

If FRDs are found, use them in Step 4 for cross-referencing. If none are found, proceed without FRD cross-referencing -- set FRD Reference to "No FRD available" on each bug entry.

### Step 2: Detect Source Type (if not specified)

Auto-detect from file content:
- **TCE**: Contains `BUG`, `FAIL`, `INCONCLUSIVE` in scenario result tables; has `## Scenario Results` section
- **A11y**: Contains `axe-core`, `WCAG`, `violations`, `impact: critical/serious`; has `## Violations` section
- **Regression**: Contains `FIXED`, `UNFIXED`, `BUG` status table; has `## Root Cause` section

### Step 3: Extract Bugs by Source Type

#### TCE Source
Parse for bug-worthy entries:
- **BUG entries**: Extract description, FRD reference, expected vs actual, evidence (screenshot path)
- **FAIL entries**: Extract which step failed, error message -- these are potential bugs or test issues
- **INCONCLUSIVE entries**: Extract what was unclear and what needs investigation

Each entry = one bug in the report.

#### A11y Source
Parse violation sections:
- Extract only `critical` and `serious` impact violations (skip `moderate` and `minor`)
- For each violation: rule ID, WCAG criterion, impact level, description, elements affected, fix recommendation URL
- Each critical/serious violation = one bug entry

#### Regression Source
Parse for failure entries:
- **BUG status**: Extract spec file, root cause, original error, FRD reference, screenshot evidence
- **UNFIXED status**: Extract spec file, all attempts made, last error, why it couldn't be fixed
- **FIXED status**: Skip -- not a bug
Each BUG/UNFIXED entry = one bug.

### Step 4: Enrich Each Bug

For each extracted bug:

1. **Cross-reference FRD** (if available from Step 1b) -- find the section defining expected behavior for this screen/flow. If no FRD was discovered, set FRD Reference to "No FRD available" and derive expected behavior from the test case description or WCAG standards (for a11y).

2. **Score severity using the Heuristic Severity Score (HSS)** -- see [references/bug-report-template.md](references/bug-report-template.md) for the full rubric. Rate each bug on 5 dimensions (1-5 each):
 - **User Impact (UI)**: cosmetic -> data loss/security breach
 - **Frequency (FR)**: rare edge case -> every user, every time
 - **Workaround (WA)**: trivial workaround -> no workaround
 - **Business Risk (BR)**: no impact -> legal/regulatory exposure
 - **Blast Radius (BL)**: single element -> system-wide

 Total (max 25) maps to severity: 21-25 = Critical, 16-20 = High, 11-15 = Medium, 5-10 = Low.

 If insufficient context to score all 5 dimensions (e.g., no business context file), use the source-type defaults from [references/bug-report-template.md](references/bug-report-template.md) as a starting point and score whatever dimensions you CAN evaluate.

3. **Assign priority**: P1 (Critical), P2 (High), P3 (Medium), P4 (Low)
4. **Categorize**: `functional`, `accessibility`, `UX`, `validation`, `data-integrity`
5. **Write clear description**: one paragraph -- what happens vs what should happen

### Step 5: Write Bug Report

**Pipeline output** -> `output/bugs/detective-{task-name}.md`:
**Standalone output** -> `{output-path}/bugs-{source-stem}.md`:

```markdown
# Bug Report: {source-stem}

> Source: {tce|a11y|regression} | Analyzed: {date}
> Source file: {path-to-source-result}

## Bugs Found

### BUG: {short-title}

- **Heuristic Severity Score**: UI:{X} FR:{X} WA:{X} BR:{X} BL:{X} = **{total}/25** -> {Critical/High/Medium/Low}
- **Priority**: {P1/P2/P3/P4}
- **Category**: {functional/accessibility/UX/validation/data-integrity}
- **Source plugin**: {tce/a11y/regression/api}
- **Affected screen**: {screen name -- URL}
- **FRD Reference**: {Section X, Rule/Item Y -- or "No FRD available"}

**Description**: {One clear paragraph: what is broken and why it matters}

**Expected behavior**: {What the FRD or WCAG says should happen}

**Actual behavior**: {What actually happens on the site}

**Evidence**:
- Screenshot: {path if available, or "None"}
- Error message: {exact error text if available}
- WCAG criterion: {if a11y source, e.g., "4.1.2 Level A"}

**Suggested fix**: {Brief, actionable recommendation}

---

{Repeat for each bug}

## Summary

| Metric | Value |
|--------|-------|
| Bugs extracted | {count} |
| Critical (21-25) | {count} |
| High (16-20) | {count} |
| Medium (11-15) | {count} |
| Low (5-10) | {count} |
| Average HSS | {avg}/25 |
```

### Step 6: Deliver Summary

**Pipeline mode** -- print only:
```
Wrote output/bugs/detective-{task-name}.md ({count} bugs: {C} critical, {H} high, {M} medium, {L} low. Source: {type}).
```

**Standalone mode** -- print:
```
Bug report written

Source: {type} -- {source-file}
Bugs found: {count} ({C} critical, {H} high, {M} medium, {L} low)

File: {output-path}/bugs-{source-stem}.md
```

---

## Consolidate Mode (`--consolidate`)

**Trigger:** Message contains `--consolidate`, keywords "aggregate", "deduplicate", "bug tracker", "merge bug reports", or a directory path containing `detective-*.md` files.

**What this does:** Reads all individual bug report files, deduplicates across sources, assigns sequential BUG-001..n IDs, and produces a unified bug tracker with statistics and recommendations.

**Read `references/consolidation-rules.md`** for the complete consolidation steps, deduplication algorithm, merge rules, and output format.

**Output:** `./output/bugs/bug-tracker-{slug}.md`. This file is consumed by `globant-qe-bug-pusher` and report generators.

**Context output** (consolidate mode):
```
Wrote {output-path}/bug-tracker-{slug}.md
{count} unique bugs: {C} critical, {H} high, {M} medium, {L} low. {D} duplicates merged.
```

---

## Key Rules

- NEVER use browser tools -- text analysis only
- NEVER fabricate bugs -- only report what the source file documents
- ALWAYS auto-discover FRDs via Step 1b when no explicit `--frd` path is given -- never skip FRD lookup
- ALWAYS score severity using the Heuristic Severity Score (HSS) from [references/bug-report-template.md](references/bug-report-template.md) -- fall back to source-type defaults only when context is insufficient
- ALWAYS include evidence references (screenshot paths, error messages) from the source
- ALWAYS assign a category to every bug
- NEVER report FIXED regression results as bugs
- NEVER report a11y violations with `moderate` or `minor` impact
