# Consolidate Mode -- Bug Report Aggregation & Deduplication

This reference is loaded when consolidate mode is detected (`--consolidate`, directory path of detective files, or keywords like "aggregate", "deduplicate", "bug tracker").

## Input Gathering

### Pipeline Mode
- Input: all `./output/bugs/detective-*.md` files
- Context: `templates/business-context.md` (app name, URL), `./output/frd/` (FRDs for reference)
- Output: `./output/bugs/bug-tracker-{slug}.md`

### Standalone Mode

| Parameter | Required | How to Recognize | Default |
|-----------|----------|------------------|---------|
| **Bug reports path** | Yes | Path to directory or glob pattern of bug report files | -- |
| **App name** | No | "for {app}", "application: {name}" | Inferred from files |
| **Output path** | No | Paths starting with `/`, `./`, `~/` | `./output/bugs/` |

If bug reports path is missing, output error and STOP:
```
ERROR: Missing required parameter. Usage: /globant-qe-bug-report-writer --consolidate [bug-reports-path] [optional: output-path]
```

## Consolidation Steps

### C1: Gather and Parse All Bug Reports

Read ALL `detective-*.md` (pipeline) or matching bug report files (standalone). For each bug entry, extract:
- Title and description
- Severity (Critical/High/Medium/Low) and Priority (P1/P2/P3/P4)
- Category (functional/accessibility/UX/validation/data-integrity)
- Source plugin (tce/a11y/regression) and source file path
- Affected screen and URL
- FRD reference
- Evidence (screenshots, error messages, WCAG criteria)
- Suggested fix

### C2: Deduplicate

Identify bugs describing the same underlying issue across sources:
- Same symptom on the same screen from TCE + regression = one bug (merge evidence)
- Same a11y violation on multiple pages = one bug with multiple affected pages listed
- Same root cause across different test cases = one bug

**Merge rules:**
- Keep the most detailed description
- Combine evidence from all sources (list all screenshots and error messages)
- List all source files as references
- Use the **highest severity** among duplicates
- Keep the **highest priority** among duplicates

### C3: Assign Bug IDs

1. Assign sequential IDs: BUG-001, BUG-002, BUG-003...
2. Sort by severity: Critical -> High -> Medium -> Low
3. Within same severity, sort by priority: P1 -> P2 -> P3 -> P4

### C4: Write Bug Tracker

**Output** -> `./output/bugs/bug-tracker-{slug}.md`

```markdown
# Bug Tracker Report

> Application: {app-name} | Generated: {date}
> Sources: TCE, A11y, Regression | Total bugs: {count}

## Executive Summary

{2-3 sentences: total bugs, severity breakdown, top concerns, most affected areas}

## Bug Summary

| ID | Title | Severity | Priority | Category | Source(s) | Screen |
|----|-------|----------|----------|----------|-----------|--------|
| BUG-001 | ... | Critical | P1 | functional | tce, regression | Login |

## Bug Details

### BUG-001: {Title}

- **Severity**: {Critical/High/Medium/Low}
- **Priority**: {P1/P2/P3/P4}
- **Category**: {functional/accessibility/UX/validation/data-integrity}
- **Source(s)**: {plugin: file, plugin: file}
- **Affected screen(s)**: {screen name - URL}
- **FRD Reference**: {Section X, Rule Y}

**Description**: {What is broken and why it matters}

**Expected behavior**: {What the FRD/WCAG says should happen}

**Actual behavior**: {What actually happens}

**Evidence**:
- {Screenshot paths, error messages, WCAG criterion}

**Suggested fix**: {Brief recommendation}

---

## Statistics

| Metric | Count |
|--------|-------|
| Total bugs | X |
| Critical | X |
| High | X |
| Medium | X |
| Low | X |
| From TCE | X |
| From A11y | X |
| From Regression | X |
| Duplicates merged | X |

## By Category

| Category | Count | Critical | High | Medium | Low |
|----------|-------|----------|------|--------|-----|

## By Screen

| Screen | Bugs | Highest Severity |
|--------|------|-----------------|

## Recommendations

### Immediate (Critical/High)
1. {Fix description}

### Short-term (Medium)
1. {Fix description}

### Backlog (Low)
1. {Fix description}
```

### C5: Quality Check

Before saving, verify:
- All input bug report files are accounted for
- No duplicate bugs in the final tracker
- Bug counts match source data (total = unique bugs, not raw count)
- Every bug has a valid FRD reference or explicit "Not found in FRD" note
- Severity and priority are consistent with the unified scale
- Duplicates merged count is accurate

## Key Rules (Consolidate Mode)

- NEVER modify source bug report files
- ALWAYS deduplicate aggressively -- same root cause = one bug
- ALWAYS use the highest severity when merging duplicates
- ALWAYS provide a suggested fix for every bug
- ALWAYS sort bugs by severity (Critical first) in all tables
- ALWAYS verify counts match source data before saving
- NEVER inflate bug counts -- duplicates must be merged, not listed separately
