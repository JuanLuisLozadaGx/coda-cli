# Bug Report Template & Severity Rubric

## Heuristic Severity Score (HSS)

Score each bug on 5 business-impact dimensions (1-5 each). Total = sum of all dimensions (max 25).

| Dimension | 1 (Minimal) | 2 (Low) | 3 (Moderate) | 4 (High) | 5 (Critical) |
|-----------|-------------|---------|--------------|----------|---------------|
| **User Impact (UI)** | Cosmetic only | Minor inconvenience | Workflow disruption | Core feature broken | Data loss or security breach |
| **Frequency (FR)** | Rare edge case | Uncommon path | Common path, some users | Main flow, most users | Every user, every time |
| **Workaround (WA)** | Trivial workaround | Easy workaround exists | Workaround is cumbersome | Workaround is fragile/partial | No workaround possible |
| **Business Risk (BR)** | No revenue/compliance impact | Minor brand impact | User churn risk | Revenue loss or SLA breach | Legal/regulatory exposure |
| **Blast Radius (BL)** | Single field/element | One screen | One flow | Multiple flows | System-wide |

**Severity mapping from HSS total:**
- **21-25** -> Critical (P1)
- **16-20** -> High (P2)
- **11-15** -> Medium (P3)
- **5-10** -> Low (P4)

## Source-Type Severity Defaults

When HSS cannot be fully assessed (insufficient context for all 5 dimensions), fall back to these source-type defaults as a starting point, then adjust based on whatever dimensions you CAN evaluate:

| Severity | TCE | A11y | Regression |
|----------|-----|------|------------|
| Critical | BUG impacting core user flow | axe impact = critical | BUG in core flow |
| High | BUG with medium impact | axe impact = serious | UNFIXED with failures |
| Medium | FAIL (possible test or app issue) | -- | -- |
| Low | INCONCLUSIVE | -- | -- |

## Bug Entry Template

```markdown
### BUG: {short-title}

- **Heuristic Severity Score**: UI:{X} FR:{X} WA:{X} BR:{X} BL:{X} = **{total}/25** -> {Critical/High/Medium/Low}
- **Priority**: {P1/P2/P3/P4}
- **Category**: {functional/accessibility/UX/validation/data-integrity}
- **Source plugin**: {tce/a11y/regression/api}
- **Affected screen**: {screen name -- URL}
- **FRD Reference**: {Section X, Rule/Item Y -- or "No FRD available" if none found}

**Description**: {One clear paragraph: what is broken and why it matters}

**Expected behavior**: {What the FRD or WCAG says should happen}

**Actual behavior**: {What actually happens on the site}

**Evidence**:
- Screenshot: {path if available, or "None"}
- Error message: {exact error text if available}
- WCAG criterion: {if a11y source, e.g., "4.1.2 Level A"}

**Suggested fix**: {Brief, actionable recommendation}
```

## Report Summary Template

```markdown
## Summary

| Metric | Value |
|--------|-------|
| Bugs extracted | {count} |
| Critical (21-25) | {count} |
| High (16-20) | {count} |
| Medium (11-15) | {count} |
| Low (5-10) | {count} |
| Average HSS | {avg}/25 |
```
