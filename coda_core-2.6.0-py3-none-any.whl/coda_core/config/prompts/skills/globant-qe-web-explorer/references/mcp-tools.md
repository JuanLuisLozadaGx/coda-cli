# MCP Web Inspector Tools Reference

Available via `mcp_execute` with server `mcp-web-inspector`.

## Navigation & Inspection

| Tool | Purpose | Key Arguments |
|------|---------|---------------|
| `navigate` | Navigate to URL | `url`, `headless` |
| `inspect_dom` | Get page structure | `maxChildren`, `includeHidden` |
| `get_test_ids` | Find testable elements | `attributes` (comma-separated), `showAll` |

## Element Discovery & Validation

| Tool | Purpose | Key Arguments |
|------|---------|---------------|
| `query_selector` | Find element with selector | `selector` |
| `element_exists` | Check if element exists | `selector` |
| `check_visibility` | Verify element visibility | `selector` |
| `find_by_text` | Find elements by text content | `text` |

## Interactions

| Tool | Purpose | Key Arguments |
|------|---------|---------------|
| `fill` | Enter text in input field | `selector`, `value` |
| `click` | Click element | `selector` |
| `select` | Select from dropdown | `selector`, `value` |

## Waits & Timing

| Tool | Purpose | Key Arguments |
|------|---------|---------------|
| `wait_for_element` | Wait for element state | `selector`, `state` (visible/hidden/detached), `timeout` |
| `scroll_to_element` | Scroll element into view | `selector` |

`wait_for_element` is the PRIMARY AND ONLY wait strategy. Use for ALL waits including after navigation.

## Observation

| Tool | Purpose | Key Arguments |
|------|---------|---------------|
| `visual_screenshot_for_humans` | Capture visual evidence | `name`, `fullPage` |
| `get_console_logs` | Check for console errors | `type` (error/warning/info) |

## Cleanup

| Tool | Purpose |
|------|---------|
| `close` | Close browser session |

## Selector Discovery Attributes

When using `get_test_ids`, check these attributes (in priority order):
1. `data-testid` -- most stable, designed for testing
2. `data-test` -- alternative test attribute
3. `data-cy` -- Cypress convention
4. `id` -- when unique and stable
5. `name` -- for form elements
6. `aria-label` -- for accessible elements
7. `class` -- last resort, use stable classes only
