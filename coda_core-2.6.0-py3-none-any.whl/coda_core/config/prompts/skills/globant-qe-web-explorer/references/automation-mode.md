# Automation Mode -- Selector Validation & Test Case Mapping

This reference is loaded when `--for-automation` mode is detected. It extends the web explorer with focused selector validation and structured output for downstream automation skills.

## Automation Mode Steps

### A1: Load Test Cases (if available)

If test cases exist from `globant-qe-test-scenario-designer`, load them to focus exploration on scenarios marked as automatable.

### A2: Discover Interactive Elements

1. **Find all testable elements** -- check attributes: `data-testid`, `data-test`, `data-cy`, `id`, `name`, `aria-label`, `class`
2. **Categorize by type**: inputs, buttons, links, dropdowns, checkboxes, radio buttons
3. **For each element**:
 - Validate selector via browser snapshot
 - Verify interactability (visible, enabled)
 - Record: selector strategy, validation status, element purpose

### A3: Explore User Journeys

For each exploration goal or test scenario:

1. **Identify entry point** in the snapshot
2. **Execute each step**: fill inputs, click buttons, select dropdowns
3. **Observe state changes** after each action:
 - What visual element confirms action completion (spinner disappears, success message, modal closes)
 - Record the specific element state indicating readiness for next step
 - Document timing of transitions
4. **Capture evidence**: screenshots for key journey milestones

### A4: Document Blocking Elements

Identify elements that may interfere with interactions:
- Cookie consent banners
- Modal dialogs and overlays
- Popups and notifications
- Sticky headers/footers covering elements

For each: document selector, behavior, and dismissal strategy.

### A5: Define Wait Strategies

For each user journey step, define wait strategy based on observed behavior:

- **What to wait for**: Specific element visibility/invisibility confirming action completed
- **NEVER use**: `networkidle`, `waitForNetworkIdle`, or hard waits (`Thread.sleep`, `time.sleep`)
- **ALWAYS use**: element state waits (visible/hidden/detached)

## Automation Mode Output

Write to `./output/exploration/validated-test-cases-{slug}.md` where `{slug}` = scope name lowercased, spaces -> hyphens. Create the `./output/exploration/` directory if it doesn't exist. This is the ONLY output location -- there are no legacy copies in `coda-testing-docs/`.

### Output Format

```markdown
# Validated Test Cases -- {Application Name}

## Summary
- Application URL: {url}
- Date explored: {date}
- Pages visited: {count}
- Selectors discovered: {count}
- Selectors validated: {count}
- Journeys mapped: {count}

## Selector Inventory

| Element | Purpose | Selector | Strategy | Validated |
|---------|---------|----------|----------|-----------|
| {name} | {purpose} | `{selector}` | {data-testid/id/name/aria-label/css} | {Yes/No} |

## User Journey Maps

### Journey: {journey name}

| Step | Action | Selector | Wait For | Notes |
|------|--------|----------|----------|-------|
| 1 | {action} | `{selector}` | {wait condition} | {notes} |

## Dynamic Behaviors
- {AJAX content, animations, transitions, validation messages}

## Blocking Elements

| Element | Selector | Behavior | Dismissal |
|---------|----------|----------|-----------|
| {name} | `{selector}` | {behavior} | {how to dismiss} |

## Additional Scenarios Recommended
- {scenarios discovered during exploration with rationale}
```

## Key Rules (Automation Mode)

- ALWAYS ensure `./output/exploration/` directory exists before writing
- ALWAYS write to `./output/exploration/validated-test-cases-{slug}.md` -- downstream skills auto-discover this path
- ALWAYS validate selectors by observing them in browser snapshots
- NEVER guess selectors -- every selector must be browser-verified
- NEVER use hard waits -- define waits based on observed completion indicators
