---
name: globant-qe-web-explorer
description: "Explore a web application area in depth using browser tools -- click elements, fill forms, check states, and document selectors and behaviors. Two modes: exploration (default) for systematic web app discovery, and automation mode (--for-automation) for focused selector validation producing validated-test-cases.md consumed by downstream automation skills."
compatibility: Designed for CODA. Requires Playwright MCP server (@playwright/mcp)
metadata:
 author: coda-testing
 version: "2.0.0"
---

# Web Application Explorer

Systematically explore a web application area using browser tools. Document selectors, behaviors, states, and edge cases. Can operate standalone (user-driven) or in pipeline mode (task-file-driven).

## Stateless Behavior

This skill is STATELESS -- each invocation is a fresh start. NEVER use URLs, paths, or findings from previous conversations. Only extract parameters from the CURRENT user message or task file.

## Instructions

### Step 1: Determine Mode and Parse Parameters

**First, check for pipeline mode**: If the message contains a task file path matching `.harness/tasks/` (e.g., `Your assigned task: .harness/tasks/.../locked/task.md`), you are in **pipeline mode**:
- Read the task file to extract: Entry Point URL, Objective, Context, Depth, flow slug, notes output path, tasks output path
- Read ALL prior notes matching the pattern provided in the prompt (e.g., `output/exploration/{slug}-notes*.md`) -- avoid re-documenting what's already known
- Budget: **~15 browser interactions** (navigate, snapshot, click, type, hover, select each = 1 interaction)
- After ~15 interactions, stop and move to writing findings. Create a continuation task if the area is not fully explored.
- Do NOT navigate outside the flow scope defined in the task file

**Otherwise, you are in standalone mode**. Parse from current message:

| Parameter | Required | How to Recognize | Default |
|-----------|----------|------------------|---------|
| **URL** | Yes | http://, https://, domain names | -- |
| **Exploration scope** | Yes | "explore the X", "check the Y", feature area | -- |
| **Output path** | No | Paths starting with `/`, `./`, `~/` | `./output/exploration/` |
| **Depth** | No | "quick", "thorough", "deep" | Thorough |

If URL or scope are missing in standalone mode, output error and STOP:
```
ERROR: Missing required parameters. Usage: /globant-qe-web-explorer [url] "[scope: what to explore]" [optional: output-path]
```

### Step 2: Read Context (Both Modes)

**Pipeline mode**:
1. Read your assigned task file -- understand your specific objective and entry point
2. Read ALL prior notes files matching the provided glob -- make a mental note of what's already documented. Do NOT re-document this.
3. Read `templates/business-context.md` if available -- understand domain boundaries

**Standalone mode**:
1. Note the URL and scope from the user's message
2. No prior notes to read

### Step 3: Navigate to Area

1. Navigate to the Entry Point URL with `browser_navigate`
2. Dismiss any popups, cookie banners, or overlays
3. Use `browser_snapshot` to read the current state (counts as 1 interaction)

**Pipeline budget check**: Keep a running count of browser interactions. After ~15, proceed to Step 5 (Write Findings).

### Step 4: Deep Exploration

This is your main work. Explore your assigned area thoroughly **within your interaction budget**:

- **Click everything relevant** -- buttons, links, tabs, toggles, accordions
- **Fill forms** -- with realistic test data (don't submit payment forms or create real accounts)
- **Check states** -- hover, focus, disabled, error, empty, loading states
- **Document validation** -- what happens with empty fields, invalid input, boundary values
- **Note selectors** -- CSS selectors, IDs, `data-testid` attributes. Selector priority:
 - `data-testid` (most stable) -> `id` -> `name` -> `aria-label` -> stable CSS class
- **Record behaviors** -- what changes, what appears, what disappears after each interaction
- **Check edge cases** -- empty states, long text, special characters
- **Document wait indicators** -- what element confirms an action is complete (spinner disappears, success message appears). NEVER rely on `networkidle`.
- **Note blocking elements** -- cookie banners, modals, overlays that interfere with interactions

After each significant interaction, use `browser_snapshot` to read the resulting state.

**Interaction budget** (pipeline mode): After ~15 interactions, stop exploring and write findings. If the area is not fully explored, you will create a continuation task in Step 6.

### Step 5: Write Findings

**Pipeline mode** -- write to the notes output path specified in the prompt (e.g., `output/exploration/{slug}-notes-task-{taskname}.md`):

```markdown
# Task Findings: {task-name}

## Task Info
- Task: {task name}
- Flow: {flow slug}
- Depth: {depth}
- Date: {date}
- Prior notes read: {list of files}
- Browser interactions used: {count}
- Continuation needed: {yes/no}

## Findings

### {Sub-area or Component 1}
{Detailed observations -- what you found, clicked, and documented}
{Include selectors inline when validated: element: `selector` (verified)}

### {Sub-area or Component 2}
{...}

## Selectors Discovered
- {element description}: `{selector}` (verified) or (not found) (not found)

## Wait Strategies
- {action}: wait for `{selector}` to be {visible/hidden/detached}

## Blocking Elements
- {element}: `{selector}` -- dismissal: {how to dismiss}

## New Discoveries
{Anything NOT in prior notes -- new areas, hidden features, unexpected behaviors}

## Remaining Work
{If continuation needed: what still needs exploring. If not: "None -- area fully explored"}

## Summary
- Objective met: {yes/no/partial + explanation}
- New areas found: {count}
- Selectors validated: {count}
```

**Standalone mode** -- write findings to `./output/exploration/{slug}-notes.md` where `{slug}` = scope name lowercased, spaces -> hyphens. Create the `./output/exploration/` directory if it doesn't exist. Screenshots (if any) go to `./output/exploration/screenshots/finding-*.png`.

Include the **Application URL** in the output's Task Info section -- downstream skills (`test-plan`, `test-scenario-designer`, `mcp-test-executor`) parse it from here to avoid re-asking the user. This is the ONLY output location -- there are no legacy copies in `./exploration/` or `coda-testing-docs/`.

### Step 6: Generate New Tasks (Pipeline Mode Only)

There are TWO types of new tasks:

#### Type A: Continuation (budget exhausted, same area not finished)

Create when you hit ~15 interactions but haven't completed the area:
- **Path**: `{tasks-output-path}/{your-taskname}-part{N}.md`
- **Depth**: Same as your current task
- **Context**: Include what you already explored and what remains
- **Entry Point**: The URL where you left off
- **Done When**: Same criteria minus what's already done

#### Type B: Discovery (genuinely new area found)

Only create if ALL are true:
1. You discovered something not in prior notes
2. It is a **UI area reachable by browser navigation** within the allowed domains -- you must have seen a link, button, or URL that leads to it in your snapshot
3. Current task depth is **0** -- depth-1 workers NEVER create discovery tasks (MAX_DEPTH = 2 means kickoff->depth1->depth2 max, so only kickoff-created depth-0 tasks may spawn depth-1 discoveries)
4. It requires significant exploration (not a quick observation you can document now)

**NEVER create Type B tasks for:**
- Backend infrastructure, servers, databases, queues, or cloud services -- even if you infer they exist
- Features or components not visible or navigable in the browser
- Implementation work ("implement X", "setup Y", "create Z service")
- Areas outside the allowed domains or flow scope defined in business-context.md
- Anything you did not directly observe via `browser_snapshot`

**Task file format** (write to `{tasks-output-path}/{task-name}.md`):

```markdown
# Task: {task-name}

## Objective
{What to explore -- be specific}

## Context
{Concrete data from your snapshot -- exact labels, counts, element names}

## Entry Point
{Direct URL}

## Depth
{current depth + 1}

## Created By
{your task name}

## Done When
{Concrete, verifiable criteria}
```

**IMPORTANT**: Do NOT verify files after writing -- a background process moves tasks from `pending/` to `locked/` immediately. Write each file once and move on.

### Step 7: Deliver Summary

**Pipeline mode** -- print only:
```
Wrote findings to {notes-path} ({count} selectors, {count} interactions used, continuation: yes/no).
```

**Standalone mode** -- present to the user:
```
Exploration complete

Area: {scope}
Interactions used: {count}

Findings:
- Selectors discovered: {count}
- Behaviors documented: {count}
- Blocking elements: {count}
- Wait strategies defined: {count}

Files:
- ./output/exploration/{slug}-notes.md

Top discoveries:
1. {key finding}
2. {key finding}
3. {key finding}
```

---

## Automation Mode (`--for-automation`)

**Trigger:** Message contains `--for-automation`, keywords "inspect selectors", "validate selectors", "automation inspection", or the request focuses on discovering selectors for test automation rather than general exploration.

**What changes:**
- Output goes to `./output/exploration/validated-test-cases-{slug}.md` (same `./output/exploration/` directory as the default mode, different filename prefix)
- Focus shifts to: selector validation, user journey mapping with wait strategies, blocking element documentation
- All selectors MUST be browser-verified before documenting

**Read `references/automation-mode.md`** for the complete automation mode steps, output format, and rules.

**Context output** (automation mode): `"Wrote ./output/exploration/validated-test-cases-{slug}.md (X pages visited, Y elements found, Z selectors validated, W blockers discovered)."`

---

## MCP Tools

Use **only `@playwright/mcp`** tools (prefixed with `mcp__playwright__`):

| Tool | When to Use |
|------|-------------|
| `browser_navigate` | Go to URLs, follow links |
| `browser_snapshot` | Read the page -- accessibility tree, elements, structure |
| `browser_click` | Click elements to see what happens |
| `browser_type` | Fill text inputs |
| `browser_navigate_back` | Go back to previous page |
| `browser_select_option` | Select from dropdowns |
| `browser_hover` | Check hover states |
| `browser_take_screenshot` | Only when visual context is essential (use sparingly -- each costs ~1500 tokens) |

## Context Efficiency

All detailed output MUST be written to files on disk, NOT printed to the conversation.

**Print ONLY** the brief delivery summary (Step 7) to the conversation.

## Key Rules

- NEVER re-document what is already in prior notes -- read them first and add only NEW information
- NEVER navigate outside the flow scope or allowed domains
- NEVER submit payment forms, create real accounts, or delete data
- NEVER use `networkidle` for wait strategies -- always use specific element state changes
- ALWAYS validate selectors by actually observing them in the snapshot
- ALWAYS note the selector's stability (data-testid > id > aria-label > CSS)
- ALWAYS respect the ~15 interaction budget in pipeline mode -- stop and write before running out
- ALWAYS create a continuation task if area is not fully explored within budget
- Pipeline mode: Do NOT create Type B discovery tasks if your current task depth >= 1 -- only depth-0 tasks may spawn discoveries
- Pipeline mode: Type B tasks MUST reference a URL or UI element you actually observed in a snapshot -- no inferences about backend/infrastructure
- Pipeline mode: Do NOT verify task files after writing
