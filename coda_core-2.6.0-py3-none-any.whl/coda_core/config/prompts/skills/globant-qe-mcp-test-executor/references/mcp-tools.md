# Playwright MCP Tools Reference

Use **only `@playwright/mcp`** tools (prefixed with `mcp__playwright__`). Do NOT use `mcp-web-inspector` tools.

## Navigation

| Tool | Purpose | Key Arguments |
|------|---------|---------------|
| `browser_navigate` | Navigate to URL | `url` |
| `browser_navigate_back` | Go back to previous page | -- |

## Observation (Primary)

| Tool | Purpose | Key Arguments |
|------|---------|---------------|
| `browser_snapshot` | Read the page -- returns accessibility tree with element names, roles, and ref identifiers | -- |
| `browser_take_screenshot` | Capture visual evidence (screenshot) | -- |
| `browser_console_messages` | Read browser console output (errors, warnings, info) | -- |

`browser_snapshot` is the PRIMARY observation tool. Use it:
- After EVERY navigation to confirm page loaded
- After EVERY interaction to verify resulting state
- To find elements by reading the accessibility tree
- To verify text presence, element visibility, and page structure

The accessibility tree output shows elements with their roles (button, textbox, link, heading, etc.), names, and reference identifiers that can be used in interaction tools.

## Interactions

| Tool | Purpose | Key Arguments |
|------|---------|---------------|
| `browser_click` | Click element (auto-scrolls into view) | `element` (description from snapshot), `ref` (element ref from snapshot) |
| `browser_type` | Enter text in input field | `element`, `text`, `ref` |
| `browser_select_option` | Select from dropdown | `element`, `values`, `ref` |
| `browser_hover` | Hover over element | `element`, `ref` |
| `browser_drag` | Drag element to target | `startElement`, `endElement` |
| `browser_press_key` | Press keyboard key | `key` (e.g., "Enter", "Tab", "Escape") |

**Element references**: Use the element description from `browser_snapshot` output (e.g., `"Submit" button`, `"Email" textbox`). Playwright MCP resolves elements from their accessibility tree descriptions.

## Tab Management

| Tool | Purpose | Key Arguments |
|------|---------|---------------|
| `browser_tab_list` | List open browser tabs | -- |
| `browser_tab_new` | Open new tab | `url` |
| `browser_tab_select` | Switch to tab | `index` |
| `browser_tab_close` | Close a tab | `index` |

## Cleanup

| Tool | Purpose |
|------|---------|
| `browser_close` | Close browser session |

## Assertion Patterns

For test execution, use these tools to validate expected outcomes:

| Assertion Type | Approach |
|----------------|----------|
| Element visible | `browser_snapshot` -- element appears in accessibility tree |
| Element hidden | `browser_snapshot` -- element NOT in tree |
| Text present | `browser_snapshot` -- search for text in tree output |
| Text absent | `browser_snapshot` -- text NOT in tree |
| Page navigated | `browser_snapshot` -- check page title or unique element |
| Element state | `browser_snapshot` -- inspect element attributes (disabled, checked, expanded) |
| Visual state | `browser_take_screenshot` -- capture for evidence |
| No errors | `browser_console_messages` -- check for error-level messages |

## Key Differences from mcp-web-inspector

- There is NO `check_visibility`, `find_by_text`, `element_exists`, or `query_selector` -- use `browser_snapshot` for all observation
- There is NO `wait_for_element` -- use `browser_snapshot` to poll state after actions
- There is NO `fill` -- use `browser_type` (click field first if needed)
- There is NO `scroll_to_element` -- `browser_click` auto-scrolls
- `browser_snapshot` returns an accessibility tree, not raw DOM -- elements are described by role and name
