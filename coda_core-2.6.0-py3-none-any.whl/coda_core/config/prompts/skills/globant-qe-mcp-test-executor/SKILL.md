---
name: globant-qe-mcp-test-executor
description: Execute documented test cases step-by-step using Playwright MCP server -- navigate, interact, validate, and report results without generating automation code. Use when the user wants to run test cases manually via browser automation to verify application behavior
compatibility: Designed for CODA. Requires Playwright MCP server (@playwright/mcp)
metadata:
 author: coda-testing
 version: "1.0.0"
---

# MCP Test Executor

Execute documented test cases step-by-step using the Playwright MCP server. Navigate the application, perform interactions, validate expected outcomes, and produce a pass/fail execution report -- all without generating automation code.

**This skill is NOT for code generation.** It uses MCP tools as a live browser to walk through each test case, perform the described actions, and verify the expected results in real time.

## Instructions

### Step 1: Load Test Cases

1. **Locate test case source**: The orchestrator (or user) provides the test case file path. Accept test cases from ANY location -- they may be in `./output/test-scenarios/`, in a user-specified path, or provided inline in the conversation.
 - If a file path is provided: read and parse that file
 - If test cases are provided inline: use them directly
 - If NO test cases are provided and no path is given: proceed to **Step 1b: Auto-Discover Local Context** before failing

2. **Parse test cases** into executable steps. For each test case extract:
 - Test case ID and name
 - Priority (P0, P1, P2, P3)
 - Preconditions
 - Steps (action + expected result per step)
 - Selectors (if available in the source document)

3. **Collect execution parameters** (ask only for what's missing):
 - **REQUIRED**: Application URL (auto-discoverable -- see Step 1b)
 - **OPTIONAL**: Credentials (if test cases mention authentication), specific test case IDs to execute (default: all), browser mode (headless/headed, default: headed)

4. **Plan execution order**: Execute by priority -- all P0 first, then P1, then P2, then P3. Within same priority, execute in document order.

5. **Ensure output directory**: Create `./output/execution/` if it doesn't exist.

### Step 1b: Auto-Discover Local Context

When test cases or URL are not provided directly, scan the local working directory. Search in priority order:

1. **Test cases** -- scan for the most recent file matching:
 - `./output/test-scenarios/test-cases-*.md` (from `globant-qe-test-scenario-designer`)
 - `./output/exploration/validated-test-cases-*.md` (automation-mode output from `globant-qe-web-explorer`)
 - `**/test-cases*.md`, `**/test_cases*.md` (broader fallback for user-provided locations)

2. **Application URL** (if not provided inline):
 - Look for an "Application URL", "Entry Point URL", or "URL" field inside the discovered test cases file
 - If not found there, scan exploration notes: `./output/exploration/**/*.md` -- extract the Task Info > Entry Point URL or the URL recorded in the exploration findings

**If content is found**: proceed with the discovered material. Add a note in the execution report metadata: _"Test cases and/or URL auto-discovered from local files: {list of source files}."_

**If no test cases are found AND none are provided inline**: output error and STOP:
```
ERROR: No test cases provided and none found in the local directory.
Usage: /globant-qe-mcp-test-executor "[test case file path]" "[URL]"
Example: /globant-qe-mcp-test-executor ./output/test-scenarios/test-cases-login.md https://example.com
Tip: Run /globant-qe-test-scenario-designer first to generate test cases from user stories.
```

**If test cases are found but URL is missing** (not in the test cases file, not in exploration notes, not provided inline): output error and STOP:
```
ERROR: Application URL is required but was not provided or discovered in upstream context.
Usage: /globant-qe-mcp-test-executor [test-cases-path] [URL]
```

### Step 2: Prepare Browser Session

1. **Navigate** to the application URL using `browser_navigate`
2. **Verify application is accessible**: Use `browser_snapshot` to read the accessibility tree and confirm the page loaded with meaningful content
3. **Handle blocking elements**: Dismiss cookie banners, popups, or overlays that may interfere with test execution (use `browser_click` to dismiss)
4. **Handle authentication** if credentials provided: execute login flow before test cases that require it

If the application is not accessible, write an error report and STOP.

### Step 3: Execute Test Cases

For each test case, execute steps sequentially using MCP tools:

#### 3.1: Execute Each Step

For each step in the test case:

1. **Resolve the action**:
 - "Navigate to [URL]" -> `browser_navigate(url)`
 - "Click [element]" -> `browser_click(element)` (Playwright auto-scrolls into view)
 - "Enter/Type [text] in [field]" -> `browser_type(element, text)` (click field first if needed: `browser_click`)
 - "Select [option] from [dropdown]" -> `browser_select_option(element, values)`
 - "Wait for [element]" -> `browser_snapshot` and verify the element appears in the accessibility tree
 - "Verify [element] is visible" -> `browser_snapshot` and check element presence in the tree
 - "Verify [text] is displayed" -> `browser_snapshot` and search for the text in the tree output
 - "Verify [element] exists" -> `browser_snapshot` and check element presence
 - "Hover [element]" -> `browser_hover(element)`

2. **Find the element** (if not already known from validated-test-cases.md):
 - Use `browser_snapshot` to read the accessibility tree -- it shows element names, roles, and ref identifiers
 - Reference elements by their accessibility tree description (e.g., `"Submit" button`, `"Email" textbox`)
 - Record discovered element references for the execution report

3. **Execute the action** using the appropriate Playwright MCP tool

4. **Wait for completion**: After each action, use `browser_snapshot` to verify the resulting page state before proceeding to the next step. NEVER use hard waits -- the snapshot reflects the current DOM state.

#### 3.2: Validate Expected Results

After executing the step's action, validate the expected result:

| Expected Result Pattern | Validation Method |
|------------------------|-------------------|
| "[element] is visible/displayed" | `browser_snapshot` -> element must appear in accessibility tree |
| "[element] is not visible/hidden" | `browser_snapshot` -> element must NOT appear in tree |
| "[text] is displayed on the page" | `browser_snapshot` -> text must appear in tree output |
| "[text] is NOT displayed" | `browser_snapshot` -> text must NOT appear in tree |
| "User is redirected to [URL/page]" | `browser_snapshot` -> check page title or page-specific element in tree |
| "[element] contains [value]" | `browser_snapshot` -> inspect element's text content in tree |
| "[element] is enabled/disabled" | `browser_snapshot` -> check element attributes in tree |
| "Error message [text] appears" | `browser_snapshot` -> text must appear in tree output |
| "No console errors" | `browser_console_messages` -> no error-level messages |

**Capture evidence**: Take a `browser_take_screenshot` after each validation -- both for passes (proof) and failures (evidence).

#### 3.3: Record Step Result

For each step, record:
- Step number and description
- Action performed (MCP tool + arguments)
- Expected result
- Actual result
- Status: **PASS** or **FAIL**
- Screenshot reference
- If FAIL: error details (what was expected vs what happened)

#### 3.4: Handle Step Failures

When a step fails:
1. **Capture evidence**: screenshot, console logs, DOM state
2. **Record the failure** with full details
3. **Decision on continuation**:
 - If the failed step is a precondition for subsequent steps -> mark remaining steps as **BLOCKED** and move to next test case
 - If the failed step is independent -> continue executing remaining steps in the same test case

#### 3.5: Record Test Case Result

A test case result is determined by its step results:
- **PASS**: ALL steps passed
- **FAIL**: One or more steps failed
- **BLOCKED**: Could not execute due to a prior failure (in precondition or previous dependent test case)

### Step 4: Generate Execution Report

Write `./output/execution/mcp-execution-report-{slug}.md` where `{slug}` = date or test suite name lowercased, spaces -> hyphens. Create the `./output/execution/` directory if it doesn't exist. This is the ONLY output location -- there are no legacy copies in `coda-testing-docs/`.

```markdown
## Summary

| Metric | Value |
|--------|-------|
| Total Test Cases | X |
| Passed | X (XX%) |
| Failed | X (XX%) |
| Blocked | X (XX%) |
| Total Steps Executed | X |
| Steps Passed | X |
| Steps Failed | X |
| Execution Date | YYYY-MM-DD HH:MM |
| Application URL | https://... |
| Duration | ~Xm |

## Results by Priority

| Priority | Total | Passed | Failed | Blocked | Pass Rate |
|----------|-------|--------|--------|---------|-----------|
| P0 | X | X | X | X | XX% |
| P1 | X | X | X | X | XX% |
| P2 | X | X | X | X | XX% |
| P3 | X | X | X | X | XX% |

## Test Case Results

| TC ID | Name | Priority | Steps | Passed | Failed | Result |
|-------|------|----------|-------|--------|--------|--------|
| TC-001 | Login happy path | P0 | 5 | 5 | 0 | PASS |
| TC-002 | Login invalid credentials | P0 | 4 | 3 | 1 | FAIL |

## Failed Test Details

### TC-002: Login invalid credentials
- **Failed Step**: Step 4 -- Verify error message "Invalid credentials" is displayed
- **Expected**: Text "Invalid credentials" visible on page
- **Actual**: Text not found. Found "Login failed" instead
- **Evidence**: screenshot-TC-002-step4.png
- **Classification**: APP_BEHAVIOR -- application shows different message than documented

ERROR TC-002: Expected text "Invalid credentials" not found -- actual text "Login failed"

## Blocked Test Details

### TC-005: Profile update
- **Blocked by**: TC-003 (login required, TC-003 failed)
- **Reason**: Cannot access profile page without successful authentication

WARNING TC-005: BLOCKED -- depends on TC-003 which failed

## Discovered Selectors

| Element | Selector | Page | Validated |
|---------|----------|------|-----------|
| Username input | input[data-testid='username'] | Login | Yes |

## Observations

- [Any unexpected behaviors, performance issues, or notes discovered during execution]

## Console Errors

- [Console errors captured during execution, if any]
```

### Step 5: Classify Failures

For each failed test case, classify the failure:

| Classification | Meaning | Example |
|---------------|---------|---------|
| **APP_BUG** | Application behavior doesn't match expected result | Button click does nothing, wrong text displayed |
| **APP_BEHAVIOR** | App works but differently than documented | Different error message text, different redirect URL |
| **SELECTOR_ISSUE** | Element not found on page | Selector changed, element removed, page restructured |
| **TIMING_ISSUE** | Element not ready in time | Slow load, animation delay, AJAX not complete |
| **BLOCKED** | Could not execute due to prior failure | Login failed, so profile tests couldn't run |

### Step 6: Cleanup

1. **Close browser session** using `browser_close`
2. **Verify report file** exists on disk
3. **Print summary** to conversation (see Context Efficiency below)

## MCP Tools Reference

See [references/mcp-tools.md](references/mcp-tools.md) for the complete MCP tools reference.

## Context Efficiency

All detailed output MUST be written to files on disk, NOT printed to the conversation. This keeps the context window small and reduces token consumption.

**To the conversation, print ONLY a brief completion summary** (max 5-10 lines):
- What was completed
- Output file path(s)
- Key metrics (counts, scores, pass rates)
- Any questions or decisions needed from the user

**In output files**, start with a `## Summary` block containing pre-computed aggregate statistics so downstream skills (or the user) can read just the summary instead of the full document.

**Use grep-friendly format** for errors and warnings in output files:
- `ERROR <identifier>: <reason on same line>`
- `WARNING <identifier>: <reason on same line>`

**Context output** (print ONLY this when done):
```
Wrote ./output/execution/mcp-execution-report-{slug}.md
Results: X total -- Y passed, Z failed, W blocked (XX% pass rate)
P0: X/Y passed | P1: X/Y passed
[1-line per failure]: FAIL TC-XXX: [brief reason]
```

Do NOT print MCP tool output, DOM data, full step details, or screenshots to the conversation. Everything goes to the report file.

## Key Rules

- ALWAYS ensure `./output/execution/` directory exists before writing output files
- ALWAYS load and parse test cases before executing -- never improvise test steps
- ALWAYS execute test cases by priority order (P0 first)
- ALWAYS validate expected results after each action -- never skip validations
- ALWAYS capture screenshot evidence for every validation (pass or fail)
- ALWAYS use `browser_snapshot` between actions to verify page state -- never assume elements are ready
- ALWAYS classify failures with evidence -- never leave failures unexplained
- ALWAYS close the browser session when done
- NEVER generate automation code -- this skill EXECUTES test cases, it does not produce code
- NEVER modify or rewrite test cases -- execute them as documented
- NEVER skip failed steps without recording evidence
- NEVER use hard waits -- always wait for specific element states
- NEVER continue dependent steps after a blocking failure -- mark as BLOCKED
- NEVER print raw MCP output to the conversation -- write to the report file
- ALWAYS write execution reports to `./output/execution/mcp-execution-report-{slug}.md` -- create the directory if missing
