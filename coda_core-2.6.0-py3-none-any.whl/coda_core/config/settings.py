"""Unified configuration management system for coda-core and client settings."""
import os
from pathlib import Path
from typing import Dict, Any, Optional, Type, List
from enum import Enum

import dotenv
import portalocker
from loguru import logger

from coda_core.config.env_config import EnvConfig
from coda_core.config.logging.configuration import configure_logger


def _get_coda_system_dir():
    """
    Compute the CODA system directory using CODA_SYSTEM_DIR env var.

    If the environment variable is not set, falls back to the user's
    home directory with ".coda" appended.

    Returns:
        str: The absolute path to the CODA system directory.
    """
    coda_system_dir_env = os.getenv(EnvConfig.CODA_SYSTEM_DIR.value)
    return (
        coda_system_dir_env if coda_system_dir_env
        else _get_default_coda_system_dir()
    )


# Internal function to compute the default CODA system directory
def _get_default_coda_system_dir():
    """
    Computes the default CODA system directory path using the user's home directory.

    The default path is the user's home directory (as determined by os.path.expanduser("~"))
    with ".coda" appended, e.g.,
    - "/home/username/.coda" on Linux
    - "/Users/username/.coda" on macOS
    - "C:\\Users\\username\\.coda" on Windows.

    Returns:
        str: The default absolute path to the CODA system directory.
    """
    return os.path.join(os.path.expanduser("~"), ".coda")


class Settings:
    """
    Unified configuration management system for coda-core and client settings.

    This class provides a singleton instance that manages both coda-core configuration
    and client-specific configurations (CLI, REST API, etc.) through a unified API.
    """
    _instance = None
    _logger_configured = False
    _env_loaded = False

    # Class attributes for shared paths
    coda_dir = _get_coda_system_dir()
    """
    The absolute path to the CODA system directory.

    This path is determined by the CODA_SYSTEM_DIR environment variable if set,
    otherwise it defaults to the user's home directory with ".coda" appended.
    """
    env_path = os.path.join(coda_dir, ".env")
    log_dir = os.path.join(coda_dir, ".logs")
    log_file_path = os.path.join(log_dir, "coda-core.log")
    sessions_db_path = os.path.join(coda_dir, "sessions.db")
    command_history_dir = os.path.join(coda_dir, ".command_history")
    backup_dir = os.path.join(coda_dir, ".backups")
    tools_dir_path = os.path.join(coda_dir, ".tools")
    recipes_dir_path = os.path.join(coda_dir, "recipes")
    agents_dir_path = os.path.join(coda_dir, "agents")
    mcp_dir_path = os.path.join(tools_dir_path, "mcp")
    mcp_servers_dir = os.path.join(mcp_dir_path, "servers.d")
    mcp_global_defaults_file = os.path.join(mcp_dir_path, "global_default_mcp.json")
    mcp_session_config_dir = os.path.join(mcp_dir_path, "sessions")
    # Private plans directory for JSONs (always in home/.coda/.plans)
    private_plans_dir = os.path.join(coda_dir, ".plans")
    # Private skills directory (always in home/.coda/skills)
    private_skills_dir = os.path.join(coda_dir, "skills")

    # Default values for environment variables
    DEFAULT_VALUES = {
        EnvConfig.CODA_LOG_LEVEL: "INFO",
        EnvConfig.CODA_LOG_DIR: log_dir,
        EnvConfig.CODA_COMMAND_HISTORY_DIR: command_history_dir,
        EnvConfig.CODA_DEFAULT_SYSTEM_PROVIDER_NAME: "anthropic",
        EnvConfig.CODA_DEFAULT_SYSTEM_MODEL_NAME: "claude-sonnet-4-6",
        EnvConfig.CODA_UPGRADE_BACKUP_DIR: backup_dir,
        EnvConfig.CODA_SESSION_DB_FILE_PATH: sessions_db_path,
        EnvConfig.CODA_RECIPES_DIR_PATH: recipes_dir_path,
        EnvConfig.CODA_AGENTS_DIR_PATH: agents_dir_path,
        EnvConfig.CODA_COPY_DEFAULT_AGENTS: "true",
        EnvConfig.CODA_SESSION_DB_TABLE_NAME: "sessions",
        EnvConfig.CODA_SESSION_MAX_AGE_DAYS: "30",
        EnvConfig.CODA_GEAI_API_KEY: "",
        EnvConfig.CODA_GEAI_BASE_URL: "",
        EnvConfig.CODA_PYPI_REPO_URL: "",
        EnvConfig.CODA_PYPI_REPO_HOST: "pkgs.dev.azure.com",
        EnvConfig.CODA_PYPI_REPO_ORG: "globant-coda",
        EnvConfig.CODA_PYPI_REPO_PROJECT: "4f87e7d6-53c5-45d6-a208-41c5e6293d99",
        EnvConfig.CODA_PYPI_REPO_FEED: "coda-releases",
        EnvConfig.CODA_PYPI_REPO_USERNAME: "globant",
        EnvConfig.CODA_PYPI_REPO_TOKEN: "",
        EnvConfig.CODA_PYPI_REPO_INCLUDE_PRERELEASE: "false",
        EnvConfig.CODA_USE_LANGFUSE: "false",
        EnvConfig.CODA_DEFAULT_SINGLE_AGENT_PROVIDER_NAME: "anthropic",
        EnvConfig.CODA_DEFAULT_SINGLE_AGENT_MODEL_NAME: "claude-sonnet-4-6",
        EnvConfig.CODA_SINGLE_AGENT_MAX_ITERATIONS: "60",
        EnvConfig.CODA_DEFAULT_SMALL_PROVIDER_NAME: "openai",
        EnvConfig.CODA_DEFAULT_SMALL_MODEL_NAME: "gpt-4o-mini",
        EnvConfig.CODA_VISION_MODEL_PROVIDER: "openai",
        EnvConfig.CODA_VISION_MODEL_NAME: "o4-mini",
        EnvConfig.CODA_TOOLS_DIR_PATH: tools_dir_path,
        EnvConfig.CODA_MCP_SERVERS_DIR: mcp_servers_dir,
        EnvConfig.CODA_MCP_GLOBAL_DEFAULTS_FILE: mcp_global_defaults_file,
        EnvConfig.CODA_MCP_SESSION_CONFIG_DIR: mcp_session_config_dir,
        EnvConfig.CODA_DEFAULT_BASH_SECURITY_LEVEL: "low",
        EnvConfig.CODA_DEFAULT_REASONING_EFFORT: "default",
        EnvConfig.CODA_MEMORY_CONDENSING_ENABLED: "true",
        EnvConfig.CODA_MEMORY_CONDENSING_THRESHOLD: "0.5",
        EnvConfig.CODA_MEMORY_CONDENSING_LLM_PROVIDER: "openai",
        EnvConfig.CODA_MEMORY_CONDENSING_LLM_MODEL: "gpt-4.1-mini",
        EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE: private_plans_dir,
        EnvConfig.CODA_REMOTE_MENTIONS_MODE: "favorites",
        EnvConfig.CODA_REMOTE_MENTIONS_ALLOWLIST: "",
        EnvConfig.CODA_OMNI_PARSER_INLINE_THRESHOLD_CHARS: "8000",
        EnvConfig.CODA_OMNI_PARSER_MAX_DOC_FILE_SIZE_MB: "50",
        EnvConfig.CODA_OMNI_PARSER_MAX_MEDIA_FILE_SIZE_MB: "300",
        EnvConfig.CODA_OMNI_PARSER_HARD_MAX_FILE_SIZE_MB: "1024",
        EnvConfig.CODA_UPGRADE_AVAILABLE: "false",
        EnvConfig.CODA_SKILL_OUTPUT_DIR: ".coda/skill-artifacts",
        EnvConfig.CODA_COPY_DEFAULT_SKILLS: "true",
        EnvConfig.CODA_SEND_METADATA: "false"
    }

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(Settings, cls).__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        """
        Initialize the Settings singleton instance.

        Sets up the configuration system by:
        - Creating required directories
        - Initializing client configuration registry
        - Loading environment variables from .env file
        - Configuring the logger
        """
        try:
            # Initialize client configuration registry
            self._client_config_registry: Dict[str, Dict[str, str]] = {}

            # Ensure all required directories exist
            self._ensure_directories()

            if not self._env_loaded:
                self._load_env()
                self._env_loaded = True
            if not self._logger_configured:
                self._configure_logger()
                self._logger_configured = True
        except OSError as e:
            logger.exception(f"OS error during Settings initialization: {e}")
            raise
        except Exception as e:
            logger.exception(f"Unexpected error during Settings initialization: {e}")
            raise

    def _ensure_directories(self) -> None:
        """
        Ensure all required directories exist.
        """
        directories = [
            self.coda_dir,
            self.log_dir,
            self.command_history_dir,
            self.backup_dir,
            self.tools_dir_path,
            self.recipes_dir_path,
            self.agents_dir_path,
            self.private_plans_dir,
            self.private_skills_dir,
        ]

        for directory in directories:
            os.makedirs(directory, exist_ok=True)
            
        # Ensure the plans directory exists in the current working directory
        plans_dir = self.get_plans_dir()
        os.makedirs(plans_dir, exist_ok=True)
        
        # Ensure the skills directory exists in the current working directory
        skills_dir = self.get_skills_dir()
        os.makedirs(skills_dir, exist_ok=True)

    def _get_env_file_path(self, client_name: Optional[str] = None) -> str:
        """
        Get the appropriate .env file path based on client_name.

        Args:
            client_name (Optional[str]): Client name or None for core settings.

        Returns:
            str: Path to the .env file.
        """
        if client_name is None:
            return self.env_path
        return os.path.join(self.coda_dir, f".env.{client_name}")

    def _get_defaults_dict(self, client_name: Optional[str] = None) -> Dict[str, str]:
        """
        Get the appropriate defaults dictionary based on client_name.

        Args:
            client_name (Optional[str]): Client name or None for core settings.

        Returns:
            Dict[str, str]: Dictionary of default values.

        Raises:
            ValueError: If client_name is not registered.
        """
        if client_name is None:
            return {key.value: value for key, value in self.DEFAULT_VALUES.items()}
        if self.is_client_registered(client_name):
            return self._client_config_registry[client_name]
        raise ValueError(
            f"Client '{client_name}' not registered. Use register_client_config() first."
        )

    def _initialize_env_file(self, client_name: Optional[str] = None) -> None:
        """
        Create and initialize the .env file with default values.

        Args:
            client_name (Optional[str]): Client name or None for core settings.
        """
        try:
            env_file_path = self._get_env_file_path(client_name)
            defaults_dict = self._get_defaults_dict(client_name)

            env_file = Path(env_file_path)
            # Create the .env file if it doesn't exist
            with env_file.open("w", encoding="utf-8") as f:
                portalocker.lock(f, portalocker.LOCK_EX)  # Acquire exclusive lock on the file

                for key, value in sorted(defaults_dict.items()):
                    f.write(f"{key}={value}\n")

            logger.info(f"Initialized {os.path.basename(env_file_path)} with default values")
        except OSError as e:
            logger.exception(f"OS error initializing {os.path.basename(env_file_path)}: {e}")
            raise
        except Exception as e:
            logger.exception(f"Error initializing {os.path.basename(env_file_path)}: {e}")
            raise

    def _write_env_file_content(
        self,
        env_file: Path,
        sync_data: Dict[str, Any]
    ) -> None:
        """
        Write the updated content to the .env file.

        Args:
            env_file (Path): Path to the .env file.
            sync_data (Dict[str, Any]): Dictionary containing:
                - current_values: Current values from the file
                - default_values: Default values
                - keys_to_add: Keys to add to the file
                - keys_to_remove: Keys to remove from the file
        """
        current_values = sync_data["current_values"]
        default_values = sync_data["default_values"]
        keys_to_add = sync_data["keys_to_add"]
        keys_to_remove = sync_data["keys_to_remove"]

        # Combine all keys to write (existing and new)
        all_keys = []

        # Add existing keys that should remain
        for key in set(current_values.keys()) - keys_to_remove:
            all_keys.append((key, current_values[key]))

        # Add new keys with default values
        for env_var in default_values.keys():
            if env_var in keys_to_add:
                all_keys.append((env_var, default_values[env_var]))

        # Sort all keys alphabetically and write to file
        with env_file.open("w", encoding="utf-8") as f:
            for key, value in sorted(all_keys, key=lambda x: x[0]):
                f.write(f"{key}={value}\n")

    def _sync_env_file(self, client_name: Optional[str] = None) -> None:
        """
        Synchronize the .env file with the current default values.

        - Preserves existing values for variables still present in defaults.
        - Adds new variables from defaults that are missing in the file.
        - Removes variables from the file that are no longer in defaults.

        Args:
            client_name (Optional[str]): Client name or None for core settings.
        """
        try:
            # Retrieve the default values and read current values
            default_values = self._get_defaults_dict(client_name)
            env_file = Path(self._get_env_file_path(client_name))
            current_values = {}

            if env_file.exists():
                with env_file.open("r", encoding="utf-8") as f:
                    portalocker.lock(f, portalocker.LOCK_SH)
                    for line in f:
                        if line.strip() and not line.startswith('#') and '=' in line:
                            key, value = line.strip().split('=', 1)
                            current_values[key] = value

            # Determine which variables to add or remove
            keys_to_add = set(default_values.keys()) - set(current_values.keys())
            keys_to_remove = set(current_values.keys()) - set(default_values.keys())

            if not keys_to_add and not keys_to_remove:
                logger.debug("Environment variables are already in sync")
                return

            # Write updated content to file
            self._write_env_file_content(env_file, {
                "current_values": current_values,
                "default_values": default_values,
                "keys_to_add": keys_to_add,
                "keys_to_remove": keys_to_remove
            })

            if keys_to_add:
                logger.info(
                    f"Added {len(keys_to_add)} new environment variables "
                    f"to .env file"
                )
            if keys_to_remove:
                logger.info(
                    f"Removed {len(keys_to_remove)} deprecated environment "
                    f"variables from .env file"
                )

        except (OSError, IOError) as e:
            logger.exception(f"Error synchronizing .env file: {e}")
            raise

    def _load_env(self) -> None:
        """
        Load environment variables from the specified .env file.
        If the file does not exist, create it and initialize with default values.
        If it exists, ensure it's synchronized with the current DEFAULT_VALUES.
        """
        try:
            env_file = Path(self.env_path)
            if not env_file.exists():
                self._initialize_env_file()
            else:
                self._sync_env_file()

            with env_file.open("r", encoding="utf-8") as f:
                portalocker.lock(f, portalocker.LOCK_SH)
                dotenv.load_dotenv(self.env_path)
            logger.info(f"Environment variables loaded from {self.env_path}")
        except FileNotFoundError as e:
            logger.exception(f".env file not found: {e}")
            raise
        except Exception as e:
            logger.exception(f"Unexpected error while loading environment variables: {e}")
            raise

    def _configure_logger(self) -> None:
        """
        Configure the loguru logger to write logs to a file.
        """
        try:
            log_file = Path(self.log_file_path)
            log_file.parent.mkdir(parents=True, exist_ok=True)

            # Use the logger configuration with session context support
            configure_logger(
                log_file_path=self.log_file_path,
                log_level=os.getenv(EnvConfig.CODA_LOG_LEVEL.value, "INFO")
            )
        except OSError as e:
            logger.exception(f"OS error while configuring logger: {e}")
            raise
        except Exception as e:
            logger.exception(f"Unexpected error while configuring logger: {e}")
            raise

    def _get_env_var_name(self, key: Enum, client_name: Optional[str] = None) -> str:
        """
        Transform environment variable name with client prefix if applicable.

        Args:
            key (Enum): The configuration key.
            client_name (Optional[str]): Client name or None for core settings.

        Returns:
            str: The transformed environment variable name.
        """
        if client_name is None:
            return key.value
        return f"{client_name.upper()}_{key.value.upper()}"

    def get_env_var(self, key: Enum, client_name: Optional[str] = None) -> str:
        """
        Get the value of an environment variable (core or client-specific).

        Args:
            key (Enum): The key of the environment variable.
            client_name (Optional[str]): Client name or None for core settings.

        Returns:
            str: The value of the environment variable, or the default value if not set.
        """
        try:
            # Check environment variable first
            # (with client prefix if applicable)
            env_var_name = self._get_env_var_name(key, client_name)
            env_value = os.getenv(env_var_name)
            if env_value is not None:
                return env_value

            # Check .env file
            env_file_path = self._get_env_file_path(client_name)
            if os.path.exists(env_file_path):
                env_values = dotenv.dotenv_values(env_file_path)
                if key.value in env_values:
                    return env_values[key.value]

            # Return default value
            defaults_dict = self._get_defaults_dict(client_name)
            return defaults_dict.get(key.value, "")

        except Exception as e:
            logger.exception(f"Error getting environment variable {key.value}: {e}")
            raise

    def set_env_var(
        self, key: Enum, value: str, client_name: Optional[str] = None
    ) -> None:
        """
        Set or update the value of an environment variable.

        Reflects changes in the .env file.

        Args:
            key (Enum): The key of the environment variable.
            value (str): The value to set.
            client_name (Optional[str]): Client name or None for core settings.
        """
        try:
            # Get the proper environment variable name
            # (with client prefix if applicable)
            env_var_name = self._get_env_var_name(key, client_name)

            # Update the .env file first to ensure consistency
            env_file_path = self._get_env_file_path(client_name)
            dotenv.set_key(env_file_path, key.value, value)
            logger.info(f"Updated {os.path.basename(env_file_path)} for {key.value}")

            # Only update the environment in-memory after successful file write
            os.environ[env_var_name] = value
            logger.info(f"Updated environment variable {env_var_name}")
        except OSError as e:
            logger.exception(f"OS error setting {key.value}: {e}")
            raise
        except Exception as e:
            logger.exception(f"Error setting {key.value}: {e}")
            raise

    def get_plans_dir(self) -> str:
        """
        Get the plans directory path in the current working directory.
        
        This path is dynamically computed based on os.getcwd() to ensure
        markdown plans are stored relative to where the user is working.
        
        Returns:
            str: The absolute path to the plans directory in the current working directory.
        """
        return os.path.join(os.getcwd(), ".coda", "plans")

    def get_skills_dir(self) -> str:
        """
        Get the skills directory path in the current working directory.
        
        This path is dynamically computed based on os.getcwd() to ensure
        skills are stored relative to where the user is working.
        
        Returns:
            str: The absolute path to the skills directory in the current working directory.
        """
        return os.path.join(os.getcwd(), ".coda", "skills")

    def check_config_key_conflicts(
        self, config_keys: List[str]
    ) -> Dict[str, str]:
        """
        Check if configuration keys conflict with existing settings.

        Args:
            config_keys (list[str]): List of configuration key names.

        Returns:
            Dict[str, str]: Dictionary mapping conflicting keys to their
                source (e.g., 'core' or 'client:cli').
        """
        conflicts = {}

        # Check against core settings
        core_keys = {key.value for key in EnvConfig}
        for key in config_keys:
            if key in core_keys:
                conflicts[key] = "core"

        # Check against existing client settings
        for (
            client_name, client_config
        ) in self._client_config_registry.items():
            for key in config_keys:
                if key in client_config:
                    conflicts[key] = f"client:{client_name}"

        return conflicts

    def is_client_registered(self, client_name: str) -> bool:
        """
        Check if a client is already registered in the configuration system.

        Args:
            client_name (str): The name of the client to check.

        Returns:
            bool: True if the client is registered, False otherwise.
        """
        return client_name in self._client_config_registry

    def _validate_and_prepare_defaults(
        self, config_enum_class: Type[Enum], defaults: Dict[Enum, Any]
    ) -> Dict[str, Any]:
        """
        Validate defaults against enum class and prepare for registration.

        Args:
            config_enum_class (Type[Enum]): The enum class defining
                configuration keys.
            defaults (Dict[Enum, Any]): Default values for each enum key
                {enum_member: default_value}.

        Returns:
            (Dict[str, Any]): A dictionary mapping configuration keys to
                their validated default values.

        Raises:
            ValueError: If any of the defaults are not part of the
                provided enum class.
        """
        valid_enum_members = set(config_enum_class)
        client_defaults = {}
        for enum_key, default_value in defaults.items():
            if enum_key not in valid_enum_members:
                raise ValueError(
                    f"Invalid config key {enum_key}, must be a "
                    f"{config_enum_class.__name__} enum member"
                )
            client_defaults[enum_key.value] = default_value
        return client_defaults

    def register_client_config(
        self,
        client_name: str,
        config_enum_class: Type[Enum],
        defaults: Dict[Enum, Any]
    ) -> None:
        """
        Register a new client configuration and set up environment file.

        Args:
            client_name (str): The name of the client
                (e.g., 'cli', 'rest-api').
            config_enum_class (Type[Enum]): The enum class defining
                configuration keys.
            defaults (Dict[Enum, Any]): Default values for each enum key
                {enum_member: default_value}.

        Raises:
            ValueError: If client name already exists, provided defaults
                are invalid, or configuration keys conflict with existing
                settings.
        """
        try:
            if self.is_client_registered(client_name):
                raise ValueError(
                    f"Client '{client_name}' is already registered. "
                    f"Use a unique client name."
                )

            # Validate client provided defaults
            client_defaults = self._validate_and_prepare_defaults(
                config_enum_class, defaults
            )

            # Validate conflicts with existing keys
            conflicts = self.check_config_key_conflicts(
                list(client_defaults.keys())
            )
            if conflicts:
                conflict_details = ", ".join(
                    [f"{key} (conflicts with {source})"
                     for key, source in conflicts.items()]
                )
                raise ValueError(
                    f"Configuration key conflicts detected for client "
                    f"'{client_name}': {conflict_details}"
                )

            self._client_config_registry[client_name] = client_defaults
            logger.info(f"Registered client {client_name} with {len(client_defaults)} settings")

            env_file_path = self._get_env_file_path(client_name)
            if os.path.exists(env_file_path):
                self._sync_env_file(client_name)
            else:
                self._initialize_env_file(client_name)
        except Exception as e:
            logger.exception(f"Error registering client {client_name}: {e}")
            raise


# Create system-wide settings instance
SETTINGS = Settings()
