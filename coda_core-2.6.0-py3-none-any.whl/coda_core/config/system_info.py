import platform
import textwrap
import datetime
import os
import locale
import codecs
import ctypes
from pathlib import Path
from typing import Optional

import psutil
from loguru import logger
from gitignore_parser import parse_gitignore
from git import Repo, InvalidGitRepositoryError, NoSuchPathError

from coda_core.config.constants import IGNORE_DIRECTORIES, KNOWN_SHELLS

class SystemInfo:
    def __init__(self):
        """
        Initialize the SystemInfo class and gather system, environment, and project-related information.
        """
        self.working_dir = os.getcwd()
        self.home_dir = str(Path.home())
        self.is_git_repo = self._check_git_repo()
        self.current_date = datetime.datetime.now().strftime('%Y-%m-%d')
        self.os_name = platform.system().lower()
        self.os_version = platform.version()
        self.os_release = platform.release()
        self.shell_process = self.get_shell_process_name()
        self.python_version = platform.python_version()
        self.git_info = self._get_git_info()
        self.directory_structure = self._get_directory_structure()


    def _check_git_repo(self) -> bool:
        """
        Check if the current directory is part of a Git repository.

        Returns:
            bool: True if the directory is part of a Git repository, False otherwise.
        """
        try:
            with Repo(self.working_dir) as repo:
                repo.git_dir
            return True
        except (InvalidGitRepositoryError, NoSuchPathError):
            return False


    def _get_git_info(self) -> dict:
        """
        Gather Git-related information if the current directory is part of a Git repository.

        Returns:
            dict: A dictionary containing Git information.
        """
        if not self.is_git_repo:
            return {
                "branch": None,
                "commit": None,
                "remote": None,
                "main_branch": None,
                "status": None,
                "recent_commits": None,
                "error": "Not a git repository",
            }

        try:
            with Repo(self.working_dir) as repo:
                git_branch = repo.active_branch.name
                git_commit = repo.head.commit.hexsha
                git_remote = "\n".join([f"{remote.name}: {remote.url}" for remote in repo.remotes])

                # Determine the main branch (default to "main" or "master")
                main_branch = "main"
                if "main" not in repo.branches and "master" in repo.branches:
                    main_branch = "master"

                # Get the status and recent commits
                status_output = [f"{item.a_path} ({item.change_type})" for item in repo.index.diff(None)]
                recent_commits = [
                    f"{commit.hexsha[:7]} {commit.message.strip()}" for commit in repo.iter_commits(max_count=5)
                ]

                return {
                    "branch": git_branch,
                    "commit": git_commit,
                    "remote": git_remote,
                    "main_branch": main_branch,
                    "status": status_output,
                    "recent_commits": recent_commits,
                    "error": None,
                }
        except Exception as e:
            return {
                "branch": None,
                "commit": None,
                "remote": None,
                "main_branch": None,
                "status": None,
                "recent_commits": None,
                "error": f"Error retrieving Git information: {str(e)}",
            }


    def _get_directory_structure(self) -> dict:
        """
        Generate a snapshot of the project's directory structure, respecting .gitignore rules.

        Returns:
            dict: A dictionary containing the directory structure or an error message.
        """
        try:
            max_depth = 3
            max_total_entries = 100
            entries_count = 0

            def build_tree(path, depth):
                """
                Recursively build the directory structure as a tree.

                Args:
                    path (Path): The current directory or file path.
                    depth (int): The current depth in the directory tree.

                Returns:
                    dict: A dictionary representing the directory or file.
                """
                nonlocal entries_count
                if entries_count >= max_total_entries:
                    return None

                if depth > max_depth:
                    return None

                if path.is_dir():
                    children = []
                    for child in sorted(path.iterdir()):
                        if any(part in IGNORE_DIRECTORIES for part in child.parts):
                            continue
                        if is_ignored(child):
                            continue
                        child_tree = build_tree(child, depth + 1)
                        if child_tree:
                            children.append(child_tree)
                    entries_count += 1
                    return {"name": path.name, "type": "directory", "children": children}
                elif path.is_file():
                    entries_count += 1
                    return {"name": path.name, "type": "file"}

            # Load .gitignore rules if the file exists
            gitignore_path = Path(self.working_dir) / ".gitignore"
            is_ignored = parse_gitignore(gitignore_path) if gitignore_path.exists() else lambda x: False

            # Build the tree starting from the working directory
            root = build_tree(Path(self.working_dir), depth=0)

            return {"entries": [root], "error": None}
        except Exception as e:
            return {"entries": None, "error": f"Error generating directory structure: {str(e)}"}


    def _get_environment_info(self) -> dict:
        """
        Gather environment-related information.

        Returns:
            dict: A dictionary containing environment information.
        """
        return {
            "working_dir": self.working_dir,
            "home_dir": self.home_dir,
            "is_git_repo": self.is_git_repo,
            "current_date": self.current_date,
            "os_name": self.os_name,
            "os_version": self.os_version,
            "os_release": self.os_release,
            "python_version": self.python_version,
        }
    

    def get_formatted_environment_info(self) -> str:
        """
        Format the environment information into a string.

        Returns:
            str: A formatted string containing environment information.
        """
        env_info = self._get_environment_info()
        # Include shell process name if available
        shell = f"Shell: {self.shell_process}" if self.shell_process else ""

        return textwrap.dedent(f"""
            Working directory: {env_info['working_dir']}
            Is directory a git repo: {env_info['is_git_repo']}
            Today's date: {env_info['current_date']}
            Platform: {env_info['os_name']}
            OS version: {env_info['os_version']}
            OS release: {env_info['os_release']}
            {shell}
            Python version: {env_info['python_version']}
        """).strip()


    def get_formatted_directory_structure_info(self) -> str:
        """
        Format the directory structure into a tree-like string.

        Returns:
            str: A formatted string representing the directory structure in a tree-like format.
        """
        dir_info = self.directory_structure

        if dir_info["error"]:
            # If an error occurred during directory structure generation, return the error message
            return dir_info["error"]

        def format_tree(entries, prefix=""):
            """
            Recursively format the directory structure into a tree-like string.

            Args:
                entries (list): List of directory or file entries.
                prefix (str): The prefix to use for the current level of the tree.

            Returns:
                str: A formatted tree-like string.
            """
            tree = []
            for i, entry in enumerate(entries):
                # Determine if this is the last item in the current level
                is_last = (i == len(entries) - 1)
                connector = "└──" if is_last else "├──"

                # Add the current entry with the appropriate prefix
                tree.append(f"{prefix}{connector} {entry['name']}")

                # If the entry is a directory, recursively format its children
                if entry["type"] == "directory" and entry["children"]:
                    child_prefix = f"{prefix}    " if is_last else f"{prefix}│   "
                    tree.append(format_tree(entry["children"], child_prefix))

            return "\n".join(tree)

        # Format the tree starting from the root
        root = dir_info["entries"][0]  # The root directory
        formatted_structure = ".\n"
        formatted_structure += format_tree(root["children"], prefix="")

        return formatted_structure.strip()


    def get_formatted_git_info(self) -> str:
        """
        Format the Git information into a string.

        Returns:
            str: A formatted string containing Git information.
        """
        git_info = self.git_info

        if git_info["error"]:
            return git_info["error"]

        # Indent each line of the status and recent commits
        status = "\n".join(f"    {line}" for line in git_info["status"]) if git_info["status"] else "    No changes"
        
        # Format the Git information
        formatted_info = f"""
Current branch: {git_info['branch']}
Main branch: {git_info['main_branch']}
Git commit: {git_info['commit']}
Git remote: {git_info['remote']}

Status:
{status}
    """

        # Clean up the overall formatting
        return textwrap.dedent(formatted_info).strip()
    
    @staticmethod
    def get_shell_process_name() -> Optional[str]:
        """
        Traverse up the process tree to find the shell or terminal process name.

        Returns:
            Optional[str]: The name of the shell/terminal process, or None if not found.
        """
        try:
            proc = psutil.Process()
            while proc:
                name = proc.name().lower()
                if any(shell in name for shell in KNOWN_SHELLS):
                    return name
                proc = proc.parent()
        except Exception as e:
            logger.warning(f"Failed to retrieve shell process name: {e}")
        
        return None
    
    @staticmethod
    def detect_system_based_on_shell() -> str:
        """
        Detect the current system based on the shell running.
        
        Returns:
            str: Operating system the shell is running on. Either "windows" or "unix".
        """
        try:
            # Validate type of terminal running
            running_terminal = SystemInfo.get_shell_process_name()
            if running_terminal and running_terminal in ("cmd.exe", "powershell.exe"):
                return "windows"
            return "unix"
        except Exception:
            return "unix"

    @staticmethod
    def detect_console_encoding() -> str:
        """Determine console/text stream encoding using shell-based OS detection.

        Returns:
            str: Preferred encoding label for text-mode subprocess pipes and console output.
        """
        try:
            system = SystemInfo.detect_system_based_on_shell()
            if system == "windows":
                try:
                    cp = ctypes.windll.kernel32.GetConsoleOutputCP()
                    candidate = f"cp{cp}"
                    codecs.lookup(candidate)
                    return candidate
                except Exception:
                    # Fall through to locale on lookup/API failure
                    pass

            enc = locale.getpreferredencoding(False)
            return enc or "utf-8"
        except Exception as e:
            logger.warning(f"Failed to detect console encoding, defaulting to utf-8: {e}")
            return "utf-8"