IGNORE_DIRECTORIES = {
    '.git', '.svn', '.hg', '.bzr',  # Version control directories
    'node_modules',  # Node.js dependencies
    'dist', 'build',  # Build output directories
    '__pycache__', '.cache',  # Python cache
    '.idea', '.vscode', '.settings',  # IDE project settings
    '.terraform',  # Terraform files
    '.serverless',  # Serverless framework files
    '.venv', 'env', 'venv',  # Python virtual environments
    'target',  # Maven/Gradle build output
    '.next', '.nuxt',  # Next.js and Nuxt.js build output
    '.expo',  # Expo for React Native
    '.pytest_cache',  # pytest cache
    '.eggs', '.egg-info',  # Python egg files
    'coverage',  # Test coverage reports
    'out',  # Build outputs for some projects
    'cabal.sandbox', '.stack-work',  # Haskell build artifacts
    'build',  # Common build directory for JavaScript/TypeScript
}

KNOWN_SHELLS = {
    "cmd.exe",
    "powershell.exe",
    "pwsh.exe",
    "wsl.exe",
    "bash.exe",
    "bash",
    "zsh",
    "fish",
    "sh",
    "gnome-terminal-",
    "konsole",
    "xfce4-terminal",
    "alacritty",
    "terminal",
    "xterm"
}

FILE_EXTENSIONS = {".png", ".jpg", ".jpeg"}

# Pattern to match potential file paths
# Matches all file paths with extensions, with or without quotes
# Handles spaces in filenames and various context patterns
FILE_PATH_PATTERN = r'''
    (?:
        # Quoted paths (complete with both quotes)
        ['"]([^'"]*\.[a-zA-Z0-9]+)['"]
        |
        # Quoted paths (missing closing quote - capture until end of line/whitespace)
        ['"]([^'"]*\.[a-zA-Z0-9]+)(?=\s|$)
        |
        # Unquoted paths with spaces after context words (see:, file:, path:, etc.)
        (?:(?:see|file|path|open|load|save|read|write|import|include|source):\s+)(/[^\n\r]*\.[a-zA-Z0-9]+)
        |
        # Unquoted absolute paths with spaces (greedy match until common delimiters)
        (/(?:[^/\n\r]+/)*[^/\n\r]*\.[a-zA-Z0-9]+)(?=\s*(?:$|\n|\r|[,;]|\s+(?:and|or|but|then|also|with|from|to|in|on|at|by)))
        |
        # Unquoted paths without spaces
        (
            # Absolute paths starting with /
            /(?:[^/\s'"]+/)*[^/\s'"]*\.[a-zA-Z0-9]+
            |
            # Relative paths starting with ./ or ../
            (?:\.\./)*(?:\./)?[^/\s'"]*(?:/[^/\s'"]+)*\.[a-zA-Z0-9]+
            |
            # Home directory paths starting with ~/
            ~(?:/[^/\s'"]+)*\.[a-zA-Z0-9]+
            |
            # Windows-style paths
            [A-Za-z]:[/\\](?:[^/\\s'"]+[/\\])*[^/\\s'"]*\.[a-zA-Z0-9]+
            |
            # Simple filename with extension (no path separators)
            [^/\s'"]+\.[a-zA-Z0-9]+
        )
    )
'''

# Agents Constants
AGENTS_PACKAGE_NAME = "coda_core.config.prompts.agents"

DIAGNOSE_AGENT = 'diagnose'
FIX_AGENT = 'fix'
EXPLAIN_AGENT = 'explain'
AGENT_MANAGER = 'agent-manager'
PLAN_AGENT = 'plan'
SKILL_CREATOR = 'coda-skill-creator'

CODEFIXER_AGENTS = [DIAGNOSE_AGENT, FIX_AGENT, EXPLAIN_AGENT]
DEFAULT_AGENTS = CODEFIXER_AGENTS + [AGENT_MANAGER, PLAN_AGENT, SKILL_CREATOR]


# Agent metadata constant
CODA_AGENT_NAME = "coding-agent"

# Skills Constants
SKILLS_PACKAGE_NAME = "coda_core.config.prompts.skills"

DEFAULT_SKILLS: list[str] = [
    'globant-qe-bug-report-writer',
    'globant-qe-mcp-test-executor',
    'globant-qe-test-plan',
    'globant-qe-test-scenario-designer',
    'globant-qe-web-explorer',
]