from typing import List, Tuple

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig


def check_required_env_variables() -> List[Tuple[EnvConfig, str]]:
    """
    Check if the required environment variables are set.
    
    Returns:
        List[Tuple[EnvConfig, str]]: A list of tuples (var_enum, description) for missing variables
    """
    missing_vars = []
    
    if not SETTINGS.get_env_var(EnvConfig.CODA_GEAI_BASE_URL):
        missing_vars.append((EnvConfig.CODA_GEAI_BASE_URL, "GEAI Base URL"))

    # Check for GEAI API key and base URL
    if not SETTINGS.get_env_var(EnvConfig.CODA_GEAI_API_KEY):
        missing_vars.append((EnvConfig.CODA_GEAI_API_KEY, "GEAI API Key"))

    # Check for Azure DevOps token (needed for automatic upgrade checks)
    if not SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_TOKEN):
        missing_vars.append((EnvConfig.CODA_PYPI_REPO_TOKEN, "Azure Access Token"))
        
    return missing_vars


def are_geai_credentials_available() -> bool:
    """
    Return True when GEAI credentials are present and non-empty.

    This helper centralizes the environment-based check used across the
    codebase to determine if remote GEAI features should be enabled.

    Returns:
        bool: True if both CODA_GEAI_BASE_URL and CODA_GEAI_API_KEY are set.
    """
    try:
        base_url = SETTINGS.get_env_var(EnvConfig.CODA_GEAI_BASE_URL)
        api_key = SETTINGS.get_env_var(EnvConfig.CODA_GEAI_API_KEY)
        return bool(base_url and api_key)
    except Exception:
        return False
