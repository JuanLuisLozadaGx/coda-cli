import contextvars
from typing import Dict, Optional
from loguru import logger

# Context variables for session and client information
session_id_var = contextvars.ContextVar("session_id", default=None)
session_name_var = contextvars.ContextVar("session_name", default=None)
client_name_var = contextvars.ContextVar("client_name", default=None)

def set_session_context(session_id: str, session_name: str, client_name: Optional[str] = None) -> None:
    """
    Set the session context for the current thread.
    
    Args:
        session_id: The ID of the current session
        session_name: The name of the current session
        client_name: The name of the client (e.g., 'cli', 'rest-api')
    """
    session_id_var.set(session_id)
    session_name_var.set(session_name)
    client_name_var.set(client_name)
    logger.debug(f"Set session context: ID={session_id}, Name={session_name}, Client={client_name}")

def clear_session_context() -> None:
    """Clear the session context for the current thread."""
    session_id_var.set(None)
    session_name_var.set(None)
    client_name_var.set(None)
    logger.debug("Cleared session context")

def capture_session_context() -> Dict[str, Optional[str]]:
    """
    Capture the current session context for later restoration.
    
    This is useful for passing context to background threads.
    
    Returns:
        A dictionary containing the session context
    """
    return {
        "session_id": session_id_var.get(),
        "session_name": session_name_var.get(),
        "client_name": client_name_var.get()
    }

def restore_session_context(context: Dict[str, Optional[str]]) -> None:
    """
    Restore a previously captured session context.
    
    Args:
        context: A dictionary containing the session context
    """
    session_id = context.get("session_id")
    session_name = context.get("session_name")
    client_name = context.get("client_name")
    
    if session_id is not None and session_name is not None:
        set_session_context(session_id, session_name, client_name)
    else:
        clear_session_context()

def set_client_context(client_name: str) -> None:
    """
    Set only the client context for the current thread.
    
    This is useful when you want to set client context independently
    of session context (e.g., for system-level operations).
    
    Args:
        client_name: The name of the client (e.g., 'cli', 'rest-api')
    """
    client_name_var.set(client_name)

def get_client_context() -> Optional[str]:
    """
    Get the current client context.
    
    Returns:
        The current client name or None if not set
    """
    return client_name_var.get()