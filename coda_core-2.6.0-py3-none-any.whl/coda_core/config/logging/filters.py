from typing import Dict, Any
from coda_core.config.logging.context import session_id_var, session_name_var, client_name_var

def session_context_filter(record: Dict[str, Any]) -> Dict[str, Any]:
    """
    Custom loguru filter to add session context to log records.
    
    Args:
        record: The log record to modify
        
    Returns:
        The modified log record with session context
    """
    # Add session and client context to the record
    session_id = session_id_var.get()
    session_name = session_name_var.get()
    client_name = client_name_var.get()
    
    # Use placeholder values for None to make logs more readable
    record["extra"]["session_id"] = session_id if session_id is not None else "system"
    record["extra"]["session_name"] = session_name if session_name is not None else "system"
    record["extra"]["client_name"] = client_name if client_name is not None else "core"
    
    return record