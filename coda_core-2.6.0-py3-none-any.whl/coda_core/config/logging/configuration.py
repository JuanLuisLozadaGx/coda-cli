from loguru import logger
from coda_core.config.logging.filters import session_context_filter

def configure_logger(log_file_path: str, log_level: str = "INFO") -> None:
    """
    Configure the loguru logger with session context.
    
    Args:
        log_file_path: Path to the log file
        log_level: Log level (default: INFO)
    """
    # Remove default logger
    logger.remove()
    
    # Add file logger with session context
    # Using loguru's default format and adding session context
    logger.add(
        log_file_path,
        rotation="1 day",  # Rotate logs daily
        retention="7 days",  # Keep logs for 7 days
        level=log_level,
        filter=session_context_filter,
        # Format includes default loguru format plus session and client context
        format="<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <magenta>[{extra[client_name]}]</magenta> | <blue>[{extra[session_id]}:{extra[session_name]}]</blue> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
    )
    
    logger.info(f"Logger configured with session and client context. Logs will be saved to {log_file_path}")