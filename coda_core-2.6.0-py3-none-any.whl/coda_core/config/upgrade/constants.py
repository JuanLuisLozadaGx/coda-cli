"""Constants used by the upgrade subsystem.

These values control which package is targeted for upgrades and the
default extras to install. Keeping them in a dedicated module makes
the values easier to reuse and test.
"""

# For now, we will upgrade the full package with all extras. In the future,
# as we add more components, we should only upgrade the components that are installed.
UPGRADABLE_PACKAGE_DISTRIBUTION_NAME = "coda"
DEFAULT_EXTRAS = "all"

TOP_LEVEL_PACKAGE_CODA_CORE = "coda_core"

TOP_LEVEL_PACKAGES_TO_BACKUP = [
    UPGRADABLE_PACKAGE_DISTRIBUTION_NAME, # The distribution name and top-level name match for the metapackage
    TOP_LEVEL_PACKAGE_CODA_CORE,
    "coda_cli",
]

# Azure DevOps repository test strings
AZURE_DEVOPS_HOSTNAME = "pkgs.dev.azure.com"
AZURE_DEVOPS_HOST_SUFFIX = f".{AZURE_DEVOPS_HOSTNAME}"
AZURE_DEVOPS_PATH_KEYWORD = "_packaging"
AZURE_KEYWORD = "azure"