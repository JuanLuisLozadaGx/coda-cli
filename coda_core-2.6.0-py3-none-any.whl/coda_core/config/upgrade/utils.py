"""Utility functions for repository URL and host validation."""
import urllib.parse
from typing import Optional

from coda_core.config.upgrade.constants import (
    AZURE_DEVOPS_HOSTNAME,
    AZURE_DEVOPS_HOST_SUFFIX,
    AZURE_DEVOPS_PATH_KEYWORD,
    AZURE_KEYWORD,
)

def is_azure_devops_url(repo_url: Optional[str]) -> bool:
    """
    Check if the given URL is an Azure DevOps feed URL.
    Args:
        repo_url (Optional[str]): The repository URL to check.
    Returns:
        bool: True if the URL matches Azure DevOps feed pattern, False otherwise.
    """
    if repo_url and isinstance(repo_url, str):
        try:
            parsed_url = urllib.parse.urlparse(repo_url)
            if parsed_url.scheme in ("http", "https") and parsed_url.netloc:
                hostname = parsed_url.hostname
                if hostname and (
                    hostname == AZURE_DEVOPS_HOSTNAME or hostname.endswith(AZURE_DEVOPS_HOST_SUFFIX)
                ) and AZURE_DEVOPS_PATH_KEYWORD in parsed_url.path:
                    return True
        except ValueError:
            return False
    return False

def is_azure_devops_host(repo_host: Optional[str]) -> bool:
    """
    Check if the given host string is likely an Azure DevOps host.
    Args:
        repo_host (Optional[str]): The repository host to check.
    Returns:
        bool: True if the host contains Azure keyword, False otherwise.
    """
    if repo_host and isinstance(repo_host, str):
        if AZURE_KEYWORD in repo_host.lower():
            return True
    return False
