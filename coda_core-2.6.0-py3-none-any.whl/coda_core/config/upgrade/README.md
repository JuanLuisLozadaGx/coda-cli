# Upgrade Management System

## Overview

The Upgrade Management System provides a robust, fault-tolerant mechanism for upgrading the CODA Core application. This system ensures that upgrades are performed safely, with automatic backup and rollback capabilities to prevent system corruption or data loss.

Key capabilities include:

- Automatic backup creation before upgrading
- Secure repository authentication
- Verification of successful upgrades
- Automatic rollback on failure
- Version management and comparison
- Comprehensive error handling

## Architecture

The upgrade system is designed with a modular architecture that separates concerns and provides robust error handling:

```mermaid
flowchart TD
    A[Executor] --> B[Backup]
    A --> C[Repository]
    A --> D[Verification]
    A --> E[Version]
    B --> F[Filesystem Operations]
    C --> G[Authentication]
    D --> H[Subprocess Verification]
    D --> I[Module Checks]
    E --> J[Version Comparison]
```

## Data Flow

```mermaid
flowchart TD
    A[User Initiates Upgrade] --> B[Create Backup]
    B --> C{Backup Success?}
    
    C -->|Yes| D[Get Repository Credentials]
    C -->|No| E[Return Backup Error]
    
    D --> F{Valid Credentials?}
    F -->|Yes| G[Execute pip Upgrade]
    F -->|No| H[Prompt for Credentials]
    H --> I{Valid Credentials?}
    I -->|Yes| G
    I -->|No| J[Return Credential Error]
    
    G --> K{Upgrade Success?}
    K -->|Yes| L[Verify Upgrade]
    K -->|No| M[Restore from Backup]
    M --> N[Return Upgrade Failure]
    
    L --> O{Verification Success?}
    O -->|Yes| P[Return Success]
    O -->|No| Q[Restore from Backup]
    Q --> R[Return Verification Failure]
```

The upgrade process follows these steps:

1. User initiates the upgrade process
2. System creates a backup of the current installation
3. System gets and validates repository credentials
4. If credentials are invalid, the system prompts for new credentials
5. System executes the upgrade using pip
6. If the upgrade fails, the system restores from backup
7. If the upgrade succeeds, the system verifies the upgrade
8. If verification fails, the system restores from backup
9. System returns the result of the upgrade process

### Core Components

| Component | Responsibility | Key Features |
|-----------|----------------|--------------|
| **Executor** | Orchestrates the upgrade process | • Upgrade execution<br>• Process coordination<br>• Error handling<br>• Result reporting |
| **Backup** | Manages system backups | • Backup creation<br>• Backup listing<br>• Backup restoration<br>• Manifest management |
| **Repository** | Handles repository access | • URL construction<br>• Credential management<br>• Authentication validation<br>• Update checking |
| **Verification** | Verifies upgrade success | • Subprocess verification<br>• Module import checks<br>• Class validation<br>• Version validation |
| **Version** | Manages version information | • Current version retrieval<br>• Version comparison<br>• Semantic versioning support |

### Key Features

#### Backup and Restore

The system creates comprehensive backups before attempting upgrades:

| Feature | Description | Implementation |
|---------|-------------|----------------|
| **Package Backup** | Backs up the CODA Core package | • Copies all package files<br>• Preserves directory structure<br>• Creates timestamped backups |
| **Configuration Backup** | Backs up user configuration | • Backs up ~/.coda directory<br>• Preserves user settings<br>• Supports custom directories |
| **Manifest Creation** | Records backup metadata | • Timestamp and date<br>• Version information<br>• File inventory |
| **Backup Listing** | Manages multiple backups | • Lists available backups<br>• Sorts by date (newest first)<br>• Provides backup metadata |
| **Restoration** | Restores from backup | • Restores package files<br>• Restores configuration<br>• Handles errors gracefully |

```mermaid
sequenceDiagram
    participant User
    participant Executor
    participant Backup
    participant Repository
    participant Verification
    
    User->>Executor: execute_upgrade_with_backup()
    Executor->>Backup: create_backup()
    Backup-->>Executor: Backup result
    
    alt Backup Success
        Executor->>Repository: get_credentials()
        Repository-->>Executor: Credentials
        Executor->>Repository: validate_credentials()
        Repository-->>Executor: Validation result
        
        alt Valid Credentials
            Executor->>Executor: execute_upgrade()
            
            alt Upgrade Success
                Executor->>Verification: verify_upgrade()
                Verification-->>Executor: Verification result
                
                alt Verification Success
                    Executor-->>User: Success result
                else Verification Failure
                    Executor->>Backup: restore_from_backup()
                    Backup-->>Executor: Restore result
                    Executor-->>User: Failure with restore info
                end
            else Upgrade Failure
                Executor->>Backup: restore_from_backup()
                Backup-->>Executor: Restore result
                Executor-->>User: Failure with restore info
            end
        else Invalid Credentials
            Executor-->>User: Credential error
        end
    else Backup Failure
        Executor-->>User: Backup error
    end
```

#### Verification Process

The verification system ensures the upgrade was successful:

| Feature | Description | Implementation |
|---------|-------------|----------------|
| **Subprocess Verification** | Tests newly installed code | • Runs in separate process<br>• Ensures testing of actual installed code<br>• Isolates verification from main process |
| **Module Checks** | Verifies critical modules | • Imports key modules<br>• Checks for required attributes<br>• Validates module functionality |
| **Class Validation** | Verifies critical classes | • Checks SingleAgent, Session<br>• Ensures class interfaces are intact<br>• Validates inheritance hierarchy |
| **Version Validation** | Confirms version upgrade | • Checks installed version<br>• Compares with expected version<br>• Validates version format |

```mermaid
flowchart TD
    A[verify_upgrade] --> B[verify_in_subprocess]
    B --> C{Subprocess Success?}
    C -->|Yes| D[run_verification_checks]
    C -->|No| E[Return Failure]
    D --> F{Checks Passed?}
    F -->|Yes| G[Check Expected Version]
    F -->|No| H[Return Failure]
    G --> I{Version Match?}
    I -->|Yes| J[Return Success]
    I -->|No| K[Return Version Mismatch]
```

#### Repository Management

The repository management system handles authentication and update checking:

| Feature | Description | Implementation |
|---------|-------------|----------------|
| **Credential Management** | Manages PyPI repository credentials | • Retrieves credentials from settings<br>• Prompts for missing credentials<br>• Validates credentials before use |
| **Update Checking** | Checks for available updates | • Compares current and latest versions<br>• Uses pip to query repository<br>• Handles parsing and comparison errors |
| **URL Construction** | Builds repository URLs | • Constructs URLs from configuration<br>• Supports custom repositories<br>• Handles authentication in URLs |

## Configuration

The upgrade system requires specific environment variables for operation:

| Category | Variable | Description | Example |
|----------|----------|-------------|---------|
| **Repository** | CODA_PYPI_REPO_URL | Full URL to the repository (alternative to individual components) | https://repo.example.com/simple/ |
| **Repository** | CODA_PYPI_REPO_HOST | Repository host | repo.example.com |
| **Repository** | CODA_PYPI_REPO_ORG | Repository organization | myorg |
| **Repository** | CODA_PYPI_REPO_PROJECT | Repository project | myproject |
| **Repository** | CODA_PYPI_REPO_FEED | Repository feed | myfeed |
| **Repository** | CODA_PYPI_REPO_INCLUDE_PRERELEASE | Include prerelease versions | true/false |
| **Credentials** | CODA_PYPI_REPO_USERNAME | Repository username | username |
| **Credentials** | CODA_PYPI_REPO_TOKEN | Repository token | token123 |
| **Backup** | CODA_UPGRADE_BACKUP_DIR | Backup directory | /path/to/backups |

## Error Handling

The upgrade system provides comprehensive error handling:

| Error Type | Description | Recovery Action |
|------------|-------------|----------------|
| **credential_validation** | Invalid repository credentials | Prompt for new credentials |
| **pip_error** | Error during pip upgrade | Restore from backup |
| **backup_failed** | Backup creation failed | Abort upgrade |
| **verification_failed** | Verification failed after upgrade | Restore from backup |
| **verification_and_restore_failed** | Both verification and restore failed | Manual intervention required |
| **upgrade_and_restore_failed** | Both upgrade and restore failed | Manual intervention required |
| **unknown_target_version** | Unable to determine target version | Abort upgrade |
| **update_check_error** | Error checking for updates | Abort upgrade |

## Security Considerations

The upgrade system includes several security features:

| Feature | Description | Implementation |
|---------|-------------|----------------|
| **Token Masking** | Prevents token exposure in logs | • Replaces token with **** in logs<br>• Prevents accidental exposure |
| **HTTPS Usage** | Secure communication | • All repository access uses HTTPS<br>• Prevents man-in-the-middle attacks |
| **Credential Validation** | Prevents unauthorized access | • Validates credentials before use<br>• Prevents failed upgrades due to auth issues |

## Testing

The upgrade system has been thoroughly tested with:

- Unit tests for all components
- Integration tests for the complete upgrade workflow
- End-to-end tests for the upgrade process
- Test coverage above 86%

The tests cover various scenarios including:
- Successful upgrades
- Failed upgrades with rollback
- Verification failures
- Authentication issues
- Version comparison edge cases
- Repository communication errors

## Prerelease Support

The upgrade system supports consuming prerelease versions of packages through pip's `--pre` flag. This feature is controlled by the `CODA_PYPI_REPO_INCLUDE_PRERELEASE` environment variable.

### Configuration

| Setting | Values | Default | Description |
|---------|--------|---------|-------------|
| `CODA_PYPI_REPO_INCLUDE_PRERELEASE` | `true`, `false`, `1`, `0`, `yes`, `no`, `on`, `off` | `false` | Include prerelease versions when checking for updates |

### Behavior

When prerelease support is **enabled** (`true`):
- The `--pre` flag is added to pip commands
- Both stable and prerelease versions are considered
- Latest prerelease version takes precedence over older stable versions
- Example: `pip install --upgrade --pre coda-core`

When prerelease support is **disabled** (`false`, default):
- Only stable versions are considered
- Prerelease versions are ignored
- Example: `pip install --upgrade coda-core`