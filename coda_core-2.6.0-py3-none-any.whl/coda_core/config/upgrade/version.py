"""Version helpers for the upgrade system.

Provides functions to retrieve the installed distribution version and to
compare semantic versions in a tolerant way (returns "unknown" or equality
on error instead of propagating unexpected exceptions).
"""
import importlib.metadata
import packaging.version

from loguru import logger


def get_current_version(package_name: str = "coda") -> str:
    """Return the installed version for a package.

    Uses :mod:`importlib.metadata` to read the distribution version. If
    the distribution is not installed or an error occurs the error is
    logged and the function returns the literal string ``"unknown"``.

    Args:
        package_name (str): Distribution name to query (default: "coda").

    Returns:
        str: Version string (e.g. "1.2.3") or "unknown" if it cannot be determined.
    """
    try:
        return importlib.metadata.version(package_name)
    except Exception as e:
        logger.error(f"Error determining current version: {e}")
        return "unknown"


def compare_versions(version1: str, version2: str) -> int:
    """
    Compare two version strings using semantic versioning rules.
    
    Args:
        version1: First version string
        version2: Second version string
        
    Returns:
        int: -1 if version1 < version2, 0 if equal, 1 if version1 > version2
    """
    try:
        v1 = packaging.version.parse(version1)
        v2 = packaging.version.parse(version2)

        if v1 < v2:
            return -1
        elif v1 > v2:
            return 1
        else:
            return 0
    except Exception as e:
        logger.error(f"Error comparing versions {version1} and {version2}: {e}")
        # Default to versions being equal if we can't compare them
    return 0
