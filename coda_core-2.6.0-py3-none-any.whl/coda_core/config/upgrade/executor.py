import os
import sys
import subprocess
from typing import Dict, Any, Optional, List

from loguru import logger

from coda_core.config.upgrade.constants import UPGRADABLE_PACKAGE_DISTRIBUTION_NAME, DEFAULT_EXTRAS

from coda_core.config.upgrade.version import get_current_version
from coda_core.config.upgrade.repository import (
    get_repository_credentials_if_required,
    build_pip_index_url,
    requires_authentication,
    check_for_updates,
    include_prerelease_versions,
    CredentialStatus
)
from coda_core.config.upgrade.backup import create_backup, restore_from_backup
from coda_core.config.upgrade.verification import verify_upgrade


def execute_upgrade(package_name: str = UPGRADABLE_PACKAGE_DISTRIBUTION_NAME, extras: str = DEFAULT_EXTRAS) -> (
        Dict)[str, Any]:
    """Execute the upgrade process using pip.

    The function checks the available update, verifies credentials and
    target version, then runs pip to perform the upgrade. It attempts
    to verify the installed version after the pip operation and returns
    a structured result describing success or failure.

    Args:
        package_name (str): Distribution name to upgrade (default: UPGRADABLE_PACKAGE_DISTRIBUTION_NAME).
        extras (str): Extras to install for the package (default: DEFAULT_EXTRAS).

    Returns:
        Dict[str, Any]: Dictionary containing keys such as ``success``,
            ``message``, ``old_version``, ``new_version``, and error details
            when applicable.
    """
    current_version = get_current_version()

    # First check for available updates
    update_info = check_for_updates()

    # If there was an error checking for updates
    if update_info.get('error'):
        return {
            "success": False,
            "message": f"Error checking for updates: {update_info['error']}",
            "error_type": "update_check_error",
            "error_details": update_info['error']
        }
    # If credentials are missing or invalid, we can't proceed
    cred_status = update_info.get('credential_status')
    if cred_status == CredentialStatus.MISSING:
        return {
            "success": False,
            "message": "Repository credentials are missing. Unable to proceed with upgrade.",
            "error_type": "missing_credentials"
        }
    if cred_status == CredentialStatus.INVALID:
        return {
            "success": False,
            "message": "Repository credentials are invalid. Unable to proceed with upgrade.",
            "error_type": "invalid_credentials"
        }

    # If we couldn't determine the latest version
    if 'latest_version' not in update_info:
        return {
            "success": False,
            "message": "Could not determine the latest version. Upgrade aborted.",
            "error_type": "unknown_target_version"
        }

    # If no update is available
    if not update_info.get('update_available'):
        return {
            "success": True,
            "message": f"Already at the latest version: {current_version}. Upgrade not needed.",
            "old_version": current_version,
            "new_version": update_info['latest_version']
        }

    # At this point, we know there's an update available and we know what version it is
    target_version = update_info['latest_version']
    logger.info(f"Upgrading from {current_version} to {target_version}")

    # Get the pip index URL (with or without authentication embedded)
    try:
        pip_index_url = build_pip_index_url()
    except ValueError as e:
        logger.error(f"Failed to build pip index URL: {e}")
        return {
            "success": False,
            "message": f"Failed to build pip index URL: {e}",
            "error_type": "configuration_error",
            "error_details": str(e)
        }

    # Construct pip command
    # - Use extra-index-url to allow fallback to default PyPI if needed for dependencies
    # - Use --upgrade to force installation even if the package is already installed
    # - Specify exact target version to ensure pip installs the version we want
    #   rather than the last version it knows (which might be outdated due to caching)
    pip_command = [
        sys.executable, "-m", "pip", "install", "--upgrade",
        f"--extra-index-url={pip_index_url}",
        f"{package_name}[{extras}]=={target_version}"
    ]

    # Add --pre flag if prerelease versions should be included
    if include_prerelease_versions():
        pip_command.insert(-1, "--pre")  # Insert before the package name
        logger.debug("Including prerelease versions in upgrade")

    try:
        # Execute pip command (mask token in logs if present)
        log_command = ' '.join(pip_command)
        if requires_authentication():
            try:
                _, token = get_repository_credentials_if_required()
                if token:
                    log_command = log_command.replace(token, '****')
            except ValueError:
                pass  # If credentials can't be retrieved, just log without masking

        logger.info(f"Executing upgrade command: {log_command}")

        result = subprocess.run(
            pip_command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace"
        )

        if result.returncode == 0:
            # Verify the installed version matches what we expected
            installed_version = None

            # Try to get the installed version using pip show
            try:
                pip_show_command = [sys.executable, "-m", "pip", "show", package_name]

                pip_show_result = subprocess.run(
                    pip_show_command,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace"
                )

                if pip_show_result.returncode == 0:
                    # Parse the output to find the version
                    show_output = pip_show_result.stdout or ""

                    for line in show_output.splitlines():
                        if line.startswith("Version:"):
                            installed_version = line.split(":", 1)[1].strip()
                            break
            except Exception as e:
                logger.warning(f"Could not get installed version: {e}")

            # If we found the installed version and it matches the target version
            if installed_version and installed_version == target_version:
                return {
                    "success": True,
                    "message": f"Successfully upgraded from {current_version} to {target_version}",
                    "old_version": current_version,
                    "new_version": target_version
                }
            # If we found the installed version but it doesn't match the target version
            elif installed_version and installed_version != target_version:
                logger.warning(f"Installed version ({installed_version}) doesn't match target version ({target_version})")
                return {
                    "success": True,
                    "message": f"Upgraded from {current_version} to {installed_version} (expected {target_version})",
                    "old_version": current_version,
                    "new_version": installed_version,
                    "expected_version": target_version,
                    "warning": "Installed version doesn't match expected version"
                }
            # If we couldn't determine the installed version
            else:
                logger.error("Could not determine installed version after upgrade")
                return {
                    "success": False,
                    "message": "Upgrade may have completed but could not verify installed version. Please check manually.",
                    "error_type": "verification_failed",
                    "old_version": current_version,
                    "expected_version": target_version
                }
        else:
            logger.error(f"Error during upgrade: {result.stderr}")
            return {
                "success": False,
                "message": f"Error during upgrade: {result.stderr}",
                "error_type": "pip_error",
                "error_details": result.stderr
            }
    except Exception as e:
        logger.exception(f"Exception during upgrade: {e}")
        return {
            "success": False,
            "message": f"Error executing upgrade: {e}",
            "error_type": "exception",
            "error_details": str(e)
        }


def execute_upgrade_with_backup(include_dirs: Optional[List[str]] = None) -> Dict[str, Any]:
    """
    Execute the upgrade process with backup and restore capability.
    Args:
        include_dirs: Optional list of additional directories to include in the backup
    Returns:
        dict: Dictionary containing success status, result message, and other relevant information
    """
    # Step 1: Create a backup before upgrading
    logger.info("Creating backup before upgrade")
    backup_result = create_backup(include_dirs)

    if not backup_result["success"]:
        return {
            "success": False,
            "message": "Failed to create backup before upgrade",
            "error_type": "backup_failed",
            "error_details": backup_result.get("error", "Unknown error during backup")
        }

    logger.info(f"Backup created successfully at {backup_result['backup_dir']}")

    # Step 2: Execute the upgrade
    logger.info("Executing upgrade")
    upgrade_result = execute_upgrade()

    # If no update is needed, return the result directly without verification
    if upgrade_result["success"] and "Already at the latest version" in upgrade_result.get("message", ""):
        logger.info("No update needed, skipping verification")
        return {
            "success": True,
            "message": upgrade_result["message"],
            "old_version": upgrade_result.get("old_version", "unknown"),
            "new_version": upgrade_result.get("new_version", "unknown"),
            "backup_dir": backup_result["backup_dir"],
            "verification": "skipped"
        }

    # Step 3: If upgrade fails, restore from backup
    if not upgrade_result["success"]:
        logger.warning("Upgrade failed, restoring from backup")

        # Get the backup directory from the backup result
        backup_dir = os.path.basename(backup_result["backup_dir"])

        # Restore from the backup we just created
        restore_result = restore_from_backup(backup_dir)

        if restore_result["success"]:
            return {
                "success": False,
                "message": f"Upgrade failed but system was restored from backup. Error: {upgrade_result['message']}",
                "error_type": upgrade_result.get("error_type", "unknown"),
                "error_details": upgrade_result.get("error_details", ""),
                "restored": True,
                "backup_dir": backup_result["backup_dir"]
            }
        else:
            return {
                "success": False,
                "message": f"Upgrade failed and restore from backup also failed. System may be in an inconsistent state.",
                "error_type": "upgrade_and_restore_failed",
                "error_details": f"Upgrade error: {upgrade_result.get('error_details', '')}, Restore error: {restore_result.get('error', '')}",
                "restored": False,
                "backup_dir": backup_result["backup_dir"]
            }

    # Step 4: If upgrade succeeds, verify the upgrade
    logger.info("Verifying upgrade")
    expected_version = upgrade_result.get("new_version")
    verification_result = verify_upgrade(expected_version)

    # Step 5: If verification fails, restore from backup
    if not verification_result["success"]:
        logger.warning("Verification failed, restoring from backup")

        # Get the backup directory from the backup result
        backup_dir = os.path.basename(backup_result["backup_dir"])

        # Restore from the backup we just created
        restore_result = restore_from_backup(backup_dir)

        if restore_result["success"]:
            return {
                "success": False,
                "message": f"Upgrade succeeded but verification failed. System was restored from backup. Verification error: {verification_result['message']}",
                "error_type": "verification_failed",
                "error_details": verification_result.get("message", ""),
                "restored": True,
                "backup_dir": backup_result["backup_dir"]
            }
        else:
            return {
                "success": False,
                "message": f"Upgrade succeeded but verification failed. Restore from backup also failed. System may be in an inconsistent state.",
                "error_type": "verification_and_restore_failed",
                "error_details": f"Verification error: {verification_result.get('message', '')}, Restore error: {restore_result.get('error', '')}",
                "restored": False,
                "backup_dir": backup_result["backup_dir"]
            }

    # Step 6: If upgrade and verification succeed, return success
    return {
        "success": True,
        "message": f"{upgrade_result['message']}",
        "old_version": upgrade_result.get("old_version", "unknown"),
        "new_version": upgrade_result.get("new_version", "unknown"),
        "backup_dir": backup_result["backup_dir"],
        "verification": "passed"
    }
