"""Upgrade verification utilities.

Provides functions to verify an installed upgrade by importing critical
modules in a fresh subprocess and performing lightweight attribute checks.
"""
import sys
import subprocess
import importlib
from typing import Dict, Any, Optional, Tuple, List

from loguru import logger


def verify_in_subprocess(command: Optional[str] = None) -> Dict[str, Any]:
    """
    Verify the upgrade by running a verification subprocess.

    This ensures we're testing the newly installed code, not the code
    currently loaded in memory.

    Returns:
        Dict: Result of the verification
    """
    # Create a command to run the verification module directly
    # This will import the module in a new process, ensuring we're
    # testing the newly installed code
    if command is None:
        command = [
            sys.executable,
            "-c",
            "import sys; "
            "from coda_core.config.upgrade.verification import run_verification_checks; "
            "success, message, version = run_verification_checks(); "
            "print(f'VERSION: {version}'); "
            "print(message); "
            "sys.exit(0 if success else 1)"
        ]

    try:
        # Run the command in a subprocess
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            shell=isinstance(command, str),
            encoding="utf-8",
            errors="replace"
        )

        # Parse the output
        output = (result.stdout or "").strip()
        success = result.returncode == 0

        # Extract version from output
        version = "unknown"
        for line in output.splitlines():
            if line.startswith("VERSION:"):
                version = line.replace("VERSION:", "").strip()
                break

        return {
            "success": success,
            "message": output,
            "version": version
        }
    except Exception as e:
        logger.error(f"Error running verification subprocess: {e}")
        return {
            "success": False,
            "message": f"Error running verification subprocess: {e}",
            "version": "unknown"
        }


def run_verification_checks(modules: Optional[List[str]] = None, required_attributes: Optional[Dict[str, List[str]]] = None) -> Tuple[bool, str, str]:
    """
    Run verification checks to ensure the application is functioning correctly.
    
    This function is meant to be called in a separate process from the
    verify_in_subprocess function.
    
    Returns:
        Tuple[bool, str, str]: (success, message, version)
    """
    success = True
    messages = []
    version = "unknown"
    
    # Use provided modules or default to critical modules
    if modules is None:
        modules = [
            "coda_core",
            "coda_core.config",
            "coda_core.core",
            "coda_core.core.agents",
            "coda_core.core.models",
            "coda_core.core.session",
            "coda_core.core.tools"
    ]

    for module_name in modules:
        try:
            __import__(module_name)
            messages.append(f"Successfully imported {module_name}")
        except ImportError as e:
            success = False
            messages.append(f"Failed to import {module_name}: {e}")

    # Check 2: Verify that critical classes exist or check required attributes
    if required_attributes:
        for module_name, attributes in required_attributes.items():
            try:
                module = importlib.import_module(module_name)
                for attr in attributes:
                    if not hasattr(module, attr):
                        success = False
                        messages.append(f"Module {module_name} missing required attribute: {attr}")
                    else:
                        messages.append(f"Module {module_name} has required attribute: {attr}")
            except ImportError as e:
                success = False
                messages.append(f"Failed to import module {module_name} for attribute check: {e}")
    else:
        try:
            from coda_core.core.agents.single_agent import SingleAgent
            from coda_core.core.session.session import Session
            # Reference the imported symbols so pylint doesn't flag them as unused.
            _ = (SingleAgent, Session)
            messages.append("Successfully imported critical classes")
        except ImportError as e:
            success = False
            messages.append(f"Failed to import critical classes: {e}")

    # Check 3: Verify that the application can be initialized
    try:
        from coda_core.config.settings import SETTINGS
        # Access SETTINGS (assign to _) so the import is considered used and initialization occurs.
        _ = SETTINGS 
        messages.append("Successfully initialized settings")
    except Exception as e:
        success = False
        messages.append(f"Failed to initialize settings: {e}")

    # Check 4: Get the current version
    try:
        from coda_core.config.upgrade.version import get_current_version
        version = get_current_version()
        messages.append(f"Current version: {version}")
    except Exception as e:
        success = False
        messages.append(f"Failed to get current version: {e}")

    # Compile the final message
    final_message = "\n".join(messages)

    return success, final_message, version


def verify_upgrade(expected_version: Optional[str] = None) -> Dict[str, Any]:
    """
    Verify that the upgrade was successful.
    
    Args:
        expected_version: The expected version after upgrade
        
    Returns:
        Dict: Result of the verification
    """
    # Run verification in subprocess
    verification_result = verify_in_subprocess()

    # If verification failed, return the result
    if not verification_result["success"]:
        return verification_result

    # Run additional checks if needed
    success, message, version = run_verification_checks()

    # If checks failed, return failure
    if not success:
        return {
            "success": False,
            "message": message,
            "version": version
        }

    # If expected_version is provided, check if it matches
    if expected_version is not None:
        current_version = verification_result["version"]

        if current_version != expected_version:
            return {
                "success": False,
                "message": f"Version mismatch: expected {expected_version}, got {current_version}",
                "version": current_version,
                "expected_version": expected_version
            }

    # All checks passed
    return verification_result

# Run the verification checks
if __name__ == "__main__":
    success, message, version = run_verification_checks()
    print(f"VERSION: {version}")
    print(message)
    sys.exit(0 if success else 1)
