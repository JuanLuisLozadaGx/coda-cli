"""Backup and restore utilities for the upgrade workflow.

Creates timestamped backups of installed packages plus user config/state and
restores them if an upgrade fails. Intentionally keeps logic here side-effect
driven (filesystem) and free of higher-level orchestration concerns.
"""
import os
import shutil
import tempfile
import json
import time
import sys
import inspect
import warnings
import importlib
import importlib.util
from typing import Dict, List, Optional, Any

# Suppress pkg_resources deprecation warning BEFORE importing pkg_resources so it takes effect.
warnings.filterwarnings("ignore", category=DeprecationWarning, message="pkg_resources is deprecated.*")

# pylint: disable=wrong-import-position
import pkg_resources  # Needs to come after the warning suppression
from loguru import logger
from coda_core.config.upgrade.version import get_current_version
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.config.upgrade.constants import TOP_LEVEL_PACKAGE_CODA_CORE, TOP_LEVEL_PACKAGES_TO_BACKUP
# pylint: enable=wrong-import-position


def create_backup_manifest(backup_dir: str, paths: List[str]) -> Dict[str, Any]:
    """
    Create a manifest file for the backup. This includes the timestamp, date, and version of the files.
    
    Args:
        backup_dir: The directory where the backup is stored
        paths: List of file and directory paths included in the backup
        
    Returns:
        Dict: The manifest data
    """
    manifest = {
        "timestamp": time.time(),
        "date": time.strftime("%Y-%m-%d %H:%M:%S"),
        "version": get_current_version(), # Determine version (get_current_version already returns "unknown" on failure)

        "paths": paths,
    }

    # Write manifest to file - each backup has its own manifest
    manifest_path = os.path.join(backup_dir, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    return manifest



def get_package_location(package_name: str) -> str:
    """
    Determine the location of a package using multiple methods.
    
    This function tries several methods to find the package location,
    which is useful for different installation types (pip, editable, etc.)
    
    Returns:
        str: The path to the package
        
    Raises:
        ValueError: If the package location cannot be determined
    """
    logger.info(f"Getting package location for: {package_name}")
    try:
        # Import the package dynamically
        try:
            module = importlib.import_module(package_name)
        except Exception as e:
            raise ValueError(f"Could not locate {package_name} package: {e}") from e

        # Try different methods to find the package location
        package_location = None

        # Method 1: Try using __file__
        if hasattr(module, '__file__') and module.__file__ is not None:
            package_location = os.path.dirname(module.__file__)
            logger.info(f"Found {package_name} using __file__ at {package_location}")

        # Method 2: Try using inspect
        if package_location is None:
            try:
                package_location = os.path.dirname(inspect.getfile(module))
                logger.info(f"Found {package_name} using inspect at {package_location}")
            except (TypeError, ValueError) as e:
                logger.warning(f"Could not determine {package_name} location using inspect: {e}")

        # Method 3: Try using sys.modules
        if package_location is None:
            try:
                module_path = sys.modules[package_name].__path__[0]
                package_location = module_path
                logger.info(f"Found {package_name} using sys.modules at {package_location}")
            except (AttributeError, IndexError, KeyError) as e:
                logger.warning(f"Could not determine {package_name} location using sys.modules: {e}")

        # Method 4: Try using pkg_resources
        if package_location is None:
            try:
                package_location = pkg_resources.resource_filename(package_name, '')
                logger.info(f"Found {package_name} using pkg_resources at {package_location}")
            except (ImportError, pkg_resources.DistributionNotFound) as e:
                logger.warning(f"Could not determine {package_name} location using pkg_resources: {e}")

        # Method 5: Try using importlib
        if package_location is None:
            try:
                spec = importlib.util.find_spec(package_name)
                if spec is not None and spec.origin is not None:
                    # If origin is a file (like __init__.py), get its directory
                    if os.path.isfile(spec.origin):
                        package_location = os.path.dirname(spec.origin)
                    else:
                        package_location = spec.origin
                    logger.info(f"Found {package_name} using importlib at {package_location}")
            except (ImportError, AttributeError) as e:
                logger.warning(f"Could not determine {package_name} location using importlib: {e}")

        # If all methods failed, raise an exception
        if package_location is None:
            raise ValueError(f"Could not determine {package_name} package location using any method")

        logger.info(f"Found {package_name} at {package_location}")
        return package_location

    except Exception as e:
        logger.error(f"Could not determine package location for {package_name}: {e}")
        raise ValueError(f"Could not locate {package_name} package: {e}") from e


def _default_package_names() -> List[str]:
    """Heuristic default package names that may be part of the meta-package.

    Returns a list that we will attempt to back up, skipping any that are not installed.
    """
    # Use the canonical list from constants. This will include the
    # top-level packages we want to attempt to back up (e.g. coda_core,
    # coda_cli).
    candidates = list(TOP_LEVEL_PACKAGES_TO_BACKUP)
    # Only include those that can be imported
    result: List[str] = []
    for name in candidates:
        try:
            if importlib.util.find_spec(name) is not None:
                result.append(name)
        except Exception:
            # Ignore any import errors here; we'll handle missing ones later.
            pass
    # Ensure at least the core top-level package is attempted even if not currently importable
    if TOP_LEVEL_PACKAGE_CODA_CORE not in result:
        result.append(TOP_LEVEL_PACKAGE_CODA_CORE)
    return result


def create_backup(include_dirs: Optional[List[str]] = None, package_names: Optional[List[str]] = None) -> Dict[str, Any]:
    """
    Create a backup of the current coda installation.
    
    Args:
        include_dirs: Optional list of additional directories to include in the backup
        package_names: Optional list of top-level package names to back up. Missing ones are skipped.
        
    Returns:
        Dict with the following keys:
            - success (bool): Whether the backup was successful
            - backup_dir (str): The directory where the backup was created
            - timestamp (float): Unix timestamp of when the backup was created
            - version (str): Version of the backed up package
            - paths_backed_up (int): Number of paths (files/directories) backed up
            - error (str, optional): Error message if backup failed
    """
    try:
        # Get the backup directory from settings
        backup_root = SETTINGS.get_env_var(EnvConfig.CODA_UPGRADE_BACKUP_DIR)

        # Create a timestamped directory for this backup
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        backup_dir = os.path.join(backup_root, f"{timestamp}_backup")
        os.makedirs(backup_dir, exist_ok=True)

        logger.info(f"Creating backup in {backup_dir}")

        # Determine what to back up
        # 1. The packages themselves (site-packages locations)
        package_names = package_names or _default_package_names()
        package_locations: Dict[str, str] = {}
        for name in package_names:
            logger.info(f"Attempting to get location for package: {name}")
            try:
                loc = get_package_location(name)
                package_locations[name] = loc
            except ValueError as e:
                logger.warning(str(e))

        # If no packages could be located, this is a critical failure
        if not package_locations:
            return {
                "success": False,
                "error": "Could not locate any packages to back up. Backup cannot proceed.",
                "backup_dir": backup_dir
            }

        # 2. Configuration files
        coda_dir = SETTINGS.coda_dir

        # List of config files to back up
        config_locations = []

        # Add specific files from the .coda directory
        try:
            for item in os.listdir(coda_dir):
                item_path = os.path.join(coda_dir, item)

                # Skip the .backups directory
                if item_path == backup_root:
                    continue

                config_locations.append(item_path)
        except OSError as e:
            logger.error(f"Error listing config directory {coda_dir}: {e}")
            return {
                "success": False,
                "error": f"Failed to list config directory: {e}",
                "backup_dir": backup_dir
            }

        # Add any additional directories
        if include_dirs:
            for dir_path in include_dirs:
                config_locations.append(dir_path)

        # Collect all files to back up
        backed_up_paths = []
        backup_errors = []

        # Back up the packages
        packages_backup_dir = os.path.join(backup_dir, "packages")
        try:
            os.makedirs(packages_backup_dir, exist_ok=True)
        except OSError as e:
            logger.error(f"Failed to create packages backup directory: {e}")
            return {
                "success": False,
                "error": f"Failed to create packages backup directory: {e}",
                "backup_dir": backup_dir
            }

        for pkg_name, pkg_src in package_locations.items():
            try:
                package_dest = os.path.join(packages_backup_dir, pkg_name)
                shutil.copytree(pkg_src, package_dest, dirs_exist_ok=True)
                backed_up_paths.append(pkg_src)
                logger.info(f"Backed up package {pkg_name} from {pkg_src}")
            except Exception as e:
                error_msg = f"Error backing up package {pkg_name}: {e}"
                logger.error(error_msg)
                backup_errors.append(error_msg)

        # Back up config files
        config_backup_dir = os.path.join(backup_dir, "config")
        try:
            os.makedirs(config_backup_dir, exist_ok=True)
        except OSError as e:
            logger.error(f"Failed to create config backup directory: {e}")
            return {
                "success": False,
                "error": f"Failed to create config backup directory: {e}",
                "backup_dir": backup_dir
            }

        for config_loc in config_locations:
            if os.path.exists(config_loc):
                try:
                    if os.path.isdir(config_loc):
                        dest_dir = os.path.join(config_backup_dir, os.path.basename(config_loc))
                        shutil.copytree(config_loc, dest_dir, dirs_exist_ok=True)
                    else:
                        shutil.copy2(config_loc, config_backup_dir)
                    backed_up_paths.append(config_loc)
                except Exception as e:
                    error_msg = f"Error backing up config {config_loc}: {e}"
                    logger.error(error_msg)
                    backup_errors.append(error_msg)

        # Create manifest
        try:
            manifest = create_backup_manifest(backup_dir, backed_up_paths)
        except Exception as e:
            logger.error(f"Failed to create backup manifest: {e}")
            return {
                "success": False,
                "error": f"Failed to create backup manifest: {e}",
                "backup_dir": backup_dir
            }

        # Determine overall success
        if backup_errors:
            logger.warning(f"Backup completed with {len(backup_errors)} errors")
            return {
                "success": False,
                "error": f"Backup completed with errors: {'; '.join(backup_errors)}",
                "backup_dir": backup_dir,
                "timestamp": manifest["timestamp"],
                "version": manifest["version"],
                "paths_backed_up": len(backed_up_paths)
            }

        return {
            "success": True,
            "backup_dir": backup_dir,
            "timestamp": manifest["timestamp"],
            "version": manifest["version"],
            "paths_backed_up": len(backed_up_paths)
        }

    except Exception as e:
        logger.error(f"Unexpected error during backup creation: {e}")
        return {
            "success": False,
            "error": f"Unexpected error during backup: {e}"
        }


def list_backups() -> List[Dict[str, Any]]:
    """
    List all available backups.
    
    Returns:
        List[Dict]: Information about each backup
    """
    backup_root = SETTINGS.get_env_var(EnvConfig.CODA_UPGRADE_BACKUP_DIR)
    backups = []

    if not os.path.exists(backup_root):
        return backups

    for item in os.listdir(backup_root):
        item_path = os.path.join(backup_root, item)
        # Look for directories that end with "_backup" (format: timestamp_backup)
        if os.path.isdir(item_path) and item.endswith("_backup"):
            manifest_path = os.path.join(item_path, "manifest.json")
            if os.path.exists(manifest_path):
                try:
                    with open(manifest_path, "r", encoding="utf-8") as f:
                        manifest = json.load(f)

                    backups.append({
                        "directory": item_path,
                        "date": manifest.get("date", "Unknown"),
                        "version": manifest.get("version", "Unknown"),
                        "files": len(manifest.get("paths", [])) if "paths" in manifest else len(manifest.get("files", []))
                    })
                except Exception as e:
                    logger.error(f"Error reading manifest {manifest_path}: {e}")

    # Sort by date (newest first)
    backups.sort(key=lambda x: x["date"], reverse=True)

    return backups


def restore_from_backup(backup_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Restore coda from a backup.
    
    Args:
        backup_id: The backup ID (directory name) to restore from. If None, uses the most recent backup.
        
    Returns:
        Dict: Result of the restore operation
    """
    backups = list_backups()

    if not backups:
        return {"success": False, "error": "No backups found"}

    # Determine which backup to use
    if backup_id:
        selected_backup = next((b for b in backups if os.path.basename(b["directory"]) == backup_id), None)
        if not selected_backup:
            return {"success": False, "error": f"Backup {backup_id} not found"}
    else:
        # Use the most recent backup
        selected_backup = backups[0]

    backup_dir = selected_backup["directory"]
    logger.info(f"Restoring from backup: {backup_dir}")

    # Load the manifest
    manifest_path = os.path.join(backup_dir, "manifest.json")
    try:
        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = json.load(f)
    except Exception as e:
        return {"success": False, "error": f"Error reading manifest: {e}"}

    # Restore package files
    packages_backup_dir = os.path.join(backup_dir, "packages")
    if os.path.exists(packages_backup_dir):
        # Determine which packages were backed up (subdirectories under packages)
        backed_up_packages = [name for name in os.listdir(packages_backup_dir) if os.path.isdir(os.path.join(packages_backup_dir, name))]
        if not backed_up_packages:
            logger.info("No packages found to restore in backup")
        else:
            # Create a single temp dir to hold original copies for rollback
            temp_dir = tempfile.mkdtemp(prefix="coda_restore_")
            logger.info(f"Creating temporary backup in {temp_dir} before restore")
            rollback_needed = False
            try:
                # First, copy current installed packages to temp
                pkg_locations: Dict[str, str] = {}
                for pkg_name in backed_up_packages:
                    try:
                        loc = get_package_location(pkg_name)
                        pkg_locations[pkg_name] = loc
                        temp_pkg_dir = os.path.join(temp_dir, pkg_name)
                        shutil.copytree(loc, temp_pkg_dir, dirs_exist_ok=True)
                    except ValueError:
                        # Package not installed currently; skip temp backup, we'll just restore if desired path can be determined later
                        logger.warning(f"Package {pkg_name} not currently installed; will attempt to restore if possible.")
                    except Exception as e:
                        logger.error(f"Error backing up current {pkg_name} before restore: {e}")

                # Now restore from backup for each package
                for pkg_name in backed_up_packages:
                    src = os.path.join(packages_backup_dir, pkg_name)
                    try:
                        if pkg_name in pkg_locations:
                            dest = pkg_locations[pkg_name]
                            shutil.rmtree(dest, ignore_errors=True)
                            shutil.copytree(src, dest, dirs_exist_ok=True)
                            logger.info(f"Restored package {pkg_name} -> {dest}")
                        else:
                            # If package wasn't importable, we can't determine the install path. Skip with warning.
                            logger.warning(f"Skipping restore for {pkg_name}: not installed in current environment")
                    except Exception as e:
                        rollback_needed = True
                        logger.error(f"Error restoring package {pkg_name}: {e}")
                        break

                if rollback_needed:
                    # Attempt rollback for packages we touched
                    for pkg_name, dest in pkg_locations.items():
                        try:
                            temp_pkg_dir = os.path.join(temp_dir, pkg_name)
                            if os.path.exists(temp_pkg_dir):
                                shutil.rmtree(dest, ignore_errors=True)
                                shutil.copytree(temp_pkg_dir, dest, dirs_exist_ok=True)
                                logger.info(f"Rolled back package {pkg_name} after failed restore")
                        except Exception as rollback_error:
                            logger.error(f"Error rolling back {pkg_name}: {rollback_error}")
                    return {"success": False, "error": "Error restoring one or more packages; attempted rollback"}
            finally:
                try:
                    shutil.rmtree(temp_dir)
                except Exception as cleanup_error:
                    logger.error(f"Error cleaning up temp directory: {cleanup_error}")

    # Restore config files
    config_backup_dir = os.path.join(backup_dir, "config")
    if os.path.exists(config_backup_dir):
        backup_root = SETTINGS.get_env_var(EnvConfig.CODA_UPGRADE_BACKUP_DIR)
        backup_dir_name = os.path.basename(backup_root)

        for config_item in os.listdir(config_backup_dir):
            # Skip restoring the backup directory to avoid recursive backups
            if config_item == backup_dir_name:
                continue

            config_item_path = os.path.join(config_backup_dir, config_item)
            target_path = os.path.join(SETTINGS.coda_dir, config_item)
            try:
                if os.path.isdir(config_item_path):
                    os.makedirs(os.path.dirname(target_path), exist_ok=True)
                    shutil.copytree(config_item_path, target_path, dirs_exist_ok=True)
                else:
                    os.makedirs(os.path.dirname(target_path), exist_ok=True)
                    shutil.copy2(config_item_path, target_path)
                logger.info(f"Restored config: {config_item_path} -> {target_path}")
            except Exception as e:
                logger.error(f"Error restoring config {config_item_path}: {e}")

    return {
        "success": True,
        "backup_dir": backup_dir,
        "date": manifest.get("date", "Unknown"),
        "version": manifest.get("version", "Unknown"),
        "files_restored": len(manifest.get("paths", [])) if "paths" in manifest else len(manifest.get("files", []))
    }
