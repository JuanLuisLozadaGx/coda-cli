"""Repository interaction utilities for managing package upgrade metadata.

Handles repository URL construction, credential retrieval/validation, and
remote version discovery logic used during upgrade checks.
"""
import subprocess
import sys
import re
from typing import Tuple, Dict, Any, Optional
from enum import Enum

import requests
from requests.auth import HTTPBasicAuth
from loguru import logger

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.config.upgrade.version import get_current_version, compare_versions
from coda_core.config.upgrade.constants import UPGRADABLE_PACKAGE_DISTRIBUTION_NAME

from coda_core.config.upgrade.utils import is_azure_devops_url, is_azure_devops_host


class CredentialStatus(Enum):
    """Enumeration describing the state of repository credentials."""
    NOT_REQUIRED = "not_required"
    MISSING = "missing"
    INVALID = "invalid"
    VALID = "valid"


def get_repository_url() -> str:
    """
    Get the repository URL. First check for a full URL, then fallback to constructing
    from individual components (Azure DevOps format).
    
    Returns:
        str: The repository URL

    Raises:
        ValueError: If repository configuration is incomplete
    """
    # First, check if a full repository URL is provided
    repo_url = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_URL)

    if repo_url:
        # Validate URL format
        if not repo_url.startswith(('http://', 'https://')):
            raise ValueError(f"Repository URL must start with http:// or https://: {repo_url}")

        # Ensure URL ends with trailing slash for consistency
        if not repo_url.endswith('/'):
            repo_url = repo_url + '/'

        logger.debug(f"Using configured repository URL: {repo_url}")
        return repo_url

    # Fallback to constructing Azure DevOps URL from components
    logger.debug("No repository URL configured, constructing from components")

    repo_host = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_HOST)
    repo_org = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_ORG)
    repo_project = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_PROJECT)
    repo_feed = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_FEED)

    # Check if any of the required settings are missing
    if not repo_host or not repo_org or not repo_project or not repo_feed:
        logger.error("Missing repository configuration")
        raise ValueError("Missing repository configuration")

    constructed_url = f"https://{repo_host}/{repo_org}/{repo_project}/_packaging/{repo_feed}/pypi/simple/"
    logger.debug(f"Constructed repository URL: {constructed_url}")

    return constructed_url


def requires_authentication() -> bool:
    """
    Check if the repository requires authentication.
    
    Returns True if either username or token is configured, indicating that
    authentication should be used.

    Returns:
        bool: True if authentication is required, False otherwise
    """
    username = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_USERNAME)
    token = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_TOKEN)
    # If either username or token is provided, assume authentication is required
    auth_configured = bool(username or token)

    logger.debug(f"Authentication {'required' if auth_configured else 'not required'} for repository")
    return auth_configured


def include_prerelease_versions() -> bool:
    """
    Check if prerelease versions should be included when checking for updates.
    
    This is controlled by the CODA_PYPI_REPO_INCLUDE_PRERELEASE environment variable.
    When enabled, pip commands will include the --pre flag to consider prerelease versions.

    Returns:
        bool: True if prerelease versions should be included, False otherwise
    """

    include_pre = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_INCLUDE_PRERELEASE)
    # Convert string to boolean (default is False)
    enabled = include_pre.lower() in ('true', '1', 'yes', 'on')

    logger.debug(f"Prerelease versions {'enabled' if enabled else 'disabled'}")
    return enabled


def get_repository_credentials() -> Tuple[str, str]:
    """
    Get the repository credentials from environment variables.
    
    Returns:
        Tuple[str, str]: Username and token

    Raises:
        ValueError: If any of the required credentials are missing when authentication is required
    """
    username = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_USERNAME)
    token = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_TOKEN)
    # Check if any of the required credentials are missing
    if not username or not token:
        logger.error("Missing repository credentials")
        raise ValueError("Missing repository credentials")
    return username, token


def get_repository_credentials_if_required() -> Tuple[str, str]:
    """
    Get repository credentials only if authentication is required.
    
    Returns:
        Tuple[str, str]: Username and token, or empty strings if no authentication is required

    Raises:
        ValueError: If credentials are required but missing
    """
    if not requires_authentication():
        logger.debug("No authentication required, returning empty credentials")
        return "", ""
    return get_repository_credentials()


def validate_credentials(username: Optional[str] = None, token: Optional[str] = None, package_name: str = UPGRADABLE_PACKAGE_DISTRIBUTION_NAME) -> bool:
    """Validate repository credentials by exercising the package index.

    Performs an HTTP GET against the repository index for ``package_name``
    (appends ``{package_name}/`` to the repository URL). If the package
    path returns 404 the function will fall back to checking the repository
    root. A 10-second timeout is used for requests. If credentials are not
    provided and the repository requires authentication, configured
    credentials will be used when available.

    Args:
        username (Optional[str]): Optional username to use for validation. If
            omitted and authentication is required, configured credentials
            will be used.
        token (Optional[str]): Optional token/password paired with ``username``.
        package_name (str): Distribution name appended to the repository URL
            (default: PACKAGE_NAME).

    Returns:
        bool: True if the repository accepted the request (status 200),
            False if credentials are missing/invalid or an error occurred.
    """
    def _evaluate_response(response: requests.Response, context: str = "") -> bool:
        """Helper function to evaluate HTTP response status codes."""
        if response.status_code == 200:
            logger.info(f"Repository credentials validated successfully{context}")
            return True
        elif response.status_code == 401:
            logger.warning("Repository credentials are invalid (401 Unauthorized)")
            return False
        elif response.status_code == 403:
            logger.warning("Repository access forbidden (403 Forbidden)")
            return False
        else:
            logger.warning(f"Repository validation failed with status code: {response.status_code}")
            return False
    try:
        # Get the repository URL and append the package path
        repo_url = get_repository_url() + f"{package_name}/"
        # Prepare authentication if credentials are provided
        auth = None
        if username and token:
            auth = HTTPBasicAuth(username, token)
            logger.debug(f"Validating repository with provided credentials: {username}")
        elif requires_authentication():
            # Use configured credentials
            try:
                config_username, config_token = get_repository_credentials()
                auth = HTTPBasicAuth(config_username, config_token)
                logger.debug(f"Validating repository with configured credentials: {config_username}")
            except ValueError:
                logger.warning("Repository requires authentication but credentials are missing")
                return False
        else:
            logger.debug("Validating repository without authentication")
        # Make HTTP request to package URL with 10s timeout
        # Allow redirects (default behavior, but made explicit)
        logger.debug(f"Making HTTP request to repository: {repo_url}")
        response = requests.get(repo_url, auth=auth, timeout=10, allow_redirects=True)
        if response.status_code == 404:
            # Package doesn't exist - try repository root to validate credentials
            logger.debug("Package not found, validating credentials against repository root")
            root_url = get_repository_url()
            logger.debug(f"Making HTTP request to repository root: {root_url}")
            root_response = requests.get(root_url, auth=auth, timeout=10, allow_redirects=True)
            return _evaluate_response(root_response, " (package does not exist)")
        else:
            return _evaluate_response(response)
    except requests.exceptions.Timeout:
        logger.error("Timeout validating repository credentials (10s)")
        return False
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error validating repository credentials: {e}")
        return False

    except Exception as e:
        logger.error(f"Unexpected error validating repository credentials: {e}")
        return False


def _prompt_for_credentials() -> Tuple[str, str]:
    """
    Prompt the user for repository credentials without saving them.
    
    This function is meant to be called from the CLI, not from within the upgrade module.
    Credentials should be validated and saved using prompt_for_credentials_and_validate().
    
    Returns:
        Tuple[str, str]: Username and token
    """
    # The CLI is responsible for user interaction
    username = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_USERNAME)
    if not username:
        username = input("Enter repository username: ")
    token = input("Enter repository token: ")
    return username, token

def prompt_for_credentials_and_validate() -> Tuple[str, str, CredentialStatus]:
    """
    Prompt the user for repository credentials, validate them, and save if valid.
    
    Returns:
        Tuple[str, str, CredentialStatus]: Username, token, and credential status
    """
    try:
        # Prompt for credentials
        username, token = _prompt_for_credentials()
        # Validate the credentials
        is_valid = validate_credentials(username, token)
        if is_valid:
            # Save validated credentials
            save_repository_credentials(username, token)
            logger.info("Credentials validated and saved successfully")
            return username, token, CredentialStatus.VALID
        else:
            logger.warning("Credentials validation failed")
            return username, token, CredentialStatus.INVALID

    except Exception as e:
        logger.error(f"Error during credential prompt and validation: {e}")
        return "", "", CredentialStatus.INVALID
def check_for_updates(skip_validation: bool = False, package_name: str = UPGRADABLE_PACKAGE_DISTRIBUTION_NAME) -> Dict[str, Any]:
    """Check whether a newer distribution version is available.

    Queries the configured package repository (authenticated or public)
    for available versions of ``package_name``, compares the latest
    available version with the currently installed version, and
    returns a structured result describing whether an update exists.

    Args:
        skip_validation (bool): If True, skip validating repository
            credentials before checking for updates (default: False).
        package_name (str): Distribution name to check (default: PACKAGE_NAME).

    Returns:
        Dict[str, Any]: Mapping containing the following keys:
            - 'update_available' (bool): True if an update is available.
            - 'current_version' (str): Currently installed version or "unknown".
            - 'latest_version' (str): Latest available version when discoverable.
            - 'credential_status' (CredentialStatus): Credential validation state.
            - 'error' (Optional[str]): Error message if an error occurred.
    """
    result = {
        'update_available': False,
        'current_version': get_current_version(),
        'credential_status': CredentialStatus.NOT_REQUIRED,
        'error': None
    }
    try:
        # Initialize credentials
        username, token = "", ""
        # Handle authentication requirements
        if requires_authentication():
            try:
                username, token = get_repository_credentials()
            except ValueError:
                logger.warning("Repository requires authentication but credentials are missing")
                result['credential_status'] = CredentialStatus.MISSING
                return result
            # Validate credentials before proceeding (unless skipped)
            if not skip_validation:
                if validate_credentials(username, token):
                    result['credential_status'] = CredentialStatus.VALID
                else:
                    logger.warning("Invalid repository credentials, skipping update check")
                    result['credential_status'] = CredentialStatus.INVALID
                    return result
            else:
                # When skipping validation, assume valid if credentials exist
                result['credential_status'] = CredentialStatus.VALID
        else:
            result['credential_status'] = CredentialStatus.NOT_REQUIRED
            # For public repositories, validate access without authentication (unless skipped)
            if not skip_validation and not validate_credentials():
                logger.warning("Failed to access repository without authentication")
                result['error'] = "Failed to access repository without authentication"
                return result
        # Get the pip index URL (with or without authentication embedded)
        try:
            pip_index_url = build_pip_index_url()
        except ValueError as e:
            logger.error(f"Failed to build pip index URL: {e}")
            result['error'] = f"Failed to build pip index URL: {e}"
            return result
        # Construct pip command to check available versions
        pip_command = [
            sys.executable, "-m", "pip", "index", "versions",
            f"--index-url={pip_index_url}",
            package_name
        ]
        # Add --pre flag if prerelease versions should be included
        if include_prerelease_versions():
            pip_command.insert(-1, "--pre")  # Insert before the package name
            logger.debug("Including prerelease versions in update check")
        # Execute pip command (mask token in logs if present)
        log_command = ' '.join(pip_command)
        if requires_authentication() and token:
            log_command = log_command.replace(token, '****')
        logger.info(f"Checking for available updates: {log_command}")
        try:
            result_proc = subprocess.run(
                pip_command,
                capture_output=True,
                text=True,
                timeout=60,
                encoding="utf-8",
                errors="replace"
            )
        except subprocess.TimeoutExpired:
            logger.error("Timeout occurred while checking for updates")
            result['error'] = "Timeout occurred while checking for updates"
            return result
        if result_proc.returncode == 0:
            # Parse the output to find the latest version
            output = result_proc.stdout or ""
            # The output format is typically:
            # <package-name> (1.0.0, 0.9.0, 0.8.0)
            # We want to extract the first version in the list
            version_match = re.search(rf'{package_name} \(([^,\)]+)', output)
            if version_match:
                latest_version = version_match.group(1).strip()
                result['latest_version'] = latest_version
                # Compare with current version
                current_version = result['current_version']
                if current_version != "unknown":
                    try:
                        if compare_versions(current_version, latest_version) < 0:
                            logger.info(f"Update available: {current_version} -> {latest_version}")
                            result['update_available'] = True
                        else:
                            logger.info(f"No update available. Current version: {current_version}, Latest version: {latest_version}")
                    except Exception as e:
                        logger.warning(f"Error comparing versions {current_version} and {latest_version}: {e}")
                        result['error'] = f"Error comparing versions: {e}"
                else:
                    logger.info(f"Current version unknown, latest available: {latest_version}")
            else:
                logger.warning("Could not parse latest version from pip output")
                logger.debug(f"Pip output was: {output}")
                result['error'] = "Could not parse latest version from pip output"
        else:
            error_msg = result_proc.stderr.strip() if result_proc.stderr else "Unknown error"
            logger.warning(f"Error checking for updates: {error_msg}")
            result['error'] = f"Error checking for updates: {error_msg}"

    except Exception as e:
        logger.exception(f"Unexpected error during update check: {e}")
        result['error'] = f"Unexpected error during update check: {e}"
    return result


def build_pip_index_url() -> str:
    """
    Build the pip index URL for the configured repository.
    
    Returns the appropriate URL format for pip commands, with authentication
    embedded if required.
    
    Returns:
        str: The pip index URL
        
    Raises:
        ValueError: If repository configuration is incomplete or credentials are missing when required
    """
    base_url = get_repository_url()

    if requires_authentication():
        username, token = get_repository_credentials()
        # Strip protocol for embedding credentials
        base_url_no_protocol = base_url.replace("https://", "").replace("http://", "")
        return f"https://{username}:{token}@{base_url_no_protocol}"
    else:
        return base_url


def validate_repository_access() -> bool:
    """
    Validate access to the repository.
    
    This function checks if the repository is accessible with the configured
    authentication (if required).
    
    Returns:
        bool: True if repository is accessible, False otherwise
    """
    try:
        # Get repository URL
        repo_url = get_repository_url()
        # Test access to the repository URL
        logger.debug(f"Testing repository access: {repo_url}")
        response = requests.get(repo_url, timeout=10)
        if response.status_code == 200:
            logger.info("Repository is accessible")
            return True
        else:
            logger.warning(f"Repository access test failed. Status code: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        logger.error(f"Error testing repository access: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error testing repository access: {e}")
        return False


def is_public_pypi() -> bool:
    """
    Check if the configured repository is the public PyPI.
    
    Returns:
        bool: True if using public PyPI, False otherwise
    """
    repo_url = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_URL)
    # Check common public PyPI URLs
    public_pypi_urls = [
        "https://pypi.org/simple/",
        "https://pypi.org/simple",
        "https://upload.pypi.org/legacy/",
        "https://test.pypi.org/simple/",
        "https://test.pypi.org/simple"
    ]
    if repo_url:
        # Normalize URL for comparison
        normalized_url = repo_url.rstrip('/')
        return any(normalized_url.startswith(url.rstrip('/')) for url in public_pypi_urls)

    return False


def is_azure_devops_repository() -> bool:
    """
    Check if the configured repository appears to be an Azure DevOps feed.
    
    Returns:
        bool: True if appears to be Azure DevOps, False otherwise
    """
    repo_url = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_URL)
    repo_host = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_HOST)
    return is_azure_devops_url(repo_url) or is_azure_devops_host(repo_host)


def save_repository_credentials(username: str, token: str) -> None:
    """
    Save both repository username and token to environment variables.
    
    Args:
        username: The username to save
        token: The token to save
    """
    try:
        if username:
            SETTINGS.set_env_var(EnvConfig.CODA_PYPI_REPO_USERNAME, username)
            logger.info("Repository username saved successfully")
        if token:
            SETTINGS.set_env_var(EnvConfig.CODA_PYPI_REPO_TOKEN, token)
            logger.info("Repository token saved successfully")
        if username or token:
            logger.info("Repository credentials saved successfully")
    except Exception as e:
        logger.error(f"Failed to save repository credentials: {e}")
        raise
