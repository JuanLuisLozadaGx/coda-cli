from loguru import logger
from coda_batch.core.cli import app
import typer

def main():
    """
    Main entry point for the Coda Batch CLI application.
    This function is exported at the module level for use by packaging systems.
    """
    try:
        app()
    except KeyboardInterrupt:
        logger.warning("\nProgram interrupted by user.")
        raise typer.Exit(code=130)
    except Exception as e:
        logger.exception(f"An error occurred: {e}")
        raise typer.Exit(code=1)
    finally:
        logger.info("Exiting program.")
        
if __name__ == "__main__":
    main()
