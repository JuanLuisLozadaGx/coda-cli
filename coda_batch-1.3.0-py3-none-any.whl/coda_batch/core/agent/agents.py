from typing import List, Dict, Any, Tuple
from loguru import logger

from coda_core.core.session.constants import MEMORY_KEY_MAIN

class BatchAgentCommand:
    """
    Handles agent commands in batch mode.
    
    This class provides functionality for parsing and executing agent calls
    using the @ prefix, similar to the interactive CLI's agent command.
    """
    
    def __init__(self, cli=None):
        """
        Initialize the agent command handler.
        
        Args:
            cli: The CLI instance providing access to shared state,
                 client state, and session management.
        """
        self.cli = cli
        self.agent_manager = cli.agent_manager if hasattr(cli, 'agent_manager') else None

    @staticmethod
    def _build_user_assistant_pairs(messages: List[Dict[str, Any]]) -> List[Tuple[Dict[str, Any], Dict[str, Any]]]:
        """
        Build user/assistant pairs using the last non-empty assistant response per user turn.

        This avoids selecting intermediate assistant messages that only contain tool calls
        (commonly represented with null/empty content), ensuring subagents receive the
        actual assistant answer as context.

        Args:
            messages: Conversation history from main memory.

        Returns:
            List[Tuple[Dict[str, Any], Dict[str, Any]]]: Ordered user/assistant pairs.
        """
        pairs: List[Tuple[Dict[str, Any], Dict[str, Any]]] = []
        user_indices = [
            index for index, message in enumerate(messages)
            if isinstance(message, dict) and message.get("role") == "user"
        ]

        for index, user_index in enumerate(user_indices):
            user_msg = messages[user_index]
            next_user_index = user_indices[index + 1] if index + 1 < len(user_indices) else len(messages)

            last_assistant = None
            for candidate_index in range(next_user_index - 1, user_index, -1):
                candidate = messages[candidate_index]
                if not isinstance(candidate, dict):
                    continue
                if candidate.get("role") != "assistant":
                    continue

                content = candidate.get("content")
                if content and str(content).strip():
                    last_assistant = candidate
                    break

            if last_assistant:
                pairs.append((user_msg, last_assistant))

        return pairs
    
    def handle_agent_command(self, command: str) -> str:
        """
        Process an agent command starting with @ prefix.
        
        Args:
            command: The agent command (e.g., "@agent_name args")
            
        Returns:
            str: The result of the agent command execution
        """
        response = ""
        try:
            # Parse the command to extract all agent calls
            agent_calls = self.agent_manager.parse_user_message(command)
            
            if not agent_calls:
                logger.error(f"No valid agent names found in the command: {command}")
                self.cli.tool_messages_formatter.print_error(f"No valid agent names found in the command: {command}")
                raise RuntimeError(f"No valid agent names found in the command: {command}")
            
            # Execute each agent in sequence
            for agent_call in agent_calls:
                agent_name = agent_call['agent_name']
                agent_args = agent_call['user_input']
                
                logger.info(f"Executing agent: {agent_name} with input: {agent_args}")
                
                # Execute the agent command by directly creating and interacting with the agent
                response = self._execute_agent(agent_name, agent_args)
                            
            return response
                
        except Exception as e:
            raise
    
    def _execute_agent(self, agent_name: str, agent_args: str) -> str:
        """
        Execute a single agent with the given arguments.
        
        Args:
            agent_name: Name of the agent to execute
            agent_args: Arguments to pass to the agent
            
        Returns:
            str: The result of the agent execution
        """
        try:
            # Validate agent exists
            agent_def = self.agent_manager.load_agent_metadata(agent_name)
            if not agent_def:
                logger.error(f"Agent not found: {agent_name}")
                raise RuntimeError(f"Agent not found: {agent_name}")
            
            # Get the most recent messages from memory for context
            messages = self.cli.shared_state.memories.get(MEMORY_KEY_MAIN).retrieve()
            messages_for_subagent = ""
            
            # Get the last 3 user + assistant pairs, choosing the final assistant answer per user turn.
            message_pairs = self._build_user_assistant_pairs(messages)
            
            # Take the 3 most recent pairs
            recent_pairs = message_pairs[-3:] if len(message_pairs) >= 3 else message_pairs
            
            # Format the messages
            for i, (user_msg, assistant_msg) in enumerate(recent_pairs, 1):
                user_content = user_msg.get("content", "") if isinstance(user_msg, dict) else ""
                assistant_content = assistant_msg.get("content", "") if isinstance(assistant_msg, dict) else ""
                messages_for_subagent += f"<message{i}>\n"
                messages_for_subagent += f"User: {user_content}\n"
                messages_for_subagent += f"Assistant: {assistant_content}\n"
                messages_for_subagent += f"</message{i}>\n\n"
            
            messages_for_subagent = f"Previous conversation for context:\n{messages_for_subagent}\n\nCurrent User: {agent_args}"
            
            logger.info(f"Creating subagent: {agent_name}")
            
            self.cli.tool_messages_formatter.print_agent_header(agent_name)
            
            # Create the agent using the AgentManager
            agent = self.agent_manager.create_agent(
                agent_name=agent_name, 
                memory=None,  # Use a new memory for the agent
                file_editor=self.cli.agent_handler.file_editor,
                user_defined_rules=self.cli.shared_state.user_defined_rules
            )
            
            if not agent:
                logger.error(f"Failed to configure agent: {agent_name}")
                return f"Error: Failed to configure agent: {agent_name}"
            
            # Process the request with the agent handler
            logger.info(f"Processing request with subagent: {agent_name}")
            subagent_result = self.cli.agent_handler.handle_interaction_with_agent(
                user_message=messages_for_subagent, agent=agent)
            
            # Add input and output messages to main agent memory
            main_agent_user_message = f"Subagent called {agent_name} processed this input: {agent_args}"
            self.cli.shared_state.memories.get(MEMORY_KEY_MAIN).add_user_message(main_agent_user_message)
            
            # If we have a valid response, return it and add to memory
            if subagent_result:
                if isinstance(subagent_result, dict):
                    content = subagent_result.get("content", "")
                    main_agent_assistant_message = f"Subagent called {agent_name} returned this result: {content}"
                    self.cli.shared_state.memories.get(MEMORY_KEY_MAIN).add_assistant_message(main_agent_assistant_message)
                    
                    self.cli.tool_messages_formatter.print_message(f"{agent_name} agent completed successfully")
                    
                    return content
                else:
                    if hasattr(agent, 'last_response'):
                        content = agent.last_response.get("content", "")
                        main_agent_assistant_message = f"Subagent called {agent_name} returned this result: {content}"
                        self.cli.shared_state.memories.get(MEMORY_KEY_MAIN).add_assistant_message(main_agent_assistant_message)
                        
                        self.cli.tool_messages_formatter.print_message(f"{agent_name} agent completed successfully")
                        
                        return content
            
            self.cli.shared_state.memories.get(MEMORY_KEY_MAIN).add_assistant_message(f"No response from subagent {agent_name}")
            
            self.cli.tool_messages_formatter.print_message(f"{agent_name} agent did not return a valid response")
            
            return f"No response from subagent {agent_name}"
            
        except Exception as e:
            logger.exception(f"Error executing agent {agent_name}: {e}")
            self.cli.tool_messages_formatter.print_error(f"Error executing agent {agent_name}: {e}")
            raise
