import sys
from loguru import logger
from prompt_toolkit.formatted_text import HTML

from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.core.filesystem_ops.utils import extract_file_paths
from coda_core.core.session.constants import MEMORY_KEY_MAIN
from coda_core.core.agents.single_agent import SingleAgent
from coda_core.core.metadata.metadata import extract_metadata
from coda_core.core.metadata.schemas import SessionMetadata
from coda_batch.config.constants import TOOLS_DEFAULT_LIST, TOOLS_ALL_LIST, CLIENT_NAME


class AgentHandler:
    """
    Handles all aspects of interaction with the AI agent.
    
    This class encapsulates the logic for preparing messages, managing animations,
    setting up callbacks, handling agent responses, and processing errors.
    """
    
    def __init__(self, cli=None):
        """
        Initialize the handler with a reference to the CLI context.
        
        Args:
            cli: The CLI instance providing access to shared state, 
                 client state, and session management.
        """
        self.cli = cli
        self.file_editor = None
        
        # Three-agent model for clear state management
        self.main_agent = None      # Persistent main agent (preserved across modes)
        self.mode_agent = None      # Current mode's agent (e.g., PlanningModeAgent)
        self.active_agent = None    # Points to whichever agent is currently active
        
        # State flags
        self.using_mode_agent = False    # True when mode_agent is active
        self.is_agent_executing = False  # True during agent execution (for Ctrl+C)

        # Select the agent tools to use for the main agent
        self.main_agent_tools = self._select_main_agent_tools()

        # Initialize main agent (which should exist for the whole session)
        try:
            self._initialize_main_agent()
        except Exception as e:
            logger.exception(f"Exception during agent handler initialization: {e}")
            raise RuntimeError(f"Exception during agent handler initialization: {e}")
   
    def _select_main_agent_tools(self):
        """
        Select the main agent tools to use.
        """
        if not self.cli.main_agent_tools or self.cli.main_agent_tools == "default":
            logger.info(f"Using default tools: {TOOLS_DEFAULT_LIST}")
            return TOOLS_DEFAULT_LIST
        elif self.cli.main_agent_tools == "all":
            logger.info(f"Using all available tools: {TOOLS_ALL_LIST}")
            return TOOLS_ALL_LIST
        else:
            tools_input = [tool.strip().lower() for tool in self.cli.main_agent_tools.split(",") if tool.strip()]
            
            if not tools_input:
                logger.warning("Empty tools list provided. Using default tools.")
                logger.info(f"Selected tools: {TOOLS_DEFAULT_LIST}")
                return TOOLS_DEFAULT_LIST
            
            tools_all_lower = [tool.lower() for tool in TOOLS_ALL_LIST]
            tool_name_map = {tool.lower(): tool for tool in TOOLS_ALL_LIST}
            
            filtered_tools = []
            seen_tools = set()
            invalid_tools = []
            
            for tool in tools_input:
                if tool in tools_all_lower:
                    if tool not in seen_tools:
                        filtered_tools.append(tool_name_map[tool])
                        seen_tools.add(tool)
                else:
                    invalid_tools.append(tool)
            
            if invalid_tools:
                logger.warning(f"Invalid tools ignored: {invalid_tools}")
            
            if not filtered_tools:
                logger.warning(f"No valid tools found in: {tools_input}. Using default tools.")
                logger.info(f"Selected tools: {TOOLS_DEFAULT_LIST}")
                return TOOLS_DEFAULT_LIST
            else:
                logger.info(f"Selected tools: {filtered_tools}")
                return filtered_tools

    def _initialize_main_agent(self):
        """
        Initialize or restore the main agent.
        
        This method:
        1. First checks if a main agent exists in shared_state (from previous mode switches)
        2. If not, creates a new main agent
        3. Stores the agent in both local state and shared_state for persistence
        4. Sets it as active if we're not currently using a mode agent
        """
        if not hasattr(self.cli, 'shared_state'):
            logger.info("The agent will be initialized later when shared_state is available")
            return
        
        # Create file editor if needed
        if not self.file_editor:
            self.file_editor = FileEditor()
        
        # Check if we already have a main agent in shared state
        if hasattr(self.cli.shared_state, 'main_agent') and self.cli.shared_state.main_agent is not None:
            # Restore the existing main agent
            self.main_agent = self.cli.shared_state.main_agent
            logger.info("Restored existing main agent from shared_state")
            
            # Log memory size for diagnosis
            if hasattr(self.main_agent, 'memory') and self.main_agent.memory:
                memory_size = len(self.main_agent.memory.messages) if hasattr(self.main_agent.memory, 'messages') else 0
                logger.info(f"Restored main agent memory size: {memory_size} messages")
        else:
            # Create a new main agent
            logger.info("Creating new main agent")
            
            # Log the memory state before creating agent
            memory_state = "None"
            if (hasattr(self.cli.shared_state, 'memories') and 
                MEMORY_KEY_MAIN in self.cli.shared_state.memories and 
                self.cli.shared_state.memories[MEMORY_KEY_MAIN] is not None):
                memory = self.cli.shared_state.memories[MEMORY_KEY_MAIN]
                memory_size = len(memory.messages) if hasattr(memory, 'messages') else 0
                memory_state = f"{memory_size} messages"
            logger.info(f"Creating main agent with memory state: {memory_state}")
            
            self.main_agent = self.cli.shared_state.create_configured_single_agent(
                provider_name=self.cli.shared_state.single_agent_provider_name,
                model_name=self.cli.shared_state.single_agent_model_name,
                memory=self.cli.shared_state.memories[MEMORY_KEY_MAIN],
                file_editor=self.file_editor,
                user_defined_rules=self.cli.shared_state.user_defined_rules,
                agent_tools=self.main_agent_tools
            )

            # Store in shared_state for persistence across mode switches
            self.cli.shared_state.main_agent = self.main_agent
            logger.info("Stored new main agent in shared_state")
        
        # Always ensure the main agent uses the current memory
        # This ensures that even if the agent object was preserved, it has the latest memory
        if (hasattr(self.cli, 'shared_state') and 
            hasattr(self.cli.shared_state, 'memories') and 
            MEMORY_KEY_MAIN in self.cli.shared_state.memories and 
            self.cli.shared_state.memories[MEMORY_KEY_MAIN] is not None):
            
            if hasattr(self.main_agent, 'memory') and self.main_agent.memory != self.cli.shared_state.memories[MEMORY_KEY_MAIN]:
                old_memory_size = len(self.main_agent.memory.messages) if hasattr(self.main_agent.memory, 'messages') else 0
                new_memory_size = len(self.cli.shared_state.memories[MEMORY_KEY_MAIN].messages) if hasattr(self.cli.shared_state.memories[MEMORY_KEY_MAIN], 'messages') else 0
                
                logger.info(f"Updating main agent memory reference: {old_memory_size} -> {new_memory_size} messages")
                self.main_agent.memory = self.cli.shared_state.memories[MEMORY_KEY_MAIN]
            
        # Set as active agent if we're not using a mode agent
        if not self.using_mode_agent:
            self.active_agent = self.main_agent
            logger.info("Set main agent as active")
        
        # Set the current session ID for MCP service
        try:
            if self.cli.session_manager.current_session:
                self.cli.mcp_service.set_current_session_id(self.cli.session_manager.current_session.id)
        except Exception as e:
            logger.debug(f"Could not set MCP session ID: {e}")

    def switch_to_mode_agent(self, mode_agent):
        """
        Switch to using a mode-specific agent while preserving the main agent.
        
        Args:
            mode_agent: The agent instance from the mode (e.g., PlanningModeAgent)
            
        Returns:
            bool: True if switch was successful
        """
        # Ensure main agent exists (but don't activate it)
        if not self.main_agent:
            logger.info("Main agent doesn't exist, initializing before mode switch")
            self._initialize_main_agent()
        
        # Store the mode agent
        self.mode_agent = mode_agent
        
        # Make the mode agent active
        self.active_agent = mode_agent
        self.using_mode_agent = True
        
        # Ensure main agent is preserved in shared_state
        self.cli.shared_state.main_agent = self.main_agent
        
        logger.info(f"Switched to mode agent: {type(mode_agent).__name__}")
        return True
    
    def switch_to_main_agent(self):
        """
        Switch back to the main agent from a mode agent.
        
        This method:
        1. Initializes main agent if it doesn't exist
        2. Makes it the active agent
        3. Clears the mode agent reference
        
        Returns:
            bool: True if switch was successful
        """        
        # Initialize main agent if it doesn't exist
        if not self.main_agent:
            logger.info("Main agent doesn't exist, initializing")
            self._initialize_main_agent()
        
        # Make main agent active
        self.active_agent = self.main_agent
        self.using_mode_agent = False
        
        # Clear mode agent reference
        self.mode_agent = None
        
        # Log memory state after setting active
        if self.active_agent and hasattr(self.active_agent, 'memory'):
            memory_size = len(self.active_agent.memory.messages) if self.active_agent.memory else 0
            logger.debug(f"AFTER switch, active agent memory size: {memory_size} messages")
        
        logger.info("Switched to main agent")
        return True
    
    def get_active_agent(self):
        """
        Get the currently active agent.
        If it doesn't exist, convert the main_agent to active_agent and return it.
        
        Returns:
            The active agent instance (either main_agent or mode_agent)
        """
        if not self.active_agent:
            self._initialize_main_agent()
            self.active_agent = self.main_agent

        return self.active_agent
    
    def handle_interaction(self, user_message: str, mode_agent=None) -> bool:
        """
        Handle complete interaction with the agent.
        
        Args:
            user_message (str): The user's message to send to the agent
            mode_agent: Optional agent instance provided by a mode (e.g., PlanningModeAgent)
            
        Returns:
            bool: True to continue CLI execution, False to exit
        """
        # Extract file paths from the input for display feedback only
        file_paths = extract_file_paths(user_message)

        if not user_message.strip():
            print("No message provided")
            return True
        
        # Prepare message with context
        formatted_message = self._prepare_message_with_context(user_message)
        
        fmt = self.cli.tool_messages_formatter

        if file_paths:
            fmt.display_detected_images()
        
        self._renew_session_lock()
        
        try:
            if mode_agent is not None:
                self.switch_to_mode_agent(mode_agent)
            elif not self.active_agent:
                logger.info("No active agent, initializing and switching to main agent")
                self._initialize_main_agent()
                self.switch_to_main_agent()
            
            callbacks = self._create_callbacks()
            
            return self._process_agent_interaction(formatted_message, callbacks)
            
        except Exception as e:
            if isinstance(e, (KeyboardInterrupt, SystemExit, GeneratorExit)):
                raise
            else:
                fmt.print_error(f'Error processing request: {e}')
            
            if hasattr(self.cli, 'shared_state'):
                fmt.print_usage_summary(self.cli.shared_state.get_usage_summary())
            return {"success": False, "error": str(e)}
            
    def handle_interaction_with_agent(self, user_message: str, agent: SingleAgent) -> bool:
        """
        Handle interaction with a specific agent instance.
        
        This is used when a subagent is called via the /agents command.
        
        Args:
            user_message (str): The user's message to send to the agent
            agent (SingleAgent): The pre-configured agent instance to use
            
        Returns:
            bool: True to continue CLI execution, False to exit
        """
        # Extract file paths from the input for display feedback only
        file_paths = extract_file_paths(user_message)

        if not user_message.strip():
            user_message = "Follow the instructions."
        
        # Prepare message with context
        formatted_message = self._prepare_message_with_context(user_message)
        
        fmt = self.cli.tool_messages_formatter

        if file_paths:
            fmt.display_detected_images()
        
        self._renew_session_lock()
        
        main_agent = self.active_agent

        filtered_tools = [tool for tool in agent.tools if tool.name in self.main_agent_tools]
        update_result = agent.update_tools(filtered_tools)
        
        if update_result['changed']:
            logger.info(f"Subagent tools adjusted to match coda-batch policy. Removed: {update_result['removed']}, Current: {update_result['current']}")
            agent.update_system_prompt()
            logger.info("Regenerated system prompt with filtered tools")

        self.active_agent = agent

        try:
            callbacks = self._create_callbacks()
            
            result = self._process_agent_interaction(formatted_message, callbacks)
            
            self.active_agent = main_agent
            
            return result
            
        except Exception as e:
            self.active_agent = main_agent
            
            if isinstance(e, (KeyboardInterrupt, SystemExit, GeneratorExit)):
                raise
            else:
                fmt.print_error(f'Error processing request with subagent: {e}')
            
            fmt.print_usage_summary(self.cli.shared_state.get_usage_summary())

            return {"success": False, "error": str(e)}
    
    def _prepare_message_with_context(self, user_message: str) -> str:
        """Prepare the user message with context about selected files."""
        if not hasattr(self.cli, 'batch_state') or not self.cli.batch_state.selected_files:
            return user_message
            
        file_count = len(self.cli.batch_state.selected_files)
        system_message = f"[CODA SYSTEM MESSAGE] The user added {file_count} file{'s' if file_count != 1 else ''} as relevant to the context. The file paths are given by:"
        
        for i, file_path in enumerate(self.cli.batch_state.selected_files, 1):
            system_message += f"\n - file {i}: {file_path}"
        
        formatted_message = f"{system_message}\n\n{user_message}"
        logger.debug(f"Prepended file context to user message: {formatted_message}")
        return formatted_message
    
    def _renew_session_lock(self):
        """Renew the session lock if a session is active."""
        if (hasattr(self.cli, 'session_manager') and 
            self.cli.session_manager and 
            self.cli.session_manager.current_session):
            self.cli.session_manager.renew_session_lock()
    
    def _create_callbacks(self):
        """Create the callback dictionary for agent interaction."""
        current_tool_args = {}
        shared_state = (self.active_agent.shared_state
                        if hasattr(self.active_agent, 'shared_state') and self.active_agent
                        else self.cli.shared_state)
        logger.info(f"Using shared_state from: {'active agent' if (hasattr(self.active_agent, 'shared_state') and self.active_agent) else 'CLI'}")
        fmt = self.cli.tool_messages_formatter

        callbacks = {
            "on_llm_start": lambda: None,

            "on_llm_parsed": lambda content, tool_calls, metadata: (
                fmt.print_intermediate_response(content) if (tool_calls and content) else None,
                shared_state.add_usage(metadata.get("usage")) if metadata and metadata.get("usage") else None,
            ),

            "on_tool_call": lambda tool_name, tool_args: (
                current_tool_args.update(tool_args),
                fmt.print_tool_call(tool_name, tool_args),
            ),

            "on_ask_user": lambda question, suggestions, direct_actions=None: (
                fmt.display_ask_user_question(question, suggestions, direct_actions),
            ),

            "on_tool_result": lambda tool_name, success, result: (
                shared_state.add_usage(result.pop("_usage")) if (success and isinstance(result, dict) and "_usage" in result) else None,
                fmt.print_tool_result(tool_name, not success, result if isinstance(result, dict) else {"result": result}, current_tool_args.copy())
                if (tool_name and tool_name.lower() not in ["think", "ask_user"]) else None,
                current_tool_args.clear(),
            ),

            "on_msg": lambda msg: (
                fmt.print_message(msg),
            ),

            "on_max_iterations": lambda last_message: (
                fmt.print_max_iterations(last_message),
            ),

            "on_complete": lambda _, content, metadata: (
                fmt.print_final_response(content),
                shared_state.add_usage(metadata.get("usage")) if metadata and metadata.get("usage") else None,
            ),

            "on_memory_condensing_start": lambda message: (
                fmt.print_memory_condensing_start(message),
            ),

            "on_memory_condensing_end": lambda result: (
                metadata := result.get("metadata", {}),
                has_error := result.get("result", {}).get("error", False),
                error_description := result.get("result", {}).get("error_dsc", "Unknown error"),
                is_skipped := metadata.get("skipped", False),
                shared_state.add_usage(metadata.get("usage")) if metadata and metadata.get("usage") else None,
                fmt.print_memory_condensing_error(error_description) if has_error else (
                    fmt.print_memory_condensing_skipped(metadata) if is_skipped else
                    fmt.print_memory_condensing_complete(metadata)
                ),
            ),
        }
        return callbacks
    
    def _extract_metadata(self):
        """Extract session metadata for GEAI tracking."""
        try:
            session_id = None
            session_name = None
            if (hasattr(self.cli, 'session_manager') and 
                self.cli.session_manager and 
                self.cli.session_manager.current_session):
                session_id = self.cli.session_manager.current_session.id
                session_name = self.cli.session_manager.current_session.name

            metadata_input = SessionMetadata(
                client=CLIENT_NAME,
                session_id=session_id,
                task_id=session_name
            )
            metadata = extract_metadata(metadata_input)
            logger.debug(f"Extracted metadata: {metadata}")
            return metadata
        except Exception as e:
            logger.warning(f"Failed to extract metadata: {e}. Continuing without metadata.")
            return None

    def _process_agent_interaction(self, formatted_message, callbacks):
        """Process the agent interaction with the formatted message."""
        fmt = self.cli.tool_messages_formatter
        response = None
        metadata = self._extract_metadata()
        
        try:
            self.is_agent_executing = True
            logger.info(f"Agent execution started with {type(self.active_agent).__name__}")
            
            response = self.active_agent.get_response(
                user_message=formatted_message, 
                callbacks=callbacks,
                metadata_param=metadata
            )
            
            self.is_agent_executing = False
            logger.info("Agent execution finished successfully")
            
        except KeyboardInterrupt:
            fmt.print_message("Process interrupted by user (Ctrl+C)")
            logger.info("KeyboardInterrupt during agent execution - flag kept for CLI decision")
            raise
            
        except (SystemExit, GeneratorExit):
            fmt.print_message("Process terminating abruptly")
            self.is_agent_executing = False
            logger.info("Agent execution terminated")
            raise
            
        except Exception as e:
            logger.error(f"Exception in agent interaction: {e}")
            self.is_agent_executing = False
            logger.info("Agent execution ended with exception")
            raise
            
        finally:
            if self.is_agent_executing and not isinstance(sys.exc_info()[1], KeyboardInterrupt):
                logger.debug("Resetting is_agent_executing flag in finally block")
                self.is_agent_executing = False
        
        if response is not None and not response.get("success", False):
            if "content" in response:
                fmt.print_final_response(response["content"])
            elif "error" in response:
                fmt.print_error(response["error"])
                
        shared_state = self.active_agent.shared_state if (hasattr(self.active_agent, 'shared_state') and self.active_agent) else self.cli.shared_state
        
        fmt.print_usage_summary(shared_state.get_usage_summary())

        if self.cli._should_attempt_rename():
            success = self.cli.session_manager.rename_session_by_llm_call(
                session_id=self.cli.session_manager.current_session.id,
                shared_state=shared_state
            )
            if success:
                logger.info(f"Session rename thread started by LLM call")
        return response
    
