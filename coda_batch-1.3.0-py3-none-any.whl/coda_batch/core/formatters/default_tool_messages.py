import sys
import contextlib
from typing import IO

from coda_batch.core.formatters.base import ToolMessagesFormatter
from coda_batch.core.ui import core as ui_core


class DefaultToolMessagesFormatter(ToolMessagesFormatter):
    """
    Preserves the current rich ANSI/emoji output.

    Output destination is controlled by self.stream (stdout or stderr).
    The existing ui_core functions print to stdout by default, so when
    self.stream is stderr we redirect stdout temporarily for each call.
    """

    def __init__(self, stream: IO = None):
        super().__init__(stream)
        self._needs_redirect = self.stream is not sys.stdout

    def _print_to_stream(self, ui_func, *args, **kwargs):
        """
        Call a ui_core function. If the target stream is not stdout,
        temporarily redirect stdout so that print() calls inside ui_core
        land on the correct stream.
        """
        if not self._needs_redirect:
            return ui_func(*args, **kwargs)
        with contextlib.redirect_stdout(self.stream):
            return ui_func(*args, **kwargs)

    def print_tool_call(self, tool_name, tool_args):
        self._print_to_stream(ui_core.print_tool_block, tool_name, tool_args)

    def print_tool_result(self, tool_name, is_error, result, tool_params=None):
        self._print_to_stream(ui_core.print_result_block, is_error, result, tool_params)

    def print_intermediate_response(self, response_text):
        self._print_to_stream(ui_core.print_intermediate_response, response_text)

    def print_final_response(self, response_text):
        self._print_to_stream(ui_core.print_markdown_response, response_text)

    def print_error(self, error_message):
        self._print_to_stream(ui_core.print_formatted_error_message, error_message)

    def print_usage_summary(self, usage_summary):
        self._print_to_stream(ui_core.print_usage_summary, usage_summary)

    def print_agent_header(self, agent_name, status=None):
        self._print_to_stream(ui_core.print_agent_header, agent_name, status)

    def print_session_info(self, session_name):
        self._print_to_stream(ui_core.print_session_oneliner, session_name)

    def print_model_info(self, provider_name, model_name):
        self._print_to_stream(ui_core.print_current_model, provider_name, model_name)

    def print_memory_condensing_start(self, message):
        self._print_to_stream(ui_core.display_memory_condensing_start, message)

    def print_memory_condensing_complete(self, metadata):
        self._print_to_stream(ui_core.display_memory_condensing_complete, metadata)

    def print_memory_condensing_skipped(self, metadata):
        self._print_to_stream(ui_core.display_memory_condensing_skipped, metadata)

    def print_memory_condensing_error(self, error_description):
        self._print_to_stream(ui_core.display_memory_condensing_error, error_description)

    def print_message(self, message):
        print(f"\033[1;31m{message}\033[0m", file=self.stream)

    def print_max_iterations(self, last_message):
        print(f"\033[1;33mReached maximum iterations\033[0m", file=self.stream)
        if last_message:
            self._print_to_stream(ui_core.print_markdown_response, last_message)

    def display_ask_user_question(self, question, suggestions, direct_actions=None):
        return ui_core.display_ask_user_question(question, suggestions, direct_actions)

    def display_detected_images(self):
        self._print_to_stream(ui_core.display_detected_images)

