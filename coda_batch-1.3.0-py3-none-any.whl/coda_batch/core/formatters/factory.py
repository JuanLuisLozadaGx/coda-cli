import sys
from typing import IO

from coda_batch.core.formatters.base import ToolMessagesFormatter, OutputFormatter
from coda_batch.core.formatters.default_tool_messages import DefaultToolMessagesFormatter
from coda_batch.core.formatters.jsonl_tool_messages import JsonlToolMessagesFormatter
from coda_batch.core.formatters.default_output import DefaultOutputFormatter
from coda_batch.core.formatters.json_output import JsonOutputFormatter


def resolve_tool_messages_stream(redirect: str) -> IO:
    """
    Resolve the --tool-messages-redirect value to an IO stream.

    Args:
        redirect: "stdout" or "stderr"
    """
    if redirect == "stderr":
        return sys.stderr
    return sys.stdout


def create_tool_messages_formatter(format_name: str, stream: IO = None) -> ToolMessagesFormatter:
    """
    Factory: create the appropriate tool-messages formatter.

    Args:
        format_name: "default" or "jsonl"
        stream: target IO stream (stdout or stderr). Defaults to sys.stdout.
    """
    if format_name == "jsonl":
        return JsonlToolMessagesFormatter(stream=stream)
    return DefaultToolMessagesFormatter(stream=stream)


def create_output_formatter(format_name: str) -> OutputFormatter:
    """
    Factory: create the appropriate output formatter.

    Args:
        format_name: "default" or "json"
    """
    if format_name == "json":
        return JsonOutputFormatter()
    return DefaultOutputFormatter()

