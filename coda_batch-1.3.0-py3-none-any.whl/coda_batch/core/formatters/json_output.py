import json

from coda_batch.core.formatters.base import OutputFormatter


class JsonOutputFormatter(OutputFormatter):
    """
    JSON output formatter. Returns a JSON object with session metadata.

    Example output:
    {
      "user_message": "fix the bug",
      "response": "Here is the fix...",
      "session_id": "abc123",
      "session_name": "session-foo",
      "model": "openai/gpt-5"
    }
    """

    def format_response(self, response, user_message, session_id, session_name, model) -> str:
        output = {
            "user_message": user_message,
            "response": response if response else "",
            "session_id": session_id,
            "session_name": session_name,
            "model": model,
        }
        return json.dumps(output, ensure_ascii=False)

