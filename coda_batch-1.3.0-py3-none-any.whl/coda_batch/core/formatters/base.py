import sys
from abc import ABC, abstractmethod
from typing import Dict, Any, IO, Optional


class ToolMessagesFormatter(ABC):
    """
    Abstract base class for tool/intermediate message formatting.

    All output from these methods goes to self.stream,
    which defaults to sys.stdout but can be set to sys.stderr
    via the --tool-messages-redirect flag.
    """

    def __init__(self, stream: IO = None):
        self.stream = stream or sys.stdout

    @abstractmethod
    def print_tool_call(self, tool_name: str, tool_args: Dict[str, Any]) -> None:
        """Print a tool call with its arguments."""

    @abstractmethod
    def print_tool_result(self, tool_name: str, is_error: bool, result: dict, tool_params: dict = None) -> None:
        """Print the result of a tool execution."""

    @abstractmethod
    def print_intermediate_response(self, response_text: str) -> None:
        """Print an intermediate text response (e.g. content between tool calls)."""

    @abstractmethod
    def print_final_response(self, response_text: str) -> None:
        """Print the final decorated response."""

    @abstractmethod
    def print_error(self, error_message: str) -> None:
        """Print a formatted error message."""

    @abstractmethod
    def print_usage_summary(self, usage_summary: dict) -> None:
        """Print token usage and cost summary."""

    @abstractmethod
    def print_agent_header(self, agent_name: str, status: str = None) -> None:
        """Print an agent processing header."""

    @abstractmethod
    def print_session_info(self, session_name: str) -> None:
        """Print current session information."""

    @abstractmethod
    def print_model_info(self, provider_name: str, model_name: str) -> None:
        """Print current model information."""

    @abstractmethod
    def print_memory_condensing_start(self, message: str) -> None:
        """Print memory condensing start notification."""

    @abstractmethod
    def print_memory_condensing_complete(self, metadata: Dict[str, Any]) -> None:
        """Print memory condensing completion with stats."""

    @abstractmethod
    def print_memory_condensing_skipped(self, metadata: Dict[str, Any]) -> None:
        """Print memory condensing skipped notification."""

    @abstractmethod
    def print_memory_condensing_error(self, error_description: str) -> None:
        """Print memory condensing error."""

    @abstractmethod
    def print_message(self, message: str) -> None:
        """Print a generic system message."""

    @abstractmethod
    def print_max_iterations(self, last_message: Optional[str]) -> None:
        """Print max iterations reached notification."""

    @abstractmethod
    def display_ask_user_question(self, question: str, suggestions: list, direct_actions: dict = None) -> str:
        """Display a question to the user and return the response."""

    @abstractmethod
    def display_detected_images(self) -> None:
        """Print visual feedback when images are detected."""


class OutputFormatter(ABC):
    """
    Abstract base class for final response formatting.

    Output from format_response() goes to stdout.
    """

    @abstractmethod
    def format_response(
        self,
        response: str,
        user_message: str,
        session_id: str,
        session_name: str,
        model: str,
    ) -> str:
        """
        Format the final response for stdout.

        Returns:
            str: The formatted output string to be printed to stdout.
        """

