import json
from typing import IO

from coda_batch.core.formatters.base import ToolMessagesFormatter


class JsonlToolMessagesFormatter(ToolMessagesFormatter):
    """
    Emit every intermediate event as a JSONL line.
    Output destination is controlled by self.stream (stdout or stderr).
    No ANSI, no emojis, no animations.
    """

    def __init__(self, stream: IO = None):
        super().__init__(stream)

    def _emit(self, event_type: str, data: dict) -> None:
        line = json.dumps({"event": event_type, **data}, ensure_ascii=False)
        print(line, file=self.stream)

    def print_tool_call(self, tool_name, tool_args):
        filtered_args = {k: v for k, v in tool_args.items() if k != "metadata"}
        self._emit("tool_call", {"tool": tool_name, "args": filtered_args})

    def print_tool_result(self, tool_name, is_error, result, tool_params=None):
        filtered_result = {k: v for k, v in result.items() if k != "metadata"} if isinstance(result, dict) else result
        self._emit("tool_result", {
            "tool": tool_name,
            "is_error": is_error,
            "result": filtered_result,
        })

    def print_intermediate_response(self, response_text):
        self._emit("intermediate_response", {"content": response_text})

    def print_final_response(self, response_text):
        self._emit("final_response", {"content": response_text})

    def print_error(self, error_message):
        self._emit("error", {"message": error_message})

    def print_usage_summary(self, usage_summary):
        self._emit("usage_summary", usage_summary)

    def print_agent_header(self, agent_name, status=None):
        self._emit("agent_start", {"agent": agent_name, "status": status or "Processing..."})

    def print_session_info(self, session_name):
        self._emit("session_info", {"session_name": session_name})

    def print_model_info(self, provider_name, model_name):
        self._emit("model_info", {"provider": provider_name, "model": model_name})

    def print_memory_condensing_start(self, message):
        self._emit("memory_condensing_start", {"message": message})

    def print_memory_condensing_complete(self, metadata):
        self._emit("memory_condensing_complete", metadata)

    def print_memory_condensing_skipped(self, metadata):
        self._emit("memory_condensing_skipped", metadata)

    def print_memory_condensing_error(self, error_description):
        self._emit("memory_condensing_error", {"error": error_description})

    def print_message(self, message):
        self._emit("message", {"content": message})

    def print_max_iterations(self, last_message):
        self._emit("max_iterations", {"last_message": last_message})

    def display_ask_user_question(self, question, suggestions, direct_actions=None):
        """
        Always use the default interactive UI for ask_user since it requires stdin input.
        The JSONL event is still emitted for observability, then the rich UI is shown.
        """
        self._emit("ask_user", {"question": question, "suggestions": suggestions})
        from coda_batch.core.ui.core import display_ask_user_question
        return display_ask_user_question(question, suggestions, direct_actions)

    def display_detected_images(self):
        self._emit("images_detected", {})

