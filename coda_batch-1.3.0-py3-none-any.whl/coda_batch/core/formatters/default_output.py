from coda_batch.core.formatters.base import OutputFormatter


class DefaultOutputFormatter(OutputFormatter):
    """
    Default output formatter. Returns the raw response text.

    Note: The decorated response was already printed by the
    tool-messages formatter's print_final_response(). This returns the
    clean text for downstream consumers.
    """

    def format_response(self, response, user_message, session_id, session_name, model) -> str:
        return response if response else ""

