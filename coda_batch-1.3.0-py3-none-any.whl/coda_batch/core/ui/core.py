from loguru import logger
import shutil
import re
from typing import Dict, Any, List
from prompt_toolkit import print_formatted_text
from prompt_toolkit.formatted_text import HTML

from pygments import highlight
from pygments.lexers import get_lexer_by_name, TextLexer
from pygments.formatters import Terminal256Formatter

from coda_batch.config.constants import (
    TOOL_NAME_EMOJIS,
    PROVIDER_DISPLAY_NAMES
)

from coda_core.config.constants import (
    DIAGNOSE_AGENT,
    FIX_AGENT,
    EXPLAIN_AGENT,
    CODEFIXER_AGENTS,
)


def color(text: str, code: str) -> str:
    """
    Return ANSI-colored text with the specified color code.
    
    Applies ANSI color codes to the provided text and ensures proper reset
    of formatting after the text.
    
    Args:
        text (str): The text to be colored
        code (str): ANSI color code (e.g., "1;31" for bold red, "2" for faint)
        
    Returns:
        str: The text with ANSI color formatting applied
    """
    return f"\033[{code}m{text}\033[0m"


def truncate_middle(text: str, max_length: int) -> str:
    """Truncate text in the middle if it exceeds ``max_length``."""
    if len(text) <= max_length:
        return text

    # Visible placeholder (without ANSI codes). New lines will be added around it
    # when we build the final string, so we account for them here as well.
    placeholder_plain = "... [output truncated] ..."
    placeholder_visible_len = len(placeholder_plain) + 2  # leading + trailing \n
    # Not enough room for text – just return the placeholder itself
    if max_length <= placeholder_visible_len:
        return f"\n{color(placeholder_plain, '38;5;246')}\n"

    # Space available for the original text once the placeholder is inserted
    remaining = max_length - placeholder_visible_len
    head_len = remaining // 2                # Front slice length
    tail_len = remaining - head_len          # Back slice length (gets the odd char if any)

    placeholder_coloured = color(placeholder_plain, "38;5;246")
    return f"{text[:head_len]}\n{placeholder_coloured}\n{text[-tail_len:]}"


def block_header(title: str, icon: str = "💡", color_code: str = "38;5;81") -> str:
    """
    Create a colored header line for a block of content.
    
    Generates a visually distinct header with an icon and title, using
    colored line characters to create a styled UI element.
    
    Args:
        title (str): The title text to display in the header
        icon (str, optional): An emoji or icon to display. Defaults to "💡".
        color_code (str, optional): ANSI color code for styling. Defaults to "38;5;81".
        
    Returns:
        str: A formatted header line with the specified styling
    """
    # We'll do 2 dashes after the corner for the header
    line_part = color("╭──", color_code)
    line_first_part = f"{line_part} {icon} {title}"
    line_so_far_len = len(line_first_part) + 1
    # We want a total of 30 chars. We'll see how many we have so far:
    total_width = 46 # to account for 🛠️ length
    needed = total_width - line_so_far_len
    if needed < 0:
        needed = 0
    trailing = "─" * needed
    trailing_colored = color(trailing, color_code)
    return f"{line_first_part} {trailing_colored}"


def block_line(label: str, value: str, label_width: int = 10, box_color: str = "38;5;81", line_color: str = None) -> str:
    """
    Create a formatted line with a label and value for a block.
    
    Generates a line with a vertical bar, label, and value with appropriate styling.
    Used for displaying parameter details within a block.
    
    Args:
        label (str): The label text to display
        value (str): The value text to display
        label_width (int, optional): Width for label field. Defaults to 10.
        box_color (str, optional): ANSI color code for box elements. Defaults to "38;5;81".
        line_color (str, optional): ANSI color code for the vertical line. If provided, overrides box_color for the line.
        
    Returns:
        str: A formatted line with the specified label and value
    """
    # Use line_color for the vertical bar if provided, otherwise use box_color
    line_part = color("│", line_color if line_color else box_color)
    faint_label = color(label.ljust(label_width), "2")  # faint
    normal_value = color(value, "0")                    # normal
    return f"{line_part} {faint_label} : {normal_value}"


def block_midline_with_result(result_label: str = "✅", color_code: str = "38;5;81") -> str:
    """
    Create a formatted middle line for a block with a result indicator.
    
    Generates a midline separator with a result label (like ✅ or ❌) for
    visually separating content within a block.
    
    Args:
        result_label (str, optional): The label to display in the midline. Defaults to "✅".
        color_code (str, optional): ANSI color code for styling. Defaults to "38;5;81".
        
    Returns:
        str: A formatted midline with the specified result label
    """
    prefix = color("├──", color_code)
    full_text = f"{prefix} {result_label} "
    line_so_far_len = len("├── ") + len(result_label) + 1

    total_width = 30
    needed = total_width - line_so_far_len
    if needed < 0:
        needed = 0
    trailing = "─" * needed
    trailing_colored = color(trailing, color_code)
    return f"{full_text}{trailing_colored}"


def block_result_line(result_label: str = "✅", color_code: str = "38;5;81") -> str:
    """
    Create a formatted result line with a curved corner and result indicator.
    
    Generates a single-line result with a curved corner (╰──) and a result label
    (like ✅ or ❌) for displaying simple results without additional parameters.
    
    Args:
        result_label (str, optional): The label to display in the result line. Defaults to "✅".
        color_code (str, optional): ANSI color code for styling. Defaults to "38;5;81".
        
    Returns:
        str: A formatted result line with the specified result label
    """
    prefix = color("╰──", color_code)
    full_text = f"{prefix} {result_label} "
    line_so_far_len = len("╰── ") + len(result_label) + 1
    
    total_width = 30
    needed = total_width - line_so_far_len
    if needed < 0:
        needed = 0
    trailing = "─" * needed
    trailing_colored = color(trailing, color_code)
    
    return f"{full_text}{trailing_colored}"


def block_footer(color_code: str = "38;5;81") -> str:
    """
    Create a formatted footer line for a block.
    
    Generates the bottom border of a content block with appropriate styling.
    
    Args:
        color_code (str, optional): ANSI color code for styling. Defaults to "38;5;81".
        
    Returns:
        str: A formatted footer line
    """
    footer = f"╰{'─'*30}"
    return color(footer, color_code)


def print_tool_block(title: str, params: Dict[str, Any]) -> None:
    """
    Print a formatted block for a tool with its parameters.
    
    Displays a tool's title and parameters in a visually distinct block format.
    Special handling for "think" tools and skips certain fields like old_string 
    and new_string.
    
    Args:
        title (str): The title of the tool
        params (Dict[str, Any]): A dictionary of parameters to display
    """
    normalized_title = title.strip().lower()
    # We'll color the header line, then normal text for icon/title after a space
    if normalized_title == "think":
        print("💭 Thought")
        for k, v in params.items():
            if k.lower() == "metadata":
                continue
            print_intermediate_response(str(v))
        return
    elif normalized_title == "ask_user": 
        return

    icon = TOOL_NAME_EMOJIS.get(title.strip().lower(), TOOL_NAME_EMOJIS["default"])

    print(block_header(title, icon=icon, color_code="38;5;81"))
    for k, v in params.items():
        # Skip printing old_string, new_string, and metadata fields
        if k.lower() in ["old_string", "new_string", "metadata"]:
            continue
        # Skip empty values
        if v == "":
            continue
        raw_val = str(v)
        val_str = truncate_middle(raw_val, 200)

        if '\n' in val_str:
            lines = val_str.split('\n')
            print(block_line(k, lines[0], label_width=12, box_color="38;5;81"))
            for line in lines[1:]:
                line_part = color("│", "38;5;81")
                print(f"{line_part} {line}")
        else:
            print(block_line(k, val_str, label_width=12, box_color="38;5;81"))
    

def print_result_block(is_error: bool, result_dict: dict, tool_params: dict = None): #
    # If diff is present in result, display formatted diff instead of message
    if "diff" in result_dict:
        # Determine label based on error status
        label = "❌" if is_error else "✅"
        # Print result midline
        midline = block_midline_with_result(label, "38;5;81")
        print(midline)
        # Print formatted diff
        print_diff_lines(result_dict["diff"])
        # Print footer
        print(block_footer("38;5;81"))
        return
    if is_error:
        label = "❌"
    else:
        label = "✅"

    # Filter out result-specific keys and keys already shown in tool block
    filtered_keys = {"status", "command", "file", "metadata"}
    if tool_params:
        # Add keys that were displayed in tool block (excluding old_string, new_string, empty values)
        filtered_keys.update(k.lower() for k, v in tool_params.items() 
                            if k.lower() not in ["old_string", "new_string"] and v != "")
    
    # Check if there are any parameters to display after filtering
    visible_params = {k: v for k, v in result_dict.items()
                     if k.lower() not in filtered_keys and v != ""}

    if not visible_params:
        result_line = block_result_line(label, "38;5;81")
        print(result_line)
        return

    # Regular output with parameters
    midline = block_midline_with_result(label, "38;5;81")
    print(midline)
    # Now param lines
    for k, v in result_dict.items():
        # Skip keys already shown in tool block and result-specific keys
        if k.lower() in filtered_keys:
            continue
        # Skip empty values
        if v == "":
            continue
        raw_val = str(v)
        val_str = truncate_middle(raw_val, 200)
        # For multiline content, ensure boxes are properly continued for all lines
        if '\n' in val_str:
            lines = val_str.split('\n')
            # Print first line
            print(block_line(k, lines[0], label_width=12, box_color="38;5;81"))
            # Print continuation lines with empty label but keeping the box character
            for line in lines[1:]:
                line_part = color("│", "38;5;81")
                # Use empty label space but maintain alignment
                print(f"{line_part} {line}")
        else:
            print(block_line(k, val_str, label_width=12, box_color="38;5;81"))
    print(block_footer("38;5;81"))
    
    # Special handling for plan approval: show the plan file path after the result block
    if "plan_file_path" in result_dict and result_dict.get("status") == "✅ Approved":
        print()  # Add spacing
        # Bold and green colored text for better visibility
        bold = "\033[1m"
        green = "\033[32m"
        reset = "\033[0m"
        
        # Make the path clickable using print_hyperlink (for VS Code and other terminals)
        plan_path = result_dict['plan_file_path']
        print(f"📄 {bold}{green}You can find the detailed plan here:{reset}")
        print_hyperlink(f"  {plan_path}", f"file://{plan_path}", "34")  # blue color


def print_diff_lines(diff_lines: List[str]) -> None:
    """
    Print a formatted display of diff output.
    
    Takes a list of diff lines and formats them with appropriate colors
    to highlight additions, deletions, and context.
    
    Args:
        diff_lines (List[str]): A list of strings representing diff output
    """
    # Skip the first few lines (header information)
    lines_to_show = diff_lines[3:] if len(diff_lines) > 3 else diff_lines
    box_color = "38;5;81"

    # Inspect each line for trailing newlines and process accordingly
    for line in lines_to_show:
        # Remove any built-in newlines that might be causing the issue
        line = line.rstrip('\n')

        if line.startswith("│ -"):
            minus_text = line[2:]  # skip "│ "
            colored_minus = color(minus_text, "31")  # red
            print(f"{color('│', box_color)} {colored_minus}")
        elif line.startswith("│ +"):
            plus_text = line[2:]
            colored_plus = color(plus_text, "32")  # green
            print(f"{color('│', box_color)} {colored_plus}")
        else:
            ctx_text = line[2:]
            faint_text = color(ctx_text, "2")
            print(f"{color('│', box_color)} {faint_text}")

def print_final_response(response_text: str) -> None:
    """
    Print a formatted final response from the AI agent.
    
    Creates a visually distinct block for the AI's final response with
    appropriate styling and formatting.
    
    Args:
        response_text (str): The response text to display
    """
    # Handle None values
    if response_text is None:
        response_text = "[SYSTEM MESSAGE] All done! Response was already provided or there's no new content to display."
    
    color_code = "38;5;213"
    header = color("╭──", color_code)
    header_ending = color(f"{'─'*15}", color_code)
    print("")
    print(f"{header} 🤖 RESPONSE {header_ending}")

    box_color = "38;5;81"  # or we can use the pink color for vertical lines; let's do the pink for consistency with the header
    for line in response_text.split('\n'):
        if not line.strip():
            line = " "
        print(f"{color('│', color_code)} {line}")
    footer = f"╰{'─'*30}"
    print(color(footer, color_code))

def print_intermediate_response(response_text: str) -> None:
    """
    Print an intermediate response or thought from the AI agent.
    
    Displays in-progress responses or thought processes with subtle styling
    to differentiate from final responses.
    
    Args:
        response_text (str): The intermediate response text to display
    """
    color_code = "38;5;246"
    print()
    print(color(response_text, color_code))

def print_session_oneliner(session_name: str) -> None:
    """
    Display session information in a formatted box.
    
    Args:
        session_name (str): The name of the current session
    """
    print_formatted_text(HTML(f'<ansibrightblue>💻 Current session: <ansibrightyellow>{session_name}</ansibrightyellow></ansibrightblue>'))


def print_current_model(provider_name: str, model_name: str) -> None:
    """
    Display the currently configured AI model with prettified provider name.
    
    Args:
        provider_name (str): The name of the model provider
        model_name (str): The name of the model
    """
    # Get prettified provider name from constants, fallback to capitalized version
    prettified_provider = PROVIDER_DISPLAY_NAMES.get(provider_name, provider_name.replace('_', ' ').title())
    formatted_display = f"{model_name} (via {prettified_provider})"
    print_formatted_text(HTML(f'<ansibrightblue>🧠 Current model: <ansibrightyellow>{formatted_display}</ansibrightyellow></ansibrightblue>'))


def display_memory_condensing_start(message: str) -> None:
    """
    Display a message when memory condensing starts.
    
    Args:
        message (str): The message to display
    """
    print_formatted_text(HTML(
        f"\n<ansibrightblue>💾 Memory Condensing Starting:</ansibrightblue> {message}. Stand by..."
    ))


def display_memory_condensing_complete(metadata: Dict[str, Any]) -> None:
    """
    Display successful memory condensing results including token savings.
    
    Args:
        metadata (Dict[str, Any]): Metadata about the condensing operation, including:
            - messages_condensed: Number of messages condensed
            - tokens_removed: Tokens removed by condensing
            - tokens_added: Tokens added by the summary
            - net_token_change: Net change in tokens
    """
    # Extract metadata values with defaults
    messages_condensed = metadata.get('messages_condensed', 0)
    tokens_removed = metadata.get('tokens_removed', 0)
    tokens_added = metadata.get('tokens_added', 0)
    net_token_change = metadata.get('net_token_change', 0)
    
    # Calculate token savings percentage
    savings_percent = (abs(net_token_change) / tokens_removed * 100) if tokens_removed > 0 else 0
    
    # Display results in a compact format
    print_formatted_text(HTML(
        f"\n<ansibrightblue>💾 Memory Condensing Complete:</ansibrightblue> "
        f"{messages_condensed} messages condensed, {tokens_removed:,} tokens → {tokens_added:,} tokens "
        f"(saved <ansibrightgreen>{abs(net_token_change):,}</ansibrightgreen> tokens, {savings_percent:.1f}%)"
    ))


def display_memory_condensing_skipped(metadata: Dict[str, Any]) -> None:
    """
    Display information when memory condensing was skipped.
    
    Args:
        metadata (Dict[str, Any]): Metadata about why condensing was skipped, including:
            - reason: The reason condensing was skipped
    """
    # Extract the reason with a default
    reason = metadata.get('reason', 'Unknown reason')
    
    # Display results in a compact format
    print_formatted_text(HTML(f"\n<ansibrightblue>💾 Memory Condensing Skipped:</ansibrightblue> {reason}"))


def display_memory_condensing_error(error_description: str) -> None:
    """
    Display information when memory condensing encountered an error.
    
    Args:
        error_description (str): Description of the error that occurred
    """
    # Display error in a compact format with red color for visibility
    print_formatted_text(HTML(f"\n<ansibrightblue>❌ Memory Condensing Error:</ansibrightblue> {error_description}"))


def display_model_change_success(provider: str, model: str) -> None:
    """
    Display a success message after changing the model.
    
    Args:
        provider (str): The provider name
        model (str): The model name
    """
    print(f"\n\033[1;32mModel changed to: {provider}/{model}\033[0m")
    print("\033[2mYour configuration has been updated.\033[0m")


def print_markdown_response(markdown_text: str) -> None:
    """
    Print a markdown-formatted response with proper handling of
    indented code blocks and nested structures.
    
    Args:
        markdown_text (str): The markdown-formatted text to display
    """
    # Handle None values
    if markdown_text is None:
        markdown_text = "[SYSTEM MESSAGE] All done! Response was already provided or there's no new content to display."
    
    # Process the markdown with indentation awareness
    processed_text = process_markdown_with_indentation(markdown_text)
    
    # Use the existing print_final_response function
    print_final_response(processed_text)

def process_markdown_with_indentation(markdown: str) -> str:
    """
    Process markdown text with careful handling of indentation and nested structures.
    
    Args:
        markdown (str): The markdown text to process
        
    Returns:
        str: Processed text with proper formatting
    """ 
    # Background color for code blocks
    bg_color = "48;5;236"  # Dark gray background
    
    result = []
    lines = markdown.split('\n')
    i = 0
    
    while i < len(lines):
        line = lines[i]
        
        # Check for code block start (with any indentation)
        code_block_match = re.match(r'^(\s*)```(\w*)$', line)
        if code_block_match:
            # Extract indentation and language
            indentation = code_block_match.group(1)
            language = code_block_match.group(2).strip()
            
            # Collect code lines
            code_lines = []
            i += 1
            
            # Find the end of the code block (matching indentation)
            while i < len(lines) and not re.match(f'^{re.escape(indentation)}```$', lines[i]):
                # Remove the same amount of indentation from each code line
                if lines[i].startswith(indentation):
                    code_line = lines[i][len(indentation):]
                else:
                    code_line = lines[i]
                code_lines.append(code_line)
                i += 1
            
            # Skip the closing backticks
            if i < len(lines):
                i += 1
            
            # Apply syntax highlighting
            code = '\n'.join(code_lines)
            if language:
                try:
                    lexer = get_lexer_by_name(language, stripall=True)
                except:
                    lexer = TextLexer()
            else:
                lexer = TextLexer()
            
            # Add an empty line before the code block
            result.append("")
            
            # Add language indicator with cyan color
            if language:
                result.append(f"{indentation}\033[36m[{language}]\033[0m")
            
            # Get the highlighted code
            highlighted = highlight(code, lexer, Terminal256Formatter(style='monokai'))
            highlighted_lines = highlighted.splitlines()
            
            # Find the maximum line length for padding
            max_line_length = 0
            for hl in highlighted_lines:
                # Strip ANSI codes to get actual visible length
                visible_line = re.sub(r'\x1b\[[0-9;]*m', '', hl)
                max_line_length = max(max_line_length, len(visible_line))
            
            # Add each highlighted line with background color
            for hl in highlighted_lines:
                # Strip ANSI codes to get actual visible length
                visible_line = re.sub(r'\x1b\[[0-9;]*m', '', hl)
                padding = max_line_length - len(visible_line)
                
                # Apply background to the entire line with padding for rectangular shape
                result.append(f"{indentation}\033[{bg_color}m {hl}{' ' * padding} \033[0m")
            
            # Add an empty line after the code block
            result.append("")
            
            continue
        
        # Process headers (with any indentation)
        header_match = re.match(r'^(\s*)(#{1,6})\s+(.+)$', line)
        if header_match:
            indentation = header_match.group(1)
            level = len(header_match.group(2))
            content = header_match.group(3)
            
            # Format headers based on level
            if level <= 2:
                result.append(f"{indentation}\033[1;34m{content}\033[0m")  # Bold blue for h1-h2
            else:
                result.append(f"{indentation}\033[34m{content}\033[0m")  # Blue for h3-h6
            
            i += 1
            continue
        
        # Process bold and inline code while preserving indentation
        processed_line = line
        
        # Bold (**text**)
        processed_line = re.sub(r'\*\*(.*?)\*\*', r'\033[1m\1\033[0m', processed_line)
        
        # Inline code (`code`)
        processed_line = re.sub(r'`([^`]+)`', r'\033[90m\1\033[0m', processed_line)
        
        result.append(processed_line)
        i += 1
    
    return '\n'.join(result)


def print_formatted_error_message(error_message: str) -> None:
    """
    Display a formatted error message box.

    Args:
        error_message (str): The full error message string to display.
    """
    error_color = "38;5;196"  # Red color
    
    try:
        # Check for wrapped error messages from single_agent.py
        wrapped_error_match = re.search(r"An error occurred while processing the request: (Error code: \d+ - .+)", error_message)
        if wrapped_error_match:
            # Extract the actual error message
            error_message = wrapped_error_match.group(1)
        
        # Attempt to parse the error message
        # This is needed to extract the status code and error details from LiteLLM exceptions
        match = re.search(r"Error code: (\d+) - (.+)", error_message)
        if not match:
            raise ValueError("Invalid error message format")

        status_code = int(match.group(1))
        error_details = eval(match.group(2))  # Convert the string to a dictionary

        # Extract details from the error details
        error_type_map = {
            400: "BadRequestError",
            401: "AuthenticationError",
            403: "PermissionDeniedError",
            404: "NotFoundError",
            422: "UnprocessableEntityError",
            429: "RateLimitError",
            500: "InternalServerError",
        }
        error_type = error_type_map.get(status_code, "UnknownError")
        message = error_details.get("error", {}).get("message", "No message provided.")
        request_id = error_details.get("requestId", "N/A")

        # Display the parsed error details in a styled box
        print(block_header("GEAI ERROR", icon="❌", color_code=error_color))
        print(block_line("Status Code", str(status_code), box_color=error_color, line_color=error_color))
        print(block_line("Error Type", error_type, box_color=error_color, line_color=error_color))
        print(block_line("Request ID", request_id, box_color=error_color, line_color=error_color))
        print(block_line("Message", message, box_color=error_color, line_color=error_color))
        print(block_footer(error_color))

    except Exception:
        # Fallback: Display the full error message if parsing fails
        print(block_header("ERROR", icon="❌", color_code=error_color))
        print(block_line("Full Message", error_message, box_color=error_color, line_color=error_color))
        print(block_footer(error_color))


def format_large_number(number: int) -> str:
    """
    Format a large number into a human-readable string with K (thousands), M (millions), etc.

    Args:
        number (int): The number to format.

    Returns:
        str: The formatted number as a string.
    """
    if number >= 1_000_000:
        return f"{number / 1_000_000:.1f}M"  # Format as millions
    elif number >= 1_000:
        return f"{number / 1_000:.1f}K"  # Format as thousands
    return str(number)  # Return as-is for smaller numbers


def print_usage_summary(usage_summary: dict) -> None:
    """
    Display a right-aligned boxed one-liner usage summary with token details and total cost.

    Args:
        usage_summary (dict): A dictionary containing usage details, including:
            - prompt_tokens (int): Number of prompt tokens used.
            - completion_tokens (int): Number of completion tokens used.
            - total_cost (float): Total cost of the interaction.
            - currency (str): The currency of the cost (e.g., "USD").
    """
    # Extract details from the usage summary
    prompt_tokens = usage_summary.get("prompt_tokens", 0)
    completion_tokens = usage_summary.get("completion_tokens", 0)
    total_cost = usage_summary.get("total_cost", 0.0)
    currency = usage_summary.get("currency", "USD")

    # Format token counts
    formatted_prompt_tokens = format_large_number(prompt_tokens)
    formatted_completion_tokens = format_large_number(completion_tokens)

    # Combine tokens and costs into a single line
    usage_line = f"Tokens: ↑ {formatted_prompt_tokens} ↓ {formatted_completion_tokens} | Costs: {currency} {total_cost:.6f}"

    # Define subtle styling
    box_color = "38;5;246"  # Faint gray for subtle visibility

    # Calculate terminal width and padding
    terminal_width = shutil.get_terminal_size().columns
    box_width = len(usage_line) + 4  # Add padding for the box edges
    padding = max(0, terminal_width - box_width)

    # Create the boxed one-liner usage summary
    print(" " * padding + color("╭" + "─" * (box_width - 2) + "╮", box_color))
    print(" " * padding + color(f"│ {usage_line} │", box_color))
    print(" " * padding + color("╰" + "─" * (box_width - 2) + "╯", box_color))


def display_ask_user_question(question: str, suggestions: list, direct_actions: dict = None) -> str:
    """
    Display a question to the user with suggested answers and get their response.
    
    Args:
        question (str): The question to ask the user
        suggestions (list): A list of 2-4 suggested answers
        direct_actions (dict): Optional mapping of option indices to action names
        
    Returns:
        str: The user's selected answer or custom response
    """
    # Define colors
    title_color = "1;97"  # Bold white
    option_color = "38;5;220"  # Gold/yellow for options
    
    # Print the question with bold text for the title but normal text for the question
    print(f"🤖 {color('CODA agent has a question:', '1;97')} {question}")
    # Add a simple separator line below
    print(color("──────────────────────────────────────────────────────────────────────────────────", "38;5;75"))
    print()
    
    # Display suggested options
    print(color('Suggested answers:', '2'))  # Grey text
    
    # Make sure suggestions is a list of strings, not a single string
    if isinstance(suggestions, str):
        # Split by comma if it's a single string
        suggestions = [s.strip() for s in suggestions.split(',')]
    
    for i, suggestion in enumerate(suggestions):
        # Display each suggestion with a number
        print(f"  {color(f'{i+1}', option_color)}. {suggestion}")
    
    # Print instructions for custom response
    print()
    print(color('Enter a number to select an option, or type your own response:', '2'))
    
    # Print separator
    separator = color("┄" * 40, "38;5;240")
    print(f"{separator}")
    
    # Get user input with user emoji
    print(f"👤 Response: ", end="")
    response = input().strip()
    
    return response


def display_detected_images() -> None:
    """
    Display visual feedback when images are detected in user input.
    
    Args:
        placeholder_info: List of dictionaries containing placeholder mappings
    """
    print_intermediate_response('🖼️  Images detected')


def print_agent_header(agent_name: str, status: str = None):
    """
    Print an agent processing header with enhanced styling.
    
    Args:
        agent_name (str): Name of the agent
        status (str, optional): Custom status message. Defaults to None.
    """
    BLUE = "\033[38;5;39m"       # Darker blue color for agent name
    LIGHT_BLUE = "\033[38;5;117m"  # Lighter blue color for status text
    RESET = "\033[0m"            # Reset color
    BOLD = "\033[1m"             # Bold text
    
    # Normalize agent name for comparison
    agent_name_lower = agent_name.lower()
    
    # Set the correct icon and status based on agent type
    if agent_name_lower == DIAGNOSE_AGENT:
        icon = "🔍"
        prefix = "Codefixer agent:"
        status_msg = "Diagnosing your code..."
    elif agent_name_lower == FIX_AGENT:
        icon = "🔍"
        prefix = "Codefixer agent:"
        status_msg = "Fixing your code..."
    elif agent_name_lower == EXPLAIN_AGENT:
        icon = "🔍"
        prefix = "Codefixer agent:"
        status_msg = "Explaining ticket..."
    else:
        icon = "✨"
        prefix = "Agent:"
        status_msg = status or "Processing..."
    
    # Override status if provided
    if status:
        status_msg = status
    
    # Format the agent name properly (only capitalize for the special cases)
    display_name = agent_name
    if agent_name_lower in CODEFIXER_AGENTS:
        display_name = agent_name.capitalize()
    
    # Calculate proper padding for consistent box width
    box_width = 42
    
    # Print the box with consistent styling
    print(f"{BLUE}╭{'─' * (box_width - 2)}╮{RESET}")
    
    # Format the title line with proper spacing and consistent styling
    title = f"{prefix} {display_name}"
    # Manual calculation: box_width = left_border + space + icon + space + title + padding + right_border
    # 42 = 1 + 1 + 2 + 1 + len(title) + padding + 1 (emoji takes 2 visual spaces)
    padding = max(0, box_width - 1 - 1 - 2 - 1 - len(title) - 1)  # left_border + space + icon(2) + space + title + right_border
    print(f"{BLUE}│ {icon} {BOLD}{title}{RESET}{' ' * padding}{BLUE}│{RESET}")
    
    # Print status with proper spacing and lighter color
    # Manual calculation: box_width = left_border + space + content + padding + right_border
    # 42 = 1 + 1 + len(status_msg) + padding + 1
    status_padding = max(0, box_width - 1 - 1 - len(status_msg) - 1)  # left_border + space + content + right_border
    print(f"{BLUE}│{LIGHT_BLUE} {status_msg}{' ' * status_padding}{RESET}{BLUE}│{RESET}")
    
    # Print footer
    print(f"{BLUE}╰{'─' * (box_width - 2)}╯{RESET}")
    print()
