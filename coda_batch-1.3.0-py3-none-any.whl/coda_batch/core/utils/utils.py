import json
from pathlib import Path
from typing import List, Optional, Tuple, Dict, Any

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig


def check_required_env_variables() -> List[Tuple[EnvConfig, str]]:
    """
    Check if the required environment variables are set.
    
    Returns:
        List[Tuple[EnvConfig, str]]: A list of tuples (var_enum, description) for missing variables
    """
    missing_vars = []
    
    if not SETTINGS.get_env_var(EnvConfig.CODA_GEAI_BASE_URL):
        missing_vars.append((EnvConfig.CODA_GEAI_BASE_URL, "GEAI Base URL"))

    # Check for GEAI API key and base URL
    if not SETTINGS.get_env_var(EnvConfig.CODA_GEAI_API_KEY):
        missing_vars.append((EnvConfig.CODA_GEAI_API_KEY, "GEAI API Key"))
        
    return missing_vars


def load_mcp_config(config_path: str) -> Dict[str, Any]:
    """
    Load and parse MCP configuration from a JSON file.
    
    Args:
        config_path: Path to the MCP configuration JSON file
        
    Returns:
        Dict[str, Any]: Parsed MCP configuration dictionary
        
    Raises:
        FileNotFoundError: If the config file doesn't exist
        ValueError: If the config format is invalid or not a dictionary
        IOError: If the file cannot be read
    """
    path = Path(config_path)
    
    if not path.exists():
        raise FileNotFoundError(f"MCP config file not found: {config_path}")
    
    if not path.is_file():
        raise ValueError(f"MCP config path is not a file: {config_path}")
    
    try: 
        with open(path, 'r', encoding='utf-8') as f:
            config = json.load(f)
    except json.JSONDecodeError as e:
        raise ValueError(
            f"Invalid JSON in MCP config file '{config_path}': {e.msg} at line {e.lineno}, column {e.colno}"
        )
    except IOError as e:
        raise IOError(f"Error reading MCP config file '{config_path}': {e}")
    
    if not isinstance(config, dict):
        raise ValueError(
            f"MCP config must be a JSON object (dictionary), got {type(config).__name__}"
        )
    
    return config


def resolve_prompt_input(
    prompt: Optional[str],
    prompt_file: Optional[str],
    piped_input: Optional[str],
) -> Optional[str]:
    """
    Resolve the final prompt from the available input sources.

    Reads and validates the file when ``prompt_file`` is provided, then checks
    that at most one prompt source is active.  Returns the resolved prompt
    string (stripped), or ``None`` when no source was supplied.

    Args:
        prompt: Inline prompt string passed via ``--prompt``.
        prompt_file: Path to a UTF-8 text file passed via ``--prompt-file``.
        piped_input: Content read from piped stdin (already stripped by the caller).

    Returns:
        The resolved prompt string, or ``None`` if no source was provided.

    Raises:
        FileNotFoundError: If ``prompt_file`` path does not exist.
        UnicodeDecodeError: If ``prompt_file`` is not valid UTF-8 text.
        OSError: If ``prompt_file`` cannot be read for any other I/O reason.
        ValueError: If ``prompt_file`` is empty/whitespace-only, or if more
            than one prompt source is active simultaneously.
    """
    prompt_file_content: Optional[str] = None
    if prompt_file:
        try:
            with open(prompt_file, "r", encoding="utf-8") as file_handle:
                prompt_file_content = file_handle.read().strip()
        except (FileNotFoundError, UnicodeDecodeError, OSError):
            raise

        if not prompt_file_content:
            raise ValueError(f"Prompt file is empty: {prompt_file}")

    prompt_sources = [bool(prompt), bool(prompt_file_content), bool(piped_input)]
    if sum(prompt_sources) > 1:
        raise ValueError(
            "Cannot use more than one prompt source. "
            "Choose one of: --prompt (-p), --prompt-file (-pf), or piped input."
        )

    final_prompt = prompt or prompt_file_content or piped_input
    return final_prompt.strip() if final_prompt else None