import sys
import importlib.metadata

from coda_batch.config.constants import SUPPORT_EMAIL, SUPPORT_INTERNAL_SLACK_CHANNEL

BATCH_VERSION = importlib.metadata.version("coda-batch")

def display_help():
    """Display short help when no arguments provided."""
    help_text = f"""coda-batch - Batch client of CODA [version {BATCH_VERSION}]

Usage: coda-batch [OPTIONS]

Examples:
# Start a session with session-id and continue
coda-batch -p "say hi in 10 languages"

# Continue from the last session
coda-batch --lastsession -p "what was my last message about?"

# Using piped input to diagnose an error
echo "@diagnose Explain this error: $(cat traceback.log)" | coda-batch

Common Options:
  -p, --prompt TEXT        The prompt to send to the agent
  -pf, --prompt-file TEXT  Path to a file whose content is used as the prompt
  -ls, --lastsession       Continue most recent session
  -s, --session-id TEXT    Use specific session
  -m, --model TEXT         Provider/model (e.g., openai/gpt-4)
  -r, --rules-path TEXT    Full path to an alternative user-defined rules file
  -t, --tools TEXT         Control which tools the agent can use (comma-delimited list, 'default', or 'all')
  -bsl, --bash-security TEXT   Bash tool security level. A high value will disable all bash security checks.
  --tool-messages-format TEXT   Format for intermediate messages: 'default' or 'jsonl'
  --output-format TEXT          Format for the final response: 'default' or 'json'
  --tool-messages-redirect TEXT Where to send tool messages: 'stdout' (default) or 'stderr'
  -v, --version                Show version information
  -h, --help                   Show help information
      --mcp TEXT               Path to MCP configuration file (Claude Desktop format)

Important: You must provide a non-empty prompt via --prompt (-p), --prompt-file (-pf), or piped input.

For further information, please contact:
- Support Email: {SUPPORT_EMAIL}
- Support (internal users): {SUPPORT_INTERNAL_SLACK_CHANNEL}
"""
    print(help_text, file=sys.stderr)
