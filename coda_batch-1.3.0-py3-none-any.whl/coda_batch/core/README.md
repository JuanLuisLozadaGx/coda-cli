# CODA Batch Core Module

## Introduction

The CODA Batch Core module serves as the foundation of the CODA Batch Command Line Interface (CLI), providing a streamlined framework for non-interactive interactions with the CODA AI agent. This module enables batch processing of prompts, persistence across multiple batch runs, and programmatic integration with automation systems and CI/CD pipelines.

## Architecture Overview

The Batch module is built around a central `BatchCLI` class that coordinates all operations through a single entry point. It employs a Typer-based CLI architecture for command-line argument processing and a SingleAgent for AI interactions.

```mermaid
graph TD
    CLI[BatchCLI Entry Point] --> Typer[Typer App]
    Typer --> ArgParsing[Parse CLI Arguments]
    ArgParsing --> SessionCheck{Session Requested?}
    
    SessionCheck -->|Yes| SessionManager[Session Manager]
    SessionCheck -->|No| DefaultSetup[Default Setup]
    
    SessionManager --> |Load/Create| Session[(Session)]
    DefaultSetup --> AgentSetup[Agent Setup]
    Session --> AgentSetup
    
    AgentSetup --> ToolSetup[Tool Configuration]
    AgentSetup --> MemorySetup[Memory Setup]
    AgentSetup --> ModelSetup[Model Configuration]
    
    ToolSetup --> AgentInstance[Single Agent]
    MemorySetup --> AgentInstance
    ModelSetup --> AgentInstance
    
    AgentInstance --> |Process Request| LLM[Language Model]
    LLM --> |Response with Tool Calls| Tools[Tool Execution]
    Tools --> |Results| AgentInstance
    AgentInstance --> |Final Response| Output[Format Output]
    Output --> |Display| User[User]
    
    SessionCheck -->|Yes| SaveSession[Save Session]
    AgentInstance --> SaveSession
```

### coda-batch - Command-Line Parameters

- `--prompt`, `-p`: The prompt to send to the agent (required, or use piped input)
- `--lastsession`, `-ls`: Continue working with the most recently used session
- `--session-id`, `-s`: Continue working with a specific session ID
- `--model`, `-m`: Provider and model to use (format: `provider/model`)
- `--tools`, `-t`: Control which tools the agent can use (`default`, `all`, or comma-delimited list)
- `--rules-path`, `-r`: Full path to an alternative user-defined rules file
- `--bash-security`, `-bsl`: Bash tool security level (`high` disables bash security checks)
- `--mcp`: Path to MCP configuration file (Claude Desktop format)
- `--version`, `-v`: Display coda-batch version
- `--help`, `-h`: Show help message


## Main Components

### BatchCLI Class

The central class that orchestrates the entire batch execution:

- Initializes the agent and session manager
- Processes command-line arguments
- Configures the agent with tools and context
- Handles the main execution flow
- Manages verbose output and formatting
- Provides session persistence

**Key File**: `coda_batch/core/cli.py`

### Session Management

Enables persistence across multiple batch runs:

- Creates or loads sessions based on user options
- Stores conversation history and memory state
- Preserves tool configurations and context
- Enables continuity in multi-step operations

**Key Files**:
- `coda_batch/core/session/states/batch_client_state.py`
- `coda_core/core/session/session_manager.py` (from coda-core)

### Agent Handler

Manages interactions with the AI agent:

- Prepares messages with appropriate context
- Sets up callbacks for tool execution
- Processes agent responses
- Formats output based on verbosity settings
- Three-agent model: main_agent, mode_agent, active_agent

**Key File**: `coda_batch/core/agent/agent_handler.py`

### Subagent System

Handles specialized agent commands:

- Parses `@` prefix commands
- Executes agents (@diagnose, @fix, @explain)
- Manages context passing between agents
- Supports agent chaining

**Key File**: `coda_batch/core/agent/agents.py`

### UI Components

Provides formatted output for batch operations:

- Colored ANSI output
- Block headers and formatted sections
- Tool execution visualization
- Progress animations
- Output truncation

**Key Files**:
- `coda_batch/core/ui/core.py`
- `coda_batch/core/ui/animation.py`

### Configuration & Constants

Centralized configuration management:

- Client identification
- Tool lists (default, all)
- Bash security settings
- Provider display names
- UI emojis and color codes

**Key File**: `coda_batch/config/constants.py`

### Utilities

Helper functions for common operations:

- Environment variable validation
- MCP configuration loading
- Help system display

**Key Files**:
- `coda_batch/core/utils/utils.py`
- `coda_batch/core/utils/help.py`

## Data Flow

The following diagram illustrates the data flow during a typical batch execution:

```mermaid
sequenceDiagram
    participant User
    participant CLI as BatchCLI
    participant SessionMgr as SessionManager
    participant Agent as SingleAgent
    participant Tools
    
    User->>CLI: coda-batch --prompt "message" [options]
    CLI->>CLI: Parse arguments
    
    alt Session Requested
        CLI->>SessionMgr: resolve_session()
        SessionMgr-->>CLI: Session instance
    else New Execution
        CLI->>CLI: create_default_context()
    end
    
    CLI->>CLI: configure_agent()
    
    alt Files Specified
        CLI->>CLI: add_files_to_context()
    end
    
    CLI->>Agent: process_message(prompt)
    Agent->>Agent: Process with LLM
    
    loop For each tool call
        Agent->>Tools: Execute Tool
        Tools-->>Agent: Tool Result
        
        alt Verbose Mode
            CLI->>User: Display tool execution
        end
    end
    
    Agent-->>CLI: Final Response
    
    alt Session Requested
        CLI->>SessionMgr: save_session()
    end
    
    CLI->>User: Display Final Result
```

## Tool System

The Batch CLI provides access to the same rich tool system as the interactive CLI:

```mermaid
classDiagram
    class Tool {
        <<abstract>>
        +name: str
        +description: str
        +schema: Dict
        +execute(*args, **kwargs)
    }
    
    class FunctionTool {
        +tool_definition: Dict
        +func: Callable
        +execute(*args, **kwargs)
    }
    
    class BashTool {
        +execute_command(command, timeout)
    }
    
    class EditTool {
        +modify_file(file_path, old_string, new_string)
    }
    
    class ViewTool {
        +read_file(file_path, offset, limit)
    }
    
    class ReplaceTool {
        +write_file(file_path, content)
    }
    
    class ThinkTool {
        +process_thought(thought)
    }
    
    class WebSearchTool {
        +search(query)
    }
    
    class ExamineImagesTool {
        +analyze_images(query, file_paths)
    }
    
    Tool <|-- FunctionTool
    FunctionTool <|-- BashTool
    FunctionTool <|-- EditTool
    FunctionTool <|-- ViewTool
    FunctionTool <|-- ReplaceTool
    FunctionTool <|-- ThinkTool
    FunctionTool <|-- WebSearchTool
    FunctionTool <|-- ExamineImagesTool
    
    class ToolManager {
        +register_tool(tool)
        +get_tool(name)
        +enable_tool(name)
        +disable_tool(name)
        +is_tool_enabled(name)
        +get_enabled_tools()
    }
    
    ToolManager o-- Tool
```

The tool system includes:

1. **File Operations**:
   - `view`: Read file contents
   - `edit`: Make targeted edits to files
   - `replace`: Overwrite file contents

2. **Environment Interaction**:
   - `bash`: Execute shell commands

3. **Meta Tools**:
   - `think`: Record reasoning steps without side effects
   - `web_search`: Search the web for information
   - `examine_images`: Analyze image content

All tools are automatically available to the agent during batch processing.

## User Interface Components

Even though CODA Batch is designed for non-interactive use, it includes UI components for progress indication and formatted output:

```mermaid
classDiagram
    class UICore {
        +format_response(response, verbosity)
        +format_tool_call(tool_call)
        +format_tool_result(result)
        +print_error(message)
        +print_warning(message)
        +print_info(message)
        +print_success(message)
    }
    
    class Animation {
        +start_thinking_animation()
        +stop_thinking_animation()
        +show_progress(message)
    }
    
    UICore <-- Animation
```

These components enable:

- Readable formatting of agent responses
- Progress indicators during processing
- Clear distinction between tool calls and results
- Proper error and status messages

## Batch Command Options

CODA Batch supports several command-line options:

```mermaid
classDiagram
    class BatchCLI {
        +run(prompt, lastsession, session_id, model, tools, rules_path, bash_security, mcp_config_path)
    }
    
    class CommandOptions {
        +prompt: str
        +lastsession: bool
        +session_id: Optional[str]
        +model: Optional[str]
        +tools: Optional[str]
        +rules_path: Optional[str]
        +bash_security: Optional[str]
        +mcp_config_path: Optional[str]
    }
    
    BatchCLI --> CommandOptions
```

## Integration with External Systems

CODA Batch is designed for integration with external systems:

```mermaid
flowchart LR
    BatchCLI[CODA Batch] --> ExitCode[Exit Code]
    BatchCLI --> StdOut[Standard Output]
    BatchCLI --> FileSystem[File System Changes]
    
    ExitCode --> CI[CI/CD Pipeline]
    StdOut --> Parser[Output Parser]
    FileSystem --> VCS[Version Control]
    
    subgraph "Integration Examples"
        CI
        GitHooks[Git Hooks]
        IDEExtension[IDE Extension]
        AutomationScript[Automation Script]
    end
    
    BatchCLI --> GitHooks
    BatchCLI --> IDEExtension
    BatchCLI --> AutomationScript
```

## Session Management Flow

The session management system enables continuity across multiple batch executions:

```mermaid
sequenceDiagram
    participant User
    participant BatchCLI
    participant SessionManager
    participant FileSystem
    
    User->>BatchCLI: --newsession
    BatchCLI->>SessionManager: create_session()
    SessionManager->>FileSystem: Write session files
    SessionManager-->>BatchCLI: Session ID
    BatchCLI-->>User: New Session ID
    
    User->>BatchCLI: --session-id "abc123"
    BatchCLI->>SessionManager: load_session("abc123")
    SessionManager->>FileSystem: Read session files
    SessionManager-->>BatchCLI: Session data
    
    User->>BatchCLI: --lastsession
    BatchCLI->>SessionManager: get_latest_session()
    SessionManager->>FileSystem: List and sort sessions
    SessionManager-->>BatchCLI: Latest session
    
    BatchCLI->>SessionManager: save_session()
    SessionManager->>FileSystem: Update session files
```
## UI Implementation Details

Even in a batch context, proper UI feedback is important:

```mermaid
sequenceDiagram
    participant BatchCLI
    participant UICore
    participant Animation
    participant Terminal
    
    BatchCLI->>UICore: print_info("Processing prompt...")
    UICore->>Terminal: Formatted info message
    
    alt Verbose Mode
        BatchCLI->>Animation: start_thinking_animation()
        Animation->>Terminal: Show spinner
        
        loop For each tool call
            BatchCLI->>UICore: format_tool_call(tool_call)
            UICore->>Terminal: Show formatted tool call
            
            BatchCLI->>UICore: format_tool_result(result)
            UICore->>Terminal: Show formatted result
        end
        
        BatchCLI->>Animation: stop_thinking_animation()
    end
    
    BatchCLI->>UICore: format_response(final_response)
    UICore->>Terminal: Formatted final response
```

## Error Handling

The Batch CLI implements robust error handling:

```mermaid
flowchart TD
    Input[User Input] --> Validation[Input Validation]
    
    Validation --> Error{Error?}
    Error -->|Yes| ErrorType{Error Type}
    Error -->|No| Process[Process Request]
    
    ErrorType -->|Invalid Args| ArgError[Argument Error]
    ErrorType -->|Session| SessionError[Session Error]
    ErrorType -->|Agent| AgentError[Agent Error]
    ErrorType -->|Tools| ToolError[Tool Error]
    ErrorType -->|System| SystemError[System Error]
    
    ArgError --> FormatError[Format Error Message]
    SessionError --> FormatError
    AgentError --> FormatError
    ToolError --> FormatError
    SystemError --> FormatError
    
    FormatError --> DisplayError[Display Error]
    DisplayError --> ExitCode[Set Exit Code]
```

