import os
from typing import Dict, Any

from coda_core.core.session.states.client_state import ClientState
from coda_core.config.settings import SETTINGS

class BatchClientState(ClientState):
    """
    Represents Batch-specific state.
    
    This includes selected files, indexing status, and other
    Batch-specific preferences and state.
    
    Attributes:
        current_directory: The current working directory
        batch_preferences: Dictionary of Batch-specific preferences
        selected_files: List of files that provide context for the agent
    """
    
    CLIENT_TYPE = "batch"
    
    def __init__(self):
        """
        Initialize Batch state with default values.
        """       
        # Current working directory
        self.current_directory = os.getcwd()
        
        # Batch-specific preferences
        self.batch_preferences = {}
        
        # Selected files for context
        self.selected_files = []
    

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize to dictionary.
        
        Returns:
            Dict containing all Batch state data
        """
        return {
            "current_directory": self.current_directory,
            "batch_preferences": self.batch_preferences,
            "selected_files": self.selected_files,
        }
    
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BatchClientState":
        """
        Create from dictionary.
        
        Args:
            data: Dictionary containing Batch state data
            
        Returns:
            New BatchClientState instance
        """
        state = cls()
               
        # Restore directory
        state.current_directory = data.get("current_directory", os.getcwd())
        
        # Restore Batch preferences
        state.batch_preferences = data.get("batch_preferences", {})
        
        # Restore selected files
        state.selected_files = data.get("selected_files", [])
        
        return state