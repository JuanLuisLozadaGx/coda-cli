import re
import sys
import typer
from typing import Optional, List
from loguru import logger
from prompt_toolkit import print_formatted_text
from prompt_toolkit.formatted_text import HTML

from coda_core.config.logging.context import set_client_context
from coda_batch.config.constants import (
    CLIENT_NAME, 
    DEFAULT_BASH_SECURITY_LEVEL,
    BASH_SECURITY_ERROR_MESSAGE,
    STARTUP_MISSING_ENV_VARS_MESSAGE,
    SUPPORT_EMAIL,
    SUPPORT_INTERNAL_SLACK_CHANNEL,
    TOOL_MESSAGES_FORMAT_CHOICES,
    OUTPUT_FORMAT_CHOICES,
    TOOL_MESSAGES_REDIRECT_CHOICES,
)
from coda_batch.core.utils.utils import check_required_env_variables, load_mcp_config, resolve_prompt_input
from coda_batch.core.utils.help import display_help
from coda_core.core.session.constants import MEMORY_KEY_MAIN
from coda_core.core.session.session_manager import SessionManager
from coda_core.core.session.states.shared_state import SharedState
from coda_core.config.logging.context import clear_session_context
from coda_core.core.agents.single_agent import SingleAgent
from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.core.agents.manager import AgentManager
from coda_core.core.mcp.service import MCPService

from coda_batch.core.session.states.batch_client_state import BatchClientState
from coda_batch.core.agent.agent_handler import AgentHandler
from coda_batch.core.agent.agents import BatchAgentCommand

class BatchCLI:
    """
    Batch CLI for the CODA agent.
    
    This class provides a command-line interface for interacting with the CODA agent in batch mode.
    """    
    def __init__(
            self,
            load_last_session: bool = False, 
            session_id: Optional[str] = None,
            model: Optional[str] = None,
            rules_path: Optional[str] = None, 
            tools: Optional[List[str]] = None,
            bash_security: Optional[str] = None,
            mcp_config_path: Optional[str] = None,
            tool_messages_format: str = "default",
            output_format: str = "default",
            tool_messages_redirect: str = "stdout",
        ):
        """
        Initialize the BatchCLI class
        
        Args:
            load_last_session: If True, auto-load most recent session
            session_id: Optional ID of a specific session to load
            model: Optional model to use
            rules_path: Optional full path to an alternative user-defined rules file
            tools: Optional list of tools to use, defaults to all tools except the ask_user tool
            bash_security: bash tool security level. A high value will disable all bash security checks.
            mcp_config_path: Optional path to MCP configuration file (Claude Desktop format)
            tool_messages_format: Format for intermediate messages ('default' or 'jsonl')
            output_format: Format for the final response ('default' or 'json')
            tool_messages_redirect: Where to send tool messages ('stdout' or 'stderr')
        """
        self.load_last_session = load_last_session
        self.session_id = session_id
        self.model = model
        self.rules_path = rules_path
        self.main_agent_tools = tools
        self.bash_security = bash_security
        self.mcp_config_path = mcp_config_path
        self.last_interaction_succeeded = False

        from coda_batch.core.formatters.factory import (
            create_tool_messages_formatter,
            create_output_formatter,
            resolve_tool_messages_stream,
        )
        stream = resolve_tool_messages_stream(tool_messages_redirect)
        self.tool_messages_formatter = create_tool_messages_formatter(tool_messages_format, stream=stream)
        self.output_formatter = create_output_formatter(output_format)
        
        # Set client context early in startup for improved log traceability
        set_client_context(CLIENT_NAME)

        # Initialize session
        self._initialize_session()

        # Re-set client context after session initialization.
        # Session initialization may clear or overwrite the logging context,
        # so we must re-apply the client context here to ensure that all subsequent
        # log entries are correctly attributed to this client. This is necessary
        # because session setup can modify or reset context variables used by the logger.
        set_client_context(CLIENT_NAME)

        # Initialize the file editor
        self.file_editor = FileEditor()

    def __enter__(self):
        """
        Set up resources when entering the context manager.
        
        This method is called when entering a 'with' block and handles
        initialization of resources that need proper cleanup.
        
        Returns:
            BatchCLI: The initialized BatchCLI instance
        """
        return self
    
    def _initialize_session(self) -> None:
        """
        Initialize the session manager and handle session loading or creation.

        This method:
        1. Initializes the session manager
        2. Checks for existing sessions
        3. Applies fast-path strategies (create_new_session, load_last_session, session_id)
        """
        # Initialize session manager
        self.session_manager = SessionManager()
        self.session_manager.initialize()

        # Initialize MCP service
        self._import_mcp_servers()

        # Get list of available sessions
        sessions = self.session_manager.list_sessions()

        # Resolve which session to use
        self._resolve_session(sessions)

    def _check_bash_security_level(self) -> None:
        """Check the bash security level and update the bash security preferences."""
        max_auto_approve_level = self.shared_state.preferences["bash_security"]["max_auto_approve_level"]

        # Reject if bash_security override is set to a non-default value and is not high
        if (self.bash_security is not None and self.bash_security != DEFAULT_BASH_SECURITY_LEVEL):
            print_formatted_text(HTML(BASH_SECURITY_ERROR_MESSAGE), file=sys.stderr)
            logger.error("Bash security preferences are not set to high.\nStopping the execution.")
            raise typer.Exit(code=1)

        # Accept if bash_security override is set to default value or is not set
        if (max_auto_approve_level == DEFAULT_BASH_SECURITY_LEVEL) or (self.bash_security and self.bash_security == DEFAULT_BASH_SECURITY_LEVEL):
            # update the bash security preferences
            self.shared_state.preferences["bash_security"]["max_auto_approve_level"] = DEFAULT_BASH_SECURITY_LEVEL
            self.shared_state.preferences["bash_security"]["disable_all_checks"] = True
            return

        print_formatted_text(HTML(BASH_SECURITY_ERROR_MESSAGE), file=sys.stderr)
        logger.error("Bash security preferences are not set to high. Stopping the execution.")
        raise typer.Exit(code=1)

    def _update_model_settings(self) -> None:
        """Validate the inputs of --model and modify the provider/model pair for the session."""
        if not self.model:
            return                                                     

        # Regex: at least one non-slash char, slash, at least one non-slash char                             
        pattern = r'^([^/]+)/([^/]+)$'
        match = re.match(pattern, self.model)                                                             
                                                                                                            
        if not match:                                                                                        
            print_formatted_text(HTML(                                                                       
                f"<ansired>Invalid model format '{self.model}'. "                                            
                "Expected format 'provider/model' (e.g., '--model openai/gpt-5')</ansired>" 
            ))                                                                                               
            raise ValueError

        provider, model = match.groups()

        # Update state                                                                                       
        self.shared_state.single_agent_provider_name = provider                       
        self.shared_state.single_agent_model_name = model
        print_formatted_text(HTML(f"<ansibrightgreen>Updated model settings to {provider}/{model}</ansibrightgreen>"))
        return True

    def _reload_rules(self) -> None:
        """Reload user-defined rules from codarules.md"""
        if not self.rules_path:
            return
        
        rules = self.shared_state.load_user_defined_rules(path=self.rules_path)
        
        # Display appropriate UI messages based on the status
        if rules['status'] in ['success', 'truncated']:
            # Display warning in UI if content was truncated
            if rules['was_truncated']:
                print_formatted_text(HTML(
                    f'<ansibrightred>Warning: Rules file exceeds the character limit '
                    f'({rules["char_count"]} characters) and has been truncated.</ansibrightred>'
                ))
            
            # Display success message
            print_formatted_text(HTML(
                f'<ansibrightgreen>Successfully reloaded user-defined rules from {rules["path"]}</ansibrightgreen>'
            ))
        elif rules['status'] == 'empty':
            print_formatted_text(HTML(
                f'<ansiyellow>Rules file at {rules["path"]} is empty.</ansiyellow>'
            ))
        elif rules['status'] == 'not_found':
            print_formatted_text(HTML(
                f'<ansibrightred>Error: Rules file not found at {rules["path"]}</ansibrightred>'
            ), file=sys.stderr)
            logger.error(f"Rules file not found: {rules['path']}")
            raise typer.Exit(code=1)
        else:
            error_msg = rules.get("error", "Unknown error")
            print_formatted_text(HTML(
                f'<ansibrightred>Error loading rules from {rules["path"]}: {error_msg}</ansibrightred>'
            ), file=sys.stderr)
            logger.error(f"Error loading rules: {error_msg}")
            raise typer.Exit(code=1)
        
        # Update the single agent's system prompt if it exists
        if hasattr(self.shared_state, 'main_agent'):
            # Update the system prompt with the new rules using instance method
            self.shared_state.user_defined_rules['content'] = rules['content']
            logger.info("User-defined rules updated via --rules-path flag")
        return True
    
    def _import_mcp_servers(self) -> None:
        """Import MCP servers from configuration file and connect to them"""
        # Get and initialize MCP service (common to both paths)
        self.mcp_service = MCPService.get()
        if not self.mcp_service._initialized:
            self.mcp_service.initialize()
        
        # If no config path provided, we're done
        if not self.mcp_config_path:
            logger.info("MCP servers initialized")
            return
        
        # Import servers from config file
        try:
            config_data = load_mcp_config(self.mcp_config_path)
            success_count, errors = self.mcp_service.import_servers(config_data)
            
            if success_count > 0:
                print_formatted_text(HTML(
                    f'<ansibrightgreen>Successfully imported {success_count} MCP server(s) from {self.mcp_config_path}</ansibrightgreen>'
                ))
            
            if errors:
                print_formatted_text(HTML(f'<ansiyellow>Failed to import {len(errors)} MCP server(s):</ansiyellow>'))
                for error in errors:
                    print_formatted_text(HTML(f'<ansiyellow>  - {error}</ansiyellow>'))
                    
        except Exception as e:
            error_msg = f"Error importing MCP servers in coda-batch: {e}"
            print_formatted_text(HTML(f'<ansired>{error_msg}</ansired>'))
            logger.error(error_msg)
            raise typer.Exit(code=1)
    
    def _find_latest_available_session(self, sessions: List[dict]) -> Optional[str]:
        """
        Find the latest session that is not locked by another process.
        
        Args:
            sessions (List[dict]): List of session dictionaries sorted by updated_at (newest first)
            
        Returns:
            Optional[str]: ID of the latest available session, or None if all are locked
        """
        if not sessions:
            return None
            
        logger.info(f"Searching for latest available session among {len(sessions)} sessions...")
        
        for idx, session_data in enumerate(sessions):
            session_id = session_data.get("id")
            session_name = session_data.get("name_info", {}).get("current", "Unknown")
            
            if not self.session_manager.is_session_locked_by_other(session_id):
                logger.info(f"Found available session {session_name} (position {idx+1} in session list)")
                return session_id
            else:
                logger.info(f"Session {session_name} is locked by another process, trying next session...")
                
        logger.warning("All sessions are locked by other processes")
        return None
    
    def _resolve_session(self, sessions: List[dict]) -> None:
        """
        Resolve which session to use based on flags and available sessions.
        
        This method ensures a session is always established by the end.
        """
        # Check for --lastsession with no existing sessions first
        if self.load_last_session and not sessions:
            logger.info("No existing sessions found when using --lastsession. Creating a new session instead.")
            self._create_new_session()
            return
            
        # load-last-session and use a specific session-id
        if self.load_last_session and self.session_id:
            if self._try_load_session(session_id=self.session_id):
                return

        # if the session-id exists in sessions and is passed as input, try to load it
        session_id_exists = self.session_id in [session['id'] for session in sessions]
        if self.session_id and session_id_exists:
            if self._try_load_session(session_id=self.session_id):
                return

        # create new session with the provided session-id
        if self.session_id and not session_id_exists:
            self._create_new_session(id=self.session_id)
            return

        # Attempt to load the most recent available session (lastsession expected use case)
        if self.load_last_session and sessions:
            # Find the latest session that isn't locked
            available_session_id = self._find_latest_available_session(sessions)
            
            if available_session_id:
                try:
                    if self._try_load_session(available_session_id):
                        return
                except Exception as e:
                    logger.error(f"Error loading session: {e}")
            
            # If no available session or loading failed, create a new session
            logger.info("Failed to load any available session, creating new session instead")
            self._create_new_session()
            return

        # Default: create a new session
        self._create_new_session()
        return

    def _create_new_session(self, name: str = None, id: str = None) -> None:
        """
        Create a new session and initialize default states.
        
        This helper method encapsulates the common functionality of creating
        a new session and initializing the shared state and Batch state with
        default values.
        
        Args:
            name (str): Optional name for the session
            id (str): Optional ID for the session
        """
        # Create a new session
        self.session_manager.create_session(name=name, id=id)
        
        # Initialize with default states
        self.shared_state = SharedState()
        self.batch_state = BatchClientState()
        
        # Load user-defined rules for new sessions
        self.shared_state.load_user_defined_rules()
        
        self.session_manager.save_session(
            shared_state=self.shared_state,
            client_state=self.batch_state,
            client_type=self.batch_state.CLIENT_TYPE
        )

        # Check the bash security permissions level
        self._check_bash_security_level()

        # Update model settings
        self._update_model_settings()
        
        # Reload user-defined rules
        self._reload_rules()

        # Initialize agent manager
        self.agent_manager = AgentManager(self.shared_state)

        # Initialize default agents
        self.agent_manager.initialize_default_agents()
        
        # Initialize agent handler
        self.agent_handler = AgentHandler(cli=self)
        
        # Initialize MCP session ID if needed
        try:
            if self.session_manager.current_session:
                self.mcp_service.set_current_session_id(self.session_manager.current_session.id)
        except Exception as e:
            logger.debug(f"Could not set MCP session ID: {e}")
                
        logger.info(f"Created new session: {self.session_manager.current_session.name}")
        
    def _try_load_session(self, session_id: str) -> bool:
        """
        Try to load a session, but check if it's locked by another process first.
        
        Args:
            session_id (str): ID of the session to load
            
        Returns:
            bool: True if session was loaded successfully, False otherwise
        """
        # Check if session is locked by another process
        if self.session_manager.is_session_locked_by_other(session_id):
            logger.warning(f"Session {session_id} is locked by another process")
            return False
            
        # If not locked, try to load it
        try:
            # Load the session
            session_data = self.session_manager.load_session(session_id)

            # Initialize states from session data
            self.shared_state = SharedState.from_dict(session_data.shared_state)

            # Check the bash security permissions level
            self._check_bash_security_level()
            
            # Initialize batch state
            batch_state_dict = session_data.client_states.get('batch')
            if batch_state_dict is None:
                logger.error("Session data is missing 'batch' client state.")
                return False
            self.batch_state = BatchClientState.from_dict(batch_state_dict)

            # Check if user-defined rules are present
            if self.shared_state.user_defined_rules:
                rules = self.shared_state.user_defined_rules
                status = rules.get('status')
                path = rules.get('path')
                
                if status == 'success':
                    logger.info(f"Session loaded with user-defined rules from {path} ({rules.get('char_count', 0)} characters)")
                elif status == 'truncated':
                    logger.warning(f"Session loaded with truncated user-defined rules from {path} ({rules.get('char_count', 0)} characters)")
                elif status == 'empty':
                    logger.info(f"Session loaded with empty rules file at {path}")
                elif status == 'not_found':
                    path_info = f"not found at {path}" if path else "path not specified"
                    logger.info(f"Session loaded without user-defined rules ({path_info})")
                elif status == 'error':
                    logger.error(f"Session loaded with error in rules from {path}: {rules.get('error', 'Unknown error')}")
            else:
                logger.info("Session loaded without user-defined rules")

            # Initialize agent manager
            self.agent_manager = AgentManager(self.shared_state)

            # Update model settings
            self._update_model_settings()

            # Reload user-defined rules
            self._reload_rules()

            # Initialize default agents
            self.agent_manager.initialize_default_agents()
            
            # Initialize agent handler
            self.agent_handler = AgentHandler(cli=self)
            
            # Initialize MCP session ID if needed
            try:
                if self.session_manager.current_session:
                    self.mcp_service.set_current_session_id(self.session_manager.current_session.id)    
            except Exception as e:
                logger.debug(f"Could not set MCP session ID: {e}")
            
            print_formatted_text(HTML(f'<ansibrightgreen>Loaded session: {self.session_manager.current_session.name}</ansibrightgreen>'))

            logger.info(f"Loaded session: {self.session_manager.current_session.name}")
            return True
        except Exception as e:
            logger.error(f"Error loading session {session_id}: {e}")
            return False     

    def handle_agent_interaction(self, user_message: str) -> str:
        """
        Handle interaction with the SingleAgent.
        
        Args:
            user_message: The user's message to send to the agent
            
        Returns:
            str: The agent's response
        """
        # Ensure we have an agent handler
        if not hasattr(self, 'agent_handler') or not self.agent_handler:
            logger.info("Agent handler not initialized, creating it")
            self.agent_handler = AgentHandler(cli=self)
        
        # Check for @ prefix commands for subagents
        if user_message.startswith("@"):
            logger.info(f"Detected @ prefix command: {user_message}")
            
            # Ensure we have an agent manager
            if not hasattr(self, 'agent_manager') or not self.agent_manager:
                logger.info("Agent manager not initialized, creating it")
                self.agent_manager = AgentManager(self.shared_state)
                # Initialize default agents
                self.agent_manager.initialize_default_agents()
            
            # Create a batch agent command handler
            agent_command = BatchAgentCommand(cli=self)
            
            # Handle the agent command
            try:
                response = agent_command.handle_agent_command(user_message)
                self.last_interaction_succeeded = True
            except Exception as e:
                self.last_interaction_succeeded = False
                logger.error(f"Error in agent interaction: {e}")
                raise e
            
            # Save session after interaction if we have a valid session
            if hasattr(self, 'session_manager') and self.session_manager.current_session:
                self.session_manager.save_session(
                    shared_state=self.shared_state,
                    client_state=self.batch_state,
                    client_type=self.batch_state.CLIENT_TYPE
                )
                logger.info(f"Saved session: {self.session_manager.current_session.name}")
                
            return response
        
        # Handle regular agent interaction with AgentHandler
        try:
            logger.info("Using AgentHandler for interaction")
            response = self.agent_handler.handle_interaction(user_message)
            
            # Save session after interaction if we have a valid session
            if hasattr(self, 'session_manager') and self.session_manager.current_session:
                self.session_manager.save_session(
                    shared_state=self.shared_state,
                    client_state=self.batch_state,
                    client_type=self.batch_state.CLIENT_TYPE
                )
                logger.info(f"Saved session: {self.session_manager.current_session.name}")
            
            # Check if response is a dictionary (from handle_interaction) or a boolean
            if isinstance(response, dict):
                if response.get("success", False):
                    self.last_interaction_succeeded = True
                    return response.get("content", "")
                else:
                    self.last_interaction_succeeded = False
                    error = response.get("error", "Unknown error")
                    logger.error(f"Error from agent: {error}")
                    return f"Error: {error}"
            else:
                # If it's not a dictionary, assume it's a boolean indicating success/failure
                # and get the last response from the active agent
                active_agent = self.agent_handler.get_active_agent()
                if active_agent and hasattr(active_agent, 'last_response'):
                    last_response = active_agent.last_response
                    if isinstance(last_response, dict):
                        content = last_response.get("content", "")
                    else:
                        content = getattr(last_response, "content", "")
                    self.last_interaction_succeeded = bool(content)
                    return content
                else:
                    self.last_interaction_succeeded = False
                    return "No response available from agent"
                
        except Exception as e:
            self.last_interaction_succeeded = False
            logger.exception(f"Exception in agent interaction: {e}")
            return f"Error: {str(e)}"
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Clean up resources when exiting the context manager."""
        self._perform_cleanup()
        
        # Handle KeyboardInterrupt specially for graceful shutdown
        if exc_type is KeyboardInterrupt:
            logger.warning("KeyboardInterrupt caught during context exit. Performing graceful shutdown.")
            return True
            
        return False
        
    def _should_attempt_rename(self) -> bool:
        """
        Determine if conditions are right to attempt session renaming.
        
        This method checks two conditions:
        1. Whether the session has already been renamed (to prevent multiple renames in the same session).
        2. Whether there are at least two user messages across the "main" memory contexts.
        
        Returns:
            bool: True if the session can be renamed (i.e., it has not been renamed before and there are
            enough user messages in memory), otherwise False.
        """
        # Skip if already renamed by any method (manual or auto)
        if self.session_manager.current_session.has_been_renamed():
            return False
                                                                                                                     
        # Count messages to see if we have enough context                                           
        main_memory = self.shared_state.memories.get(MEMORY_KEY_MAIN)
        main_user_messages = sum(
            1
            for msg in main_memory.retrieve()
            if isinstance(msg, dict) and msg.get("role") == "user"
        ) if main_memory else 0
        
        # Need at least 2 messages for meaningful naming                                                       
        return main_user_messages >= 2
    
    def _perform_cleanup(self) -> None:
        """Clean up resources."""
        try:
            # Shutdown MCP service first to properly close async tasks
            try:
                mcp_service = MCPService.get()
                mcp_service.shutdown()
                logger.info("MCP service shutdown completed")
            except Exception as e:
                logger.warning(f"Error shutting down MCP service: {e}")
            
            # Clean up session manager resources
            if hasattr(self, 'session_manager') and self.session_manager:
                # Save session before closing
                if self.session_manager.current_session and hasattr(self, 'shared_state') and hasattr(self, 'batch_state'):
                    logger.info(f"Saving session before exit: {self.session_manager.current_session.name}")
                    self.session_manager.save_session(
                        shared_state=self.shared_state,
                        client_state=self.batch_state,
                        client_type=self.batch_state.CLIENT_TYPE
                    )
                
                # Close the session manager
                self.session_manager.close()
                
                # Clear session context for logging
                clear_session_context()
                logger.info("Session context cleared")
                
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")

# Typer App
app = typer.Typer(
    help="Coda Batch - Run CODA in batch mode", 
    add_completion=False,
    context_settings={"help_option_names": ["-h", "--help"]}
)

@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    prompt: Optional[str] = typer.Option(None, "--prompt", "-p", help="The prompt to send to the agent"),
    lastsession: bool = typer.Option(False, "--lastsession", "-ls", help="Continue working with the most recently used session"),
    session_id: Optional[str] = typer.Option(None, "--session-id", "-s", help="Continue working with a specific session ID"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Provider and model to use (format: provider/model)"),
    tools: Optional[str] = typer.Option(None, "--tools", "-t", help="Control which tools the agent can use (comma-delimited list, 'default', or 'all')"),
    rules_path: Optional[str] = typer.Option(None, "--rules-path", "-r", help="Full path to an alternative user-defined rules file"),
    bash_security: Optional[str] = typer.Option(None, "--bash-security", "-bsl", help="Bash tool security level. A high value will disable all bash security checks."),
    mcp: Optional[str] = typer.Option(None, "--mcp", help="Path to MCP configuration file (Claude Desktop format)"),
    tool_messages_format: str = typer.Option("default", "--tool-messages-format", help="Format for tool calls and intermediate messages: 'default' (rich) or 'jsonl' (JSON lines)"),
    output_format: str = typer.Option("default", "--output-format", help="Format for the final response: 'default' (raw text) or 'json' (structured JSON)"),
    tool_messages_redirect: str = typer.Option("stdout", "--tool-messages-redirect", help="Where to send tool messages: 'stdout' (default) or 'stderr'"),
    prompt_file: Optional[str] = typer.Option(None, "--prompt-file", "-pf", help="Path to a text file whose content is used as the prompt (useful when the prompt exceeds OS argument length limits)",),
    version: bool = typer.Option(False, "--version", "-v", help="coda-batch version"),
):
    """
    Entry point for the Coda Batch CLI application.
    
    Handles version requests and initializes the CLI for batch processing.
    """
    # Handle version request
    if version:
        import importlib.metadata
        try:
            version = importlib.metadata.version("coda-batch")
            typer.echo(f"Coda Batch v{version}")
        except importlib.metadata.PackageNotFoundError:
            typer.echo("Coda Batch (development version)", err=True)
        raise typer.Exit()
    
    # Check for piped input from stdin
    piped_input = None
    if not sys.stdin.isatty():
        piped_input = sys.stdin.read().strip()

    # Resolve the final prompt from all possible input sources
    try:
        final_prompt = resolve_prompt_input(prompt, prompt_file, piped_input)
    except FileNotFoundError:
        typer.echo(f"Error: Prompt file not found: {prompt_file}", err=True)
        raise typer.Exit(code=1)
    except UnicodeDecodeError:
        typer.echo(f"Error: Prompt file is not valid UTF-8 text: {prompt_file}", err=True)
        raise typer.Exit(code=1)
    except OSError as os_error:
        typer.echo(f"Error reading prompt file '{prompt_file}': {os_error}", err=True)
        raise typer.Exit(code=1)
    except ValueError as value_error:
        typer.echo(f"Error: {value_error}", err=True)
        raise typer.Exit(code=1)

    if not final_prompt:
        display_help()
        raise typer.Exit(code=1)
    
    # Check environment variables
    missing_vars = check_required_env_variables()
    if missing_vars:
        missing_vars_str = ", ".join([var[0].value for var in missing_vars])
        help_message = STARTUP_MISSING_ENV_VARS_MESSAGE.format(missing_vars_str=missing_vars_str, SUPPORT_EMAIL=SUPPORT_EMAIL, SUPPORT_INTERNAL_SLACK_CHANNEL=SUPPORT_INTERNAL_SLACK_CHANNEL)
        typer.echo(help_message, err=True)
        raise typer.Exit(code=1)
    
    # Validate mutually exclusive options
    if sum([lastsession, bool(session_id)]) > 1:
        typer.echo("Error: --lastsession and --session-id cannot be used together", err=True)
        raise typer.Exit(code=1)
    
    if tool_messages_format not in TOOL_MESSAGES_FORMAT_CHOICES:
        typer.echo(f"Error: Invalid --tool-messages-format '{tool_messages_format}'. "
                   f"Accepted: {', '.join(TOOL_MESSAGES_FORMAT_CHOICES)}", err=True)
        raise typer.Exit(code=1)

    if output_format not in OUTPUT_FORMAT_CHOICES:
        typer.echo(f"Error: Invalid --output-format '{output_format}'. "
                   f"Accepted: {', '.join(OUTPUT_FORMAT_CHOICES)}", err=True)
        raise typer.Exit(code=1)

    if tool_messages_redirect not in TOOL_MESSAGES_REDIRECT_CHOICES:
        typer.echo(f"Error: Invalid --tool-messages-redirect '{tool_messages_redirect}'. "
                   f"Accepted: {', '.join(TOOL_MESSAGES_REDIRECT_CHOICES)}", err=True)
        raise typer.Exit(code=1)
    
    # Initialize the CLI with session parameters
    try:
        with BatchCLI(
            load_last_session=lastsession,
            session_id=session_id,
            model=model,
            tools=tools,
            rules_path=rules_path,
            bash_security=bash_security,
            mcp_config_path=mcp,
            tool_messages_format=tool_messages_format,
            output_format=output_format,
            tool_messages_redirect=tool_messages_redirect,
        ) as cli:
            # Most errors should be handled by the agent interaction
            # Leaving this try/except for unexpected errors
            try:
                response = cli.handle_agent_interaction(final_prompt)
                formatted_output = cli.output_formatter.format_response(
                    response=response,
                    user_message=final_prompt,
                    session_id=cli.session_manager.current_session.id if cli.session_manager.current_session else "",
                    session_name=cli.session_manager.current_session.name if cli.session_manager.current_session else "",
                    model=f"{cli.shared_state.single_agent_provider_name}/{cli.shared_state.single_agent_model_name}",
                )
                if formatted_output:
                    print(formatted_output)
            except Exception as e:
                typer.echo(f"Error: {e}", err=True)
                raise typer.Exit(code=1)
            if not cli.last_interaction_succeeded:
                raise typer.Exit(code=1)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(code=1)
            
if __name__ == "__main__":
    app()
