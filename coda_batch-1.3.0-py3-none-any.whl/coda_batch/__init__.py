"""Coda Batch - Batch CLI version of the Neo AI coding agent."""

__version__ = "0.1.0"