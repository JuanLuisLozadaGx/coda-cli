from coda_core.core.tools.constants import (
    TOOL_TYPE_BASIC,
    TOOL_TYPE_EXTENDED,
    TOOL_TYPE_EXPERIMENTAL,
    TOOL_TYPE_MCP,
    TOOL_TYPE_USER_DEFINED,
    TOOL_TYPE_PLUGINS
)

# Support constants
SUPPORT_EMAIL = "coding-agent-tech-support@globant.com"
SUPPORT_INTERNAL_SLACK_CHANNEL = "#g-coda-for-coding"

# Client identification constant
CLIENT_NAME = "batch"

# Emoji mapping for tool types
TOOL_TYPE_EMOJIS = {
    TOOL_TYPE_BASIC: "⚙️ ",        # Gear for basic tools
    TOOL_TYPE_EXTENDED: "🧰",     # Toolbox for extended tools
    TOOL_TYPE_EXPERIMENTAL: "🧪", # Test tube for experimental tools
    TOOL_TYPE_MCP: "🌐",          # Globe for MCP tools
    TOOL_TYPE_USER_DEFINED: "👤", # Person for user-defined tools
    TOOL_TYPE_PLUGINS: "🧩"       # Puzzle piece for plugins
}

# Emoji mapping for specific tool names
TOOL_NAME_EMOJIS = {
    "web_search": "🌐",
    "ask_user": "❓",
    "think": "💭",
    "examine_images": "🖼️",
    "mcp_execute": "🔌",
    "default": "🛠️"               # Default emoji for other tools
}

# Risk level color codes
RISK_LEVEL_COLORS = {
    "safe": "32",        # Green
    "low": "36",         # Cyan
    "medium": "33",      # Yellow
    "high": "31",        # Red
    "critical": "37;41", # White on red background
    "unknown": "35"      # Magenta
}

# Risk level emoji icons
RISK_LEVEL_ICONS = {
    "safe": "✅",
    "low": "ℹ️",
    "medium": "⚠️",
    "high": "🚨",
    "critical": "⛔",
    "unknown": "❓"
}


RECIPE_EMOJIS = {
    "default": "📝",
    "bug": "🐞",
    "test": "🧪",
    "security": "🔒",
    "upgrade": "🔄",
}

RECIPE_DEFAULT_COLOR = "ansibrightblue"

# Provider display names for prettier formatting
PROVIDER_DISPLAY_NAMES = {
    "openai": "OpenAI",
    "vertex_ai": "Vertex AI",
    "azure": "Azure OpenAI",
    "anthropic": "Anthropic",
    "awsbedrock": "AWS Bedrock",
    "xai": "xAI",
    "cohere": "Cohere",
    "azure_ai_foundry": "Azure AI Foundry",
    "openrouter": "OpenRouter",
    "mistral": "Mistral AI",
    "deepseek": "DeepSeek",
    "groq": "Groq",
    "nvidia": "NVIDIA",
    "sambanova": "SambaNova",
    "cerebras": "Cerebras",
    "inception": "Inception Labs"
}

DEFAULT_BASH_SECURITY_LEVEL = "high"

TOOLS_DEFAULT_LIST = [
    "think",
    "view",
    "replace",
    "edit",
    "bash",
    "examine_images",
    "web_search",
    "mcp_execute",
    "omni_parser",
    "run_skill",
]

TOOLS_ALL_LIST = TOOLS_DEFAULT_LIST + ["ask_user"]

TOOL_MESSAGES_FORMAT_DEFAULT = "default"
TOOL_MESSAGES_FORMAT_JSONL = "jsonl"
TOOL_MESSAGES_FORMAT_CHOICES = [TOOL_MESSAGES_FORMAT_DEFAULT, TOOL_MESSAGES_FORMAT_JSONL]

OUTPUT_FORMAT_DEFAULT = "default"
OUTPUT_FORMAT_JSON = "json"
OUTPUT_FORMAT_CHOICES = [OUTPUT_FORMAT_DEFAULT, OUTPUT_FORMAT_JSON]

TOOL_MESSAGES_REDIRECT_STDOUT = "stdout"
TOOL_MESSAGES_REDIRECT_STDERR = "stderr"
TOOL_MESSAGES_REDIRECT_CHOICES = [TOOL_MESSAGES_REDIRECT_STDOUT, TOOL_MESSAGES_REDIRECT_STDERR]


BASH_SECURITY_ERROR_MESSAGE = """
<ansibrightyellow>
⚠️  Bash security preferences are not set to high for this coda-batch session.
Stopping the execution.</ansibrightyellow>

To avoid this error in coda-batch, you can:
1. Pass the --bash-security=high for this session
2. Set the environment variable CODA_DEFAULT_BASH_SECURITY_LEVEL=high in ~/.coda/.env
3. export CODA_DEFAULT_BASH_SECURITY_LEVEL=high in your shell

Option (1) will only affect this coda-batch session
Option (2) will affect other coda clients as well
Option (3) will affect only the current shell session
"""

STARTUP_MISSING_ENV_VARS_MESSAGE = """
The following environment variables are not set:
{missing_vars_str}

You can use coda-cli --reconfigure to set them or directly set them in the ~/.coda/.env file.

For further information, please contact:
- Support Email: {SUPPORT_EMAIL}
- Support (internal users): {SUPPORT_INTERNAL_SLACK_CHANNEL}
"""

