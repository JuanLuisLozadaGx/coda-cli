from loguru import logger

from coda_cli.pre_init_checks import get_app_with_checks


def main():
    """
    Main entry point for the CODA CLI application.
    This function is exported at the module level for use by packaging systems.
    """
    try:
        app = get_app_with_checks()
        if app:
            app()
    except KeyboardInterrupt:
        logger.warning("\nProgram interrupted by user.")
    except Exception as e:
        logger.exception(f"An error occurred: {e}")
    finally:
        logger.info("Exiting program.")


if __name__ == "__main__":
    main()
