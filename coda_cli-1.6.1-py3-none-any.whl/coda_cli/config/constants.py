from coda_core.core.tools.constants import (
    TOOL_TYPE_BASIC,
    TOOL_TYPE_EXTENDED,
    TOOL_TYPE_EXPERIMENTAL,
    TOOL_TYPE_MCP,
    TOOL_TYPE_USER_DEFINED,
    TOOL_TYPE_PLUGINS
)

# Client identification constant
CLIENT_NAME = "cli"

# Emoji mapping for tool types
TOOL_TYPE_EMOJIS = {
    TOOL_TYPE_BASIC: "⚙️ ",        # Gear for basic tools
    TOOL_TYPE_EXTENDED: "🧰",     # Toolbox for extended tools
    TOOL_TYPE_EXPERIMENTAL: "🧪", # Test tube for experimental tools
    TOOL_TYPE_MCP: "🌐",          # Globe for MCP tools
    TOOL_TYPE_USER_DEFINED: "👤", # Person for user-defined tools
    TOOL_TYPE_PLUGINS: "🧩"       # Puzzle piece for plugins
}

# Emoji mapping for specific tool names
TOOL_NAME_EMOJIS = {
    "web_search": "🌐",
    "ask_user": "❓",
    "think": "💭",
    "examine_images": "🖼️",
    "mcp_execute": "🔌",
    "default": "🛠️"               # Default emoji for other tools
}

# Risk level color codes
RISK_LEVEL_COLORS = {
    "safe": "32",        # Green
    "low": "36",         # Cyan
    "medium": "33",      # Yellow
    "high": "31",        # Red
    "critical": "37;41", # White on red background
    "unknown": "35"      # Magenta
}

# Risk level emoji icons
RISK_LEVEL_ICONS = {
    "safe": "✅",
    "low": "ℹ️",
    "medium": "⚠️",
    "high": "🚨",
    "critical": "⛔",
    "unknown": "❓"
}


RECIPE_EMOJIS = {
    "default": "📝",
    "bug": "🐞",
    "test": "🧪",
    "security": "🔒",
    "upgrade": "🔄",
}

RECIPE_DEFAULT_COLOR = "ansibrightblue"

# Provider display names for prettier formatting
PROVIDER_DISPLAY_NAMES = {
    "openai": "OpenAI",
    "vertex_ai": "Vertex AI",
    "azure": "Azure OpenAI",
    "anthropic": "Anthropic",
    "awsbedrock": "AWS Bedrock",
    "xai": "xAI",
    "cohere": "Cohere",
    "azure_ai_foundry": "Azure AI Foundry",
    "openrouter": "OpenRouter",
    "mistral": "Mistral AI",
    "deepseek": "DeepSeek",
    "groq": "Groq",
    "nvidia": "NVIDIA",
    "sambanova": "SambaNova",
    "cerebras": "Cerebras",
    "inception": "Inception Labs"
}

# Coda for Coding relevant links and contact information
SLACK_CHANNEL_NAME = "#g-coda-for-coding"
SLACK_CHANNEL_URL = "https://globant.slack.com/archives/C07LDG3HJFR"
SUPPORT_EMAIL = "coda-tech-support@globant.com"
FAQ_URL = "https://docs.google.com/document/d/16EZHUO4l4tKBn7rJd6JlpkE8e3JkiW4hC8EOFtzs_us"
