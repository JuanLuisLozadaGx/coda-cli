import os


def print_migration_success():
    """
    Print a success message after migration is complete.
    """
    print("\033[1;32mMigration completed successfully!\033[0m\n")
    print("The following items were migrated:")
    print("  \033[1;33m• Environment variables\033[0m")
    print("  \033[1;33m• Configuration files: tools, logs, and recipes\033[0m")
    print("  \033[1;33m• Sessions database\033[0m\n")
    coda_dir = os.path.join(os.path.expanduser("~"), ".coda")
    print(f"Migration directory: \033[1;33m{coda_dir}\033[0m\n")
