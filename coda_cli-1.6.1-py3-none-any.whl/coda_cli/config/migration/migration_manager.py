import shutil
import re
import os

from loguru import logger
from dotenv import dotenv_values
from coda_core.config.env_config import EnvConfig
from coda_core.config.settings import SETTINGS

from coda_cli.config.env_config import CLIEnvConfig
from coda_cli.config.constants import CLIENT_NAME
from coda_cli.core.ui.core import display_asterisk_banner

"""
Set of environment variable names whose values should NOT be translated during migration from Neo to CODA.

These variables are migrated as-is because their values may contain the substring "neo"
as part of repository configuration, credentials, or URLs that should remain unchanged.
"""
NON_TRANSLATABLE_ENV_VARS: set[str] = {
    "NEO_PYPI_REPO_FEED",
    "NEO_PYPI_REPO_HOST",
    "NEO_PYPI_REPO_ORG",
    "NEO_PYPI_REPO_PROJECT",
    "NEO_PYPI_REPO_TOKEN",
    "NEO_PYPI_REPO_URL",
    "NEO_PYPI_REPO_USERNAME",
}

def _directory_has_files(directory: str) -> bool:
    """
    Check if a directory contains any files.

    Args:
        directory (str): The directory path to check for files.

    Returns:
        bool: Whether the directory has any files.
    """
    if not os.path.exists(directory):
        return False
    return any(
        os.path.isfile(os.path.join(directory, file)) for file in os.listdir(directory)   
    )


def _are_coda_directories_empty(coda_dir: str) -> bool:
    """
    Verify that all the directories in the CODA directory are empty.

    Args:
        coda_dir (str): The path to the CODA directory.

    Returns:
        bool: Whether all the CODA directories are empty or not.
    """
    if not os.path.exists(coda_dir):
        return True

    directories_to_check = [".command_history", ".tools", ".backups", ".logs", "recipes"]
    for dir_to_check in directories_to_check:
        dir_path = os.path.join(coda_dir, dir_to_check)
        if dir_to_check != ".logs":
            if _directory_has_files(dir_path):
                return False
        else:
            if _directory_has_files(dir_path):
                # Verify that only the default log file exists
                for log_file in os.listdir(dir_path):
                    if log_file != "coda-core.log":
                        return False

    return True


def needs_migration() -> bool:
    """
    Verify if a migration needs to be performed, migrating configuration from
    the ~/.neo directory to the ~/.coda directory.

    To decide whether a migration is needed or not, the following conditions are check:
    - If the migration already happened, the migration is avoided.
    - If the Neo directory was never used, the migration is avoided.
    - If any CODA configuration files exist, the migration is avoided.
    - If any Neo configuration files exist, the migration is allowed.

    Returns:
        bool: Whether a migration needs to be performed or not.
    """
    # If the migration already happened, the migration is avoided
    if SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_HAS_MIGRATED_FROM_NEO, CLIENT_NAME).lower() == "true":
        return False

    home_dir = os.path.expanduser("~")

    # If Neo was never used, the migration is avoided
    neo_dir = os.path.join(home_dir, ".neo")
    if not os.path.exists(neo_dir):
        return False

    # If any CODA configuration files exist, the migration is avoided
    if not _are_coda_directories_empty(SETTINGS.coda_dir):
        return False

    # If any Neo configuration files exist, the migration is allowed
    return any(
        os.path.isfile(os.path.join(neo_dir, file)) for file in os.listdir(neo_dir)
    )


def _migrate_environment_variables(neo_env_path: str) -> bool:
    """
    Migrate existing environment variables from the Neo to Coda.

    Environment variables are migrated only if their translated values differ from the current settings.

    Args:
        neo_env_path (str): The path to the Neo environment file.

    Returns:
        bool: True if migration was successful, False otherwise.
    """
    print("\033[1;33mMigrating environment variables...\033[0m")

    neo_environment_values = dotenv_values(neo_env_path)
    for key, value in neo_environment_values.items():
        translated_key_name = re.sub(r'^NEO_', 'CODA_', key) # Keys start with "NEO_"

        if key in NON_TRANSLATABLE_ENV_VARS:
            translated_value = value  # Preserve original value for repo-related variables to avoid breaking URLs/credentials
        else:
            translated_value = value.replace("neo", "coda")  # Replace "neo" with "coda" in other values

        try:
            valid_key = EnvConfig(translated_key_name)
            if SETTINGS.get_env_var(valid_key) != translated_value:
                SETTINGS.set_env_var(valid_key, translated_value)
        except ValueError:
            logger.warning(f"Existing Neo environment variable: {key} had no valid renaming: {translated_key_name} for migration.")

    print("\033[1;32mEnvironment variables migrated successfully\033[0m\n")
    return True


def _migrate_logs(neo_logs_path: str, coda_logs_path: str) -> bool:
    """
    Migrate existing logs from Neo to Coda.

    This function changes the log naming format from 'neo-ai' to 'coda-core' and moves
    them to the ~/.coda/.logs directory.

    Args:
        neo_logs_path (str): The path to the Neo logs directory.
        coda_logs_path (str): The path to the Coda logs directory.

    Returns:
        bool: True if migration was successful, False otherwise.
    """
    print("\033[1;33mMigrating log files...\033[0m")

    for log_file in os.scandir(neo_logs_path):
        try:
            if "neo-ai" in log_file.name:
                new_name = log_file.name.replace("neo-ai", "coda-core")

                src_name = os.path.join(neo_logs_path, log_file.name)
                dst_name = os.path.join(coda_logs_path, new_name)

                shutil.copyfile(src_name, dst_name)
        except (OSError, shutil.Error) as e:
            logger.exception(f"Error renaming log file: {log_file.name}. Error: {e}")
            return False

    print("\033[1;32mLog files migrated successfully\033[0m\n")
    return True

def _migrate_directory(src_root_path: str, dst_root_path: str, dir_name: str, migrated_dir_message: str) -> bool:
    """
    Migrate the content of a directory from the source to the destination.

    Args:
        src_root_path (str): The root path of the source directory.
        dst_root_path (str): The root path of the destination directory.
        dir_name (str): The name of the directory to migrate.
        migrated_dir_message (str): A message describing the directory being migrated.

    Returns:
        bool: True if migration was successful, False otherwise.
    """
    try:
        print(f"\033[1;33mMigrating {migrated_dir_message}...\033[0m")

        src_path = os.path.join(src_root_path, dir_name)
        if not os.path.exists(src_path):
            return True # Nothing to migrate

        dst_path = os.path.join(dst_root_path, dir_name)
        shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
        print(f"\033[1;32m{migrated_dir_message} migrated successfully\033[0m\n")
        return True
    except shutil.Error as e:
        logger.exception(f"Error migrating directory '{dir_name}'. Error: {e}")
        return False


def handle_migration() -> bool:
    """
    Handle the migration process from ~/.neo to ~/.coda.

    Returns:
        bool: True if migration was successful, False otherwise.
    """
    display_asterisk_banner(
        messages=["Starting migration from Neo to CODA.", "This might take a few seconds..."]
    )

    # This path is fixed because Neo only placed its configuration in the home directory
    neo_dir = os.path.join(os.path.expanduser("~"), ".neo")

    coda_dir = SETTINGS.coda_dir
    if not os.path.exists(coda_dir):
        os.makedirs(coda_dir, exist_ok=True)

    # Migrate environment variables
    neo_env_path = os.path.join(neo_dir, ".env")
    if os.path.exists(neo_env_path):
        if not _migrate_environment_variables(neo_env_path):
            return False

    # Migrate all the log files
    neo_logs_path = os.path.join(neo_dir, ".logs")
    if os.path.exists(neo_logs_path):
        # Initialize the coda logs if needed
        coda_logs_path = os.path.join(coda_dir, ".logs")
        if not os.path.exists(coda_logs_path):
            os.makedirs(coda_logs_path, exist_ok=True)

        if not _migrate_logs(neo_logs_path, coda_logs_path):
            return False

    # Migrate command_history
    if not _migrate_directory(neo_dir, coda_dir, ".command_history", "command history"):
        return False

    # Migrate tools
    if not _migrate_directory(neo_dir, coda_dir, ".tools", "tools"):
        return False

    # Migrate recipes
    if not _migrate_directory(neo_dir, coda_dir, "recipes", "recipes"):
        return False

    # Migrate Sessions database
    # This might look like an over simplified solution but since it's a fresh migration there shouldn't be existing sessions in ~/.coda
    src_sessions_db = os.path.join(neo_dir, "sessions.db")
    if os.path.exists(src_sessions_db):
        try:
            print("\033[1;33mMigrating sessions...\033[0m")
            dst_sessions_db = os.path.join(coda_dir, "sessions.db")
            shutil.copy(src_sessions_db, dst_sessions_db)
            print("\033[1;32mSessions migrated successfully\033[0m\n")
        except shutil.Error as e:
            logger.exception(f"Error migrating sessions database. Error: {e}")
            return False

    # If we reached this point, the migration was successful
    SETTINGS.set_env_var(CLIEnvConfig.CODA_CLI_HAS_MIGRATED_FROM_NEO, "true", CLIENT_NAME)
    return True
