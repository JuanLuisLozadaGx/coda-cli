# Configuration Module

The configuration module provides a centralized system for managing CLI-specific settings and environment variables in the CODA CLI application, integrating seamlessly with the CODA Core configuration system.

## Overview

This module handles CLI-specific configuration aspects:

- **CLI Environment Variables**: Managing CLI-specific settings like verbosity, auto-completion, and theme
- **CODA Core Integration**: Registering CLI configuration with the CODA Core settings system
- **Type Safety**: Using enum-based configuration keys to prevent errors
- **Automatic Initialization**: Package-level setup ensuring configuration is always available

## Architecture

The CODA CLI configuration module is built on top of the CODA Core configuration system, extending it with CLI-specific settings while maintaining full compatibility with the unified configuration API.

### 1. Client Configuration Registration

The CLI registers itself as a client with the CODA Core settings system, providing its own configuration schema and default values.

```python
from coda_cli.config.env_config import CLIEnvConfig
from coda_cli.config.setup import CLI_DEFAULT_VALUES
from coda_core.config.settings import SETTINGS

# CLI configuration is automatically registered when the package is imported
# This happens in coda_cli/config/setup.py
SETTINGS.register_client_config(
    client_name="cli",
    config_enum_class=CLIEnvConfig,
    defaults=CLI_DEFAULT_VALUES
)
```

### 2. Configuration Components

| Component | Purpose | Location |
|-----------|---------|----------|
| `CLIEnvConfig` | Enum defining CLI configuration keys | [`env_config.py`](env_config.py) |
| `CLI_DEFAULT_VALUES` | Default values for CLI settings | [`setup.py`](setup.py) |
| `setup.py` | Registration and initialization logic | [`setup.py`](setup.py) |
| Package initialization | Automatic config setup on import | [`__init__.py`](..//__init__.py) |

### 3. CLI Environment Variables

The `CLIEnvConfig` enum defines all CLI-specific environment variables:

| Variable | Purpose | Default Value | Description |
|----------|---------|---------------|-------------|
| `CODA_CLI_VERBOSE` | Enable verbose output | `true` | Controls detailed logging and output |
| `CODA_CLI_AUTO_COMPLETE` | Enable auto-completion | `true` | Controls command and path auto-completion |
| `CODA_CLI_THEME` | CLI color theme | `dark` | Visual theme for CLI output (`dark` or `light`) |

### 4. Configuration Access Patterns

#### Getting Configuration Values

```python
from coda_core.config.settings import SETTINGS
from coda_cli.config.env_config import CLIEnvConfig

# Get CLI configuration values
verbose = SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_VERBOSE, client_name="cli")
auto_complete = SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_AUTO_COMPLETE, client_name="cli")
theme = SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_THEME, client_name="cli")
```

#### Setting Configuration Values

```python
# Update CLI configuration values
SETTINGS.set_env_var(CLIEnvConfig.CODA_CLI_THEME, "light", client_name="cli")
SETTINGS.set_env_var(CLIEnvConfig.CODA_CLI_VERBOSE, "false", client_name="cli")
```

### 5. File Structure and Persistence

The CLI configuration follows the CODA Core client configuration pattern:

```
~/.coda/
├── .env                    # CODA Core settings
├── .env.cli                # CLI-specific settings (auto-created)
└── ...
```

#### Environment Variable Precedence

The configuration system follows this precedence order (highest to lowest):

1. **Environment Variables**: `CODA_CLI_VERBOSE`, `CODA_CLI_AUTO_COMPLETE`, `CODA_CLI_THEME`
2. **Client Config File**: Values in `~/.coda/.env.cli`
3. **Default Values**: Values defined in `CLI_DEFAULT_VALUES`

### 6. Automatic Initialization

The CLI configuration is automatically initialized when the `coda_cli` package is imported:

```python
# In coda_cli/__init__.py
import coda_cli.config.setup  # Triggers automatic registration
```

This ensures that:
- Configuration is always available when using any CLI functionality
- No manual setup is required
- The CLI is properly registered with the CODA Core system

### 7. Type Safety and Validation

The configuration system provides several layers of type safety:

#### Enum-Based Keys
```python
from enum import Enum

class CLIEnvConfig(Enum):
    CODA_CLI_VERBOSE = 'CODA_CLI_VERBOSE'
    CODA_CLI_AUTO_COMPLETE = 'CODA_CLI_AUTO_COMPLETE'
    CODA_CLI_THEME = 'CODA_CLI_THEME'
```

#### Default Value Mapping
```python
CLI_DEFAULT_VALUES = {
    CLIEnvConfig.CODA_CLI_VERBOSE: "true",
    CLIEnvConfig.CODA_CLI_AUTO_COMPLETE: "true",
    CLIEnvConfig.CODA_CLI_THEME: "dark"
}
```

This approach prevents:
- Typos in configuration key names
- Invalid configuration keys
- Missing default values
- Runtime configuration errors

### 8. Error Handling and Resilience

The configuration system includes robust error handling:

#### Duplicate Registration Prevention
```python
if SETTINGS.is_client_registered(client_name="cli"):
    logger.warning("CLI configuration already registered, skipping registration")
    return
```

#### Registration Error Handling
```python
try:
    SETTINGS.register_client_config(
        client_name="cli",
        config_enum_class=CLIEnvConfig,
        defaults=CLI_DEFAULT_VALUES
    )
    logger.info("CLI configuration registered successfully")
except Exception as e:
    logger.error(f"Failed to register CLI settings: {e}")
    raise
```

## Usage Examples

### Basic Configuration Access

```python
from coda_core.config.settings import SETTINGS
from coda_cli.config.env_config import CLIEnvConfig

# Check if verbose mode is enabled
if SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_VERBOSE, client_name="cli") == "true":
    print("Verbose mode is enabled")

# Get the current theme
theme = SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_THEME, client_name="cli")
print(f"Current theme: {theme}")
```

### Configuration Updates

```python
# Switch to light theme
SETTINGS.set_env_var(CLIEnvConfig.CODA_CLI_THEME, "light", client_name="cli")

# Disable auto-completion
SETTINGS.set_env_var(CLIEnvConfig.CODA_CLI_AUTO_COMPLETE, "false", client_name="cli")
```

### Integration in CLI Commands

```python
class SomeCommand:
    def execute(self):
        # Check configuration before executing
        verbose = SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_VERBOSE, client_name="cli")
        
        if verbose == "true":
            print("Executing command in verbose mode...")
        
        # Command logic here...
```

## Testing

The configuration module includes comprehensive unit tests covering:

- Configuration structure validation
- Registration success and failure scenarios
- Configuration access and modification
- Integration with CODA Core system
- Error handling and edge cases

### Running Tests

```bash
# Run CLI config tests with coverage
poetry run python -m pytest tests/unit/coda_cli/config/test_config_setup.py --cov=coda_cli/config --cov-report=term-missing -v
```

### Test Coverage

The test suite achieves 100% coverage on core configuration modules:

- `coda_cli/config/env_config.py`: 100% coverage
- `coda_cli/config/setup.py`: 100% coverage

## Integration with CODA Core

The CLI configuration integrates seamlessly with the CODA Core configuration system:

### Unified API
- Uses the same `get_env_var()` and `set_env_var()` methods as core settings
- Follows the same client configuration patterns
- Maintains compatibility with existing CODA Core configuration features

### Conflict Prevention
- Automatic detection of configuration key conflicts
- Prevention of duplicate client registration
- Validation of enum-based configuration keys

### File Management
- Automatic creation of client-specific `.env.cli` file
- Proper file locking and synchronization
- Environment variable precedence handling

## Best Practices

### 1. Always Use Enum Keys
```python
# ✅ Correct - using enum
SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_THEME, client_name="cli")

# ❌ Incorrect - using string
SETTINGS.get_env_var("CODA_CLI_THEME", client_name="cli")
```

### 2. Include Client Name
```python
# ✅ Correct - specifying client name
SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_VERBOSE, client_name="cli")

# ❌ Incorrect - missing client name (will look in core settings)
SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_VERBOSE)
```

### 3. Handle Configuration Gracefully
```python
try:
    theme = SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_THEME, client_name="cli")
except Exception as e:
    logger.warning(f"Failed to get theme setting, using default: {e}")
    theme = "dark"
```

## Future Enhancements

Potential future improvements to the CLI configuration system:

1. **Configuration Validation**: Add validation for configuration values (e.g., theme must be "dark" or "light")
2. **Dynamic Configuration**: Support for runtime configuration changes without restart
3. **Configuration Profiles**: Support for multiple configuration profiles (development, production, etc.)
4. **Configuration UI**: Command-line interface for managing configuration settings
5. **Configuration Import/Export**: Ability to backup and restore configuration settings

## Migration Guide

### From Legacy Configuration

If migrating from a legacy configuration system:

1. **Update Imports**: Change from direct environment variable access to using the Settings API
2. **Use Enum Keys**: Replace string-based configuration keys with enum members
3. **Add Client Name**: Include the `client_name="cli"` parameter in all configuration calls
4. **Update Tests**: Modify tests to use the new configuration API

### Example Migration

```python
# Before (legacy)
import os
verbose = os.getenv("CODA_CLI_VERBOSE", "true")

# After (new system)
from coda_core.config.settings import SETTINGS
from coda_cli.config.env_config import CLIEnvConfig

verbose = SETTINGS.get_env_var(CLIEnvConfig.CODA_CLI_VERBOSE, client_name="cli")
```

This migration ensures type safety, centralized configuration management, and integration with the broader CODA ecosystem.