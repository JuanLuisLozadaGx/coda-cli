from loguru import logger

from coda_cli.config.env_config import CLIEnvConfig
from coda_cli.config.constants import CLIENT_NAME
from coda_core.config.settings import SETTINGS

# Register CLI configuration with core Settings
CLI_DEFAULT_VALUES = {
    CLIEnvConfig.CODA_CLI_VERBOSE: "true",
    CLIEnvConfig.CODA_CLI_AUTO_COMPLETE: "true",
    CLIEnvConfig.CODA_CLI_THEME: "dark",
    CLIEnvConfig.CODA_CLI_DEFAULT_REASONING_EFFORT: "default",
    CLIEnvConfig.CODA_CLI_HAS_MIGRATED_FROM_NEO: "false",
}

# Register with core Settings using new method signature
try:
    if not SETTINGS.is_client_registered(client_name=CLIENT_NAME):
        SETTINGS.register_client_config(
            client_name=CLIENT_NAME,
            config_enum_class=CLIEnvConfig,
            defaults=CLI_DEFAULT_VALUES
        )
        logger.info("CLI configuration registered successfully")
    else:
        logger.warning("CLI configuration already registered, skipping registration")
except Exception as e:
    logger.error(f"Failed to register CLI settings: {e}")
    raise
