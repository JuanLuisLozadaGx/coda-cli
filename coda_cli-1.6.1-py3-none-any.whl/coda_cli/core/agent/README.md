# CODA CLI Agent Module

## Overview

The Agent module in CODA CLI is responsible for managing interactions with AI agents, including state management, context preparation, and handling responses. The module implements a three-agent model to maintain clear state separation across different operational modes.

## Three-Agent Model

The AgentHandler maintains three key agent references:

```
┌─────────────────────────────────────────────────────┐
│                   AgentHandler                      │
├─────────────────┬───────────────────┬───────────────┤
│   main_agent    │    mode_agent     │  active_agent │
│ (persistent)    │ (mode-specific)   │   (pointer)   │
└─────────────────┴───────────────────┴───────────────┘
```

- **main_agent**: The persistent main agent that's preserved across all mode switches. It maintains consistent state and memory throughout the session.

- **mode_agent**: The current mode's specialized agent (e.g., PlanningModeAgent). This agent is active only when a specific mode is enabled.

- **active_agent**: A pointer that always points to whichever agent is currently handling interactions - either the main_agent or the mode_agent.

## State Management

The AgentHandler tracks important state flags:

- **using_mode_agent**: Boolean flag indicating whether a mode-specific agent is currently active.
- **is_agent_executing**: Boolean flag used to track ongoing agent execution (important for handling interruptions via Ctrl+C).

## Agent Initialization and Persistence

The main agent is initialized at startup or restored from shared state:

```mermaid
sequenceDiagram
    participant CLI
    participant AgentHandler
    participant SharedState
    participant Memory
    
    CLI->>AgentHandler: Initialize
    AgentHandler->>SharedState: Check for existing main_agent
    
    alt Main agent exists in shared_state
        SharedState-->>AgentHandler: Return existing main_agent
        AgentHandler->>AgentHandler: Restore main_agent
        AgentHandler->>Memory: Sync with latest memory
    else No main agent in shared_state
        AgentHandler->>SharedState: Create new main_agent
        SharedState-->>AgentHandler: Return new main_agent
        AgentHandler->>SharedState: Store main_agent reference
    end
    
    AgentHandler->>AgentHandler: Set active_agent = main_agent
```

The initialization process:
1. Checks if a main agent already exists in shared_state (from previous mode switches)
2. If not, creates a new main agent
3. Stores the agent in both local state and shared_state for persistence
4. Sets it as active if not currently using a mode agent
5. Ensures the agent has the latest memory reference

## Mode Switching

The AgentHandler provides methods to switch between agents:

### switch_to_mode_agent

```mermaid
sequenceDiagram
    participant Mode
    participant AgentHandler
    participant SharedState
    
    Mode->>AgentHandler: switch_to_mode_agent(mode_agent)
    AgentHandler->>AgentHandler: Ensure main_agent exists
    AgentHandler->>AgentHandler: mode_agent = provided agent
    AgentHandler->>AgentHandler: active_agent = mode_agent
    AgentHandler->>AgentHandler: using_mode_agent = true
    AgentHandler->>SharedState: Preserve main_agent reference
```

This method:
1. Ensures the main_agent exists
2. Stores the provided mode_agent
3. Sets the active_agent pointer to the mode_agent
4. Sets the using_mode_agent flag to true
5. Preserves the main_agent in shared_state for later restoration

### switch_to_main_agent

```mermaid
sequenceDiagram
    participant Mode
    participant AgentHandler
    
    Mode->>AgentHandler: switch_to_main_agent()
    AgentHandler->>AgentHandler: Ensure main_agent exists
    AgentHandler->>AgentHandler: active_agent = main_agent
    AgentHandler->>AgentHandler: using_mode_agent = false
    AgentHandler->>AgentHandler: Clear mode_agent reference
```

This method:
1. Ensures the main_agent exists
2. Sets the active_agent pointer back to the main_agent
3. Sets the using_mode_agent flag to false
4. Clears the mode_agent reference

## Interaction Flow

The `handle_interaction` method manages the complete interaction lifecycle:

```mermaid
sequenceDiagram
    participant CLI
    participant AgentHandler
    participant Agent
    participant Callbacks
    
    CLI->>AgentHandler: handle_interaction(user_message)
    AgentHandler->>AgentHandler: Format message with context
    AgentHandler->>AgentHandler: Renew session lock
    
    alt Mode agent provided
        AgentHandler->>AgentHandler: switch_to_mode_agent(mode_agent)
    else No active agent
        AgentHandler->>AgentHandler: Initialize and switch to main agent
    end
    
    AgentHandler->>Callbacks: Create callbacks with animations
    AgentHandler->>Agent: get_response(formatted_message, callbacks)
    
    loop For each tool call
        Agent->>Callbacks: on_tool_call
        Callbacks-->>CLI: Display tool call
        Agent->>Tool: Execute tool
        Tool-->>Agent: Return result
        Agent->>Callbacks: on_tool_result
        Callbacks-->>CLI: Display result
    end
    
    Agent-->>AgentHandler: Final response
    AgentHandler->>CLI: Return formatted response
```

This process:
1. Prepares the message with appropriate context (e.g., selected files)
2. Sets up animations and callbacks for tool execution and results
3. Processes the interaction with the active agent
4. Handles exceptions and ensures proper cleanup

## Subagent Handling

The `handle_interaction_with_agent` method allows interaction with specialized agents:

```mermaid
sequenceDiagram
    participant CLI
    participant AgentsCommand
    participant AgentHandler
    participant SubAgent
    
    CLI->>AgentsCommand: Execute(@agent-name request)
    AgentsCommand->>AgentHandler: handle_interaction_with_agent(message, subagent)
    
    AgentHandler->>AgentHandler: Store original active_agent
    AgentHandler->>AgentHandler: Temporarily set active_agent = subagent
    
    AgentHandler->>SubAgent: get_response(message, callbacks)
    SubAgent-->>AgentHandler: Return response
    
    AgentHandler->>AgentHandler: Restore original active_agent
    AgentHandler-->>AgentsCommand: Return formatted response
```

This method:
1. Temporarily sets the provided subagent as the active agent
2. Processes the interaction
3. Restores the original active agent afterward

## Key Implementation Details

### Memory Management

The AgentHandler ensures memory consistency by:
- Storing the main agent's memory in shared_state
- Updating memory references when switching between agents
- Syncing memory with the latest state on initialization

### Animation Handling

The module includes sophisticated animation management:
- Creates and manages loading animations during processing
- Pauses animations during tool calls and results
- Ensures proper cleanup even during exceptions

### Callback System

The agent module implements a comprehensive callback system that handles:
- LLM response parsing and tool calls
- Risk assessments for bash commands
- Interactive user questions
- Tool execution results
- Memory condensing processes

## Usage Example

```python
# Create an agent handler
agent_handler = AgentHandler(cli=cli_instance)

# Get a response from the main agent
success = agent_handler.handle_interaction("What files are in the current directory?")

# Switch to a mode agent
planning_agent = create_planning_agent()
agent_handler.switch_to_mode_agent(planning_agent)

# Get a response from the mode agent
success = agent_handler.handle_interaction("Create a plan for implementing feature X")

# Switch back to the main agent
agent_handler.switch_to_main_agent()
```

## Integration with Modes

The agent module integrates with the mode system by:
1. Preserving the main agent's state when switching to a mode
2. Maintaining separate tools and context for each mode
3. Supporting seamless transitions between modes
4. Handling interrupted operations (e.g., Ctrl+C during execution)