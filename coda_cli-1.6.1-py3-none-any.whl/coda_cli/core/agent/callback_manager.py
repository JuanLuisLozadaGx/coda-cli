from typing import Dict, Callable, Any
from loguru import logger
from coda_cli.core.agent.ui_manager import UIManager


class CallbackManager:
    """
    Central manager for all callback types (UI, memory, etc.).
    
    This class coordinates different callback managers and provides a clean API
    for the AgentHandler to request callbacks based on the current mode.
    """
    
    def __init__(self):
        """Initialize the callback manager with empty managers."""
        self.ui_managers: Dict[str, UIManager] = {}
        logger.info("CallbackManager initialized")
    
    def register_ui_manager(self, ui_style: str, ui_handler=None):
        """
        Register a UI manager for a specific UI style.
        
        Args:
            ui_style: The style identifier (e.g., "main_mode", "plan_mode")
            ui_handler: Optional UI handler instance for plan mode
        """
        ui_manager = UIManager(ui_style)
        
        if ui_style == "plan_mode" and ui_handler:
            ui_manager.set_plan_ui_handler(ui_handler)
        
        self.ui_managers[ui_style] = ui_manager
        logger.info(f"Registered UI manager for style: {ui_style}")
        
    def get_ui_callbacks(
        self,
        ui_style: str,
        start_animation: Callable,
        stop_animation: Callable,
        shared_state: Any,
        agent_handler: Any
    ) -> Dict[str, Callable]:
        """
        Get UI callbacks for the specified UI style.
        
        Args:
            ui_style: The style to use ("main_mode" or "plan_mode")
            start_animation: Function to start loading animation
            stop_animation: Function to stop loading animation
            shared_state: Shared state for usage tracking
            agent_handler: Reference to agent handler
            
        Returns:
            Dictionary of callbacks for agent interaction
        """
        if ui_style not in self.ui_managers:
            logger.warning(f"UI manager not registered for style: {ui_style}, creating default")
            self.register_ui_manager(ui_style)
        
        ui_manager = self.ui_managers[ui_style]
        callbacks = ui_manager.create_callbacks(
            start_animation, stop_animation, shared_state, agent_handler
        )
        
        logger.info(f"Created {len(callbacks)} callbacks for UI style: {ui_style}")
        return callbacks
    
    def has_ui_manager(self, ui_style: str) -> bool:
        """
        Check if a UI manager is registered for the given style.
        
        Args:
            ui_style: The style to check
            
        Returns:
            True if UI manager exists for this style
        """
        return ui_style in self.ui_managers
    
    def get_ui_manager(self, ui_style: str):
        """
        Get the UI manager for a specific style.
        
        Args:
            ui_style: The style identifier
            
        Returns:
            The UIManager instance, or None if not found
        """
        return self.ui_managers.get(ui_style)
