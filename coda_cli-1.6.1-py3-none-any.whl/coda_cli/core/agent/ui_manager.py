from typing import Dict, Callable, Any
from loguru import logger
from coda_cli.core import ui
from coda_cli.core.ui.tools.bash_live_view import BashLiveView

class UIManager:
    """
    Manages UI callback creation based on the UI style (main mode vs plan mode).
    
    This class is responsible for creating the appropriate callbacks for tool calls
    and tool results based on the current UI style.
    """
    
    def __init__(self, ui_style: str):
        """
        Initialize the UI Manager with a specific UI style.
        
        Args:
            ui_style: The style of UI to use ("main_mode" or "plan_mode")
        """
        self.ui_style = ui_style
        self.plan_ui_handler = None
        logger.info(f"UIManager initialized with style: {ui_style}")
    
    def set_plan_ui_handler(self, ui_handler):
        """
        Set the plan mode UI handler for rendering plan tools.
        
        Args:
            ui_handler: Instance of PlanningModeUIHandler
        """
        self.plan_ui_handler = ui_handler
        logger.info(f"UI handler set: {type(ui_handler).__name__}")
    
    def create_callbacks(
        self, 
        start_animation: Callable,
        stop_animation: Callable,
        shared_state: Any,
        agent_handler: Any
    ) -> Dict[str, Callable]:
        """
        Create UI callbacks based on the current UI style.
        
        Args:
            start_animation: Function to start loading animation
            stop_animation: Function to stop loading animation
            shared_state: Shared state for usage tracking
            agent_handler: Reference to agent handler for animation control
            
        Returns:
            Dictionary of callbacks for agent interaction
        """
        if self.ui_style == "plan_mode":
            logger.info("Creating plan mode UI callbacks")
            return self._create_plan_mode_callbacks(
                start_animation, stop_animation, shared_state, agent_handler
            )
        else:
            logger.info("Creating main mode UI callbacks")
            return self._create_main_mode_callbacks(
                start_animation, stop_animation, shared_state, agent_handler
            )
    
    def _create_plan_mode_callbacks(
        self,
        start_animation: Callable,
        stop_animation: Callable,
        shared_state: Any,
        agent_handler: Any
    ) -> Dict[str, Callable]:
        """
        Create callbacks for plan mode with delegation to plan UI handler.
        
        Uses PlanningModeUIHandler for rendering plan-specific tools,
        falls back to standard UI if handler is not available or errors occur.
        """
        current_tool_args = {}
        
        bash_live_view = BashLiveView()

        
        def tool_call_callback(tool_name, tool_args):
            """Delegate to agent's ui_handler (source of truth), with fallback to standard UI."""
            current_tool_args.update(tool_args)
            agent_handler._stop_animation_if_needed(stop_animation, end_with_newline=True)
            
            # Check if active agent has ui_handler (source of truth)
            agent_ui_handler = None
            if (hasattr(agent_handler, 'active_agent') and 
                agent_handler.active_agent and
                hasattr(agent_handler.active_agent, 'ui_handler')):
                agent_ui_handler = agent_handler.active_agent.ui_handler
            
            try:
                if agent_ui_handler:
                    agent_ui_handler.print_tool_call(tool_name, tool_args)
                    logger.debug(f"Agent's UI handler rendered tool call: {tool_name}")
                elif self.plan_ui_handler:
                    self.plan_ui_handler.print_tool_call(tool_name, tool_args)
                    logger.debug(f"Registered plan UI handler rendered tool call: {tool_name}")
                else:
                    logger.warning("No UI handler found, falling back to standard UI")
                    ui.print_tool_block(tool_name, tool_args)
            except Exception as e:
                logger.error(f"Error in UI handler tool_call for {tool_name}: {e}")
                ui.print_tool_block(tool_name, tool_args)
            
            agent_handler._ensure_animation_running(start_animation)
            
        def tool_result_callback(tool_name, success, result):
            """Delegate to agent's ui_handler (source of truth), with fallback to standard UI."""
            if tool_name.lower() == "bash":
                bash_live_view.clear()
            
            agent_handler._stop_animation_if_needed(stop_animation)
            
            if success and isinstance(result, dict) and "_usage" in result:
                shared_state.add_usage(result.pop("_usage"))
            
            # Check if active agent has ui_handler (source of truth)
            agent_ui_handler = None
            if (hasattr(agent_handler, 'active_agent') and 
                agent_handler.active_agent and
                hasattr(agent_handler.active_agent, 'ui_handler')):
                agent_ui_handler = agent_handler.active_agent.ui_handler
            
            try:
                if agent_ui_handler:
                    agent_ui_handler.print_tool_result(tool_name, success, result)
                    logger.debug(f"Agent's UI handler rendered tool result: {tool_name}")
                    current_tool_args.clear()
                elif self.plan_ui_handler:
                    self.plan_ui_handler.print_tool_result(tool_name, success, result)
                    logger.debug(f"Registered plan UI handler rendered tool result: {tool_name}")
                    current_tool_args.clear()
                else:
                    logger.warning("No UI handler found, falling back to standard UI")
                    if tool_name.lower() not in ["think", "ask_user"]:
                        ui.print_result_block(
                            not success,
                            result if isinstance(result, dict) else {"result": result},
                            current_tool_args.copy()
                        )
                    current_tool_args.clear()
            except Exception as e:
                logger.error(f"Error in UI handler tool_result for {tool_name}: {e}")
                if tool_name.lower() not in ["think", "ask_user"]:
                    ui.print_result_block(
                        not success,
                        result if isinstance(result, dict) else {"result": result},
                        current_tool_args.copy()
                    )
                current_tool_args.clear()
            
            agent_handler._ensure_animation_running(start_animation)
        
        return {
            "on_llm_start": lambda: agent_handler._ensure_animation_running(start_animation),
            
            "on_llm_parsed": lambda content, tool_calls, metadata: (
                agent_handler._stop_animation_if_needed(stop_animation),
                ui.print_intermediate_response(content) if (tool_calls and content) else None,
                agent_handler._ensure_animation_running(start_animation) if tool_calls else None,
                shared_state.add_usage(metadata.get("usage")) if metadata and metadata.get("usage") else None
            ),
            
            "on_tool_call": tool_call_callback,
            
            "on_bash_risk_assessment": lambda command, risk_assessment: (
                agent_handler._stop_animation_if_needed(stop_animation),
                ui.display_bash_risk_assessment(
                    command,
                    risk_assessment,
                    shared_state.preferences.get("bash_security", {})
                ),
                agent_handler._ensure_animation_running(start_animation)
            )[1],

            "on_omni_parser_preflight": lambda file_path, size_bytes, context: (
                agent_handler._stop_animation_if_needed(stop_animation),
                ui.display_omni_preflight(
                    file_path,
                    size_bytes,
                    context,
                    shared_state.preferences.get("omni_upload", {})
                ),
                agent_handler._ensure_animation_running(start_animation)
            )[1],
            
            "on_ask_user": lambda question, suggestions, direct_actions=None: (
                stop_animation(),
                ui.display_ask_user_question(question, suggestions, direct_actions)
            ),
            
            "on_tool_result": tool_result_callback,
            
            "on_msg": lambda msg: (
                agent_handler._stop_animation_if_needed(stop_animation, end_with_newline=True),
                print(f"\033[1;31m{msg}\033[0m")
            ),
            
            "on_max_iterations": lambda last_message: (
                agent_handler._stop_animation_if_needed(stop_animation, end_with_newline=True),
                print(f"\033[1;33mReached maximum iterations\033[0m"),
                ui.print_markdown_response(last_message) if last_message else None
            ),
            
            "on_complete": lambda _, content, metadata: (
                agent_handler._stop_animation_if_needed(stop_animation, end_with_newline=True),
                ui.print_markdown_response(content),
                shared_state.add_usage(metadata.get("usage")) if metadata and metadata.get("usage") else None
            ),
            
            "on_memory_condensing_start": lambda message: (
                stop_animation(),
                ui.display_memory_condensing_start(message),
                agent_handler._ensure_animation_running(start_animation)
            ),
            
            "on_memory_condensing_end": lambda result: (
                agent_handler._stop_animation_if_needed(stop_animation),
                metadata := result.get("metadata", {}),
                has_error := result.get("result", {}).get("error", False),
                error_description := result.get("result", {}).get("error_dsc", "Unknown error"),
                is_skipped := metadata.get("skipped", False),
                shared_state.add_usage(metadata.get("usage")) if metadata and metadata.get("usage") else None,
                ui.display_memory_condensing_error(error_description) if has_error else (
                    ui.display_memory_condensing_skipped(metadata) if is_skipped else
                    ui.display_memory_condensing_complete(metadata)
                ),
                agent_handler._ensure_animation_running(start_animation)
            ),
            
            "on_bash_stdout_line": lambda line: (
                agent_handler._stop_animation_if_needed(stop_animation),
                bash_live_view.update_stdout(line=line)
            ),
            
            "on_bash_stderr_line": lambda line: (
                agent_handler._stop_animation_if_needed(stop_animation),
                bash_live_view.update_stderr(line=line)
            ),
            
            "on_bash_heartbeat": lambda elapsed_ms: (
                agent_handler._stop_animation_if_needed(stop_animation),
                bash_live_view.update_heartbeat(elapsed_ms=elapsed_ms)
            )
        }
    
    def _create_main_mode_callbacks(
        self,
        start_animation: Callable,
        stop_animation: Callable,
        shared_state: Any,
        agent_handler: Any
    ) -> Dict[str, Callable]:
        """Create standard callbacks for main mode (no special UI handler)."""
        current_tool_args = {}
        
        bash_live_view = BashLiveView()
        
        def tool_call_callback(tool_name, tool_args):
            """Standard tool call display."""
            current_tool_args.update(tool_args)
            agent_handler._stop_animation_if_needed(stop_animation, end_with_newline=True)
            ui.print_tool_block(tool_name, tool_args)
            agent_handler._ensure_animation_running(start_animation)
        
        def tool_result_callback(tool_name, success, result):
            """Standard tool result display."""
            if tool_name.lower() == "bash":
                bash_live_view.clear()
            
            agent_handler._stop_animation_if_needed(stop_animation)
            
            if success and isinstance(result, dict) and "_usage" in result:
                shared_state.add_usage(result.pop("_usage"))
            
            # Skip result block for think tool and ask_user tool
            if tool_name.lower() not in ["think", "ask_user"]:
                ui.print_result_block(
                    not success,
                    result if isinstance(result, dict) else {"result": result},
                    current_tool_args.copy()
                )
            
            current_tool_args.clear()
            agent_handler._ensure_animation_running(start_animation)
        
        return {
            "on_llm_start": lambda: agent_handler._ensure_animation_running(start_animation),
            
            "on_llm_parsed": lambda content, tool_calls, metadata: (
                agent_handler._stop_animation_if_needed(stop_animation),
                ui.print_intermediate_response(content) if (tool_calls and content) else None,
                agent_handler._ensure_animation_running(start_animation) if tool_calls else None,
                shared_state.add_usage(metadata.get("usage")) if metadata and metadata.get("usage") else None
            ),
            
            "on_tool_call": tool_call_callback,
            
            "on_bash_risk_assessment": lambda command, risk_assessment: (
                agent_handler._stop_animation_if_needed(stop_animation),
                ui.display_bash_risk_assessment(
                    command,
                    risk_assessment,
                    shared_state.preferences.get("bash_security", {})
                ),
                agent_handler._ensure_animation_running(start_animation)
            )[1],

            "on_omni_parser_preflight": lambda file_path, size_bytes, context: (
                agent_handler._stop_animation_if_needed(stop_animation),
                ui.display_omni_preflight(
                    file_path,
                    size_bytes,
                    context,
                    shared_state.preferences.get("omni_upload", {})
                ),
                agent_handler._ensure_animation_running(start_animation)
            )[1],
            
            "on_ask_user": lambda question, suggestions, direct_actions=None: (
                stop_animation(),
                ui.display_ask_user_question(question, suggestions, direct_actions)
            ),
            
            "on_tool_result": tool_result_callback,
            
            "on_msg": lambda msg: (
                agent_handler._stop_animation_if_needed(stop_animation, end_with_newline=True),
                print(f"\033[1;31m{msg}\033[0m")
            ),
            
            "on_max_iterations": lambda last_message: (
                agent_handler._stop_animation_if_needed(stop_animation, end_with_newline=True),
                print(f"\033[1;33mReached maximum iterations\033[0m"),
                ui.print_markdown_response(last_message) if last_message else None
            ),
            
            "on_complete": lambda _, content, metadata: (
                agent_handler._stop_animation_if_needed(stop_animation, end_with_newline=True),
                ui.print_markdown_response(content),
                shared_state.add_usage(metadata.get("usage")) if metadata and metadata.get("usage") else None
            ),
            
            "on_memory_condensing_start": lambda message: (
                stop_animation(),
                ui.display_memory_condensing_start(message),
                agent_handler._ensure_animation_running(start_animation)
            ),
            
            "on_memory_condensing_end": lambda result: (
                agent_handler._stop_animation_if_needed(stop_animation),
                metadata := result.get("metadata", {}),
                has_error := result.get("result", {}).get("error", False),
                error_description := result.get("result", {}).get("error_dsc", "Unknown error"),
                is_skipped := metadata.get("skipped", False),
                shared_state.add_usage(metadata.get("usage")) if metadata and metadata.get("usage") else None,
                ui.display_memory_condensing_error(error_description) if has_error else (
                    ui.display_memory_condensing_skipped(metadata) if is_skipped else
                    ui.display_memory_condensing_complete(metadata)
                ),
                agent_handler._ensure_animation_running(start_animation)
            ),
            
            "on_bash_stdout_line": lambda line: (
                agent_handler._stop_animation_if_needed(stop_animation),
                bash_live_view.update_stdout(line=line)
            ),
            
            "on_bash_stderr_line": lambda line: (
                agent_handler._stop_animation_if_needed(stop_animation),
                bash_live_view.update_stderr(line=line)
            ),
            
            "on_bash_heartbeat": lambda elapsed_ms: (
                agent_handler._stop_animation_if_needed(stop_animation),
                bash_live_view.update_heartbeat(elapsed_ms=elapsed_ms)
            )
        }
