from threading import Thread
import time as tm
import sys

from loguru import logger
from prompt_toolkit.formatted_text import HTML
from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.core.filesystem_ops.utils import extract_file_paths
from coda_core.core.session.constants import MEMORY_KEY_MAIN
from coda_core.core.mcp.service import MCPService
from coda_core.core.agents.single_agent import SingleAgent
from coda_core.core.metadata.metadata import extract_metadata
from coda_core.core.metadata.schemas import SessionMetadata
from coda_cli.core import ui
from coda_cli.core.ui.animation import create_loading_animation
from coda_cli.core.ui.core import print_contact_methods
from coda_cli.post_init_checks import post_init_checks
from coda_cli.post_init_checks import check_model_not_available, post_init_checks
from coda_cli.config.constants import CLIENT_NAME
from coda_cli.core.agent.callback_manager import CallbackManager
from coda_cli.core.ui.plan_mode_core import PlanningModeUIHandler

class AgentHandler:
    """
    Handles all aspects of interaction with the AI agent.
    
    This class encapsulates the logic for preparing messages, managing animations,
    setting up callbacks, handling agent responses, and processing errors.
    """
    
    def __init__(self, cli=None):
        """
        Initialize the handler with a reference to the CLI context.
        
        Args:
            cli: The CLI instance providing access to shared state, 
                 client state, and session management.
        """
        self.cli = cli
        self.file_editor = None
        
        # Three-agent model for clear state management
        self.main_agent = None      # Persistent main agent (preserved across modes)
        self.mode_agent = None      # Current mode's agent (e.g., PlanningModeAgent)
        self.active_agent = None    # Points to whichever agent is currently active
        
        # State flags
        self.using_mode_agent = False    # True when mode_agent is active
        self.is_agent_executing = False  # True during agent execution (for Ctrl+C)
        
        # Animation state
        self._animation_active = False
        self._animation_thread = None

        self._initialization_thread = Thread(target=self._initialize_main_agent, daemon=True)
        self._initialization_thread.start()
        self._initialization_exception = None
        self._last_rules_warning_signature = None
        
        # Initialize callback manager and register main mode UI
        self.callback_manager = CallbackManager()
        self.callback_manager.register_ui_manager("main_mode")

    def _initialize_main_agent(self):
        """
        Initialize or restore the main agent.

        This method:
        1. First checks if a main agent exists in shared_state (from previous mode switches)
        2. If not, creates a new main agent
        3. Stores the agent in both local state and shared_state for persistence
        4. Sets it as active if we're not currently using a mode agent
        """
        try:
            # Create file editor if needed
            if not self.file_editor:
                self.file_editor = FileEditor()

            # Check if we already have a main agent in shared state
            if hasattr(self.cli.shared_state, 'main_agent') and self.cli.shared_state.main_agent is not None:
                # Restore the existing main agent
                self.main_agent = self.cli.shared_state.main_agent
                logger.info("Restored existing main agent from shared_state")

                # Log memory size for diagnosis
                if hasattr(self.main_agent, 'memory') and self.main_agent.memory:
                    memory_size = len(self.main_agent.memory.messages) if hasattr(self.main_agent.memory, 'messages') else 0
                    logger.info(f"Restored main agent memory size: {memory_size} messages")
            else:
                # Create a new main agent
                logger.info("Creating new main agent")

                # Log the memory state before creating agent
                memory_state = "None"
                if (hasattr(self.cli.shared_state, 'memories') and 
                    MEMORY_KEY_MAIN in self.cli.shared_state.memories and 
                    self.cli.shared_state.memories[MEMORY_KEY_MAIN] is not None):
                    memory = self.cli.shared_state.memories[MEMORY_KEY_MAIN]
                    memory_size = len(memory.messages) if hasattr(memory, 'messages') else 0
                    memory_state = f"{memory_size} messages"
                logger.info(f"Creating main agent with memory state: {memory_state}")

            # Create the main agent
            self._create_main_agent()

            # Always ensure the main agent uses the current memory
            # This ensures that even if the agent object was preserved, it has the latest memory
            if (hasattr(self.cli, 'shared_state') and 
                hasattr(self.cli.shared_state, 'memories') and 
                MEMORY_KEY_MAIN in self.cli.shared_state.memories and 
                self.cli.shared_state.memories[MEMORY_KEY_MAIN] is not None):

                if hasattr(self.main_agent, 'memory') and self.main_agent.memory != self.cli.shared_state.memories[MEMORY_KEY_MAIN]:
                    old_memory_size = len(self.main_agent.memory.messages) if hasattr(self.main_agent.memory, 'messages') else 0
                    new_memory_size = len(self.cli.shared_state.memories[MEMORY_KEY_MAIN].messages) if hasattr(self.cli.shared_state.memories[MEMORY_KEY_MAIN], 'messages') else 0

                    logger.info(f"Updating main agent memory reference: {old_memory_size} → {new_memory_size} messages")
                    self.main_agent.memory = self.cli.shared_state.memories[MEMORY_KEY_MAIN]

            # Set as active agent if we're not using a mode agent
            if not self.using_mode_agent:
                self.active_agent = self.main_agent
                logger.info("Set main agent as active")

            # Set the current session ID for MCP service
            try:
                mcp_service = MCPService.get()
                if self.cli.session_manager.current_session:
                    mcp_service.set_current_session_id(self.cli.session_manager.current_session.id)
            except Exception as e:
                logger.debug(f"Could not set MCP session ID: {e}")

        except Exception as e:
            self._initialization_exception = e
            logger.exception(f"Exception during main agent initialization: {e}")

    def _create_main_agent(self):
        """
        Create a new main agent and store it in main_agent.

        Returns:
            The created main agent, or None if the model is not available.
        """
        try:
            self.main_agent = self.cli.shared_state.create_configured_single_agent(
                provider_name=self.cli.shared_state.single_agent_provider_name,
                model_name=self.cli.shared_state.single_agent_model_name,
                memory=self.cli.shared_state.memories[MEMORY_KEY_MAIN],
                file_editor=self.file_editor,
                user_defined_rules=self.cli.shared_state.user_defined_rules
            )
            # Store in shared_state for persistence across mode switches
            self.cli.shared_state.main_agent = self.main_agent
            logger.info("Stored new main agent in shared_state")
        except ValueError as e:
            if not check_model_not_available(e):
                # Handling exception to avoid exiting the CLI.
                logger.error(f"Model not available error during main agent initialization: {e}")
            else:
                logger.exception(f"Unexpected error during main agent initialization: {e}")
                raise e
        except Exception as e:
            logger.exception(f"Unexpected error during main agent initialization: {e}")
            raise e


    def switch_to_mode_agent(self, mode_agent):
        """
        Switch to using a mode-specific agent while preserving the main agent.
        
        Args:
            mode_agent: The agent instance from the mode (e.g., PlanningModeAgent)
            
        Returns:
            bool: True if switch was successful
        """
        # Ensure main agent exists (but don't activate it)
        if not self.main_agent:
            logger.info("Main agent doesn't exist, initializing before mode switch")
            self._initialize_main_agent()
        
        # Store the mode agent
        self.mode_agent = mode_agent
        
        # Make the mode agent active
        self.active_agent = mode_agent
        self.using_mode_agent = True
        
        # Ensure main agent is preserved in shared_state
        self.cli.shared_state.main_agent = self.main_agent
        
        # Get the mode instance from mode manager
        mode_instance = None
        if hasattr(self.cli, 'mode_manager') and self.cli.mode_manager:
            current_mode_key = self.cli.mode_manager._current_mode_key
            if current_mode_key:
                mode_instance = self.cli.mode_manager.get_mode_by_key(current_mode_key)
                logger.debug(f"Retrieved mode instance: {type(mode_instance).__name__ if mode_instance else 'None'}")
        
        # If the mode agent has a mode reference, provide CLI and set up UI
        # Otherwise, check if we found the mode instance from mode manager
        if hasattr(mode_agent, 'mode') and mode_agent.mode:
            mode_instance = mode_agent.mode
        
        if mode_instance:
            mode_instance.cli = self.cli
            logger.info(f"Provided CLI reference to mode for usage synchronization")
            
            # DEBUG: Log mode details
            mode_type = type(mode_instance).__name__
            mode_has_handler = hasattr(mode_instance, 'ui_handler')
            mode_handler_value = getattr(mode_instance, 'ui_handler', 'NO_ATTR') if mode_has_handler else 'NO_ATTR'
            logger.debug(f"mode type={mode_type}, has_ui_handler={mode_has_handler}, ui_handler_value={mode_handler_value}")
            
            # Create and set PlanningModeUIHandler if this is planning mode and handler not set
            if not hasattr(mode_instance, 'ui_handler') or mode_instance.ui_handler is None:
                is_planning_mode = (
                    hasattr(mode_instance, 'key') and mode_instance.key == "Plan Mode"
                ) or (
                    type(mode_instance).__name__ == "PlanningMode"
                )
                
                logger.debug(f"Condition met - is_planning_mode={is_planning_mode}")
                
                if is_planning_mode:
                    logger.debug("Creating PlanningModeUIHandler for plan mode")
                    ui_handler = PlanningModeUIHandler()
                    mode_instance.ui_handler = ui_handler
                    
                    # CRITICAL: Set ui_handler directly on the agent for UIManager to find it
                    mode_agent.ui_handler = ui_handler
                    logger.info("Attached UI handler to planning mode agent (directly on agent)")
            else:
                logger.debug(f"Skipping UI handler creation - ui_handler already exists: {mode_instance.ui_handler}")
            
            # Register plan mode UI handler if available
            if hasattr(mode_instance, 'ui_handler') and mode_instance.ui_handler:
                self.callback_manager.register_ui_manager("plan_mode", mode_instance.ui_handler)
                logger.info("Registered plan mode UI handler with callback manager")
        
        logger.info(f"Switched to mode agent: {type(mode_agent).__name__}")
        return True
    
    def switch_to_main_agent(self):
        """
        Switch back to the main agent from a mode agent.
        
        This method:
        1. Initializes main agent if it doesn't exist
        2. Makes it the active agent
        3. Clears the mode agent reference
        
        Returns:
            bool: True if switch was successful
        """        
        # Initialize main agent if it doesn't exist
        if not self.main_agent:
            logger.info("Main agent doesn't exist, initializing")
            self._initialize_main_agent()
        
        # Make main agent active
        self.active_agent = self.main_agent
        self.using_mode_agent = False
        
        # Clear mode agent reference
        self.mode_agent = None
        
        # Log memory state after setting active
        if self.active_agent and hasattr(self.active_agent, 'memory'):
            memory_size = len(self.active_agent.memory.messages) if self.active_agent.memory else 0
            logger.debug(f"AFTER switch, active agent memory size: {memory_size} messages")
        
        logger.info("Switched to main agent")
        return True

    def has_active_agent(self) -> bool:
        """
        Check if there is an active agent.

        Returns:
            bool: True if an active agent exists, False otherwise
        """
        return self.active_agent is not None

    def get_active_agent(self):
        """
        Get the currently active agent.
        If it doesn't exist, convert the main_agent to active_agent and return it.
        
        Returns:
            The active agent instance (either main_agent or mode_agent)
        """
        if not self.active_agent:
            self._initialize_main_agent()
            self.active_agent = self.main_agent

        return self.active_agent

    def _has_initialization_errors(self) -> bool:
        """Check whether agent initialization failed and display fallback messaging.

        Returns:
            True when initialization errors should stop CLI execution, otherwise False.
        """
        if self._initialization_exception is not None:
            logger.error(f"Agent initialization error detected: {self._initialization_exception}")
            # Check if it was post init checks error.
            if not post_init_checks():
                return True

            # This means an unexpected/unknown error during the agent initialization
            print("\n\033[1;33m⚠️ Unexpected error while trying to use CODA. Please reach us via:\033[0m\n")
            print_contact_methods()

            # Return False so we stop executing the CLI
            return True

        return False

    def wait_for_agent_initialization(self, with_animations: bool = True):
        """
        Wait for the main agent initialization thread to finish.

        Args:
            with_animations (bool): Whether to show loading animations during the wait

        Raises:
            RuntimeError: If there was an error during initialization
        """
        if self._initialization_thread.is_alive():
            start_animation = stop_animation = None
            try:
                if with_animations:
                    start_animation, stop_animation = create_loading_animation(message="\033[1;36mWorking\033[0m")
                    self._ensure_animation_running(start_animation)

                self._initialization_thread.join()
            finally:
                if with_animations and stop_animation:
                    self._stop_animation_if_needed(stop_animation, end_with_newline=True)

        if self._has_initialization_errors():
            raise RuntimeError("Failed to initialize agent")

    def _refresh_rules(self, agent=None) -> None:
        """Reload AGENTS.md rules from the `cwd` hierarchy and refresh the prompt.

        Args:
            agent: Optional agent instance to refresh. Defaults to `self.active_agent`.

        Returns:
            None.
        """
        if not self.cli or not hasattr(self.cli, "shared_state"):
            return

        rules = self.cli.shared_state.load_user_defined_rules()

        warnings = []
        if isinstance(rules, dict):
            raw_warnings = rules.get("warnings", [])
            if isinstance(raw_warnings, list):
                warnings = [warning for warning in raw_warnings if isinstance(warning, str) and warning]

        warning_signature = tuple(warnings)
        if warnings and warning_signature != self._last_rules_warning_signature:
            for warning in warnings:
                ui.print_formatted_text(HTML(f"<ansiyellow>{warning}</ansiyellow>"))
        self._last_rules_warning_signature = warning_signature

        target_agent = agent or self.active_agent
        if target_agent is not None and hasattr(target_agent, "update_system_prompt"):
            target_agent.update_system_prompt(user_defined_rules=rules)


    def handle_interaction(self, user_message: str, mode_agent=None) -> bool:
        """
        Handle complete interaction with the agent.

        Args:
            user_message (str): The user's message to send to the agent
            mode_agent: Optional agent instance provided by a mode (e.g., PlanningModeAgent)

        Returns:
            bool: True to continue CLI execution, False to exit
        """
        # Early return in case user provides an empty message
        if not user_message.strip():
            print("No message provided")
            return True

        # Create animation manager
        start_animation, stop_animation = create_loading_animation()

        if self._initialization_thread.is_alive():
            try:
                # Provide the user with some feedback while the agent is finishing its initialization
                self._ensure_animation_running(start_animation)
                # Avoid blocking the main thread (don't use .join() and poll with time)
                while self._initialization_thread.is_alive():
                    tm.sleep(0.2) # Avoid instant polling
                    if self._has_initialization_errors():
                        self._stop_animation_if_needed(stop_animation, end_with_newline=True)
                        # Stop executing if we had initialization errors
                        return False
            except (KeyboardInterrupt, SystemExit, GeneratorExit, Exception):
                # This handles an edge-case where:
                #   1. User prompts the agent
                #   2. Agent is still initializing
                #   3. User hits Ctrl+C during the initialization wait
                #   4. We need to stop the animation and re-raise to propagate to main loop
                self._stop_animation_if_needed(stop_animation, end_with_newline=True)
                raise

        # Double-check for initialization errors post-join
        if self._has_initialization_errors():
            self._stop_animation_if_needed(stop_animation, end_with_newline=True)
            return False

        # Prepare message with context
        formatted_message = self._prepare_message_with_context(user_message)
        
        # Display visual feedback about detected images (for user awareness)
        file_paths = extract_file_paths(user_message)
        if file_paths:
            ui.display_detected_images()
        
        # Renew session lock on user interaction
        self._renew_session_lock()
        
        try:
            # Handle agent switching if needed
            if mode_agent is not None:
                # Switch to the mode agent
                self.switch_to_mode_agent(mode_agent)
            elif not self.active_agent:
                # No active agent, initialize and switch to main agent
                logger.info("No active agent, initializing and switching to main agent")
                self._initialize_main_agent()
                self.switch_to_main_agent()
            
            # Get callbacks for agent interaction (AFTER agent switching to ensure correct UI handler)
            callbacks = self._create_callbacks(start_animation, stop_animation)
            
            # Refresh system prompt to pick up any changes (skills)
            if self.active_agent and hasattr(self.active_agent, 'update_system_prompt'):
                try:
                    self.active_agent.update_system_prompt()
                    logger.debug("Refreshed system prompt before interaction")
                except Exception as e:
                    logger.error(f"Error updating system prompt: {e}")
            
            # Refresh AGENTS.md rules before each interaction.
            self._refresh_rules(agent=self.active_agent)

            # Process the interaction with the active agent
            return self._process_agent_interaction(formatted_message, callbacks, stop_animation)
        except (KeyboardInterrupt, SystemExit, GeneratorExit) as e:
            logger.info(f"Agent interaction interrupted or terminated: {e}")
            # Re-raise these exceptions to let them propagate to the main loop
            raise
        except Exception as e:
            ui.print_formatted_error_message(error_message=f'Error processing request: {e}')
            ui.print_usage_summary(self.cli.shared_state.get_usage_summary())
            return True
        finally:
            # Clear animation
            if stop_animation is not None:
                self._stop_animation_if_needed(stop_animation, end_with_newline=True)

    def handle_interaction_with_agent(self, user_message: str, agent: SingleAgent) -> bool:
        """
        Handle interaction with a specific agent instance.
        
        This is used when a subagent is called via the /agents command.
        
        Args:
            user_message (str): The user's message to send to the agent
            agent (SingleAgent): The pre-configured agent instance to use
            
        Returns:
            bool: True to continue CLI execution, False to exit
        """
        if not user_message.strip():
            user_message = "Follow the instructions."

        # Prepare message with context
        formatted_message = self._prepare_message_with_context(user_message)

        # Display visual feedback about detected images (for user awareness)
        file_paths = extract_file_paths(user_message)
        if file_paths:
            ui.display_detected_images()

        # Renew session lock on user interaction
        self._renew_session_lock()

        # Store the original agent temporarily
        main_agent = self.active_agent

        # assign as active the subagent provided
        self.active_agent = agent

        # Refresh AGENTS.md rules before running this agent.
        self._refresh_rules(agent=self.active_agent)

        start_animation, stop_animation = None, None
        try:
            start_animation, stop_animation = create_loading_animation()
            callbacks = self._create_callbacks(start_animation, stop_animation)
            return self._process_agent_interaction(formatted_message, callbacks, stop_animation)
        except (KeyboardInterrupt, SystemExit, GeneratorExit) as e:
            logger.info(f"Subagent interaction interrupted or terminated: {e}")
            # Re-raise these exceptions to let them propagate to the main loop
            raise
        except Exception as e:
            ui.print_formatted_error_message(error_message=f'Error processing request with subagent: {e}')
            ui.print_usage_summary(self.cli.shared_state.get_usage_summary())
            # TODO: review if we need to return a system message when the subagent fails
            return True
        finally:
            # Ensure the main agent is restored in any case
            self.active_agent = main_agent
            # Clear animation
            if stop_animation is not None:
                self._stop_animation_if_needed(stop_animation, end_with_newline=True)

    def _prepare_message_with_context(self, user_message: str) -> str:
        """Prepare the user message with context about selected files."""
        if not self.cli.cli_state.selected_files:
            return user_message
            
        file_count = len(self.cli.cli_state.selected_files)
        system_message = f"[CODA SYSTEM MESSAGE] The user added {file_count} file{'s' if file_count != 1 else ''} as relevant to the context. The file paths are given by:"
        
        for i, file_path in enumerate(self.cli.cli_state.selected_files, 1):
            system_message += f"\n - file {i}: {file_path}"
        
        formatted_message = f"{system_message}\n\n{user_message}"
        logger.debug(f"Prepended file context to user message: {formatted_message}")
        return formatted_message
    
    def _renew_session_lock(self):
        """Renew the session lock if a session is active."""
        if (hasattr(self.cli, 'session_manager') and 
            self.cli.session_manager and 
            self.cli.session_manager.current_session):
            self.cli.session_manager.renew_session_lock()
    
    def _create_callbacks(self, start_animation, stop_animation):
        """Create the callback dictionary for agent interaction using CallbackManager."""
        # Get the shared state to use (mode agent's state if available, otherwise CLI's)
        shared_state = (self.active_agent.shared_state 
                       if (hasattr(self.active_agent, 'shared_state') and self.active_agent) 
                       else self.cli.shared_state)
        logger.info(f"Using shared_state from: {'mode agent' if (hasattr(self.active_agent, 'shared_state') and self.active_agent) else 'CLI'}")
        
        # Determine UI style based on whether we're using a mode agent
        ui_style = "plan_mode" if self.using_mode_agent else "main_mode"
        logger.info(f"Creating callbacks for UI style: {ui_style}")
        
        # Delegate to callback manager to get the appropriate callbacks
        return self.callback_manager.get_ui_callbacks(
            ui_style=ui_style,
            start_animation=start_animation,
            stop_animation=stop_animation,
            shared_state=shared_state,
            agent_handler=self
        )
    
    def _process_agent_interaction(self, formatted_message, callbacks, stop_animation):
        """Process the agent interaction with the formatted message."""
        response = None
        
        # Extract metadata from session information
        metadata = None
        try:
            # Get session information if available
            session_id = None
            session_name = None
            if (hasattr(self.cli, 'session_manager') and 
                self.cli.session_manager and 
                self.cli.session_manager.current_session):
                session_id = self.cli.session_manager.current_session.id
                session_name = self.cli.session_manager.current_session.name
                
            # Create Pydantic input object
            metadata_input = SessionMetadata(
                client=CLIENT_NAME,
                session_id=session_id,
                task_id=session_name
            )
            
            # Extract metadata (returns a dictionary)
            metadata = extract_metadata(metadata_input)
            logger.debug(f"Extracted metadata: {metadata}")
        except Exception as e:
            logger.warning(f"Failed to extract metadata: {e}. Continuing without metadata.")
            metadata = None
        try:
            # Set the flag to indicate agent is executing
            self.is_agent_executing = True
            logger.info(f"Agent execution started with {type(self.active_agent).__name__}")
            
            if not self.active_agent:
                # Sending a fake response to avoid exiting the CLI.
                logger.error("No active agent found")
                response = {
                    "success": False,
                    "content": "No active agent found",
                    "error": "No active agent found"
                }
            else:
                # Get response from the active agent with callbacks and metadata
                response = self.active_agent.get_response(
                    user_message=formatted_message, 
                    callbacks=callbacks,
                    metadata_param=metadata
                )
            
            # If we get here without exception, we completed successfully
            self.is_agent_executing = False
            logger.info("Agent execution finished successfully")
            
        except KeyboardInterrupt:
            # The SingleAgent will handle KeyboardInterrupt and resolve orphaned tool calls
            # Then we display a message here
            ui.print_formatted_text(HTML('\n<ansired>Process interrupted by user (Ctrl+C)</ansired>'))
            # Important: Keep the is_agent_executing flag set
            # The CLI main loop will check this flag to determine if it should stay in planning mode
            # The flag will be reset by CLI after making the decision
            logger.info("KeyboardInterrupt during agent execution - flag kept for CLI decision")
            # Re-raise to propagate to the main loop
            raise
            
        except (SystemExit, GeneratorExit):
            # These exceptions should also be re-raised after cleanup
            ui.print_formatted_text(HTML('\n<ansired>Process terminating abruptly</ansired>'))
            # Reset the flag since we're terminating
            self.is_agent_executing = False
            logger.info("Agent execution terminated")
            # Re-raise to allow proper termination
            raise
            
        except Exception as e:
            # Log the error but re-raise it to be caught by the outer try-except block
            logger.error(f"Exception in agent interaction: {e}")
            # Reset the flag for normal exceptions
            self.is_agent_executing = False
            logger.info("Agent execution ended with exception")
            # Re-raise the exception
            raise
            
        finally:
            # Stop the animation if it's still running
            stop_animation()
            if hasattr(self, '_animation_thread') and self._animation_thread and self._animation_thread.is_alive():
                self._animation_thread.join(0.5)
            
            # Ensure the flag is reset in case of normal completion
            # (KeyboardInterrupt case is handled by CLI)
            if self.is_agent_executing and not isinstance(sys.exc_info()[1], KeyboardInterrupt):
                logger.debug("Resetting is_agent_executing flag in finally block")
                self.is_agent_executing = False
        
        # If we got a response and it wasn't successful, show the appropriate message
        if response is not None and not response.get("success", False):
            if "content" in response:
                ui.print_markdown_response(response["content"])
            elif "error" in response:
                ui.print_formatted_error_message(error_message=response["error"])
                
        # Determine which shared_state to use for usage summary and session rename
        shared_state = self.active_agent.shared_state if (hasattr(self.active_agent, 'shared_state') and self.active_agent) else self.cli.shared_state
        
        # Show usage summary before exiting
        ui.print_usage_summary(shared_state.get_usage_summary())

        # Only try to rename the session if it hasn't been renamed already
        if self.cli._should_attempt_rename():
            success = self.cli.session_manager.rename_session_by_llm_call(
                session_id=self.cli.session_manager.current_session.id,
                shared_state=shared_state
            )
            if success:
                # Rename was initiated (will complete asynchronously)
                logger.info(f"Session rename thread started by LLM call")
        return response
    
    def _ensure_animation_running(self, start_animation_fn):
        """Ensure animation is running, starting it if needed."""
        if not self._animation_active:
            self._animation_thread = start_animation_fn()
            self._animation_active = True

    def _stop_animation_if_needed(self, stop_animation_fn, end_with_newline: bool = False):
        """Stop animation if it's running and clear the line."""
        if self._animation_active:
            stop_animation_fn(end_with_newline=end_with_newline)
            self._animation_active = False

    def cleanup(self):
        """
        Perform a cleanup of the initialization thread if it's still running.
        """
        try:
            if self._initialization_thread.is_alive():
                self._initialization_thread.join(timeout=0.1)
        except (Exception, RuntimeError) as e:
            logger.exception(f"Error during AgentHandler cleanup: {e}")
