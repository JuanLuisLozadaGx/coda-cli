import os
import typer
import pyperclip
import threading

from loguru import logger
from typing import List, Optional
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.styles import Style
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.key_binding.key_processor import KeyPressEvent
from prompt_toolkit.completion import merge_completers

from coda_core.config.logging.context import clear_session_context
from coda_core.config.logging.context import set_client_context
from coda_core.core.session.session_manager import SessionManager
from coda_core.core.session.states.shared_state import SharedState
from coda_core.core.session.constants import MEMORY_KEY_MAIN
from coda_core.core.agents.manager import AgentManager
from coda_core.core.agents.utils import parse_user_message_for_agents
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.config.utils import are_geai_credentials_available
try:
    from coda_core.core.models.utils import normalize_reasoning_effort
except ImportError:
    from coda_cli.core.utils.reasoning_utils import normalize_reasoning_effort

from coda_cli.core import ui
from coda_cli.core.utils import utils
from coda_cli.core.utils.command_completer import CommandCompleter
from coda_cli.core.utils.agent_completer import AgentCompleter
from coda_cli.core.utils.skill_completer import SkillCompleter
from coda_cli.core.utils.smart_completer import SmartCompleter
from coda_core.core.utils.skill_loader import SkillLoader
from coda_cli.core.utils.utils import get_yes_no_input
from coda_core.core.utils.configuration import update_default_bash_security_level
from coda_cli.core.commands.tools.utils import update_agent_tools
from coda_cli.core.session.states.cli_client_state import CLIClientState
from coda_cli.core.commands.registry import CommandRegistry
from coda_cli.config.migration.migration_manager import handle_migration, needs_migration
from coda_cli.config.migration.utils import print_migration_success
from coda_cli.config.constants import CLIENT_NAME
from coda_cli.config.env_config import CLIEnvConfig
from coda_cli.core.commands.misc.health import HealthCommand
from coda_cli.core.commands.step_by_step.approve import ApprovePlanCommand
from coda_cli.core.commands.misc.exit import ExitCommand
from coda_cli.core.commands.misc.help import HelpCommand
from coda_cli.core.commands.misc.man import ManCommand
from coda_cli.core.commands.misc.reload_rules import ReloadRulesCommand
from coda_cli.core.commands.add.add import AddCommand, ClearFilesCommand
from coda_cli.core.commands.ask.ask import AskCommand
from coda_cli.core.commands.clear.clear import ClearCommand
from coda_cli.core.commands.switch_model.switch_model import SwitchModelCommand
from coda_cli.core.commands.session.session import SessionCommand
from coda_cli.core.commands.step_by_step.load_plan import LoadPlanCommand
from coda_cli.core.commands.preferences.menu import PreferencesMenuCommand
from coda_cli.core.commands.recipes.recipes import RecipesCommand
from coda_cli.core.commands.upgrade.upgrade import UpgradeCommand
from coda_cli.core.commands.upgrade.ui import prompt_continue_input
from coda_cli.core.commands.tools.tools import ToolsCommand
from coda_cli.core.agent.agent_handler import AgentHandler
from coda_cli.core.commands.mcp.mcp import MCPCommand
from coda_cli.core.commands.agents.agents import AgentsCommand
from coda_cli.core.commands.skills.skills import SkillsCommand
from coda_core.core.mcp.service import MCPService
from coda_core.core.modes.mode_manager import ModeManager
from coda_cli.core.commands.modes.modes import ModesCommand
from coda_cli.core.commands.upgrade.background_checker import BackgroundUpdateChecker
from coda_cli.core.commands.upgrade.state_manager import UpgradeStateManager


class CLI:
    """
    CLI client for the CODA agent.
    
    This class provides the command-line interface for interacting with the CODA agent.
    It handles user input, command processing, and maintains the state of selected files
    and history.
    """

    def __init__(
        self,
        load_last_session: bool = False,
        initial_prompt: Optional[str] = None,
    ) -> None:
        """
        Initializes the CLI client with minimum setup.

        Args:
            load_last_session (bool): If True, auto-load most recent session.
            initial_prompt (Optional[str]): If provided, this prompt is executed automatically on startup before entering the interactive loop.
        """
        # Start-up strategy flags
        self.load_last_session = load_last_session
        self.initial_prompt = initial_prompt
        
        # Background update checker
        self.background_checker = BackgroundUpdateChecker()

        # Register all commands
        self.command_registry = CommandRegistry()        
        self.command_registry.register_commands([
            AddCommand,
            ClearFilesCommand,
            AskCommand,
            ClearCommand,
            HealthCommand,
            SwitchModelCommand,
            SessionCommand,
            PreferencesMenuCommand,
            ToolsCommand,
            SkillsCommand,
            UpgradeCommand,
            ExitCommand,
            ManCommand,
            ReloadRulesCommand,
            RecipesCommand,
            HelpCommand,
            MCPCommand,
            ModesCommand,
            AgentsCommand,
            LoadPlanCommand,
            ApprovePlanCommand
        ])
        # Get all command instances and their metadata
        self.commands = self.command_registry.get_commands_metadata()

        # Initialize animation flag
        self._animation_active = False
        
        # SkillLoader will be initialized in _create_new_session() to get correct session_id
        self.skill_loader: Optional[SkillLoader] = None
        # Tracks whether default-skills initialization has been attempted on
        # this CLI instance, so _create_new_session() and _setup_ui() do not
        # both run it on a fresh startup. Set on first attempt (success or
        # failure) and consulted by _setup_ui()'s resume-path fallback.
        self._default_skills_init_attempted: bool = False

        # Completers will be initialized in _setup_ui(); declared here for type checker
        self.agent_completer: Optional[AgentCompleter] = None
        self.skill_completer: Optional[SkillCompleter] = None


    def __enter__(self):
        """
        Set up resources when entering the context manager.
        
        This method is called when entering a 'with' block and handles
        initialization of resources that need proper cleanup.
        
        Returns:
            CLI: The initialized CLI instance
        """
        return self
        
        
    def _startup(self) -> bool:
        """
        Handle all startup logic for the CLI in the correct order.
        
        This centralizes the initialization process, ensuring resources
        are created only after session decisions are made.
        
        Returns:
            bool: True to continue startup, False to exit after startup
        """
        # Set client context early in startup for improved log traceability
        set_client_context(CLIENT_NAME)

        # Check if upgrade is needed from previous background check
        if UpgradeStateManager.is_new_version_available():
            logger.info("Background check found update available, triggering upgrade flow")
            # Trigger upgrade flow - this block executes in foreground
            upgrade_command = UpgradeCommand(cli=self)
            if not upgrade_command.check_for_updates():
                return False  # Exit if upgrade was not successful

        else:
            # Start background update check for next time (non-blocking)
            self._start_background_update_check()

        # Re-set client context after session initialization.
        # Session initialization may clear or overwrite the logging context,
        # so we must re-apply the client context here to ensure that all subsequent
        # log entries are correctly attributed to this client. This is necessary
        # because session setup can modify or reset context variables used by the logger.
        set_client_context(CLIENT_NAME)
        
        # Initialize session first to create shared_state
        self._initialize_session()

        # Initialize mode manager
        self._init_modes_manager()
        
        # Then set up UI components using the initialized state
        self._setup_ui()
        
        # Start lock monitor
        self.session_manager.start_lock_monitor()
        
        return True
    
    def _start_background_update_check(self) -> None:
        """Start background update check for next startup"""
        try:
            self.background_checker.start_background_check()
            logger.debug("Started background update checker")
        except Exception as e:
            logger.warning(f"Failed to start background update checker: {e}")
    
    def _init_modes_manager(self) -> None:  
        """Initialize mode manager in the CLI."""
        self.mode_manager = ModeManager()

    def _perform_cleanup(self) -> None:
        """
        Perform cleanup operations to ensure resources are properly released.
        
        This method contains the same cleanup logic as __exit__ but can be called
        directly from signal handlers or other places where cleanup is needed.
        """
        try:            
            # Wait for background update check to complete
            if hasattr(self, 'background_checker') and self.background_checker:
                self.background_checker.join(timeout=2.0)
            
            # Clean up session manager resources
            if hasattr(self, 'session_manager') and self.session_manager:
                # If there's a rename thread running, wait for it to complete (with a timeout)
                if self.session_manager.rename_thread and self.session_manager.rename_thread.is_alive():
                    logger.info("Waiting for session rename to complete before cleanup (max 2 seconds)...")
                    self.session_manager.rename_thread.join(timeout=2.0)
                
                rename_info = self._check_session_rename_status()
                
                if rename_info["old_name"] and rename_info["new_name"] and rename_info["old_name"] != rename_info["new_name"]:
                    # Use the logger instead of print for non-/exit command paths
                    # Only log the rename message if it was an automatic rename, not a manual one
                    if rename_info.get("rename_method") != "manual":
                        logger.info(f"Session was renamed from '{rename_info['old_name']}' to '{rename_info['new_name']}' (auto)")
                
                # Save session before closing to ensure latest state is persisted
                if self.session_manager.current_session and hasattr(self, 'shared_state') and hasattr(self, 'cli_state'):
                    logger.info(f"Saving session before exit: {self.session_manager.current_session.name}")
                    self.session_manager.save_session(
                        shared_state=self.shared_state,
                        client_state=self.cli_state,
                        client_type=self.cli_state.CLIENT_TYPE
                    )
                
                # Close the session manager (stops threads, unlocks session, closes DB connection)
                self.session_manager.close()
                
                # Clear session context for logging
                clear_session_context()
                logger.info("Session context cleared")

            # Clean up agent handler resources
            self.agent_handler.cleanup()

            # Gracefully shutdown MCP service to prevent "Task was destroyed but it is pending!" warnings
            try:
                mcp = MCPService.get()
                if mcp.is_available():
                    logger.info("Starting MCP service shutdown...")
                    
                    # Create a thread to run shutdown with overall timeout protection
                    shutdown_complete = threading.Event()
                    shutdown_error = None
                    
                    def shutdown_worker():
                        nonlocal shutdown_error
                        try:
                            mcp.shutdown()
                            shutdown_complete.set()
                        except Exception as e:
                            shutdown_error = e
                            shutdown_complete.set()
                    
                    # Start shutdown in a separate thread
                    shutdown_thread = threading.Thread(target=shutdown_worker, daemon=True)
                    shutdown_thread.start()
                    
                    # Wait for shutdown to complete, but not forever
                    if shutdown_complete.wait(timeout=10.0):
                        if shutdown_error:
                            logger.warning(f"Error during MCP service shutdown: {shutdown_error}")
                        else:
                            logger.info("MCP service shutdown completed successfully")
                    else:
                        logger.warning("MCP service shutdown timed out after 10 seconds, proceeding with exit")
                else:
                    logger.info("No MCP service available, skipping shutdown")
            except Exception as e:
                logger.warning(f"Error during MCP service shutdown: {e}")

        except Exception as e:
            logger.error(f"Error during cleanup: {e}")



    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        """
        Clean up resources when exiting the context manager.
        
        This method is called when exiting a 'with' block, regardless of whether
        an exception occurred. It ensures proper cleanup of resources.
        
        Args:
            exc_type: The exception type, if an exception was raised
            exc_val: The exception value, if an exception was raised
            exc_tb: The traceback, if an exception was raised
            
        Returns:
            bool: True if the exception was handled, False otherwise
        """
        # Perform cleanup operations
        self._perform_cleanup()
        
        # Handle KeyboardInterrupt specially - we want to suppress it at this level
        # to allow for graceful shutdown
        if exc_type is KeyboardInterrupt:
            logger.warning("KeyboardInterrupt caught during context exit. Performing graceful shutdown.")
            return True  # Suppress the exception
            
        return False  # Don't suppress other exceptions


    def _create_new_session(self, name: str = None) -> None:
        """
        Create a new session and initialize default states.
        
        This helper method encapsulates the common functionality of creating
        a new session and initializing the shared state and CLI state with
        default values, and loads user-defined rules.
        
        Args:
            name (str): Optional name for the session
        """
        # Create a new session
        self.session_manager.create_session(name=name)

        # Initialize with default states
        self.shared_state = SharedState()
        self.cli_state = CLIClientState()

        # Load user-defined rules for new sessions
        rules = self.shared_state.load_user_defined_rules()
        utils.display_rules_warnings(rules.get("warnings", []))

        # Initialize SkillLoader with the session_id from the newly created session
        session_id = self.session_manager.current_session.id if self.session_manager.current_session else "default"
        self.skill_loader = SkillLoader(session_id=session_id)
        try:
            self.skill_loader.initialize_default_skills()
            self._default_skills_init_attempted = True
            logger.debug(f"SkillLoader initialized for new session: {session_id}")
        except Exception as e:
            logger.warning(
                f"Failed to initialize default skills for new session {session_id}: {e}"
            )

        # Initialize agent handler in CLI early to kick off main agent background init
        self.agent_handler = AgentHandler(cli=self)

        # Initialize agent manager
        self.agent_manager = AgentManager(self.shared_state)

        # Initialize default agents (guarded)
        self.agent_manager.initialize_default_agents()


    def _initialize_session(self) -> None:
        """
        Initialize the session manager and handle session loading or creation.

        This method:
        1. Initializes the session manager
        2. Checks for existing sessions
        3. Applies fast-path strategies (--newsession, --lastsession)
        4. Falls back to interactive session picker if needed
        """
        # Initialize session manager
        self.session_manager = SessionManager()
        self.session_manager.initialize()

        # Get list of available sessions
        sessions = self.session_manager.list_sessions()

        # Resolve which session to use
        self._resolve_session(sessions)


    def _resolve_session(self, sessions: List[dict]) -> None:
        """
        Resolve which session to use based on flags and available sessions.
        
        This method ensures a session is always established by the end.
        """
        if not sessions:
            self._create_new_session()
            return

        # Attempt to load the most recent session (with fallback to creating a new one if locked/fails).
        if self.load_last_session:
            if self._try_load_session(sessions[0]["id"], create_new_if_locked=True):
                return
            # Loading failed or session was locked – create a new session instead.
            self._create_new_session()
            return

        # Otherwise, fall back to interactive session selection.
        ui.print_banner()
        print()
        self._create_new_session()


    def _try_load_session(self, session_id: str, create_new_if_locked: bool = True) -> bool:
        """
        Try to load a session, but check if it's locked by another process first.
        
        Args:
            session_id (str): ID of the session to load
            create_new_if_locked (bool): Whether to create a new session if the selected session is locked
            
        Returns:
            bool: True if session was loaded successfully, False otherwise
        """
        # Check if session is locked by another process
        if self.session_manager.is_session_locked_by_other(session_id):
            if create_new_if_locked:
                print(f"\033[1;31mError: Session is currently in use by another client. A new session will be created.\033[0m")
                # Pause so the user can read the error before the screen is cleared in later startup steps
                prompt_continue_input()
                # Create a new session instead when a session is locked
                self._create_new_session()
                return True
            else:
                print(f"\033[1;31mError: Session is currently in use by another client. Please select a different session.\033[0m")
                return False
            
        # If not locked, try to load it
        return utils.load_session_and_update_ui(self, session_id)
    
    
    def _auto_save_if_needed(self) -> None:
        """
        Auto-save the current session if needed.
        
        This method checks if auto-save should be triggered based on the time elapsed
        since the last auto-save, and if so, saves the current session.
        """
        if self.shared_state.should_auto_save():
            self.session_manager.save_session(
                shared_state=self.shared_state,
                client_state=self.cli_state,
                client_type=self.cli_state.CLIENT_TYPE
            )
            self.shared_state.update_auto_save_timestamp()


    def _ensure_animation_running(self, start_animation_fn):
        """Ensure animation is running, starting it if needed."""
        if not hasattr(self, '_animation_active') or not self._animation_active:
            self._animation_thread = start_animation_fn()
            self._animation_active = True


    def _stop_animation_if_needed(self, stop_animation_fn, end_with_newline: bool = False):
        """Stop animation if it's running and clear the line.

        Args:
            stop_animation_fn: Function returned by ``create_loading_animation`` to stop the spinner.
            end_with_newline (bool, optional): If ``True`` clear the spinner line and move the
                cursor to the next line. Defaults to ``False`` so callers can avoid introducing
                blank lines between printed blocks.
        """
        if hasattr(self, '_animation_active') and self._animation_active:
            stop_animation_fn(end_with_newline=end_with_newline)
            self._animation_active = False


    def _setup_ui(self) -> None:
        """
        Set up the CLI UI components using the initialized state.
        
        This method should be called after _initialize_session to ensure
        it uses the correct command history path and current directory
        from the chosen session.
        """
        
        command_history_file = self.cli_state.command_history_path
        self.style = Style.from_dict(ui.CLI_DEFAULT_STYLE)
                    
        # Ensure agent manager exists (may be missing on resume)
        if not hasattr(self, 'agent_manager') or self.agent_manager is None:
            self.agent_manager = AgentManager(self.shared_state)
            try:
                self.agent_manager.initialize_default_agents()
            except Exception as exc:
                logger.debug(f"Unable to initialize default agents during UI setup: {exc}")

        # Ensure default skills are initialized (may be missing on resume).
        # On fresh startup _create_new_session() has already done this and set
        # _default_skills_init_attempted, so we skip the call here to avoid an
        # unnecessary second invocation (and the lock acquisition it would
        # imply, even though the underlying method is idempotent).
        if (
            self.skill_loader is not None
            and not getattr(self, "_default_skills_init_attempted", False)
        ):
            try:
                self.skill_loader.initialize_default_skills()
            except Exception as exc:
                logger.debug(f"Unable to initialize default skills during UI setup: {exc}")
            finally:
                self._default_skills_init_attempted = True

        # Initialize command completer with recipe support
        self.command_completer = CommandCompleter(self.commands)
        
        # Initialize or refresh agent completer for @agent suggestions
        if hasattr(self, 'agent_completer') and self.agent_completer is not None:
            self.agent_completer.agent_manager = self.agent_manager
            try:
                self.agent_completer.refresh()
            except Exception as exc:
                logger.debug(f"Agent completer refresh failed during UI setup: {exc}")
        else:
            self.agent_completer = AgentCompleter(agent_manager=self.agent_manager)
        
        # Initialize or refresh skill completer for /skill-name suggestions
        if hasattr(self, 'skill_completer') and self.skill_completer is not None:
            self.skill_completer.skill_loader = self.skill_loader
            try:
                self.skill_completer.refresh()
            except Exception as exc:
                logger.debug(f"Skill completer refresh failed during UI setup: {exc}")
        else:
            self.skill_completer = SkillCompleter(skill_loader=self.skill_loader)
        
        # Create smart completer that intelligently orders command vs skill completions
        # Commands appear first by default, unless the user is typing a skill name
        smart_slash_completer = SmartCompleter(
            command_completer=self.command_completer,
            skill_completer=self.skill_completer
        )
        
        # Merge completers - agent completer for @agents, smart completer for /commands and /skill-names
        combined_completer = merge_completers([self.agent_completer, smart_slash_completer])

        # Initialize key bindings before session
        self.kb = KeyBindings()
        @self.kb.add('c-v')
        def _(event: KeyPressEvent) -> None:
            try:
                clipboard_text = pyperclip.paste()
                event.current_buffer.insert_text(clipboard_text)
            except Exception as e:
                print(f"\nError pasting from clipboard: {e}")
                
        # ******** TODO: Disable ESC until we figure out how to make it work on Windows systems ********
        # @self.kb.add('escape')
        # def _(event: KeyPressEvent) -> None:
        #     # Only handle ESC if we're in a mode and no agent is executing
        #     current_mode_key = self.mode_manager._current_mode_key if hasattr(self, 'mode_manager') else None
            
        #     if current_mode_key and not self.agent_handler.is_agent_executing:
        #         logger.info(f"ESC key pressed, exiting mode {current_mode_key} to main")
                
        #         # Get the current mode instance
        #         current_mode = self.mode_manager.get_mode_by_key(current_mode_key)
                
        #         # Clear the input buffer
        #         event.current_buffer.text = ""
                
        #         # Submit the empty input buffer (simulates pressing Enter)
        #         event.current_buffer.validate_and_handle()
                
        #         # Print feedback to user
        #         ui.print_formatted_text(HTML('\n<ansigreen>Returning to main mode...</ansigreen>'))
                
        #         # Deactivate the current mode
        #         if current_mode:
        #             current_mode.on_deactivate()
        #             self.mode_manager.clear_mode()
        #             logger.info("Mode deactivated and cleared")
                
        #         # Switch back to main agent
        #         # Make sure we initialize the main agent first if it doesn't exist
        #         if not hasattr(self.agent_handler, 'main_agent'):
        #             logger.info("Main agent doesn't exist, initializing before switch")
        #             self.agent_handler._initialize_main_agent()
                
        #         # Now switch to it
        #         self.agent_handler.switch_to_main_agent()
                
        #         # Update tools for main agent
        #         try:
        #             update_agent_tools(self)
        #             logger.info("Updated agent tools for main mode")
        #         except Exception as e:
        #             logger.error(f"Error updating agent tools: {e}")
                
        #         # Confirm success to user (matching the Ctrl+C handler behavior)
        #         ui.print_formatted_text(HTML('<ansigreen>Successfully returned to main mode</ansigreen>'))
        # ******** TODO: Disable ESC until we figure out how to make it work on Windows systems ********

        self.prompt_session = PromptSession(
            history=FileHistory(command_history_file),
            auto_suggest=AutoSuggestFromHistory(),
            completer=combined_completer,
            style=self.style,
            key_bindings=self.kb
        )


    def _can(self) -> HTML:
        """
        Generate the command prompt display with selected files indicator.
        
        The prompt shows the agent indicator and any selected files that
        are currently in context.
        
        Returns:
            HTML: The formatted prompt with selected files display.
        """
        prompt_parts: list[str] = []

        # Add mode indicator if a mode is active and not the default mode
        # Force re-fetch the current mode to ensure we have the latest state
        # This is crucial for Plan Mode to show the updated step counter
        current_mode = self.mode_manager.get_current_mode()
        logger.info(f"Current mode in prompt: {current_mode}")
        if current_mode is not None:
            # Example: current_mode = "Plan Mode] [draft"
            # This will render as: [Plan Mode] [draft]
            prompt_parts.append(f'<ansiyellow>{current_mode}</ansiyellow> ')

        # Add selected files if there are any
        if self.cli_state.selected_files:
            files_str = ", ".join(os.path.basename(f) for f in self.cli_state.selected_files)
            prompt_parts.append(f'<selected-files>[{files_str}]</selected-files> ')

        # Finally, add the arrow at the end
        prompt_parts.append('<prompt>\u2af8</prompt> ')

        # Return the combined prompt
        return HTML(''.join(prompt_parts))

    
    def _ask_make_tools_config_default(self) -> None:
        """
        Ask the user if they want to make the current tools configuration the default.
        This will set the current enabled/disabled state of all tools as the global default.
        """
        # Ask if user wants to make this the default
        prompt = "\nWould you like to set the current tools configuration as the global default for all new sessions?"
        make_default = get_yes_no_input(prompt, default="n")
        
        if make_default:
            if self.shared_state.tool_manager.save_current_config_as_default():
                print("\033[1;32mDefault tools configuration updated successfully.\033[0m")
            else:
                print("\033[1;31mFailed to update default tools configuration. Please check logs for details.\033[0m")
    
    
    def _ask_make_security_level_default(self, level: str) -> None:
        """
        Ask the user if they want to make the current security level the default.
        
        Args:
            level: The security level to potentially set as default
        """
        # Ask if user wants to make this the default
        prompt = f"\nWould you like to set {level.upper()} as the default security level system-wide?"
        make_default = get_yes_no_input(prompt, default="n")
        
        if make_default:
            if update_default_bash_security_level(level):
                print(f"\033[1;32mDefault security level updated to {level.upper()}.\033[0m")
            else:
                print("\033[1;31mFailed to update default security level. Please check logs for details.\033[0m")


    def _check_session_rename_status(self) -> dict:
        """
        Check if a session was renamed and get the old and new names.
        
        This method retrieves the last rename info from the session manager.
        
        Returns:
            dict: A dictionary containing "old_name", "new_name", and "rename_method" keys,
                 or None values if no rename has occurred. The "rename_method" will be
                 either "manual" or "auto" depending on how the rename was performed.
        """
        if hasattr(self, 'session_manager') and self.session_manager:
            # Get the rename info from the session manager
            rename_info = self.session_manager.get_last_rename_info()
            
            # Get the current session name directly from the session object
            current_session = self.session_manager.current_session
            if current_session:
                current_name = current_session.name
                original_name = current_session.name_info.get("original")
                
                # If rename_info doesn't have values but the session name has changed,
                # create rename info from the session's name_info
                if (not rename_info.get("old_name") or not rename_info.get("new_name")) and \
                   original_name and current_name and original_name != current_name:
                    rename_info = {
                        "old_name": original_name,
                        "new_name": current_name,
                        "rename_method": current_session.name_info.get("rename_method", "auto")
                    }
            
            return rename_info
        return {"old_name": None, "new_name": None}


    def _should_attempt_rename(self) -> bool:
        """
        Determine if conditions are right to attempt session renaming.
        
        This method checks two conditions:
        1. Whether the session has already been renamed (to prevent multiple renames in the same session).
        2. Whether there are at least two user messages across the "main" memory contexts.
        
        Returns:
            bool: True if the session can be renamed (i.e., it has not been renamed before and there are
            enough user messages in memory), otherwise False.
        """
        # Skip if already renamed by any method (manual or auto)
        if self.session_manager.current_session.has_been_renamed():
            return False
                                                                                                                    
        # Count messages to see if we have enough context                                           
        main_memory = self.shared_state.memories.get(MEMORY_KEY_MAIN)
        main_user_messages = sum(
            1 for msg in main_memory.retrieve() if msg.get("role") == "user"
        ) if main_memory else 0
        # Need at least 1 messages for meaningful naming                                                       
        return main_user_messages >= 2


    def _handle_keyboard_interrupt(self):
        """
        Unified handler for Ctrl+C interrupts.
        
        This method implements the rules:
        1. No mode active → show quit message
        2. Mode agent executing → stay in mode for feedback
        3. Mode idle → exit to main agent
        """
        # Log the interruption
        logger.info("KeyboardInterrupt caught in _handle_keyboard_interrupt")
        
        # Get current mode state
        current_mode_key = self.mode_manager._current_mode_key
        
        # Case 1: No mode active (in main/default state)
        if not current_mode_key:
            ui.print_formatted_text(HTML('\n<ansiyellow>Use /q to quit</ansiyellow>'))
            return
        
        # Case 2: In a mode - check if agent was executing
        logger.info(f"Handling Ctrl+C in mode: {current_mode_key}")
        
        # Get the current mode instance
        current_mode = self.mode_manager.get_mode_by_key(current_mode_key)
        
        # Check if agent was executing
        agent_was_executing = self.agent_handler.is_agent_executing
        logger.info(f"Agent was executing: {agent_was_executing}")
        # Reset the flag after checking
        self.agent_handler.is_agent_executing = False
        
        if agent_was_executing:
            # Agent was running - stay in mode for feedback
            mode_name = current_mode_key.replace('_', ' ').replace('mode', '').strip().title() + " mode"
            ui.print_formatted_text(HTML(f'\n<ansigreen>Execution stopped. Still in {mode_name} - you can add feedback or corrections.</ansigreen>'))
        else:
            # No agent running - exit to main
            logger.info(f"Exiting mode {current_mode_key} to main")
            ui.print_formatted_text(HTML('\n<ansigreen>Returning to main mode...</ansigreen>'))
            
            # Deactivate the current mode
            if current_mode:
                current_mode.on_deactivate()
                self.mode_manager.clear_mode()
                logger.info("Mode deactivated and cleared")
            
            # Switch back to main agent
            # Make sure we initialize the main agent first if it doesn't exist
            if not hasattr(self.agent_handler, 'main_agent'):
                logger.info("Main agent doesn't exist, initializing before switch")
                self.agent_handler._initialize_main_agent()
            
            # Now switch to it
            self.agent_handler.switch_to_main_agent()
            # Update tools for main agent
            try:
                update_agent_tools(self)
                logger.info("Updated agent tools for main mode")
            except Exception as e:
                logger.error(f"Error updating agent tools: {e}")
            
            ui.print_formatted_text(HTML('<ansigreen>Successfully returned to main mode</ansigreen>'))
    
    def _resolve_orphaned_tool_calls(self):
        """
        Resolve any orphaned tool calls in the active agent's memory.
        
        This ensures message history consistency after interruptions.
        """
        try:
            if self.agent_handler.has_active_agent():
                agent = self.agent_handler.get_active_agent()
                if agent and hasattr(agent, 'memory') and agent.memory:
                    resolved_count = agent.memory.resolve_orphaned_tool_calls(
                        error_message="Process interrupted by user"
                    )
                    if resolved_count > 0:
                        logger.info(f"Resolved {resolved_count} orphaned tool calls")
        except Exception as e:
            logger.error(f"Error resolving orphaned tool calls: {e}")

    def _handle_agent_interaction(self, user_message: str) -> bool:
        """
        Handle interaction with the SingleAgent with real-time UI updates.

        Args:
            user_message (str): The user's message to send to the agent
            
        Returns:
            bool: True to continue CLI execution, False to exit
        """            
        # Check if we have a mode-specific agent to use
        mode_agent = None
        current_mode_key = self.mode_manager._current_mode_key if hasattr(self, 'mode_manager') else None
        
        if current_mode_key:
            # Get the current mode instance
            current_mode = self.mode_manager.get_mode_by_key(current_mode_key)
            if current_mode and hasattr(current_mode, 'agent'):
                # Mode has its own agent - use it
                mode_agent = current_mode.agent
                logger.info(f"Using agent from mode: {current_mode_key}")
        
        # Delegate to the AgentHandler implementation with the mode's agent if available
        return self.agent_handler.handle_interaction(user_message, mode_agent=mode_agent)


    def _handle_command(self, command: str) -> bool:
        """
        Handles the commands entered by the user.
        
        Processes special commands prefixed with '/' and bash commands prefixed with '!'.
        Also handles agent commands prefixed with '@'.
        Special commands include help, file management, and application control.
        
        Args:
            command (str): The command string entered by the user.
            
        Returns:
            bool: True to continue CLI execution, False to exit.
        """
        # Check if the command is empty
        if not command.strip():
            return True
        
        # Renew session lock on user activity
        if hasattr(self, 'session_manager') and self.session_manager and self.session_manager.current_session:
            self.session_manager.renew_session_lock()
        
        # Handle bash commands
        if command.startswith("!"):
            bash_command = command[1:].strip()
            return utils.execute_bash_command(bash_command)

        # Handle agent commands with @ prefix
        if command.startswith("@"):
            if not hasattr(self, 'agent_manager') or self.agent_manager is None:
                self.agent_manager = AgentManager(self.shared_state)
            try:
                self.agent_manager.initialize_default_agents()
            except Exception as exc:
                logger.debug(f"Unable to initialize default agents during command handling: {exc}")

            # Build available agent names for '@' parsing with remote filtering per preferences
            available_agent_names: List[str] = []
            try:
                available_agent_names = self.agent_manager.build_available_agent_names()
            except Exception as exc:
                logger.debug(f"Error building available agent list: {exc}")
                available_agent_names = []

            agent_calls = parse_user_message_for_agents(command, available_agent_names)

            if not agent_calls:
                print(f"\033[1;31mError: No valid agent names found in the command: {command}\033[0m")
                return True

            command_instance = self.command_registry.get_command("/agents", self)
            if not command_instance:
                print("\033[1;31mError: Agent command handler not found\033[0m")
                return True

            remote_names = set()
            try:
                remote_names = {agent.name for agent in self.agent_manager.list_visible_remote_agents()}
            except Exception as exc:
                logger.debug(f"Could not preload remote agent names: {exc}")
                remote_names = set()

            for agent_call in agent_calls:
                agent_name = agent_call['agent_name']
                agent_args = agent_call['user_input']

                logger.info(f"Executing agent: {agent_name} with input: {agent_args}")

                is_local = bool(self.agent_manager.load_agent_metadata(agent_name))
                is_remote = (not is_local) and (agent_name in remote_names)

                if is_local:
                    exec_args = f"{agent_name} {agent_args}".strip()
                elif is_remote:
                    exec_args = f"run-remote {agent_name} {agent_args}".strip()
                else:
                    print(f"\033[1;31mError: Unknown agent '{agent_name}'. Configure GEAI for remote agents or create a local agent.\033[0m")
                    continue

                result = command_instance.execute(exec_args)

                if result is False:
                    return False

            return True
        
        # Handle skill invocations with / prefix (before regular command check)
        if command.startswith("/"):
            # First, check if it's a registered command (like /help, /skills, etc.)
            parts = command.split(maxsplit=1)
            cmd = parts[0]
            
            command_instance = self.command_registry.get_command(cmd, self)
            if command_instance:
                # It's a registered command, handle normally
                args = parts[1] if len(parts) > 1 else ""
                return command_instance.execute(args)
            
            # Not a registered command - try skill invocation
            # Parse: /skill-name optional user task
            skill_input = command[1:].strip()  # Remove leading /
            
            if skill_input and self.skill_loader is not None:
                try:
                    # Get available skills using the CLI's skill_loader
                    available_skills = self.skill_loader.discover_skills()
                    skill_names = [s.name for s in available_skills if s.enabled]
                    
                    # Match against available skills (longest first to handle prefixes)
                    skill_name = None
                    user_task = ""
                    
                    for name in sorted(skill_names, key=len, reverse=True):
                        if skill_input == name:
                            # Exact match, no additional task
                            skill_name = name
                            break
                        elif skill_input.startswith(name + ' '):
                            # Match with additional text
                            skill_name = name
                            user_task = skill_input[len(name):].strip()
                            break
                    
                    if skill_name:
                        logger.info(f"Executing skill: {skill_name} with task: {user_task}")
                        
                        # Construct a message that tells the agent to use the run_skill tool
                        # This ensures the tool call is visible in the UI
                        if user_task:
                            agent_prompt = f"Use the run_skill tool to load the '{skill_name}' skill and then: {user_task}"
                        else:
                            agent_prompt = (
                                f"The user wants to use the skill '{skill_name}' but did not add a specific task. "
                                "Use the ask_user tool to ask the user the specific task to accomplish using the skill"
                            )
                        
                        # Send to agent handler - agent will call run_skill tool
                        return self._handle_agent_interaction(user_message=agent_prompt)
                    else:
                        # Unknown skill name
                        print(f"\033[1;31mUnknown skill or command: {cmd}\033[0m")
                        if skill_names:
                            print(f"Available skills: {', '.join(sorted(skill_names))}")
                        print("Type /help for commands or start typing / to see autocomplete suggestions.")
                        return True
                        
                except Exception as e:
                    logger.error(f"Error processing skill invocation: {e}")
                    print(f"\033[1;31mError: {e}\033[0m")
                    return True
        
        # Extract command and arguments for regular commands
        parts = command.split(maxsplit=1)
        cmd = parts[0]
        args = parts[1] if len(parts) > 1 else ""

        # Get and execute the command
        command_instance = self.command_registry.get_command(cmd, self)
        if command_instance:
            return command_instance.execute(args)

        # If the command is not found, treat it as a message to the agent
        return self._handle_agent_interaction(user_message=command)

    def wait_for_agent_initialization(self, with_animations: bool = True) -> bool:
        """
        Wait for the main agent initialization to finish.

        Args:
            with_animations (bool): Whether to show loading animations during the wait

        Returns:
            bool: True if initialization succeeded, False otherwise
        """
        try:
            self.agent_handler.wait_for_agent_initialization(with_animations)
            return True
        except RuntimeError as e:
            logger.error(f"Error waiting for agent initialization: {e}")
            return False

    def _get_selected_reasoning_effort(self) -> str:
        """
        Resolve the selected reasoning effort from persisted configuration.

        Returns:
            Normalized reasoning effort value for UI display.
        """
        configured_effort: Optional[str] = None
        env_key = getattr(EnvConfig, "CODA_DEFAULT_REASONING_EFFORT", None)
        if env_key is not None:
            env_var_name = env_key.value if hasattr(env_key, "value") else str(env_key)
            configured_effort = os.getenv(env_var_name)

        if not isinstance(configured_effort, str) or not configured_effort:
            configured_effort = SETTINGS.get_env_var(
                CLIEnvConfig.CODA_CLI_DEFAULT_REASONING_EFFORT,
                client_name=CLIENT_NAME,
            )

        if not isinstance(configured_effort, str) or not configured_effort:
            # Compatibility path for mixed-version upgrades where coda-cli
            # is newer than the installed coda-core enum surface.
            configured_effort = os.getenv("CODA_DEFAULT_REASONING_EFFORT", "default")

        if isinstance(configured_effort, str) and configured_effort.strip().lower() == "default":
            return "none"

        normalized_effort = normalize_reasoning_effort(configured_effort)
        return normalized_effort or "none"

    def run(self) -> None:
        """
        Run the CLI client.
        
        Starts the main loop that displays the prompt, processes user input,
        and handles commands until the user exits.
        
        Catches keyboard interrupts and EOF to provide a clean exit experience.
        """
        # Get the current session name if available
        session_name = None
        if self.session_manager and self.session_manager.current_session:
            session_name = self.session_manager.current_session.name

        selected_reasoning_effort = self._get_selected_reasoning_effort()
        
        ui.clear_screen()
        ui.print_banner()
        print()
        ui.print_initialized(cwd=self.cli_state.current_directory)
        print()
        ui.print_session_oneliner(session_name=session_name)
        print()
        ui.print_current_model(
            provider_name=self.shared_state.provider_name,
            model_name=self.shared_state.model_name,
            reasoning_effort=selected_reasoning_effort,
        )
        print()
        ui.print_quick_start()

        if self.initial_prompt:
            ui.print_formatted_text(HTML(f'<prompt>\u2af8</prompt> {self.initial_prompt}'), style=self.style)
            self._handle_command(self.initial_prompt)
            self._auto_save_if_needed()

        while True:
            try:
                command = self.prompt_session.prompt(self._can())
                if not self._handle_command(command):
                    break

                # Auto-save if needed
                self._auto_save_if_needed()
                
                # Renew session lock after each command
                if self.session_manager and self.session_manager.current_session:
                    self.session_manager.renew_session_lock()
                    
                # For Plan Mode, force refresh the mode state to ensure counter is updated
                if hasattr(self, 'mode_manager') and self.mode_manager._current_mode_key:
                    current_mode = self.mode_manager.get_current_mode()
                    logger.info(f"Refreshed mode display after command: {current_mode}")

            except KeyboardInterrupt:
                # Delegate to unified handler
                self._handle_keyboard_interrupt()
                
                # Resolve orphaned tool calls if needed
                self._resolve_orphaned_tool_calls()
                
                # Log the interruption
                logger.warning("KeyboardInterrupt caught in main CLI loop")
                
                # If we were interrupted while not in a command, we should resolve any
                # orphaned tool calls to maintain message history consistency
                if hasattr(self.shared_state, 'main_agent') and self.shared_state.main_agent:
                    try:
                        if hasattr(self.shared_state.main_agent, 'memory') and self.shared_state.main_agent.memory:
                            resolved_count = self.shared_state.main_agent.memory.resolve_orphaned_tool_calls(
                                error_message="Process interrupted by user"
                            )
                            if resolved_count > 0:
                                logger.info(f"Resolved {resolved_count} orphaned tool calls after CLI interruption")
                    except Exception as e:
                        logger.error(f"Error resolving orphaned tool calls: {e}")
            except (SystemExit, GeneratorExit):
                # These are termination signals - perform cleanup and exit
                logger.warning("Termination signal received in main CLI loop")
                self._perform_cleanup()
                # Re-raise to allow proper termination
                raise
                
            except EOFError:
                # Perform cleanup before exiting
                self._perform_cleanup()
                break
                
            except Exception as e:
                # Log unexpected exceptions but don't exit
                logger.exception(f"Unexpected error in CLI main loop: {e}")
                ui.print_formatted_error_message(f"Unexpected error: {e}")


# Typer App
app = typer.Typer(help="CODA - AI Agent CLI tool that helps you write code!", add_completion=False)

# Typer automatically turns bare bools into "--flag / --no-flag".
@app.command()
def chat(
    lastsession: bool = False,
    prompt: Optional[str] = None,
):
    """Start the interactive CODA chat interface."""
    with CLI(load_last_session=lastsession, initial_prompt=prompt) as cli:
        # Only run if startup was successful
        if cli._startup():
            cli.run()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", help="Show version information"),
    reconfigure: bool = typer.Option(False, "--reconfigure", help="Force reconfiguration of environment variables"),
    lastsession: bool = typer.Option(False, "--lastsession", help="Automatically load the most recently used session"),
    prompt: Optional[str] = typer.Option(None, "--prompt", "-p", help="Initial prompt to execute on startup"),
) -> None:
    """
    Entry point for the CODA CLI application.
    
    Handles version and configuration requests, and initializes the CLI client.
    
    The function sets up the environment and starts the CLI interface
    for user interaction with the CODA agent.
    """
    # Handle version request
    if version:
        ui.show_version()
        raise typer.Exit()
    
    if needs_migration():
        print("\n\033[1;33mWelcome to CODA! Since this is your first time, we'll migrate your Neo configuration files so your settings are preserved.\033[0m")
        success = handle_migration()
        if not success:
            print("\033[1;31mAn error occurred during migration.\033[0m")
            raise typer.Exit()
        else:
            print_migration_success()
            if not typer.confirm("Press enter to continue to the CODA CLI...", default=True, show_default=False, prompt_suffix=""):
                raise typer.Exit()

    # Setup environment variables if needed or if reconfiguration is requested
    if utils.setup_configuration(reconfigure=reconfigure, print_banner=ui.print_banner):

        # If no command was invoked, default to chat
        if ctx.invoked_subcommand is None:
            ctx.invoke(chat, lastsession=lastsession, prompt=prompt)


if __name__ == "__main__":
    app()
