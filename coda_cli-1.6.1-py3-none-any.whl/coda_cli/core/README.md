# CODA CLI Core Module

## Introduction

The CODA CLI Core module serves as the foundation of the CODA Command Line Interface (CLI), providing a robust and extensible framework for interacting with the CODA AI agent through a terminal interface. This module enables users to communicate with the AI, manage sessions, add contextual files, configure tools, and switch between different operational modes.

## Architecture Overview

The CLI module is built around a central `CLI` class that coordinates all interactions, including command processing, agent communication, session management, and mode switching. It employs a plugin-based command architecture that allows for easy extension of functionality.

```mermaid
graph TD
    User(User Input) --> CLI[CLI Main Loop]
    CLI --> ParseInput[Parse User Input]
    ParseInput --> CommandCheck{Is Command?}
    
    CommandCheck -->|Yes| Registry[Command Registry]
    CommandCheck -->|No| AgentHandler[Agent Handler]
    
    Registry --> CommandInstance[Command Instance]
    CommandInstance --> Execute[Execute Command]
    Execute --> |Return Result| CLI
    
    AgentHandler --> ActiveAgent[Active Agent]
    ActiveAgent --> |Process Request| LLM[Language Model]
    LLM --> |Response with Tool Calls| Tools[Tool Execution]
    Tools --> |Results| ActiveAgent
    ActiveAgent --> |Final Response| CLI
    
    CLI --> ModeManager[Mode Manager]
    ModeManager --> Modes[Different Modes]
    Modes --> |Mode-specific Agents/Tools| AgentHandler
    
    CLI --> SessionManager[Session Manager]
    SessionManager --> |Load/Save/Create| Sessions[(Sessions)]
```

## Main Components

### CLI Class

The central class that orchestrates the entire CLI experience:

- Initializes the command registry, session manager, and mode manager
- Handles user input in the main loop
- Routes commands to appropriate handlers
- Manages the agent handler and active mode
- Provides session persistence and auto-saving

### Command Registry

Manages command registration and dispatching:

- Maps command aliases to command implementations
- Instantiates command objects as needed
- Provides metadata for command completion and help

### Agent Handler

Manages interactions with AI agents:

- Handles message formatting and context preparation
- Manages animations during processing
- Sets up callbacks for tool execution
- Processes agent responses
- Supports switching between main and mode-specific agents

### Mode Manager

Enables switching between different operational modes:

- Manages available modes (like Planning Mode)
- Activates/deactivates modes and their specific agents
- Handles mode-specific tool configurations
- Preserves main agent state during mode transitions

### Session Manager

Provides persistence across CLI sessions:

- Creates, loads, and saves sessions
- Manages session locking for multi-client scenarios
- Handles automatic session renaming

## Command Structure

All commands in CODA CLI follow a consistent structure based on the abstract `Command` class:

```mermaid
classDiagram
    class Command {
        <<abstract>>
        +cli: CLI
        +aliases() List[str]
        +description() str
        +arguments() List[str]
        +execute(args) bool
        +get_metadata() Dict
    }
    
    Command <|-- AddCommand
    Command <|-- AskCommand
    Command <|-- AgentsCommand
    Command <|-- ClearCommand
    Command <|-- HelpCommand
    Command <|-- SessionCommand
    Command <|-- ModesCommand
    Command <|-- ToolsCommand
    Command <|-- SwitchModelCommand
    Command <|-- PreferencesMenuCommand
    Command <|-- RecipesCommand
    Command <|-- MCPCommand
    Command <|-- SkillsCommand
    
    class CommandRegistry {
        +commands: Dict
        +register_command(command_class)
        +register_commands(command_classes)
        +get_command(alias, cli)
        +get_all_commands(cli)
        +get_commands_metadata()
    }
    
    CommandRegistry --> Command
```

## Data Flow

The following diagram illustrates the data flow during a typical interaction:

```mermaid
sequenceDiagram
    participant User
    participant CLI
    participant CommandRegistry
    participant AgentHandler
    participant Agent
    participant Tools
    
    User->>CLI: Enter Input
    CLI->>CLI: _handle_command()
    
    alt Is Command
        CLI->>CommandRegistry: get_command()
        CommandRegistry-->>CLI: Command Instance
        CLI->>Command: execute(args)
        Command-->>CLI: Result
    else Is Message to Agent
        CLI->>AgentHandler: handle_interaction(message)
        AgentHandler->>Agent: get_response(message)
        Agent->>Agent: Process with LLM
        
        loop For each tool call
            Agent->>Tools: Execute Tool
            Tools-->>Agent: Tool Result
        end
        
        Agent-->>AgentHandler: Final Response
        AgentHandler-->>CLI: Formatted Response
    end
    
    CLI->>User: Display Result
```

## Tool System

The CLI provides a rich tool system that allows the agent to interact with the external environment:

```mermaid
classDiagram
    class Tool {
        <<abstract>>
        +name: str
        +description: str
        +schema: Dict
        +execute(*args, **kwargs)
    }
    
    class FunctionTool {
        +tool_definition: Dict
        +func: Callable
        +execute(*args, **kwargs)
    }
    
    class BashTool {
        +execute_command(command, timeout)
    }
    
    class EditTool {
        +modify_file(file_path, old_string, new_string)
    }
    
    class ViewTool {
        +read_file(file_path, offset, limit)
    }
    
    class ReplaceTool {
        +write_file(file_path, content)
    }
    
    class ThinkTool {
        +process_thought(thought)
    }
    
    class AskUserTool {
        +get_user_input(question, suggestions)
    }
    
    Tool <|-- FunctionTool
    FunctionTool <|-- BashTool
    FunctionTool <|-- EditTool
    FunctionTool <|-- ViewTool
    FunctionTool <|-- ReplaceTool
    FunctionTool <|-- ThinkTool
    FunctionTool <|-- AskUserTool
    
    class ToolManager {
        +register_tool(tool)
        +get_tool(name)
        +enable_tool(name)
        +disable_tool(name)
        +is_tool_enabled(name)
        +get_enabled_tools()
    }
    
    ToolManager o-- Tool
```

The tool system includes:

1. **File Operations**:
   - `view`: Read file contents
   - `edit`: Make targeted edits to files
   - `replace`: Overwrite file contents

2. **Environment Interaction**:
   - `bash`: Execute shell commands
   - `ask_user`: Request input from the user with suggestions

3. **Meta Tools**:
   - `think`: Record reasoning steps without side effects
   - `web_search`: Search the web for information

4. **Skill Execution**:
   - `run_skill`: Load and execute user-defined task templates

5. **MCP Tools**:
   - `mcp_execute`: Execute tools from external services

Tools can be enabled/disabled through the `/tools` command, and different modes can have different sets of available tools.

## Skills System

CODA CLI implements a user-defined skills system that enables agents to execute complex, reusable task templates consistently. Skills are discovered from both project-local directories and package defaults, providing a flexible framework for standardizing common workflows.

### Skills Architecture

```mermaid
flowchart TD
    CLI --> SkillsCommand[Skills Command]
    SkillsCommand --> SkillManager[Skill Manager]
    
    SkillManager --> Discovery[Skill Discovery]
    Discovery --> ProjectLocal[.coda/skills/]
    Discovery --> PackageDefaults[Package Defaults]
    
    SkillManager --> SkillDefinition[Skill Definitions]
    SkillDefinition --> Metadata[YAML Frontmatter]
    SkillDefinition --> Instructions[Execution Instructions]
    SkillDefinition --> Scripts[Optional Scripts]
    
    Agent --> RunSkillTool[run_skill Tool]
    RunSkillTool --> SkillLoader[Skill Loader]
    SkillLoader --> LoadSkill[Load Skill Metadata]
    LoadSkill --> ReturnInstructions[Return Instructions]
    ReturnInstructions --> Agent
    
    Agent --> StandardTools[Use Standard Tools]
    StandardTools --> Bash[bash]
    StandardTools --> View[view]
    StandardTools --> Edit[edit]
    StandardTools --> Replace[replace]
```

### Skill Components

The skills system is built around several key components:

```mermaid
classDiagram
    class SkillDefinition {
        +name: str
        +description: str
        +execution: ExecutionContext
        +instructions: str
        +scripts_dir: Path
        +validate()
        +to_dict()
    }
    
    class ExecutionContext {
        +context: str
        +timeout: int
        +env_vars: Dict
        +dependencies: List
    }
    
    class SkillLoader {
        +skills_dirs: List[Path]
        +load_skill(name) SkillDefinition
        +discover_skills() List[SkillMetadata]
        +get_enabled_skills() List[str]
        +is_skill_enabled(name) bool
    }
    
    class SkillManager {
        +skill_loader: SkillLoader
        +list_skills() List[SkillMetadata]
        +enable_skill(name) bool
        +disable_skill(name) bool
        +get_skill_status(name) SkillStatus
    }
    
    class RunSkillTool {
        +name: str
        +description: str
        +schema: Dict
        +execute(skill_name, user_idea)
        -_format_instructions(skill, user_idea)
    }
    
    SkillDefinition --> ExecutionContext
    SkillLoader --> SkillDefinition
    SkillManager --> SkillLoader
    RunSkillTool --> SkillLoader
```

### Skill Definition Structure

Skills are defined using markdown files with YAML frontmatter, similar to agent definitions:

```markdown
---
name: my-skill
description: Brief description of what this skill does
execution:
  context: native
  timeout: 120
  env_vars:
    CUSTOM_VAR: value
  dependencies:
    - package-name
---

# Skill Instructions

Detailed execution instructions that the agent will follow.

## Steps
1. First step description
2. Second step description
3. Final step description

## Notes
- Important considerations
- Best practices
```

### Execution Contexts

Skills support multiple execution contexts for isolation and reproducibility:

```mermaid
flowchart TD
    RunSkill[run_skill Tool] --> CheckContext{Execution Context}
    
    CheckContext --> Native[native]
    CheckContext --> UV[uv]
    CheckContext --> Docker[docker]
    CheckContext --> NPM[npm]
    
    Native --> DirectExec[Direct execution in current environment]
    UV --> PythonVenv[Python virtual environment with uv]
    Docker --> Container[Containerized execution]
    NPM --> NodeEnv[Node.js package management]
    
    DirectExec --> Agent[Agent executes with standard tools]
    PythonVenv --> Agent
    Container --> Agent
    NodeEnv --> Agent
```

**Supported Contexts:**

1. **native**: Direct execution in the current environment
   - No isolation, uses current system dependencies
   - Fastest execution, minimal overhead

2. **uv**: Python virtual environment managed by uv
   - Isolated Python dependencies
   - Automatic environment creation and management
   - Reproducible Python workflows

3. **docker**: Containerized execution
   - Full system isolation
   - Consistent environment across platforms
   - Supports custom Dockerfiles

4. **npm**: Node.js package management
   - Isolated Node.js dependencies
   - Uses npm or yarn for package management
   - Supports package.json definitions

### Skill Discovery and Management

```mermaid
sequenceDiagram
    participant User
    participant CLI
    participant SkillsCommand
    participant SkillManager
    participant SkillLoader
    participant FileSystem
    
    User->>CLI: /skills
    CLI->>SkillsCommand: execute()
    SkillsCommand->>SkillManager: list_skills()
    SkillManager->>SkillLoader: discover_skills()
    
    SkillLoader->>FileSystem: scan .coda/skills/
    FileSystem-->>SkillLoader: project skills
    
    SkillLoader->>FileSystem: scan package defaults
    FileSystem-->>SkillLoader: default skills
    
    SkillLoader-->>SkillManager: all discovered skills
    SkillManager-->>SkillsCommand: skills with status
    SkillsCommand-->>CLI: formatted list
    CLI->>User: Display skills table
```

**Skill Discovery:**
- **Project-local skills**: Located in `.coda/skills/` directory
  - Auto-enabled by default
  - Version-controlled with the project
  - Project-specific workflows
  
- **Package defaults**: Built-in example skills
  - Disabled by default
  - Provided by the coda-cli package
  - General-purpose templates

**Management Commands:**
- `/skills`: List all available skills with their status and open the interactive menu for enabling/disabling skills
- `/skills enable <name>`: Enable a specific skill
- `/skills disable <name>`: Disable a specific skill

### Run Skill Tool Execution Flow

```mermaid
sequenceDiagram
    participant Agent
    participant RunSkillTool
    participant SkillLoader
    participant SkillDefinition
    participant StandardTools
    
    Agent->>RunSkillTool: run_skill(skill_name, user_idea)
    RunSkillTool->>SkillLoader: load_skill(skill_name)
    
    alt Skill not found
        SkillLoader-->>RunSkillTool: Error: Skill not found
        RunSkillTool-->>Agent: Error message
    else Skill disabled
        SkillLoader-->>RunSkillTool: Error: Skill disabled
        RunSkillTool-->>Agent: Error message
    else Skill found and enabled
        SkillLoader->>SkillDefinition: Load YAML + Instructions
        SkillDefinition-->>SkillLoader: skill metadata
        SkillLoader-->>RunSkillTool: SkillDefinition
        
        RunSkillTool->>RunSkillTool: format_instructions(skill, user_idea)
        RunSkillTool-->>Agent: Detailed execution guide
        
        Agent->>Agent: Process instructions
        
        loop Execute skill steps
            Agent->>StandardTools: Use bash, view, edit, replace
            StandardTools-->>Agent: Results
        end
        
        Agent->>Agent: Complete task
    end
```

**Key Features:**
- **Simple instruction loading**: The `run_skill` tool loads skill metadata and returns formatted instructions to the agent
- **No isolated subagents**: The main agent executes skill instructions using standard tools
- **Dependency injection**: Skills receive `skill_loader` and `file_editor` dependencies for validation
- **Context-aware execution**: Instructions include execution context details (native, uv, docker, npm)
- **User customization**: The `user_idea` parameter allows agents to adapt skill execution to specific needs

### Creating Custom Skills

To create a custom skill:

1. **Create skill directory**:
   ```bash
   mkdir -p .coda/skills/my-custom-skill
   ```

2. **Add SKILL.md file**:
   ```markdown
   ---
   name: my-custom-skill
   description: Performs a specific task workflow
   execution:
     context: native
     timeout: 180
   ---
   
   # Instructions
   Follow these steps to complete the task:
   1. Analyze the codebase
   2. Make necessary changes
   3. Validate the results
   ```

3. **Optional: Add scripts**:
   ```bash
   mkdir -p .coda/skills/my-custom-skill/scripts
   # Add executable scripts here
   ```

4. **Skill auto-discovery**:
   - The skill is automatically discovered on next CLI startup
   - Project-local skills are enabled by default
   - Use `/skills` to verify the skill is available

### Skills vs Agents vs Recipes

CODA CLI provides three complementary systems for task automation:

| Feature | Skills | Agents | Recipes |
|---------|--------|--------|---------|
| **Purpose** | Reusable task templates | Specialized AI personas | Pre-built code snippets |
| **Execution** | Main agent with instructions | Separate agent instance | Code generation |
| **Customization** | YAML + Markdown | YAML + System prompt | Template variables |
| **Isolation** | Execution context | Separate memory | None |
| **Use Case** | Standardized workflows | Domain expertise | Quick code insertion |
| **Discovery** | `.coda/skills/` | `.coda/agents/` | Package defaults |

**When to use:**
- **Skills**: For repeatable multi-step workflows that should be executed consistently
- **Agents**: For specialized tasks requiring different behavior or tool access
- **Recipes**: For quick code generation and insertion tasks

## Modes of Operation

CODA CLI supports different operational modes that can change how the agent behaves and what tools are available:

```mermaid
flowchart TD
    CLI --> ModeManager[Mode Manager]
    
    ModeManager --> DefaultMode[Default Mode]
    ModeManager --> PlanningMode[Planning Mode]
    
    DefaultMode --> MainAgent[Main Agent]
    PlanningMode --> PlanningAgent[Planning Agent]
    
    MainAgent --> StandardTools[Standard Tools]
    PlanningAgent --> PlanningTools[Planning Tools]
    
    UserActivation[User activates mode] --> ModesCommand[modes command]
    ModesCommand --> ModeManager[select_mode]
    ModeManager --> NewMode[activate_mode]
    NewMode --> SetupMode[on_activate]
    SetupMode --> AgentHandler[switch_to_mode_agent]
```

## Available Commands

The CLI supports the following commands, each with specific functionality:

| Command | Aliases | Description |
|---------|---------|-------------|
| `/add` | `/a` | Add files to the current context |
| `/agents` | | Interact with specialized agents |
| `/ask` | | Ask a question to the agent (deprecated) |
| `/autocomplete` | | Code completion functionality |
| `/clear` | `/c` | Clear the selected files |
| `/exit` | `/q` | Exit the CLI |
| `/help` | `/h` | Display help information |
| `/man` | | Display detailed documentation for commands |
| `/mcp` | | Manage MCP servers and tools |
| `/modes` | `/m`| Switch between operational modes |
| `/preferences` | `/prefs`, `/p` | Configure preferences and settings |
| `/recipes` | `/r` | Access pre-built code recipes |
| `/session` | `/s` | Manage sessions |
| `/skills` | | Manage user-defined skills |
| `/switch_model` | `/sm` | Change the model being used |
| `/tools` | `/t` | Configure available tools |
| `/upgrade` | | Check for and apply updates |

## Agent System

The agent system is built around the `SingleAgent` class from the `coda_core` module and an extensible architecture for specialized agents.

### Agent Architecture

```mermaid
classDiagram
    class BaseAgent {
        <<abstract>>
        +id: UUID
        +tools: List[Tool]
        +llm: LLM
        +memory: Memory
        +get_response()* str
    }
    
    class SingleAgent {
        +tool_choice: str
        +max_iterations: int
        +get_response(user_message, callbacks) Dict
        -_parse_llm_response(llm_response) Dict
        -_call_tool(tool_name, tool_args) Dict
        +update_tools(new_tools) Dict
        +handle_tool_transition(result)
    }
    
    BaseAgent <|-- SingleAgent
    
    class AgentHandler {
        +cli: CLI
        +main_agent: SingleAgent
        +mode_agent: SingleAgent
        +active_agent: SingleAgent
        +handle_interaction(user_message) bool
        +switch_to_mode_agent(mode_agent) bool
        +switch_to_main_agent() bool
        +get_active_agent() SingleAgent
        +handle_interaction_with_agent(user_message, agent) bool
    }
    
    class AgentManager {
        +shared_state: SharedState
        +agents_dir: str
        +load_agent_metadata(agent_name) AgentDefinition
        +create_agent(agent_name, memory) SingleAgent
        +list_agents() List[AgentMetadata]
        +filter_agents_list(attribute) List[str]
        +delete_agent(agent_name) bool
        +parse_user_message(message) List[Dict]
    }
    
    AgentHandler --> SingleAgent
    AgentManager --> SingleAgent
```

### Agent Command Flow

```mermaid
sequenceDiagram
    participant User
    participant CLI
    participant AgentsCommand
    participant AgentManager
    participant AgentHandler
    participant SingleAgent
    
    User->>CLI: @agent-name some request
    CLI->>AgentsCommand: Execute(@agent-name some request)
    AgentsCommand->>AgentManager: parse_user_message(input)
    AgentManager-->>AgentsCommand: [{agent_name, user_input}]
    
    AgentsCommand->>AgentManager: load_agent_metadata(agent_name)
    AgentManager-->>AgentsCommand: agent_definition
    
    AgentsCommand->>AgentManager: create_agent(agent_name, memory)
    AgentManager->>SharedState: create_configured_single_agent()
    SharedState-->>AgentManager: configured_agent
    AgentManager-->>AgentsCommand: agent
    
    AgentsCommand->>AgentHandler: handle_interaction_with_agent(user_input, agent)
    AgentHandler->>SingleAgent: get_response(formatted_message)
    SingleAgent->>SingleAgent: Process with LLM
    
    loop For each tool call
        SingleAgent->>Tool: Execute Tool
        Tool-->>SingleAgent: Tool Result
    end
    
    SingleAgent-->>AgentHandler: Response
    AgentHandler-->>AgentsCommand: Formatted Response
    AgentsCommand-->>CLI: Display Result
    CLI->>User: Show Response
```

### Agent Definition System

Specialized agents are defined using markdown files with YAML frontmatter:

```mermaid
flowchart TD
    AgentFile[Agent Definition File] --> Frontmatter[YAML Frontmatter]
    AgentFile --> Content[System Prompt Content]
    
    Frontmatter --> Name[name: Identifier]
    Frontmatter --> Description[description: Purpose]
    Frontmatter --> Model[model: provider/model_name]
    Frontmatter --> Tools[tools: Comma-separated list]
    Frontmatter --> Flags[Optional flags]
    
    AgentManager --> AgentFile[Loads]
    AgentManager --> Agent[Creates Instance]
    
    Agent --> Model[Uses]
    Agent --> SystemPrompt[Uses]
    Agent --> EnabledTools[Has access to]
    Agent --> Memory[Uses Context]
```

The agent interaction is managed by the `AgentHandler` class, which:
- Maintains references to both the main agent and any mode-specific agents
- Prepares messages with appropriate context (e.g., selected files)
- Handles animations and user feedback during processing
- Sets up callbacks for tool execution and result handling
- Processes agent responses and formats them for display

### Metadata Handling

Before each agent interaction, the `AgentHandler` extracts session metadata and passes it to the agent. A `SessionMetadata` Pydantic object is created containing the client name, session ID, and task ID. This object is then transformed into a dictionary using `extract_metadata()` and passed to `self.active_agent.get_response()` as the `metadata` parameter, enabling tracking and contextual information during agent execution.

### Specialized Agents System

CODA CLI implements a specialized agents system that allows users to create, manage, and use domain-specific agents. The key components of this system include:

1. **AgentManager**: Responsible for managing agent definition files, loading agent metadata, and creating agent instances.

2. **AgentsCommand**: Implements the `/agents` command interface for listing, creating, updating, and deleting agents, as well as invoking agents by name.

3. **CLIAgentsManager**: Provides an interactive user interface for managing agents, including creating new agents, updating existing ones, and listing available agents.

4. **AgentCompleter**: Offers autocompletion for agent names when using the `@agent-name` syntax or the `/agents` command.

5. **AgentHandler**: Manages interaction with agents, including preparing messages with context, processing responses, and handling tool execution.

The system supports two main ways to invoke agents:

- **@agent Syntax**: Users can invoke agents directly in the chat by typing `@agent-name [input]`.
- **/agents Command**: Users can manage agents and invoke them through the `/agents` command interface.

Agent definition files follow a consistent format with YAML frontmatter for metadata and markdown content for the agent's system prompt:

```markdown
---
name: fix
description: Fixes bugs in a codebase.
tools: bash, view, think, examine_images, web_search, mcp_execute
model: openai/gpt-5
command: True
discoverable: True
---

### Instructions
Follow this TASK
1. Plan: 
    - If a bug diagnosis was provided, analyze it and continue to step 2. 
    - If the diagnosis isn't provided, define a plan to solve the reported issue based on the analysis provided.    
2. Implement the plan to solve the issue.
   - This will involve reading candidate files, searching the codebase and editing the codebase to solve the issue.
3. Verify, check that your changes match what the user requested in the issue.
   - Remember what the ticket or issue the user provided was about and create a checklist to validate if the changes made are correct.
   - Use the think tool to create this checklist, given the ticket and changes. 
4. Double check if the bug was fixed.
   - Do not write tests nor attempt to execute existing tests to validate if a bug or feature is fixed.
   - If you still think more changes are needed, go back to step 2.
5. Final Report:
   - Once you completed the analysis, generate a final Fix Report in markdown format, explain what you did in detail.
```

Notes:
- The command flag controls if the user will be able to access the agent in the @ dropdown.
- The discoverable flag is not yet consumed in the application but it's planned in a later stage.

### /agents interface

The CLI provides a complete management interface for agents through:

- `/agents list`: List all available agents
- `/agents create [name] [description]`: Create a new agent
- `/agents update [name] [changes]`: Update an existing agent
- `/agents delete`: Delete an existing agent
- `/agents [agent-name] [input] [--context full|recent|none]`: Run a specific agent with optional context window control

Additionally, users can chain multiple agent calls in a single message. 
This allows for sophisticated workflows where different specialized agents handle different parts of a complex task.

```
@diagnose [issue descriptio]
@fix 
```

In issues with images it's possible to "process" the images and text issue into an explained ticket. 
This can be done with the explain agent that is also built-in. 
```
@explain /full/path/ticket-id/
@diagnose 
@fix 
```

Also possible is to include instructions for each subagent. 
```
@explain /full/path/ticket-id/
@diagnose make sure to search in the base.py file
@fix use best practices of the codebase
```

You can scope the history each inline call sees by appending `--context full`, `--context recent`, or `--context none` right after the agent name:
```
@diagnose --context full take another look at the ticket summary
@fix --context none start fresh with only this instruction
```

- `full` mode replays every stored **user → assistant** exchange (tool chatter is still omitted), so remote agents can see the complete conversation arc.
- `recent` mode keeps only the last three user/assistant pairs to stay fast while still providing immediate context.
- `none` skips history entirely and only sends the new instruction you provide after the agent name.

Notes:
- The input and output of each agent is available for the main-agent. 
- Agents inherit the last few exchanges (`recent` mode) unless you override it with `--context full` or `--context none`. Use `none` when you want a clean hand-off without prior conversation noise.


## Session Management

The CLI provides robust session management through the `SessionManager` class:

```mermaid
flowchart TD
    CLI --> SessionManager[Session Manager]
    
    SessionManager --> CreateSession[Create Session]
    SessionManager --> ListSessions[List Sessions]
    SessionManager --> LoadSession[Load Session]
    SessionManager --> SaveSession[Save Session]
    SessionManager --> RenameSession[Rename Session]
    
    SessionManager --> Session[Session Object]
    Session --> SessionId[Session ID]
    Session --> SessionName[Session Name]
    Session --> SessionState[Session State]
    
    SessionState --> SharedState[Shared State]
    SessionState --> ClientState[Client State]
    
    SharedState --> MainAgent[Main Agent]
    SharedState --> Memories[Memory]
    SharedState --> ToolManager[Tool Manager]
    
    ClientState --> SelectedFiles[Selected Files]
    ClientState --> CurrentDirectory[Current Directory]
    ClientState --> CommandHistory[Command History]
```

Sessions store:
- The main agent and its memory
- Selected files and current directory
- Tool configurations
- Command history
- Model preferences

## Configuration and Customization

CODA CLI provides multiple ways to customize its behavior:

- **Preferences System**: Configure security levels, model settings, and other options
- **Tool Management**: Enable/disable specific agent capabilities
- **Mode Selection**: Switch between different operational modes
- **Model Selection**: Change the underlying language model

These configurations persist across sessions and can be modified through the appropriate commands.

## MCP (Multi-Connection Protocol)

The CLI includes support for the Multi-Connection Protocol (MCP), which allows integration with external services:

```mermaid
flowchart TD
    CLI --> MCPCommand[MCP Command]
    MCPCommand --> MCPService[MCP Service]
    
    MCPService --> Servers[External Servers]
    Servers --> GithubServer[GitHub Server]
    Servers --> CustomServers[Custom Servers]
    
    MCPService --> Tools[External Tools]
    Tools --> ServerTools[Server-provided Tools]
    
    MCPCommand --> ListServers[List Available Servers]
    MCPCommand --> EnableServer[Enable Server]
    MCPCommand --> DisableServer[Disable Server]
    
    Agent --> MCPExecute[mcp_execute Tool]
    MCPExecute --> MCPService
```

The MCP system:
- Connects CODA to external services (like GitHub)
- Allows the agent to use tools provided by these services
- Supports secure authentication and communication
- Can be managed through the `/mcp` command

When a server is enabled through MCP, its tools become available to the agent, which can access them using the `mcp_execute` tool to route requests to the appropriate server.
