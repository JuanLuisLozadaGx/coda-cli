import sys
import time
from datetime import datetime
from threading import Lock, Timer

from coda_cli.core.ui.core import color
from coda_cli.core.ui.tools.constants import (
    ANSI_ERASE_LINE,
    ANSI_CARRIAGE_RETURN,
    ANSI_CURSOR_UP_ONE,
    BASH_LIVE_VIEW_PIPE_COLOR,
    BASH_LIVE_VIEW_SEPARATOR_COLOR,
    BASH_LIVE_VIEW_LABEL_COLOR,
    BASH_LIVE_VIEW_SEPARATOR_CHAR,
    BASH_LIVE_VIEW_SEPARATOR_LENGTH,
    BASH_LIVE_VIEW_MAX_LINE_LENGTH,
    BASH_LIVE_VIEW_EMPTY_PLACEHOLDER,
    BASH_LIVE_VIEW_DYNAMIC_LINES,
    BASH_LIVE_VIEW_TOTAL_LINES,
    BASH_LIVE_VIEW_RENDER_INTERVAL_S,
)


class BashLiveView:
    """
    Manages a fixed 4-line live block for bash command streaming output.
    
    The block structure displays:
    - Line 0: Separator (printed once when first output arrives)
    - Line 1: Last stdout line (updates in-place)
    - Line 2: Last stderr line (updates in-place)
    - Line 3: Running status with timestamp (updates in-place)
    
    Uses ANSI cursor control for in-place updates to avoid terminal flooding
    while still showing real-time activity.
    
    Rendering is **throttled** to at most one screen write every
    ``BASH_LIVE_VIEW_RENDER_INTERVAL_S`` seconds.  Rapid callback bursts
    (e.g. thousands of stdout lines per second) only update the stored state;
    a deferred timer ensures the last state is always flushed to the screen.
    """
    
    def __init__(self) -> None:
        """Initialize the bash live view with empty state."""
        self._lock = Lock()
        self._last_stdout = ""
        self._last_stderr = ""
        self._last_update_time: datetime | None = None
        self._separator_printed = False
        self._lines_printed = 0

        # Throttle state
        self._last_render_ts: float = 0.0
        self._pending_timer: Timer | None = None
        self._dirty = False          # True when state changed but not yet rendered
        self._cleared = False        # True after clear() is called; suppresses deferred renders
        
    def _format_timestamp(self) -> str:
        """
        Format the last update time as HH:MM:SS AM/PM.
        
        Returns:
            Formatted timestamp string, or empty string if no updates yet.
        """
        if self._last_update_time:
            return self._last_update_time.strftime("%I:%M:%S %p")
        return ""
    
    def _print_separator(self) -> None:
        """Print the separator line once when first output arrives."""
        if not self._separator_printed:
            line_part = color("│", BASH_LIVE_VIEW_PIPE_COLOR)
            separator = color(BASH_LIVE_VIEW_SEPARATOR_CHAR * BASH_LIVE_VIEW_SEPARATOR_LENGTH, BASH_LIVE_VIEW_SEPARATOR_COLOR)
            print(f"{line_part} {separator}")
            self._separator_printed = True
    
    def _render_lines(self) -> None:
        """Render the 3 dynamic lines in-place using ANSI cursor control."""
        # Format the three lines with placeholder if empty
        stdout_display = self._last_stdout[:BASH_LIVE_VIEW_MAX_LINE_LENGTH] if self._last_stdout else BASH_LIVE_VIEW_EMPTY_PLACEHOLDER
        stderr_display = self._last_stderr[:BASH_LIVE_VIEW_MAX_LINE_LENGTH] if self._last_stderr else BASH_LIVE_VIEW_EMPTY_PLACEHOLDER
        
        # Style components
        line_part = color("│", BASH_LIVE_VIEW_PIPE_COLOR)
        stdout_label = color("stdout    ", BASH_LIVE_VIEW_LABEL_COLOR)
        stderr_label = color("stderr    ", BASH_LIVE_VIEW_LABEL_COLOR)
        running_label = color(f"Running (last updated: {self._format_timestamp()})", BASH_LIVE_VIEW_LABEL_COLOR)
        
        # Build lines: pipe (blue) + space + label (grey) + ":" (white) + space + content (grey)
        stdout_line = f"{line_part} {stdout_label}: {color(stdout_display, BASH_LIVE_VIEW_LABEL_COLOR)}"
        stderr_line = f"{line_part} {stderr_label}: {color(stderr_display, BASH_LIVE_VIEW_LABEL_COLOR)}"
        running_line = f"{line_part} {running_label}"
        
        if self._lines_printed == 0:
            # First time: just print the lines
            print(stdout_line)
            print(stderr_line)
            print(running_line)
            self._lines_printed = BASH_LIVE_VIEW_DYNAMIC_LINES
        else:
            # Update in-place: move cursor up 3 lines, then overwrite each
            sys.stdout.write(ANSI_CURSOR_UP_ONE * BASH_LIVE_VIEW_DYNAMIC_LINES)
            sys.stdout.write(f"{ANSI_CARRIAGE_RETURN}{ANSI_ERASE_LINE}{stdout_line}\n")
            sys.stdout.write(f"{ANSI_CARRIAGE_RETURN}{ANSI_ERASE_LINE}{stderr_line}\n")
            sys.stdout.write(f"{ANSI_CARRIAGE_RETURN}{ANSI_ERASE_LINE}{running_line}\n")
            sys.stdout.flush()

        self._last_render_ts = time.monotonic()
        self._dirty = False

    # ------------------------------------------------------------------
    # Throttled rendering helpers
    # ------------------------------------------------------------------

    def _schedule_deferred_render(self) -> None:
        """Schedule a deferred render after the throttle interval elapses.

        Must be called while ``_lock`` is held.  If a timer is already
        pending it is left alone so we don't accumulate timers.
        """
        if self._pending_timer is not None:
            return  # already scheduled

        delay = BASH_LIVE_VIEW_RENDER_INTERVAL_S - (time.monotonic() - self._last_render_ts)
        if delay < 0:
            delay = 0

        def _deferred() -> None:
            with self._lock:
                self._pending_timer = None
                if self._dirty and not self._cleared:
                    self._render_lines()

        self._pending_timer = Timer(delay, _deferred)
        self._pending_timer.daemon = True
        self._pending_timer.start()

    def _throttled_render(self) -> None:
        """Render immediately if enough time has passed, else schedule a deferred render.

        Must be called while ``_lock`` is held.
        """
        now = time.monotonic()
        if now - self._last_render_ts >= BASH_LIVE_VIEW_RENDER_INTERVAL_S:
            # Enough time has elapsed — render now.
            self._render_lines()
        else:
            # Too soon — mark dirty and schedule a deferred render so the
            # latest state is always flushed eventually.
            self._dirty = True
            self._schedule_deferred_render()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def update_stdout(self, line: str) -> None:
        """
        Update with a new stdout line.
        
        Args:
            line: The stdout line to display (will be stripped of trailing newlines).
        """
        with self._lock:
            self._print_separator()
            self._last_stdout = line.rstrip('\n')
            self._last_update_time = datetime.now()
            self._throttled_render()
    
    def update_stderr(self, line: str) -> None:
        """
        Update with a new stderr line.
        
        Args:
            line: The stderr line to display (will be stripped of trailing newlines).
        """
        with self._lock:
            self._print_separator()
            self._last_stderr = line.rstrip('\n')
            self._last_update_time = datetime.now()
            self._throttled_render()
    
    def update_heartbeat(self, elapsed_ms: int) -> None:
        """
        Update the heartbeat timestamp during quiet periods.
        
        Args:
            elapsed_ms: Elapsed time in milliseconds (not currently displayed).
        """
        with self._lock:
            if self._separator_printed:  # Only update if we've started showing output
                self._last_update_time = datetime.now()
                self._throttled_render()
    
    def clear(self) -> None:
        """Clear the entire 4-line block (separator + 3 dynamic lines)."""
        with self._lock:
            # Cancel any pending deferred render first
            self._cleared = True
            if self._pending_timer is not None:
                self._pending_timer.cancel()
                self._pending_timer = None

            # If there is dirty (un-rendered) state, flush it now so the
            # cursor position is consistent before we erase lines.
            if self._dirty and self._separator_printed:
                self._render_lines()

            if self._separator_printed:
                # Move up to the separator line and clear all 4 lines
                # We're currently after the 3 dynamic lines, so move up 3 times to get to line after separator
                sys.stdout.write(ANSI_CURSOR_UP_ONE * BASH_LIVE_VIEW_DYNAMIC_LINES)
                # Now move up one more to get to the separator line itself
                sys.stdout.write(ANSI_CURSOR_UP_ONE)
                # Clear all 4 lines without adding newlines (to avoid empty space)
                for i in range(BASH_LIVE_VIEW_TOTAL_LINES):
                    sys.stdout.write(f"{ANSI_CARRIAGE_RETURN}{ANSI_ERASE_LINE}")
                    if i < BASH_LIVE_VIEW_TOTAL_LINES - 1:
                        sys.stdout.write("\n")
                # Move cursor back up to where the separator was
                sys.stdout.write(ANSI_CURSOR_UP_ONE * (BASH_LIVE_VIEW_TOTAL_LINES - 1))
                # Position at start of line
                sys.stdout.write(ANSI_CARRIAGE_RETURN)
                sys.stdout.flush()
                
                # Reset state
                self._separator_printed = False
                self._lines_printed = 0
                self._last_stdout = ""
                self._last_stderr = ""
                self._last_update_time = None
                self._dirty = False
