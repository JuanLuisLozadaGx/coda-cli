import threading
import time
import itertools
import sys

def create_loading_animation(message="Working", spinner_color="38;5;213", message_color="1;36"):
    """
    Create a loading animation function that can be started and stopped.
    
    Args:
        message (str): The message to display alongside the animation
        spinner_color (str): ANSI color code for the spinner animation
        message_color (str): ANSI color code for the message text
        
    Returns:
        tuple: (start_animation, stop_animation) functions
    """
    # Animation frames
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    # Alternative options:
    # frames = ["-", "\\", "|", "/"]  # Simple spinner
    # frames = ["▖", "▘", "▝", "▗"]  # Box drawing animation
    # frames = ["◜", "◠", "◝", "◞", "◡", "◟"]  # Circle animation
    
    stop_event = threading.Event()
    animation_thread = None
    
    def _clear_line(end_with_newline: bool = False) -> None:
        """Clear the current console line and optionally append a newline."""
        if sys.stdout.isatty():
            sys.stdout.write("\r\033[2K")  # Clear line only in TTY
        if end_with_newline:
            sys.stdout.write("\n")
        sys.stdout.flush()

    def animate():
        for frame in itertools.cycle(frames):
            if stop_event.is_set():
                break

            # Clear the current line
            sys.stdout.write("\r")

            # Print the colored spinner
            sys.stdout.write(f"\033[{spinner_color}m{frame}\033[0m ")

            # Print the message with different color and formatting
            sys.stdout.write(f"\033[{message_color}m{message}...\033[0m ")

            sys.stdout.flush()
            time.sleep(0.1)
    
    def start_animation():
        nonlocal animation_thread

        # Reset the stop event
        stop_event.clear()

        # Create and start the animation thread
        animation_thread = threading.Thread(target=animate)
        animation_thread.daemon = True  # Thread will exit when main program exits
        animation_thread.start()

    def stop_animation(end_with_newline: bool = True):
        """Stop the animation and clear the line."""
        stop_event.set()

        # Wait for the animation thread to finish
        if animation_thread and animation_thread.is_alive():
            animation_thread.join(timeout=0.5)

        _clear_line(end_with_newline)

    return start_animation, stop_animation
