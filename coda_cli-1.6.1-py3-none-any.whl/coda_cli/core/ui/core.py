from loguru import logger
import shutil
import re
from typing import Dict, Any, List, Optional, Callable, Sequence
import time
import os
import typer
from datetime import datetime, timezone
from importlib.metadata import version, PackageNotFoundError

from prompt_toolkit import print_formatted_text
from prompt_toolkit.formatted_text import HTML
from pygments import highlight
from pygments.lexers import get_lexer_by_name
from pygments.lexers.special import TextLexer
from pygments.formatters.terminal256 import Terminal256Formatter

from coda_cli.config.constants import (
    SLACK_CHANNEL_NAME,
    SLACK_CHANNEL_URL,
    TOOL_NAME_EMOJIS,
    RISK_LEVEL_COLORS,
    RISK_LEVEL_ICONS,
    PROVIDER_DISPLAY_NAMES,
    SUPPORT_EMAIL
)

from coda_core.config.constants import (
    DIAGNOSE_AGENT,
    FIX_AGENT,
    EXPLAIN_AGENT,
    CODEFIXER_AGENTS,
)

from coda_cli.core.ui.tools.constants import (
    RESULT_BLOCK_MAX_LINES,
    RESULT_BLOCK_MAX_CHARS,
)

# Direct action handlers moved to registry pattern
CLI_DEFAULT_STYLE = {
    'prompt': 'ansiblue bold',
    'command': 'ansilightgray',
    'selected-files': 'bg:#3A3341 ansilightgray',
    'coda-title': 'ansibrightblue bold',
    'coda-subtitle': 'ansibrightcyan',
    'completion-menu': 'bg:#3A3341 ansilightgray',
    'completion.command': 'bg:#3A3341 ansibrightcyan',
    'completion.agent.local': 'bg:#3A3341 ansibrightcyan',
    'completion.agent.remote': 'bg:#3A3341 ansibrightmagenta'
}

class Colors:
    """ANSI color codes for terminal output formatting."""
    
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    
    RED = "\033[1;31m"
    GREEN = "\033[1;32m"
    YELLOW = "\033[1;33m"
    CYAN = "\033[1;36m"
    GRAY = "\033[90m"
    
    ENABLED = "\033[1;32m●\033[0m"
    DISABLED = "\033[1;31m○\033[0m"
    
    CLEAR_SCREEN = "\033[2J\033[H"

def resolve_package_version(packages: Sequence[str], fallback: str) -> str:
    """Resolve the first available version from a list of package candidates.

    Tries each package name in order and returns the version of the first one
    that resolves via ``importlib.metadata.version``. If none resolve, returns
    the provided ``fallback``.

    This function is generic and makes no assumptions about application
    semantics; it simply implements the try-in-order logic.

    Args:
        packages (Sequence[str]): Ordered package names to attempt.
        fallback (str): Version to return if none of the packages resolve.

    Returns:
        str: Resolved version string, or ``fallback`` when none succeed.
    """

    for pkg in packages:
        try:
            resolved = version(pkg)
            logger.debug(f"Retrieved version {resolved} for package {pkg}")
            return resolved
        except PackageNotFoundError:
            logger.debug(f"Package {pkg} not found.")
        except Exception as exc:  # pylint: disable=broad-exception-caught
            logger.error(f"Error occurred while retrieving version for {pkg}: {exc}")

    logger.warning(f"Could not determine package version, defaulting to {fallback}")
    return fallback


# Implementation detail: package candidates used to determine the installed CODA package version.
# This is a private constant and may change; do not rely on it outside this module.
# Using an immutable tuple avoids mutable-default pitfalls and centralizes the application's canonical package names.
_DEFAULT_CODA_PACKAGE_CANDIDATES = ('coda', 'coda-cli')

def get_coda_installation_version(fallback: str = "1.0.0") -> str:
    """Return the version string for the installed CODA distribution.

    Uses the canonical CODA package candidates (implementation detail: ``_DEFAULT_CODA_PACKAGE_CANDIDATES``)
    and returns the first successfully resolved version. Falls back to
    ``fallback`` when none resolve. This is the preferred API for retrieving the
    "CODA installation" version displayed in the UI.

    Args:
        fallback (str, optional): Version to return if no candidate package
            resolves. Defaults to "1.0.0" when omitted.

    Returns:
        str: The CODA installation version string, or ``fallback``.
    """
    return resolve_package_version(_DEFAULT_CODA_PACKAGE_CANDIDATES, fallback=fallback)


def clear_screen():
    """Clear the terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

def color(text: str, code: str) -> str:
    """
    Return ANSI-colored text with the specified color code.
    
    Applies ANSI color codes to the provided text and ensures proper reset
    of formatting after the text.
    
    Args:
        text (str): The text to be colored
        code (str): ANSI color code (e.g., "1;31" for bold red, "2" for faint)
        
    Returns:
        str: The text with ANSI color formatting applied
    """
    return f"\033[{code}m{text}\033[0m"


def truncate_middle(text: str, max_length: int) -> str:
    """Truncate text in the middle if it exceeds ``max_length``."""
    if len(text) <= max_length:
        return text

    # Visible placeholder (without ANSI codes). New lines will be added around it
    # when we build the final string, so we account for them here as well.
    placeholder_plain = "... [output truncated] ..."
    placeholder_visible_len = len(placeholder_plain) + 2  # leading + trailing \n
    # Not enough room for text – just return the placeholder itself
    if max_length <= placeholder_visible_len:
        return f"\n{color(placeholder_plain, '38;5;246')}\n"

    # Space available for the original text once the placeholder is inserted
    remaining = max_length - placeholder_visible_len
    head_len = remaining // 2                # Front slice length
    tail_len = remaining - head_len          # Back slice length (gets the odd char if any)

    placeholder_coloured = color(placeholder_plain, "38;5;246")
    return f"{text[:head_len]}\n{placeholder_coloured}\n{text[-tail_len:]}"


def truncate_lines(text: str, max_lines: int, max_chars: int) -> str:
    """Truncate text by line count *and* total character length.

    Shows the first ``max_lines // 2`` lines and last ``max_lines // 2`` lines
    with a ``... [N lines truncated] ...`` placeholder in between.  A final
    character-level cap is enforced via :func:`truncate_middle` as a safety net.

    Args:
        text: The text to (possibly) truncate.
        max_lines: Maximum number of output lines before truncation kicks in.
        max_chars: Maximum total character length (applied after line truncation).

    Returns:
        The original text if within limits, otherwise a truncated version.
    """
    lines = text.splitlines()

    if len(lines) <= max_lines and len(text) <= max_chars:
        return text

    # --- line-based truncation ---
    if len(lines) > max_lines:
        head_count = max_lines // 2
        tail_count = max_lines - head_count
        hidden = len(lines) - max_lines
        head = lines[:head_count]
        tail = lines[-tail_count:]
        placeholder = color(f"... [{hidden} lines truncated] ...", "38;5;246")
        text = "\n".join(head + [placeholder] + tail)

    # --- character-level safety net ---
    if len(text) > max_chars:
        text = truncate_middle(text, max_chars)

    return text


def block_header(title: str, icon: str = "💡", color_code: str = "38;5;81") -> str:
    """
    Create a colored header line for a block of content.
    
    Generates a visually distinct header with an icon and title, using
    colored line characters to create a styled UI element.
    
    Args:
        title (str): The title text to display in the header
        icon (str, optional): An emoji or icon to display. Defaults to "💡".
        color_code (str, optional): ANSI color code for styling. Defaults to "38;5;81".
        
    Returns:
        str: A formatted header line with the specified styling
    """
    # We'll do 2 dashes after the corner for the header
    line_part = color("╭──", color_code)
    line_first_part = f"{line_part} {icon} {title}"
    line_so_far_len = len(line_first_part) + 1
    # We want a total of 30 chars. We'll see how many we have so far:
    total_width = 46 # to account for 🛠️ length
    needed = total_width - line_so_far_len
    if needed < 0:
        needed = 0
    trailing = "─" * needed
    trailing_colored = color(trailing, color_code)
    return f"{line_first_part} {trailing_colored}"


def block_line(label: str, value: str, label_width: int = 10, box_color: str = "38;5;81", line_color: str = None) -> str:
    """
    Create a formatted line with a label and value for a block.
    
    Generates a line with a vertical bar, label, and value with appropriate styling.
    Used for displaying parameter details within a block.
    
    Args:
        label (str): The label text to display
        value (str): The value text to display
        label_width (int, optional): Width for label field. Defaults to 10.
        box_color (str, optional): ANSI color code for box elements. Defaults to "38;5;81".
        line_color (str, optional): ANSI color code for the vertical line. If provided, overrides box_color for the line.
        
    Returns:
        str: A formatted line with the specified label and value
    """
    # Use line_color for the vertical bar if provided, otherwise use box_color
    line_part = color("│", line_color if line_color else box_color)
    faint_label = color(label.ljust(label_width), "2")  # faint
    normal_value = color(value, "0")                    # normal
    return f"{line_part} {faint_label} : {normal_value}"


def block_midline_with_result(result_label: str = "✅", color_code: str = "38;5;81") -> str:
    """
    Create a formatted middle line for a block with a result indicator.
    
    Generates a midline separator with a result label (like ✅ or ❌) for
    visually separating content within a block.
    
    Args:
        result_label (str, optional): The label to display in the midline. Defaults to "✅".
        color_code (str, optional): ANSI color code for styling. Defaults to "38;5;81".
        
    Returns:
        str: A formatted midline with the specified result label
    """
    prefix = color("├──", color_code)
    full_text = f"{prefix} {result_label} "
    line_so_far_len = len("├── ") + len(result_label) + 1

    total_width = 30
    needed = total_width - line_so_far_len
    if needed < 0:
        needed = 0
    trailing = "─" * needed
    trailing_colored = color(trailing, color_code)
    return f"{full_text}{trailing_colored}"


def block_result_line(result_label: str = "✅", color_code: str = "38;5;81") -> str:
    """
    Create a formatted result line with a curved corner and result indicator.
    
    Generates a single-line result with a curved corner (╰──) and a result label
    (like ✅ or ❌) for displaying simple results without additional parameters.
    
    Args:
        result_label (str, optional): The label to display in the result line. Defaults to "✅".
        color_code (str, optional): ANSI color code for styling. Defaults to "38;5;81".
        
    Returns:
        str: A formatted result line with the specified result label
    """
    prefix = color("╰──", color_code)
    full_text = f"{prefix} {result_label} "
    line_so_far_len = len("╰── ") + len(result_label) + 1
    
    total_width = 30
    needed = total_width - line_so_far_len
    if needed < 0:
        needed = 0
    trailing = "─" * needed
    trailing_colored = color(trailing, color_code)
    
    return f"{full_text}{trailing_colored}"


def block_footer(color_code: str = "38;5;81") -> str:
    """
    Create a formatted footer line for a block.
    
    Generates the bottom border of a content block with appropriate styling.
    
    Args:
        color_code (str, optional): ANSI color code for styling. Defaults to "38;5;81".
        
    Returns:
        str: A formatted footer line
    """
    footer = f"╰{'─'*30}"
    return color(footer, color_code)


def _print_block_value(key: str, raw_val: str, box_color: str = "38;5;81") -> None:
    """Print a single key/value pair inside a tool or result block.

    Handles truncation (both line-count and character-count) and multiline
    continuation lines so that the caller doesn't have to duplicate this logic.

    Args:
        key: The label displayed on the left of the block line.
        raw_val: The raw string value to display (will be truncated if needed).
        box_color: ANSI colour code for the ``│`` pipe character.
    """
    val_str = truncate_lines(raw_val, max_lines=RESULT_BLOCK_MAX_LINES, max_chars=RESULT_BLOCK_MAX_CHARS)

    if '\n' in val_str:
        lines = val_str.split('\n')
        print(block_line(key, lines[0], label_width=12, box_color=box_color))
        line_part = color("│", box_color)
        for line in lines[1:]:
            print(f"{line_part} {line}")
    else:
        print(block_line(key, val_str, label_width=12, box_color=box_color))


def print_tool_block(title: str, params: Dict[str, Any]) -> None:
    """
    Print a formatted block for a tool with its parameters.
    
    Displays a tool's title and parameters in a visually distinct block format.
    Special handling for "think" tools and skips certain fields like old_string 
    and new_string.
    
    Args:
        title (str): The title of the tool
        params (Dict[str, Any]): A dictionary of parameters to display
    """
    normalized_title = title.strip().lower()
    # We'll color the header line, then normal text for icon/title after a space
    if normalized_title == "think":
        print("💭 Thought")
        for k, v in params.items():
            if k.lower() == "metadata":
                continue
            print_intermediate_response(str(v))
        return
    elif normalized_title == "ask_user": 
        return

    icon = TOOL_NAME_EMOJIS.get(title.strip().lower(), TOOL_NAME_EMOJIS["default"])

    print(block_header(title, icon=icon, color_code="38;5;81"))
    for k, v in params.items():
        # Skip printing old_string, new_string, and metadata fields
        if k.lower() in ["old_string", "new_string", "metadata"]:
            continue
        # Skip empty values
        if v == "":
            continue
        _print_block_value(k, str(v))
    

def print_result_block(is_error: bool, result_dict: dict, tool_params: dict = None): #
    # If diff is present in result, display formatted diff instead of message
    if "diff" in result_dict:
        # Determine label based on error status
        label = "❌" if is_error else "✅"
        # Print result midline
        midline = block_midline_with_result(label, "38;5;81")
        print(midline)
        # Print formatted diff
        print_diff_lines(result_dict["diff"])
        # Print footer
        print(block_footer("38;5;81"))
        return
    if is_error:
        label = "❌"
    else:
        label = "✅"

    # Filter out result-specific keys and keys already shown in tool block
    filtered_keys = {"status", "command", "file", "metadata"}
    if tool_params:
        # Add keys that were displayed in tool block (excluding old_string, new_string, empty values)
        filtered_keys.update(k.lower() for k, v in tool_params.items() 
                            if k.lower() not in ["old_string", "new_string"] and v != "")
    
    # Check if there are any parameters to display after filtering
    visible_params = {k: v for k, v in result_dict.items()
                     if k.lower() not in filtered_keys and v != ""}

    if not visible_params:
        result_line = block_result_line(label, "38;5;81")
        print(result_line)
        return

    # Regular output with parameters
    midline = block_midline_with_result(label, "38;5;81")
    print(midline)
    # Now param lines
    for k, v in result_dict.items():
        # Skip keys already shown in tool block and result-specific keys
        if k.lower() in filtered_keys:
            continue
        # Skip empty values
        if v == "":
            continue
        _print_block_value(k, str(v))
    print(block_footer("38;5;81"))
    
    # Special handling for plan approval: show the plan file path after the result block
    if "plan_file_path" in result_dict and result_dict.get("status") == "✅ Approved":
        print()  # Add spacing
        # Bold and green colored text for better visibility
        bold = "\033[1m"
        green = "\033[32m"
        reset = "\033[0m"
        
        # Make the path clickable using print_hyperlink (for VS Code and other terminals)
        plan_path = result_dict['plan_file_path']
        print(f"📄 {bold}{green}You can find the detailed plan here:{reset}")
        print_hyperlink(f"  {plan_path}", f"file://{plan_path}", "34")  # blue color


def print_diff_lines(diff_lines: List[str]) -> None:
    """
    Print a formatted display of diff output.
    
    Takes a list of diff lines and formats them with appropriate colors
    to highlight additions, deletions, and context.
    
    Args:
        diff_lines (List[str]): A list of strings representing diff output
    """
    # Skip the first few lines (header information)
    lines_to_show = diff_lines[3:] if len(diff_lines) > 3 else diff_lines
    box_color = "38;5;81"

    # Inspect each line for trailing newlines and process accordingly
    for line in lines_to_show:
        # Remove any built-in newlines that might be causing the issue
        line = line.rstrip('\n')

        if line.startswith("│ -"):
            minus_text = line[2:]  # skip "│ "
            colored_minus = color(minus_text, "31")  # red
            print(f"{color('│', box_color)} {colored_minus}")
        elif line.startswith("│ +"):
            plus_text = line[2:]
            colored_plus = color(plus_text, "32")  # green
            print(f"{color('│', box_color)} {colored_plus}")
        else:
            ctx_text = line[2:]
            faint_text = color(ctx_text, "2")
            print(f"{color('│', box_color)} {faint_text}")

def print_final_response(response_text: str | None) -> None:
    """
    Print a formatted final response from the AI agent.
    
    Displays the response in a styled box format with header and footer.
    
    Args:
        response_text: The response text to display, or None to show a default message
    """
    if response_text is None:
        response_text = "[SYSTEM MESSAGE] All done! Response was already provided or there's no new content to display."
    
    color_code = "38;5;213"
    title = color("🤖 RESPONSE", color_code)
    separator = color("─" * 24, color_code)
    print("")
    print(title)
    print(separator)
    print()
    print(response_text)

def print_intermediate_response(response_text: str) -> None:
    """
    Print an intermediate response or thought from the AI agent.
    
    Displays in-progress responses or thought processes with subtle styling
    to differentiate from final responses.
    
    Args:
        response_text (str): The intermediate response text to display
    """
    color_code = "38;5;246"
    print()
    print(color(response_text, color_code))


def print_banner() -> None:
    """
    Display the CODA CLI application banner.
    
    Prints a visually distinct banner showing the CODA system name and version information.
    Also displays a quick start message to help users begin using the application.
    
    Args:
        session_name (str, optional): Name of the current session to display
    """
    # Clear the screen first
    clear_screen()
    
    # Use a consistent gradient from blue to purple/magenta with softer tones
    CODA_DARK_BLUE = "\033[38;5;67m"     # Softer slate blue for 'C'
    CODA_MEDIUM_BLUE = "\033[38;5;110m"  # Softer medium blue for 'O'
    reset_color = "\033[0m"
    box_color = CODA_DARK_BLUE
    
    ver = get_coda_installation_version()

    # Title box with Globant branding
    title_text_start = "Welcome to CODA! "
    title_text_end = f"AI Coding Agent v{ver}"
    green_text = "Globant's"
    
    # Calculate the total visible length (accounting for color codes not adding to displayed width)
    full_title_length = len(title_text_start) + len(green_text) + len(title_text_end)
    box_width = full_title_length + 4  # Add padding for the box edges
    
    # Create the boxed title
    print(f"{box_color}╭{'─' * (box_width - 2)}╮{reset_color}")
    print(f"{box_color}│ {reset_color}{title_text_start}{CODA_DARK_BLUE}{green_text}{reset_color} {title_text_end}{' ' * (box_width - full_title_length - 4)}{box_color}│{reset_color}")
    print(f"{box_color}╰{'─' * (box_width - 2)}╯{reset_color}")
    print()

    # Coda-themed logo
    space_block = "    "
    logo = f"""
{space_block}{CODA_MEDIUM_BLUE} ██████╗{CODA_MEDIUM_BLUE} ██████╗ {CODA_MEDIUM_BLUE}██████╗ {CODA_MEDIUM_BLUE} █████╗ {reset_color}
{space_block}{CODA_MEDIUM_BLUE}██╔════╝{CODA_MEDIUM_BLUE}██╔═══██╗{CODA_MEDIUM_BLUE}██╔══██╗{CODA_MEDIUM_BLUE}██╔══██╗{reset_color}
{space_block}{CODA_MEDIUM_BLUE}██║     {CODA_MEDIUM_BLUE}██║   ██║{CODA_MEDIUM_BLUE}██║  ██║{CODA_MEDIUM_BLUE}███████║{reset_color}
{space_block}{CODA_MEDIUM_BLUE}██║     {CODA_MEDIUM_BLUE}██║   ██║{CODA_MEDIUM_BLUE}██║  ██║{CODA_MEDIUM_BLUE}██╔══██║{reset_color}
{space_block}{CODA_MEDIUM_BLUE}╚██████╗{CODA_MEDIUM_BLUE}╚██████╔╝{CODA_MEDIUM_BLUE}██████╔╝{CODA_MEDIUM_BLUE}██║  ██║{reset_color}
{space_block}{CODA_MEDIUM_BLUE} ╚═════╝{CODA_MEDIUM_BLUE} ╚═════╝ {CODA_MEDIUM_BLUE}╚═════╝ {CODA_MEDIUM_BLUE}╚═╝  ╚═╝{reset_color}
    """
    print(logo)


def print_session_oneliner(session_name: str) -> None:
    """
    Display session information in a formatted box.
    
    Args:
        session_name (str): The name of the current session
    """
    print_formatted_text(HTML(f'<ansibrightblue>💻 Current session: <ansibrightyellow>{session_name}</ansibrightyellow></ansibrightblue>'))


def print_current_model(
    provider_name: str,
    model_name: str,
    reasoning_effort: Optional[str] = None,
) -> None:
    """
    Display the currently configured AI model with prettified provider name.
    
    Args:
        provider_name (str): The name of the model provider
        model_name (str): The name of the model
        reasoning_effort (Optional[str]): Selected reasoning effort, if available.
    """
    # Get prettified provider name from constants, fallback to capitalized version
    prettified_provider = PROVIDER_DISPLAY_NAMES.get(provider_name, provider_name.replace('_', ' ').title())
    formatted_display = f"{model_name} (via {prettified_provider})"
    reasoning_suffix = ""
    if reasoning_effort:
        reasoning_display = "default" if reasoning_effort.strip().lower() == "none" else reasoning_effort
        reasoning_suffix = f" · reasoning: {reasoning_display}"
    print_formatted_text(HTML(
        f'<ansibrightblue>🧠 Current model: '
        f'<ansibrightyellow>{formatted_display}</ansibrightyellow>'
        f'<ansibrightyellow>{reasoning_suffix}</ansibrightyellow>'
        f'</ansibrightblue>'
    ))


def print_quick_start() -> None:
    """
    Display a quick start message for the CODA CLI application.
    """
    message = '<ansibrightblue>⚡Use CODA for any coding task!</ansibrightblue>\n'
    message += '<ansibrightblue> • Type</ansibrightblue> <ansiyellow>/help</ansiyellow> <ansibrightblue>to view all available commands</ansibrightblue>\n'
    message += '<ansibrightblue> • Use</ansibrightblue> <ansiyellow>/sm</ansiyellow> <ansibrightblue>to switch between AI models</ansibrightblue>\n'
    message += '<ansibrightblue> • Use</ansibrightblue> <ansiyellow>/s</ansiyellow> <ansibrightblue>to manage sessions</ansibrightblue>\n'
    message += '<ansibrightblue> • Type</ansibrightblue> <ansiyellow>@</ansiyellow> <ansibrightblue>to select agents and</ansibrightblue> <ansiyellow>/mode</ansiyellow> <ansibrightblue>to select plan mode</ansibrightblue>\n'
    print_formatted_text(HTML(message))
    print()


def goodbye() -> None:
    """
    Display a goodbye message when exiting the application.
    
    Prints a nicely formatted message to inform the user that the
    system has been disconnected.
    """
    print_formatted_text(HTML('<coda-title>System disconnected. Goodbye.</coda-title>'))


def display_memory_condensing_start(message: str) -> None:
    """
    Display a message when memory condensing starts.
    
    Args:
        message (str): The message to display
    """
    print_formatted_text(HTML(
        f"\n<ansibrightblue>💾 Memory Condensing Starting:</ansibrightblue> {message}. Stand by..."
    ))


def display_memory_condensing_complete(metadata: Dict[str, Any]) -> None:
    """
    Display successful memory condensing results including token savings.
    
    Args:
        metadata (Dict[str, Any]): Metadata about the condensing operation, including:
            - messages_condensed: Number of messages condensed
            - tokens_removed: Tokens removed by condensing
            - tokens_added: Tokens added by the summary
            - net_token_change: Net change in tokens
    """
    # Extract metadata values with defaults
    messages_condensed = metadata.get('messages_condensed', 0)
    tokens_removed = metadata.get('tokens_removed', 0)
    tokens_added = metadata.get('tokens_added', 0)
    net_token_change = metadata.get('net_token_change', 0)
    
    # Calculate token savings percentage
    savings_percent = (abs(net_token_change) / tokens_removed * 100) if tokens_removed > 0 else 0
    
    # Display results in a compact format
    print_formatted_text(HTML(
        f"\n<ansibrightblue>💾 Memory Condensing Complete:</ansibrightblue> "
        f"{messages_condensed} messages condensed, {tokens_removed:,} tokens → {tokens_added:,} tokens "
        f"(saved <ansibrightgreen>{abs(net_token_change):,}</ansibrightgreen> tokens, {savings_percent:.1f}%)"
    ))


def display_memory_condensing_skipped(metadata: Dict[str, Any]) -> None:
    """
    Display information when memory condensing was skipped.
    
    Args:
        metadata (Dict[str, Any]): Metadata about why condensing was skipped, including:
            - reason: The reason condensing was skipped
    """
    # Extract the reason with a default
    reason = metadata.get('reason', 'Unknown reason')
    
    # Display results in a compact format
    print_formatted_text(HTML(f"\n<ansibrightblue>💾 Memory Condensing Skipped:</ansibrightblue> {reason}"))


def display_memory_condensing_error(error_description: str) -> None:
    """
    Display information when memory condensing encountered an error.
    
    Args:
        error_description (str): Description of the error that occurred
    """
    # Display error in a compact format with red color for visibility
    print_formatted_text(HTML(f"\n<ansibrightblue>❌ Memory Condensing Error:</ansibrightblue> {error_description}"))


def print_initialized(cwd: str) -> None:
    """
    Displays the current working directory.
    If the session's original directory differs from the actual current working directory,
    that information is shown as well.

    Args:
        cwd (str): The directory stored in the session (where the session was originally created).
    """
    actual_cwd = os.getcwd()
    
    # Always show the actual current directory as the primary location
    print_formatted_text(HTML(f"<ansibrightblue>📂 Current working directory: <ansibrightyellow>{actual_cwd}</ansibrightyellow></ansibrightblue>"))
    
    # If session directory is different, show it as additional info with more descriptive text
    if cwd != actual_cwd:
        print_formatted_text(HTML(f"<ansimagenta>   Beware! This session was originally created in {cwd}</ansimagenta>"))
    
def print_invalid_geai_credentials() -> None:
    """
    Display an error message when GEAI credentials are invalid.
    """
    print("\n\033[1;33m⚠️ Your GEAI credentials appear to be invalid.\033[0m\n")

    print("Possible causes:")
    causes = ["API key expired", "API key ran out of quota", "Incorrect GEAI URL or API key value"]
    for c in causes:
        print(f"  \033[1;33m• {c}\033[0m")
    print()

    print(f"Try reconfiguring them with: \033[1;33m`coda-cli --reconfigure`\033[0m\n")

    print_formatted_text(HTML(
        '<ansiyellow>'
        "If you're unsure about the correct GEAI URL or API key, reach us via:"
        '</ansiyellow>'
    ))

    print_contact_methods()


def print_model_not_available(error_message: str) -> None:
    """
    Display an error message when the model is not available.
    """
    print(f"\n\033[1;33m⚠️ {error_message}\033[0m\n")
    print("Use /switch-model to select a different model.")


def print_contact_methods() -> None:
    """
    Print the contact methods for support.
    """
    contact_methods = [
        {"text": f"Slack: {SLACK_CHANNEL_NAME}", "url": SLACK_CHANNEL_URL},
        {"text": f"Email: {SUPPORT_EMAIL}", "url": f"mailto:{SUPPORT_EMAIL}"},
    ]
    for method in contact_methods:
        print_hyperlink(f"- {method['text']}", method['url'])

    print()


def print_hyperlink(text: str, url: str, colour: str = "34") -> None:
    """
    Render a clickable hyperlink in the terminal.

    This is like a normal print() but with a hyperlink that can be clicked.

    Args:
        text (str): The text to display for the hyperlink
        url (str): The URL that the hyperlink points to
        colour (str, optional): ANSI color code for the hyperlink. Defaults to "34" (blue).
    """
    ESC = "\033"          # byte 0x1b
    ST  = ESC + "\\"      # “String Terminator”  (= ESC \)

    set_colour = f"{ESC}[{colour}m"
    reset    = f"{ESC}[0m"
    
    open_link  = f"{ESC}]8;;{url}{ST}"
    close_link = f"{ESC}]8;;{ST}"

    typer.echo(f"{set_colour}{open_link}{text}{close_link}{reset}") 


def show_version() -> None:
    """
    Display the CODA CLI version information in a formatted box.
    
    This function is called when the --version flag is used.
    It displays the current version of CODA CLI in a visually appealing format.
    """
    try:
        cli_ver = get_coda_installation_version()
        coda_ver = resolve_package_version(["coda"], fallback="not installed")
        coda_core_ver = resolve_package_version(["coda-core"], fallback="not installed")

        # Determine installation mode and output structure
        is_metapackage = coda_ver != "not installed"
        print_formatted_text(HTML(f'\n<ansibrightblue>CODA Installation Mode: <ansibrightyellow>{"Metapackage" if is_metapackage else "Standalone CLI"}</ansibrightyellow></ansibrightblue>'))
        if is_metapackage:
            print_formatted_text(HTML(f'<ansibrightblue>Metapackage version <ansibrightyellow>{coda_ver}</ansibrightyellow></ansibrightblue>'))
        print_formatted_text(HTML(f'<ansibrightblue>CODA CLI version <ansibrightyellow>{cli_ver}</ansibrightyellow></ansibrightblue>'))
        print_formatted_text(HTML(f'<ansibrightblue>coda-core dependency version <ansibrightyellow>{coda_core_ver}</ansibrightyellow></ansibrightblue>'))
        print_formatted_text(HTML('<ansibrightcyan>AI-powered code assistant</ansibrightcyan>\n'))
    except Exception:
        print_formatted_text(HTML('\n<ansibrightblue>CODA CLI <ansibrightyellow>development version</ansibrightyellow></ansibrightblue>'))
        print_formatted_text(HTML('<ansibrightcyan>AI-powered code assistant</ansibrightcyan>\n'))




def display_model_selector_header(current_model: str, page: int, total_pages: int) -> None:
    """
    Display the header for the model selector UI.
    
    Args:
        current_model (str): The currently selected model (provider/name)
        page (int): Current page number
        total_pages (int): Total number of pages
    """
    # Clear screen for better UX
    print("\033[2J\033[H", end="")
    
    # Display header
    print("\n\033[1;36mModel Selector\033[0m")
    print("\033[1;36m=============\033[0m")
    print(f"Current model: \033[1;33m{current_model}\033[0m")
    
    # Display pagination info
    print(f"\nPage {page} of {total_pages}")


def format_model_entry(
    idx: int,
    model_name: str,
    context_size: int,
    max_output: int,
    is_current: bool = False,
    reasoning_efforts: Optional[List[str]] = None,
) -> str:
    """
    Format a model entry for display in the model selector.
    
    Args:
        idx (int): Display index for the model
        model_name (str): The name of the model
        context_size (int): The context window size
        max_output (int): Maximum output tokens
        is_current (bool): Whether this is the currently selected model
        reasoning_efforts (Optional[List[str]]): Available reasoning efforts for this model.
        
    Returns:
        str: Formatted model entry string
    """
    # Format marker and name
    if is_current:
        marker = "*"
        name_format = "\033[1;33m{}\033[0m"
    else:
        marker = " "
        name_format = "{}"
    
    formatted_name = name_format.format(model_name)
    
    # Format context window size
    if context_size >= 100000:
        context_display = f"{context_size//1000}K"
    else:
        context_display = str(context_size)

    reasoning_label = ""
    if reasoning_efforts:
        display_efforts = ["default" if effort == "none" else effort for effort in reasoning_efforts]
        reasoning_label = f", reasoning: {', '.join(display_efforts)}"

    return (
        f"  \033[1;36m{idx:2d}.\033[0m [{marker}] {formatted_name} "
        f"\033[2m(context: {context_display}, max output: {max_output}{reasoning_label})\033[0m"
    )


def display_provider_header(provider_name: str) -> None:
    """
    Display a provider header in the model selector.
    
    Args:
        provider_name (str): The name of the provider
    """
    print(f"\n\033[1;32m{provider_name.capitalize()} Models:\033[0m")


def display_navigation_options() -> None:
    """
    Display navigation options for the model selector.
    """
    print("\n\033[1mNavigation:\033[0m")
    print("  n: Next page")
    print("  p: Previous page")
    print("  q: Cancel selection")
    print("  Or enter a number to select a model")


def display_model_change_success(provider: str, model: str) -> None:
    """
    Display a success message after changing the model.
    
    Args:
        provider (str): The provider name
        model (str): The model name
    """
    print(f"\n\033[1;32mModel changed to: {provider}/{model}\033[0m")
    print("\033[2mYour configuration has been updated.\033[0m")


def display_model_selection_cancelled() -> None:
    """
    Display a message when model selection is cancelled.
    """
    print("\n\033[2mModel selection cancelled. No changes made.\033[0m")


def display_error_message(message: str) -> None:
    """
    Display an error message to the user.

    Args:
        message (str): The error message to display.
    """
    print(f"\n\033[1;31m{message}\033[0m")
    input("Press Enter to continue...")


def print_markdown_response(markdown_text: str) -> None:
    """
    Print a markdown-formatted response with proper handling of
    indented code blocks and nested structures.
    
    Args:
        markdown_text (str): The markdown-formatted text to display
    """
    # Handle None values
    if markdown_text is None:
        markdown_text = "[SYSTEM MESSAGE] All done! Response was already provided or there's no new content to display."
    
    # Process the markdown with indentation awareness
    processed_text = process_markdown_with_indentation(markdown_text)
    
    # Use the existing print_final_response function
    print_final_response(processed_text)

def process_markdown_with_indentation(markdown: str) -> str:
    """
    Process markdown text with careful handling of indentation and nested structures.
    
    Args:
        markdown (str): The markdown text to process
        
    Returns:
        str: Processed text with proper formatting
    """ 
    # Background color for code blocks
    bg_color = "48;5;236"  # Dark gray background
    
    result = []
    lines = markdown.split('\n')
    i = 0
    
    while i < len(lines):
        line = lines[i]
        
        # Check for code block start (with any indentation)
        code_block_match = re.match(r'^(\s*)```(\w*)$', line)
        if code_block_match:
            # Extract indentation and language
            indentation = code_block_match.group(1)
            language = code_block_match.group(2).strip()
            
            # Collect code lines
            code_lines = []
            i += 1
            
            # Find the end of the code block (matching indentation)
            while i < len(lines) and not re.match(f'^{re.escape(indentation)}```$', lines[i]):
                # Remove the same amount of indentation from each code line
                if lines[i].startswith(indentation):
                    code_line = lines[i][len(indentation):]
                else:
                    code_line = lines[i]
                code_lines.append(code_line)
                i += 1
            
            # Skip the closing backticks
            if i < len(lines):
                i += 1
            
            # Apply syntax highlighting
            code = '\n'.join(code_lines)
            if language:
                try:
                    lexer = get_lexer_by_name(language, stripall=True)
                except:
                    lexer = TextLexer()
            else:
                lexer = TextLexer()
            
            # Add an empty line before the code block
            result.append("")
            
            # Add language indicator with cyan color
            if language:
                result.append(f"{indentation}\033[36m[{language}]\033[0m")
            
            # Get the highlighted code
            highlighted = highlight(code, lexer, Terminal256Formatter(style='monokai'))
            highlighted_lines = highlighted.splitlines()
            
            # Find the maximum line length for padding
            max_line_length = 0
            for hl in highlighted_lines:
                # Strip ANSI codes to get actual visible length
                visible_line = re.sub(r'\x1b\[[0-9;]*m', '', hl)
                max_line_length = max(max_line_length, len(visible_line))
            
            # Add each highlighted line with background color
            for hl in highlighted_lines:
                # Strip ANSI codes to get actual visible length
                visible_line = re.sub(r'\x1b\[[0-9;]*m', '', hl)
                padding = max_line_length - len(visible_line)
                
                # Apply background to the entire line with padding for rectangular shape
                result.append(f"{indentation}\033[{bg_color}m {hl}{' ' * padding} \033[0m")
            
            # Add an empty line after the code block
            result.append("")
            
            continue
        
        # Process headers (with any indentation)
        header_match = re.match(r'^(\s*)(#{1,6})\s+(.+)$', line)
        if header_match:
            indentation = header_match.group(1)
            level = len(header_match.group(2))
            content = header_match.group(3)
            
            # Format headers based on level
            if level <= 2:
                result.append(f"{indentation}\033[1;34m{content}\033[0m")  # Bold blue for h1-h2
            else:
                result.append(f"{indentation}\033[34m{content}\033[0m")  # Blue for h3-h6
            
            i += 1
            continue
        
        # Process bold and inline code while preserving indentation
        processed_line = line
        
        # Bold (**text**)
        processed_line = re.sub(r'\*\*(.*?)\*\*', r'\033[1m\1\033[0m', processed_line)
        
        # Inline code (`code`)
        processed_line = re.sub(r'`([^`]+)`', r'\033[90m\1\033[0m', processed_line)
        
        result.append(processed_line)
        i += 1
    
    return '\n'.join(result)


def print_formatted_error_message(error_message: str) -> None:
    """
    Display a formatted error message box.

    Args:
        error_message (str): The full error message string to display.
    """
    error_color = "38;5;196"  # Red color
    
    try:
        # Check for wrapped error messages from single_agent.py
        wrapped_error_match = re.search(r"An error occurred while processing the request: (Error code: \d+ - .+)", error_message)
        if wrapped_error_match:
            # Extract the actual error message
            error_message = wrapped_error_match.group(1)
        
        # Attempt to parse the error message
        # This is needed to extract the status code and error details from LiteLLM exceptions
        match = re.search(r"Error code: (\d+) - (.+)", error_message)
        if not match:
            raise ValueError("Invalid error message format")

        status_code = int(match.group(1))
        error_details = eval(match.group(2))  # Convert the string to a dictionary

        # Extract details from the error details
        error_type_map = {
            400: "BadRequestError",
            401: "AuthenticationError",
            403: "PermissionDeniedError",
            404: "NotFoundError",
            422: "UnprocessableEntityError",
            429: "RateLimitError",
            500: "InternalServerError",
        }
        error_type = error_type_map.get(status_code, "UnknownError")
        message = error_details.get("error", {}).get("message", "No message provided.")
        request_id = error_details.get("requestId", "N/A")
        context_info = error_details.get("context", None)

        # Display the parsed error details in a styled box
        print(block_header("GEAI ERROR", icon="❌", color_code=error_color))
        print(block_line("Status Code", str(status_code), box_color=error_color, line_color=error_color))
        print(block_line("Error Type", error_type, box_color=error_color, line_color=error_color))
        print(block_line("Request ID", request_id, box_color=error_color, line_color=error_color))
        print(block_line("Message", message, box_color=error_color, line_color=error_color))
        # Optional context data (provider/model/etc.)
        if isinstance(context_info, dict) and context_info:
            try:
                for k, v in context_info.items():
                    print(block_line(k.capitalize(), str(v), box_color=error_color, line_color=error_color))
            except Exception:
                # Fallback: render raw context
                print(block_line("Context", str(context_info), box_color=error_color, line_color=error_color))
        print(block_footer(error_color))

    except Exception:
        # Fallback: Display the full error message if parsing fails
        print(block_header("ERROR", icon="❌", color_code=error_color))
        print(block_line("Full Message", error_message, box_color=error_color, line_color=error_color))
        print(block_footer(error_color))


def format_large_number(number: int) -> str:
    """
    Format a large number into a human-readable string with K (thousands), M (millions), etc.

    Args:
        number (int): The number to format.

    Returns:
        str: The formatted number as a string.
    """
    if number >= 1_000_000:
        return f"{number / 1_000_000:.1f}M"  # Format as millions
    elif number >= 1_000:
        return f"{number / 1_000:.1f}K"  # Format as thousands
    return str(number)  # Return as-is for smaller numbers


def print_usage_summary(usage_summary: dict) -> None:
    """
    Display a right-aligned boxed one-liner usage summary with token details and total cost.

    Args:
        usage_summary (dict): A dictionary containing usage details, including:
            - prompt_tokens (int): Number of prompt tokens used.
            - completion_tokens (int): Number of completion tokens used.
            - total_cost (float): Total cost of the interaction.
            - currency (str): The currency of the cost (e.g., "USD").
    """
    # Extract details from the usage summary
    prompt_tokens = usage_summary.get("prompt_tokens")
    completion_tokens = usage_summary.get("completion_tokens")

    if prompt_tokens is None:
        prompt_tokens = usage_summary.get("input_tokens", 0)
    if completion_tokens is None:
        completion_tokens = usage_summary.get("output_tokens", 0)

    total_cost = usage_summary.get("total_cost")
    if total_cost is None:
        prompt_cost = usage_summary.get("prompt_cost", 0.0)
        completion_cost = usage_summary.get("completion_cost", 0.0)
        total_cost = prompt_cost + completion_cost

    currency = usage_summary.get("currency", "USD")

    # Format token counts
    formatted_prompt_tokens = format_large_number(prompt_tokens)
    formatted_completion_tokens = format_large_number(completion_tokens)

    # Combine tokens and costs into a single line
    usage_line = f"Tokens: ↑ {formatted_prompt_tokens} ↓ {formatted_completion_tokens} | Costs: {currency} {total_cost:.6f}"

    # Define subtle styling
    box_color = "38;5;246"  # Faint gray for subtle visibility

    # Calculate terminal width and padding
    terminal_width = shutil.get_terminal_size().columns
    box_width = len(usage_line) + 4  # Add padding for the box edges
    padding = max(0, terminal_width - box_width)

    # Create the boxed one-liner usage summary
    print(" " * padding + color("╭" + "─" * (box_width - 2) + "╮", box_color))
    print(" " * padding + color(f"│ {usage_line} │", box_color))
    print(" " * padding + color("╰" + "─" * (box_width - 2) + "╯", box_color))


def display_session_manager_header(current_session_name: str = None) -> None:
    """
    Display the header for the session manager UI.
    
    Args:
        current_session_name (str, optional): The name of the current session
    """
    # Clear screen for better UX
    clear_screen()
    
    # Display header
    print("\n\033[1;36mSession Manager\033[0m")
    print("\033[1;36m==============\033[0m")
    
    if current_session_name:
        print(f"Current session: \033[1;33m{current_session_name}\033[0m\n")
    else:
        print("No active session\n")
    
    # Display main menu
    print("\033[1mOptions:\033[0m")
    print("  1. Save current session")
    print("  2. Load a session")
    print("  3. Delete a session")
    print("  4. Rename a session")
    print("  q. Return to main interface")


def display_sessions_list(sessions: List[Dict[str, Any]], action: str = "select") -> None:
    """
    Display a list of available sessions.
    
    Args:
        sessions: List of session data dictionaries
        action: The action to perform on the sessions (select, load, delete, rename)
    """
    if not sessions:
        print("\nNo saved sessions found.")
        return
    
    print("\n\033[1mAvailable Sessions:\033[0m")
    print("-" * 80)
    print(f"{'#':<4} | {'Name':<30} | {'Last Updated':<20} | {'Summary':<20}")
    print("-" * 80)
    
    for i, session in enumerate(sessions, 1):
        id = session.get("id")
        # Get name from name_info if available, otherwise fall back to name
        if "name_info" in session:
            name = session["name_info"].get("current")
        else:
            name = session.get("name")
        updated = datetime.fromisoformat(session.get("updated_at")).strftime("%Y-%m-%d %H:%M:%S")
        
        # Get summary from metadata if available
        metadata = session.get("metadata", {})
        summary = metadata.get("summary", "")
        if len(summary) > 20:
            summary = summary[:17] + "..."
        
        # Check if session is locked
        locked_by = session.get("locked_by")
        locked_indicator = " \033[1;31m[IN USE]\033[0m" if locked_by else ""
        
        print(f"{i:<4} | {name[:30]:<30} | {updated:<20} | {summary:<20}{locked_indicator}")
    
    print("-" * 80)
    print(f"\nEnter the number of the session to {action} (or 'q' to cancel): ", end="")


def print_session_header(title: str = "Available Sessions") -> None:
    """
    Print a header for session listings.
    
    Args:
        title (str): The title to display
    """
    print(f"\n\033[1;36m{title}\033[0m")
    print("\033[1;36m" + "=" * len(title) + "\033[0m")
    print()


def format_session_timestamp(timestamp: str) -> str:
    """
    Format a session timestamp for display.
    
    Args:
        timestamp (str): ISO format timestamp string
        
    Returns:
        str: Formatted timestamp string (YYYY-MM-DD HH:MM:SS)
    """
    try:
        dt = datetime.fromisoformat(timestamp)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return timestamp


def print_session_info(
    index: int, 
    name: str, 
    updated_at: str, 
    file_count: int = 0, 
    message_count: int = 0,
    is_current: bool = False
) -> None:
    """
    Print formatted information about a session.
    
    Args:
        index (int): The session index number
        name (str): The session name
        updated_at (str): The timestamp when the session was last updated
        file_count (int): Number of files in the session
        message_count (int): Number of messages in the session
        is_current (bool): Whether this is the current active session
    """
    # Format the timestamp
    updated_str = format_session_timestamp(updated_at)
    
    # Add current marker if this is the current session
    current_marker = " \033[1;32m(current)\033[0m" if is_current else ""
    
    # Display session info
    print(f"{index}. {name}{current_marker} (Last updated: {updated_str})")
    print(f"   Files: {file_count}, Messages: {message_count}")


def get_session_stats(session: dict) -> tuple[int, int]:
    """
    Extract file count and message count from a session dictionary.
    
    Args:
        session (dict): Session data dictionary
        
    Returns:
        tuple: (file_count, message_count)
    """
    file_count = 0
    message_count = 0
    
    # Get client state for CLI
    client_states = session.get("client_states", {})
    cli_state = client_states.get("cli", {})
    
    # Get selected files count
    if cli_state:
        file_count = len(cli_state.get("selected_files", []))
    
    # Get message count from shared state
    shared_state = session.get("shared_state", {})
    memories = shared_state.get("memories", {})
    
    # Count messages in all memories
    message_count = 0
    for memory_key, memory_data in memories.items():
        messages = memory_data.get("messages", [])
        message_count += len(messages)
    
    return file_count, message_count


def display_session_list(
    sessions: list, 
    current_session_id: Optional[str] = None, 
    show_stats: bool = True,
    show_cancel_option: bool = True
) -> None:
    """
    Display a list of sessions with their details.
    
    Args:
        sessions (list): List of session dictionaries
        current_session_id (str, optional): ID of the current session
        show_stats (bool): Whether to show file and message counts
        show_cancel_option (bool): Whether to show the cancel option
    """
    if not sessions:
        print("\033[1;33mNo saved sessions found.\033[0m")
        return
    
    print_session_header()
    
    # Sort sessions by updated_at (newest first)
    sorted_sessions = sorted(sessions, key=lambda s: s.get("updated_at", ""), reverse=True)
    
    # Display session list with numbers
    for i, session in enumerate(sorted_sessions, 1):
        # Get name from name_info if available, otherwise fall back to name
        if "name_info" in session:
            name = session["name_info"].get("current", "Unnamed")
        else:
            name = session.get("name", "Unnamed")
        updated_at = session.get("updated_at", "")
        
        # Get stats if requested
        file_count = message_count = 0
        if show_stats:
            file_count, message_count = get_session_stats(session)
        
        # Check if this is the current session
        is_current = current_session_id is not None and current_session_id == session.get("id")
        
        # Display session info
        print_session_info(
            index=i,
            name=name,
            updated_at=updated_at,
            file_count=file_count,
            message_count=message_count,
            is_current=is_current
        )
    
    if show_cancel_option:
        print()
        print("0. Cancel")


def display_session_selector_header(
    header_text: str,
    current_session_name: str = None,
    page: int = 1,
    total_pages: int = 1
) -> None:
    """
    Display a header for the session selector UI.
    
    Args:
        header_text (str): The header text to display
        current_session_name (str, optional): The name of the current session
        page (int): Current page number
        total_pages (int): Total number of pages
    """
    # Clear screen for better UX
    print("\033[2J\033[H", end="")
    
    # Display header
    print(f"\n\033[1;36m{header_text}\033[0m")
    print("\033[1;36m" + "=" * len(header_text) + "\033[0m")
    
    if current_session_name:
        print(f"Current session: \033[1;33m{current_session_name}\033[0m")
    
    # Display pagination info if there are multiple pages
    if total_pages > 1:
        print(f"\nPage {page} of {total_pages}")


def display_session_navigation_options(
    header_text: str = "Available Sessions",
    allow_detailed_view: bool = True,
    show_create_option: bool = True,
    actions: List[str] = ["load"],
    primary_action: Optional[str] = None
) -> None:
    """
    Display navigation options for the session selector.
    
    Args:
        header_text (str): The header text of the current view to determine context
        allow_detailed_view (bool): Whether to show the detailed view option
        show_create_option (bool): Whether to show the create new session option
        actions (List[str]): List of actions that can be performed on sessions
    """
    print("\n\033[1mNavigation:\033[0m")
    
    # Pagination options
    print("  n: Next page")
    print("  p: Previous page")
    
    # Determine which options to show based on context
    is_view_only = header_text == "Available Sessions"
    is_load_view = header_text == "Load Session"
    is_delete_view = header_text == "Delete Session"
    is_rename_view = header_text == "Rename Session"
    
    # Only show detailed view option if:
    # 1. We're not already showing "view" action
    # 2. Detailed view is allowed
    detailed_view_condition = allow_detailed_view and "view" not in actions
    
    if detailed_view_condition:
        print("  v: Detailed view of a session")
    
    # Action options - only show actions that are relevant to current context
    action_descriptions = {
        "load": "Load a session",
        "delete": "Delete a session",
        "rename": "Rename a session",
        "view": "View session details"
    }
    
    # We don't need to show the primary action for the current view
    # since it's already clear from the header what action we're performing
    
    # Show other actions that aren't redundant
    for action in actions:
        # Skip the primary action (already shown) and other redundant actions
        skip_action = False
        if action == primary_action:
            skip_action = True
        elif action == "load" and (is_load_view or header_text == "Available Sessions"):
            skip_action = True
        elif action == "delete" and is_delete_view:
            skip_action = True
        elif action == "rename" and is_rename_view:
            skip_action = True
        
        if not skip_action and action in action_descriptions:
            print(f"  {action[0]}: {action_descriptions[action]}")
    
    # Create new session option
    if show_create_option:
        print("  c: Create a new session")
    
    print("  q: Cancel or return")
    
    # Only show the "enter a number" option when it makes sense
    # Don't show it in "Available Sessions" view when there are no actions that can be performed
    # by selecting a session number
    
    # Check if there are any actions that can be performed by selecting a number
    has_number_selectable_actions = False
    
    # Primary action is always selectable by number
    if primary_action:
        has_number_selectable_actions = True
    
    # If we're not in a specific action view and "load" is available, it's selectable by number
    if not (is_delete_view or is_load_view or is_rename_view) and "load" in actions:
        has_number_selectable_actions = True
    
    if has_number_selectable_actions:
        print("  Or enter a number to select a session")

def format_session_entry(
    idx: int,
    name: str,
    updated_at: str,
    file_count: int = 0,
    message_count: int = 0,
    is_current: bool = False,
    is_locked: bool = False
) -> str:
    """
    Format a session entry for display in the session selector.
    
    Args:
        idx (int): Display index for the session
        name (str): The name of the session
        updated_at (str): The timestamp when the session was last updated
        file_count (int): Number of files in the session
        message_count (int): Number of messages in the session
        is_current (bool): Whether this is the current active session
        is_locked (bool): Whether the session is locked by another process
        
    Returns:
        str: Formatted session entry string
    """
    # Format timestamp
    updated_str = format_session_timestamp(updated_at)
    
    # Format marker and name
    if is_current:
        marker = "*"
        name_format = "\033[1;33m{}\033[0m"
    else:
        marker = " "
        name_format = "{}"
    
    formatted_name = name_format.format(name)
    
    # Format locked indicator
    locked_indicator = " \033[1;31m[IN USE]\033[0m" if is_locked else ""
    
    # Format the entry
    entry = f"  \033[1;36m{idx:2d}.\033[0m [{marker}] {formatted_name} (Last updated: {updated_str}){locked_indicator}"
    stats = f"      Files: {file_count}, Messages: {message_count}"
    
    return f"{entry}\n{stats}"


def display_session_detail(session: Dict, is_current: bool = False) -> None:
    """
    Display detailed information about a session.
    
    Args:
        session (Dict): The session dictionary
        is_current (bool): Whether this is the current active session
    """
    # Get session details
    session_id = session.get("id", "Unknown ID")
    # Get name from name_info if available, otherwise fall back to name
    if "name_info" in session:
        name = session["name_info"].get("current", "Unnamed")
    else:
        name = session.get("name", "Unnamed")
    created_at = session.get("created_at", "")
    updated_at = session.get("updated_at", "")
    locked_by = session.get("locked_by", "")
    
    # Get stats
    file_count, message_count = get_session_stats(session)
    
    # Format timestamps
    created_str = format_session_timestamp(created_at) if created_at else "Unknown"
    updated_str = format_session_timestamp(updated_at) if updated_at else "Unknown"
    
    # Clear screen and show header
    print("\033[2J\033[H", end="")
    
    # Display session header
    print(f"\n\033[1;36mSession Details\033[0m")
    print("\033[1;36m" + "=" * 14 + "\033[0m")
    
    # Current session indicator
    current_indicator = " \033[1;32m(current)\033[0m" if is_current else ""
    locked_indicator = " \033[1;31m[IN USE]\033[0m" if locked_by else ""
    
    # Add the working directory information
    client_states = session.get("client_states", {})
    cli_state = client_states.get("cli", {})
    session_directory = cli_state.get("current_directory", "Unknown")
    actual_directory = os.getcwd()
        
    # Always show the session directory
    print(f"\033[1mWorking Directory:\033[0m {session_directory}")
        
    # Only show the current directory and warning if they differ
    if session_directory != actual_directory:
        print(f"\033[1mCurrent Directory:\033[0m {actual_directory}")
        print(f"\033[1;33mNote:\033[0m The session directory differs from the current directory")

    # Display basic info
    print(f"\n\033[1mName:\033[0m {name}{current_indicator}{locked_indicator}")
    print(f"\033[1mID:\033[0m {session_id}")
    print(f"\033[1mCreated:\033[0m {created_str}")
    print(f"\033[1mLast Updated:\033[0m {updated_str}")
    
    # Display stats
    print(f"\n\033[1mStats:\033[0m")
    print(f"  Files: {file_count}")
    print(f"  Messages: {message_count}")
    
    # Get file list if available
    client_states = session.get("client_states", {})
    cli_state = client_states.get("cli", {})
    selected_files = cli_state.get("selected_files", [])
    
    if selected_files:
        print(f"\n\033[1mSelected Files:\033[0m")
        for i, file in enumerate(selected_files, 1):
            print(f"  {i}. {file}")
    
    # Get message history summary if available
    shared_state = session.get("shared_state", {})
    memories = shared_state.get("memories", {})
    
    if memories:
        print(f"\n\033[1mMessage History:\033[0m")
        total_messages = 0
        
        for memory_key, memory_data in memories.items():
            messages = memory_data.get("messages", [])
            message_count = len(messages)
            total_messages += message_count
            print(f"  {memory_key.capitalize()} memory: {message_count} messages")
        
        print(f"  Total messages: {total_messages}")
        
        # Show the last few message snippets
        max_messages = min(3, len(messages))
        if max_messages > 0:
            print(f"  Last {max_messages} messages:")
            for i, msg in enumerate(messages[-max_messages:]):
                content = msg.get("content", "")
                role = msg.get("role", "unknown")
                
                # Truncate content if too long
                if content and len(content) > 50:
                    content = content[:47] + "..."
                
                print(f"    - {role}: {content}")
    
    print("\nPress Enter to return to session list...")




def display_interactive_session_list(
    sessions: list,
    current_session_id: Optional[str] = None,
    header_text: str = "Available Sessions",
    page_size: int = 5,
    allow_detailed_view: bool = True,
    show_create_option: bool = True,
    actions: List[str] = ["load"],
    callback_handlers: Dict[str, Callable] = None
) -> Optional[Dict]:
    """
    Display an interactive, paginated list of sessions with options for detailed view.
    
    Args:
        sessions (list): List of session dictionaries
        current_session_id (str, optional): ID of the current session
        header_text (str): Text to display in the header
        page_size (int): Number of sessions to display per page
        allow_detailed_view (bool): Whether to allow detailed view of sessions
        show_create_option (bool): Whether to show the create new session option
        actions (List[str]): List of actions that can be performed on sessions
                             (e.g., "load", "delete", "rename")
        callback_handlers (Dict[str, Callable]): Callback functions for actions
        
    Returns:
        Optional[Dict]: The selected session or None if cancelled
    """
    if not sessions:
        print("\033[1;33mNo saved sessions found.\033[0m")
        return None
    
    # Sort sessions by updated_at (newest first)
    sorted_sessions = sorted(sessions, key=lambda s: s.get("updated_at", ""), reverse=True)
    
    # Calculate pagination
    total_pages = (len(sorted_sessions) + page_size - 1) // page_size
    current_page = 1
    
    # Get current session name if available
    current_session_name = None
    if current_session_id:
        for session in sorted_sessions:
            if session.get("id") == current_session_id:
                # Get name from name_info if available, otherwise fall back to name or "Unnamed"
                if "name_info" in session:
                    current_session_name = session["name_info"].get("current", "Unnamed")
                else:
                    current_session_name = session.get("name", "Unnamed")
                break
    
    while True:
        # Display header with pagination info
        display_session_selector_header(
            header_text=header_text,
            current_session_name=current_session_name,
            page=current_page,
            total_pages=total_pages
        )
        
        # Calculate page bounds
        start_idx = (current_page - 1) * page_size
        end_idx = min(start_idx + page_size, len(sorted_sessions))
        
        # Display sessions for current page
        for i, session in enumerate(sorted_sessions[start_idx:end_idx], start_idx + 1):
            # Get session details
            session_id = session.get("id")
            # Get name from name_info if available, otherwise fall back to name or "Unnamed"
            if "name_info" in session:
                name = session["name_info"].get("current", "Unnamed")
            else:
                name = session.get("name", "Unnamed")
            updated_at = session.get("updated_at", "")
            
            # For locked status, check directly from session data
            # A session is considered locked if it has a locked_by value
            # and the locked_at timestamp is less than 30 minutes old
            locked_by = session.get("locked_by")
            locked_at = session.get("locked_at")
            
            is_locked = False
            if locked_by and str(locked_by) != str(os.getpid()):  # Only show as locked if locked by another process
                if locked_at:
                    try:
                        locked_time = datetime.fromisoformat(locked_at)
                        # Check if lock has expired (30 minutes)
                        is_locked = (datetime.now() - locked_time).total_seconds() <= 1800
                    except (ValueError, TypeError):
                        # If there's an error parsing the timestamp, assume it's locked
                        is_locked = True
                else:
                    # If there's a locked_by but no locked_at, assume it's locked
                    is_locked = True
            
            # Get stats
            file_count, message_count = get_session_stats(session)
            
            # Check if this is the current session
            is_current = (current_session_id and current_session_id == session_id)
            
            # Format and display the session entry
            entry = format_session_entry(
                idx=i,
                name=name,
                updated_at=updated_at,
                file_count=file_count,
                message_count=message_count,
                is_current=is_current,
                is_locked=is_locked
            )
            print(entry)
        
        # Determine the primary action for the current view
        primary_action = None
        is_load_view = header_text == "Load Session"
        is_delete_view = header_text == "Delete Session"
        is_rename_view = header_text == "Rename Session"
        
        if is_delete_view and "delete" in actions:
            primary_action = "delete"
        elif is_load_view and "load" in actions:
            primary_action = "load"
        elif is_rename_view and "rename" in actions:
            primary_action = "rename"
            
        # Display navigation options
        display_session_navigation_options(
            header_text=header_text,
            allow_detailed_view=allow_detailed_view,
            show_create_option=show_create_option,
            actions=actions,
            primary_action=primary_action
        )
        
        # Get user input
        selection = input("\n\033[1mEnter choice: \033[0m").strip().lower()
        
        # Handle navigation commands
        if selection == 'q':
            return None
        elif selection == 'n':
            if current_page < total_pages:
                current_page += 1
            continue
        elif selection == 'p':
            if current_page > 1:
                current_page -= 1
            continue
        elif selection == 'v' and allow_detailed_view:
            # Detailed view of a session
            detail_selection = input("Enter session number for detailed view: ").strip()
            if detail_selection.isdigit():
                idx = int(detail_selection)
                if 1 <= idx <= len(sorted_sessions):
                    session = sorted_sessions[idx - 1]
                    is_current = (current_session_id and current_session_id == session.get("id"))
                    display_session_detail(session, is_current)
                    input()  # Wait for user to press Enter
                else:
                    print("\033[1;31mInvalid session number.\033[0m")
                    time.sleep(1)
            else:
                print("\033[1;31mInvalid input. Please enter a number.\033[0m")
                time.sleep(1)
            continue
        elif selection == 'c' and show_create_option and callback_handlers and 'create' in callback_handlers:
            # Create a new session
            callback_handlers['create']()
            # Return a dummy session object to prevent creating another session
            return {"_created_via_callback": True}
        elif selection in [a[0] for a in actions]:
            # Handle action (load, delete, rename, etc.)
            # Find which action was selected
            selected_action = None
            for action in actions:
                if action.startswith(selection):
                    selected_action = action
                    break
            
            if selected_action and callback_handlers and selected_action in callback_handlers:
                action_selection = input(f"Enter session number to {selected_action}: ").strip()
                
                if action_selection.isdigit():
                    idx = int(action_selection)
                    if 1 <= idx <= len(sorted_sessions):
                        session = sorted_sessions[idx - 1]
                        session_id = session.get("id")
                        callback_handlers[selected_action](session_id)
                        return session
                    else:
                        print("\033[1;31mInvalid session number.\033[0m")
                        time.sleep(1)
                else:
                    print("\033[1;31mInvalid input. Please enter a number.\033[0m")
                    time.sleep(1)
            elif selected_action:
                print(f"\033[1;31mNo callback handler found for action '{selected_action}'.\033[0m")
                time.sleep(1)
            else:
                print(f"\033[1;31mAction '{selection}' not found in available actions.\033[0m")
                time.sleep(1)
            continue
        elif selection.isdigit():
            # Direct session selection
            idx = int(selection)
            if 1 <= idx <= len(sorted_sessions):
                session = sorted_sessions[idx - 1]
                session_id = session.get("id")
                
                # Handle based on the view type
                if is_delete_view and "delete" in actions and callback_handlers and "delete" in callback_handlers:
                    # For delete view, directly call the delete handler
                    callback_handlers["delete"](session_id)
                    return session
                elif is_rename_view and "rename" in actions and callback_handlers and "rename" in callback_handlers:
                    # For rename view, directly call the rename handler
                    callback_handlers["rename"](session_id)
                    return session
                # For load view or default view, call the load handler
                elif "load" in actions and callback_handlers and "load" in callback_handlers:
                    callback_handlers["load"](session_id)
                    return session
                
                return session
            else:
                print("\033[1;31mInvalid session number.\033[0m")
                time.sleep(1)
        else:
            print("\033[1;31mInvalid input. Please try again.\033[0m")
            time.sleep(1)


def format_iso_timestamp(iso_timestamp: str) -> str:
    """
    Format an ISO 8601 timestamp into a human-readable local time with GMT offset.
    
    Args:
        iso_timestamp (str): The timestamp in ISO 8601 format.
        
    Returns:
        str: A human-readable timestamp string with local time and GMT offset.
    """
    # Parse the timestamp from ISO format and explicitly mark as UTC
    utc_time = datetime.fromisoformat(iso_timestamp).replace(tzinfo=timezone.utc)
    
    # Convert to local time
    local_time = utc_time.astimezone()
    
    # Format the time with GMT offset
    tz_offset_hours = int(local_time.utcoffset().total_seconds() / 3600)
    tz_offset_str = f"GMT{'+' if tz_offset_hours >= 0 else ''}{tz_offset_hours}"
    
    # Format the time with a simple, clean format
    return f"{local_time.strftime('%Y-%m-%d %H:%M:%S')} ({tz_offset_str})"


def format_risk_assessment(command: str, assessment: dict) -> str:
    """
    Format a risk assessment for display.
    
    Args:
        command: The assessed command
        assessment: Risk assessment data
        
    Returns:
        Formatted string with risk information
    """
    risk_level = assessment['risk_level']
    risk_score = assessment['risk_score']
    risk_factors = assessment['risk_factors']
    
    # Use existing color function for consistency
    if risk_level == "high":
        level_color = "1;31"  # Bold Red
    elif risk_level == "medium":
        level_color = "1;33"  # Bold Yellow
    else:
        level_color = "1;32"  # Bold Green
    
    # Format the header with appropriate color
    header = color(f"Risk Assessment: {risk_level.upper()} ({risk_score}/10)", level_color)
    output = [
        header,
        f"Command: {command}"
    ]
    
    # Add risk factors if present
    if risk_factors:
        output.append("Risk factors:")
        for factor in risk_factors:
            output.append(f"- {factor}")
    
    return "\n".join(output)


def display_risk_warning(command: str, assessment: dict) -> None:
    """
    Display a warning for medium-risk commands.
    
    Args:
        command: The bash command
        assessment: Risk assessment data
    """
    print("\n" + format_risk_assessment(command, assessment))
    print(color("Proceeding with execution, but please review the command carefully.", "1;33"))


def request_command_authorization(command: str, assessment: dict) -> bool:
    """
    Request user authorization for a high-risk command.
    
    Args:
        command: The command requiring authorization
        assessment: Risk assessment data
        
    Returns:
        bool: True if authorized, False if denied
    """
    print("\n" + format_risk_assessment(command, assessment))
    
    # Use color for the prompt
    response = input(color("\nDo you authorize this command to run? (y/N): ", "1;31"))
    return response.lower() in ('y', 'yes')


def display_omni_preflight(file_path: str, size_bytes: int, context: dict, preferences: dict = None) -> bool:
    """
    Display an omni-parser preflight prompt when a file exceeds the default size limit.

    Args:
        file_path: Absolute path to the file being uploaded.
        size_bytes: File size in bytes.
        context: Dict with the following keys:
            - category (str): Detected content category (for example "doc", "image", "audio").
            - extension (str): File extension (for example ".pdf", ".png").
            - size_mb (float): File size in megabytes; if not provided, it is derived from ``size_bytes``.
            - threshold_mb (float): Soft size limit at which this preflight prompt should be shown.
            - hard_max_mb (float): Hard maximum size allowed by the backend.
            - hiResMode (bool): Whether high-resolution parsing is enabled.
            - structure: Structured parsing mode or schema information, if present.
            - dialogue: Dialogue or conversation parsing configuration, if present.
            - outputFormat (str): Desired output format (for example "markdown" or "json").
        preferences: Session preferences for omni uploads (optional). Expected keys:
            - allow_all_over_limit (bool): If True, auto-approves uploads larger than
              ``threshold_mb`` but not exceeding ``hard_max_mb``.

    Returns:
        bool: True to proceed with upload, False to cancel.
    """
    prefs = preferences or {}
    size_mb = context.get("size_mb") or round(size_bytes / (1024 * 1024), 2)
    threshold_mb = context.get("threshold_mb")
    hard_max_mb = context.get("hard_max_mb")
    category = (context.get("category") or "doc").upper()
    ext = context.get("extension") or ""
    hi_res = context.get("hiResMode")
    structure = context.get("structure")
    dialogue = context.get("dialogue")
    output_format = context.get("outputFormat")

    # Auto-approval from preferences (if enabled)
    auto_approve = bool(prefs.get("allow_all_over_limit", False)) and hard_max_mb is not None and (size_mb <= hard_max_mb)
    if auto_approve:
        print(color("│", "38;5;81"), color("Auto-approved omni upload by session preferences.", "38;5;246"))
        return True

    # Present preflight information
    line_part = color("│", "38;5;81")
    separator = color("┄" * 40, "38;5;240")
    print(f"{line_part} {separator}")
    print(f"{line_part} 📄 Omni-parser preflight: {os.path.basename(file_path)} {ext}")
    print(f"{line_part}   • Detected type: {category}")
    print(f"{line_part}   • File size: {size_mb} MB (limit: {threshold_mb} MB, hard max: {hard_max_mb} MB)")
    if hi_res:
        print(f"{line_part}   • hiResMode: True (higher cost)")
    if output_format:
        print(f"{line_part}   • outputFormat: {output_format}")
    if structure:
        print(f"{line_part}   • structure: {structure}")
    if dialogue is not None:
        print(f"{line_part}   • dialogue: {dialogue}")
    print(f"{line_part}")
    print(f"{line_part} Recommendation: Narrow pages (startPage/endPage) for documents, or trim media if possible.")
    print(f"{line_part} Proceed with upload anyway? (y/N): ", end="")

    response = input().strip().lower()
    proceed = response in ("y", "yes")

    if proceed:
        print(f"{line_part} {color('Proceeding with upload.', '32')}")
    else:
        print(f"{line_part} {color('Upload cancelled by user.', '1;33')}")
    return proceed


def display_bash_risk_assessment(command: str, risk_assessment: dict, security_prefs: dict = None) -> bool:
    """
    Display bash command risk assessment and ask for user confirmation.
    
    Args:
        command (str): The bash command to be executed
        risk_assessment (dict): Risk assessment information
        security_prefs (dict, optional): Bash security preferences from the session
        
    Returns:
        bool: True if user confirms execution, False otherwise
    """
    risk_level = risk_assessment.get("risk_level", "unknown").lower()
    reasons = risk_assessment.get("reasons", [])
    warnings = risk_assessment.get("warnings", [])
    recommendation = risk_assessment.get("recommendation", "")
    
    # Initialize auto-approval flag
    auto_approve = False
    auto_approve_reason = None
    
    # Check security preferences if provided
    if security_prefs:
        # Check if all security checks are disabled (except for critical)
        if security_prefs.get("disable_all_checks", False) and risk_level != "critical":
            auto_approve = True
            auto_approve_reason = "All security checks are disabled in session preferences"
        else:
            # Get the maximum auto-approve level
            max_level = security_prefs.get("max_auto_approve_level", "low").lower()
            
            # Apply hierarchical security model
            # If risk_level is lower or equal to max_level, auto-approve
            risk_levels = ["safe", "low", "medium", "high", "critical"]
            risk_level_idx = risk_levels.index(risk_level) if risk_level in risk_levels else 2  # Default to medium
            max_level_idx = risk_levels.index(max_level) if max_level in risk_levels else 1     # Default to low
            
            if risk_level_idx <= max_level_idx and risk_level != "critical":
                auto_approve = True
                auto_approve_reason = f"Session preferences auto-approve up to {max_level.upper()} risk"
    
    color_code = RISK_LEVEL_COLORS.get(risk_level, RISK_LEVEL_COLORS["unknown"])
    icon = RISK_LEVEL_ICONS.get(risk_level, RISK_LEVEL_ICONS["unknown"])
    box_color = "38;5;81"  # Same blue color as the bash tool call
    
    # Print a separator line inside the bash tool call
    line_part = color("│", box_color)
    separator = color("┄" * 40, "38;5;240")
    print(f"{line_part} {separator}")
    
    # Print risk assessment header inside the bash tool call
    risk_level_colored = color(risk_level.upper(), color_code)
    # Ensure consistent spacing by using a fixed-width space after the emoji
    print(f"{line_part} {icon} Risk Level: {risk_level_colored}")
    
    # Display combined reasons and warnings as a single bullet list
    if reasons or warnings:
        print(f"{line_part}")
        
        # Display reasons
        for reason in reasons:
            print(f"{line_part}   • {reason}")
        
        # Display warnings
        for warning in warnings:
            print(f"{line_part}   • {warning}")
    
    # Display recommendation with a bit of space
    if recommendation:
        # Only the "Recommendation:" label should be grey, the actual recommendation text should be normal
        print(f"{line_part} {color('Recommendation:', '2')} {recommendation}")
    
    # Print another separator
    print(f"{line_part} {separator}")
    
    # Handle different risk levels
    if risk_level == "safe":
        message = "This command is safe to execute."
        print(f"{line_part} {color(message, color_code)}")
        
        # Show auto-approval reason if present
        if auto_approve_reason:
            print(f"{line_part} {color('Auto-approved:', '38;5;246')} {color(auto_approve_reason, '38;5;246')}")
        
        # Show execution message
        print(f"{line_part} {color('Proceeding with execution.', '32')}")  # Green color
        return True
        
    elif risk_level == "low":
        message = "This command has LOW risk."
        print(f"{line_part} {color(message, color_code)}")
        
        # Show auto-approval reason if present
        if auto_approve_reason:
            print(f"{line_part} {color('Auto-approved:', '38;5;246')} {color(auto_approve_reason, '38;5;246')}")
        
        # Show execution message
        print(f"{line_part} {color('Proceeding with execution.', '32')}")  # Green color
        return True
        
    # For medium, high, or critical risk
    else:
        if risk_level == "critical":
            message = "This command is potentially VERY DANGEROUS."
            prompt = "Are you sure you want to execute it? (y/N): "
        elif risk_level == "high":
            message = "This command has HIGH risk."
            prompt = "Are you sure you want to execute it? (y/N): "
        else:  # medium
            message = "This command has MEDIUM risk."
            prompt = "Do you want to proceed? (y/N): "
        
        # Print the warning message inside the bash tool call box
        print(f"{line_part} {color(message, color_code)}")
        
        # If auto-approve is enabled, show that instead of prompting
        if auto_approve:
            print(f"{line_part} {color('Auto-approved:', '38;5;246')} {color(auto_approve_reason, '38;5;246')}")
            print(f"{line_part} {color('Proceeding with execution.', '32')}")  # Green color
            return True
        
        # Otherwise prompt for user confirmation
        print(f"{line_part} {prompt}", end="")
        
        # Get user input
        response = input().strip().lower()
        proceed = response == 'y'
        
        # Print the result inside the bash tool call box
        if not proceed:
            print(f"{line_part} {color('Command execution cancelled by user.', color_code)}")
        else:
            print(f"{line_part} {color('Proceeding with execution.', '32')}")  # Green color
        
        return proceed


def display_ask_user_question(question: str, suggestions: list, direct_actions: dict = None) -> str:
    """
    Display a question to the user with suggested answers and get their response.
    
    Args:
        question (str): The question to ask the user
        suggestions (list): A list of 2-4 suggested answers
        direct_actions (dict): Optional mapping of option indices to action names
        
    Returns:
        str: The user's selected answer or custom response
    """
    # Define colors
    title_color = "1;97"  # Bold white
    option_color = "38;5;220"  # Gold/yellow for options
    
    # Print the question with bold text for the title but normal text for the question
    print(f"🤖 {color('CODA agent has a question:', '1;97')} {question}")
    # Add a simple separator line below
    print(color("──────────────────────────────────────────────────────────────────────────────────", "38;5;75"))
    print()
    
    # Display suggested options
    print(color('Suggested answers:', '2'))  # Grey text
    
    # Make sure suggestions is a list of strings, not a single string
    if isinstance(suggestions, str):
        # Split by comma if it's a single string
        suggestions = [s.strip() for s in suggestions.split(',')]
    
    for i, suggestion in enumerate(suggestions):
        # Display each suggestion with a number
        print(f"  {color(f'{i+1}', option_color)}. {suggestion}")
    
    # Print instructions for custom response
    print()
    print(color('Enter a number to select an option, or type your own response:', '2'))
    
    # Print separator
    separator = color("┄" * 40, "38;5;240")
    print(f"{separator}")
    
    # Get user input with user emoji
    print(f"👤 Response: ", end="")
    response = input().strip()
    
    # Check if the response is a number corresponding to a suggestion
    try:
        selection_index = int(response) - 1
        if 0 <= selection_index < len(suggestions):
            return suggestions[selection_index]
    except ValueError:
        # Not a number, return the raw response
        pass
    
    return response


def display_detected_images() -> None:
    """
    Display visual feedback when images are detected in user input.
    
    Args:
        placeholder_info: List of dictionaries containing placeholder mappings
    """
    print_intermediate_response('🖼️  Images detected')


def display_asterisk_banner(messages: List[str], color: str = "1;32") -> None:
    """
    Display a banner surrounded by asterisks, with each message centered and colorized.

    Args:
        messages (List[str]): List of message lines to display inside the banner.
        color (str): ANSI color code (e.g., '1;32' for bright green). Defaults to 1;32 for bright green.
    """
    ESC = "\033["
    reset = "\033[0m"
    banner_width = 50
    print(f"{ESC}{color}m")
    print("*" * banner_width)
    for msg in messages:
        # Center the message and pad with spaces, surrounded by asterisks
        padded_msg = f"* {msg.center(banner_width - 4)} *"
        print(padded_msg)
    print("*" * banner_width + reset + "\n")


def print_agent_header(agent_name: str, status: str = None):
    """
    Print an agent processing header with enhanced styling.
    
    Args:
        agent_name (str): Name of the agent
        status (str, optional): Custom status message. Defaults to None.
    """
    BLUE = "\033[38;5;39m"       # Darker blue color for agent name
    LIGHT_BLUE = "\033[38;5;117m"  # Lighter blue color for status text
    RESET = "\033[0m"            # Reset color
    BOLD = "\033[1m"             # Bold text
    
    # Normalize agent name for comparison
    agent_name_lower = agent_name.lower()
    
    # Set the correct icon and status based on agent type
    if agent_name_lower == DIAGNOSE_AGENT:
        icon = "🔍"
        prefix = "Codefixer agent:"
        status_msg = "Diagnosing your code..."
    elif agent_name_lower == FIX_AGENT:
        icon = "🔍"
        prefix = "Codefixer agent:"
        status_msg = "Fixing your code..."
    elif agent_name_lower == EXPLAIN_AGENT:
        icon = "🔍"
        prefix = "Codefixer agent:"
        status_msg = "Explaining ticket..."
    else:
        icon = "✨"
        prefix = "Agent:"
        status_msg = status or "Processing..."
    
    # Override status if provided
    if status:
        status_msg = status
    
    # Format the agent name properly (only capitalize for the special cases)
    display_name = agent_name
    if agent_name_lower in CODEFIXER_AGENTS:
        display_name = agent_name.capitalize()
    
    # Calculate proper padding for consistent box width
    box_width = 42
    
    # Print the box with consistent styling
    print(f"{BLUE}╭{'─' * (box_width - 2)}╮{RESET}")
    
    # Format the title line with proper spacing and consistent styling
    title = f"{prefix} {display_name}"
    # Manual calculation: box_width = left_border + space + icon + space + title + padding + right_border
    # 42 = 1 + 1 + 2 + 1 + len(title) + padding + 1 (emoji takes 2 visual spaces)
    padding = max(0, box_width - 1 - 1 - 2 - 1 - len(title) - 1)  # left_border + space + icon(2) + space + title + right_border
    print(f"{BLUE}│ {icon} {BOLD}{title}{RESET}{' ' * padding}{BLUE}│{RESET}")
    
    # Print status with proper spacing and lighter color
    # Manual calculation: box_width = left_border + space + content + padding + right_border
    # 42 = 1 + 1 + len(status_msg) + padding + 1
    status_padding = max(0, box_width - 1 - 1 - len(status_msg) - 1)  # left_border + space + content + right_border
    print(f"{BLUE}│{LIGHT_BLUE} {status_msg}{' ' * status_padding}{RESET}{BLUE}│{RESET}")
    
    # Print footer
    print(f"{BLUE}╰{'─' * (box_width - 2)}╯{RESET}")
    print()
