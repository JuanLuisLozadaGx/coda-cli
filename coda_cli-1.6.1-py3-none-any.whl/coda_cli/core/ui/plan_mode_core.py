from typing import Dict, Any
from loguru import logger
from coda_core.core.modes.step_by_step_utilities.planning_converters import load_plan
from coda_core.config.settings import SETTINGS, EnvConfig

# CLI-style UI helper functions (copied from coda_cli for independence)
def _color(text: str, code: str) -> str:
    """Return ANSI-colored text with the specified color code."""
    return f"\033[{code}m{text}\033[0m"

def _truncate_middle(text: str, max_length: int) -> str:
    """Truncate text in the middle if it exceeds max_length."""
    if len(text) <= max_length:
        return text
    placeholder_plain = "... [output truncated] ..."
    placeholder_visible_len = len(placeholder_plain) + 2
    if max_length <= placeholder_visible_len:
        return f"\n{_color(placeholder_plain, '38;5;246')}\n"
    remaining = max_length - placeholder_visible_len
    head_len = remaining // 2
    tail_len = remaining - head_len
    placeholder_coloured = _color(placeholder_plain, "38;5;246")
    return f"{text[:head_len]}\n{placeholder_coloured}\n{text[-tail_len:]}"

def _print_intermediate_response(response_text: str) -> None:
    """Print an intermediate response with subtle styling."""
    color_code = "38;5;246"
    print()
    print(_color(response_text, color_code))

# Tool emojis map (copied from CLI)
TOOL_EMOJIS = {
    "bash": "🛠️",
    "view": "🛠️",
    "edit": "🛠️",
    "replace": "🛠️",
    "think": "💭",
    "ask_user": "❓",
    "web_search": "🔍",
    "examine_images": "🖼️",
    "default": "🔧"
}

class PlanningModeUIHandler:
    """
    Custom UI handler for planning mode tools.
    Provides minimalistic, mode-specific output formatting without CLI dependency.
    """
    
    def __init__(self):
        """Initialize the UI handler."""
        self.plan_file_path = None
        self.planning_tools = ["create_plan_tool", 
                               "approve_plan_tool", 
                               "update_plan_tool", 
                               "mark_step_tool", 
                               "mark_plan_as_pending_tool", 
                               "load_plan_tool"]
        # Storage for tool args (needed for result formatting)
        self.current_tool_args = {}
        
    def set_plan_file_path(self, path: str) -> None:
        """
        Store the plan file path for later use in approve_plan result output.
        
        Args:
            path: The path to the plan markdown file
        """
        self.plan_file_path = path
    
    def print_tool_call(self, tool_name: str, tool_args: Dict[str, Any]) -> None:
        """
        Print a minimalistic tool call for planning mode tools.
        
        Args:
            tool_name: The name of the tool being called
            tool_args: The arguments for the tool
        """
        # Store args for result callback
        self.current_tool_args = tool_args.copy()
        
        # Debug log to help diagnose tool recognition issues
        logger.debug(f"print_tool_call received tool: {tool_name!r}")
        
        # Check for planning-specific tools (with flexible matching)
        # Use more flexible patterns that match both with and without "_tool" suffix
        create_plan_pattern = "create_plan" in tool_name.lower()
        approve_plan_pattern = "approve_plan" in tool_name.lower()
        update_plan_pattern = any(x in tool_name.lower() for x in ["update_plan", "edit_plan"])
        mark_step_pattern = "mark_step" in tool_name.lower()
        mark_pending_pattern = "mark_plan_as_pending" in tool_name.lower() or "mark_pending" in tool_name.lower()
        load_plan_pattern = "load_plan" in tool_name.lower()
        
        # Debug logging to help diagnose tool recognition issues
        logger.info(f"Tool pattern matches: create_plan={create_plan_pattern}, load_plan={load_plan_pattern}, in planning_tools={tool_name in self.planning_tools}")
        
        # Check if this is a planning tool (including load_plan_tool)
        is_planning_tool = tool_name in self.planning_tools or create_plan_pattern or approve_plan_pattern or update_plan_pattern or mark_step_pattern or mark_pending_pattern or load_plan_pattern
                
        if is_planning_tool and create_plan_pattern:
            # Special case - Create plan uses the standard format with Tool: prefix

            # Use the enhanced agent header style for planning tools
            BLUE = "\033[38;5;39m"       # Darker blue color for tool name
            LIGHT_BLUE = "\033[38;5;117m"  # Lighter blue color for status text
            RESET = "\033[0m"            # Reset color
            BOLD = "\033[1m"             # Bold text
            
            # Set icon and prefix for planning tools
            icon = "📝"
            #display_name = stripped_name
            status_msg = "Creating a new plan"
            
            # Calculate proper padding for consistent box width
            box_width = 30  # Wider box for planning tools to accommodate plan_id
            
            # Print the box with consistent styling
            print(f"{BLUE}╭{'─' * (box_width - 2)}╮{RESET}")
            
            # Format the title line with proper spacing and consistent styling
            title = f"{status_msg}"
            # Manual calculation: box_width = left_border + space + icon + space + title + padding + right_border
            # 60 = 1 + 1 + 2 + 1 + len(title) + padding + 1 (emoji takes 2 visual spaces)
            padding = max(0, box_width - 1 - 1 - 2 - 1 - len(title) - 1)  # left_border + space + icon(2) + space + title + right_border
            print(f"{BLUE}│ {icon} {BOLD}{title}{RESET}{' ' * padding}{BLUE}│{RESET}")
            
            # Print footer
            print(f"{BLUE}╰{'─' * (box_width - 2)}╯{RESET}")
            print()
        elif is_planning_tool:
            # Other planning tools (not create_plan) use the new format
            # Strip _tool suffix if present for cleaner display
            stripped_name = tool_name.replace("_tool", "")
            
            # Use the enhanced agent header style for planning tools
            BLUE = "\033[38;5;39m"       # Darker blue color for tool name
            LIGHT_BLUE = "\033[38;5;117m"  # Lighter blue color for status text
            RESET = "\033[0m"            # Reset color
            BOLD = "\033[1m"             # Bold text
            
            # Set icon for planning tools
            icon = "🔧"
            display_name = stripped_name
            
            # Get the plan_id parameter if available
            plan_id = None
            if "plan_id" in tool_args:
                plan_id = str(tool_args['plan_id'])
            
            # Safe string version for calculations and display
            plan_id_str = plan_id or ""
            
            # Create title with plan_id in parentheses if available
            if mark_step_pattern and "step_number" in tool_args:
                step_number = tool_args.get("step_number", "?")
                # Check if step_title is available in tool args
                if "step_title" in tool_args and tool_args["step_title"]:
                    step_title = tool_args["step_title"]
                    title = f"mark_step (step {step_number})"  # Simplified title format
                else:
                    title = f"{display_name} (step {step_number})"
            elif plan_id:
                title = f"{display_name}"
            else:
                title = display_name
            
            # Set dynamic box width based on title and plan_id length
            if mark_step_pattern and "step_number" in tool_args:
                # Make box width depend on title length for mark_step with step number
                # Add more buffer to ensure the title fits properly
                step_display_width = len(title) + 25  # Increased buffer for the step display
                box_width = max(60, step_display_width)
            elif plan_id:
                # Make box width depend on plan_id length plus buffer for other elements
                # Minimum 60, but expand if needed based on plan_id length
                box_width = max(40, len(plan_id_str) + 10)  # Adding buffer for formatting
            else:
                box_width = 40  # Default for planning tools
            
            # Print the box with consistent styling
            print(f"{BLUE}╭{'─' * (box_width - 2)}╮{RESET}")
            
            # Format the title line with proper spacing and consistent styling
            # Manual calculation for padding
            padding = max(0, box_width - 1 - 1 - 2 - 1 - len(title) - 1)  # left_border + space + icon(2) + space + title + right_border
            print(f"{BLUE}│ {icon} {BOLD}{title}{RESET}{' ' * padding}{BLUE}│{RESET}")
            
            # Set appropriate status message based on tool type
            if "approve_plan" in tool_name.lower():
                status_msg = "Approving plan..."
            elif update_plan_pattern:
                status_msg = "Updating plan..."
            elif mark_step_pattern:
                step_number = tool_args.get("step_number", "?")
                status_msg = f"Marking step {step_number}..."
            elif mark_pending_pattern:
                status_msg = "Marking plan as pending..."
            elif load_plan_pattern:
                logger.info(f"load_plan tool called with args: {tool_args}")
                plan_id = tool_args.get("plan_id", "")
                status_msg = f"Loading plan {plan_id}..."
            else:
                status_msg = "Processing..."
            
            # Calculate padding for status message
            # For mark_step, display the step title instead of plan_id if possible
            if mark_step_pattern and "step_number" in tool_args:                
                # Get the plan_id and step_number
                step_number = tool_args.get("step_number", 1)
                current_plan_id = tool_args.get("plan_id", "")
                
                try:
                    # Try to load the plan
                    plan = load_plan(
                        current_plan_id, 
                        SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR),
                        SETTINGS.get_env_var(EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE)
                    )
                    
                    # Extract the step title if plan was loaded
                    step_title = None
                    if plan:
                        for step in plan.steps:
                            if step.number == step_number:
                                step_title = step.title
                                break
                    
                    if step_title:
                        # Display the step title instead of plan_id
                        display_text = step_title
                        
                        # Check if display_text is too long for the box width
                        if len(display_text) > box_width - 6:  # 6 = borders + minimum padding
                            # Truncate with ellipsis if too long
                            display_text = display_text[:box_width - 9] + "..."
                            
                        status_padding = max(0, box_width - 1 - 1 - len(display_text) - 1)
                        print(f"{BLUE}│{LIGHT_BLUE} {display_text}{' ' * status_padding}{RESET}{BLUE}│{RESET}")
                    else:
                        # Fallback to displaying the status message
                        status_padding = max(0, box_width - 1 - 1 - len(status_msg) - 1)
                        print(f"{BLUE}│{LIGHT_BLUE} {status_msg}{' ' * status_padding}{RESET}{BLUE}│{RESET}")
                except Exception as e:
                    # On error, display status_msg or plan_id_str
                    logger.debug(f"Error loading plan for UI display: {e}")
                    display_text = plan_id_str if plan_id_str else status_msg
                    status_padding = max(0, box_width - 1 - 1 - len(display_text) - 1)
                    print(f"{BLUE}│{LIGHT_BLUE} {display_text}{' ' * status_padding}{RESET}{BLUE}│{RESET}")
            else:
                # For other tools, display plan_id_str if available, otherwise status_msg
                display_text = plan_id_str if plan_id_str else status_msg
                status_padding = max(0, box_width - 1 - 1 - len(display_text) - 1)
                print(f"{BLUE}│{LIGHT_BLUE} {display_text}{' ' * status_padding}{RESET}{BLUE}│{RESET}")
            
            # Print footer
            print(f"{BLUE}╰{'─' * (box_width - 2)}╯{RESET}")
            print()
        else:
            # For non-planning tools, use CLI-style formatting
            self._print_cli_style_tool_call(tool_name, tool_args)
    
    def print_tool_result(self, tool_name: str, success: bool, result: Any) -> None:
        """
        Print a minimalistic tool result for planning mode tools.
        
        Args:
            tool_name: The name of the tool that was called
            success: Whether the tool call was successful
            result: The result returned by the tool
        """
        # Debug log to help identify problematic result formats
        logger.debug(f"print_tool_result received tool: {tool_name!r}, success: {success}, result type: {type(result)}")
        if isinstance(result, dict):
            logger.debug(f"Result keys: {list(result.keys())}")
        
        # Check for planning-specific tools (with flexible matching)
        create_plan_pattern = "create_plan" in tool_name.lower()
        approve_plan_pattern = "approve_plan" in tool_name.lower()
        update_plan_pattern = any(x in tool_name.lower() for x in ["update_plan", "edit_plan"])
        mark_step_pattern = "mark_step" in tool_name.lower()
        mark_pending_pattern = "mark_plan_as_pending" in tool_name.lower()
        load_plan_pattern = "load_plan" in tool_name.lower()
        
        # Debug logging to help diagnose tool recognition issues in print_tool_result
        logger.info(f"Tool pattern matches in print_tool_result: create_plan={create_plan_pattern}, load_plan={load_plan_pattern}, in planning_tools={tool_name in self.planning_tools}")
        
        # Check if this is a planning tool (including load_plan_tool)
        is_planning_tool = tool_name in self.planning_tools or create_plan_pattern or approve_plan_pattern or update_plan_pattern or mark_step_pattern or mark_pending_pattern or load_plan_pattern
        
        # Force load_plan_tool to be recognized as a planning tool
        if "load_plan" in tool_name.lower():
            is_planning_tool = True
            logger.info(f"Forcing load_plan_tool to be recognized as a planning tool")
        
        if is_planning_tool:
            # Display customized result based on tool
            if not success:
                error_msg = "Unknown error"
                if isinstance(result, dict) and "message" in result:
                    error_msg = result["message"]
                elif isinstance(result, str):
                    error_msg = result
                print(f"❌ Error with {tool_name}: {error_msg}")
                return
                
            # Strip _tool suffix if present for cleaner display
            stripped_name = tool_name.replace("_tool", "")
            
            # For all planning tools, show a simple success message with additional info if available
            # This ensures minimal output regardless of result format
            
            # Debug log to understand approve_plan result structure
            if "approve_plan" in tool_name.lower():
                logger.debug(f"Approve plan result structure: {result}")
                if isinstance(result, dict):
                    logger.debug(f"Approve plan result keys: {list(result.keys())}")
                logger.debug(f"Stored plan_file_path in UI handler: {self.plan_file_path}")
            
            # Check for file_path in result - different tools may use different key names
            plan_path = None
            
            # First try using the stored path from the mode transition callback
            if "approve_plan" in tool_name.lower() and self.plan_file_path:
                plan_path = self.plan_file_path
                logger.debug(f"Using stored plan_file_path: {plan_path}")
            
            # If no stored path, try to extract it from the result
            if not plan_path and isinstance(result, dict):
                # Try different possible key names for the markdown file path
                for key in ["plan_path", "file_path", "markdown_path", "path", "plan_file_path"]:
                    if key in result:
                        plan_path = result[key]
                        logger.debug(f"Found plan path in result[{key}]: {plan_path}")
                        break
                
                # Also check for metadata section that might contain the path
                if not plan_path and "metadata" in result and isinstance(result["metadata"], dict):
                    metadata = result["metadata"]
                    for key in ["plan_path", "file_path", "markdown_path", "path", "plan_file_path"]:
                        if key in metadata:
                            plan_path = metadata[key]
                            logger.debug(f"Found plan path in metadata[{key}]: {plan_path}")
                            break
                
                # Also check for nested file path in "data" or "result" dictionaries
                if not plan_path and "data" in result and isinstance(result["data"], dict):
                    for key in ["plan_path", "file_path", "markdown_path", "path", "plan_file_path"]:
                        if key in result["data"]:
                            plan_path = result["data"][key]
                            logger.debug(f"Found plan path in data[{key}]: {plan_path}")
                            break
                            
                # Also check for nested file path in "result" dictionary
                if not plan_path and "result" in result and isinstance(result["result"], dict):
                    for key in ["plan_path", "file_path", "markdown_path", "path", "plan_file_path"]:
                        if key in result["result"]:
                            plan_path = result["result"][key]
                            logger.debug(f"Found plan path in result[result][{key}]: {plan_path}")
                            break
            
            # Check if we found a plan path and this is an approve_plan tool
            if "approve_plan" in tool_name.lower():
                print(f"✅ {stripped_name} completed successfully")
                if plan_path:
                    # Use bright green color for better visibility
                    print()
                    print(f"📝 Plan available at: \033[1;32m{plan_path}\033[0m")
                else:
                    logger.warning(f"No plan file path found for approved plan in result or stored path")
            else:
                print(f"✅ {stripped_name} completed successfully")
            
        else:
            # For non-planning tools (bash, view, edit, replace), use CLI-style result formatting
            self._print_cli_style_tool_result(tool_name, success, result)
    
    def _print_cli_style_tool_call(self, tool_name: str, tool_args: Dict[str, Any]) -> None:
        """Print tool call using CLI-style formatting for bash, view, edit, replace."""
        normalized_title = tool_name.strip().lower()
        
        # Special handling for think and ask_user
        if normalized_title == "think":
            print("💭 Thought")
            for k, v in tool_args.items():
                if k.lower() == "metadata":
                    continue
                _print_intermediate_response(str(v))
            return
        elif normalized_title == "ask_user":
            return
        tool_emojis = {
            "bash": "💻",
            "view": "👁️",
            "edit": "✏️",
            "replace": "📄",
            "think": "💭",
            "ask_user": "❓",
            "web_search": "🔍",
            "examine_images": "🖼️"
        }
        
        icon = TOOL_EMOJIS.get(tool_name.strip().lower(), TOOL_EMOJIS["default"])
        
        # Use unicode box-drawing characters directly without escaping
        box_color = "38;5;81"
        tool_name_color = "0"  # White/default color for tool name
        header_box = _color(f"╭── {icon} ", box_color)
        header_tool = _color(tool_name, tool_name_color)
        header_len = len(f"╭── {tool_name} ") + 2  # +2 for emoji width
        trailing = "─" * max(0, 20 - header_len)
        print(f"{header_box}{header_tool} {_color(trailing, box_color)}")
        
        for k, v in tool_args.items():
            # Skip printing old_string, new_string, and metadata fields
            if k.lower() in ["old_string", "new_string", "metadata"]:
                continue
            # Skip empty values
            if v == "":
                continue
            raw_val = str(v)
            val_str = _truncate_middle(raw_val, 200)
            
            line_part = _color("│", box_color)
            faint_label = _color(k.ljust(12), "2")
            
            if '\n' in val_str:
                lines = val_str.split('\n')
                print(f"{line_part} {faint_label} : {lines[0]}")
                for line in lines[1:]:
                    print(f"{line_part} {line}")
            else:
                print(f"{line_part} {faint_label} : {val_str}")
    
    def _print_cli_style_tool_result(self, tool_name: str, success: bool, result: Any) -> None:
        """Print tool result using CLI-style formatting for bash, view, edit, replace."""
        # Special handling for ask_user and think - don't print result
        normalized_title = tool_name.strip().lower()
        if normalized_title in ["ask_user", "think"]:
            return
        
        # Filter out result-specific keys and keys already shown in tool block
        result_dict = result if isinstance(result, dict) else {"result": result}
        
        filtered_keys = {"status", "command", "file", "metadata"}
        if self.current_tool_args:
            # Add keys that were displayed in tool block (excluding old_string, new_string, empty values)
            filtered_keys.update(k.lower() for k, v in self.current_tool_args.items() 
                                if k.lower() not in ["old_string", "new_string"] and v != "")
        
        # Check if there are any parameters to display after filtering
        visible_params = {k: v for k, v in result_dict.items()
                         if k.lower() not in filtered_keys and v != ""}
        
        label = "❌" if not success else "✅"
        box_color="38;5;81"
        
        if not visible_params:
            # Simple result line with just a status indicator
            result_part = _color(f"╰── {label} ", box_color)
            trailing = "─" * 18
            print(f"{result_part}{_color(trailing, box_color)}")
            print()  # Add blank line after tool result to separate from next tool call
            self.current_tool_args = {}  # Clear tool args
            return
        
        # Regular output with parameters
        mid_part = _color(f"├── {label} ", box_color)
        trailing = "─" * 18
        print(f"{mid_part}{_color(trailing, box_color)}")
        
        # Now param lines
        for k, v in result_dict.items():
            # Skip keys already shown in tool block and result-specific keys
            if k.lower() in filtered_keys:
                continue
            # Skip empty values
            if v == "":
                continue
            
            raw_val = str(v)
            val_str = _truncate_middle(raw_val, 200)
            line_part = _color("│", box_color)
            faint_label = _color(k.ljust(12), "2")
            
            # For multiline content, ensure boxes are properly continued for all lines
            if '\n' in val_str:
                lines = val_str.split('\n')
                # Print first line
                print(f"{line_part} {faint_label} : {lines[0]}")
                # Print continuation lines
                for line in lines[1:]:
                    print(f"{line_part} {line}")
            else:
                print(f"{line_part} {faint_label} : {val_str}")
                
        # Footer
        footer = _color(f"╰{'─' * 30}", box_color)
        print(footer)
        print()  # Add blank line after tool result to separate from next tool call
        
        # Clear tool args
        self.current_tool_args = {}