# UI Module

The UI module provides a collection of functions for displaying information to the user in a formatted and visually appealing manner, enhancing the CLI experience with rich formatting, colors, and interactive elements.

## Overview

The UI module handles all aspects of user interface presentation:
- Formatting text with ANSI colors and styles
- Creating boxed and structured displays for content
- Rendering markdown with syntax highlighting
- Managing interactive selectors and prompts
- Displaying animated elements

## Architecture

```mermaid
flowchart TD
    subgraph "UI Module"
        CoreUI[Core UI Functions]
        Animation[Animation Functions]
        
        CoreUI --> Formatting[Text Formatting]
        CoreUI --> Boxes[Boxed Content]
        CoreUI --> ToolDisplay[Tool Display]
        CoreUI --> MarkdownRender[Markdown Rendering]
        CoreUI --> ErrorDisplay[Error Handling]
        CoreUI --> Interactive[Interactive Elements]
        CoreUI --> Banners[Banners and Messages]
    end
    
    Animation --> |Controls| Spinner[Loading Spinners]
    
    CLI[CLI Instance] --> CoreUI
    AgentHandler[Agent Handler] --> CoreUI
    AgentHandler --> Animation
    
    User(User) <--> Interactive
    Formatting --> User
    Boxes --> User
    ToolDisplay --> User
    MarkdownRender --> User
    ErrorDisplay --> User
    Banners --> User
    Spinner --> User
```

## Key Components

### Core UI Functions

The `core.py` file contains most UI functionality:

- **Basic Formatting**: Functions for applying ANSI color codes to text, printing styled text, and intelligently truncating long text

- **Boxed Content**: Functions for creating visually distinct boxed displays with headers, content lines, and footers

- **Tool Display**: Functions for displaying information about tool calls, tool results, and formatted diff output

- **Response Formatting**: Functions for formatting and displaying markdown responses, handling code blocks with syntax highlighting, and showing in-progress responses

- **Banners and Messages**: Functions for displaying the application banner, session information, quick start help, and exit messages

- **Interactive UI**: Functions for creating interactive session selection interfaces, model selection interfaces, and user prompts with suggestions

- **Error Handling**: Functions for formatting and displaying error messages and command risk assessments

### Animation Functions

The `animation.py` file provides loading animation capabilities:

- **Loading Animations**: Functions for creating and managing animated spinners to provide visual feedback during long-running operations

## UI Design Principles

The UI module follows several design principles:

1. **Consistent Styling**: Maintaining a consistent visual language throughout the application
2. **Minimal Distraction**: Using subtle colors and formatting that enhance readability without overwhelming
3. **Clear Hierarchy**: Visually distinguishing different types of information
4. **Visual Feedback**: Providing immediate visual feedback for user actions and background processes
5. **Error Clarity**: Making error messages clear and actionable

The UI module serves as the visual layer for Coda-CLI, ensuring that information is presented in a way that is both functional and visually appealing. It transforms raw data and responses into a rich interactive experience appropriate for a command-line interface.