import re
from loguru import logger

from coda_core.core.tools.schemas import ToolManagerConfig
from coda_core.core.filesystem_ops.file_editor import FileEditor
from coda_core.core.tools.constants import TOOL_TYPES, TOOL_TYPE_BASIC, TOOL_TYPE_EXPERIMENTAL
from coda_core.core.mcp.service import MCPService

from coda_cli.config.constants import TOOL_TYPE_EMOJIS
from coda_cli.core.utils.utils import get_yes_no_input


def reset_tools_to_system_defaults(cli) -> None:
    """
    Reset global default configuration to system defaults.
    
    This resets the global default configuration to the system defaults
    defined in SYSTEM_DEFAULT_TOOL_CONFIGS, effectively removing any user customizations.
    It also updates the current session's configuration and the agent's tools.
    """
    # Clear screen
    print("\033[2J\033[H", end="")  # Clear screen
    print("\n\033[1;36mReset Tools Configuration\033[0m")
    print("\033[1;36m========================\033[0m")
    
    # Get tool manager from shared state
    tool_manager = cli.shared_state.tool_manager
    
    # Create a new configuration based on system defaults for comparison only
    system_defaults = ToolManagerConfig.create_default().model_dump()
    
    # Check if there are any differences between current and system defaults
    if not cli.shared_state.tool_manager.has_config_differences(system_defaults):
        print("\n\033[1;33mTools configuration is already at system defaults.\033[0m")
        input("\nPress Enter to continue...")
        return
    
    # Check for ongoing conversation only if there are differences
    if not check_ongoing_conversation(cli):
        return
        
    # Display warning
    print("\n\033[1;33m⚠️ WARNING:\033[0m \033[33mThis will reset the global default tool configuration")
    print("\033[33mto its defaults, removing all customizations you may have done.\033[0m")
    print("\033[33mThis action cannot be undone.\033[0m")
    
    # Confirm with user
    confirm = get_yes_no_input("\nAre you sure you want to proceed?", default="n")
    
    if not confirm:
        print("\n\033[1;33mOperation cancelled.\033[0m")
        input("\nPress Enter to continue...")
        return
        
    # Reset global default
    if not tool_manager.reset_global_default_config():
        print("\n\033[1;31mFailed to reset global default configuration. Please check logs for details.\033[0m")
        input("\nPress Enter to continue...")
        return
        
    print("\n\033[1;32mSuccessfully reset global default configuration to system defaults.\033[0m")
    
    # Load the global default configuration and apply it to the current session
    global_default = tool_manager.load_global_default_config()
    if global_default:
        tool_manager.config = global_default
    else:
        # Fallback to the system defaults if loading global default fails
        tool_manager.config = system_defaults
    
    tool_manager._save_config()
    
    # Update the agent with the new tools configuration
    success = update_agent_tools(cli)
    if not success:
        print("\033[1;31mFailed to update agent tools. Please check logs for details.\033[0m")
    
    # Wait for user to press Enter
    input("\nPress Enter to continue...")


def check_ongoing_conversation(cli) -> bool:
    """
    Check if there's an ongoing conversation and warn the user about changing tools.
    
    Returns:
        bool: True if the user wants to proceed, False otherwise
    """
    # Check if single_agent exists and has memory
    if not hasattr(cli.shared_state, 'main_agent') or not hasattr(cli.shared_state.main_agent, 'memory'):
        return True
    
    # Get the memory
    memory = cli.shared_state.main_agent.memory
    
    # Get message counts by role
    counts = memory.count_by_role()
    
    # Check if there are any user or assistant messages
    has_conversation = counts.get('user', 0) > 0 or counts.get('assistant', 0) > 0
    
    # If there's an ongoing conversation, warn the user
    if has_conversation:
        print("\n\033[1;33m⚠️ WARNING:\033[0m \033[33mAn active conversation is in progress.")
        print("\033[33mModifying tools during an ongoing conversation may lead to unexpected behavior,\033[0m")
        print("\033[33mas the agent might attempt to use tools that are no longer available.")
        print("\nTo ensure smooth operation, consider clearing the conversation first using the /clear command.\033[0m")
        
        # Ask if the user wants to proceed
        choice = input("\nDo you still want to proceed? (y/n): ").strip().lower()
        return choice == 'y'
    
    return True


def list_tools(cli) -> None:
    """
    List all available tools with their status and category.
    """
    # Clear screen
    print("\033[2J\033[H", end="")  # Clear screen
    print("\n\033[1;36mAvailable Tools\033[0m")
    print("\033[1;36m===============\033[0m")
    
    # Get tool manager from shared state
    tool_manager = cli.shared_state.tool_manager
    
    # Get all tools from the configuration
    config = tool_manager.get_config()
    
    # Track if we have any tools to display
    have_tools = False
    
    # Display tools by category
    for tool_type in TOOL_TYPES:
        # Skip experimental tools
        if tool_type == TOOL_TYPE_EXPERIMENTAL:
            continue
            
        tools_in_category = config["tools"].get(tool_type, {})
        
        # Get emoji for this tool type
        emoji = TOOL_TYPE_EMOJIS.get(tool_type, "")
        
        # Print category header with emoji
        print(f"\n\033[1m{emoji} {tool_type.upper()} Tools:\033[0m")
        
        # Display message if no tools in category
        if not tools_in_category:
            print("  \033[90mNo tools available in this category\033[0m")
            continue

        have_tools = True

        # Sort tools by name
        sorted_tools = sorted(tools_in_category.items())
        
        # Helper function to format tool names properly
        def format_tool_name(name):
            # Replace underscores with spaces and capitalize each word
            if '_' in name:
                return ' '.join(word.capitalize() for word in name.split('_'))
            # Just capitalize the first letter for single-word names
            return name.capitalize()
        
        # Display each tool
        for i, (tool_name, tool_config) in enumerate(sorted_tools):
            # Add extra line between tools (except before the first tool)
            if i > 0:
                print()
            
            # Format the tool name properly
            display_name = format_tool_name(tool_name)
            
            # Get tool info if available
            tool_info = tool_manager.get_tool_info(tool_name)
            description = tool_info.get("short_description", "") if tool_info else ""
            
            # Format status
            enabled = tool_config.get("enabled", True)
            status = "\033[1;32m(Enabled)\033[0m" if enabled else "\033[1;31m(Disabled)\033[0m"
            
            # Format category
            category = tool_config.get("category", "unknown")
            
            # Format description - keep only the first phrase/sentence
            if description:
                # Split by sentence-ending punctuation and take only the first sentence
                sentences = re.split(r'(?<=[.!?])\s+', description)
                description = sentences[0].strip()
                
                # Add a period if it doesn't end with punctuation
                if not description[-1] in '.!?':
                    description += '.'
                
                # Clean up extra spaces
                description = " ".join(description.split())
            
            # Print tool info with status in parentheses next to the tool name
            print(f"  \033[1;36m{display_name}\033[0m {status}")
            # Keep the label in default color (white) and make the value gray
            print(f"    Category: \033[90m{category}\033[0m")
            if description:
                # Keep the label in default color (white) and make the value gray
                # Use a fixed width for the Description label to ensure proper alignment
                print(f"    Description: \033[90m{description}\033[0m")
    
    if not have_tools:
        print("\n\033[1;33mNo tools found in configuration.\033[0m")
    
    # Wait for user to press Enter
    input("\nPress Enter to continue...")


def enable_tools(cli) -> None:
    """
    Enable one or more tools.
    """
    # Clear screen
    print("\033[2J\033[H", end="")  # Clear screen
    print("\n\033[1;36mEnable Tools\033[0m")
    print("\033[1;36m============\033[0m")
    
    # Get tool manager from shared state
    tool_manager = cli.shared_state.tool_manager
    
    # Get all tools from the configuration
    config = tool_manager.get_config()
    
    # Create a dictionary to organize disabled tools by category
    disabled_tools_by_category = {tool_type: [] for tool_type in TOOL_TYPES}
    disabled_tools_flat = []
    
    # Collect disabled tools from all categories (excluding experimental)
    for tool_type in TOOL_TYPES:
        # Skip experimental tools
        if tool_type == TOOL_TYPE_EXPERIMENTAL:
            continue
            
        tools_in_category = config["tools"].get(tool_type, {})
        for tool_name, tool_config in tools_in_category.items():
            if not tool_config.get("enabled", True):
                disabled_tools_by_category[tool_type].append(tool_name)
                disabled_tools_flat.append((tool_name, tool_type))
    
    # Build the flat list in display order (by category, then alphabetically within category)
    disabled_tools_flat = []
    for tool_type in TOOL_TYPES:
        if disabled_tools_by_category[tool_type]:
            # Sort tools in this category alphabetically
            disabled_tools_by_category[tool_type].sort()
            # Add them to the flat list in display order
            for tool_name in disabled_tools_by_category[tool_type]:
                disabled_tools_flat.append((tool_name, tool_type))
    
    if not disabled_tools_flat:
        print("\n\033[1;33mAll tools are already enabled.\033[0m")
        input("\nPress Enter to continue...")
        return
        
    # Check for ongoing conversation only if there are tools to enable
    if not check_ongoing_conversation(cli):
        return
    
    # Display disabled tools by category
    print("\n\033[1mDisabled Tools:\033[0m")
    tool_index = 1
    
    for tool_type in TOOL_TYPES:
        # Skip categories with no disabled tools
        if not disabled_tools_by_category[tool_type]:
            continue
            
        # Get emoji for this tool type
        emoji = TOOL_TYPE_EMOJIS.get(tool_type, "")
        
        print(f"\n\033[1m{emoji} {tool_type.upper()} Tools:\033[0m")
        
        # Display tools in this category with sequential numbering
        for tool_name in disabled_tools_by_category[tool_type]:
            print(f"  \033[1;36m{tool_index}.\033[0m {tool_name}")
            tool_index += 1
    
    print("\n\033[1mOptions:\033[0m")
    print("  \033[1;36ma.\033[0m Enable all tools")
    print("  \033[1;36mq.\033[0m Return to tools management menu")
    
    # Get user choice
    print("(You can enter multiple numbers separated by commas, e.g., '1,3,5')")
    choice = input("\n\033[1mEnter choice(s):\033[0m ").strip().lower()
    
    if choice == 'q':
        return
    
    # Track tools that were enabled and their previous state for potential rollback
    enabled_tools = []
    
    # Enable all tools
    if choice == 'a':
        for tool_name, _ in disabled_tools_flat:
            if tool_manager.enable_tool(tool_name):
                print(f"\033[1;32mTool '{tool_name}' has been enabled.\033[0m")
                enabled_tools.append(tool_name)
            else:
                print(f"\033[1;31mFailed to enable tool '{tool_name}'.\033[0m")
    
    # Enable specific tools
    else:
        # Parse comma-separated choices
        try:
            # Split by comma and convert to integers, accounting for spaces
            indices = [int(idx.strip()) - 1 for idx in choice.split(',') if idx.strip().isdigit()]
            
            # Enable each selected tool
            for idx in indices:
                if 0 <= idx < len(disabled_tools_flat):
                    tool_name, _ = disabled_tools_flat[idx]
                    
                    # Enable the tool
                    if tool_manager.enable_tool(tool_name):
                        print(f"\033[1;32mTool '{tool_name}' has been enabled.\033[0m")
                        enabled_tools.append(tool_name)
                    else:
                        print(f"\033[1;31mFailed to enable tool '{tool_name}'.\033[0m")
                else:
                    print(f"\033[1;31mInvalid selection: {idx + 1}\033[0m")
        except ValueError:
            print(f"\033[1;31mInvalid input: {choice}\033[0m")
    
    # Update the agent with the new tools if any were enabled
    if enabled_tools:
        success = update_agent_tools(cli)
        
        # If update failed, roll back the changes
        if not success:
            print("\033[1;33mRolling back tool changes to maintain synchronization...\033[0m")
            for tool_name in enabled_tools:
                if tool_manager.disable_tool(tool_name):
                    print(f"\033[1;33mRolled back: Tool '{tool_name}' has been disabled.\033[0m")
                else:
                    print(f"\033[1;31mFailed to roll back tool '{tool_name}'.\033[0m")
        else:
            # Ask if user wants to make this the default tools configuration
            cli._ask_make_tools_config_default()
    
    # Wait for user to press Enter
    input("\nPress Enter to continue...")


def disable_tools(cli) -> None:
    """
    Disable one or more tools.
    """
    # Clear screen
    print("\033[2J\033[H", end="")  # Clear screen
    print("\n\033[1;36mDisable Tools\033[0m")
    print("\033[1;36m=============\033[0m")
    
    # Get tool manager from shared state
    tool_manager = cli.shared_state.tool_manager
    
    # Get all tools from the configuration
    config = tool_manager.get_config()
    
    # Create a dictionary to organize enabled tools by category
    enabled_tools_by_category = {tool_type: [] for tool_type in TOOL_TYPES}
    enabled_tools_flat = []
    
    # Collect enabled tools from all categories (excluding experimental)
    for tool_type in TOOL_TYPES:
        # Skip experimental tools
        if tool_type == TOOL_TYPE_EXPERIMENTAL:
            continue
            
        tools_in_category = config["tools"].get(tool_type, {})
        for tool_name, tool_config in tools_in_category.items():
            if tool_config.get("enabled", True):
                enabled_tools_by_category[tool_type].append(tool_name)
                enabled_tools_flat.append((tool_name, tool_type))
    
    # Build the flat list in display order (by category, then alphabetically within category)
    enabled_tools_flat = []
    for tool_type in TOOL_TYPES:
        if enabled_tools_by_category[tool_type]:
            # Sort tools in this category alphabetically
            enabled_tools_by_category[tool_type].sort()
            # Add them to the flat list in display order
            for tool_name in enabled_tools_by_category[tool_type]:
                enabled_tools_flat.append((tool_name, tool_type))
    
    if not enabled_tools_flat:
        print("\n\033[1;33mAll tools are already disabled.\033[0m")
        input("\nPress Enter to continue...")
        return
        
    # Check for ongoing conversation only if there are tools to disable
    if not check_ongoing_conversation(cli):
        return
    
    # Display enabled tools by category
    print("\n\033[1mEnabled Tools:\033[0m")
    tool_index = 1
    
    for tool_type in TOOL_TYPES:
        # Skip categories with no enabled tools
        if not enabled_tools_by_category[tool_type]:
            continue
            
        # Get emoji for this tool type
        emoji = TOOL_TYPE_EMOJIS.get(tool_type, "")
        
        print(f"\n\033[1m{emoji} {tool_type.upper()} Tools:\033[0m")
        
        # Display tools in this category with sequential numbering
        for tool_name in enabled_tools_by_category[tool_type]:
            print(f"  \033[1;36m{tool_index}.\033[0m {tool_name}")
            tool_index += 1
    
    print("\n\033[1mOptions:\033[0m")
    print("  \033[1;36ma.\033[0m Disable all tools")
    print("  \033[1;36mq.\033[0m Return to tools management menu")
    
    # Get user choice
    print("(You can enter multiple numbers separated by commas, e.g., '1,3,5')")
    choice = input("\n\033[1mEnter choice(s):\033[0m ").strip().lower()
    
    if choice == 'q':
        return
    
    # Track tools that were disabled and their previous state for potential rollback
    disabled_tools = []
    
    # Disable all tools
    if choice == 'a':
        for tool_name, tool_type in enabled_tools_flat:
            # Check if it's a basic tool first
            if tool_type == TOOL_TYPE_BASIC:
                print(f"\n\033[1;33m⚠️ WARNING:\033[0m \033[33mBasic tool cannot be disabled as they provide core functionality.")
                print(f"\033[33mTool '{tool_name}' is a basic tool that is required by the system.\033[0m")
                continue
            
            if tool_manager.disable_tool(tool_name):
                print(f"\033[1;32mTool '{tool_name}' has been disabled.\033[0m")
                disabled_tools.append(tool_name)
            else:
                print(f"\033[1;31mFailed to disable tool '{tool_name}'.\033[0m")
    
    # Disable specific tools
    else:
        # Parse comma-separated choices
        try:
            # Split by comma and convert to integers, accounting for spaces
            indices = [int(idx.strip()) - 1 for idx in choice.split(',') if idx.strip().isdigit()]
            
            # Disable each selected tool
            for idx in indices:
                if 0 <= idx < len(enabled_tools_flat):
                    tool_name, tool_type = enabled_tools_flat[idx]
                    
                    # Check if it's a basic tool first
                    if tool_type == TOOL_TYPE_BASIC:
                        print(f"\n\033[1;33m⚠️ WARNING:\033[0m \033[33mBasic tool cannot be disabled as they provide core functionality.")
                        print(f"\033[33mTool '{tool_name}' is a basic tool that is required by the system.\033[0m")
                        continue
                    
                    # Disable the tool
                    if tool_manager.disable_tool(tool_name):
                        print(f"\033[1;32mTool '{tool_name}' has been disabled.\033[0m")
                        disabled_tools.append(tool_name)
                    else:
                        print(f"\033[1;31mFailed to disable tool '{tool_name}'.\033[0m")
                else:
                    print(f"\033[1;31mInvalid selection: {idx + 1}\033[0m")
        except ValueError:
            print(f"\033[1;31mInvalid input: {choice}\033[0m")
    
    # Update the agent with the new tools if any were disabled
    if disabled_tools:
        success = update_agent_tools(cli)
        
        # If update failed, roll back the changes
        if not success:
            print("\033[1;33mRolling back tool changes to maintain synchronization...\033[0m")
            for tool_name in disabled_tools:
                if tool_manager.enable_tool(tool_name):
                    print(f"\033[1;33mRolled back: Tool '{tool_name}' has been enabled.\033[0m")
                else:
                    print(f"\033[1;31mFailed to roll back tool '{tool_name}'.\033[0m")
        else:
            # Ask if user wants to make this the default tools configuration
            cli._ask_make_tools_config_default()
    
    # Wait for user to press Enter
    input("\nPress Enter to continue...")


def register_tool_dependencies(cli) -> None:
    """
    Register dependencies for all tools, regardless of whether they're enabled.
    
    This method ensures that all tools have the dependencies they need:
    - WebSearchTool needs the GEAIClient
    - Edit, View, and Replace tools need the FileEditor
    
    Dependencies are lazily created if they don't exist.
    """
    # Get tool manager from shared state
    tool_manager = cli.shared_state.tool_manager
    
    if not tool_manager:
        logger.error("Cannot register tool dependencies: Tool manager not initialized")
        return
        
    # Ensure the file editor is initialized in the agent handler
    if not hasattr(cli, 'agent_handler'):
        logger.error("Cannot register tool dependencies: Agent handler not initialized")
        return
        
    if not hasattr(cli.agent_handler, 'file_editor') or cli.agent_handler.file_editor is None:
        cli.agent_handler.file_editor = FileEditor()

    # Get the GEAIClient from shared state
    geai_client = cli.shared_state.geai_client
    
    # Get all tools from the configuration (both enabled and disabled)
    # This ensures we register dependencies for all tools, not just the enabled ones
    config = tool_manager.get_config()
    
    # Register dependencies for all tools
    for tool_type in config["tools"]:
        for tool_name in config["tools"][tool_type]:
            # File operations tools need the file editor
            if tool_name in ["edit", "view", "replace"]:
                # Register the file editor as a dependency
                tool_manager.register_tool_dependency(tool_name, "editor", cli.agent_handler.file_editor)
            
            # External tools need the client
            if tool_name in ["web_search", "examine_images"]:
                # Register the client as a dependency
                tool_manager.register_tool_dependency(tool_name, "client", geai_client)


def update_agent_tools(cli, active_mode=None) -> bool:
    """
    Update the agent with the current tool configuration.
    This method is called after enabling or disabling tools.
    
    Args:
        cli: The CLI instance containing shared state and agent handler
        active_mode: Optional active mode dict if using modes containing (template name and key), otherwise None

    Returns:
        bool: True if the update was successful, False otherwise
    """
    
    # Get the active agent from the handler
    active_agent = cli.agent_handler.get_active_agent()
    
    if active_agent is None:
        logger.info("No active agent found. Tools will be applied when agent is available.")
    
    # Check if the main_agent exists. It should always be available at this point
    if not hasattr(cli.shared_state, 'main_agent'):
        print("\033[1;33mNo agent initialized yet. Tools will be applied when agent is created.\033[0m")
        return True
    
    # Get tool manager from shared state
    tool_manager = cli.shared_state.tool_manager
    
    if not tool_manager:
        print("\033[1;31mError: Tool manager not initialized.\033[0m")
        return False
    
    try:
        # Get all enabled tools with dependencies injected
        enabled_tools = tool_manager.get_enabled_tools()

        # Use the prompt_management helper to update agent tools and handle transitions
        # Get MCP server states before update to track changes
        mcp_servers_before = set()
        try:
            mcp_service = MCPService.get()
            if mcp_service.is_available() and hasattr(cli, 'session_manager') and cli.session_manager:
                # Check if MCP UI set a before state for us to use
                if hasattr(cli, '_mcp_servers_before_from_ui'):
                    mcp_servers_before = cli._mcp_servers_before_from_ui
                    # Clean up after use
                    delattr(cli, '_mcp_servers_before_from_ui')
                else:
                    effective_states = mcp_service.get_effective_server_states(cli.session_manager.current_session.id)
                    mcp_servers_before = set(name for name, enabled in effective_states.items() if enabled)
        except Exception as e:
            pass  # Don't let MCP tracking break tool updates
               
        # We'll handle system prompt update after MCP transition. 
        # Since no system prompt update here, user defined rules won't be applied.
        # Now call the update method on the agent
        result = active_agent.update_agent_with_tool_changes(
            updated_tools=enabled_tools,
            update_system_prompt_flag=True,  
            active_mode=active_mode
        )

        # Check for MCP server changes and handle transition
        mcp_servers_after = set()
        try:
            if mcp_service.is_available() and hasattr(cli, 'session_manager') and cli.session_manager:
                effective_states = mcp_service.get_effective_server_states(cli.session_manager.current_session.id)
                mcp_servers_after = set(name for name, enabled in effective_states.items() if enabled)
        except Exception as e:
            pass

        # Handle MCP transitions if there were changes
        if mcp_servers_before != mcp_servers_after:
            added_servers = list(mcp_servers_after - mcp_servers_before)
            removed_servers = list(mcp_servers_before - mcp_servers_after)

            active_agent.handle_mcp_transition(
                added_servers=added_servers,
                removed_servers=removed_servers,
                update_system_prompt_flag=True,
                user_defined_rules=cli.shared_state.user_defined_rules,
                active_mode=active_mode)

            if added_servers or removed_servers:
                print("\033[1;36mMCP server changes detected and transition message added.\033[0m")
        else:
            # No MCP changes, just update system prompt if tools changed
            if result['changed']:
                # Continue using the same agent instance
                if hasattr(active_agent, 'update_system_prompt'):
                    # If active_mode is provided, use its template
                    if active_mode is not None and "system_prompt_template_name" in active_mode:
                        template_name = active_mode["system_prompt_template_name"]
                        active_agent.update_system_prompt(user_defined_rules=cli.shared_state.user_defined_rules, template_name=template_name)
                    # Otherwise check mode_manager
                    elif hasattr(cli, 'mode_manager') and hasattr(cli.mode_manager, 'get_current_mode'):
                        current_mode_key = cli.mode_manager.get_current_mode() 
                        if current_mode_key is not None:
                            current_mode_object = cli.mode_manager.get_mode_by_key(current_mode_key)  
                            template_name = current_mode_object.system_prompt
                            active_agent.update_system_prompt(user_defined_rules=cli.shared_state.user_defined_rules, template_name=template_name)
                        else:
                            # No active mode or mode_manager, use default prompt
                            active_agent.update_system_prompt(
                                user_defined_rules=cli.shared_state.user_defined_rules)
                else:
                    logger.warning(f"Agent of type {type(active_agent).__name__} doesn't support update_system_prompt")
            
            # update system prompt to handle mcp changes
            active_agent.update_system_prompt(user_defined_rules=cli.shared_state.user_defined_rules)
        
        return True
            
    except Exception as e:
        print(f"\033[1;31mError updating active_agent tools: {str(e)}\033[0m")
        return False