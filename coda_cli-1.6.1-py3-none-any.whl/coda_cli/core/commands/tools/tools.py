import time
from typing import List
from coda_cli.core.commands.base import Command
from coda_cli.core.commands.tools.utils import (
    reset_tools_to_system_defaults,
    list_tools,
    enable_tools,
    disable_tools,
    register_tool_dependencies
)

class ToolsCommand(Command):
    """Implementation of the /tools command to manage agent tools."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/tools", "/t"]
    
    def description(self) -> str:
        """Return command description."""
        return "Manage agent tools"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []
    
    def execute(self, args) -> bool:
        """
        Manage agent tools (list, enable, disable).
        
        This command provides an interactive interface for tool management:
        - List available tools with their status
        - Enable specific tools
        - Disable specific tools
        
        Args:
            args (str): Command arguments (not used)
            
        Returns:
            bool: Always returns True to continue CLI execution
        """
        # The /tools menu has a hard-dependency on the agent initialization, so we have to block until it's finished
        if not self.cli.wait_for_agent_initialization():
            # Finish CLI execution on agent initialization failure
            return False

        # register tools dependencies
        register_tool_dependencies(self.cli)
        
        # Display tools management header
        print("\033[2J\033[H", end="")  # Clear screen
        print("\n\033[1;36mTools Management\033[0m")
        print("\033[1;36m================\033[0m")
        
        # Main menu options
        operations = [
            "List all tools",
            "Enable tools",
            "Disable tools",
            "Reset to system defaults"
        ]
        
        # Display operations
        for i, op in enumerate(operations, 1):
            print(f"  \033[1;36m{i}.\033[0m {op}")
        print("  \033[1;36mq.\033[0m Return to main interface")
        
        # Get user choice
        while True:
            try:
                choice = input("\n\033[1mEnter choice: \033[0m").strip().lower()
                
                if choice == 'q':
                    return True
                    
                elif choice == '1':
                    # List all tools
                    list_tools(self.cli)
                    
                elif choice == '2':
                    # Enable tools
                    enable_tools(self.cli)
                    
                elif choice == '3':
                    # Disable tools
                    disable_tools(self.cli)
                
                elif choice == '4':
                    # Reset to system defaults
                    reset_tools_to_system_defaults(self.cli)
                    
                else:
                    # Clear screen and show error
                    print("\033[2J\033[H", end="")
                    print(f"\033[1;31mInvalid selection: {choice}. Please try again.\033[0m")
                    print("Returning to tools management menu...")
                    time.sleep(1.5)
                    
                # Return to the tools management menu
                return self.execute("")
                    
            except Exception as e:
                print(f"\033[1;31mError: {e}\033[0m")
                return True
            