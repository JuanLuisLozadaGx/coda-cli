from typing import List, Dict, Any, Optional
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit import print_formatted_text
import json

from loguru import logger
from coda_cli.core.commands.base import Command
from coda_cli.core.commands.modes.ui import display_auto_execution_start, display_auto_execution_response
from coda_cli.core.commands.step_by_step.constants import auto_execution_injected_message

class ApprovePlanCommand(Command):
    """
    CLI command to approve the current plan in Plan Mode.
    
    This command approves the currently active plan, which causes 
    the agent to transition from planning to execution mode.
    """
    
    def aliases(self) -> List[str]:
        """Return the command aliases."""
        return ["/approve", "/start"]
    
    def description(self) -> str:
        """Return the command description."""
        return "Approve the current plan and switch to execution mode (only available in Plan Mode)."
    
    def arguments(self) -> List[str]:
        """Return the command arguments."""
        return []  # No arguments needed
    
    def get_metadata(self) -> Dict[str, Any]:
        """Return the command metadata."""
        return {
            "command_class": "step_by_step",
            "description": self.description(),
            "arguments": []
        }
    
    def execute(self, args: str) -> bool:
        """
        Execute the approve plan command.
        
        Args:
            args: Not used for this command
            
        Returns:
            bool: True to continue CLI execution, False to exit
        """
        # Check if we're in Plan Mode - if not, show an error
        if not self.cli or not hasattr(self.cli, "mode_manager"):
            print_formatted_text(HTML("<ansired>Error: Mode manager not available</ansired>"))
            return True
            
        current_mode_key = self.cli.mode_manager._current_mode_key
        if not current_mode_key or "Plan Mode" not in current_mode_key:
            print_formatted_text(HTML("<ansired>Error: This command is only available in Plan Mode</ansired>"))
            return True
        
        # Get the current mode instance
        current_mode = self.cli.mode_manager.get_mode_by_key(current_mode_key)
        if not current_mode or not hasattr(current_mode, "agent"):
            print_formatted_text(HTML("<ansired>Error: Plan Mode agent not available</ansired>"))
            return True
        
        # Get the agent
        agent = current_mode.agent
        if not agent:
            print_formatted_text(HTML("<ansired>Error: Plan Mode agent not available</ansired>"))
            return True
        
        # Get the plan ID - try multiple sources
        plan_id = None
        
        # First, try to get it from the memory manager (if already set during a previous approval or load)
        if hasattr(current_mode, "state_machine") and hasattr(current_mode.state_machine, "_memory_manager"):
            plan_id = current_mode.state_machine._memory_manager.plan_id
        
        # If not found in memory manager, extract it from the agent's recent memory
        if not plan_id and agent and hasattr(agent, 'memory'):
            plan_id = self._extract_plan_id_from_memory(agent.memory)
        
        if not plan_id:
            print_formatted_text(HTML("<ansired>Error: No active plan found. Create a plan first.</ansired>"))
            return True
        
        # Find the approve_plan_tool in the agent's tools
        approve_plan_tool = None
        if hasattr(agent, 'tools'):
            for tool in agent.tools:
                if tool.name == "approve_plan_tool":
                    approve_plan_tool = tool
                    break
        
        if not approve_plan_tool:
            print_formatted_text(HTML("<ansired>Error: approve_plan_tool not found in agent's tools</ansired>"))
            logger.error("approve_plan_tool not available in agent's tools")
            return True
        
        try:

            # Call the tool directly with the plan_id parameter
            result = approve_plan_tool.execute(plan_id=plan_id, start_command = True)
            logger.info(f"Approve plan tool result: {result}")
            
            if isinstance(result, dict) and result.get("status") == "error":
                print_formatted_text(HTML(f"<ansired>Error approving plan: {result.get('message', 'Unknown error')}</ansired>"))
            else:
                print_formatted_text(HTML(f"<ansigreen>✅ Plan approved successfully! Mode switched to execution.</ansigreen>"))
                print()  # Add blank line after approval message
                
                # Trigger automatic execution start if the mode supports it
                if hasattr(current_mode, 'trigger_auto_execution'):
                    try:                     
                        # Show a message that auto-execution is starting
                        display_auto_execution_start()
                        
                        # Call the auto-execution method
                        logger.info("Calling trigger_auto_execution on current mode")
                        agent_response = current_mode.trigger_auto_execution()
                        
                        # Log detailed information about the response
                        logger.debug(f"trigger_auto_execution returned: {type(agent_response).__name__}")
                        if agent_response is None:
                            logger.warning("trigger_auto_execution returned None - no response to display")
                        elif isinstance(agent_response, str):
                            logger.debug(f"Response length: {len(agent_response)}")
                            logger.debug(f"Response starts with: {agent_response[:100] if len(agent_response) > 100 else agent_response}")
                            logger.debug(f"Response is whitespace only: {not agent_response.strip()}")
                        else:
                            logger.warning(f"Unexpected response type: {type(agent_response).__name__}")
                        
                        # Use the dedicated UI function to display the response
                        display_auto_execution_response(agent_response)
                        print()
                        
                    except Exception as auto_exec_error:
                        logger.error(f"Could not trigger auto execution: {auto_exec_error}")
                        print_formatted_text(HTML(f"<ansiblue>Ready to start execution. Press Enter to begin...</ansiblue>"))
                else:
                    # Fallback: inject user message for next interaction
                    if agent and hasattr(agent, 'memory'):
                        try:
                            start_execution_message = auto_execution_injected_message()
                            agent.memory.add_user_message(start_execution_message)
                            logger.info("Injected auto-start execution message into agent memory")
                            print_formatted_text(HTML(f"<ansiblue>Ready to start execution. Press Enter to begin...</ansiblue>"))
                        except Exception as mem_error:
                            logger.error(f"Could not inject message into memory: {mem_error}")
                            print_formatted_text(HTML(f"<ansiblue>Ready to start execution. Press Enter to begin...</ansiblue>"))
                
        except Exception as e:
            logger.error(f"Error executing approve_plan_tool: {e}")
            print_formatted_text(HTML(f"<ansired>Error: {str(e)}</ansired>"))
        
        # No need to manually switch modes - the tool's state machine callback handles that
        return True
    
    def _extract_plan_id_from_memory(self, memory) -> Optional[str]:
        """
        Extract the plan_id from the most recent create_plan tool call in agent memory.
        
        Args:
            memory: The agent's memory object
            
        Returns:
            The plan_id if found, None otherwise
        """
        try:
            if not memory or not hasattr(memory, 'retrieve'):
                return None
            
            messages = memory.retrieve()
            
            # Build a map of tool_call_id to tool name
            tool_call_map = {}
            
            # First pass: identify create_plan tool calls
            for message in messages:
                if message.get('role') == 'assistant' and 'tool_calls' in message:
                    for tool_call in message.get('tool_calls', []):
                        tool_call_id = tool_call.get('id')
                        function = tool_call.get('function', {})
                        tool_name = function.get('name')
                        if tool_name == 'create_plan':
                            tool_call_map[tool_call_id] = tool_name
            
            # Second pass: find the result of the most recent create_plan call
            for message in reversed(messages):
                # Look for tool result messages
                if message.get('role') == 'tool':
                    tool_call_id = message.get('tool_call_id')
                    
                    # Check if this is a create_plan result
                    if tool_call_id and tool_call_map.get(tool_call_id) == 'create_plan':
                        content = message.get('content', '')
                        
                        # Try to parse the content as JSON
                        try:
                            result = json.loads(content)
                            
                            # create_plan returns a tuple: (md_path, plan_dict)
                            # Handle both tuple/list and direct dict formats
                            plan_dict = None
                            
                            if isinstance(result, (list, tuple)) and len(result) >= 2:
                                # Result is a tuple/list, second element is the plan dict
                                plan_dict = result[1]
                            elif isinstance(result, dict):
                                # Result is already a dict
                                plan_dict = result
                            
                            # Extract plan_id from the plan dict
                            if plan_dict and isinstance(plan_dict, dict) and 'plan_id' in plan_dict:
                                plan_id = plan_dict.get('plan_id')
                                logger.info(f"Extracted plan_id from memory: {plan_id}")
                                return plan_id
                        except (json.JSONDecodeError, TypeError) as e:
                            logger.debug(f"Could not parse tool result as JSON: {e}")
                            continue
            
            logger.warning("No plan_id found in agent memory")
            return None
            
        except Exception as e:
            logger.error(f"Error extracting plan_id from memory: {e}")
            return None