import os
import glob
from typing import List, Dict, Any, Optional
from loguru import logger

from prompt_toolkit.formatted_text import HTML
from prompt_toolkit import print_formatted_text

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.core.modes.step_by_step_utilities.planning_converters import (
    load_plan,
    json_to_markdown,
)
from coda_cli.core.ui.core import print_markdown_response


def cleanup_orphaned_plans(
    plans_dir: str,
    private_plans_dir: Optional[str] = None,
) -> List[str]:
    """
    Clean up orphaned JSON plan files that don't have corresponding .md files.

    Args:
        plans_dir: Directory containing markdown plan files
        private_plans_dir: Optional private plans directory containing JSON files

    Returns:
        List of removed plan IDs
    """
    removed_plans: List[str] = []

    # Collect all markdown files from both directories
    md_files = set()
    for directory in [d for d in [plans_dir, private_plans_dir] if d]:
        if not os.path.exists(directory):
            continue
        for filename in os.listdir(directory):
            if filename.endswith(".md"):
                md_files.add(filename[:-3])  # Store without extension

    # Check JSON files and remove those without markdown counterparts
    for directory in [d for d in [plans_dir, private_plans_dir] if d]:
        if not os.path.exists(directory):
            continue

        json_files = [f for f in os.listdir(directory) if f.endswith(".json")]

        for json_file in json_files:
            json_id = os.path.splitext(json_file)[0]
            # Check if there's a corresponding markdown file in either directory
            if json_id not in md_files:
                try:
                    os.remove(os.path.join(directory, json_file))
                    removed_plans.append(json_id)
                except Exception as e:
                    logger.error(
                        f"Error removing orphaned JSON file {json_file}: {e}"
                    )

    return removed_plans
def refresh_agent_after_transition(current_mode: Any) -> None:
    """
    Refresh the agent after state transition to execution mode.

    After load_plan_tool is executed, the state machine transitions from PLANNING_MODE
    to EXECUTION_MODE and creates a new agent with execution tools. This method ensures
    the CLI has the updated agent reference.
    """
    try:
        if current_mode and hasattr(current_mode, "agent"):
            updated_agent = current_mode.agent
            if updated_agent:
                logger.info("Agent refreshed after transition to execution mode")
                logger.info(
                    "Agent has %d tools available",
                    len(updated_agent.tools) if hasattr(updated_agent, "tools") else 0,
                )
                if hasattr(updated_agent, "tools"):
                    tool_names = [tool.name for tool in updated_agent.tools]
                    logger.info(f"Available tools: {tool_names}")
            else:
                logger.warning("Current mode agent is None after transition")
        else:
            logger.warning("Current mode does not have an agent attribute")
    except Exception as e:
        logger.error(f"Error refreshing agent after transition: {e}")


def load_selected_plan(cli, plan_id: str) -> None:
    """
    Load the selected plan using the agent's load_plan_tool.

    This will trigger the state machine to transition from planning to execution mode.
    """
    logger.info(f"Loading plan: {plan_id}")

    if not cli or not hasattr(cli, "mode_manager"):
        print_formatted_text(HTML("<ansired>Error: Mode manager not available</ansired>"))
        return

    current_mode_key = cli.mode_manager._current_mode_key
    current_mode = cli.mode_manager.get_mode_by_key(current_mode_key)
    logger.info(f"Current mode key: {current_mode_key}")

    if not current_mode or not hasattr(current_mode, "agent"):
        print_formatted_text(
            HTML("<ansired>Error: Plan Mode mode agent not available</ansired>")
        )
        return

    agent = current_mode.agent
    if not agent:
        print_formatted_text(
            HTML("<ansired>Error: Plan Mode agent not available</ansired>")
        )
        return

    load_plan_tool = None
    if hasattr(agent, "tools"):
        for tool in agent.tools:
            if tool.name == "load_plan_tool":
                load_plan_tool = tool
                break

    if not load_plan_tool:
        print_formatted_text(
            HTML("<ansired>Error: load_plan_tool not found in agent's tools</ansired>")
        )
        logger.error("load_plan_tool not available in agent's tools")
        return

    try:
        result: Dict[str, Any] = load_plan_tool.execute(plan_id=plan_id)  # type: ignore[arg-type]
        logger.info(f"Load plan tool result: {result}")

        if result.get("status") == "error":
            print_formatted_text(
                HTML(
                    f"<ansired>Error loading plan: "
                    f"{result.get('message', 'Unknown error')}</ansired>"
                )
            )
            return

        print_formatted_text(
            HTML("<ansigreen>✅ Plan loaded successfully!</ansigreen>")
        )

        # Refresh agent after the state machine transition
        refresh_agent_after_transition(current_mode)

        # Load and display the plan details using markdown formatting
        plans_dir = SETTINGS.get_plans_dir()
        private_plans_dir = SETTINGS.get_env_var(
            EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE
        )
        plan = load_plan(plan_id, plans_dir, private_plans_dir, save_json=False)

        if plan:
            markdown_content = json_to_markdown(plan)
            print_markdown_response(markdown_content)
            logger.info(
                "Plan loaded and displayed. User can now use execution commands like /proceed"
            )

    except Exception as e:
        logger.error(f"Error executing load_plan_tool: {e}")
        print_formatted_text(HTML(f"<ansired>Error: {str(e)}</ansired>"))


def list_plans(plans_dir: str, include_private: bool = False, private_plans_dir: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    List all available plans from the specified directories.
    
    Args:
        plans_dir: Directory containing shared plans
        include_private: Whether to include private plans in the result
        private_plans_dir: Directory containing private plans (if any)
        
    Returns:
        List of plan metadata dictionaries
    """
    all_plans = []
    
    # Helper function to extract metadata from a plan file
    def extract_plan_metadata(file_path: str) -> Optional[Dict[str, Any]]:
        try:
            # Get plan ID from filename
            plan_id = os.path.splitext(os.path.basename(file_path))[0]
            
            # Load the plan using the coda-core function
            plan = load_plan(plan_id, plans_dir, private_plans_dir, save_json=False)
            
            if not plan:
                return None
            
            # Handle the case where status is a string instead of an enum
            status_value = plan.status
            if hasattr(plan.status, 'value'):
                status_value = plan.status.value
                
            # Extract metadata
            return {
                "id": plan.plan_id,
                "summary": plan.summary,
                "updated_at": plan.updated_at.strftime("%Y-%m-%d %H:%M"),
                "steps_count": len(plan.steps) if plan.steps else 0,
                "status": status_value,
                "completed_steps": sum(1 for step in plan.steps 
                                     if hasattr(step.status, 'value') and step.status.value in ["✅ Completed", "✓ Completed"]
                                     or step.status in ["✅ Completed", "✓ Completed"])
                if plan.steps else 0
            }
        except Exception as e:
            logger.error(f"Error extracting plan metadata from {file_path}: {e}")
            return None
    
    dirs_to_process = []
    if plans_dir:
        dirs_to_process.append((plans_dir, False))
    if include_private and private_plans_dir:
        dirs_to_process.append((private_plans_dir, True))
    
    for directory, is_private in dirs_to_process:
        if not os.path.isdir(directory):
            continue
        for md_file in glob.glob(os.path.join(directory, "*.md")):
            metadata = extract_plan_metadata(md_file)
            if metadata:
                if is_private:
                    metadata["private"] = True
                all_plans.append(metadata)
                
    return all_plans