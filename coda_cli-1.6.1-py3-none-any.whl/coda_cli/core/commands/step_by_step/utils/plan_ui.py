from typing import List, Dict, Any
from coda_core.core.modes.step_by_step_utilities.schemas import Plan

from .plan_formatting import (
    format_plan_entry,
    ANSI_BOLD,
    ANSI_CYAN,
    ANSI_DIM,
    ANSI_RESET,
)


def select_plan_interactive(
    plans: List[Dict[str, Any]],
    page_size: int = 7,
) -> str | None:
    """
    Display interactive plan selection UI with pagination.

    Args:
        plans: List of plan metadata dictionaries
        page_size: Number of plans to display per page

    Returns:
        Selected plan ID or None if cancelled
    """
    if not plans:
        return None

    total_pages = (len(plans) + page_size - 1) // page_size
    current_page = 1

    while True:
        # Clear screen
        print("\033[2J\033[H", end="")

        print(f"\n{ANSI_CYAN}Available Plans{ANSI_RESET}")
        print(f"{ANSI_CYAN}==============={ANSI_RESET}")
        print(f"\nPage {current_page} of {total_pages}\n")

        start_idx = (current_page - 1) * page_size
        end_idx = min(start_idx + page_size, len(plans))

        for i, plan in enumerate(plans[start_idx:end_idx], start=1):
            print(format_plan_entry(plan, i))

        print(f"\n{ANSI_BOLD}Navigation:{ANSI_RESET}")
        if total_pages > 1:
            print("  n: Next page")
            print("  p: Previous page")
        print("  q: Cancel and return to Plan Mode")
        print("  Or enter a number to load a plan")

        selection = input(f"\n{ANSI_BOLD}Enter choice: {ANSI_RESET}").strip().lower()

        if selection == "q":
            print(f"\n{ANSI_DIM}Plan selection cancelled.{ANSI_RESET}")
            return None
        elif selection == "n":
            if current_page < total_pages:
                current_page += 1
            continue
        elif selection == "p":
            if current_page > 1:
                current_page -= 1
            continue
        elif selection.isdigit():
            idx = int(selection)
            visible_items = len(plans[start_idx:end_idx])
            if 1 <= idx <= visible_items:
                actual_idx = start_idx + idx - 1
                return plans[actual_idx]["id"]
            else:
                print(
                    f"\n\033[1;31mInvalid selection. "
                    f"Please enter a number between 1 and {visible_items}\033[0m"
                )
                input("Press Enter to continue...")
        else:
            print(
                "\n\033[1;31mInvalid input. Please enter a number, 'n', 'p', or 'q'\033[0m"
            )
            input("Press Enter to continue...")


def display_plan_details(plan: Plan) -> None:
    """
    Display the complete plan details in a formatted way.

    Args:
        plan: The Plan object to display
    """
    print("\n")
    print(f"{ANSI_CYAN}{plan.plan_id.replace('_', ' ').title()}{ANSI_RESET}")
    print()

    # Summary
    print(f"{ANSI_BOLD}Summary:{ANSI_RESET} {plan.summary}")
    print()

    # Status
    status_value = plan.status
    if hasattr(plan.status, "value"):
        status_value = plan.status.value
    print(f"{ANSI_BOLD}Current Status:{ANSI_RESET} {status_value}")

    # Execution mode
    exec_pref = plan.execution_preference
    if hasattr(plan.execution_preference, "value"):
        exec_pref = plan.execution_preference.value

    execution_mode = "Step by step" if exec_pref == "step_by_step" else "All at once"
    print(f"{ANSI_BOLD}Execution mode:{ANSI_RESET} {execution_mode}")
    print()

    # Steps
    if plan.steps:
        print(f"{ANSI_BOLD}Steps:{ANSI_RESET}")
        for step in plan.steps:
            # Step status
            step_status = step.status
            if hasattr(step.status, "value"):
                step_status = step.status.value
            print(f"{step.number}. {step_status} {step.title}")

            # Subtasks
            if step.subtasks:
                for subtask in step.subtasks:
                    print(f"   - {subtask.description}")

            print()  # Empty line between steps

    print(ANSI_DIM + "─" * 80 + ANSI_RESET)
    print()
