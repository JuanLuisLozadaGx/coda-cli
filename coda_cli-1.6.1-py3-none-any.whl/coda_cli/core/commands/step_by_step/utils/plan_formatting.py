from typing import Dict, Any


ANSI_RESET = "\033[0m"
ANSI_BOLD = "\033[1m"
ANSI_DIM = "\033[2m"
ANSI_CYAN = "\033[1;36m"
ANSI_GREEN = "\033[1;32m"
ANSI_RED = "\033[1;31m"
ANSI_YELLOW = "\033[1;33m"


def format_plan_status(status: str) -> str:
    """
    Format plan status with appropriate color codes.

    Args:
        status: Plan status string

    Returns:
        Formatted status string with ANSI color codes
    """
    if status == "✅ Approved":
        return f"{ANSI_GREEN}✅ Approved{ANSI_RESET}"
    elif status == "✅ Completed":
        return f"{ANSI_GREEN}✅ Completed{ANSI_RESET}"
    elif status == "❌ Failed":
        return f"{ANSI_RED}❌ Failed{ANSI_RESET}"
    else:
        return f"{ANSI_YELLOW}⏳ Pending{ANSI_RESET}"


def format_plan_entry(plan: Dict[str, Any], index: int) -> str:
    """
    Format a plan entry for display in the plan selection UI.

    Args:
        plan: Plan metadata dictionary
        index: Display index (1-based)

    Returns:
        Formatted plan entry string
    """
    status_display = format_plan_status(plan["status"])
    plan_id = f"{ANSI_CYAN}{index:2d}.{ANSI_RESET} {plan['id']}"

    summary = plan["summary"][:50]
    if len(plan["summary"]) > 50:
        summary += "..."

    completed_steps = plan.get("completed_steps", 0)
    if completed_steps > 0:
        progress = f"{completed_steps}/{plan['steps_count']} steps"
    else:
        progress = f"{plan['steps_count']} steps"

    return (
        f"  {plan_id}\n"
        f"     {status_display} - {summary}\n"
        f"     {ANSI_DIM}({progress}) - {plan['updated_at']}{ANSI_RESET}\n"
    )
