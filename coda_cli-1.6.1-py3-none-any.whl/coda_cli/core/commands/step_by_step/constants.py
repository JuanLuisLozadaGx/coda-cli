
def auto_execution_injected_message() -> str:
    """
    Returns a message indicating that the plan is already approved and execution should begin without using any tools.
    """
    return "DO NOT use any tool (update_plan_tool, approve_plan_tool or user_ask_tool). The plan is already approved. Please start executing the plan. Begin with step 1."

def prompt_message_for_loading_plan(result: str) -> str:
     return f"First approve the plan using the approve_plan_tool, then show the following plan to the user with all the details, it means all the steps with its subtasks:{result}"
