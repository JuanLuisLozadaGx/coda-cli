
from typing import List, Dict, Any
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit import print_formatted_text
from loguru import logger

from coda_cli.core.commands.base import Command
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_cli.core.commands.step_by_step.utils.planning_helpers import list_plans
from coda_cli.core.commands.step_by_step.utils.planning_helpers import cleanup_orphaned_plans, load_selected_plan
from coda_cli.core.commands.step_by_step.utils.plan_ui import select_plan_interactive, display_plan_details

# Fallback for missing EnvConfig attributes in different versions of coda-core
if not hasattr(EnvConfig, "CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE"):
    setattr(
        EnvConfig,
        "CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE",
        "CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE",
    )


class LoadPlanCommand(Command):
    """
    CLI command to list and load available plans in step by step mode.

    This command displays a menu of available plans, lets the user select one,
    and triggers loading the selected plan, which causes the agent to transition
    from planning to execution mode.
    """

    def aliases(self) -> List[str]:
        return ["/load_plan", "/plans"]

    def description(self) -> str:
        return "List and load available plans (only available in Plan Mode)."

    def arguments(self) -> List[str]:
        return ["[plan_id|cleanup]"]

    # --- internal helpers -------------------------------------------------

    def _ensure_plan_mode(self) -> bool:
        """
        Ensure we are in Plan Mode; if not, attempt to activate it.

        Returns:
            True if Plan Mode is active / available, False otherwise.
        """
        if not self.cli or not hasattr(self.cli, "mode_manager"):
            print_formatted_text(
                HTML("<ansired>Error: Mode manager not available</ansired>")
            )
            return False

        current_mode_key = self.cli.mode_manager._current_mode_key
        if current_mode_key and "Plan Mode" in current_mode_key:
            return True

        # Try to find planning mode
        planning_mode_key = None
        modes_info = self.cli.mode_manager.get_available_modes()
        for key, _ in modes_info.items():
            if "Plan Mode" in key:
                planning_mode_key = key
                break

        if not planning_mode_key:
            print_formatted_text(
                HTML("<ansired>Error: Plan Mode not found</ansired>")
            )
            return False

        # Provide CLI reference to mode for usage synchronization
        mode_instance = self.cli.mode_manager.get_mode_by_key(planning_mode_key)
        if mode_instance:
            mode_instance.cli = self.cli

        success = self.cli.mode_manager.select_mode(planning_mode_key)
        if not success:
            print_formatted_text(
                HTML("<ansired>Error: Failed to activate Plan Mode</ansired>")
            )
            return False

        return True

    # --- command entrypoint -----------------------------------------------

    def execute(self, args: str) -> bool:
        """
        Execute the load plan command.

        Args:
            args: Optional plan ID to load directly, or the keyword 'cleanup'.

        Returns:
            bool: True to continue CLI execution, False to exit
        """
        if not self._ensure_plan_mode():
            return True

        plans_dir = SETTINGS.get_plans_dir()
        private_plans_dir = SETTINGS.get_env_var(
            EnvConfig.CODA_STEP_BY_STEP_PLANS_DIR_PRIVATE
        )

        arg_str = args.strip()

        # --- direct arguments: cleanup or specific plan id -----------------
        if arg_str:
            arg_lower = arg_str.lower()

            if arg_lower == "cleanup":
                print_formatted_text(
                    HTML(
                        "<ansiblue>Cleaning up orphaned JSON plan files..."
                        "</ansiblue>"
                    )
                )
                removed = cleanup_orphaned_plans(plans_dir, private_plans_dir)
                if removed:
                    print_formatted_text(
                        HTML(
                            f"<ansigreen>✅ Removed {len(removed)} "
                            f"orphaned JSON plan files:</ansigreen>"
                        )
                    )
                    for plan_id in removed:
                        print(f"  - {plan_id}")
                else:
                    print_formatted_text(
                        HTML(
                            "<ansigreen>✓ No orphaned JSON plan files found"
                            "</ansigreen>"
                        )
                    )
                return True

            # treat as plan_id
            plan_id = arg_str
            load_selected_plan(self.cli, plan_id)
            return True

        # --- no arguments: auto-clean + interactive picker -----------------
        removed = cleanup_orphaned_plans(plans_dir, private_plans_dir)
        if removed:
            print_formatted_text(
                HTML(
                    f"<ansigreen>✅ Automatically removed {len(removed)} "
                    f"orphaned JSON plan files</ansigreen>"
                )
            )

        all_plans = list_plans(plans_dir, False, private_plans_dir)
        all_plans.sort(key=lambda x: x["updated_at"], reverse=True)

        if not all_plans:
            print_formatted_text(
                HTML("<ansiyellow>No saved plans found</ansiyellow>")
            )
            return True

        selected_plan_id = select_plan_interactive(all_plans)
        if selected_plan_id:
            load_selected_plan(self.cli, selected_plan_id)

        return True
        
    # --- backward compatibility methods for tests ----------------------------
    
    def _load_selected_plan(self, plan_id: str) -> None:
        """
        Backward compatibility method for tests that call LoadPlanCommand._load_selected_plan.
        Delegates to the function moved to planning_helpers module.
        """
        load_selected_plan(self.cli, plan_id)
        
    def _display_plan_details(self, plan) -> None:
        """
        Backward compatibility method for tests that call LoadPlanCommand._display_plan_details.
        Delegates to the function moved to plan_ui module.
        """
        display_plan_details(plan)
        
    def _refresh_agent_after_transition(self, current_mode) -> None:
        """
        Backward compatibility method for tests.
        Delegates to the function moved to planning_helpers module.
        """
        from coda_cli.core.commands.step_by_step.utils.planning_helpers import refresh_agent_after_transition
        refresh_agent_after_transition(current_mode)
