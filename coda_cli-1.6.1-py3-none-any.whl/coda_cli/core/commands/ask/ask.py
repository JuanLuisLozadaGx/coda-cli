from typing import List
from coda_cli.core.commands.base import Command

class AskCommand(Command):
    """Implementation of the /ask command to ask a question to the agent."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/ask"]
    
    def description(self) -> str:
        """Return command description."""
        return "Ask a question to the agent (⚠️ DEPRECATED)."
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return ["message"]
    
    def execute(self, args) -> bool:
        """
        Handles the '/ask' command to ask a question to the agent.

        Args:
            args (str): The arguments provided with the '/ask' command,
                        expected to contain a message.

        Returns:
            bool: True to continue CLI execution.
            
        Behavior:
            - Checks if files are selected
            - Displays a deprecation message as this command is no longer supported
            - Directs the user to use the main chat interface instead
        """
        # Check if files are selected
        if not self.cli.cli_state.selected_files:
            # Set flag to track that user attempted /ask without files
            print()
            print("\033[1;31m⚠️  DEPRECATED COMMAND\033[0m")
            print("Please select the relevant files first using the /add command,")
            print("then ask your question directly in the main chat interface.")
            print("The /ask command is no longer supported.")
            print()
            return True
        else:
            # Instead of prompting for input like the old version, show deprecation message
            print()
            print("\033[1;31m⚠️  DEPRECATED COMMAND\033[0m")
            print("The /ask command is no longer supported.")
            print("Please ask your question directly in the main chat interface.")
            print()
            return True