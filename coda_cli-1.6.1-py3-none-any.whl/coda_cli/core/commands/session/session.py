from typing import List
from loguru import logger

from coda_cli.core.commands.base import Command
from coda_cli.core.ui import display_interactive_session_list
from coda_cli.core.utils.utils import get_yes_no_input, load_session_and_update_ui

from coda_cli.core.commands.tools.utils import update_agent_tools, register_tool_dependencies


class SessionCommand(Command):
    """Implementation of the /session command to manage sessions."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/session", "/s"]
    
    def description(self) -> str:
        """Return command description."""
        return "Manage sessions (save, load, delete, rename)"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []
    
    def execute(self, args) -> bool:
        """
        Manage sessions (save, load, delete, rename).
        
        This command provides an interactive interface for session management operations:
        - List available sessions
        - Create a new session
        - Load an existing session
        - Delete a session
        - Rename a session
        - Save current session with a name
        
        Args:
            args: Command arguments (not used)
            
        Returns:
            bool: Always returns True to continue CLI execution
        """
        # The /sessions menu has a hard-dependency on the agent initialization, so we have to block until it's finished
        if not self.cli.wait_for_agent_initialization():
            # Finish CLI execution on agent initialization failure
            return False

        # Get current session info
        current_session_name = "None"
        current_session_id = None
        if self.cli.session_manager.current_session:
            current_session_name = self.cli.session_manager.current_session.name or "Unnamed"
            current_session_id = self.cli.session_manager.current_session.id
            # Save the current session before allowing any possible action on the sessions and the states
            self.cli.session_manager.save_session(
                shared_state=self.cli.shared_state,
                client_state=self.cli.cli_state,
                client_type=self.cli.cli_state.CLIENT_TYPE
            )

        # Display session management header
        print("\033[2J\033[H", end="")  # Clear screen
        print("\n\033[1;36mSession Management\033[0m")
        print("\033[1;36m=================\033[0m")
        print(f"Current session: \033[1;33m{current_session_name}\033[0m")
        print("\n\033[1mAvailable operations:\033[0m")
        
        # Main menu options
        operations = [
            "List available sessions",
            "Create a new session",
            "Load a session",
            "Delete a session",
            "Rename a session",
            "Save current session with a name"
        ]
        
        # Display operations
        for i, op in enumerate(operations, 1):
            print(f"  \033[1;36m{i}.\033[0m {op}")
        print("  \033[1;36mq.\033[0m Quit session management")
        
        # Get user choice
        while True:
            try:
                choice = input("\n\033[1mEnter choice: \033[0m").strip().lower()
                
                if choice == 'q':
                    return True
                    
                elif choice == '1':
                    # List available sessions
                    sessions = self.cli.session_manager.list_sessions()
                    if not sessions:
                        print("\033[1;33mNo saved sessions found.\033[0m")
                        return True
                    
                    # Define callback handlers - in this case we just want to view
                    callback_handlers = {
                        "view": lambda session_id: None  # Just view, no action
                    }
                    
                    # Display interactive session list
                    display_interactive_session_list(
                        sessions=sessions,
                        current_session_id=current_session_id,
                        header_text="Available Sessions",
                        page_size=5,
                        allow_detailed_view=True,
                        show_create_option=False,
                        actions=["view"],
                        callback_handlers=callback_handlers
                    )
                    
                elif choice == '2':
                    # Create a new session
                    name = input("Enter a name for the new session (leave empty for default): ").strip()
                    name = name if name else None
                    
                    # Create a new session
                    self.cli._create_new_session(name)
                    print(f"\033[1;32mCreated new session{' ' + name if name else ''}.\033[0m")
                
                elif choice == '3':
                    # Load a session
                    sessions = self.cli.session_manager.list_sessions()
                    if not sessions:
                        print("\033[1;33mNo saved sessions found.\033[0m")
                        return True
                    
                    # Define callback handlers
                    callback_handlers = {
                        "load": lambda session_id: self.cli._try_load_session(session_id, create_new_if_locked=False)
                    }
                    
                    # Display interactive session list
                    session_data = display_interactive_session_list(
                        sessions=sessions,
                        current_session_id=current_session_id,
                        header_text="Load Session",
                        page_size=5,
                        allow_detailed_view=True,
                        show_create_option=False,
                        actions=["load"],
                        callback_handlers=callback_handlers
                    )

                    if session_data is not None and session_data.get("id"):
                        session_id = session_data.get("id")
                        # Update the agent tools for the new session
                        register_tool_dependencies(self.cli)
                        update_agent_tools(self.cli)
                
                elif choice == '4':
                    # Delete a session
                    sessions = self.cli.session_manager.list_sessions()
                    if not sessions:
                        print("\033[1;33mNo saved sessions found.\033[0m")
                        return True
                    
                    # Define custom delete handler
                    def delete_session_handler(session_id):
                        # Find the session name
                        session_name = "Unnamed Session"
                        for session in sessions:
                            if session.get("id") == session_id:
                                # Get name from name_info if available, otherwise fall back to name
                                if "name_info" in session:
                                    session_name = session["name_info"].get("current", "Unnamed")
                                else:
                                    session_name = session.get("name", "Unnamed")
                                break
                        
                        # Check if this is the current session
                        if session_id == current_session_id:
                            print(f"\033[1;31mCannot delete the current active session.\033[0m")
                            print("Please switch to another session first using option 3 (Load an existing session),")
                            print("or create a new session using option 2 before attempting to delete this session.")
                            return False
                        
                        # Confirm deletion
                        prompt = f"Are you sure you want to delete session '{session_name}'?"
                        confirm = get_yes_no_input(prompt, default="n")
                        if confirm:
                            if self.cli.session_manager.delete_session(session_id):
                                print(f"\033[1;32mSession '{session_name}' deleted.\033[0m")
                                return True
                            else:
                                print(f"\033[1;31mCould not delete session '{session_name}'. It may be in use by another process.\033[0m")
                                return False
                        return False
                    
                    # Define callback handlers
                    callback_handlers = {
                        "delete": delete_session_handler
                    }
                    
                    # Display interactive session list
                    display_interactive_session_list(
                        sessions=sessions,
                        current_session_id=current_session_id,
                        header_text="Delete Session",
                        page_size=5,
                        allow_detailed_view=True,
                        show_create_option=False,
                        actions=["delete"],
                        callback_handlers=callback_handlers
                    )
                
                elif choice == '5':
                    # Rename a session
                    sessions = self.cli.session_manager.list_sessions()
                    if not sessions:
                        print("\033[1;33mNo saved sessions found.\033[0m")
                        return True
                    
                    # Define custom rename handler
                    def rename_session_handler(session_id):
                        # Find the session name
                        old_name = "Unnamed Session"
                        for session in sessions:
                            if session.get("id") == session_id:
                                # Get name from name_info if available, otherwise fall back to name
                                if "name_info" in session:
                                    old_name = session["name_info"].get("current", "Unnamed")
                                else:
                                    old_name = session.get("name", "Unnamed")
                                break
                        
                        # Get new name
                        new_name = input(f"Enter new name for session '{old_name}': ").strip()
                        if new_name:
                            if self.cli.session_manager.rename_session(session_id, new_name, rename_method="manual"):
                                print(f"\033[1;32mSession renamed from '{old_name}' to '{new_name}' (manual).\033[0m")
                                logger.info(f"Session manually renamed from '{old_name}' to '{new_name}'")
                                return True
                            else:
                                print(f"\033[1;31mCould not rename session. It may be in use by another process.\033[0m")
                                return False
                        return False
                    
                    # Define callback handlers
                    callback_handlers = {
                        "rename": rename_session_handler
                    }
                    
                    # Display interactive session list
                    display_interactive_session_list(
                        sessions=sessions,
                        current_session_id=current_session_id,
                        header_text="Rename Session",
                        page_size=5,
                        allow_detailed_view=True,
                        show_create_option=False,
                        actions=["rename"],
                        callback_handlers=callback_handlers
                    )
                
                elif choice == '6':
                    # Save current session with a name
                    current_name = self.cli.session_manager.current_session.name if self.cli.session_manager.current_session else None
                    prompt = f"Enter a name for the session (current: {current_name}): " if current_name else "Enter a name for the session: "
                    
                    name = input(prompt).strip()
                    if name:
                        # Update the session name if it's different
                        if self.cli.session_manager.current_session and name != self.cli.session_manager.current_session.name:
                            # Use set_name with "manual" method to ensure proper tracking of name changes
                            old_name = self.cli.session_manager.current_session.name
                            success = self.cli.session_manager.current_session.set_name(name, "manual")
                            if success:
                                logger.info(f"Session manually renamed from '{old_name}' to '{name}'")
                        
                        # Save the session
                        self.cli.session_manager.save_session(
                            shared_state=self.cli.shared_state,
                            client_state=self.cli.cli_state,
                            client_type=self.cli.cli_state.CLIENT_TYPE
                        )
                        
                        print(f"\033[1;32mSession saved as '{name}'.\033[0m")
                
                else:
                    print("Invalid choice. Please try again.")
                    continue
                
                return True
                
            except Exception as e:
                logger.error(f"Error on session management: {e}")
                print(f"\033[1;31mError: {e}\033[0m")
                return True