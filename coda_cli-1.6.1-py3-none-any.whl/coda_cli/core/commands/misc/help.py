from typing import List
from coda_cli.core.commands.base import Command
from coda_cli.core.commands.misc.ui import print_help


class HelpCommand(Command):
    """Implementation of the /help command to display CLI command help."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/help", "/h"]
    
    def description(self) -> str:
        """Return command description."""
        return "Show this help message"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []
    
    def execute(self, args) -> bool:
        """
        Displays the help information for the CLI commands.

        Args:
            args (str): The arguments provided with the '/help' command (not used)

        Returns:
            bool: Always returns True to indicate the command executed successfully.
        """
        print_help(self.cli.commands)
        return True
