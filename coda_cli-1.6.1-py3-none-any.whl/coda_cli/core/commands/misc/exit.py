from typing import List
from loguru import logger
from coda_cli.core.commands.base import Command
from coda_cli.core import ui


class ExitCommand(Command):
    """Implementation of the /exit command to exit the CLI application."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/exit", "/quit", "/q"]
    
    def description(self) -> str:
        """Return command description."""
        return "Exit the application"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []
    
    def execute(self, args) -> bool:
        """
        Handles the '/exit' command to exit the CLI application.

        Args:
            args (str): The arguments provided with the '/exit' command (not used)

        Returns:
            bool: Always returns False to exit CLI execution
        """
        # If there's a rename thread running, wait for it to complete (with a timeout)
        if hasattr(self.cli, 'session_manager') and self.cli.session_manager and self.cli.session_manager.rename_thread and self.cli.session_manager.rename_thread.is_alive():
            logger.info("Waiting for session rename to complete before exiting (max 2 seconds)...")
            self.cli.session_manager.rename_thread.join(timeout=2.0)
        
        # Check if the session was renamed during this session
        rename_info = self.cli._check_session_rename_status()
        # Only show the rename message if it was an automatic rename, not a manual one
        if (rename_info["old_name"] and rename_info["new_name"] and
            rename_info["old_name"] != rename_info["new_name"] and
            rename_info.get("rename_method") != "manual"):
            print(f"\033[1;32mSession was renamed from '{rename_info['old_name']}' to '{rename_info['new_name']}' (auto)\033[0m")
            print()
            
        ui.goodbye()
        return False




