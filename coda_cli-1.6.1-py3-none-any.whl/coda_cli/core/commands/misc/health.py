from typing import List
from coda_cli.core.commands.base import Command
from coda_cli.core.ui.animation import create_loading_animation
from coda_cli.core.commands.misc.ui import display_health_status


class HealthCommand(Command):
    """Implementation of the /health command to check GEAI service health status."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/health"]
    
    def description(self) -> str:
        """Return command description."""
        return "Check and display the health status of the GEAI service"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []
    
    def execute(self, args) -> bool:
        """
        Handles the '/health' command to check and display GEAI service health.

        Args:
            args (str): The arguments provided with the '/health' command (not used)

        Returns:
            bool: Always returns True to continue CLI execution
        """
        print("Checking GEAI service health...")
        
        # Create the animation functions
        start_loading, stop_loading = create_loading_animation()
        
        try:
            # Start the loading animation
            start_loading()
            
            # Force a fresh health check
            health_status = self.cli.shared_state.geai_client.check_health(force_refresh=True)
            
            # Stop the loading animation
            stop_loading()

            # Display the health status using the utility function
            display_health_status(health_status)
                    
        except Exception as e:
            # Stop the loading animation
            stop_loading()
            print(f"\n❌ Error checking health status: {e}")
            
        return True
