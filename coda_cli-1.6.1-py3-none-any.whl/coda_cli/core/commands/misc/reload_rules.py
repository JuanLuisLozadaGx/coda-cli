from typing import Any, Dict, List
from loguru import logger
from prompt_toolkit.formatted_text import HTML
from coda_cli.core import ui
from coda_cli.core.commands.base import Command


def _format_rules_source(rules: Dict[str, Any]) -> str:
    """Build a human-friendly source label for loaded rules.

    Args:
        rules: Rules metadata dictionary returned by shared state loading.

    Returns:
        String describing the source file(s) used for rules content.
    """
    paths = rules.get("paths") or []
    if paths:
        if len(paths) == 1:
            return paths[0]
        return f"{len(paths)} files (latest: {paths[-1]})"
    return rules.get("path") or "unknown path"

class ReloadRulesCommand(Command):
    """Implementation of the /reload-rules command to reload user-defined rules."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/reload-rules", '/rr']
    
    def description(self) -> str:
        """Return command description."""
        return "Reload user-defined rules from AGENTS.md hierarchy"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return ["path"]
    
    def execute(self, args) -> bool:
        """
        Handles the '/reload-rules' command to reload user-defined rules from AGENTS.md.

        Args:
            args (str): Optional path to the rules file

        Returns:
            bool: True to continue CLI execution
            
        Behavior:
            - Parses arguments to extract the optional path
            - Uses the SharedState method to load user-defined rules
            - Displays appropriate UI messages based on the status
            - Updates the single agent's system prompt if it exists
            - Saves the session
        """
        # Parse arguments
        path = args.strip() if args.strip() else None
        
        # Remove any single quotes that might be added when dragging and dropping files
        if path and ((path.startswith("'") and path.endswith("'")) or (path.startswith('"') and path.endswith('"'))):
            path = path[1:-1]
        
        # Use the SharedState method to load user-defined rules
        rules = self.cli.shared_state.load_user_defined_rules(path)
        
        # Display appropriate UI messages based on the status
        if rules['status'] in ['success', 'truncated']:
            source = _format_rules_source(rules)
            # Display warning in UI if content was truncated
            if rules['was_truncated']:
                ui.print_formatted_text(HTML(
                    f'<ansibrightred>Warning: Rules file exceeded size limits '
                    f'({rules["char_count"]} chars / {rules.get("line_count", 0)} lines) and was truncated.</ansibrightred>'
                ))

            # If new rules are provided, we need to block until the agent is initialized in order to later update the prompt
            if not self.cli.wait_for_agent_initialization():
                # Finish CLI execution on agent initialization failure
                return False

            # Update the single agent's system prompt if it exists
            if hasattr(self.cli.shared_state, 'main_agent'):
                # Update the system prompt with the new rules using instance method
                self.cli.shared_state.main_agent.update_system_prompt(user_defined_rules=rules)
                logger.info(f"Single agent (ID {self.cli.shared_state.main_agent.id}) system prompt updated with the new rules")

            # Display success message
            ui.print_formatted_text(HTML(
                f'<ansibrightgreen>Successfully reloaded user-defined rules from {source}</ansibrightgreen>'
            ))
        elif rules['status'] == 'empty':
            ui.print_formatted_text(HTML(
                f'<ansiyellow>Rules file at {_format_rules_source(rules)} is empty.</ansiyellow>'
            ))
        elif rules['status'] == 'not_found':
            ui.print_formatted_text(HTML(
                f'<ansiyellow>No AGENTS.md rules found at {_format_rules_source(rules)}</ansiyellow>'
            ))
        else:  # error
            ui.print_formatted_text(HTML(
                f'<ansibrightred>Error loading rules from {_format_rules_source(rules)}: {rules.get("error", "Unknown error")}</ansibrightred>'
            ))

        for warning in rules.get('warnings', []):
            ui.print_formatted_text(HTML(
                f'<ansiyellow>{warning}</ansiyellow>'
            ))

        # Save the session (rules content won't be serialized)
        self.cli.session_manager.save_session(
            shared_state=self.cli.shared_state,
            client_state=self.cli.cli_state,
            client_type=self.cli.cli_state.CLIENT_TYPE
        )
        
        return True
