from typing import Dict, Tuple, Any
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit import print_formatted_text
from coda_cli.core.ui import format_iso_timestamp


def display_health_status(health_status: dict) -> None:
    """
    Display the health status of the GEAI service.

    Args:
        health_status (dict): A dictionary containing the health status information.
            Expected keys:
            - "is_healthy" (bool): Whether the service is healthy.
            - "timestamp" (str): The timestamp of the health check in ISO 8601 format.
            - "error" (str): An error message if the service is not healthy.
    """
    if health_status["is_healthy"]:
        print(f"\n✅ GEAI service is healthy and running!")
        if health_status.get("timestamp"):
            human_readable_time = format_iso_timestamp(health_status["timestamp"])
            print(f"   Timestamp: {human_readable_time}")
    else:
        print(f"\n❌ GEAI service is not healthy")
        if health_status.get("timestamp"):
            human_readable_time = format_iso_timestamp(health_status["timestamp"])
            print(f"   Timestamp: {human_readable_time}")
        if health_status.get("error"):
            print(f"   Error: {health_status['error']}")



def print_help(commands: Dict[Tuple[str, ...], Dict[str, Any]]) -> None:
    """
    Display all available commands and their descriptions in the CLI.

    Args:
        commands (Dict[Tuple[str, ...], Dict[str, Any]]): A dictionary where:
            - Keys are tuples of command aliases.
            - Values are dictionaries containing 'method', 'description', and 'arguments'.
    """
    print_formatted_text(HTML('\n<ansibold>Available commands:</ansibold>'))

    # Group commands by their descriptions and arguments
    grouped_commands = {}
    for aliases, command_info in commands.items():
        description = command_info["description"]
        arguments = command_info.get("arguments", [])
        if description not in grouped_commands:
            grouped_commands[description] = {"aliases": [], "arguments": arguments}
        grouped_commands[description]["aliases"].extend(aliases)

    # Helper function to calculate visible length (accounting for HTML entities)
    def visible_length(text):
        # Replace HTML entities with their visible equivalents
        visible_text = text.replace("&lt;", "<").replace("&gt;", ">")
        return len(visible_text)
    
    # Calculate the maximum visible length of grouped commands
    max_cmd_length = max(
        visible_length(", ".join(cmd_info["aliases"]) + " " + " ".join(f"&lt;{arg}&gt;" for arg in cmd_info["arguments"]))
        for cmd_info in grouped_commands.values()
    )
    
    # Print each group of commands with consistent alignment
    for description, cmd_info in grouped_commands.items():
        # Combine commands into a single string
        combined_cmds = ", ".join(cmd_info["aliases"])
        # Format arguments as &lt;arg1&gt; &lt;arg2&gt; ...
        formatted_args = " ".join(f"&lt;{arg}&gt;" for arg in cmd_info["arguments"])
        # Combine commands and arguments
        command_with_args = f"{combined_cmds} {formatted_args}".strip()

        # Calculate padding based on visible length
        padding = max_cmd_length - visible_length(command_with_args) + 5

        # Create the HTML string with proper spacing
        html_string = f'  <ansibrightblue>{command_with_args}</ansibrightblue>{" " * padding} - {description}'
        print_formatted_text(HTML(html_string))

    print()