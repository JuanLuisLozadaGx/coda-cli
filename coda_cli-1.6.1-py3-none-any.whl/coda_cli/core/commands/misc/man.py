import os
import shutil
import importlib.resources
from typing import List
from coda_cli.core.commands.base import Command


class ManCommand(Command):
    """Implementation of the /man command to display the manual page."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/man"]
    
    def description(self) -> str:
        """Return command description."""
        return "Display the manual page"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []
    
    def execute(self, args) -> bool:
        """
        Displays the detailed manual for CODA CLI.

        Opens the manual text in a pager (less) for convenient reading. If the pager is not available,
        the content is printed directly to stdout.
        
        Args:
            args (str): The arguments provided with the '/man' command (not used)
            
        Returns:
            bool: True to continue the CLI loop.
        """
        # Get the manual file using importlib.resources.files (modern API)
        try:
            files = importlib.resources.files('coda_cli.core.resources')
            manual_file = files / 'manual.txt'
            
            # Use 'less' pager if available, otherwise print to standard output
            pager = shutil.which("less")
            if pager:
                # For pager, we need a real file path, so use as_file context manager
                with importlib.resources.as_file(manual_file) as manual_path:
                    # Pause the CLI and open the manual in the pager
                    os.system(f"{pager} {manual_path}")
            else:
                # Fallback: read the content directly and print to console
                try:
                    manual_content = manual_file.read_text(encoding="utf-8")
                    print(manual_content)
                except FileNotFoundError:
                    print("Manual file not found. Please ensure 'manual.txt' is installed.")
        except (ImportError, FileNotFoundError) as e:
            print(f"Manual file not found: {e}")
            print("Please ensure 'manual.txt' is installed in the coda_cli.core.resources package.")
        return True