from typing import List, Dict, Any
from abc import ABC, abstractmethod


class Command(ABC):
    """
    Base class for CLI commands that provides a consistent structure.

    Each command should define:
    - aliases: The command aliases (e.g., ["/foo", "/f"])
    - description: A human-readable description of what the command does
    - arguments: A list of argument names the command accepts
    - execute: The function that implements the command's behavior

    Args:
        cli: The CLI instance that's calling this command

    Returns:
        Dict[str, Any]: A dictionary containing command metadata
    """

    def __init__(self, cli = None):
        """
        Initialize the command a placeholder for the CLI instance.
        
        Args:
            cli: placeholder cli instance
        """
        self.cli = cli
    
    def get_metadata(self) -> Dict[str, Any]:
        """
        Returns the command metadata including aliases, description, arguments, and method.
        
        This method should be called by the CLI to register commands.
        
        Returns:
            Dict[str, Any]: A dictionary containing command metadata
        """
        return {
            "aliases": self.aliases(),
            "description": self.description(),
            "arguments": self.arguments(),
            "command_class": self.__class__
        }

    @abstractmethod
    def aliases(self) -> List[str]:
        """
        Get the command aliases.
        
        Returns:
            List[str]: A list of command aliases
        """
        raise NotImplementedError("Subclasses must implement aliases()")
    
    @abstractmethod
    def description(self) -> str:
        """
        Get the command description.
        
        Returns:
            str: A human-readable description of the command
        """
        raise NotImplementedError("Subclasses must implement description()")
    
    @abstractmethod
    def arguments(self) -> List[str]:
        """
        Get the command arguments.
        
        Returns:
            List[str]: Command arguments
        """
        raise NotImplementedError("Subclasses must implement arguments()")
    
    @abstractmethod
    def execute(self, args) -> bool:
        """
        Execute the command.
        
        Args:
            args: The arguments passed to the command
            
        Returns:
            bool: True to continue CLI execution, False to exit
        """
        raise NotImplementedError("Subclasses must implement execute()")
