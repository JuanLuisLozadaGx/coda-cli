# Commands Module

The Commands module is the core of Coda-CLI's user interface, implementing all available CLI commands and providing a consistent structure for command execution.

## Overview

Commands in Coda-CLI follow a plugin-like architecture where each command:
1. Inherits from the base `Command` class
2. Implements required methods for metadata and execution
3. Is registered with the command registry

## Architecture

```mermaid
flowchart TD
    User(User Input) --> CLI["CLI (_handle_command)"]
    CLI --> CheckCommand{Is Command?}
    CheckCommand -->|Yes| CommandRegistry[Command Registry]
    CheckCommand -->|No| Agent[Agent Handler]
    
    CommandRegistry --> CommandInstance[Command Instance]
    CommandInstance --> Execute[Execute Command]
    Execute --> |Return True/False| CLI
    
    subgraph "Command Module"
        CommandRegistry
        BaseCommand[Command Base Class]
        CommandInstance -.-> BaseCommand
        
        subgraph "Command Categories"
            AddCmd[add]
            AskCmd[ask]
            PrefCmd[preferences]
            RecCmd[recipes]
            SessCmd[session]
            SwModCmd[switch_model]
            ToolsCmd[tools]
            MiscCmd[misc]
        end
        
        CommandRegistry --> AddCmd & AskCmd & PrefCmd & RecCmd & SessCmd & SwModCmd & ToolsCmd & MiscCmd
    end
    
    Agent --> |Return True/False| CLI
```

## Key Components

### Base Command Class

The `Command` abstract base class (`base.py`) defines the interface that all commands must implement. It requires methods for retrieving command aliases, descriptions, argument definitions, and execution logic.

### Command Registry

The `registry.py` file handles command registration and dispatching. It maintains a registry of all available commands, maps command aliases to their implementations, and provides lookup functionality for command execution.

### Command Categories

Commands are organized into subdirectories by functionality:

- **add**: Commands for adding files to the context
  - Usage: `/add <filepath>` - Adds a file to the current context

- **ask**: Main interaction command for talking to the agent
  - Usage: Just type your query and press Enter

- **preferences**: User preferences management
  - Configure security levels, model settings, etc.

- **recipes**: Pre-defined AI recipe catalogs
  - Predefined templates for common coding tasks

- **session**: Session management commands
  - Save, load, and manage conversation sessions

- **switch_model**: Model selection functionality
  - Switch between different AI models

- **tools**: Agent tools management
  - Enable/disable specific agent capabilities

- **misc**: Miscellaneous commands
  - Help, exit, and other utility functions

## Creating New Commands

To create a new command:

1. Create a new class inheriting from `Command`
2. Implement the required methods for aliases, description, arguments, and execution
3. Register the command in the registry
4. Ensure proper access to CLI context is maintained

Commands are parsed and executed by the CLI's `_handle_command` method, which distinguishes between built-in commands (prefixed with `/`) and regular input that should be sent to the agent.