from typing import List

from coda_core.core.session.constants import MEMORY_KEY_MAIN

from coda_cli.core.commands.base import Command


class ClearCommand(Command):
    """Implementation of the /clear command to clear the conversation memory."""

    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/clear"]

    def description(self) -> str:
        """Return command description."""
        return "Clear the conversation memory"

    def arguments(self) -> List[str]:
        """Return command arguments."""
        return ["main"]
    
    def execute(self, args) -> bool:
        """
        Execute the /clear command.

        This command removes all stored conversation history from memory,
        effectively starting a fresh conversation while keeping the selected files.

        Args:
            args (str): The arguments provided with the '/clear' command. For now, this is ignored, but kept for future extensions.

        Returns:
            bool: True if the memory was cleared, False otherwise.
        """
        if self.cli.agent_handler.has_active_agent():
            # In order to avoid race conditions we finish the agent initialization before accessing memories
            self.cli.wait_for_agent_initialization()
            self.cli.shared_state.memories[MEMORY_KEY_MAIN].clear()
            print("Cleared main conversation memory.")

        # Auto-save if needed
        self.cli._auto_save_if_needed()
        
        return True