# How to Add Skills to Coda

## Quick Start

Skills are discovered from two locations:
- **Project-local**: `.coda/skills/` (in your working directory)
- **System-wide**: `~/.coda/skills/` (in your home directory)

**Note**: If a skill with the same name exists in both locations, the project-local skill takes precedence.

## Managing Skills

You can manage skills using direct commands:

```bash
⫸ /skills                          # Open interactive menu
⫸ /skills list                     # List available skills
⫸ /skills enable <skill-name>      # Enable a skill
⫸ /skills disable <skill-name>     # Disable a skill
⫸ /skills add https://github.com/organization/skills-repo       # Install skills from GitHub
⫸ /skills refresh                  # Detect manually added/removed skills
```

## How Skills Affect the System Prompt

**Enabled skills** are automatically included in the system prompt on every conversation turn. This means:
- When you **enable** a skill → it appears in the system prompt on your next message
- When you **disable** a skill → it's removed from the system prompt on your next message
- **Project-local skills** are always enabled automatically
- **Default skills** must be explicitly enabled

## Adding a Skill

### 1. Create the skill directory structure:

```bash
# For project-local skill
mkdir -p .coda/skills/my-skill
```

### 2. Create the skill file (skill.md or SKILL.md):

```bash
# Either lowercase
touch .coda/skills/my-skill/skill.md

# OR uppercase (both work)
touch .coda/skills/my-skill/SKILL.md
```

### 3. Add YAML frontmatter and content:

The skill file must start with YAML frontmatter containing:

**Required fields:**
- `name`: The skill name (used when calling with run_skill tool)
- `description`: Brief description (shown in skill listings and system prompt)

**Optional fields:**
- `execution.context`: Execution environment (`native`, `uv`, `docker`, `npm`) - default: `native`
- `execution.timeout`: Maximum execution time in seconds - default: `120`
- `execution.python`: Python version for uv/docker contexts (e.g., `"3.11"`)
- `execution.requirements`: Path to requirements.txt for uv context - default: `requirements.txt`
- `execution.docker_image`: Docker image for docker context (e.g., `python:3.11-slim`)
- `license`: License information

**Example with execution context:**

```markdown
---
name: my-skill
description: A brief description of what this skill does
execution:
  context: native  # or uv, docker, npm
  timeout: 120
license: Optional license information
---

# My Skill

Your detailed skill instructions go here...

## When to Use This Skill
- Use case 1
- Use case 2

## How to Use
1. Step 1
2. Step 2
```

**Example with UV virtual environment:**

```markdown
---
name: dataframe-generator
description: Generate pandas DataFrames with custom data
execution:
  context: uv
  timeout: 120
  python: "3.11"
  requirements: requirements.txt
---

# DataFrame Generator Skill

This skill creates sample pandas DataFrames in isolated Python environments.

## When to Use
- Create sample CSV files
- Prototype data structures
```

## Example: Adding a new skill

```bash
# 1. Create directory
mkdir -p .coda/skills/pdf

# 2. Copy your skill content
cp /path/to/your/pdf/SKILL.md .coda/skills/pdf/

# 3. (Optional) Copy supporting files
cp -r /path/to/your/pdf/scripts .coda/skills/pdf/
cp /path/to/your/pdf/LICENSE.txt .coda/skills/pdf/

# 4. Refresh to detect the new skill
⫸ /skills refresh
```

**Output:**
```
✔ Detected new skills: pdf
✔ System prompt updated
```

## Verifying Your Skill

Run the `/skills` command in coda-cli:

```
⫸ /skills
```

You should see your skill listed with its name, description, and status (enabled/disabled).

### Manual Skill Detection

If you manually copy/paste skill files into `.coda/skills/`, run the refresh command to detect them:

```bash
⫸ /skills refresh
```

This will:
- Scan for new skill directories
- Detect removed skills
- Update the agent's system prompt
- Display a summary of changes

## Using a Skill

Once a skill is added and enabled, the agent can use it with the `run_skill` tool:

```
Agent: I'll load the PDF skill to help with that.
[Calls run_skill(skill_name="pdf")]
```

Or you can reference it in your prompt:
```
⫸ Use the pdf skill to extract text from document.pdf
```

## Skill Directory Structure

A complete skill directory might look like:

```
.coda/skills/
└── my-skill/
    ├── SKILL.md          # Main skill file (required)
    ├── requirements.txt  # Python dependencies (optional, for uv context)
    ├── package.json      # Node.js dependencies (optional, for npm context)
    ├── Dockerfile        # Custom Docker setup (optional, for docker context)
    ├── LICENSE.txt       # License info (optional)
    ├── reference.md      # Additional docs (optional)
    ├── examples/         # Example files (optional)
    └── scripts/          # Executable scripts (optional)
        ├── run.sh        # Bash script
        ├── run.py        # Python script
        └── build.js      # Node.js script
```

## Current Skills in This Project

Run `/skills` to see all available skills, or check:
```bash
ls -la .coda/skills/
```

## Execution Contexts

Skills may be executed in different environments to ensure isolation and proper dependency management; therefore, the execution environment must be defined a priori by the user as well as the environment execution context and execution instructions.

## How Skills Are Executed

When you use a skill, the `run_skill` tool loads the skill definition and the coda-agent receives the instructions for executing the skill.
## Tips

1. **Keep descriptions concise**: They appear in the system prompt for enabled skills
2. **Use clear names**: The agent uses these to decide when to load a skill
3. **Include examples**: Help the agent understand when and how to use the skill
4. **Version control**: Add skills to your repo to share with your team
5. **Package defaults**: Use default skills as examples to create your own custom skills
6. **Enable selectively**: Only enable the skills you need to keep the system prompt focused
7. **Choose the right context**: Use `uv` for Python isolation, `docker` for complete isolation, `native` for simplicity
8. **Cross-platform considerations**: Use Python scripts instead of bash for Windows compatibility
9. **Manual file changes**: After copying/pasting skill files, run `/skills refresh` to detect them without restarting

