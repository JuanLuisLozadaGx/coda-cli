from typing import List, Optional

from coda_cli.core.commands.base import Command
from coda_cli.core.commands.skills.skills_ui import SkillsManager


# Command argument prefixes for direct skill operations
_ENABLE_PREFIX = "enable "
_DISABLE_PREFIX = "disable "
_ADD_PREFIX = "add "
_REFRESH_CMD = "refresh"
_LIST_CMD = "list"


class SkillsCommand(Command):
    """
    CLI command for managing agent skills.
    
    This command provides both direct subcommands (enable/disable) and an
    interactive menu for skill management. Skills are reusable task templates
    that help the agent complete complex workflows.
    
    Examples:
        /skills                         - Opens interactive skill management menu
        /skills enable pdf              - Enables the 'pdf' skill
        /skills disable pdf             - Disables the 'pdf' skill
        /skills add vercel-labs/agent-skills  - Installs skills from GitHub
        /skills refresh                  - Detects manually added/removed skills
        /sk                             - Alias for /skills
    """
    
    def aliases(self) -> List[str]:
        """
        Return the command aliases.
        
        Returns:
            List of command trigger strings including primary (/skills) and shorthand (/sk).
        """
        return ["/skills", "/sk"]
    
    def description(self) -> str:
        """
        Return the command description shown in help menus.
        
        Returns:
            Human-readable description of the command's purpose.
        """
        return "Manage available skills with interactive menu"
    
    def arguments(self) -> List[str]:
        """
        Return the list of accepted argument patterns.
        
        Returns:
            List of argument format strings for documentation.
        """
        return ["enable [skill-name]|disable [skill-name]|add [github-repo|local-path]|list|refresh"]

    def execute(self, args: Optional[str]) -> bool:
        """
        Execute the skills command with the given arguments.
        
        Supports five modes:
        - No arguments: Opens the interactive skill management menu
        - "enable <name>": Directly enables a skill by name
        - "disable <name>": Directly disables a skill by name
        - "add <repo|path>": Installs skills from GitHub or local path
        - "refresh": Detects manually added/removed skills
        - "list": Displays the same list as the interactive menu

        Args:
        args: Optional command arguments string.
            
        Returns:
            True to continue CLI loop, False would exit (currently always True).
        """
        if not self.cli.wait_for_agent_initialization():
            return False
        
        args_str = args.strip() if args else ""
        manager = SkillsManager(self.cli)
        
        if args_str.startswith(_ENABLE_PREFIX):
            skill_name = args_str[len(_ENABLE_PREFIX):].strip()
            if not skill_name:
                print(f"\033[1;31mError: Please specify a skill name\033[0m")
                manager.show_usage_help()
                return True
            return manager.enable_skill(skill_name)
        
        if args_str.startswith(_DISABLE_PREFIX):
            skill_name = args_str[len(_DISABLE_PREFIX):].strip()
            if not skill_name:
                print(f"\033[1;31mError: Please specify a skill name\033[0m")
                manager.show_usage_help()
                return True
            return manager.disable_skill(skill_name)
        
        if args_str.startswith(_ADD_PREFIX):
            repo_input = args_str[len(_ADD_PREFIX):].strip()
            if not repo_input:
                print("\033[1;31mPlease specify a GitHub repository or local path for the add command.\033[0m")
                manager.show_usage_help()
                return True
            return manager.install_from_github_cli(repo_input)
        
        if args_str == _REFRESH_CMD:
            return manager.refresh_skills()
        
        if args_str == _LIST_CMD:
            return manager.list_skills()
        
        if args_str == "":
            return manager.show_main_menu()

        # Unknown subcommand
        print(f"\033[1;31mUnknown subcommand: {args_str}\033[0m")
        manager.show_usage_help()
        return True
