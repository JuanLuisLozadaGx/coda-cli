from typing import TYPE_CHECKING, List, Optional
import re

from loguru import logger
from git import Repo
from coda_core.core.utils.skill_loader import SkillInfo, SkillLoader
from coda_core.core.utils.github_skill_installer import GitHubSkillInstaller
from coda_core.core.utils.skill_constants import SKILL_FORMAT_TEMPLATE
from coda_core.core.agents.manager import AgentManager

from coda_cli.core.ui.core import Colors
from coda_cli.core import ui


if TYPE_CHECKING:
    from coda_cli.core.cli import CLI


_ACTION_ENABLED = "enabled"
_ACTION_DISABLED = "disabled"
_ACTION_REMOVED = "removed"


class SkillsManager:
    """
    Manages skills via a menu-based interface.
    
    This class provides an interactive terminal UI for viewing and managing
    agent skills. It integrates with the SkillLoader from coda_core to
    discover, enable, and disable skills.
    
    Attributes:
        cli: Reference to the main CLI instance for agent access.
        skill_loader: SkillLoader instance for skill discovery and management.
        MAX_DESCRIPTION_LENGTH: Maximum characters for skill descriptions in lists.
    """
    
    MAX_DESCRIPTION_LENGTH: int = 100
    
    def __init__(self, cli: "CLI") -> None:
        """
        Initialize the SkillsManager.
        
        Args:
            cli: The CLI instance providing access to agent and system state.
        """
        self.cli = cli
        session_id = self._get_session_id()
        self.skill_loader = SkillLoader(session_id=session_id)
    
    def _get_session_id(self) -> str:
        """
        Get the current session ID from the CLI session manager.
        
        Returns:
            Session ID string, or "default" if no session is active.
        """
        if hasattr(self.cli, 'session_manager') and self.cli.session_manager:
            if hasattr(self.cli.session_manager, 'current_session') and self.cli.session_manager.current_session:
                return self.cli.session_manager.current_session.id
        return "default"
    
    def _truncate_description(self, description: str, max_length: Optional[int] = None) -> str:
        """
        Truncate a description string to fit display constraints.
        
        Args:
            description: The full description text.
            max_length: Maximum allowed length. Defaults to MAX_DESCRIPTION_LENGTH.
            
        Returns:
            The truncated description with ellipsis if needed.
        """
        max_length = max_length or self.MAX_DESCRIPTION_LENGTH
        if len(description) <= max_length:
            return description
        return description[:max_length - 3].rstrip() + "..."
    
    def _print_menu_header(self, title: str) -> None:
        """Print a menu header without clearing the screen."""
        print(f"\n{Colors.CYAN}{'='*60}{Colors.RESET}")
        print(f"{Colors.CYAN}{title:^60}{Colors.RESET}")
        print(f"{Colors.CYAN}{'='*60}{Colors.RESET}\n")
    
    def _display_format_errors(self) -> None:
        """Display format validation errors for malformed skills."""
        format_errors = self.skill_loader.get_format_errors()
        
        if not format_errors:
            return
        
        print(f"\n{Colors.YELLOW}{'='*60}{Colors.RESET}")
        print(f"{Colors.YELLOW}⚠️  SKILL FORMAT WARNINGS{Colors.RESET}")
        print(f"{Colors.YELLOW}{'='*60}{Colors.RESET}\n")
        
        print(f"{Colors.YELLOW}{len(format_errors)} skill(s) found with invalid format:{Colors.RESET}\n")
        
        for error in format_errors:
            print(f"{Colors.RED}• {error.skill_path}{Colors.RESET}")
            print(f"  Issue: {error.issue}\n")
        
        print(f"{Colors.CYAN}{'='*60}{Colors.RESET}")
        print(f"{Colors.CYAN}CORRECT SKILL FORMAT:{Colors.RESET}")
        print(f"{Colors.CYAN}{'='*60}{Colors.RESET}")
        print(SKILL_FORMAT_TEMPLATE)
        print(f"{Colors.CYAN}{'='*60}{Colors.RESET}\n")
    
    def _refresh_and_update(self) -> None:
        """
        Manually refresh skill discovery and update agent's system prompt.
        
        This is useful when skills have been manually added or removed from
        the .coda/skills/ directory outside of the CLI.
        """
        self._print_menu_header("Refreshing Skills")
        
        # Get current state before refresh
        all_skills_before = self.skill_loader.discover_skills(include_disabled=True)
        skills_before = {s.name for s in all_skills_before}
        
        # Force re-scan of skill directories (bypass cache)
        all_skills_after = self.skill_loader.discover_skills(include_disabled=True, force_refresh=True)
        skills_after = {s.name for s in all_skills_after}
        
        # Detect changes
        added = skills_after - skills_before
        removed = skills_before - skills_after
        
        if added:
            print(f"{Colors.GREEN}✔ Detected new skills:{Colors.RESET}")
            for skill_name in sorted(added):
                print(f"  • {skill_name}")
            print()
        
        if removed:
            print(f"{Colors.YELLOW}⚠ Detected removed skills:{Colors.RESET}")
            for skill_name in sorted(removed):
                print(f"  • {skill_name}")
            print()
        
        # Update system prompt to reflect current state
        self._update_system_prompt()
        self._refresh_skill_completer()
        
        enabled_count = len([s for s in all_skills_after if s.enabled])
        total_count = len(all_skills_after)
        
        print(f"{Colors.GREEN}✔ Refresh complete!{Colors.RESET}")
        print(f"\nCurrent state: {Colors.GREEN}{enabled_count}{Colors.RESET} / {total_count} skills enabled")
        print(f"{Colors.DIM}Agent's system prompt has been updated.{Colors.RESET}")
        
        input("\nPress Enter to continue...")
    
    def _update_system_prompt(self) -> None:
        """
        Update the agent's system prompt after skill state changes.
        
        This ensures the agent is aware of newly enabled or disabled skills
        in its next interaction.
        """
        try:
            if hasattr(self.cli, 'agent_handler') and self.cli.agent_handler.has_active_agent():
                agent = self.cli.agent_handler.get_active_agent()
                agent.update_system_prompt()
                logger.debug("Updated system prompt after skill change")
        except Exception as e:
            logger.warning(f"Could not update system prompt: {e}")
    
    def _refresh_skill_completer(self) -> None:
        """
        Refresh the skill autocompleter after skill state changes.
        
        This ensures the autocompleter immediately reflects the current state
        of enabled/disabled/removed skills, so users don't see stale suggestions.
        """
        try:
            if hasattr(self.cli, 'skill_completer') and self.cli.skill_completer is not None:
                self.cli.skill_completer.refresh()
                logger.debug("Refreshed skill autocompleter after skill change")
        except Exception as e:
            logger.warning(f"Could not refresh skill autocompleter: {e}")
    
    def _inject_skill_change_notification(self, skill_name: str, action: str) -> None:
        """
        Inject a context message into the agent's memory about skill changes.
        
        This helps the agent understand that a skill has been enabled or disabled
        mid-conversation.
        
        Args:
            skill_name: Name of the skill that was changed.
            action: Either _ACTION_ENABLED, _ACTION_DISABLED, or _ACTION_REMOVED.
        """
        try:
            if not (hasattr(self.cli, 'agent_handler') and self.cli.agent_handler.has_active_agent()):
                return
                
            agent = self.cli.agent_handler.get_active_agent()
            
            if not (hasattr(agent, 'memory') and agent.memory):
                logger.debug("Agent has no memory to inject skill change notification")
                return
            
            context_message = self.skill_loader.generate_skill_change_notification(skill_name, action)
            if context_message is None:
                return
            
            agent.memory.add_assistant_message(context_message)
            logger.debug(f"Injected skill change notification into agent memory: {action} {skill_name}")
                
        except Exception as e:
            logger.warning(f"Could not inject skill change notification: {e}")

    def show_main_menu(self) -> bool:
        """
        Display the main skill management menu.
        
        Presents an interactive menu with options to:
        - List available skills
        - Enable skills
        - Disable skills
        - View help documentation
        
        Returns:
            True to continue CLI loop.
        """
        while True:
            # Get skill counts (force refresh to get latest state)
            all_skills = self.skill_loader.discover_skills(include_disabled=True, force_refresh=True)
            enabled_count = len([s for s in all_skills if s.enabled])
            total_count = len(all_skills)
            
            # Check for format errors
            format_errors = self.skill_loader.get_format_errors()
            error_count = len(format_errors)
            
            # Header (preserves terminal history - no clear_screen)
            print(f"\n{Colors.CYAN}╭── 🔧 Skill Management ────{Colors.RESET}")
            print(f"{Colors.CYAN}│{Colors.RESET} Skills enabled: {Colors.GREEN}{enabled_count}{Colors.RESET} / {total_count}")
            if error_count > 0:
                skill_word = "skill has format issue" if error_count == 1 else "skills have format issues"
                print(f"{Colors.CYAN}│{Colors.RESET} {Colors.YELLOW}⚠️  {error_count} {skill_word}{Colors.RESET}")
            print(f"{Colors.CYAN}╰──────────────────────────────{Colors.RESET}\n")
            
            # Menu options
            print(f"  {Colors.CYAN}1.{Colors.RESET} List available skills")
            print(f"  {Colors.CYAN}2.{Colors.RESET} Enable skills")
            print(f"  {Colors.CYAN}3.{Colors.RESET} Disable skills")
            print(f"  {Colors.CYAN}4.{Colors.RESET} Remove project skills")
            print(f"  {Colors.CYAN}5.{Colors.RESET} Install from GitHub")
            print(f"  {Colors.CYAN}6.{Colors.RESET} Refresh (detect manual changes)")
            print(f"  {Colors.CYAN}7.{Colors.RESET} Help & Quickstart")
            print(f"  {Colors.CYAN}8.{Colors.RESET} Create new skill with AI")
            print()
            print(f"  {Colors.CYAN}q.{Colors.RESET} Return to main interface")
            print()
            
            try:
                choice = input(f"{Colors.BOLD}Enter choice:{Colors.RESET} ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print()
                self._update_system_prompt()
                return True
            
            if choice == '':
                print(f"\n{Colors.YELLOW}Please select one of the options.{Colors.RESET}")
                input("\nPress Enter to continue...")
            elif choice == '1':
                self._list_skills()
            elif choice == '2':
                self._enable_skills_menu()
            elif choice == '3':
                self._disable_skills_menu()
            elif choice == '4':
                self._remove_skills_menu()
            elif choice == '5':
                self._install_from_github_menu()
            elif choice == '6':
                self._refresh_and_update()
            elif choice == '7':
                self._show_help()
            elif choice == '8':
                self._create_new_skill()
            elif choice == 'q':
                self._update_system_prompt()
                return True
            else:
                print(f"\n{Colors.RED}Invalid choice: {choice}{Colors.RESET}")
                input("\nPress Enter to continue...")
    
    def _display_skills_by_source(
        self,
        skills: List[SkillInfo],
        show_status: bool = True,
        start_index: int = 1
    ) -> List[SkillInfo]:
        """
        Display skills grouped by source (project, system, custom).
        
        Args:
            skills: List of SkillInfo objects to display.
            show_status: Whether to show enabled/disabled status indicators.
            start_index: Starting index for skill numbering.
            
        Returns:
            Flattened list of skills in display order for selection.
        """
        # Group skills by source
        project_skills = [s for s in skills if s.source == "project"]
        system_skills = [s for s in skills if s.source == "system"]
        other_skills = [s for s in skills if s.source not in ("project", "system")]
        
        skills_flat: List[SkillInfo] = []
        idx = start_index
        
        for source_name, source_skills, emoji in [
            ("Project Skills", project_skills, "📦"),
            ("System Skills", system_skills, "🌐"),
            ("Custom Skills", other_skills, "📚"),
        ]:
            if not source_skills:
                continue
                
            print(f"{Colors.BOLD}{emoji} {source_name}:{Colors.RESET}")
            for skill in source_skills:
                desc = self._truncate_description(skill.description)
                if show_status:
                    status = Colors.ENABLED if skill.enabled else Colors.DISABLED
                    print(f"  {status} {Colors.CYAN}{idx}.{Colors.RESET} {skill.name} - {Colors.GRAY}{desc}{Colors.RESET}")
                else:
                    print(f"  {Colors.CYAN}{idx}.{Colors.RESET} {skill.name} - {Colors.GRAY}{desc}{Colors.RESET}")
                skills_flat.append(skill)
                idx += 1
            print()
        
        return skills_flat
    
    def _list_skills(self) -> None:
        """Display all available skills with their enabled/disabled status."""
        # Removed clear_screen() to preserve terminal history
        
        print(f"\n{Colors.CYAN}Available Skills{Colors.RESET}")
        print(f"{Colors.CYAN}================{Colors.RESET}\n")
        
        all_skills = self.skill_loader.discover_skills(include_disabled=True)
        
        if not all_skills:
            print(f"{Colors.YELLOW}No skills found.{Colors.RESET}")
            print("\nSkills are discovered from:")
            print(f"  • {Colors.BOLD}.coda/skills{Colors.RESET} (project-local, in current working directory)")
            print(f"  • {Colors.BOLD}~/.coda/skills{Colors.RESET} (system-wide)")
            print("\nCreate a skill by adding a folder with a skill.md or SKILL.md file.")
            input("\nPress Enter to continue...")
            return
        
        self._display_skills_by_source(all_skills, show_status=True)
        
        # Display format errors if any malformed skills were found
        self._display_format_errors()
        
        print(f"{Colors.DIM}Use the 'run_skill' tool to load a skill's detailed instructions.{Colors.RESET}")
        input("\nPress Enter to continue...")
    
    def _enable_skills_menu(self) -> None:
        """Display menu to enable one or more currently disabled skills."""
        # Removed clear_screen() to preserve terminal history
        
        print(f"\n{Colors.CYAN}Enable Skills{Colors.RESET}")
        print(f"{Colors.CYAN}============={Colors.RESET}\n")
        
        all_skills = self.skill_loader.discover_skills(include_disabled=True)
        disabled_skills = [s for s in all_skills if not s.enabled]
        
        if not disabled_skills:
            print(f"{Colors.YELLOW}All skills are already enabled.{Colors.RESET}")
            input("\nPress Enter to continue...")
            return
        
        print(f"{Colors.BOLD}Disabled Skills:{Colors.RESET}\n")
        disabled_skills_flat = self._display_skills_by_source(disabled_skills, show_status=False)
        
        # Options
        print(f"{Colors.BOLD}Options:{Colors.RESET}")
        print(f"  {Colors.CYAN}a.{Colors.RESET} Enable all skills")
        print(f"  {Colors.CYAN}q.{Colors.RESET} Return to skill management menu")
        print()
        print(f"{Colors.DIM}(You can enter multiple numbers separated by commas, e.g., '1,3,5'){Colors.RESET}")
        
        try:
            choice = input(f"\n{Colors.BOLD}Enter choice(s):{Colors.RESET} ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        
        if choice in ('q', ''):
            return
        
        enabled_skills: List[str] = []
        
        if choice == 'a':
            # Enable all disabled skills
            for skill in disabled_skills_flat:
                if self.skill_loader.enable_skill(skill.name):
                    print(f"{Colors.GREEN}✔ Enabled: {skill.name}{Colors.RESET}")
                    enabled_skills.append(skill.name)
                else:
                    print(f"{Colors.RED}✗ Failed to enable: {skill.name}{Colors.RESET}")
        else:
            enabled_skills = self._process_skill_selection(
                choice, disabled_skills_flat, self.skill_loader.enable_skill, "Enabled"
            )
        
        # Update system prompt and inject notifications
        if enabled_skills:
            for skill_name in enabled_skills:
                self._inject_skill_change_notification(skill_name, _ACTION_ENABLED)
            self._update_system_prompt()
            self._refresh_skill_completer()
            print(f"\n{Colors.GREEN}✔ Enabled {len(enabled_skills)} skill(s){Colors.RESET}")
            print(f"{Colors.DIM}System prompt has been updated.{Colors.RESET}")
        
        input("\nPress Enter to continue...")
    
    def _disable_skills_menu(self) -> None:
        """Display menu to disable one or more currently enabled skills."""
        # Removed clear_screen() to preserve terminal history
        
        print(f"\n{Colors.CYAN}Disable Skills{Colors.RESET}")
        print(f"{Colors.CYAN}=============={Colors.RESET}\n")
        
        all_skills = self.skill_loader.discover_skills(include_disabled=True)
        enabled_skills = [s for s in all_skills if s.enabled]
        
        if not enabled_skills:
            print(f"{Colors.YELLOW}All skills are already disabled.{Colors.RESET}")
            input("\nPress Enter to continue...")
            return
        
        print(f"{Colors.BOLD}Enabled Skills:{Colors.RESET}\n")
        enabled_skills_flat = self._display_skills_by_source(enabled_skills, show_status=False)
        
        # Options
        print(f"{Colors.BOLD}Options:{Colors.RESET}")
        print(f"  {Colors.CYAN}a.{Colors.RESET} Disable all skills")
        print(f"  {Colors.CYAN}q.{Colors.RESET} Return to skill management menu")
        print()
        print(f"{Colors.DIM}(You can enter multiple numbers separated by commas, e.g., '1,3,5'){Colors.RESET}")
        
        try:
            choice = input(f"\n{Colors.BOLD}Enter choice(s):{Colors.RESET} ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        
        if choice in ('q', ''):
            return
        
        disabled_skills: List[str] = []
        
        if choice == 'a':
            # Disable all enabled skills
            for skill in enabled_skills_flat:
                if self.skill_loader.disable_skill(skill.name):
                    print(f"{Colors.YELLOW}○ Disabled: {skill.name}{Colors.RESET}")
                    disabled_skills.append(skill.name)
                else:
                    print(f"{Colors.RED}✗ Failed to disable: {skill.name}{Colors.RESET}")
        else:
            disabled_skills = self._process_skill_selection(
                choice, enabled_skills_flat, self.skill_loader.disable_skill, "Disabled"
            )
        
        # Update system prompt and inject notifications
        if disabled_skills:
            for skill_name in disabled_skills:
                self._inject_skill_change_notification(skill_name, _ACTION_DISABLED)
            self._update_system_prompt()
            self._refresh_skill_completer()
            print(f"\n{Colors.YELLOW}○ Disabled {len(disabled_skills)} skill(s){Colors.RESET}")
            print(f"{Colors.DIM}System prompt has been updated.{Colors.RESET}")
        
        input("\nPress Enter to continue...")
    
    def _remove_skills_menu(self) -> None:
        """Display menu to remove project-local skills only."""
        # Removed clear_screen() to preserve terminal history
        
        print(f"\n{Colors.CYAN}Remove Project Skills{Colors.RESET}")
        print(f"{Colors.CYAN}====================={Colors.RESET}\n")
        print(f"{Colors.YELLOW}⚠️  Note: Only project-local skills can be removed (permanently deleted).{Colors.RESET}")
        print(f"{Colors.YELLOW}          To disable system-wide skills, use option 3 (Disable skills).{Colors.RESET}\n")
        
        all_skills = self.skill_loader.discover_skills(include_disabled=True)
        project_skills = [s for s in all_skills if s.source == "project"]
        
        if not project_skills:
            print(f"{Colors.YELLOW}No project-local skills found.{Colors.RESET}")
            print(f"\n{Colors.DIM}Project skills are located in .coda/skills/ in your working directory.{Colors.RESET}")
            input("\nPress Enter to continue...")
            return
        
        print(f"{Colors.BOLD}📦 Project Skills:{Colors.RESET}\n")
        skills_flat = []
        for idx, skill in enumerate(project_skills, 1):
            desc = self._truncate_description(skill.description)
            print(f"  {Colors.CYAN}{idx}.{Colors.RESET} {skill.name} - {Colors.GRAY}{desc}{Colors.RESET}")
            skills_flat.append(skill)
        
        # Options
        print(f"{Colors.BOLD}Options:{Colors.RESET}")
        print(f"  {Colors.CYAN}q.{Colors.RESET} Return to skill management menu")
        print()
        print(f"{Colors.DIM}(You can enter multiple numbers separated by commas, e.g., '1,3,5'){Colors.RESET}")
        
        try:
            choice = input(f"\n{Colors.BOLD}Select skills to remove:{Colors.RESET} ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        
        if choice in ('q', ''):
            return
        
        # Parse selection
        skills_to_remove: List[SkillInfo] = []
        try:
            indices = [int(idx.strip()) - 1 for idx in choice.split(',') if idx.strip().isdigit()]
            skills_to_remove = [skills_flat[idx] for idx in indices if 0 <= idx < len(skills_flat)]
        except (ValueError, IndexError):
            print(f"\n{Colors.RED}Invalid selection{Colors.RESET}")
            input("\nPress Enter to continue...")
            return
        
        if not skills_to_remove:
            print(f"\n{Colors.YELLOW}No skills selected{Colors.RESET}")
            input("\nPress Enter to continue...")
            return
        
        # Confirm action
        print(f"\n{Colors.YELLOW}⚠️  The following project skills will be PERMANENTLY DELETED:{Colors.RESET}")
        for skill in skills_to_remove:
            print(f"  • {skill.name}")
        print()
        
        try:
            confirm = input(f"{Colors.BOLD}Type 'yes' to confirm:{Colors.RESET} ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        
        if confirm != 'yes':
            print(f"\n{Colors.YELLOW}Removal cancelled{Colors.RESET}")
            input("\nPress Enter to continue...")
            return
        
        # Remove skills using the SkillLoader's remove_skill method
        removed_skills: List[str] = []
        for skill in skills_to_remove:
            try:
                if self.skill_loader.remove_skill(skill.name):
                    removed_skills.append(skill.name)
                    print(f"{Colors.GREEN}✔ Deleted: {skill.name}{Colors.RESET}")
                else:
                    print(f"{Colors.YELLOW}⚠ Failed to delete skill: {skill.name}{Colors.RESET}")
            except Exception as e:
                print(f"{Colors.RED}✗ Failed to delete {skill.name}: {e}{Colors.RESET}")
                logger.error(f"Error removing skill {skill.name}: {e}")
        
        # Update system prompt and inject notifications
        if removed_skills:
            for skill_name in removed_skills:
                self._inject_skill_change_notification(skill_name, _ACTION_REMOVED)
            self._update_system_prompt()
            self._refresh_skill_completer()
            print(f"\n{Colors.GREEN}✔ Removed {len(removed_skills)} skill(s){Colors.RESET}")
            print(f"{Colors.DIM}System prompt has been updated.{Colors.RESET}")
        
        input("\nPress Enter to continue...")
    
    def _process_skill_selection(
        self,
        choice: str,
        skills_list: List[SkillInfo],
        action_fn,
        action_label: str
    ) -> List[str]:
        """
        Process comma-separated skill selection and apply an action.
        
        Args:
            choice: User input string with comma-separated indices.
            skills_list: List of skills corresponding to display indices.
            action_fn: Function to call for each skill (enable_skill or disable_skill).
            action_label: Label for success messages ("Enabled" or "Disabled").
            
        Returns:
            List of skill names that were successfully modified.
        """
        modified_skills: List[str] = []
        
        try:
            indices = [int(idx.strip()) - 1 for idx in choice.split(',') if idx.strip().isdigit()]
            
            for idx in indices:
                if 0 <= idx < len(skills_list):
                    skill = skills_list[idx]
                    if action_fn(skill.name):
                        color = Colors.GREEN if action_label == "Enabled" else Colors.YELLOW
                        symbol = "✔" if action_label == "Enabled" else "○"
                        print(f"{color}{symbol} {action_label}: {skill.name}{Colors.RESET}")
                        modified_skills.append(skill.name)
                    else:
                        print(f"{Colors.RED}✗ Failed to {action_label.lower()}: {skill.name}{Colors.RESET}")
                else:
                    print(f"{Colors.RED}Invalid selection: {idx + 1}{Colors.RESET}")
        except ValueError:
            print(f"{Colors.RED}Invalid input: {choice}{Colors.RESET}")
        
        return modified_skills
    
    def _show_help(self) -> None:
        """Display help and quickstart guide for the skills system."""
        # Removed clear_screen() to preserve terminal history
        
        print(f"\n{Colors.CYAN}Skills Help & Quickstart{Colors.RESET}")
        print(f"{Colors.CYAN}========================{Colors.RESET}\n")
        
        print(f"{Colors.BOLD}What are Skills?{Colors.RESET}")
        print("  Skills are reusable task templates that help the agent complete")
        print("  complex workflows efficiently and consistently.")
        print()
        
        print(f"{Colors.BOLD}Where are Skills Stored?{Colors.RESET}")
        print(f"  • {Colors.BOLD}.coda/skills/{Colors.RESET} - Project-local skills (in current directory)")
        print(f"  • {Colors.BOLD}~/.coda/skills/{Colors.RESET} - System-wide skills (in home directory)")
        print()
        print(f"  {Colors.DIM}Project-local skills take precedence when names conflict.{Colors.RESET}")
        print()
        
        print(f"{Colors.BOLD}Skill Structure{Colors.RESET}")
        print("  Each skill is a folder containing:")
        print(f"  {Colors.GRAY}┌─ skill-name/{Colors.RESET}")
        print(f"  {Colors.GRAY}│  ├── SKILL.md          # Main skill file (required){Colors.RESET}")
        print(f"  {Colors.GRAY}│  ├── requirements.txt  # Python dependencies (optional){Colors.RESET}")
        print(f"  {Colors.GRAY}│  ├── scripts/          # Executable scripts (optional){Colors.RESET}")
        print(f"  {Colors.GRAY}│  └── LICENSE.txt       # License info (optional){Colors.RESET}")
        print(f"  {Colors.GRAY}└─{Colors.RESET}")
        print()
        
        print(f"{Colors.BOLD}SKILL.md Format{Colors.RESET}")
        print("  Skills use YAML frontmatter for metadata:")
        print()
        print(f"  {Colors.GRAY}---{Colors.RESET}")
        print(f"  {Colors.GRAY}name: my-skill{Colors.RESET}")
        print(f"  {Colors.GRAY}description: A helpful skill description{Colors.RESET}")
        print(f"  {Colors.GRAY}execution:{Colors.RESET}")
        print(f"  {Colors.GRAY}  context: native  # or: uv, docker, npm{Colors.RESET}")
        print(f"  {Colors.GRAY}  timeout: 120{Colors.RESET}")
        print(f"  {Colors.GRAY}---{Colors.RESET}")
        print(f"  {Colors.GRAY}# Skill Instructions{Colors.RESET}")
        print(f"  {Colors.GRAY}...{Colors.RESET}")
        print()
        
        print(f"{Colors.BOLD}Execution Contexts{Colors.RESET}")
        print(f"  • {Colors.BOLD}native{Colors.RESET}  - Run directly in current shell")
        print(f"  • {Colors.BOLD}uv{Colors.RESET}      - Python environment with uv")
        print(f"  • {Colors.BOLD}docker{Colors.RESET}  - Containerized execution")
        print(f"  • {Colors.BOLD}npm{Colors.RESET}     - Node.js environment")
        print()
        
        print(f"{Colors.BOLD}Using Skills{Colors.RESET}")
        print("  The agent automatically discovers enabled skills and can use them")
        print(f"  via the {Colors.BOLD}run_skill{Colors.RESET} tool. You can also explicitly request:")
        print()
        print(f"  {Colors.GRAY}\"Use the dataframe-generator skill to create sample data\"{Colors.RESET}")
        print()
        
        print(f"{Colors.BOLD}CLI Commands{Colors.RESET}")
        print(f"  {Colors.BOLD}/skills{Colors.RESET}                         - Open skill management menu")
        print(f"  {Colors.BOLD}/skills list{Colors.RESET}                    - List available skills")
        print(f"  {Colors.BOLD}/skills enable <name>{Colors.RESET}           - Enable a skill directly")
        print(f"  {Colors.BOLD}/skills disable <name>{Colors.RESET}          - Disable a skill directly")
        print(f"  {Colors.BOLD}/skills add <github-repo|local-path>{Colors.RESET} - Install skills from GitHub or local path")
        print()

        input("Press Enter to continue...")
    
    # Direct command methods (for CLI argument usage)
    
    def show_usage_help(self) -> None:
        """Display brief usage help for command-line skill operations."""
        print("\nUsage:")
        print("  /skills                          - Open skill management menu")
        print("  /skills list                     - List available skills")
        print("  /skills enable <skill-name>      - Enable a skill")
        print("  /skills disable <skill-name>     - Disable a skill")
        print("  /skills add https://github.com/organization/skills-repo - Install skills from GitHub")
        print("  /skills refresh                  - Detect manually added/removed skills")

    def enable_skill(self, skill_name: str) -> bool:
        """
        Enable a skill by name via direct command.
        
        Args:
            skill_name: The name of the skill to enable.
            
        Returns:
            True to continue CLI execution (always returns True).
        """
        try:
            if self.skill_loader.enable_skill(skill_name):
                self._update_system_prompt()
                self._refresh_skill_completer()
                self._inject_skill_change_notification(skill_name, _ACTION_ENABLED)
                print(f"{Colors.GREEN}✔ Enabled skill: {skill_name}{Colors.RESET}")
                print(f"{Colors.DIM}System prompt has been updated.{Colors.RESET}")
            else:
                print(f"{Colors.YELLOW}! Skill '{skill_name}' not found or already enabled{Colors.RESET}")
        except Exception as e:
            logger.error(f"Error enabling skill: {e}")
            print(f"{Colors.RED}Error enabling skill: {e}{Colors.RESET}")
        return True
    
    def disable_skill(self, skill_name: str) -> bool:
        """
        Disable a skill by name via direct command.
        
        Args:
            skill_name: The name of the skill to disable.
            
        Returns:
            True to continue CLI execution (always returns True).
        """
        try:
            if self.skill_loader.disable_skill(skill_name):
                self._update_system_prompt()
                self._refresh_skill_completer()
                self._inject_skill_change_notification(skill_name, _ACTION_DISABLED)
                print(f"{Colors.GREEN}✔ Disabled skill: {skill_name}{Colors.RESET}")
                print(f"{Colors.DIM}System prompt has been updated.{Colors.RESET}")
            else:
                print(f"{Colors.YELLOW}! Skill '{skill_name}' not found or not enabled{Colors.RESET}")
        except Exception as e:
            logger.error(f"Error disabling skill: {e}")
            print(f"{Colors.RED}Error disabling skill: {e}{Colors.RESET}")
        return True
    
    def refresh_skills(self) -> bool:
        """
        Refresh skill detection (wrapper for CLI direct command).
        
        Detects skills that were manually added or removed from the .coda/skills directory.
        
        Returns:
            True to continue CLI execution (always returns True).
        """
        self._refresh_and_update()
        return True
    
    def list_skills(self) -> bool:
        """
        List skills via the main menu interface.
        
        This method exists for backwards compatibility and redirects to the
        interactive main menu.
        
        Returns:
            True to continue CLI execution.
        """
        self._list_skills()
        return True

    def interactive_select_skills(self) -> bool:
        """
        Open interactive skill selection.
        
        This method exists for backwards compatibility and redirects to the
        interactive main menu.
        
        Returns:
            True to continue CLI execution.
        """
        return self.show_main_menu()
    
    def _install_from_github_menu(self) -> None:
        """Display interactive menu for installing skills from GitHub."""
        
        # Removed clear_screen() to preserve terminal history
        
        print(f"\n{Colors.CYAN}Install Skills from Repository{Colors.RESET}")
        print(f"{Colors.CYAN}=============================={Colors.RESET}\n")
        
        trusted_owners = {"openai", "anthropics", "google-labs-code", "5G-AGE009-HZ"}

        print(
            f"{Colors.YELLOW}⚠️  Please review repositories before installing skills. "
            f"You are responsible for what you install, and third-party content may be unreliable or unsafe. "
            f"Some skills rely on external MCP servers or tools that are not bundled with Coda. "
            f"If a skill mentions an MCP server, you must connect that server before the skill can run. "
            f"Only proceed if you understand and trust the source.{Colors.RESET}"
        )
        print(
            f"{Colors.DIM}Note: Some skills are installed via NPX and are not supported here.{Colors.RESET}\n"
        )

        try:
            repo_input = input(
                f"{Colors.BOLD}Paste the repository (organization/reponame) or local path, or 'q' to cancel:{Colors.RESET} "
            ).strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return

        if repo_input.lower() == 'q' or repo_input == "":
            return

        repo_owner = repo_input.split("/")[-2] if "/" in repo_input else ""
        if repo_owner and repo_owner not in trusted_owners:
            print(
                f"{Colors.YELLOW}⚠️  This repository is not in the trusted list. "
                f"Only proceed if you trust the source.{Colors.RESET}"
            )
            try:
                confirm = input(f"{Colors.BOLD}Continue? [y/N]:{Colors.RESET} ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print()
                return
            if confirm not in ("y", "yes"):
                return

        self._install_from_repo_input(repo_input)

    def _install_from_repo_input(self, repo_input: str) -> None:
        """Install skills from a repository or local path with selection menu."""
        print(f"\n{Colors.CYAN}Fetching repository...{Colors.RESET}")
        
        try:
            installer = GitHubSkillInstaller()
            repo_dir = installer.resolve_repo_source(repo_input)
            repo_url = None
            try:
                repo_url = installer.parse_repo_url(repo_input)
            except ValueError:
                repo_url = f"file://{repo_dir.resolve()}"

            try:
                # Load metadata for category filtering
                metadata = installer.load_skills_metadata(repo_dir)
                categories = installer.get_skill_categories(metadata)
                
                # Show category filter menu if metadata available
                selected_category = None
                if categories:
                    # Removed clear_screen() to preserve terminal history
                    print(f"\n{Colors.CYAN}Filter Skills by Category{Colors.RESET}")
                    print(f"{Colors.CYAN}========================={Colors.RESET}\n")
                    
                    # Count skills per category
                    category_counts = {}
                    if metadata and 'skills' in metadata:
                        for skill in metadata['skills']:
                            cat = skill.get('category', 'unknown')
                            category_counts[cat] = category_counts.get(cat, 0) + 1
                    
                    print(f"  {Colors.CYAN}0.{Colors.RESET} All skills ({metadata.get('total', '?')})")
                    for idx, category in enumerate(categories, 1):
                        count = category_counts.get(category, 0)
                        print(f"  {Colors.CYAN}{idx}.{Colors.RESET} {category.capitalize()} ({count})")
                    print(f"  {Colors.CYAN}q.{Colors.RESET} Cancel")
                    print()
                    
                    try:
                        filter_choice = input(f"{Colors.BOLD}Select category filter:{Colors.RESET} ").strip().lower()
                    except (EOFError, KeyboardInterrupt):
                        print()
                        return
                    
                    if filter_choice == 'q':
                        return
                    elif filter_choice.isdigit():
                        idx = int(filter_choice)
                        if 1 <= idx <= len(categories):
                            selected_category = categories[idx - 1]
                            print(f"\n{Colors.GREEN}✓ Filtering by: {selected_category}{Colors.RESET}")
                
                # Discover skills with optional category filter
                discovered_skills = installer.discover_skills_in_repo(repo_dir, category_filter=selected_category, metadata=metadata)
                
                if not discovered_skills:
                    print(f"\n{Colors.YELLOW}! No skills found{Colors.RESET}")
                    print(
                        f"{Colors.DIM}This repository may use NPX or another installer. "
                        f"If so, install via the terminal and place skills under .coda/skills manually.{Colors.RESET}"
                    )
                    input("\nPress Enter to continue...")
                    return

                previews = [installer.preview_skill(skill_dir) for skill_dir in discovered_skills]
                
                # Pagination settings
                page_size = 10
                total_pages = (len(previews) + page_size - 1) // page_size
                current_page = 1
                choice = None
                
                while True:
                    # Removed clear_screen() to preserve terminal history
                    
                    # Display header
                    header = f"Found {len(previews)} skill(s)"
                    if selected_category:
                        header += f" in category: {selected_category.capitalize()}"
                    else:
                        header += " in repository"
                    
                    if total_pages > 1:
                        print(f"\n{Colors.CYAN}{header}{Colors.RESET} (Page {current_page}/{total_pages})\n")
                    else:
                        print(f"\n{Colors.CYAN}{header}{Colors.RESET}\n")
                    
                    # Calculate page bounds
                    start_idx = (current_page - 1) * page_size
                    end_idx = min(start_idx + page_size, len(previews))
                    
                    # Display skills for current page
                    for i in range(start_idx, end_idx):
                        preview = previews[i]
                        idx = i + 1  # Use original index (1-based)
                        
                        print(f"{Colors.CYAN}{idx}.{Colors.RESET} {Colors.BOLD}{preview.name}{Colors.RESET}")
                        print(f"   {Colors.GRAY}{self._truncate_description(preview.description)}{Colors.RESET}")
                        print(f"   Size: {preview.size_kb:.1f} KB", end="")
                        
                        if preview.has_scripts:
                            print(f" | Scripts: {preview.script_count}", end="")
                        
                        if preview.has_warnings:
                            print(f" | {Colors.YELLOW}⚠️  {len(preview.warnings)} warning(s){Colors.RESET}")
                            for warning in preview.warnings:
                                print(f"      {Colors.YELLOW}• {warning}{Colors.RESET}")
                        else:
                            print()
                        print()
                    
                    # Display options
                    print(f"{Colors.BOLD}Options:{Colors.RESET}")
                    print(f"  {Colors.CYAN}a.{Colors.RESET} Install all skills")
                    if total_pages > 1:
                        print(f"\n{Colors.BOLD}Navigation:{Colors.RESET}")
                        if current_page > 1:
                            print(f"  {Colors.CYAN}b.{Colors.RESET} Previous page")
                        if current_page < total_pages:
                            print(f"  {Colors.CYAN}n.{Colors.RESET} Next page")
                    print(f"  {Colors.CYAN}q.{Colors.RESET} Cancel")
                    print()
                    print(f"{Colors.DIM}(You can enter numbers separated by commas, e.g., '1,3'){Colors.RESET}")
                    
                    try:
                        choice = input(f"\n{Colors.BOLD}Select skills to install:{Colors.RESET} ").strip().lower()
                    except (EOFError, KeyboardInterrupt):
                        print()
                        return
                    
                    # Handle navigation
                    if choice == 'q' or choice == '':
                        return
                    elif choice == 'n' and current_page < total_pages:
                        current_page += 1
                        continue
                    elif choice == 'b' and current_page > 1:
                        current_page -= 1
                        continue
                    elif choice in ['n', 'b']:
                        # Invalid navigation (e.g., 'n' on last page)
                        continue
                    else:
                        # User made a selection, break out of pagination loop
                        break
                
                skills_to_install = []
                
                if choice == 'a':
                    skills_to_install = discovered_skills
                else:
                    try:
                        indices = [int(idx.strip()) - 1 for idx in choice.split(',') if idx.strip().isdigit()]
                        skills_to_install = [discovered_skills[idx] for idx in indices if 0 <= idx < len(discovered_skills)]
                    except (ValueError, IndexError):
                        print(f"\n{Colors.RED}Invalid selection{Colors.RESET}")
                        input("\nPress Enter to continue...")
                        return
                
                if not skills_to_install:
                    print(f"\n{Colors.YELLOW}No skills selected{Colors.RESET}")
                    input("\nPress Enter to continue...")
                    return
                
                print(f"\n{Colors.CYAN}Installing {len(skills_to_install)} skill(s)...{Colors.RESET}\n")
                
                try:
                    with Repo(repo_dir) as repo:
                        commit_sha = repo.head.commit.hexsha
                except Exception:
                    commit_sha = None
                
                installed_count = 0
                installed_skill_names = []
                for skill_dir in skills_to_install:
                    try:
                        source_path = f"skills/{skill_dir.name}"
                        try:
                            source_path = str(skill_dir.relative_to(repo_dir))
                        except ValueError:
                            pass
                        installer.install_skill(skill_dir, repo_url, commit_sha, source_path=source_path)
                        if (skill_dir / "SKILL.md").exists():
                            skill_name = installer.preview_skill(skill_dir).name
                        else:
                            skill_name = skill_dir.name
                        installed_skill_names.append(skill_name)
                        print(f"{Colors.GREEN}✔ Installed: {skill_name}{Colors.RESET}")
                        installed_count += 1
                    except Exception as e:
                        print(f"{Colors.RED}✗ Failed: {skill_dir.name} - {e}{Colors.RESET}")
                        logger.error(f"Failed to install skill {skill_dir.name}: {e}")
                
                if installed_count > 0:
                    print(f"\n{Colors.GREEN}✔ Successfully installed {installed_count} skill(s){Colors.RESET}")
                    
                    # Auto-enable newly installed skills
                    print(f"\n{Colors.CYAN}Enabling installed skills...{Colors.RESET}")
                    print()
                    enabled_count = 0
                    for skill_name in installed_skill_names:
                        try:
                            logger.debug(f"Attempting to enable skill: {skill_name}")
                            # Force re-discovery by calling discover_skills first
                            all_skills = self.skill_loader.discover_skills(include_disabled=True)
                            found_skill = next((s for s in all_skills if s.name == skill_name), None)
                            
                            if not found_skill:
                                print(f"{Colors.RED}✗ Skill not found after installation: {skill_name}{Colors.RESET}")
                                logger.error(f"Skill {skill_name} not found in skill directories after installation")
                                continue
                            
                            logger.debug(f"Found skill {skill_name}, enabled={found_skill.enabled}")
                            
                            if self.skill_loader.enable_skill(skill_name):
                                enabled_count += 1
                                print(f"{Colors.GREEN}✔ Enabled: {skill_name}{Colors.RESET}")
                                logger.info(f"Successfully enabled skill: {skill_name}")
                            else:
                                # Check if already enabled
                                if found_skill.enabled:
                                    enabled_count += 1
                                    print(f"{Colors.GREEN}✔ Already enabled: {skill_name}{Colors.RESET}")
                                else:
                                    print(f"{Colors.YELLOW}⚠ Could not enable: {skill_name}{Colors.RESET}")
                                    logger.warning(f"Failed to enable skill {skill_name}")
                        except Exception as e:
                            print(f"{Colors.RED}✗ Failed to enable {skill_name}: {e}{Colors.RESET}")
                            logger.error(f"Exception enabling skill {skill_name}: {e}")
                    
                    # Update system prompt to include new skills
                    if enabled_count > 0:
                        logger.info(f"Updating system prompt after enabling {enabled_count} skills")
                        self._update_system_prompt()
                        print(f"\n{Colors.GREEN}✔ {enabled_count} skill(s) are now available for use!{Colors.RESET}")
                    else:
                        print(f"\n{Colors.DIM}Use option 2 to enable skills manually if needed.{Colors.RESET}")
            finally:
                installer.cleanup_repo_source(repo_dir)
                
        except Exception as e:
            logger.error(f"Error during GitHub skill installation: {e}")
            print(f"\n{Colors.RED}✗ Installation failed: {e}{Colors.RESET}")
        
        input("\nPress Enter to continue...")

    def install_from_github_cli(self, repo_input: str) -> bool:
        """
        Install skills from GitHub or local path via CLI command.
        
        Args:
            repo_input: Repository URL, shorthand, or local path
        Returns:
            True to continue CLI execution
        """
        trusted_owners = {"openai", "anthropics", "google-labs-code", "5G-AGE009-HZ"}
        repo_owner = repo_input.split("/")[-2] if "/" in repo_input else ""
        if repo_owner and repo_owner not in trusted_owners:
            print(
                f"{Colors.YELLOW}⚠️  This repository is not in the trusted list. "
                f"Only proceed if you trust the source.{Colors.RESET}"
            )
        
        self._install_from_repo_input(repo_input)
        return True
    
    def _create_new_skill(self) -> bool:
        """
        Handle creation of a new skill by collecting user input and 
        delegating to the coda skill creator agent/subagent.
        
        Pattern based on: coda_cli/core/commands/agents/ui.py::_create_new_agent()
        
        Returns:
            bool: True to continue CLI execution
        """        
        # Loop to allow editing/retry
        while True:
            # Clear screen for better UX (following agent pattern)
            print("\033[2J\033[H", end="")
            
            # Header (following UI pattern from agents/ui.py)
            print(f"\n{ui.color('┌── ', '38;5;81')}✨ Create New Skill {ui.color('────────────────────────', '38;5;81')}")
            
            print("\nEnter skill details:")
            
            # Prompt for skill name
            skill_name = input("Skill name (e.g., my-awesome-skill): ").strip()
            if not skill_name:
                print("❌ Skill name cannot be empty.")
                retry = input("\nTry again? (y/N): ").strip().lower()
                if retry not in ('y', 'yes'):
                    return True
                continue
            
            # Validate skill name format
            if not self._is_valid_skill_name(skill_name):
                print(f"❌ Invalid skill name. Use lowercase letters, numbers, hyphens, and underscores only.")
                retry = input("\nTry again? (y/N): ").strip().lower()
                if retry not in ('y', 'yes'):
                    return True
                continue
            
            # Prompt for skill description
            skill_description = input("Skill description (what should this skill do?): ").strip()
            if not skill_description:
                print("❌ Skill description cannot be empty.")
                retry = input("\nTry again? (y/N): ").strip().lower()
                if retry not in ('y', 'yes'):
                    return True
                continue
            
            # Show confirmation with option to edit
            print(f"\n{Colors.CYAN}Ready to create skill:{Colors.RESET}")
            print(f"  Name: {Colors.BOLD}{skill_name}{Colors.RESET}")
            print(f"  Description: {skill_description}")
            print(f"\nThis will invoke the AI skill creator (coda-skill-creator)")
            
            print(f"\n{Colors.BOLD}Options:{Colors.RESET}")
            print("  y - Proceed with skill creation")
            print("  e - Edit (start over)")
            print("  n - Cancel and return to menu")
            
            confirm = input(f"\n{Colors.BOLD}Choice (y/e/N):{Colors.RESET} ").strip().lower()
            
            if confirm in ('y', 'yes'):
                # User confirmed - proceed
                break
            elif confirm in ('e', 'edit'):
                # User wants to edit - restart the loop
                continue
            else:
                # User cancelled
                print("\nCancelled.")
                input("Press Enter to continue...")
                return True
        
        # Trigger the skill creator
        print(f"\n{Colors.GREEN}Delegating to AI skill creator...{Colors.RESET}\n")
        
        # Execute the skill creator
        return self._invoke_skill_creator(skill_name, skill_description)
    
    def _is_valid_skill_name(self, name: str) -> bool:
        """
        Validate skill name format.
        
        Args:
            name: Skill name to validate
            
        Returns:
            bool: True if valid, False otherwise
        """
        # Allow lowercase letters, numbers, hyphens, and underscores
        # Must start with a letter
        pattern = r'^[a-z][a-z0-9\-_]*$'
        return bool(re.match(pattern, name))
    
    def _invoke_skill_creator(self, skill_name: str, skill_description: str) -> bool:
        """
        Invoke the coda-skill-creator subagent to create a new skill.
        
        This method follows the delegate_to_subagent pattern:
        - Uses AgentManager to check if coda-skill-creator agent exists
        - Creates a subagent instance via agent_manager.create_agent()
        - Calls get_response() with the skill creation task prompt
        
        Args:
            skill_name: Name of the skill to create
            skill_description: Description of what the skill should do
            
        Returns:
            bool: True to continue CLI execution
        """
        try:
            
            # Check if shared_state is available
            if not hasattr(self.cli, 'shared_state') or self.cli.shared_state is None:
                print(f"\n{Colors.RED}❌ Error: Shared state not available{Colors.RESET}")
                input("\nPress Enter to continue...")
                return True
            
            shared_state = self.cli.shared_state
            
            # Ensure agent handler is available before creating the subagent
            if not hasattr(self.cli, "agent_handler") or self.cli.agent_handler is None:
                print(f"\n{Colors.RED}❌ Error: Agent handler not available{Colors.RESET}")
                input("\nPress Enter to continue...")
                return True
            
            # Initialize AgentManager (following delegate_to_subagent pattern)
            if hasattr(self.cli, "agent_manager") and self.cli.agent_manager is not None:
                agent_manager = self.cli.agent_manager
            else:
                agent_manager = AgentManager(shared_state=shared_state)
                agent_manager.initialize_default_agents()
            
            # Check if coda-skill-creator subagent exists
            skill_creator_name = "coda-skill-creator"
            available_agents = agent_manager.list_agents()
            
            if skill_creator_name not in available_agents:
                print(f"\n{Colors.RED}❌ Error: Subagent '{skill_creator_name}' not found{Colors.RESET}")
                print(f"{Colors.DIM}Available subagents: {', '.join(available_agents)}{Colors.RESET}")
                print(f"\n{Colors.YELLOW}Note:{Colors.RESET} The coda-skill-creator must be available as a subagent.")
                input("\nPress Enter to continue...")
                return True
            
            # Build the prompt for skill creation
            skills_dir = ".coda/skills"
            skill_prompt = (
                f"Create a new skill called '{skill_name}' that {skill_description}. "
                f"Save it in the '{skills_dir}' directory. "
                f"IMPORTANT: Before writing any files, use the ask_user tool at least 3 times "
                f"to gather enough context about the user's specific requirements and expectations. "
                f"The goal is to fully understand the user's needs so you can create a meaningful, "
                f"well-tailored skill rather than a generic one."
            )
            
            # Create a skill-creator subagent instance
            subagent = agent_manager.create_agent(
                agent_name=skill_creator_name,
                memory=None,
                file_editor=self.cli.agent_handler.file_editor,
                user_defined_rules=self.cli.shared_state.user_defined_rules,
                workspace_context=None
            )
            
            if not subagent:
                print(f"\n{Colors.RED}❌ Error: Failed to create subagent instance{Colors.RESET}")
                input("\nPress Enter to continue...")
                return True
            
            # Use agent_handler.handle_interaction_with_agent to execute the subagent
            # This follows the /agents command pattern and shows the standard callback UI
            
            try:
                # Print agent header (same as /agents command)
                ui.print_agent_header(skill_creator_name, status="Starting...")
                
                # Use handle_interaction_with_agent (same as /agents command)
                logger.info(f"Delegating to subagent '{skill_creator_name}' with prompt: {skill_prompt}")
                self.cli.agent_handler.handle_interaction_with_agent(skill_prompt, subagent)
                
                # After execution completes
                print(f"\n{Colors.GREEN}✔ Skill creation process completed!{Colors.RESET}")
                print(f"{Colors.DIM}The new skill should now be in {skills_dir}/{skill_name}{Colors.RESET}")
                print(f"\n{Colors.CYAN}Next steps:{Colors.RESET}")
                print(f"  1. Use '/skills refresh' to detect the new skill")
                print(f"  2. Enable the skill if needed")
                print(f"  3. Try it out with the run_skill tool")
                
            except Exception as e:
                logger.error(f"Error during subagent execution: {e}")
                print(f"\n{Colors.YELLOW}⚠️  Skill creation encountered an error{Colors.RESET}")
                print(f"{Colors.DIM}Details: {str(e)}{Colors.RESET}")
            
            input("\nPress Enter to return to skills menu...")
            return True
            
        except Exception as e:
            logger.error(f"Error invoking skill creator: {e}")
            print(f"\n{Colors.RED}❌ Error: Failed to create skill{Colors.RESET}")
            print(f"{Colors.DIM}{str(e)}{Colors.RESET}")
            input("\nPress Enter to continue...")
            return True
