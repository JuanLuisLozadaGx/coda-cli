import json
import re
import uuid
from pathlib import Path
from typing import Optional, Tuple, Any, Dict
from dataclasses import dataclass

from coda_cli.core import ui
from coda_cli.core.utils.utils import get_yes_no_input, input_file_path_cleanup
from coda_core.config.settings import Settings
from coda_core.config.env_config import EnvConfig

from coda_core.core.mcp.config import MCPServerConfig
from coda_core.core.mcp.enums import TransportType
from coda_core.core.mcp.service import MCPService


@dataclass
class ServerStatus:
    """Represents the status of an MCP server"""
    name: str
    config: MCPServerConfig
    connected: bool = False
    tool_count: int = 0
    error_message: Optional[str] = None


class MCPManager:
    """
    Interactive MCP server management interface following CODA's UI patterns.
    
    Provides a comprehensive menu system for managing MCP servers with features
    including server listing, addition, removal, and configuration management.
    """
    
    def __init__(self, cli, agent_update_callback=None, session_manager=None):
        """
        Initialize the MCP manager.
        
        Args:
            cli: CODA's CLI instance that will be used to update the session's agent tools
            agent_update_callback: Optional callback function to update the session's agent tools
        """
        self.settings = Settings()
        self.cli = cli
        # Use the shared tool manager instead of creating a new one
        self.tool_manager = cli.shared_state.tool_manager
        self.agent_update_callback = agent_update_callback
        
        # Use MCPService singleton and set session context
        self.mcp_service = MCPService.get()
        
        # Set session ID and update MCP service context
        if session_manager and session_manager.current_session:
            self.session_id = session_manager.current_session.id
            self.mcp_service.set_current_session_id(self.session_id)
        else:
            self.session_id = None
    
    def _capture_mcp_state_before_changes(self):
        """Capture MCP server state before changes and pass to agent update callback."""
        if not self.agent_update_callback or not hasattr(self.agent_update_callback, '__self__'):
            return
        
        try:
            effective_states = self.mcp_service.get_effective_server_states(self.session_id)
            mcp_servers_before = set(name for name, enabled in effective_states.items() if enabled)
            
            # Store the before state on the CLI instance that will call the agent update
            cli_instance = self.agent_update_callback.__self__
            cli_instance._mcp_servers_before_from_ui = mcp_servers_before
            
        except Exception as e:
            pass
        
    def run_interactive_session(self):
        """Run the main interactive MCP management session."""
        while True:
            try:
                self._display_main_menu()
                choice = input("\nEnter choice: ").strip().lower()
                
                if choice == 'q':
                    break
                elif choice == '1':
                    self._list_servers()
                elif choice == '2':
                    self._import_servers()
                elif choice == '3':
                    self._add_server()
                elif choice == '4':
                    self._manage_server_states()
                elif choice == '5':
                    self._reload_servers()
                elif choice == '6':
                    self._view_tools()
                elif choice == '7':
                    self._export_servers()
                elif choice == '8':
                    self._remove_server()
                elif choice == '9' or choice == 'h':  
                    self._show_help()
                else:
                    print("Invalid choice. Please try again.")
                    
            except KeyboardInterrupt:
                print("\n\nExiting MCP management...")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}")
                
    def _display_main_menu(self):
        """Display the main MCP management menu."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        # Get server status summary
        server_count, active_count, tool_count = self._get_server_summary()
        
        # Display header
        print(ui.block_header("MCP Server Management", icon="🔧", color_code="38;5;81"))
        print(ui.block_line("Servers", f"{server_count} configured, {active_count} active"))
        print(ui.block_line("Tools", f"{tool_count} available"))
        print(ui.block_footer())
        
        print("\nAvailable options:")
        print("  \033[1;36m1.\033[0m List configured servers")
        print("  \033[1;36m2.\033[0m Add server (JSON)")
        print("  \033[1;36m3.\033[0m Add server (interactive)")
        print("  \033[1;36m4.\033[0m Enable/disable servers")
        print("  \033[1;36m5.\033[0m Reload servers")
        print("  \033[1;36m6.\033[0m View available tools")
        print("  \033[1;36m7.\033[0m Export servers to JSON")
        print("  \033[1;36m8.\033[0m Remove server")
        print("  \033[1;36m9.\033[0m Help & quickstart")
        print()
        print("  \033[1;33mq.\033[0m Return to main interface")
        
    def _get_server_summary(self) -> Tuple[int, int, int]:
        """Get summary statistics for servers."""
        try:
            configs = self.mcp_service.load_configurations()
            server_count = len(configs)
            
            # Get active servers and tool count using MCPService
            server_status = self.mcp_service.get_server_status()
            
            active_count = sum(1 for status in server_status.values() if status.get('connected', False))
            tool_count = sum(status.get('tool_count', 0) for status in server_status.values())
                    
            return server_count, active_count, tool_count
            
        except Exception:
            return 0, 0, 0
            
    def _list_servers(self):
        """Display detailed list of configured servers."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        print(f"\n{ui.color('╭── ', '38;5;81')}📋 MCP Server List {ui.color('────────────────────────────', '38;5;81')}")
        
        try:
            configs = self.mcp_service.load_configurations()
            
            if not configs:
                print("\n🔍 No MCP servers configured.")
                print("\nTip: Use option 2 to add your first server.")
            else:
                # Get effective server states for consistent display
                effective_states = self.mcp_service.get_effective_server_states(self.session_id)
                
                print()
                for i, (server_name, config) in enumerate(configs.items(), 1):
                    status = self._get_server_status(server_name, config)
                    # Add effective enabled state to status
                    status.effective_enabled = effective_states.get(server_name, config.enabled)
                    self._display_server_entry(i, status)
                    
        except Exception as e:
            print(f"\n❌ Error loading servers: {e}")
            
        input("\nPress Enter to continue...")
        
    def _get_server_status(self, server_name: str, config: MCPServerConfig) -> ServerStatus:
        """Get the current status of a server."""
        status = ServerStatus(
            name=server_name,
            config=config
        )
        
        try:
            # Use MCPService to get server status
            server_status = self.mcp_service.get_server_status()
            
            if server_name in server_status:
                server_info = server_status[server_name]
                status.connected = server_info.get('connected', False)
                status.tool_count = server_info.get('tool_count', 0)
                if not status.connected:
                    status.error_message = server_info.get('last_error') or "Server not connected"
            else:
                status.connected = False
                status.error_message = "Not started (requires agent initialization)"
                
        except Exception as e:
            status.connected = False
            status.error_message = str(e)
            
        return status
        
    def _display_server_entry(self, index: int, status: ServerStatus):
        """Display a single server entry."""
        # Status indicator
        if status.connected:
            status_icon = "✅"
            status_color = "32"  # Green
            status_text = f"Active ({status.tool_count} tools)"
        else:
            # Different styling for servers waiting for initialization vs connection errors
            if status.error_message == "Not started (requires agent initialization)":
                status_icon = "⏳"
                status_color = "33"  # Yellow/Orange
            else:
                status_icon = "❌"
                status_color = "31"  # Red
            status_text = status.error_message or "Inactive"
        
        # Add enabled/disabled indicator using effective session state
        effective_enabled = getattr(status, 'effective_enabled', status.config.enabled)
        enabled_text = "Enabled" if effective_enabled else "Disabled"

        # Status indicator and text based on connection and enabled state               
        if status.connected:                                                            
            status_icon = "✅"                                                           
            status_color = "32"  # Green                                                
            status_text = f"Active ({status.tool_count} tools)"                         
        elif not effective_enabled:                                                     
            # Server is disabled - show as such regardless of connection status         
            status_icon = "⏸️ "                                                          
            status_color = "90"  # Gray                                                 
            status_text = "Disabled"                                                    
        else:                                                                           
            # Server is enabled but not connected                                       
            if status.error_message == "Not started (requires agent initialization)":   
                status_icon = "⏳"                                                       
                status_color = "33"  # Yellow/Orange                                    
                status_text = "Waiting for agent initialization"                        
            else:                                                                       
                status_icon = "❌"                                                       
                status_color = "31"  # Red                                              
                status_text = status.error_message or "Inactive"      
            
        print(f"  \033[1;36m{index:2d}.\033[0m {status_icon} \033[1m{status.name}\033[0m")
        print(f"      \033[{status_color}m{status_text}\033[0m")
        # Display transport-specific information
        if status.config.transport_type == TransportType.HTTP:
            print(f"      Transport: HTTP Streamable")
            print(f"      URL: {status.config.url}")
            if status.config.headers:
                print(f"      Headers: {len(status.config.headers)} configured")
            print(f"      Timeout: {status.config.timeout}s")
        else:
            print(f"      Transport: STDIO")
            print(f"      Command: {status.config.command}")
            
            if status.config.args:
                args_str = " ".join(status.config.args)
                if len(args_str) > 60:
                    args_str = args_str[:57] + "..."
                print(f"      Args: {args_str}")
                
            if status.config.env:
                env_count = len(status.config.env)
                print(f"      Environment: {env_count} variables")
            
        print()
        
    def _add_server(self):
        """Interactive server addition with transport type selection."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        print(f"\n{ui.color('╭── ', '38;5;81')}➕ Add MCP Server {ui.color('─────────────────────────────', '38;5;81')}")
        
        try:
            # Get server details
            print("\nEnter server configuration:")
            
            server_name = input("Server name: ").strip()
            if not server_name:
                print("❌ Server name cannot be empty.")
                input("Press Enter to continue...")
                return
                
            # Check if server already exists
            configs = self.mcp_service.load_configurations()
            if server_name in configs:
                print(f"❌ Server '{server_name}' already exists.")
                input("Press Enter to continue...")
                return
            
            # Transport type selection
            print("\nTransport type:")
            print("  1. STDIO (local command)")
            print("  2. HTTP Streamable (remote server)")
            
            transport_choice = input("Choose transport (1-2): ").strip()
            
            if transport_choice == "2":
                config = self._add_http_server(server_name)
            else:
                config = self._add_stdio_server(server_name)
            
            if config:
                # Capture MCP state before adding server (for transition tracking)
                self._capture_mcp_state_before_changes()
                
                try:
                    validation = self.mcp_service.add_server(config)
                except ValueError as e:
                    print(f"\n❌ {e}")
                    input("\nPress Enter to continue...")
                    return
                
                print(f"\n✅ Server '{server_name}' added successfully!")
                if validation:
                    print(f"   Tools discovered: {validation.tool_count}")
                
                # Automatically reload servers to activate new server
                print("🔄 Reloading servers to activate new server...")
                self._reload_servers_internal()
                
        except Exception as e:
            print(f"\n❌ Error adding server: {e}")
            
        input("\nPress Enter to continue...")
    
    def _add_stdio_server(self, server_name: str) -> Optional[MCPServerConfig]:
        """Add STDIO server configuration."""
        print(f"\nConfiguring STDIO transport for '{server_name}':")
        
        command = input("Command: ").strip()
        if not command:
            print("❌ Command cannot be empty.")
            return None
            
        # Get arguments
        args_input = input("Arguments (space-separated): ").strip()
        args = args_input.split() if args_input else []
        
        # Get environment variables
        env = {}
        if get_yes_no_input("Add environment variables?", default="no"):
            print("\nEnter environment variables (press Enter with empty name to finish):")
            while True:
                env_name = input("  Variable name: ").strip()
                if not env_name:
                    break
                env_value = input(f"  {env_name} value: ").strip()
                env[env_name] = env_value
        
        return MCPServerConfig(
            name=server_name,
            transport_type=TransportType.STDIO,
            command=command,
            args=args,
            env=env
        )
    
    def _add_http_server(self, server_name: str) -> Optional[MCPServerConfig]:
        """Add HTTP Streamable server configuration."""
        print(f"\nConfiguring HTTP Streamable transport for '{server_name}':")
        print("Note: This uses the MCP HTTP Streamable transport (2025-03-26 spec)")
        
        url = input("Server URL: ").strip()
        if not url:
            print("❌ URL cannot be empty.")
            return None
        
        # Ensure URL has proper scheme
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        headers = {}
        auth_token = None
        
        # Quick authorization token setup
        if get_yes_no_input("Add authorization token?", default="no"):
            auth_token = input("  Authorization token (include Bearer prefix if needed): ").strip()
        
        # Additional custom headers
        if get_yes_no_input("Add other custom headers?", default="no"):
            print("\nEnter additional headers (press Enter with empty name to finish):")
            while True:
                header_name = input("  Header name: ").strip()
                if not header_name:
                    break
                header_value = input(f"  {header_name} value: ").strip()
                headers[header_name] = header_value
        
        timeout_input = input("Timeout (seconds) [30]: ").strip()
        timeout = int(timeout_input) if timeout_input.isdigit() else 30
        
        return MCPServerConfig(
            name=server_name,
            transport_type=TransportType.HTTP,
            url=url,
            headers=headers,
            timeout=timeout,
            authorization_token=auth_token
        )
        
    def _remove_server(self):
        """Interactive server removal."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        print(f"\n{ui.color('╭── ', '38;5;81')}🗑️ Remove MCP Server {ui.color('──────────────────────────────', '38;5;81')}")
        
        try:
            configs = self.mcp_service.load_configurations()
            
            if not configs:
                print("\n🔍 No servers configured to remove.")
                input("Press Enter to continue...")
                return
                
            print("\nConfigured servers:")
            server_list = list(configs.keys())
            
            for i, server_name in enumerate(server_list, 1):
                print(f"  \033[1;36m{i}.\033[0m {server_name}")
                
            print(f"  \033[1;33m{len(server_list) + 1}.\033[0m Cancel")
            
            choice = input(f"\nSelect server to remove (1-{len(server_list) + 1}): ").strip()
            
            try:
                choice_num = int(choice)
                if choice_num == len(server_list) + 1:
                    return
                    
                if 1 <= choice_num <= len(server_list):
                    server_name = server_list[choice_num - 1]
                    
                    # Confirm removal
                    if get_yes_no_input(f"Remove server '{server_name}'?", default="no"):
                        # Capture MCP state before removal (for transition tracking)
                        self._capture_mcp_state_before_changes()
                        
                        self.mcp_service.remove_server(server_name)
                        print(f"\n✅ Server '{server_name}' removed successfully!")
                        
                        # Clean up stale session overrides for removed server
                        self.mcp_service.cleanup_stale_session_overrides(self.session_id)
                        
                        # Automatically reload servers after removal
                        print("🔄 Reloading servers to apply changes...")
                        self._reload_servers_internal()
                    else:
                        print("Removal cancelled.")
                else:
                    print("Invalid selection.")
                    
            except ValueError:
                print("Invalid input. Please enter a number.")
                
        except Exception as e:
            print(f"\n❌ Error removing server: {e}")
            
        input("\nPress Enter to continue...")
        
    def _reload_servers(self):
        """Reload all servers."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        print(f"\n{ui.color('╭── ', '38;5;81')}🔄 Reload Servers {ui.color('───────────────────────────────────', '38;5;81')}")
        
        self._reload_servers_internal()
        
        input("\nPress Enter to continue...")
        
    def _reload_servers_internal(self):
        """Internal server reload implementation."""
        try:
            print("\nReloading MCP servers...")
            
            # Reload using MCPService
            success = self.mcp_service.reload()
            
            if success:
                print("✅ Servers reloaded successfully!")
                
                # Update the current session's agent with the new tool configuration
                self._update_session_agent_tools()
            else:
                print("⚠️ Some issues occurred during reload, check logs for details")
                
        except Exception as e:
            print(f"❌ Error reloading servers: {e}")
            
    def _import_servers(self):
        """Import servers from JSON file or direct JSON input."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        print(f"\n{ui.color('╭── ', '38;5;81')}📥 Import MCP Servers {ui.color('──────────────────────────────', '38;5;81')}")
        
        try:
            print("\nImport MCP servers from JSON.")
            print("Supports both Claude Desktop format and flat JSON format.")
            print("\nFormats accepted:")
            print("  • Claude style: {\"mcpServers\": {\"serverName\": {...}, ...}}")
            print("  • Flat style:   {\"serverName\": {...}, \"anotherServer\": {...}}")
            
            print("\nImport options:")
            print("  1. Load from file")
            print("  2. Paste JSON directly")
            
            choice = input("\nChoose import method (1-2): ").strip()
            
            data = None
            
            if choice == "1":
                # File import
                file_path = input("\nEnter JSON file path: ").strip()
                
                if not file_path:
                    print("❌ File path cannot be empty.")
                    input("Press Enter to continue...")
                    return
                
                file_path = input_file_path_cleanup(file_path)
                # Expand user path
                file_path = Path(file_path).expanduser()
                
                if not file_path.exists():
                    print(f"❌ File not found: {file_path}")
                    input("Press Enter to continue...")
                    return
                
                # Load and validate JSON
                try:
                    with open(file_path, 'r') as f:
                        data = json.load(f)
                except json.JSONDecodeError as e:
                    print(f"❌ Invalid JSON format: {e}")
                    input("Press Enter to continue...")
                    return
                    
            elif choice == "2":
                # Direct JSON input with auto-detection
                print("\nPaste your JSON configuration below.")
                print("The input will auto-complete when valid JSON is detected.")
                print("Or type 'END' on its own line to finish manually.")
                print("─" * 50)
                
                try:
                    lines = []
                    while True:
                        try:
                            line = input()
                            
                            # Check for manual terminator
                            if line.strip().upper() == "END":
                                break
                                
                            lines.append(line)
                            
                            # Try parsing accumulated JSON after each line
                            json_text = "\n".join(lines)
                            if json_text.strip():
                                try:
                                    json.loads(json_text)
                                    # Valid JSON found - ask if user is done
                                    print("✅ Valid JSON detected. Continue adding more? (y/N): ", end="")
                                    response = input().strip().lower()
                                    if response not in ['y', 'yes']:
                                        break
                                except json.JSONDecodeError:
                                    # Not valid yet, continue
                                    continue
                                    
                        except EOFError:
                            # Ctrl+D still works as fallback
                            break
                    
                    json_text = "\n".join(lines)
                    
                    if not json_text.strip():
                        print("❌ No JSON provided.")
                        input("Press Enter to continue...")
                        return
                    
                    # Final JSON validation
                    try:
                        data = json.loads(json_text)
                    except json.JSONDecodeError as e:
                        print(f"❌ Invalid JSON format: {e}")
                        input("Press Enter to continue...")
                        return
                        
                except KeyboardInterrupt:
                    print("\n❌ Import cancelled.")
                    input("Press Enter to continue...")
                    return
                    
            else:
                print("❌ Invalid choice.")
                input("Press Enter to continue...")
                return
            
            # Import servers
            if data is not None:
                # Capture MCP state before import (for transition tracking)
                self._capture_mcp_state_before_changes()
                
                success_count, errors = self.mcp_service.import_servers(data)
                
                # Report results
                print(f"\n✅ Successfully imported {success_count} servers!")
                
                if errors:
                    print(f"\n⚠️  {len(errors)} servers had errors:")
                    for error in errors[:5]:  # Show first 5 errors
                        print(f"   • {error}")
                    if len(errors) > 5:
                        print(f"   ... and {len(errors) - 5} more errors")
                
                if success_count > 0:
                    # Automatically reload servers after successful import
                    print("🔄 Reloading servers to activate imported servers...")
                    self._reload_servers_internal()
                    
        except Exception as e:
            print(f"\n❌ Error importing servers: {e}")
            
        input("\nPress Enter to continue...")
    
    def _export_servers(self):
        """Export servers to JSON file."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        print(f"\n{ui.color('╭── ', '38;5;81')}📤 Export MCP Servers {ui.color('──────────────────────────────', '38;5;81')}")
        
        try:
            configs = self.mcp_service.load_configurations()
            
            if not configs:
                print("\n🔍 No servers configured to export.")
                input("Press Enter to continue...")
                return
            
            print(f"\nFound {len(configs)} servers to export.")
            
            # Get export data
            export_data = self.mcp_service.export_servers()
            
            print("\nExport options:")
            print("  1. Save to file")
            print("  2. Print to screen")
            
            choice = input("\nChoose export option (1-2): ").strip()
            
            if choice == "1":
                # Save to file
                default_path = "mcp_servers_export.json"
                file_path = input(f"Export file path [{default_path}]: ").strip()
                
                if not file_path:
                    file_path = default_path
                
                file_path = Path(file_path).expanduser()
                
                # Check if the export path is within the MCP servers directory
                mcp_servers_dir = Path(self.settings.get_env_var(EnvConfig.CODA_MCP_SERVERS_DIR)).expanduser()
                try:
                    # Check if the file path is within the MCP servers directory
                    file_path.resolve().relative_to(mcp_servers_dir.resolve())
                    print(f"\n❌ Error: Cannot export to the MCP servers directory: {mcp_servers_dir}")
                    print("This directory is reserved for MCP server configuration files.")
                    print("Please choose a different export location.")
                    input("\\nPress Enter to continue...")
                    return
                except ValueError:
                    # Path is not within the MCP servers directory, proceed with export
                    pass
                
                with open(file_path, 'w') as f:
                    json.dump(export_data, f, indent=2)
                
                print(f"\n✅ Exported {len(configs)} servers to: {file_path}")
                
            elif choice == "2":
                # Print to screen with obfuscated sensitive data
                print("\n" + "─" * 60)
                print("🔒 Sensitive data has been obfuscated for security")
                print("─" * 60)
                obfuscated_data = self._obfuscate_export_data(export_data)
                print(json.dumps(obfuscated_data, indent=2))
                print("─" * 60)
                
            else:
                print("Invalid choice.")
                
        except Exception as e:
            print(f"\n❌ Error exporting servers: {e}")
            
        input("\nPress Enter to continue...")

    def _obfuscate_export_data(self, data: Any) -> Any:
        """
        Obfuscate sensitive fields in export data for safe display.
        
        This function creates a deep copy of the data with sensitive values obfuscated.
        Only used when displaying to screen - file exports remain unmodified.
        
        Args:
            data: The data structure to obfuscate (dict, list, or primitive)
            
        Returns:
            A copy of the data with sensitive values obfuscated
        """
        if isinstance(data, dict):
            return self._obfuscate_dict(data)
        elif isinstance(data, list):
            return [self._obfuscate_export_data(item) for item in data]
        else:
            return data
    
    def _obfuscate_dict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Obfuscate sensitive fields in a dictionary."""
        result = {}
        
        for key, value in data.items():
            key_lower = key.lower()
            
            # Check if this is a sensitive field name
            if self._is_sensitive_field(key_lower):
                result[key] = self._obfuscate_value(value)
            # Special handling for headers
            elif key_lower == 'headers' and isinstance(value, dict):
                result[key] = self._obfuscate_headers(value)
            # Special handling for environment variables
            elif key_lower == 'env' and isinstance(value, dict):
                result[key] = self._obfuscate_env_vars(value)
            # Recursively process nested structures
            elif isinstance(value, (dict, list)):
                result[key] = self._obfuscate_export_data(value)
            else:
                result[key] = value
                
        return result
    
    def _is_sensitive_field(self, field_name: str) -> bool:
        """Check if a field name indicates sensitive data."""
        sensitive_fields = {
            'authorization_token', 'auth_token', 'token', 'api_key', 'secret',
            'password', 'passwd', 'key', 'access_token', 'refresh_token',
            'bearer_token', 'client_secret', 'private_key'
        }
        return field_name in sensitive_fields
    
    def _obfuscate_headers(self, headers: Dict[str, str]) -> Dict[str, str]:
        """Obfuscate sensitive headers."""
        result = {}
        sensitive_headers = {'authorization', 'x-api-key', 'x-auth-token', 'bearer', 'cookie'}
        
        for header_name, header_value in headers.items():
            header_lower = header_name.lower()
            
            if header_lower in sensitive_headers:
                result[header_name] = self._obfuscate_value(header_value)
            else:
                result[header_name] = header_value
                
        return result
    
    def _obfuscate_env_vars(self, env_vars: Dict[str, str]) -> Dict[str, str]:
        """Obfuscate sensitive environment variables."""
        result = {}
        sensitive_patterns = [
            r'.*_token.*', r'.*_key.*', r'.*_secret.*', r'.*_password.*',
            r'.*_auth.*', r'.*api.*key.*', r'.*bearer.*'
        ]
        
        for env_name, env_value in env_vars.items():
            env_lower = env_name.lower()
            
            # Check against sensitive patterns
            is_sensitive = any(
                re.match(pattern, env_lower, re.IGNORECASE) 
                for pattern in sensitive_patterns
            )
            
            if is_sensitive:
                result[env_name] = self._obfuscate_value(env_value)
            else:
                result[env_name] = env_value
                
        return result
    
    def _obfuscate_value(self, value: str) -> str:
        """
        Obfuscate a sensitive value.
        
        Shows the first 4 characters and replaces the rest with asterisks.
        For very short values, shows fewer characters.
        """
        if not isinstance(value, str) or not value:
            return value
            
        if len(value) <= 4:
            return "*" * len(value)
        elif len(value) <= 8:
            return value[:2] + "*" * (len(value) - 2)
        else:
            return value[:4] + "*" * (len(value) - 4)
    
    def _update_session_agent_tools(self):
        """Update the current session's agent with the new tool configuration after MCP changes.""" 
        try:                                                                                        
            if self.agent_update_callback:
                # Use the callback provided by the CLI                                              
                success = self.agent_update_callback(self.cli)                                              
                if success:                                                                         
                    print("🔄 Session agent tools updated successfully!")                            
                else:                                                                               
                    print("⚠️ Failed to update session agent tools")                                
            else:                                                                                   
                print("ℹ️ No active agent session to update")                                       
        except Exception as e:                                                                      
            print(f"⚠️ Error updating session agent tools: {e}")

    def _view_tools(self):
        """Display detailed list of available MCP tools grouped by server with pagination."""
        print("\033[2J\033[H", end="")  # Clear screen

        # Display MCP tools if available (via gateway tool approach)
        try:
            mcp_service = MCPService.get()
            if mcp_service.is_available():
                mcp_tools = mcp_service.list_tools()
                if mcp_tools:
                    # Group tools by server
                    servers = {}
                    for server_name, tool_name, description in mcp_tools:
                        if server_name not in servers:
                            servers[server_name] = []
                        servers[server_name].append({'name': tool_name, 'description': description})

                    # Flatten tools for pagination - each tool takes 2 lines
                    all_tool_entries = []
                    for server_name, server_tools in sorted(servers.items()):
                        # Add server header
                        all_tool_entries.append(("server_header", server_name, len(server_tools)))
                        
                        # Add tools for this server
                        for tool in sorted(server_tools, key=lambda x: x['name']):
                            all_tool_entries.append(("tool", tool['name'], tool['description']))

                    if not all_tool_entries:
                        print("\n🔍 No MCP tools available.")
                        input("\nPress Enter to continue...")
                        return
                        
                    # Pagination settings
                    page_size = 15  # Show fewer items per page since tools take 2 lines each
                    total_pages = (len(all_tool_entries) + page_size - 1) // page_size
                    current_page = 1
                    
                    while True:
                        # Clear screen and display header
                        print("\033[2J\033[H", end="")  # Clear screen
                        print(f"\n\033[1m🔧 MCP Tools\033[0m (Page {current_page}/{total_pages})")
                        print(f"  Access via: \033[1;36mmcp_execute\033[0m tool with server_name and tool_name parameters\n")

                        # Calculate page bounds
                        start_idx = (current_page - 1) * page_size
                        end_idx = min(start_idx + page_size, len(all_tool_entries))
                        
                        # Display entries for current page
                        for i in range(start_idx, end_idx):
                            entry_type, name, extra = all_tool_entries[i]
                            
                            if entry_type == "server_header":
                                tool_count = extra
                                # Add spacing before server header (except for first item)
                                if i > start_idx:
                                    print()
                                print(f"  \033[1;35m{name}\033[0m \033[1;32m({tool_count} tools)\033[0m")
                            else:  # tool
                                description = extra
                                display_name = name.replace('_', ' ').title()
                                desc = description[:60] + "..." if len(description) > 60 else description
                                
                                print(f"    \033[1;36m{display_name}\033[0m")
                                print(f"      \033[90m{desc}\033[0m")
                        
                        # Display navigation options
                        print("\n\033[1mNavigation:\033[0m")
                        if current_page > 1:
                            print("  p: Previous page")
                        if current_page < total_pages:
                            print("  n: Next page")
                        print("  q: Return to main menu")
                        
                        # Get user input
                        choice = input("\n\033[1mEnter choice: \033[0m").strip().lower()
                        
                        if choice == 'q':
                            break
                        elif choice == 'n' and current_page < total_pages:
                            current_page += 1
                        elif choice == 'p' and current_page > 1:
                            current_page -= 1
                        elif choice in ['n', 'p']:
                            # Invalid navigation - just continue to show current page
                            continue
                        else:
                            print("\033[1;31mInvalid input. Please try again.\033[0m")
                            input("Press Enter to continue...")
                else:
                    print("\n🔍 No MCP tools available.")
                    print("\nThis could mean:")
                    print("  • No MCP servers are configured")
                    print("  • No servers are currently active")
                    print("  • Active servers don't provide any tools")
                    print("\nTip: Use option 1 to check server status, or option 2 to add servers.")
                    input("\nPress Enter to continue...")
        except Exception:
            # Silently handle MCP display errors to not break regular tool display
            print("\n❌ Error loading MCP tools.")
            input("\nPress Enter to continue...")
    
    def _manage_server_states(self):
        """Manage enable/disable states of MCP servers."""
        while True:
            try:
                self._display_server_states_menu()
                choice = input("\nEnter choice: ").strip().lower()
                
                if choice == 'q':
                    break
                elif choice == '1':
                    self._enable_servers()
                elif choice == '2':
                    self._disable_servers()
                elif choice == '3':
                    self._show_server_states()
                else:
                    print("Invalid choice. Please try again.")
                    
            except KeyboardInterrupt:
                print("\n\nReturning to main menu...")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}")
    
    def _display_server_states_menu(self):
        """Display the server enable/disable management menu."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        # Get effective session states and global defaults
        effective_states = self.mcp_service.get_effective_server_states(self.session_id)
        global_states = self.mcp_service.load_global_mcp_defaults()
        session_overrides = self.mcp_service.load_session_mcp_config(self.session_id)
        
        enabled_count = sum(1 for enabled in effective_states.values() if enabled)
        disabled_count = len(effective_states) - enabled_count
        override_count = len(session_overrides)
        
        # Display header
        print(ui.block_header("MCP Server States", icon="⚡", color_code="38;5;81"))
        print(ui.block_line("Enabled", f"{enabled_count} servers"))
        print(ui.block_line("Disabled", f"{disabled_count} servers"))
        print(ui.block_footer())
        
        print("\nAvailable options:")
        print("  \033[1;36m1.\033[0m Enable servers")
        print("  \033[1;36m2.\033[0m Disable servers")
        print("  \033[1;36m3.\033[0m Show server states")
        print()
        print("  \033[1;33mq.\033[0m Return to MCP management")
    
    def _enable_servers(self):
        """Enable one or more MCP servers."""
        print("\033[2J\033[H", end="")  # Clear screen
        print("\n\033[1;36mEnable MCP Servers\033[0m")
        print("\033[1;36m==================\033[0m")
        
        # Get disabled servers using effective session states
        effective_states = self.mcp_service.get_effective_server_states(self.session_id)
        disabled_servers = [name for name, enabled in effective_states.items() if not enabled]
        
        if not disabled_servers:
            print("\n\033[1;33mAll servers are already enabled.\033[0m")
            input("\nPress Enter to continue...")
            return
        
        # Check for ongoing conversation
        if not self._check_ongoing_conversation():
            return
        
        # Capture MCP state before any changes
        self._capture_mcp_state_before_changes()
        
        # Display disabled servers
        print("\n\033[1mDisabled Servers:\033[0m")
        for i, server_name in enumerate(disabled_servers, 1):
            print(f"  \033[1;36m{i}.\033[0m {server_name}")
        
        print("\n\033[1mOptions:\033[0m")
        print("  \033[1;36ma.\033[0m Enable all servers")
        print("  \033[1;36mq.\033[0m Return to server states menu")
        
        print("(You can enter multiple numbers separated by commas, e.g., '1,3,5')")
        choice = input("\n\033[1mEnter choice(s):\033[0m ").strip().lower()
        
        if choice == 'q':
            return
        
        # Track servers that were enabled for potential rollback
        enabled_servers = []
        
        # Enable all servers
        if choice == 'a':
            for server_name in disabled_servers:
                if self.mcp_service.set_session_server_state(self.session_id, server_name, True):
                    print(f"\033[1;32mServer '{server_name}' has been enabled.\033[0m")
                    enabled_servers.append(server_name)
                else:
                    print(f"\033[1;31mFailed to enable server '{server_name}'.\033[0m")
        
        # Enable specific servers
        else:
            try:
                indices = [int(idx.strip()) - 1 for idx in choice.split(',') if idx.strip().isdigit()]
                
                for idx in indices:
                    if 0 <= idx < len(disabled_servers):
                        server_name = disabled_servers[idx]
                        
                        if self.mcp_service.set_session_server_state(self.session_id, server_name, True):
                            print(f"\033[1;32mServer '{server_name}' has been enabled.\033[0m")
                            enabled_servers.append(server_name)
                        else:
                            print(f"\033[1;31mFailed to enable server '{server_name}'.\033[0m")
                    else:
                        print(f"\033[1;31mInvalid selection: {idx + 1}\033[0m")
            except ValueError:
                print(f"\033[1;31mInvalid input: {choice}\033[0m")
        
        # Update the agent with new tools if any servers were enabled
        if enabled_servers:
            success = self._update_session_agent_tools_with_rollback()
            
            # If update failed, roll back the changes
            if not success:
                print("\033[1;33mRolling back server changes to maintain synchronization...\033[0m")
                for server_name in enabled_servers:
                    if self.mcp_service.set_session_server_state(self.session_id, server_name, False):
                        print(f"\033[1;33mRolled back: Server '{server_name}' has been disabled.\033[0m")
                    else:
                        print(f"\033[1;31mFailed to roll back server '{server_name}'.\033[0m")
            else:
                # Successfully enabled servers, ask about making global default
                self._prompt_make_global_default()
        
        input("\nPress Enter to continue...")
    
    def _disable_servers(self):
        """Disable one or more MCP servers."""
        print("\033[2J\033[H", end="")  # Clear screen
        print("\n\033[1;36mDisable MCP Servers\033[0m")
        print("\033[1;36m===================\033[0m")
        
        # Get enabled servers using effective session states
        effective_states = self.mcp_service.get_effective_server_states(self.session_id)
        enabled_servers = [name for name, enabled in effective_states.items() if enabled]
        
        if not enabled_servers:
            print("\n\033[1;33mNo servers are currently enabled.\033[0m")
            input("\nPress Enter to continue...")
            return
        
        # Check for ongoing conversation
        if not self._check_ongoing_conversation():
            return
        
        # Capture MCP state before any changes
        self._capture_mcp_state_before_changes()
        
        # Display enabled servers
        print("\n\033[1mEnabled Servers:\033[0m")
        for i, server_name in enumerate(enabled_servers, 1):
            print(f"  \033[1;36m{i}.\033[0m {server_name}")
        
        print("\n\033[1mOptions:\033[0m")
        print("  \033[1;36ma.\033[0m Disable all servers")
        print("  \033[1;36mq.\033[0m Return to server states menu")
        
        print("(You can enter multiple numbers separated by commas, e.g., '1,3,5')")
        choice = input("\n\033[1mEnter choice(s):\033[0m ").strip().lower()
        
        if choice == 'q':
            return
        
        # Track servers that were disabled for potential rollback
        disabled_servers = []
        
        # Disable all servers
        if choice == 'a':
            for server_name in enabled_servers:
                if self.mcp_service.set_session_server_state(self.session_id, server_name, False):
                    print(f"\033[1;32mServer '{server_name}' has been disabled.\033[0m")
                    disabled_servers.append(server_name)
                else:
                    print(f"\033[1;31mFailed to disable server '{server_name}'.\033[0m")
        
        # Disable specific servers
        else:
            try:
                indices = [int(idx.strip()) - 1 for idx in choice.split(',') if idx.strip().isdigit()]
                
                for idx in indices:
                    if 0 <= idx < len(enabled_servers):
                        server_name = enabled_servers[idx]
                        
                        if self.mcp_service.set_session_server_state(self.session_id, server_name, False):
                            print(f"\033[1;32mServer '{server_name}' has been disabled.\033[0m")
                            disabled_servers.append(server_name)
                        else:
                            print(f"\033[1;31mFailed to disable server '{server_name}'.\033[0m")
                    else:
                        print(f"\033[1;31mInvalid selection: {idx + 1}\033[0m")
            except ValueError:
                print(f"\033[1;31mInvalid input: {choice}\033[0m")
        
        # Update the agent with new tools if any servers were disabled
        if disabled_servers:
            success = self._update_session_agent_tools_with_rollback()
            
            # If update failed, roll back the changes
            if not success:
                print("\033[1;33mRolling back server changes to maintain synchronization...\033[0m")
                for server_name in disabled_servers:
                    if self.mcp_service.set_session_server_state(self.session_id, server_name, True):
                        print(f"\033[1;33mRolled back: Server '{server_name}' has been enabled.\033[0m")
                    else:
                        print(f"\033[1;31mFailed to roll back server '{server_name}'.\033[0m")
            else:
                # Successfully disabled servers, ask about making global default
                self._prompt_make_global_default()
        
        input("\nPress Enter to continue...")
    
    def _show_server_states(self):
        """Display current enable/disable states of all servers for this session."""
        print("\033[2J\033[H", end="")  # Clear screen
        print(f"\n{ui.color('╭── ', '38;5;81')}⚡ Server States {ui.color('──────────────────────────────', '38;5;81')}")
        
        try:
            effective_states = self.mcp_service.get_effective_server_states(self.session_id)
            
            if not effective_states:
                print("\n🔍 No MCP servers configured.")
                input("\nPress Enter to continue...")
                return
            
            print(f"\nSession ID: {self.session_id}")
            
            # Display servers grouped by status
            enabled_servers = [name for name, enabled in sorted(effective_states.items()) if enabled]
            disabled_servers = [name for name, enabled in sorted(effective_states.items()) if not enabled]
            
            # Display enabled servers
            if enabled_servers:
                print("\n\033[1;32m✅ Enabled Servers:\033[0m")
                for server_name in enabled_servers:
                    print(f"  • {server_name}")
            
            # Display disabled servers
            if disabled_servers:
                print("\n\033[1;31m❌ Disabled Servers:\033[0m")
                for server_name in disabled_servers:
                    print(f"  • {server_name}")
            
            # Summary
            print(f"\n\033[1mSummary:\033[0m")
            print(f"  Total servers: {len(effective_states)}")
            print(f"  Enabled: \033[1;32m{len(enabled_servers)}\033[0m")
            print(f"  Disabled: \033[1;31m{len(disabled_servers)}\033[0m")
            
        except Exception as e:
            print(f"\n❌ Error loading server states: {e}")
        
        input("\nPress Enter to continue...")
    
    def _prompt_make_global_default(self):
        """Prompt user to set current MCP server configuration as global default."""
        if get_yes_no_input("\nWould you like to set the current MCP servers configuration as the global default for all new sessions?", default="no"):
            success = self.mcp_service.make_session_global_default(self.session_id)
            if success:
                print("✅ Session configuration is now the global default!")
            else:
                print("❌ Failed to set session configuration as global default.")
    
    def _check_ongoing_conversation(self) -> bool:
        """Check if there's an ongoing conversation and warn user about changes."""
        # This mimics the tool manager's approach for consistency
        print("\n\033[1;33m⚠️  Warning:\033[0m \033[33mChanging server states will affect available tools.")
        print("This may impact an ongoing conversation if you're using MCP tools.\033[0m")
        
        return get_yes_no_input("Do you want to continue?", default="yes")
    
    def _update_session_agent_tools_with_rollback(self) -> bool:
        """Update session agent tools with rollback capability."""
        try:
            if self.agent_update_callback:
                success = self.agent_update_callback(self.cli)
                if success:
                    print("🔄 Session agent tools updated successfully!")
                    return True
                else:
                    print("⚠️ Failed to update session agent tools")
                    return False
            else:
                print("ℹ️ No active agent session to update")
                return True  # No agent to update, consider this successful
        except Exception as e:
            print(f"⚠️ Error updating session agent tools: {e}")
            return False
        
    def _show_help(self):
        """Display MCP help and quickstart guide."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        print(f"\n{ui.color('╭── ', '38;5;81')}❓ MCP Help & Quickstart {ui.color('─────────────────────────', '38;5;81')}")
        
        # Brief intro
        print("\n\033[1m🔌 What is MCP (Model Context Protocol)?\033[0m")
        print("MCP standardizes how CODA connects to external tools and data - like USB-C for AI.")

        # Warning
        print("\n\033[1m⚠️ Warning\033[0m")
        print("  Add only trusted MCP servers — they can access your workspace and run actions on your behalf.")
        
        # Quick start
        print("\n\033[1m🚀 Getting Started\033[0m")
        print("  1. Import servers (option 2) or add interactively (option 3)")
        print("  2. View tools (option 6)")
        print("  3. Use CODA, now equipped with your MCP servers!")
        
        # Best practices
        print("\n\033[1m✨ Tip\033[0m")
        print("  Keep it lean — enable only the MCP servers you need (ideally 1 to 3).")
        
        # Status
        print("\n\033[1m📋 Support Status\033[0m")
        print("  ✅ Local (STDIO) and Remote (HTTP) servers")
        print("  🚧 OAuth servers (coming soon)")
        
        # Links
        print("\n\033[1m📚 Resources\033[0m")
        print(" Official MCP Docs: \033[34mhttps://modelcontextprotocol.io\033[0m")
        print(" Server Registry: \033[34mhttps://github.com/modelcontextprotocol/servers\033[0m")

        print("\nNote: To turn off MCP in CODA, disable the 'mcp_execute' tool in the /tools menu.")
        
        input("\nPress Enter to continue...")
