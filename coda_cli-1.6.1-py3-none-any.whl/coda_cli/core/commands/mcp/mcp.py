from typing import List, Callable
from coda_cli.core.commands.base import Command
from coda_cli.core.commands.mcp.ui import MCPManager
from coda_cli.core.commands.tools.utils import update_agent_tools
from loguru import logger


class MCPCommand(Command):
    """Implementation of the /mcp command for MCP server management."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/mcp"]
    
    def description(self) -> str:
        """Return command description."""
        return "Manage MCP (Model Context Protocol) servers"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []
    
    def execute(self, args) -> bool:
        """
        MCP server management command.
        
        Provides an interactive interface for managing MCP (Model Context Protocol) servers,
        including adding, removing, testing, and configuring servers.
        
        Args:
            args: Command arguments (not used in this implementation)
            
        Returns:
            bool: Always returns True to continue CLI operation
        """
        # The /mcp menu has a hard-dependency on the agent initialization, so we have to block until it's finished
        if not self.cli.wait_for_agent_initialization():
            # Finish CLI execution on agent initialization failure
            return False

        try:
            # Initialize MCP manager with current session state and agent update callback
            mcp_manager = MCPManager(
                cli=self.cli,
                agent_update_callback=update_agent_tools,
                session_manager=self.cli.session_manager
            )

            # Run the interactive MCP management interface
            mcp_manager.run_interactive_session()

            # Auto-save session after MCP operations
            self.cli._auto_save_if_needed()

            return True

        except Exception as e:
            logger.error(f"Error in MCP command: {e}")
            print(f"\033[1;31mError in MCP management: {e}\033[0m")
            return True
