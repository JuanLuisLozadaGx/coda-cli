from typing import List, Dict, Any
from abc import ABC, abstractmethod
from coda_cli.core.commands.base import Command

class CommandRegistry:
    """
    Registry for CLI commands.
    
    This class manages command registration, instantiation, and lookup.
    """
    
    def __init__(self):
        """Initialize an empty command registry."""
        self.commands = {}  # Maps command aliases to command classes
    
    def register_command(self, command_class: Command):
        """
        Register a command class with the registry.
        
        Args:
            command_class: The command class to register
        """
        # Create a temporary instance to get metadata
        temp_instance = command_class()
        for alias in temp_instance.aliases():
            self.commands[alias] = command_class
    
    def register_commands(self, command_classes: List[Command]):
        """
        Register multiple command classes at once.
        
        Args:
            command_classes: List of command classes to register
        """
        for command_class in command_classes:
            self.register_command(command_class)
    
    def get_command(self, alias, cli=None):
        """
        Get a command instance for the given alias.
        
        Args:
            alias: The command alias to look up
            cli: The CLI instance to pass to the command
            
        Returns:
            Command: An instantiated command, or None if not found
        """
        command_class = self.commands.get(alias)
        if command_class:
            return command_class(cli)
        return None
    
    def get_all_commands(self, cli=None):
        """
        Get all registered commands as instances.
        
        Args:
            cli: The CLI instance to pass to the commands
            
        Returns:
            Dict[str, Command]: A dictionary mapping aliases to command instances
        """
        result = {}
        # Use a set to track which command classes we've seen
        seen_classes = set()
        
        for alias, command_class in self.commands.items():
            # Only create one instance per class
            if command_class not in seen_classes:
                command = command_class(cli)
                seen_classes.add(command_class)
                # Add all aliases for this command
                for cmd_alias in command.aliases():
                    result[cmd_alias] = command
        
        return result
    
    def get_commands_metadata(self):
        """
        Get metadata for all registered commands.
        
        Returns:
            Dict[Tuple[str], Dict]: A dictionary mapping command aliases to metadata
        """
        result = {}
        # Use a set to track which command classes we've seen
        seen_classes = set()
        
        for alias, command_class in self.commands.items():
            # Only process each command class once
            if command_class not in seen_classes:
                seen_classes.add(command_class)
                
                # Create a temporary instance to get metadata
                temp_instance = command_class()
                metadata = temp_instance.get_metadata()
                
                # Create a tuple of all aliases for this command
                aliases_tuple = tuple(temp_instance.aliases())
                
                # Store metadata with aliases as key
                result[aliases_tuple] = {
                    "description": metadata["description"],
                    "arguments": metadata["arguments"],
                    "command_class": metadata["command_class"]
                }
        
        return result