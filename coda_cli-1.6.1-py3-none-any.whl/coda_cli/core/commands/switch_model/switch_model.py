import os
from typing import List

from coda_cli.config.constants import CLIENT_NAME
from coda_cli.config.env_config import CLIEnvConfig
from coda_core.config.env_config import EnvConfig
from coda_core.config.settings import SETTINGS
from coda_core.core.models.schemas import Model
from coda_core.core.models.utils import is_model_supported
from coda_cli.core import ui
from coda_cli.core.commands.base import Command
from coda_cli.core.utils.utils import get_yes_no_input
from coda_core.core.utils.configuration import update_default_model

try:
    from coda_core.core.models.utils import get_model_reasoning_efforts, normalize_reasoning_effort
except ImportError:
    from coda_cli.core.utils.reasoning_utils import normalize_reasoning_effort

    def get_model_reasoning_efforts(model_obj: object) -> List[str]:
        """
        Resolve reasoning efforts from model metadata with fallback heuristics.

        Args:
            model_obj: Provider model metadata object.

        Returns:
            Available reasoning efforts including ``none``.
        """
        full_name = str(getattr(model_obj, "full_name", "") or "").lower()
        model_name = str(getattr(model_obj, "name", "") or "").lower()
        provider_name = full_name.split("/", maxsplit=1)[0] if "/" in full_name else ""

        if provider_name == "openai" and model_name.startswith("gpt-5"):
            return ["none", "minimal", "low", "medium", "high"]

        if "claude" in model_name and provider_name in {"anthropic", "vertex_ai", "bedrock"}:
            return ["none", "low", "medium", "high"]

        return ["none"]

try:
    from coda_core.core.utils.configuration import update_default_reasoning_effort
except ImportError:
    def update_default_reasoning_effort(effort: str) -> bool:
        """
        Persist default reasoning effort when core helper is unavailable.

        Args:
            effort: Reasoning effort to persist.

        Returns:
            True if persisted successfully, otherwise False.
        """
        normalized_effort = _to_canonical_reasoning_effort(effort)
        if normalized_effort is None:
            return False

        env_key = getattr(EnvConfig, "CODA_DEFAULT_REASONING_EFFORT", None)
        if env_key is not None:
            SETTINGS.set_env_var(env_key, normalized_effort)
        else:
            # Compatibility path for older coda-core enum surfaces.
            SETTINGS.set_env_var(
                CLIEnvConfig.CODA_CLI_DEFAULT_REASONING_EFFORT,
                _to_display_reasoning_effort(normalized_effort),
                client_name=CLIENT_NAME,
            )
            os.environ["CODA_DEFAULT_REASONING_EFFORT"] = normalized_effort
        return True


def _to_display_reasoning_effort(effort: str) -> str:
    """
    Convert canonical reasoning effort values into user-facing labels.

    Args:
        effort: Canonical reasoning effort value.

    Returns:
        User-facing reasoning effort label.
    """
    if effort == "none":
        return "default"
    return effort


def _to_canonical_reasoning_effort(value: str | None) -> str | None:
    """
    Normalize and map user-facing reasoning effort aliases to canonical values.

    Args:
        value: Raw user-facing value.

    Returns:
        Canonical reasoning effort value, or ``None`` when invalid.
    """
    if not isinstance(value, str):
        return None

    normalized_value = value.strip().lower()
    if normalized_value == "default":
        return "none"

    return normalize_reasoning_effort(normalized_value)


class SwitchModelCommand(Command):
    """Implementation of the /switch-model command to select a different LLM model."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/switch-model", "/sm"]
    
    def description(self) -> str:
        """Return command description."""
        return "Switch to a different LLM model"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []

    @staticmethod
    def _get_reasoning_effort_env_key() -> object | None:
        """
        Get the reasoning-effort env enum key when available.

        Returns:
            EnvConfig member for reasoning effort, or ``None`` for older coda-core versions.
        """
        return getattr(EnvConfig, "CODA_DEFAULT_REASONING_EFFORT", None)

    @staticmethod
    def _persist_cli_reasoning_effort(effort: str) -> None:
        """
        Persist reasoning effort in CLI-scoped settings for upgrade-safe UX.

        Args:
            effort: Canonical or alias reasoning effort value.
        """
        normalized_effort = _to_canonical_reasoning_effort(effort)
        if normalized_effort is None:
            return

        cli_value = _to_display_reasoning_effort(normalized_effort)
        SETTINGS.set_env_var(
            CLIEnvConfig.CODA_CLI_DEFAULT_REASONING_EFFORT,
            cli_value,
            client_name=CLIENT_NAME,
        )
        os.environ["CODA_DEFAULT_REASONING_EFFORT"] = normalized_effort

    def _select_reasoning_effort(self, model_obj: Model) -> str:
        """
        Prompt the user to select a reasoning effort for the selected model.

        Args:
            model_obj: Model object from provider metadata.

        Returns:
            Selected reasoning effort value.
        """
        available_efforts = get_model_reasoning_efforts(model_obj)
        display_efforts = [_to_display_reasoning_effort(effort) for effort in available_efforts]
        env_key = self._get_reasoning_effort_env_key()
        if env_key is not None:
            env_var_name = env_key.value if hasattr(env_key, "value") else str(env_key)
            current_effort_raw = os.getenv(env_var_name)
        else:
            current_effort_raw = None

        if not isinstance(current_effort_raw, str) or not current_effort_raw:
            current_effort_raw = SETTINGS.get_env_var(
                CLIEnvConfig.CODA_CLI_DEFAULT_REASONING_EFFORT,
                client_name=CLIENT_NAME,
            )
        if not isinstance(current_effort_raw, str) or not current_effort_raw:
            current_effort_raw = os.getenv("CODA_DEFAULT_REASONING_EFFORT", "default")

        current_effort = _to_canonical_reasoning_effort(current_effort_raw)
        default_effort = current_effort if current_effort in available_efforts else "none"
        default_effort_display = _to_display_reasoning_effort(default_effort)

        if available_efforts == ["none"]:
            print("\n\033[2mThis model does not support configurable reasoning effort. Using 'default'.\033[0m")
            return "none"

        print("\n\033[1;36mReasoning Effort\033[0m")
        print("\033[1;36m================\033[0m")
        for index, effort in enumerate(display_efforts, start=1):
            marker = " \033[1;32m[Default]\033[0m" if effort == default_effort_display else ""
            print(f"  \033[1;36m{index:2d}.\033[0m {effort}{marker}")

        while True:
            selection = input(
                f"\n\033[1mEnter reasoning effort [default: {default_effort_display}]: \033[0m"
            ).strip().lower()

            if not selection:
                return default_effort
            if selection.isdigit():
                selection_index = int(selection)
                if 1 <= selection_index <= len(available_efforts):
                    return available_efforts[selection_index - 1]
            if (selected_effort := _to_canonical_reasoning_effort(selection)) in available_efforts:
                return selected_effort
            if selection == "q":
                return default_effort

            ui.display_error_message(
                f"Invalid reasoning effort selection: {selection}. Please try again."
            )

    def execute(self, args) -> bool:
        """
        Display available LLM models and allow the user to select one.
        
        This command shows a paginated list of available models grouped by provider,
        and allows the user to select a model to use for future interactions.
        
        Args:
            args: Command arguments (not used)
            
        Returns:
            bool: Always returns True to continue CLI execution
        """
        # Get current model info
        current_provider = self.cli.shared_state.provider_name
        current_model = self.cli.shared_state.model_name
        current_full_name = f"{current_provider}/{current_model}"
        
        print("\033[1;36mFetching available models... this may take a few seconds\033[0m")
        
        try:
            # Get all providers and their models
            full_info = self.cli.shared_state.geai_client.get_full_info()

            # Delay the agent-blocking until we did the API call to GEAI
            # The /sm menu has a hard-dependency on the agent initialization, so we have to block until it's finished
            if not self.cli.wait_for_agent_initialization(with_animations=False):
                # Finish CLI execution on agent initialization failure
                return False

            # Flatten the model list for pagination
            all_models = []
            for provider_with_models in full_info.providers_with_models:
                provider = provider_with_models.provider
                # Add provider as a header
                all_models.append(("provider", provider.name))
                
                # Filter to only include supported models
                supported_models = [model for model in provider_with_models.models if is_model_supported(model)]
                
                # Sort models by name
                for model in sorted(supported_models, key=lambda x: x.name):
                    all_models.append(("model", (provider.name, model)))
            
            if not all_models:
                print("No models found. Please check your connection to the API.")
                return True
                
            # Pagination settings
            page_size = 20
            total_pages = (len(all_models) + page_size - 1) // page_size
            current_page = 1
            
            while True:
                # Display header with pagination info
                ui.display_model_selector_header(current_full_name, current_page, total_pages)
                
                # Calculate page bounds
                start_idx = (current_page - 1) * page_size
                end_idx = min(start_idx + page_size, len(all_models))
                
                # Display models for current page
                model_indices = {}  # Map display index to (provider_name, model_name)
                display_idx = 1
                
                for i in range(start_idx, end_idx):
                    item_type, item_data = all_models[i]
                    
                    # If the first item is not a provider, render the item's provider
                    if i == start_idx and item_type != "provider":
                        provider_name, _ = item_data 
                        ui.display_provider_header(provider_name)
                    
                    # If a provider is the last item to render, avoid rendering it and leave it for the next page
                    if i == end_idx - 1 and item_type == "provider":
                        continue

                    if item_type == "provider":
                        ui.display_provider_header(item_data)
                    else:
                        provider_name, model = item_data # (str, ModelSchema)
                        
                        model_indices[display_idx] = (provider_name, model)
                        
                        # Check if this is the current model
                        full_name = model.full_name
                        is_current = (full_name == current_full_name)
                        
                        # Format and display the model entry
                        entry = ui.format_model_entry(
                            idx=display_idx,
                            model_name=model.name,
                            context_size=model.context_window,
                            max_output=model.max_output_tokens,
                            is_current=is_current,
                            reasoning_efforts=get_model_reasoning_efforts(model),
                        )
                        print(entry)
                        display_idx += 1
                
                # Display navigation options
                ui.display_navigation_options()
                
                # Get user input
                selection = input("\n\033[1mEnter choice: \033[0m").strip().lower()
                
                if selection == 'q':
                    ui.display_model_selection_cancelled()
                    break
                elif selection == 'n':
                    if current_page < total_pages:
                        current_page += 1
                    continue
                elif selection == 'p':
                    if current_page > 1:
                        current_page -= 1
                    continue
                elif selection.isdigit():
                    idx = int(selection)
                    if idx in model_indices:
                        provider_name, model_obj = model_indices[idx]

                        # Get the model's full name, which also has the provider name
                        new_provider, new_model = model_obj.full_name.split("/")
                        selected_reasoning_effort = self._select_reasoning_effort(model_obj)
                        
                        # Update shared state with model context window and max output tokens
                        # Pass the main_agent if it exists to update its LLM as well
                        main_agent = self.cli.shared_state.main_agent if hasattr(self.cli.shared_state, 'main_agent') else None
                        success = self.cli.shared_state.update_model_settings(
                            provider_name=new_provider,
                            model_name=new_model,
                            context_window=model_obj.context_window,
                            max_output_tokens=model_obj.max_output_tokens,
                            single_agent=main_agent
                        )
                        
                        if success:
                            reasoning_saved = update_default_reasoning_effort(selected_reasoning_effort)
                            self._persist_cli_reasoning_effort(selected_reasoning_effort)
                            if not reasoning_saved:
                                print("\033[1;33mWarning: failed to update default reasoning effort.\033[0m")

                            # Auto-save if needed
                            self.cli._auto_save_if_needed()
                            
                            # Display success message
                            ui.display_model_change_success(new_provider, new_model)
                        
                            # Ask if user wants to make this the default model
                            prompt = f"\nWould you like to set this as the default model system-wide?"
                            make_default = get_yes_no_input(prompt, default="n")
                            
                            if make_default:
                                if update_default_model(new_provider, new_model):
                                    print(f"\033[1;32mDefault model updated to {new_provider}/{new_model}\033[0m")
                                else:
                                    print(f"\033[1;31mFailed to update default model. Please check logs for details.\033[0m")
                        else:
                            # Display error message
                            print(f"\033[1;31mError: Failed to update model to {new_provider}/{new_model}.\033[0m")
                            print("\033[1;31mThe model settings were not changed.\033[0m")
                        break
                    else:
                        ui.display_error_message(f"Invalid selection: {selection}. Please try again.")
                else:
                    ui.display_error_message(f"Invalid input: {selection}. Please try again.")
        
        except Exception as e:
            print(f"Error fetching models: {e}")
        
        return True
