"""Module for handling upgrade operations in the CODA CLI."""
import platform
from typing import List

from loguru import logger

from coda_core.config.env_config import EnvConfig
from coda_core.config.settings import SETTINGS
from coda_core.config.system_info import SystemInfo
from coda_core.config.upgrade.executor import execute_upgrade_with_backup
from coda_core.config.upgrade.version import get_current_version
from coda_core.config.upgrade.repository import (
    check_for_updates,
    prompt_for_credentials_and_validate,
    CredentialStatus
)
from coda_core.config.upgrade.constants import (
    UPGRADABLE_PACKAGE_DISTRIBUTION_NAME,
    DEFAULT_EXTRAS
)

from coda_cli.core.commands.base import Command
from coda_cli.core.commands.upgrade import ui
from coda_cli.core.commands.upgrade.state_manager import UpgradeStateManager
from coda_cli.core.commands.upgrade.utils import check_for_updates_at_startup


class UpgradeCommand(Command):
    """Implementation of the /upgrade command to upgrade the CLI."""

    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/upgrade", "/auto-upgrade", "/au"]

    def description(self) -> str:
        """Return command description."""
        return "Upgrade CODA to the latest version"

    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []

    # pylint: disable=too-many-return-statements
    def execute(self, args) -> bool:
        """
        Handles the '/upgrade' command to upgrade the CLI to the latest version.

        This command performs the following steps:
        1. Checks the currently installed version and confirms the upgrade with the user.
        2. Saves the current session state before proceeding with the upgrade.
        3. Validates repository credentials, prompting the user for a token if necessary.
        4. Executes the upgrade process with backup and verification.
        5. Displays the result of the upgrade process.

        Args:
            args (str): The arguments provided with the '/upgrade' command,
                        expected to be empty.

        Returns:
            bool:
                - False if the upgrade is successful, indicating the CLI should exit.
                - True if the upgrade is canceled or fails, allowing the CLI to continue running.
        """
        # Execute upgrade on Windows is not allowed. This command shouldn't be executed on Windows.
        if (platform.system().lower() == "windows" and
                SystemInfo.get_shell_process_name() != "wsl.exe"):
            # Display message to allow users to manually upgrade
            user = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_USERNAME)
            # No defaults
            token = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_TOKEN) or "<AZURETOKEN>"
            host = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_HOST)
            org = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_ORG)
            project = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_PROJECT)
            feed = SETTINGS.get_env_var(EnvConfig.CODA_PYPI_REPO_FEED)
            # Hardcode the feed to avoid users from getting QA packages
            install_command = (
                "pip install --upgrade "
                "--index-url "
                f"\"https://{user}:{token}@{host}/{org}/{project}/_packaging/{feed}/pypi/simple/\" "
                "--extra-index-url "
                "\"https://pypi.org/simple/\" "
                f"\"{UPGRADABLE_PACKAGE_DISTRIBUTION_NAME}[{DEFAULT_EXTRAS}]\""
            )
            print(
                "\033[1;31mUpgrade is temporarily unavailable on Windows.\033[0m\n"
                f"Try upgrading manually by closing CODA and running:\n{install_command}"
            )
            return True

        # Step 1: Check if updates are available
        current_version = get_current_version()

        ui.display_upgrade_checking_for_updates()
        update_info = check_for_updates()

        # If there was an error checking for updates
        if update_info.get('error'):
            error_message = f"Error checking for updates: {update_info['error']}"
            logger.error(error_message)
            print(f"\033[1;31m{error_message}\033[0m")
            return True

        # If credentials are invalid or missing, prompt for new ones
        credential_status = update_info.get('credential_status')
        if credential_status in (CredentialStatus.INVALID, CredentialStatus.MISSING):
            # Display appropriate initial message based on status
            if credential_status == CredentialStatus.INVALID:
                ui.display_upgrade_credentials_invalid_command()
            else:  # MISSING
                ui.display_upgrade_credentials_missing_command()

            ui.display_upgrade_credentials_prompt()
            _, _, credential_status = prompt_for_credentials_and_validate()

            if credential_status == CredentialStatus.VALID:
                # Retry checking for updates with the validated credentials
                ui.display_upgrade_retrying_with_credentials()
                update_info = check_for_updates()
            else:
                ui.display_upgrade_credentials_invalid()
                return True

        # If no update is available, inform the user and exit
        if not update_info.get('update_available'):
            print(
                f"Already at the latest version: {current_version}. "
                "No upgrade needed."
            )
            # Reset update flag because no update is available
            UpgradeStateManager.set_new_version_available(False)
            return True

        # Step 2: Confirm upgrade with user
        latest_version = update_info.get('latest_version') or ""
        if not ui.display_update_available(current_version, latest_version):
            print("Upgrade cancelled.")
            return True

        # Step 2: Save the current session state before upgrading
        if self.cli.session_manager and self.cli.session_manager.current_session:
            ui.display_upgrade_saving_session()

            # The saving of the shared_state can cause conflicts if the agent is mid-initialization
            # so we need to block prior to the saving
            if not self.cli.wait_for_agent_initialization(with_animations=False):
                # Finish CLI execution on agent initialization failure
                return False

            self.cli.session_manager.save_session(
                shared_state=self.cli.shared_state,
                client_state=self.cli.cli_state,
                client_type=self.cli.cli_state.CLIENT_TYPE
            )

        # Step 3: Execute the upgrade with backup and verification
        ui.display_upgrade_in_progress()

        # Execute upgrade with backup but without including any specific directories
        # since we don't want to backup user work files
        result = execute_upgrade_with_backup(include_dirs=None)

        # Step 4: Display the result
        ui.display_upgrade_result(result)

        update_was_successful = result.get("success")
        if update_was_successful:
            # If upgrade was successful, reset update available flag (set it to False)
            UpgradeStateManager.set_new_version_available(False)

        # Return False to exit if successful, True to continue if failed
        return not update_was_successful

    def check_for_updates(self) -> bool:
        """
        Check for updates at startup if repository credentials are configured.
        If updates are available, prompt the user to upgrade.

        This method is called before session initialization, so there's no current
        session to save before upgrading.

        Returns:
            bool: True to continue startup, False to exit after startup
        """
        # Check for updates if not in Windows or if WSL is used
        if (not platform.system().lower() == "windows" or
                SystemInfo.get_shell_process_name() == "wsl.exe"):
            # Check for updates first, before session selection
            # if returns False, exit after startup
            if not check_for_updates_at_startup(self.cli):
                return False

        return True
