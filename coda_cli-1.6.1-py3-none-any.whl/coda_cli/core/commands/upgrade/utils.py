"""Utilities for handling update checks and upgrades at startup."""

from loguru import logger
from coda_core.config.upgrade.executor import execute_upgrade_with_backup
from coda_core.config.upgrade.repository import check_for_updates, CredentialStatus

from coda_cli.core.commands.upgrade.state_manager import UpgradeStateManager
from coda_cli.core.commands.upgrade import ui as upgrade_ui
from coda_cli.core import ui


def check_for_updates_at_startup(cli) -> bool:
    """Check for updates at startup and optionally perform an upgrade.

    This function performs the following operations:
    1. Checks if updates are available from the repository
    2. Handles credential validation (missing or invalid)
    3. Prompts the user to upgrade if an update is available
    4. Executes the upgrade with backup if user accepts
    5. Offers the user to exit or continue after successful upgrade

    Note:
        This method is called before session initialization, so typically there's
        no current session to save before upgrading. However, it checks and saves
        the session if one exists.

    Args:
        cli: The CLI instance containing session manager and state objects.

    Returns:
        bool: True to continue with normal startup, False to exit the application.
            Returns False only when user chooses to exit after a successful upgrade.

    Raises:
        Exceptions are caught and logged; the function returns True to allow
        startup to continue even if the update check fails.
    """
    try:
        # Check for updates
        logger.info("Checking for updates at startup")
        upgrade_ui.display_upgrade_checking_for_updates()
        update_result = check_for_updates()

        # If credentials missing or invalid, skip update check with user notice
        status = update_result.get('credential_status', CredentialStatus.NOT_REQUIRED)
        if status in (CredentialStatus.MISSING, CredentialStatus.INVALID):
            if status == CredentialStatus.MISSING:
                logger.info("Repository credentials not configured, skipping update check")
                upgrade_ui.display_update_check_failed(
                    reason="repository credentials are required to access the update server."
                )
            else:  # If status is INVALID
                logger.info("Repository credentials are invalid, skipping update check")
                upgrade_ui.display_update_check_failed(
                    reason="the configured repository credentials are invalid."
                )

            upgrade_ui.display_manual_upgrade_instruction()
            _ = upgrade_ui.prompt_continue_input()
            return True

        # If error occurred, log it but continue
        if update_result.get('error'):
            logger.warning(f"Error checking for updates: {update_result['error']}")
            return True

        if not update_result.get('update_available', False):
            # No update available, disable automatic update for next startup.
            # This might happen when available updates are detected but then installed
            # by another means (e.g., manually).
            UpgradeStateManager.set_new_version_available(False)
            logger.info("No updates available")
            return True

        current_version = update_result['current_version']
        latest_version = update_result['latest_version']

        logger.info(f"Update available: {current_version} -> {latest_version}")

        # Prompt user to upgrade
        if not upgrade_ui.display_update_available(current_version, latest_version):
            logger.info("User declined upgrade")
            return True

        # Save the current session state before upgrading (unlikely to exist since
        # this runs before session initialization, but check just in case)
        if (hasattr(cli, 'session_manager') and cli.session_manager and
                cli.session_manager.current_session):
            upgrade_ui.display_upgrade_saving_session()
            cli.session_manager.save_session(
                shared_state=cli.shared_state,
                client_state=cli.cli_state,
                client_type=cli.cli_state.CLIENT_TYPE
            )

        # Execute the upgrade
        upgrade_ui.display_upgrade_in_progress()

        # Execute upgrade with backup but without including any specific directories
        # since the user is just starting and hasn't done any work yet
        result = execute_upgrade_with_backup(include_dirs=None)

        # Display the result
        upgrade_ui.display_upgrade_result(result)

        # If upgrade was successful, ask the user if they want to exit now
        if result.get("success"):
            UpgradeStateManager.set_new_version_available(False)
            logger.info("Upgrade successful, prompting user to exit")
            print(
                "\nThe upgrade was successful. "
                "You need to restart CODA to use the new version."
            )
            exit_now = input("Would you like to exit now? (y/n): ").lower() == 'y'
            if exit_now:
                logger.info("User chose to exit after upgrade")
                ui.goodbye()
                return False  # Signal to exit

            logger.info("User chose to continue with current session")
        else:
            # Upgrade failed, but continue with startup anyway
            logger.warning("Upgrade failed, continuing with startup")

    except Exception as exc:  # pylint: disable=broad-exception-caught
        logger.exception(f"Unexpected error during update check: {exc}")

    return True
