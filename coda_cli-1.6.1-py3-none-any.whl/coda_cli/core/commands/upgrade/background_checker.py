"""Background update checker that runs update checks asynchronously."""

import threading
from loguru import logger

from coda_core.config.upgrade.repository import check_for_updates
from coda_cli.core.commands.upgrade.state_manager import UpgradeStateManager


class BackgroundUpdateChecker:
    """
    Background update checker that runs update checks asynchronously
    and sets the CODA_UPGRADE_AVAILABLE environment variable based on results.
    """

    def __init__(self):
        self.thread = None

    def start_background_check(self):
        """Start background update check in a daemon thread"""
        if self._is_running():
            logger.debug("Background update check already running")
            return

        self.thread = threading.Thread(target=self._check_updates, daemon=True)
        self.thread.start()
        logger.debug("Started background update check")

    def join(self, timeout: float = 0.5) -> bool:
        """
        Wait for the background check thread to complete.

        Args:
            timeout (float): Maximum time to wait in seconds. Defaults to 0.5 seconds.

        Returns:
            bool: True if thread completed, False if timeout was reached.
        """
        try:
            if self._is_running():
                self.thread.join(timeout=timeout)
                return not self._is_running()
            return True
        except (Exception, RuntimeError) as e:
            logger.exception(f"Error during background update cleanup: {e}")
            return False


    def _check_updates(self):
        """Background update check logic"""
        try:
            logger.debug("Running background update check")
            # Run the existing check_for_updates logic
            update_result = check_for_updates()

            # Set environment variable based on result
            if update_result.get('update_available', False):
                UpgradeStateManager.set_new_version_available(True)
            else:
                UpgradeStateManager.set_new_version_available(False)

        except Exception as exc:  # pylint: disable=broad-exception-caught
            # On error, set to false and log the error
            logger.warning(f"Background update check failed: {exc}")
            UpgradeStateManager.set_new_version_available(False)

    def _is_running(self) -> bool:
        """Check if background thread is still running"""
        return self.thread is not None and self.thread.is_alive()
