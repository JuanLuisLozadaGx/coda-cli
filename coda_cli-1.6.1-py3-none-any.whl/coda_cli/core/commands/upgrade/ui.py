from prompt_toolkit.formatted_text import HTML
from prompt_toolkit import print_formatted_text

from coda_cli.config.constants import SUPPORT_EMAIL
from coda_cli.core.utils.utils import get_yes_no_input


def display_update_available(current_version: str, latest_version: str) -> bool:
    """
    Display a message indicating that an update is available and prompt for confirmation.
    
    Args:
        current_version (str): The current version of CODA
        latest_version (str): The latest available version
        
    Returns:
        bool: True if the user confirms the upgrade, False otherwise
    """
    print_formatted_text(HTML(f"\n<ansibrightblue>🔄 Update available: <ansibrightyellow>{current_version}</ansibrightyellow> → <ansibrightgreen>{latest_version}</ansibrightgreen></ansibrightblue>"))
    return get_yes_no_input("Do you want to upgrade CODA AI to the latest version?", default="yes")


def display_update_check_failed(reason: str) -> None:
    """
    Display a message when update check fails.
    
    Args:
        reason (str): The reason for the failure (e.g., "missing credentials", "invalid credentials")
    """
    print_formatted_text(HTML(f'<ansiyellow>Could not check for updates at startup: {reason}.</ansiyellow>'))


def display_manual_upgrade_instruction() -> None:
    """
    Display instruction to use manual upgrade command.
    """
    print_formatted_text(HTML('<ansibrightblue>To upgrade manually and update your credentials, run the \'/upgrade\' command.</ansibrightblue>'))


def prompt_continue_input() -> str:
    """
    Prompt user to press Enter to continue and return input.
    
    Returns:
        str: User input (usually empty from pressing Enter)
    """
    return input("Press Enter to continue...")


def display_upgrade_checking_for_updates() -> None:
    """
    Display a message indicating that the system is checking for updates.
    """
    print_formatted_text(HTML("<ansibrightblue>🔍 Looking for available updates...</ansibrightblue>"))


def display_upgrade_retrying_with_credentials() -> None:
    """
    Display a message indicating that the system is retrying to look for available updates with provided credentials.
    """
    print_formatted_text(HTML("<ansibrightblue>🔍 Retrying to look for available updates with provided credentials...</ansibrightblue>"))


def display_upgrade_start(current_version: str) -> bool:
    """
    Display upgrade start information and prompt for confirmation.
    
    Args:
        current_version (str): The current version of CODA AI
        
    Returns:
        bool: True if the user confirms the upgrade, False otherwise
    """
    print_formatted_text(HTML(f"<ansibrightblue>🔄 Current version: <ansibrightyellow>{current_version}</ansibrightyellow></ansibrightblue>"))
    return get_yes_no_input("Do you want to upgrade CODA to the latest version?", default="yes")


def display_upgrade_saving_session() -> None:
    """
    Display a message indicating that the session state is being saved.
    """
    print_formatted_text(HTML("<ansibrightblue>💾 Saving current session state...</ansibrightblue>"))


def display_upgrade_credentials_prompt() -> None:
    """
    Display a message indicating that repository credentials are required.
    """
    print_formatted_text(HTML("\n<ansibrightblue>🔑 Valid repository credentials are required for upgrading.</ansibrightblue>"))


def display_upgrade_credentials_invalid() -> None:
    """
    Display an error message indicating that the provided credentials are invalid.
    """
    print_formatted_text(HTML("\n<ansired>❌ Invalid credentials. Unable to proceed with upgrade.</ansired>"))
    print_formatted_text(HTML(f"<ansiyellow>Please try again or contact support at {SUPPORT_EMAIL}.</ansiyellow>"))


def display_upgrade_credentials_invalid_command() -> None:
    """
    Display a warning message indicating that the provided credentials are invalid for the upgrade command.
    """
    print_formatted_text(HTML("<ansiyellow>Invalid repository credentials detected. New credentials are required to proceed with the upgrade.</ansiyellow>"))


def display_upgrade_credentials_missing_command() -> None:
    """
    Display a warning message indicating that repository credentials are missing for the upgrade command.
    """
    print_formatted_text(HTML("<ansiyellow>Repository credentials are required to check for and install updates.</ansiyellow>"))


def display_upgrade_in_progress() -> None:
    """
    Display a message indicating that the upgrade is in progress.
    """
    print_formatted_text(HTML("<ansibrightblue>🚀 Upgrading CODA...</ansibrightblue>"))


def display_upgrade_result(result: dict) -> None:
    """
    Display the result of the upgrade process.
    
    Args:
        result (dict): The result of the upgrade process, containing success status, message,
                      and additional information like version details, backup info, and verification status.
    """
    if result["success"]:
        print_formatted_text(HTML(f"\n<ansigreen>✅ {result['message']}</ansigreen>"))
        
        # Check if an actual upgrade was performed
        upgrade_performed = result.get("upgrade_performed", True)
        if "verification" in result and result["verification"] == "skipped":
            # If verification was skipped, it means no upgrade was needed
            upgrade_performed = False
        
        # Only show upgrade information if an actual upgrade was performed
        if upgrade_performed:
            # Show version information if available
            if "old_version" in result and "new_version" in result:
                print_formatted_text(HTML(f"<ansibrightcyan>Upgraded from {result['old_version']} to {result['new_version']}</ansibrightcyan>"))
            
            # Show verification status if available
            if "verification" in result and result["verification"] == "passed":
                print_formatted_text(HTML("<ansigreen>✅ Verification passed: The new version is functioning correctly</ansigreen>"))
            
            print_formatted_text(HTML("\n<ansibrightblue>CODA AI has been upgraded. Please restart CODA to use the new version.</ansibrightblue>"))
        
        # Always show backup information if available
        if "backup_dir" in result:
            print_formatted_text(HTML(f"<ansibrightblue>Backup created at: {result['backup_dir']}</ansibrightblue>"))
    else:
        print_formatted_text(HTML(f"\n<ansired>❌ {result['message']}</ansired>"))
        
        # Show error details if available
        if "error_type" in result:
            error_type = result["error_type"]
            print_formatted_text(HTML(f"<ansiyellow>Error type: {error_type}</ansiyellow>"))
        
        if "error_details" in result and result["error_details"]:
            print_formatted_text(HTML(f"<ansiyellow>Details: {result['error_details']}</ansiyellow>"))
        
        # Show restore information if available
        if "restored" in result:
            if result["restored"]:
                print_formatted_text(HTML("<ansigreen>✅ System was restored from backup</ansigreen>"))
            else:
                print_formatted_text(HTML("<ansired>❌ System could not be restored from backup</ansired>"))
        
        print_formatted_text(HTML(f"\n<ansiyellow>Please try again or contact support at {SUPPORT_EMAIL}.</ansiyellow>"))
