"""Manages upgrade state using the core configuration system."""

from loguru import logger

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig


class UpgradeStateManager:
    """
    Manages the upgrade availability state using the core configuration system.

    This class provides a centralized way to manage the CODA_UPGRADE_AVAILABLE
    environment variable, which tracks whether a new version is available.
    """

    @staticmethod
    def set_new_version_available(available: bool):
        """
        Set the new version availability flag.

        Args:
            available (bool): Whether a new version is available or not.
        """
        try:
            value = str(available).lower()
            SETTINGS.set_env_var(EnvConfig.CODA_UPGRADE_AVAILABLE, value)
        except Exception as e:  # pylint: disable=broad-exception-caught
            logger.error(f"Failed to set {EnvConfig.CODA_UPGRADE_AVAILABLE.value}: {e}")

    @staticmethod
    def is_new_version_available() -> bool:
        """
        Check if a new version is available.

        Returns:
            bool: True if a new version is available, False otherwise.
        """
        try:
            value = SETTINGS.get_env_var(EnvConfig.CODA_UPGRADE_AVAILABLE)
            return value.lower() == 'true' if value else False
        except Exception as e:  # pylint: disable=broad-exception-caught
            logger.error(f"Failed to get {EnvConfig.CODA_UPGRADE_AVAILABLE.value}: {e}")
            return False
