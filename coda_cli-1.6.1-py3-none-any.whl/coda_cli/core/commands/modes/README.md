# Modes Module

## Overview and Purpose

The Modes module provides a command-line interface for switching between different operational modes within the CODA CLI. Each mode offers a distinct behavior set and tool configuration, allowing the CLI to adapt to different user workflows and requirements.

The primary purposes of the modes module are:

1. **User Interface**: Provide a simple command-line interface for users to view and select different operational modes.
2. **Mode Management**: Interface with the coda_core ModeManager to activate and deactivate modes.
3. **Integration**: Integrate the mode system with the CLI command architecture.

The modes system enables CODA to adapt its behavior to specific tasks or workflows. For example, the Plan Mode enables specialized planning tools and changes the system prompt, while the Default Mode provides standard agent functionality.

## Architecture

### Component Diagram

The Modes module integrates with both coda_cli and coda_core components:

```mermaid
flowchart LR
    subgraph coda_cli
        ModesCommand --> UI["UI Functions"]
        ModesCommand --> Utils["Utility Functions"]
        Utils --> ErrorHandlers["Error Handlers"]
        Utils --> ModeOperations["Mode Operations"]
        Utils --> Interfaces["Interface Definitions"]
    end
    
    subgraph coda_core
        ModeManager --> Mode["Mode\n(Abstract Interface)"]
        Mode --> OtherModes
        Mode --> PlanningMode
    end
    
    ModesCommand -- uses --> ModeManager
    UI -- interacts --> Mode
    ModeOperations -- validates --> ModeManager
```

### Mode Command Flow

The following diagram illustrates the flow of execution when a user invokes the modes command:

```mermaid
sequenceDiagram
    participant User
    participant CLI
    participant CommandRegistry
    participant ModesCommand
    participant Utils
    participant UI
    participant ModeManager
    
    alt Direct mode activation
        User->>CLI: /modes plan
        CLI->>CommandRegistry: get_command("/modes")
        CommandRegistry-->>CLI: ModesCommand
        CLI->>ModesCommand: execute(["plan"])
        ModesCommand->>Utils: initialize_mode_manager()
        Utils->>ModeManager: new ModeManager()
        ModesCommand->>ModeManager: get_available_modes()
        ModesCommand->>ModesCommand: find plan mode key
        ModesCommand->>Utils: activate_mode(plan_mode_key)
        Utils->>ModeManager: select_mode(key)
        Note over ModeManager: activate Plan Mode
        Utils->>User: display status message
    else Standard mode selection
        User->>CLI: /modes
        CLI->>CommandRegistry: get_command("/modes")
        CommandRegistry-->>CLI: ModesCommand
        CLI->>ModesCommand: execute()
        ModesCommand->>Utils: initialize_mode_manager()
        Utils->>ModeManager: new ModeManager()
        ModesCommand->>Utils: select_mode()
        Utils->>UI: select_mode_with_ui()
        UI->>User: display mode list
        User->>UI: select mode
        UI-->>Utils: selected mode key
        Utils-->>ModesCommand: selected mode key
        ModesCommand->>Utils: activate_mode()
        Utils->>ModeManager: select_mode(key)
        Note over ModeManager: activate selected mode
        Utils->>User: display status message
    end
```

### Class Relationships

#### Command Base Class and ModesCommand

```mermaid
classDiagram
    class Command {
        <<Abstract Base Class>>
        -cli
        +get_metadata()
        +aliases()* 
        +description()*
        +arguments()*
        +execute()*
    }
    
    class ModesCommand {
        +aliases()
        +description()
        +arguments()
        +execute()
    }
    
    Command <|-- ModesCommand : inherits
```

#### ModeManager and Modes

```mermaid
classDiagram
    class ModeManager {
        -modes
        -current_mode_key
        -cli_instance
        +register_mode()
        +select_mode()
        +get_available_modes()
        +get_mode_by_key()
        +get_current_mode()
    }
    
    class Mode {
        <<Interface/Base>>
        +key
        +name
        +description
        +system_prompt
        +activate()
        +deactivate()
    }
        
    class PlanningMode {
    }
    
    ModeManager --> Mode : manages
    Mode <|-- PlanningMode : implements
```

#### Integration with CLI

```mermaid
classDiagram
    class CLI {
        -command_registry
        -mode_manager
        -shared_state
        +_handle_command()
        +run()
    }
    
    class CommandRegistry {
        -commands
        +register_command()
        +get_command()
    }
    
    class ModeManager {
        -modes
        -current_mode_key
        +register_mode()
        +select_mode()
    }
    
    class ModesCommand {
        +execute()
    }
    
    CLI --> CommandRegistry : contains
    CLI --> ModeManager : contains
    CommandRegistry --> ModesCommand : contains
```

#### Utility Classes

```mermaid
classDiagram
    class ErrorHandlers {
        +ModeError
        +ModeInitializationError
        +ModeSelectionError
        +ModeActivationError
        +handle_operation()
    }
    
    class ModeOperations {
        +initialize_mode_manager()
        +select_mode()
        +get_mode_name()
        +activate_mode()
    }
    
    class Interfaces {
        +ModeManagerProtocol
        +validate_mode_manager()
        +validate_cli_state()
        +validate_mode_key()
        +validate_user_input()
    }
    
    class UI {
        +display_mode_header()
        +format_mode_entry()
        +display_modes()
        +display_options()
        +get_user_choice()
        +map_choice_to_mode_key()
        +select_mode_with_ui()
    }
    
    ModeOperations --> ErrorHandlers : uses
    ModeOperations --> Interfaces : uses
    UI --> ErrorHandlers : uses
```

## Implementation Details

### ModesCommand

The `ModesCommand` class implements the Command interface and provides the user interface for switching between operational modes. The key methods are:

- **aliases()**: Returns the command aliases (`/modes`, `/mode`, `/m`)
- **description()**: Returns a description of the command
- **arguments()**: Returns ["plan", "p"] to support direct activation of Plan Mode
- **execute(args)**: Executes the modes command, handling mode manager initialization, mode selection, and mode activation

### UI Implementation

The UI implementation is contained in `ui.py` and provides a user-friendly interface for selecting modes. The UI module includes these key functions:

- **display_mode_header()**: Displays the formatted header
- **format_mode_entry()**: Formats and displays a single mode entry
- **display_modes()**: Displays all available modes and returns a mapping from indices to keys
- **display_options()**: Displays additional options (like quit)
- **get_user_choice()**: Gets the user's input
- **map_choice_to_mode_key()**: Maps the user's choice to a mode key
- **select_mode_with_ui()**: Orchestrates the UI interaction process

### Error Handling

The error handling is implemented in the `utils/error_handlers.py` module.



### Mode Operations

Mode operations are implemented in the `utils/mode_operations.py`. The Mode Manager Protocol defines a critical architectural pattern that ensures type safety and clean separation between the CLI layer and the core mode management functionality. This is implemented in the `utils/interfaces.py`. The Protocol interface is critical for the Plan Mode functionality:

1. **Mode Registration & Discovery**: The PlanningMode is registered with the ModeManager, which implements the ModeManagerProtocol.

2. **Mode Activation Flow**: When activating plan mode via `/modes plan`, the flow follows:
   ```
   User Command → ModesCommand → validate_mode_manager() → ModeManager.select_mode() → PlanningMode.on_activate()
   ```

3. **Validation at Each Step**: The protocol ensures safe operations:
   - Before initialization: Validates CLI state
   - Before selection: Validates mode manager implementation
   - Before activation: Validates mode key existence

#### Advantages of the Protocol Pattern

1. **Type Safety**
   - Ensures compile-time and runtime type checking
   - Catches implementation errors early
   - Provides clear interface contracts

2. **Decoupling**
   - CLI layer doesn't depend on concrete ModeManager implementation
   - Can swap implementations without changing CLI code
   - Enables testing with mock implementations

3. **Extensibility**
   - New mode managers can be created by following the protocol
   - Third-party extensions can integrate seamlessly
   - No inheritance required - just implement the interface

4. **Validation & Error Handling**
   - Built-in validation functions prevent runtime errors
   - Clear error messages via logging
   - Graceful degradation when components are missing

5. **Documentation as Code**
   - The Protocol serves as living documentation
   - Clear method signatures and return types
   - Self-documenting interface requirements



## Integration with CLI

The modes module integrates with the CLI in several ways:

1. **Command Registration**: ModesCommand is registered with the CommandRegistry in the CLI constructor.
2. **Mode Manager Initialization**: The CLI initializes the ModeManager and registers available modes.
3. **Default Mode Activation**: The CLI activates the default mode during startup.
4. **Tool Configuration**: The CLI configures tools based on the active mode.
5. **Mode Indicator in Prompt**: The CLI shows the current mode in the prompt.

## Available Modes

The CLI initializes one mode:

### Plan Mode (planning_mode.py)

The Plan Mode enables structured planning functionality. It activates the "Planning" tool and temporarily disables certain tools (edit, replace, bash) until a plan is approved. This mode provides:

1. **Structured Planning**: Creates organized, Planning plans with tracking
2. **Plan Storage**: Stores plans as both markdown and JSON files in ~/.coda/plans directory
3. **Progressive Execution**: Supports both Planning and all-at-once execution modes
4. **Status Tracking**: Tracks progress of individual steps and overall plan status
5. **Tool Safety**: Temporarily disables potentially destructive tools until a plan is approved

The planning tool supports various actions including:
- create_plan: Create a new plan with structured data
- list/list_markdowns: List all available plans
- load: Load an existing plan
- update_plan: Update an existing plan
- approve_plan: Approve a plan to enable execution
- mark_step: Mark a step as completed, pending, in progress, or failed
- mark_plan_as_pending: use this tool ONLY when the user explicitly requests to create a new plan, to transition back to Plan Mode.


#### Planning Workflow

The Plan Mode follows this typical workflow:

1. **Plan Creation**: The agent creates a structured plan with numbered steps
2. **User Approval**: The user must explicitly approve the plan with "approve the plan" 
3. **Execution Mode Selection**: The user chooses between Planning or all-at-once execution
4. **Tool Enabling**: After approval, previously disabled tools (edit, replace, bash) are re-enabled
5. **Step Execution**: Steps are executed according to the chosen execution mode
6. **Status Tracking**: Each step is marked with appropriate status as execution proceeds

#### Execution Preferences

The planning tool supports two execution modes:

1. **Planning**: After completing each step, the agent pauses for user confirmation
2. **All-at-Once**: The agent executes all steps sequentially without stopping

## Mode Selection Workflow

The mode selection workflow involves the following steps:

1. **User invokes the modes command**: The user enters `/modes`, `/mode`, or `/m` (optionally with "plan" or "p" argument)
2. **Command lookup**: The CLI looks up the command in the CommandRegistry
3. **Command execution**: The CLI executes the ModesCommand.execute() method
4. **Mode manager initialization**: The command initializes the mode manager if needed
5. **Direct mode activation (optional)**: If the command was invoked with "plan" or "p" argument (e.g. `/modes plan`), the system directly activates the Plan Mode if available
6. **UI display (if no direct activation)**: The UI displays available modes with their names, descriptions, and current status
7. **User selection (if no direct activation)**: The user selects a mode by number or key
8. **Mode activation**: The command activates the selected mode
9. **Tool configuration**: The mode's activate() method configures the appropriate tools
10. **Feedback**: The user receives feedback about the mode activation


## Usage Examples

### Example 1: Using the Modes Command

```
⫸ /mode

Mode Selection
=============
  1. Plan Mode
     Mode for generating structured plans and organized execution steps.

Options:
  q. Return to main interface
Select mode: 1
⫸ [Plan Mode][draft] 
```

### Example 2: Direct Plan Mode Activation

```
⫸ /mode s
Press CTRL + C to exit the current mode and return to Standard Mode. Now you are in Plan Mode, currently in the draft phase. You can read files and provide feedback to help create a good plan. Once the plan is approved, the agent will have access to editing and code generation.
⫸ [Plan Mode][draft] 
```

### Example 3: Plan Execution Flow

```
⫸ /mode s
⫸ [Plan Mode][draft] Create a two step plan for: in the first step write a python script for a he
llo world. And a second script for creating a simple calculator.
Explain using a markdown file all the implementation details. DO not set environments I will do th
at. Do not add tests.
                 
I'll create a plan for you to write two Python scripts - a Hello World program and a simple calculator, along with documentation for both. Let me draft a plan for you.
                 
╭──────────────────────────────────────────────────────────╮
│ 🔧 Tool: create_plan                                     │
│ Creating a new plan with title: python_scripts_plan      │
╰──────────────────────────────────────────────────────────╯

✅ create_plan completed successfully
                 
╭── 🤖 RESPONSE ───────────────
│ Plan: Python Scripts Plan
│  
│ Summary
│ A plan to create two Python scripts: a Hello World program and a simple calculator, along with comprehensive documentation explaining the implementation details.
│  
│ Status: ⏳ Pending
│  
│ Last Updated: 2025-10-01
│  
│ Steps
│  
│ Step 1: ⏳ Create Hello World Script
│  
│ Subtasks:
│ - Create a basic Python script that prints 'Hello, World!' to the console
│ - Add comments explaining the code structure and functionality
│ - Create a section in the documentation explaining the Hello World implementation
│  
│ Step 2: ⏳ Create Simple Calculator Script
│  
│ Subtasks:
│ - Create a Python script for a calculator with basic operations (addition, subtraction, multiplication, division)
│ - Implement user input handling and display of results
│ - Add error handling for invalid inputs and division by zero
│ - Create a section in the documentation explaining the calculator implementation and how to use it
│  
│ Would you like me to make any changes to this plan or shall we approve it?
╰──────────────────────────────
                 
                                                   ╭─────────────────────────────────────────────╮
                                                   │ Tokens: ↑ 18.6K ↓ 555 | Costs: USD 0.063990 │
                                                   ╰─────────────────────────────────────────────╯
⫸ [Plan Mode][draft] approve
                 
╭──────────────────────────────────────────────────────────╮
│ 🔧 approve_plan (python_scripts_plan_3f09e4cf)           │
│ Approving plan...                                        │
╰──────────────────────────────────────────────────────────╯

✅ approve_plan completed successfully

📝 Plan available at: /Users/rodolfo.lobo/.coda/.plans/python_scripts_plan_3f09e4cf.md
                 
╭── 🤖 RESPONSE ───────────────
│ Now I have access to code edition tools. The plan has been approved, we can start executing it when you're ready!
╰──────────────────────────────
                 
                                                   ╭─────────────────────────────────────────────╮
                                                   │ Tokens: ↑ 38.9K ↓ 652 | Costs: USD 0.126354 │
                                                   ╰─────────────────────────────────────────────╯
⫸ [Plan Mode][exec] proceed
                 
I'll start executing the plan now, beginning with Step 1: Create Hello World Script.
                 
💭 Thought

Let's execute Step 1 of the plan: Create Hello World Script

I need to:
1. Create a basic Python script that prints 'Hello, World!' to the console
2. Add comments explaining the code structur
```