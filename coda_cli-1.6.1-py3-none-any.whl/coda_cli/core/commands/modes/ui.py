from typing import Dict, Optional, Any, Mapping
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit import print_formatted_text
from loguru import logger
from coda_cli.core.ui.core import print_markdown_response
import time
import re


def display_auto_execution_start() -> None:
    """
    Display a message indicating that auto-execution is about to start.
    This helps users understand that the system is preparing to execute the plan.
    """
    print_formatted_text(HTML(f"""
<ansiblue>Starting plan execution...</ansiblue>
"""))
    print()  # Add blank line after execution start message


def display_auto_execution_response(response: Optional[str] = None) -> None:
    """
    Display the agent's auto-execution response with proper formatting.
    If no response is available, display a message indicating the user needs to proceed manually.
    
    Args:
        response: The agent's response string to display, or None if no response is available
    """
    if response and isinstance(response, str) and response.strip():
        print()  # Add a blank line before the response
        print_markdown_response(response)
        print()
    else:
        # User feedback for when auto-execution doesn't produce a response
        logger.debug("Auto-execution did not return a valid response")
        
        print()
        print_formatted_text(HTML(
            "<ansibrightblue>Plan loaded successfully. To begin execution:</ansibrightblue>\n"
            "• Type a message to start executing the first step\n"
            "• Or use <ansibold>/mark 1</ansibold> to mark a step as done\n"
        ))

def display_mode_header() -> None:
    """
    Display the mode selection header.
    """
    print_formatted_text(HTML('<ansibrightcyan>\nMode Selection</ansibrightcyan>'))
    print_formatted_text(HTML('<ansibrightcyan>=============</ansibrightcyan>'))


def format_mode_entry(
    index: int,
    mode_name: str,
    description: str,
    is_current: bool
) -> None:
    """
    Format and display a single mode entry.
    
    Args:
        index: The numeric index of the mode
        mode_name: The human-readable name of the mode
        description: The description of the mode
        is_current: Whether this mode is currently active
    """
    current_indicator = " [Current]" if is_current else ""
    
    print_formatted_text(
        HTML(f"  <ansibrightcyan>{index}.</ansibrightcyan> "
             f"<ansibold>{mode_name}</ansibold>{current_indicator}")
    )
    
    if description:
        print_formatted_text(
            HTML(f"     <ansibrightblack>{description}</ansibrightblack>")
        )


def display_modes(
    modes_info: Mapping[str, Dict[str, Any]],
    current_mode_key: Optional[str]
) -> Dict[str, str]:
    """
    Display available modes and return a mapping from index to mode key.
    
    Args:
        modes_info: A mapping from mode keys to mode info dictionaries
        current_mode_key: The key of the currently active mode, if any
        
    Returns:
        A mapping from index strings to mode keys
    """
    mode_index = 1
    mode_index_to_key = {}
    
    # Manually add main mode if it's missing
    if 'main_mode' not in modes_info:
        modes_info['main_mode'] = {
            'name': 'Main Mode',
            'description': 'Return to the main Coda agent.'
        }
    
    # Ensure 'main_mode' is processed second (Plan Mode first)
    sorted_keys = sorted(modes_info.keys(), key=lambda k: 1 if k == "main_mode" else 0)
    
    for key in sorted_keys:
        mode_info = modes_info[key]
        mode_name = mode_info.get('name', key)
        description = mode_info.get('description', '')
        
        # Strip state indicators from mode name for menu display
        # This handles " [draft]" or " [0/5]" (prompt parts sent by the mode automatically)
        mode_name = re.sub(r'\]\[(?:draft|exec)$|\s+\[(?:draft|\d+/\d+)\]$', '', mode_name)
        
        # Map index to key
        mode_index_to_key[str(mode_index)] = key
        
        # Display formatted mode
        is_current = (current_mode_key == key)
        format_mode_entry(mode_index, mode_name, description, is_current)
        
        mode_index += 1
    
    return mode_index_to_key


def display_options() -> None:
    """
    Display additional options for mode selection.
    """
    print_formatted_text(HTML("\n<ansibold>Options:</ansibold>"))
    print_formatted_text(
        HTML("  <ansibrightcyan>q.</ansibrightcyan> Return to main interface")
    )

def display_exit_option() -> None:
    print()
    
    # Define ANSI color codes
    BLUE = "\033[38;5;39m"       # Darker blue color
    LIGHT_BLUE = "\033[38;5;117m"  # Lighter blue color
    RESET = "\033[0m"            # Reset color
    BOLD = "\033[1m"             # Bold text
    
    lines = [
        "• Plan Mode lets you draft a plan and edit its steps.",
        "  You can run steps one by one.",
        "",
        f"• Press {BOLD}CTRL + C{RESET}{LIGHT_BLUE} to exit Plan Mode",
        "  and return to the main Coding Agent.",
        "",
        "• To begin, send your prompt with clear instructions.",
        "",
        "• When you are done refining the plan,",
        f"use {BOLD}/start{RESET}{LIGHT_BLUE} to approve the plan and start the execution.",
        "",
        "• You can also simply type 'approve' to approve without execution.",
    ]
        
    # Determine box width based on the longest line
    # Add 4 for the left margin (│ ) and right margin ( │)
    box_width = max(len(line) for line in lines) + 4
    
    # Ensure the header fits
    header = "You have entered Plan Mode"
    if len(header) + 4 > box_width:
        box_width = len(header) + 4
    
    # Calculate padding for header
    header_padding = max(0, box_width - 2 - len(header))
    left_padding = header_padding // 2
    right_padding = header_padding - left_padding
    
    # Print box with content
    print(f"{BLUE}╭{'─' * (box_width - 2)}╮{RESET}")
    print(f"{BLUE}│{' ' * left_padding}{BOLD}{header}{RESET}{' ' * right_padding}{BLUE}│{RESET}")
    print(f"{BLUE}├{'─' * (box_width - 2)}┤{RESET}")
    
    # Print body content with proper padding
    for line in lines:
        # Remove bold formatting for length calculation
        plain_line = line.replace(f"{BOLD}", "").replace(f"{RESET}{LIGHT_BLUE}", "")
        
        # Add color reset and blue for each line to ensure proper coloring
        formatted_line = f"{LIGHT_BLUE}{line}{RESET}"
        
        # Calculate padding based on the plain line length
        visible_length = len(plain_line)
        padding = max(0, box_width - 2 - visible_length - 1)  # -1 for the space after │
        
        print(f"{BLUE}│ {formatted_line}{' ' * padding}{BLUE}│{RESET}")
    
    # Print footer
    print(f"{BLUE}╰{'─' * (box_width - 2)}╯{RESET}")
    
    # Add a brief pause to ensure the user has time to see the message
    time.sleep(0.5)
    
    print()



def get_user_choice() -> str:
    """
    Get the user's choice of mode.
    
    Returns:
        The user's input string
    """
    print("Select mode: ", end="", flush=True)
    return input().strip().lower()


def map_choice_to_mode_key(
    choice: str,
    mode_index_to_key: Dict[str, str],
    modes_info: Mapping[str, Dict[str, Any]]
) -> Optional[str]:
    """
    Map the user's choice to a mode key.
    
    Args:
        choice: The user's input string
        mode_index_to_key: A mapping from index strings to mode keys
        modes_info: A mapping from mode keys to mode info dictionaries
        
    Returns:
        The selected mode key, or None if the choice is invalid or the user quit
    """
    # Handle quit
    if choice == 'q':
        return None
    
    # Map numeric choice to key
    if choice in mode_index_to_key:
        return mode_index_to_key[choice]
    
    # Handle direct key input
    if choice in modes_info:
        return choice
    
    # Invalid choice
    logger.warning(f"Invalid mode selection: {choice}")
    return None


def select_mode_with_ui(mode_manager: Any) -> Optional[str]:
    """
    Display a UI for selecting a mode and return the selected mode key.
    
    This function displays available modes, gets the user's selection,
    and returns the corresponding mode key.
    
    Args:
        mode_manager: The mode manager instance
        
    Returns:
        The selected mode key, or None if the selection was invalid or the user quit
    """
    try:
        # Display header
        display_mode_header()
        
        # Get available modes
        modes_info = mode_manager.get_available_modes()
        
        # Get current mode key using safe access
        current_mode_key = getattr(mode_manager, 'get_current_mode_key', 
                            lambda: getattr(mode_manager, '_current_mode_key', None))()
        
        # Display modes and get mapping
        mode_index_to_key = display_modes(modes_info, current_mode_key)
        
        # Display options
        display_options()
        
        # Get user input
        choice = get_user_choice()
        
        # Map choice to mode key
        return map_choice_to_mode_key(choice, mode_index_to_key, modes_info)
        
    except Exception as e:
        logger.error(f"Error in mode selection UI: {str(e)}")
        return None