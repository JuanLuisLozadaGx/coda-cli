from typing import Any, Dict, List, Optional, Protocol, runtime_checkable
from loguru import logger


@runtime_checkable
class ModeManagerProtocol(Protocol):
    """Protocol defining the expected interface for a mode manager."""
    
    def get_available_modes(self) -> Dict[str, Dict[str, Any]]:
        """Get information about available modes."""
        ...
    
    def select_mode(self, mode_key: str) -> bool:
        """Activate the specified mode."""
        ...
    
    def get_mode_by_key(self, mode_key: str) -> Any:
        """Get a mode by its key."""
        ...


def validate_mode_manager(mode_manager: Any) -> bool:
    """
    Validate that an object implements the ModeManagerProtocol.
    
    Args:
        mode_manager: The object to validate
        
    Returns:
        True if the object implements the protocol, False otherwise
    """
    try:
        return isinstance(mode_manager, ModeManagerProtocol)
    except Exception as e:
        logger.error(f"Error validating mode manager: {str(e)}")
        return False


def validate_cli_state(cli: Any) -> bool:
    """
    Validate that the CLI instance has the necessary state for mode operations.
    
    Args:
        cli: The CLI instance to validate
        
    Returns:
        True if the CLI has valid state, False otherwise
    """
    if not hasattr(cli, 'shared_state'):
        logger.error("CLI instance missing shared_state attribute")
        return False
        
    if not hasattr(cli.shared_state, 'tool_manager'):
        logger.error("CLI shared_state missing tool_manager attribute")
        return False
        
    return True


def validate_mode_key(
    mode_key: str,
    available_modes: Dict[str, Dict[str, Any]]
) -> bool:
    """
    Validate that a mode key exists in the available modes.
    
    Args:
        mode_key: The mode key to validate
        available_modes: The dictionary of available modes
        
    Returns:
        True if the mode key is valid, False otherwise
    """
    if not mode_key:
        logger.warning("Empty mode key provided")
        return False
        
    if mode_key not in available_modes:
        logger.warning(f"Invalid mode key: {mode_key}")
        return False
        
    return True


def validate_user_input(input_value: str, valid_options: List[str]) -> bool:
    """
    Validate that user input is in a list of valid options.
    
    Args:
        input_value: The user input to validate
        valid_options: A list of valid input options
        
    Returns:
        True if the input is valid, False otherwise
    """
    if not input_value:
        logger.warning("Empty user input")
        return False
        
    if input_value not in valid_options:
        logger.warning(f"Invalid user input: {input_value}")
        return False
        
    return True