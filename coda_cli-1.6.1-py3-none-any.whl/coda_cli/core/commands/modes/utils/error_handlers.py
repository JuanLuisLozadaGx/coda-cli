from typing import Any, Callable, TypeVar
from loguru import logger

# Define a generic type for function return values
T = TypeVar('T')


class ModeError(Exception):
    """Base exception for mode-related errors."""
    pass


class ModeInitializationError(ModeError):
    """Error initializing the mode manager."""
    pass


class ModeSelectionError(ModeError):
    """Error selecting a mode."""
    pass


class ModeActivationError(ModeError):
    """Error activating a mode."""
    pass


def handle_operation(operation_func: Callable[[], T], 
                    error_context: str, 
                    fallback: T) -> T:
    """
    Execute an operation with standardized error handling.
    
    Args:
        operation_func: Callable that performs the operation
        error_context: String describing the operation for error messages
        fallback: Value to return if the operation fails
        
    Returns:
        The result of operation_func or fallback if an exception occurs
    """
    try:
        return operation_func()
    except Exception as e:
        logger.error(f"Error {error_context}: {str(e)}")
        return fallback