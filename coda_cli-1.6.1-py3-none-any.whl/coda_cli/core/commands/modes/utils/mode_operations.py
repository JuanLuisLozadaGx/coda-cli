from typing import Any, Optional, cast, TYPE_CHECKING
if TYPE_CHECKING:
    from coda_cli.core.cli import CLI
from loguru import logger
from coda_core.core.modes.mode_manager import ModeManager
from coda_cli.core.commands.modes.ui import select_mode_with_ui, display_exit_option
from coda_cli.core.commands.modes.utils.error_handlers import (
    ModeInitializationError,
    ModeSelectionError,
    ModeActivationError
)
from coda_cli.core.commands.modes.utils.interfaces import (
    validate_mode_manager,
    validate_mode_key
)


def initialize_mode_manager(cli: 'CLI') -> bool:
    """
    Initialize the mode manager if not already done.
    
    Args:
        cli: The CLI instance
        
    Returns:
        True if initialization was successful, False otherwise
    """
    if hasattr(cli, 'mode_manager'):
        if validate_mode_manager(cli.mode_manager):
            return True
        else:
            logger.warning("Existing mode_manager does not implement the required interface")
    
    try:
        cli.mode_manager = ModeManager()
        
        # Validate the newly created manager
        if not validate_mode_manager(cli.mode_manager):
            logger.warning("Created mode_manager does not implement the required interface")
            return False
            
        return True
    except Exception as e:
        logger.error(f"Error initializing ModeManager: {str(e)}")
        raise ModeInitializationError(f"Failed to initialize mode manager: {str(e)}") from e


def select_mode(mode_manager: ModeManager) -> Optional[str]:
    """
    Use the UI to select a mode.
    
    Args:
        mode_manager: The mode manager instance
        
    Returns:
        The selected mode key or None if selection failed or user canceled
    """
    # Validate the mode manager
    if not validate_mode_manager(mode_manager):
        logger.error("Invalid mode manager provided")
        raise ModeSelectionError("Invalid mode manager provided")
    
    try:
        # Get selected mode key from UI
        selected_mode_key = select_mode_with_ui(mode_manager)
        
        # If a key was selected, validate it
        if selected_mode_key:
            modes_info = mode_manager.get_available_modes()
            if not validate_mode_key(selected_mode_key, modes_info):
                logger.warning(f"Invalid mode key selected: {selected_mode_key}")
                return None
        
        return selected_mode_key
    except Exception as e:
        logger.error(f"Error in mode selection UI: {str(e)}")
        raise ModeSelectionError(f"Failed to select mode: {str(e)}") from e


def get_mode_name(mode_manager: ModeManager, mode_key: str) -> str:
    """
    Get the human-readable name of a mode.
    
    Args:
        mode_manager: The mode manager instance
        mode_key: The key of the mode
        
    Returns:
        The human-readable name of the mode or the mode key if name is not available
    """
    try:
        mode = mode_manager.get_mode_by_key(mode_key)
        return getattr(mode, 'name', mode_key)
    except Exception as e:
        logger.error(f"Error getting mode info: {str(e)}")
        return mode_key


def activate_mode(mode_manager: ModeManager, mode_key: str) -> bool:
    """
    Activate the selected mode.
    
    Args:
        mode_manager: The mode manager instance
        mode_key: The key of the mode to activate
        
    Returns:
        True if activation was successful, False otherwise
    """
    # Validate inputs
    if not validate_mode_manager(mode_manager):
        logger.error("Invalid mode manager provided")
        raise ModeActivationError("Invalid mode manager provided")
        
    if not mode_key:
        logger.warning("No mode key provided")
        return False
    
    # Validate mode key
    modes_info = mode_manager.get_available_modes()
    if not validate_mode_key(mode_key, modes_info):
        logger.error(f"Invalid mode key: {mode_key}")
        raise ModeActivationError(f"Invalid mode key: {mode_key}")
    
    try:
        # Activate the mode
        success = mode_manager.select_mode(mode_key)
        
        # Provide feedback
        if success:
            display_exit_option()
            return True
        else:
            logger.error("Failed to activate mode. Check logs for details.", False)
            return False
    except Exception as e:
        logger.error(f"Error activating mode: {str(e)}")
        raise ModeActivationError(f"Failed to activate mode {mode_key}: {str(e)}") from e