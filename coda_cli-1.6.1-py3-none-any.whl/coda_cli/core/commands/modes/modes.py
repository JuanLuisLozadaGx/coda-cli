from typing import List
from loguru import logger
from coda_cli.core.commands.base import Command
from coda_cli.core.commands.modes.utils import (
    initialize_mode_manager,
    select_mode,
    activate_mode,
    ModeError
)


class ModesCommand(Command):
    """Implementation of the /mode command to select an operational mode."""
    
    def aliases(self) -> List[str]:
        """
        Get the command aliases.
        
        Returns:
            A list of string aliases for this command.
        """
        return ["/mode", "/m"]
    
    def description(self) -> str:
        """
        Get the command description.
        
        Returns:
            A string description of this command.
        """
        return "Select an operational mode (e.g'/mode p', or '/mode m')"
    
    def arguments(self) -> List[str]:
        """
        Get the command arguments.
        
        Returns:
            A list of string arguments for this command.
        """
        return ["step", "s", "p", "plan", "planning", "main", "m"]
    
    def execute(self, args) -> bool:
        """
        Execute the mode command.
        
        This method initializes the mode manager if not already done,
        displays the mode selection UI, and activates the selected mode.
        If 'step' or 's' argument is provided, selects the step/plan mode directly.
        If 'main' or 'm' argument is provided, selects the main mode to return to the main agent.
        
        Args:
            args: Command arguments (list of strings)
            
        Returns:
            True to continue CLI execution
        """
        # The /mode menu has a hard-dependency on the agent initialization, so we have to block until it's finished
        if not self.cli.wait_for_agent_initialization():
            # Finish CLI execution on agent initialization failure
            return False

        try:
            # Step 1: Initialize the mode manager
            if not initialize_mode_manager(self.cli):
                logger.error(
                    "Failed to initialize mode manager. Check logs for details.", 
                    success=False
                )
                return True
            
            # Check if we have a mode activation request
            if args and args[0] in self.arguments():
                # Look for mode in available modes
                modes_info = self.cli.mode_manager.get_available_modes()
                target_mode_key = None
                
                # Check if we're looking for main mode
                if args[0] in ["main", "m"]:
                    # Find the main mode key
                    for key, mode_info in modes_info.items():
                        mode_name = mode_info.get('name', '').lower()
                        if 'main' in key.lower() or 'main' in mode_name:
                            target_mode_key = key
                            break
                    
                    # If main mode not found in modes_info, use 'main_mode' as default key
                    if not target_mode_key:
                        target_mode_key = 'main_mode'
                else:
                    # Find the planning/step mode key
                    for key, mode_info in modes_info.items():
                        mode_name = mode_info.get('name', '').lower()
                        if 'step' in key.lower() or 'step' in mode_name or 'plan' in mode_name:
                            target_mode_key = key
                            break
                
                if target_mode_key:
                    # Provide CLI reference to mode for usage synchronization
                    mode_instance = self.cli.mode_manager.get_mode_by_key(target_mode_key)
                    if mode_instance:
                        mode_instance.cli = self.cli
                        logger.info(f"Provided CLI reference to mode for usage synchronization")
                    
                    # Select the target mode directly
                    activate_mode(self.cli.mode_manager, target_mode_key)
                    return True
                else:
                    requested_mode = "main" if args[0] in ["main", "m"] else "step/planning"
                    logger.error(f"{requested_mode} mode not found", success=False)
                    return True
                
            # Step 2: Get mode selection from user
            selected_mode_key = select_mode(self.cli.mode_manager)
            
            # Handle empty or None mode key (user quit or invalid selection)
            if not selected_mode_key:
                return True
                
            # Step 3: Provide CLI reference to mode for usage synchronization
            mode_instance = self.cli.mode_manager.get_mode_by_key(selected_mode_key)
            if mode_instance:
                mode_instance.cli = self.cli
                logger.info(f"Provided CLI reference to mode for usage synchronization")
            
            # Step 4: Select the selected mode
            activate_mode(self.cli.mode_manager, selected_mode_key)
            
        except ModeError as e:
            # Specific mode errors are already logged in the utility functions
            logger.error(f"Mode selection failed: {str(e)}", success=False)
        except Exception as e:
            # Catch any unexpected errors
            logger.error(f"Unexpected error in mode command: {str(e)}")
            logger.error(
                "An unexpected error occurred. Check logs for details.", 
                success=False
            )
            
        return True