from typing import List

from coda_cli.core.utils.utils import input_file_path_cleanup
from coda_cli.core.commands.base import Command


class AddCommand(Command):
    """Implementation of the /add command to add a file to the current context."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/add"]
    
    def description(self) -> str:
        """Return command description."""
        return "Add files to context"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return ["filepath"]
    
    def execute(self, args) -> bool:
        """
        Handles the '/add' command to add a file to the current context.

        Args:
            args (str): The arguments provided with the '/add' command, 
                        expected to contain a filepath.

        Returns:
            bool: True if the command managed to execute, False otherwise.

        Behavior:
            - Splits the input arguments to extract the filepath.
            - Attempts to add the specified file to the context using the `add_file` method of the state.
            - Provides feedback to the user about the success or failure of the operation.
            - If no filepath is provided or the file is not found, displays appropriate usage instructions.
        """
        # Use the entire argument string without splitting to preserve spaces in filenames
        filepath = input_file_path_cleanup(args)
        if filepath:
            if self.cli.cli_state.add_file(filepath):
                print()
                # Auto-save if needed
                self.cli._auto_save_if_needed()
            else:
                print(f"\033[1;31mFile '{filepath}' not found. Make sure the path provided is correct.\033[0m")
        else:
            print("\033[1;31mNo filepath was provided after the /add command\033[0m")
            print("\033[1;33mUsage: /add <filepath> or @ <filepath> to include relevant files to the agent context\033[0m")

        return True
        


class ClearFilesCommand(Command):
    """Implementation of the /clear-files command to clear all selected files from the current context."""

    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/clear-files"]
    
    def description(self) -> str:
        """Return command description."""
        return "Clear all selected files from context"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []

    def execute(self, args) -> bool:
        """
        Handles the '/clear-files' command to remove all files from the current context.

        Args:
            cli: The CLI instance that's calling this command
            args (str): The arguments provided with the '/clear-files' command 
                       (not used for this command).

        Returns:
            bool: True if the files were successfully cleared from the context.
        """
        self.cli.cli_state.clear_files()
        print("\nCleared all selected files from context")
        print()

        # Auto-save if needed
        self.cli._auto_save_if_needed()
        
        return True
    

