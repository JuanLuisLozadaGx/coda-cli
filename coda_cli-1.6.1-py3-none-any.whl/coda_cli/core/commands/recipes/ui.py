from typing import List, Tuple, Optional
from prompt_toolkit import print_formatted_text
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.completion import FuzzyCompleter, WordCompleter
from prompt_toolkit.shortcuts import prompt
from loguru import logger

from coda_core.core.recipes.manager import RecipeManager
from coda_cli.config.constants import RECIPE_DEFAULT_COLOR, RECIPE_EMOJIS



def get_recipe_style(recipe_name: str) -> Tuple[str, str]:
    """
    Determine the appropriate icon and color for a recipe based on its name.
    
    Args:
        recipe_name (str): The name of the recipe
        
    Returns:
        Tuple[str, str]: A tuple containing (icon, color_class)
    """
    recipe_color = RECIPE_DEFAULT_COLOR
    icon = RECIPE_EMOJIS['default']
    
    if "bug" in recipe_name.lower() or "fix" in recipe_name.lower():
        icon = RECIPE_EMOJIS['bug']
    elif "test" in recipe_name.lower():
        icon = RECIPE_EMOJIS['test']
    elif "security" in recipe_name.lower():
        icon = RECIPE_EMOJIS['security']
    elif "upgrade" in recipe_name.lower():
        icon = RECIPE_EMOJIS['upgrade']
        
    return icon, recipe_color


def display_recipe_catalog(available_recipes: List[str], recipe_manager: RecipeManager) -> None:
    """
    Display the recipe catalog organized by category with improved styling.
    
    Args:
        available_recipes (List[str]): List of available recipe names
        recipe_manager: Recipe manager instance to fetch metadata
    """
    if not available_recipes:
        print_formatted_text(HTML("<ansiyellow>⚠️ No recipes found</ansiyellow> in <ansibrightblue>~/.coda/recipes/</ansibrightblue>"))
        print_formatted_text(HTML("Type <ansibold>/help</ansibold> to see available commands."))
        return
    
    # Group recipes by their first letter for better organization
    grouped_recipes = {}
    for recipe_name in available_recipes:
        first_letter = recipe_name[0].upper()
        if first_letter not in grouped_recipes:
            grouped_recipes[first_letter] = []
        grouped_recipes[first_letter].append(recipe_name)
    
    # Sort the groups alphabetically
    sorted_groups = sorted(grouped_recipes.keys())
    
    # Display header with improved styling
    print_formatted_text(HTML(f"<ansibrightblue>✨ Available Recipes</ansibrightblue>\n"))
    
    # Display recipes grouped by first letter with improved formatting
    for group in sorted_groups:
        # Sort recipes within each group
        recipes_in_group = sorted(grouped_recipes[group])
        
        # Display recipes with their descriptions
        for recipe_name in recipes_in_group:
            metadata = recipe_manager.get_recipe_metadata(recipe_name)
            description = metadata.description
            
            # Get recipe style (icon and color)
            icon, recipe_color = get_recipe_style(recipe_name)
            
            # Format display with numbering, icon, colored name and description
            display_text = f"{icon} <{recipe_color}><ansibold>{recipe_name}</ansibold></{recipe_color}>"
            
            if description:
                display_text += f"\n     <ansiitalic>{description}</ansiitalic>"
            
            print_formatted_text(HTML(display_text))
    
    print_formatted_text(HTML("\n<ansibrightyellow>Hit tab to search for a recipe</ansibrightyellow>\n"))


def display_recipe_instructions(recipe_name: str, recipe_description: str, recipe_user_instructions: str) -> None:
    """
    Display instructions for using a selected recipe.
    
    Args:
        recipe_name (str): Name of the selected recipe
        recipe_description (str): Description of the recipe
        recipe_user_instructions (str): User instructions for the recipe
    """
    # Get appropriate icon and color for this recipe
    icon, recipe_color = get_recipe_style(recipe_name)
    
    message = f"You have selected the recipe:{icon} <{recipe_color}><ansibold>{recipe_name}</ansibold></{recipe_color}>.\n"
    message += f"This recipe will do the following: <ansibrightblue>{recipe_description}</ansibrightblue>"
    print_formatted_text(HTML(message))
    
    # Show recipe-specific instructions if available, otherwise show generic guidance
    if recipe_user_instructions:
        print_formatted_text(HTML("\n<ansibrightblue>💡 User Instructions:</ansibrightblue>"))
        print_formatted_text(HTML(f"<ansibrightyellow>{recipe_user_instructions}</ansibrightyellow>\n"))
    else:
        print_formatted_text(HTML("\n<ansibrightgreen>💡 Please provide specific instructions for this recipe:</ansibrightgreen>"))
        print_formatted_text(HTML("<ansigray>  • Include the task or issue you want CODA to work with.</ansigray>"))
        print_formatted_text(HTML("<ansigray>  • For example, to diagnose a bug include the issue you are facing.</ansigray>\n"))


def select_recipe(available_recipes: List[str], recipe_manager: RecipeManager) -> Optional[str]:
    """
    Display an interactive recipe selector using autocomplete.
    
    Args:
        available_recipes (List[str]): List of available recipe names
        recipe_manager: Recipe manager instance to fetch metadata
        
    Returns:
        Optional[str]: Selected recipe name, or None if cancelled
    """
    
    if not available_recipes:
        print_formatted_text(HTML("<ansiyellow>⚠️ No recipes found</ansiyellow> in <ansibrightblue>~/.coda/recipes/</ansibrightblue>"))
        print_formatted_text(HTML("Type <ansibold>/help</ansibold> to see available commands."))
        return None

    try:
        # Display the catalog of available recipes
        display_recipe_catalog(available_recipes, recipe_manager)
        
        # Create fuzzy completer with available recipes
        completer = FuzzyCompleter(WordCompleter(available_recipes))
        
        # Create prompt message with styling
        prompt_message = HTML('<ansibrightblue>✨ Select Recipe</ansibrightblue><ansiwhite>: </ansiwhite>')
        
        # Store recipe name by number for quick selection
        recipes_by_number = {}
        counter = 1
        
        # Group recipes by their first letter for better organization
        grouped_recipes = {}
        for recipe_name in available_recipes:
            first_letter = recipe_name[0].upper()
            if first_letter not in grouped_recipes:
                grouped_recipes[first_letter] = []
            grouped_recipes[first_letter].append(recipe_name)
            
        # Sort the groups alphabetically
        sorted_groups = sorted(grouped_recipes.keys())
        
        # Build the lookup dictionary for numerical selection
        for group in sorted_groups:
            for recipe_name in sorted(grouped_recipes[group]):
                recipes_by_number[str(counter)] = recipe_name
                counter += 1
        
        # Get user selection with autocomplete
        selected = prompt(prompt_message, completer=completer, 
                          complete_style='column', complete_while_typing=True).strip()
        
        # Validate selection
        if not selected:
            # User cancelled (empty input)
            return None
            
        # Check if the user entered a number
        if selected.isdigit() and selected in recipes_by_number:
            return recipes_by_number[selected]
        # Check if the user entered a recipe name
        elif selected in available_recipes:
            return selected
        else:
            print_formatted_text(HTML(f"<ansired>❌ Recipe '</ansired><ansibold>{selected}</ansibold><ansired>' not found.</ansired>"))
            print_formatted_text(HTML("<ansigray>You can enter either a recipe name or the number shown next to it.</ansigray>"))
            return None
            
    except KeyboardInterrupt:
        print_formatted_text(HTML("\n<ansired>⌨️  Recipe selection cancelled.</ansired>"))
        return None
    except Exception as e:
        logger.error(f"Error in recipe selection: {e}")
        print_formatted_text(HTML(f"<ansired>❗ Error selecting recipe:</ansired> <ansiwhite>{e}</ansiwhite>"))
        return None


def get_recipe_with_user_input(recipe_manager: RecipeManager) -> Optional[str]:
    """
    Select a recipe and combine it with additional user input.
    
    Args:
        recipe_manager: Recipe manager instance to fetch recipes
        
    Returns:
        Optional[str]: Combined recipe content and user input, or None if cancelled
    """
    
    # Step 1: Get available recipes
    available_recipes = recipe_manager.list_recipes()
    
    # Step 2: Select a recipe
    selected_recipe = select_recipe(available_recipes, recipe_manager)
    if not selected_recipe:
        return None

    # Step 3: Load the recipe content
    recipe = recipe_manager.load_recipe(selected_recipe)
    if not recipe:
        print_formatted_text(HTML(f"<ansired>❌ Error:</ansired> Could not load recipe '<ansibold>{selected_recipe}</ansibold>'"))
        return None
    
    recipe_content = recipe.content
    recipe_description = recipe.description
    recipe_user_instructions = recipe.user_instructions
    
    # Step 4: Display recipe instructions
    display_recipe_instructions(selected_recipe, recipe_description, recipe_user_instructions)
    
    # Step 5: Get additional user input with validation
    try:
        while True:
            prompt_label = 'Your Input'
            user_input = prompt(
                HTML(f'<ansibrightblue>✨ {prompt_label}</ansibrightblue><ansiwhite>: </ansiwhite>'),
                multiline=False
            ).strip()
            
            if user_input:
                # Combine recipe content with user input
                combined_message = f"{user_input}\n\n{recipe_content}"
                return combined_message
            else:
                # Warn about empty input and prompt again
                print_formatted_text(HTML("<ansiyellow>⚠️  Instructions cannot be empty. Please describe what you want to accomplish.</ansiyellow>"))
        
    except KeyboardInterrupt:
        print_formatted_text(HTML("\n<ansiyellow>⌨️  Message input cancelled.</ansiyellow>"))
        return None


