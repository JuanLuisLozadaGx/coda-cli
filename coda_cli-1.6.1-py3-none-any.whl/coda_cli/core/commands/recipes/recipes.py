from typing import List
from loguru import logger
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit import print_formatted_text

from coda_core.core.recipes.manager import RecipeManager
from coda_cli.core.commands.base import Command
from coda_cli.core.commands.recipes.ui import get_recipe_with_user_input



class RecipesCommand(Command):
    """Implementation of the /recipes command to browse and use pre-defined AI recipes."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/recipes", "/rcp"]
    
    def description(self) -> str:
        """Return command description."""
        return "Browse and use a visual catalog of pre-defined AI recipes"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []
    
    def execute(self, args) -> bool:
        """
        Handles the '/recipes' command to browse and use a visual catalog of pre-defined AI recipes.

        Args:
            args (str): The arguments provided with the '/recipes' command 
                      (not used for this command).

        Returns:
            bool: True to continue CLI execution, False to exit.

        Behavior:
            - Initializes the recipe manager
            - Provides a visual interface to browse and select recipes
            - Allows users to preview recipe content before selection
            - Enables selection of recipes via numbered options or autocomplete
            - Supports adding custom instructions to tailor the recipe to specific needs
        """
        try:
            # Initialize recipe manager
            recipe_manager = RecipeManager()
            recipe_manager.initialize_default_recipes()
            
            # Use the UI functions to handle recipe selection and user input
            combined_message = get_recipe_with_user_input(recipe_manager)
            
            if combined_message:
                return self.cli._handle_agent_interaction(user_message=combined_message)
            else:
                return True
        except Exception as e:
            logger.error(f"Error in recipes command: {e}")
            print_formatted_text(HTML('<ansibrightred>Error accessing recipes</ansibrightred>'))
            return True