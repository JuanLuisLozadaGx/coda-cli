import time
from typing import List
from coda_cli.core.commands.base import Command
from coda_cli.core.commands.preferences.bash import manage_bash_security_preferences
from coda_cli.core.commands.preferences.condensing import manage_memory_condensing_preferences
from coda_cli.core.commands.preferences.subagent import manage_subagent_preferences


class PreferencesMenuCommand(Command):
    """Implementation of the /preferences command to manage session preferences."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/preferences", "/prefs"]
    
    def description(self) -> str:
        """Return command description."""
        return "Manage session preferences"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return []
    
    def execute(self, args) -> bool:
        """
        Manage session preferences.
        
        This command provides an interactive interface for managing preferences
        that are stored with the current session, including bash command security settings.
        
        Args:
            cli: The CLI instance that's calling this command
            args: Command arguments (not used)
            
        Returns:
            bool: Always returns True to continue CLI execution
        """
        # The /preferences menu has a hard-dependency on the agent initialization, so we have to block until it's finished
        if not self.cli.wait_for_agent_initialization():
            # Finish CLI execution on agent initialization failure
            return False

        # Ensure bash_security is initialized
        if "bash_security" not in self.cli.shared_state.preferences:
            # Use the shared state's initialization method
            self.cli.shared_state._initialize_bash_security_preferences()
        
        # Get current bash security preferences
        security_prefs = self.cli.shared_state.preferences["bash_security"]
        
        while True:
            # Clear screen and display header
            print("\033[2J\033[H", end="")  # Clear screen
            
            # Get current session info
            current_session_name = "None"
            if self.cli.session_manager.current_session:
                current_session_name = self.cli.session_manager.current_session.name or "Unnamed"
            
            # Display preferences management header
            print("\n\033[1;36mSession Preferences Management\033[0m")
            print("\033[1;36m============================\033[0m")
            print(f"Current session: \033[1;33m{current_session_name}\033[0m")
            
            # Display available preference categories
            print("\n\033[1mAvailable preference categories:\033[0m")
            print("  1. Bash Command Security")
            print("  2. Memory Condensing")
            print("  3. Subagent Preferences")
            # Future categories can be added here
            print("  q. Return to main interface")
            
            # Get user selection
            selection = input("\n\033[1mEnter choice: \033[0m").strip().lower()
            
            if selection == 'q':
                return True
            elif selection == '1':
                # Display bash security preferences                
                manage_bash_security_preferences(self.cli, security_prefs)
            elif selection == '2':
                # Display memory condensing preferences
                manage_memory_condensing_preferences(self.cli)
            elif selection == '3':
                # Display subagent preferences
                manage_subagent_preferences(self.cli)
            else:
                # Clear screen
                print("\033[2J\033[H", end="")
                print(f"\033[1;31mInvalid selection: {selection}. Please try again.\033[0m")
                # Wait a moment to show the error
                time.sleep(1.5)