import time
from loguru import logger

from coda_core.config.env_config import EnvConfig
from coda_core.config.settings import SETTINGS
from coda_cli.core import ui


def manage_subagent_preferences(cli) -> None:
    """
    Manage global subagent preferences.
    
    Args:
        cli: The CLI instance that's calling this function
    
    This function provides an interface for configuring subagent settings:
    - Enable/disable automatic copying of default subagents at startup
    """
    while True:
        # Clear screen at the start of each iteration
        print("\033[2J\033[H", end="")  # Clear screen
        
        # Get current settings from environment
        should_copy_subagents = SETTINGS.get_env_var(EnvConfig.CODA_COPY_DEFAULT_AGENTS).lower() == "true"
        
        # Display UI header
        print(ui.block_header("Subagent Preferences", icon="🤖", color_code="38;5;81"))
        print(ui.block_line("Status", "Manage subagent preferences", box_color="38;5;81"))
        print(ui.block_footer())
        
        # Display current settings
        print("\n\033[1;36mSubagent Settings (Global)\033[0m")
        print("\033[1;36m===========================\033[0m")
        print(f"Copy default subagents at startup: \033[1;{'32' if should_copy_subagents else '31'}m{'Enabled' if should_copy_subagents else 'Disabled'}\033[0m")
        
        # Display options
        print("\n\033[1mOptions:\033[0m")
        print(f"  1. {'Disable' if should_copy_subagents else 'Enable'} copying default subagents at startup")
        print("  b. Back to main preferences menu")
        
        # Get user selection
        selection = input("\n\033[1mEnter choice: \033[0m").strip().lower()
        
        if selection == 'b':
            return True
        elif selection == '1':
            # Toggle enabled state and update environment setting
            new_setting = not should_copy_subagents
            new_value = "true" if new_setting else "false"
            SETTINGS.set_env_var(EnvConfig.CODA_COPY_DEFAULT_AGENTS, new_value)
            
            # Show confirmation without clearing screen
            status = "enabled" if new_setting else "disabled"
            print(f"\033[1;32mCopying default subagents at startup {status}.\033[0m")
            
            time.sleep(1.5)
        else:
            print(f"\033[1;31mInvalid selection: {selection}. Please try again.\033[0m")
            time.sleep(1.5)