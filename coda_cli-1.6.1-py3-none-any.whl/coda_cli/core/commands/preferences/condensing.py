import time
from loguru import logger

from coda_core.config.env_config import EnvConfig
from coda_core.config.settings import SETTINGS
from coda_core.core.memories.condenser import MemoryCondenser


def manage_memory_condensing_preferences(cli) -> None:
    """
    Manage global memory condensing preferences.
    
    Args:
        cli: The CLI instance that's calling this function
    
    This function provides an interface for configuring memory condensing settings:
    - Enable/disable memory condensing
    - Set condensing threshold
    """
    while True:
        # Clear screen at the start of each iteration
        print("\033[2J\033[H", end="")  # Clear screen
        
        # Get current settings from environment
        enabled = SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_ENABLED).lower() == "true"
        threshold = float(SETTINGS.get_env_var(EnvConfig.CODA_MEMORY_CONDENSING_THRESHOLD))
        threshold_percent = int(threshold * 100)
        
        # Display current settings
        print("\n\033[1;36mMemory Condensing Settings (Global)\033[0m")
        print("\033[1;36m================================\033[0m")
        print(f"Memory condensing: \033[1;{'32' if enabled else '31'}m{'Enabled' if enabled else 'Disabled'}\033[0m")
        if enabled:
            print(f"Condensing threshold: \033[1;33m{threshold_percent}%\033[0m (condenses when memory reaches {threshold_percent}% of capacity)")
        
        # Display options
        print("\n\033[1mOptions:\033[0m")
        print(f"  1. {'Disable' if enabled else 'Enable'} memory condensing")
        if enabled:
            print("  2. Change condensing threshold")
        print("  b. Back to main preferences menu")
        
        # Get user selection
        selection = input("\n\033[1mEnter choice: \033[0m").strip().lower()
        
        if selection == 'b':
            break
        elif selection == '1':
            # Toggle enabled state and update environment setting
            new_enabled = not enabled
            SETTINGS.set_env_var(
                EnvConfig.CODA_MEMORY_CONDENSING_ENABLED,
                "true" if new_enabled else "false"
            )
            
            # Show confirmation without clearing screen
            status = "enabled" if new_enabled else "disabled"
            print(f"\033[1;32mMemory condensing {status}.\033[0m")
            
            # Apply changes to current memories
            _apply_memory_condensing_settings(cli, new_enabled, threshold)
            
            # Sleep briefly to show the message
            time.sleep(1.5)
            
            # Clear screen before showing the menu again
            print("\033[2J\033[H", end="")
        elif selection == '2' and enabled:
            # Get new threshold
            while True:
                try:
                    new_threshold_percent = input("\nEnter new threshold percentage (30-90%): ").strip().rstrip('%')
                    new_threshold_percent = int(new_threshold_percent)
                    
                    # Enforce the proper threshold range (30-90%)
                    if 30 <= new_threshold_percent <= 90:
                        # Convert percentage to decimal
                        new_threshold = new_threshold_percent / 100.0
                        
                        # Update environment setting
                        SETTINGS.set_env_var(
                            EnvConfig.CODA_MEMORY_CONDENSING_THRESHOLD,
                            str(new_threshold)
                        )
                        
                        # Show confirmation without clearing screen
                        print(f"\033[1;32mCondensing threshold set to {new_threshold_percent}%.\033[0m")
                        
                        # Apply changes to current memories
                        _apply_memory_condensing_settings(cli, enabled, new_threshold)
                        
                        # Sleep briefly to show the message
                        time.sleep(1.5)
                        
                        # Clear screen before showing the menu again
                        print("\033[2J\033[H", end="")
                        break
                    else:
                        print("\033[1;31mThreshold must be between 30% and 90%.\033[0m")
                except ValueError:
                    print("\033[1;31mInvalid input. Please enter a number.\033[0m")
        else:
            # Show error without clearing screen
            print(f"\033[1;31mInvalid selection: {selection}. Please try again.\033[0m")
            # Wait a moment to show the error
            time.sleep(1.5)
            # Clear screen before showing the menu again
            print("\033[2J\033[H", end="")


def _apply_memory_condensing_settings(cli, enabled: bool, threshold: float) -> None:
    """
    Apply memory condensing settings to all current memories.
    
    Args:
        cli: The CLI instance that's calling this function
        enabled: Whether memory condensing is enabled
        threshold: The threshold percentage (as a decimal) for memory condensing
    """
    # Apply to all memories in shared state
    for key, memory in cli.shared_state.memories.items():
        if enabled:
            # Create a new condenser if needed
            if memory.condenser is None:
                memory.condenser = MemoryCondenser(threshold=threshold)
            else:
                # Update existing condenser threshold
                memory.condenser.threshold = threshold
                
            logger.info(f"Memory condensing enabled for '{key}' memory with threshold={int(threshold*100)}%")
        else:
            # Remove condenser if present
            if memory.condenser is not None:
                memory.condenser = None
                logger.info(f"Memory condensing disabled for '{key}' memory")
    
    # If we have a single agent, update its memory's condenser too
    if hasattr(cli.shared_state, 'main_agent') and hasattr(cli.shared_state.main_agent, 'memory'):
        memory = cli.shared_state.main_agent.memory
        
        if enabled:
            # Create a new condenser if needed
            if memory.condenser is None:
                memory.condenser = MemoryCondenser(threshold=threshold)
            else:
                # Update existing condenser threshold
                memory.condenser.threshold = threshold
                
            logger.info(f"Memory condensing enabled for single agent memory with threshold={int(threshold*100)}%")
        else:
            # Remove condenser if present
            if memory.condenser is not None:
                memory.condenser = None
                logger.info(f"Memory condensing disabled for single agent memory")
        
        # Auto-save session after each change
        cli._auto_save_if_needed()