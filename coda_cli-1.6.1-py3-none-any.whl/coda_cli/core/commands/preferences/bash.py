import time

from coda_core.config.env_config import EnvConfig
from coda_core.config.settings import SETTINGS


def manage_bash_security_preferences(cli, security_prefs: dict) -> None:
    """
    Manage bash command security preferences for the current session.
    
    Args:
        cli: The CLI instance that's calling this function
        security_prefs: The bash security preferences dictionary from the session
    """
    def _update_security_level(level: str, warning_msg: str = None):
        """
        Helper function to update security level and handle common tasks.
        
        Args:
            level: The security level to set ('low', 'medium', or 'high')
            warning_msg: Optional warning message to display
        """
        # Store the previous level to detect changes
        prev_level = security_prefs.get("max_auto_approve_level", "low").lower()
        
        # Update the security level
        security_prefs["max_auto_approve_level"] = level
        
        # Clear screen and show confirmation
        print("\033[2J\033[H", end="")
        print(f"\033[1;32mMaximum auto-approve level set to {level.upper()}.\033[0m")
        
        # Show warning message if provided
        if warning_msg:
            print(f"\033[1;33m{warning_msg}\033[0m")
        
        # Only ask about making it default if the level actually changed
        if prev_level != level:
            cli._ask_make_security_level_default(level)
        
        print("Returning to security preferences menu...")
        time.sleep(1.5)
    
    while True:
        # Clear screen
        print("\033[2J\033[H", end="")  # Clear screen
        
        # Get current values with defaults
        max_level = security_prefs.get("max_auto_approve_level", "low").lower()
        disable_checks = security_prefs.get("disable_all_checks", False)
        
        # Display current settings
        print("\n\033[1;36mBash Command Security Preferences\033[0m")
        print("\033[1;36m===============================\033[0m")
        
        # Display security warning with emoji and light yellow text
        print("\n\033[1;33m⚠️ WARNING:\033[0m \033[33mChanging the default security settings may introduce security risks.")
        print("\033[33mHigher auto-approval levels reduce the number of prompts but may allow potentially")
        print("\033[33mdangerous commands to execute without explicit confirmation.\033[0m")
        
        print("\n\033[1mMaximum auto-approve level:\033[0m")
        print(f"  1. LOW only (risks up to LOW are auto-approved){' \033[1;32m[Current]\033[0m' if max_level == 'low' else ''}")
        print(f"  2. MEDIUM (risks up to MEDIUM are auto-approved){' \033[1;32m[Current]\033[0m' if max_level == 'medium' else ''}")
        print(f"  3. HIGH (risks up to HIGH are auto-approved){' \033[1;32m[Current]\033[0m' if max_level == 'high' else ''}")
        
        print("\n\033[1mActions:\033[0m")
        print("  r. Reset security preferences to global settings")
        print("  b. Back to main preferences menu")
        
        # Get user selection
        selection = input("\n\033[1mEnter choice: \033[0m").strip().lower()
        
        if selection == 'b':
            break
        elif selection == 'r':
            # Get global security preferences from environment variable
            default_level = SETTINGS.get_env_var(EnvConfig.CODA_DEFAULT_BASH_SECURITY_LEVEL) or "low"
            
            # Reset to global security preferences
            security_prefs.update({
                "max_auto_approve_level": default_level,
                "disable_all_checks": False,
            })
            
            # Clear screen and show confirmation
            print("\033[2J\033[H", end="")
            print("\033[1;32mSecurity preferences have been reset to global settings.\033[0m")
            print("Returning to security preferences menu...")
            time.sleep(1.5)
        elif selection == '1':
            _update_security_level("low")
        elif selection == '2':
            _update_security_level("medium", "Note: This will auto-approve MEDIUM risk commands without prompting.")
        elif selection == '3':
            _update_security_level("high", "WARNING: This will auto-approve HIGH risk commands without prompting.")
        else:
            # Clear screen and show error
            print("\033[2J\033[H", end="")
            print(f"\033[1;31mInvalid selection: {selection}. Please try again.\033[0m")
            print("Returning to security preferences menu...")
            time.sleep(1.5)
