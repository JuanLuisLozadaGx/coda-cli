from loguru import logger
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.config.utils import are_geai_credentials_available
from coda_cli.core.utils.remote_mentions import (
    get_remote_mentions_preferences,
    set_remote_mentions_mode,
    set_remote_mentions_allowlist,
)

from coda_cli.config.constants import FAQ_URL, SLACK_CHANNEL_NAME, SLACK_CHANNEL_URL
from coda_cli.core import ui
from coda_cli.core.utils.utils import get_yes_no_input
from coda_core.config.constants import (
    DIAGNOSE_AGENT,
    FIX_AGENT,
    EXPLAIN_AGENT,
)


def show_context_error(error_message: str) -> None:
    """Render context flag error for agent calls."""
    print(ui.block_header("Invalid Context", icon="⚠️", color_code="38;5;214"))
    print(ui.block_line("Error", error_message, box_color="38;5;214"))
    print(ui.block_line("Usage", "--context [none|recent|full]", box_color="38;5;214"))
    print(ui.block_footer())
    input("\nPress Enter to continue...")


def show_geai_not_configured() -> None:
    """Render GEAI configuration missing notice."""
    print(ui.block_header("GEAI Not Configured", icon="❌", color_code="38;5;196"))
    print(ui.block_line("Error", "GEAI environment variables not set", box_color="38;5;196"))
    print(ui.block_line("Required", "CODA_GEAI_BASE_URL and CODA_GEAI_API_KEY", box_color="38;5;196"))
    print(ui.block_footer())
    input("\nPress Enter to continue...")


class CLIAgentsManager:
    """
    Interactive agents management interface following CODA's UI patterns.
    
    Provides a comprehensive menu system for managing agents with features
    including agent listing, creation, updating, deletion, and execution.
    """
    
    def __init__(self, cli):
        """
        Initialize the Agents UI.
        
        Args:
            cli: CODA's CLI instance for accessing agent functionality
        """
        self.cli = cli
        self.agent_manager = cli.agent_manager
        
    def run_interactive_session(self):
        """Run the main interactive agents management session."""
        while True:
            try:
                self._display_main_menu()
                choice = input("\nEnter choice: ").strip().lower()
                
                if choice == 'q':
                    break
                elif choice == '1':
                    self._handle_list_command()
                elif choice == '2':
                    self._create_or_update_agent()
                elif choice == '3':
                    self._handle_delete_command("")
                elif choice == '4':
                    self._configure_remote_agents()
                elif choice == '5':
                    self._show_help()
                else:
                    print("Invalid choice. Please try again.")
                    
            except KeyboardInterrupt:
                print("\n\nExiting agents management...")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}")
                
    def _display_main_menu(self):
        """Display the main agents management menu."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        # Display header with improved styling
        print(ui.block_header("CODA Agents Manager", icon="🤖", color_code="38;5;81"))
        print(ui.block_line("Info", "Call agents with @ (local and remote)", box_color="38;5;81"))
        print(ui.block_footer())

        # Menu options with improved styling and icons
        print("\n\033[1;38;5;81mAvailable options:\033[0m")
        print("  \033[1;36m1.\033[0m \033[1mAvailable agents\033[0m")
        print("  \033[1;36m2.\033[0m \033[1mCreate\033[0m or \033[1mUpdate\033[0m a local Agent with AI")
        print("  \033[1;36m3.\033[0m \033[1mRemove\033[0m a local Agent")
        print("  \033[1;36m4.\033[0m \033[1mRemote Agents\033[0m visibility in '@' mentions")
        print("  \033[1;36m5.\033[0m \033[1mQuick Start Guide\033[0m")
        print()
        print("  \033[1;33mq.\033[0m \033[3mReturn to main interface\033[0m")
        
        # Directory info with improved styling
        agents_dir = SETTINGS.get_env_var(EnvConfig.CODA_AGENTS_DIR_PATH)
        print(f"\n\033[38;5;245m╭─ \033[3mInformation\033[0m \033[38;5;245m───────────────────────────────────")
        print(f"\033[38;5;245m│\033[0m The local agents definition can be found in the coda directory.")
        print(f"\033[38;5;245m│\033[0m It's possible to manually modify the agents prompts.")
        print(f"\033[38;5;245m│\033[0m Directory: \033[38;5;81m{agents_dir}\033[0m")
        print(f"\033[38;5;245m│\033[0m Adjust context per call with: @agent --context full|recent|none")
        print(f"\033[38;5;245m╰────────────────────────────────────────────────────────")

    def _configure_remote_agents(self) -> bool:
        """Interactive configuration for remote GEAI agent visibility in '@' mentions."""
        print("\033[2J\033[H", end="")  # Clear screen

        geai_base_url = SETTINGS.get_env_var(EnvConfig.CODA_GEAI_BASE_URL)
        geai_api_key = SETTINGS.get_env_var(EnvConfig.CODA_GEAI_API_KEY)
        if not geai_base_url or not geai_api_key:
            print(ui.block_header("GEAI Not Configured", icon="❌", color_code="38;5;196"))
            print(ui.block_line("Error", "GEAI environment variables not set", box_color="38;5;196"))
            print(ui.block_line("Required", "CODA_GEAI_BASE_URL and CODA_GEAI_API_KEY", box_color="38;5;196"))
            print(ui.block_footer())
            input("\nPress Enter to continue...")
            return True

        # Load full remote list
        remote_agents = self.agent_manager.list_remote_agents_cached()
        names = [a.name for a in remote_agents]
        try:
            mode, _, allow_set = get_remote_mentions_preferences()
        except Exception:
            mode, allow_set = "favorites", set()

        def _allowed_count():
            if mode == "all":
                return len(names)
            if mode == "none":
                return 0
            return len([n for n in names if n in allow_set])

        print(ui.block_header("Remote Agents Visibility", icon="☁️", color_code="38;5;81"))
        print(ui.block_line("Mode", f"{mode}", box_color="38;5;81"))
        print(ui.block_line("Remote agents", f"{len(names)} found", box_color="38;5;81"))
        print(ui.block_line("Allowed in @", f"{_allowed_count()}", box_color="38;5;81"))
        print(ui.block_footer())

        while True:
            print("\nOptions:")
            print("  1. Hide all")
            print("  2. Show favorites")
            print("  3. Show all")
            print("  4. Edit favorites list")
            print()
            print("  q. Return to agents menu")

            choice = input("\nEnter choice: ").strip().lower()
            if choice == 'q':
                return True
            elif choice == '1':
                set_remote_mentions_mode("none")
                mode = "none"
            elif choice == '2':
                set_remote_mentions_mode("favorites")
                mode = "favorites"
            elif choice == '3':
                set_remote_mentions_mode("all")
                mode = "all"
            elif choice == '4':
                if not names:
                    print("\nNo remote agents available to configure.")
                    input("Press Enter to continue...")
                    continue
                while True:
                    print("\nSelect favorite remote agents for '@' (toggle with numbers):")
                    for idx, n in enumerate(names, 1):
                        mark = "x" if n in allow_set else " "
                        print(f"  [{mark}] {idx}. {n}")
                    print("\nCommands: numbers to toggle (e.g., 1 3 5), 'a' all, 'n' none, 's' save, 'c' cancel")
                    sel = input("Choice: ").strip().lower()
                    if sel == 'c':
                        break
                    if sel == 'a':
                        allow_set = set(names)
                        continue
                    if sel == 'n':
                        allow_set = set()
                        continue
                    if sel == 's':
                        set_remote_mentions_allowlist(",".join(sorted(allow_set)))
                        if mode not in {"all", "none"}:
                            set_remote_mentions_mode("favorites")
                            mode = "favorites"
                        if hasattr(self.cli, 'agent_completer'):
                            try:
                                self.cli.agent_completer.refresh()
                            except Exception:
                                pass
                        print("\nSaved favorites list.")
                        input("Press Enter to continue...")
                        break
                    parts = [p for p in sel.replace(',', ' ').split() if p]
                    for p in parts:
                        try:
                            i = int(p)
                            if 1 <= i <= len(names):
                                name = names[i-1]
                                if name in allow_set:
                                    allow_set.remove(name)
                                else:
                                    allow_set.add(name)
                        except ValueError:
                            continue
            else:
                print("Invalid choice. Please try again.")

            # Refresh completer after any update
            if hasattr(self.cli, 'agent_completer'):
                try:
                    self.cli.agent_completer.refresh()
                except Exception:
                    pass

            # Reprint status
            print("\033[2J\033[H", end="")
            print(ui.block_header("Remote Agents Visibility", icon="☁️", color_code="38;5;81"))
            print(ui.block_line("Mode", f"{mode}", box_color="38;5;81"))
            print(ui.block_line("Remote agents", f"{len(names)} found", box_color="38;5;81"))
            print(ui.block_line("Allowed in @", f"{_allowed_count()}", box_color="38;5;81"))
            print(ui.block_footer())

        return True
        
    def _create_or_update_agent(self, agent_name=None, agent_description=None, agent_changes=None):
        """
        Interactive agent creation or update with UI logic.
        
        Args:
            agent_name: Optional name of the agent to create/update
            agent_description: Optional prompt for a new agent
            agent_changes: Optional changes for an existing agent
        
        Returns:
            bool: True to continue CLI execution, False to exit
        """
        # If no parameters provided, show the selection menu
        if not any([agent_name, agent_description, agent_changes]):
            print("\033[2J\033[H", end="")  # Clear screen
            
            print(f"\n{ui.color('╭── ', '38;5;81')}➕ Agent Creation/Update {ui.color('────────────────────────', '38;5;81')}")
            
            print("\nDo you want to:")
            print("  1. Create a new agent")
            print("  2. Update an existing agent")
            print()
            print("  \033[1;33mq.\033[0m Return to agents menu")
            
            choice = input("\nEnter choice: ").strip()
            
            if choice == "1":
                self._create_new_agent()
            elif choice == "2":
                self._update_existing_agent()
            elif choice == "q":
                return True
            else:
                input("Invalid choice. Press Enter to continue...")
                return True
        
        # Create a new agent
        elif agent_name and agent_description and not agent_changes:
            try:
                # Display creation process header
                print(ui.block_header("Creating Agent", icon="🚀", color_code="38;5;81"))
                print(ui.block_line("Name", agent_name, box_color="38;5;81"))
                print(ui.block_line("Description", agent_description, box_color="38;5;81"))
                print(ui.block_footer())
                
                # Collect inputs
                agents_dir_path = SETTINGS.get_env_var(EnvConfig.CODA_AGENTS_DIR_PATH)

                # Call the agent-manager
                agent_manager = self.cli.agent_manager
                agent_input = f"Create a new agent with name '{agent_name}', description '{agent_description}', in directory '{agents_dir_path}'"
                            
                # Display processing message
                print(ui.block_line("Processing", "Calling agent-manager to create the agent...", box_color="38;5;81"))
                                
                # Create the subagent using the AgentManager
                subagent = agent_manager.create_agent(
                    agent_name="agent-manager", 
                    memory=None,
                    file_editor=self.cli.agent_handler.file_editor,
                    user_defined_rules=self.cli.shared_state.user_defined_rules
                )

                if not subagent:
                    print(ui.block_header("Agent Creation Failed", icon="❌", color_code="38;5;196"))
                    print(ui.block_line("Error", "Failed to initialize agent-manager", box_color="38;5;196"))
                    print(ui.block_footer())
                    input("\nPress Enter to continue...")
                    return True
                
                # Process the request
                result = self.cli.agent_handler.handle_interaction_with_agent(
                    user_message=agent_input, agent=subagent)
                
                if result:
                    print(ui.block_header("Agent Created", icon="✅", color_code="38;5;40"))
                    print(ui.block_line("Status", f"Agent '{agent_name}' created successfully", box_color="38;5;40"))
                    print(ui.block_line("Location", f"{agents_dir_path}/{agent_name}", box_color="38;5;40"))
                    print(ui.block_footer())
                    
                    # Force refresh of agent completer so the new agent shows up immediately in @ completions
                    if hasattr(self.cli, 'agent_completer'):
                        self.cli.agent_completer._refresh_agents()
                else:
                    print(ui.block_header("Agent Creation Warning", icon="⚠️", color_code="38;5;214"))
                    print(ui.block_line("Status", "No response from agent-manager", box_color="38;5;214"))
                    print(ui.block_line("Action", "Please check agent directory for results", box_color="38;5;214"))
                    print(ui.block_footer())
                
                input("\nPress Enter to continue...")
                return True
                
            except Exception as e:
                logger.error(f"Error creating agent: {e}")
                print(ui.block_header("Creation Error", icon="❌", color_code="38;5;196"))
                print(ui.block_line("Error", str(e), box_color="38;5;196"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True
        
        # Update an existing agent
        elif agent_name and agent_changes and not agent_description:
            try:
                # Validate agent exists
                agent_manager = self.cli.agent_manager
                agent_def = agent_manager.load_agent_metadata(agent_name)
                if not agent_def:
                    print(ui.block_header("Agent Not Found", icon="❌", color_code="38;5;196"))
                    print(ui.block_line("Agent", agent_name, box_color="38;5;196"))
                    print(ui.block_line("Error", "The requested agent does not exist", box_color="38;5;196"))
                    print(ui.block_footer())
                    input("\nPress Enter to continue...")
                    return True
                
                agents_dir_path = SETTINGS.get_env_var(EnvConfig.CODA_AGENTS_DIR_PATH)
                
                # Display update process header
                print(ui.block_header("Updating Agent", icon="🔄", color_code="38;5;81"))
                print(ui.block_line("Name", agent_name, box_color="38;5;81"))
                print(ui.block_line("Changes", agent_changes, box_color="38;5;81"))
                print(ui.block_footer())
                
                # Display processing message
                print(ui.block_line("Processing", "Calling agent-manager to update the agent...", box_color="38;5;81"))
                
                # Call the agent-manager
                agent_input = f"Update the agent with name '{agent_name}' with these changes: '{agent_changes}'. The agent is located in directory '{agents_dir_path}/{agent_name}'"
                
                # Create the subagent using the AgentManager
                subagent = agent_manager.create_agent(
                    agent_name="agent-manager", 
                    memory=None,
                    file_editor=self.cli.agent_handler.file_editor,
                    user_defined_rules=self.cli.shared_state.user_defined_rules
                )
                
                if not subagent:
                    print(ui.block_header("Agent Update Failed", icon="❌", color_code="38;5;196"))
                    print(ui.block_line("Error", "Failed to initialize agent-manager", box_color="38;5;196"))
                    print(ui.block_footer())
                    input("\nPress Enter to continue...")
                    return True
                
                # Process the request
                result = self.cli.agent_handler.handle_interaction_with_agent(
                    user_message=agent_input, agent=subagent)
                
                if result:
                    print(ui.block_header("Agent Updated", icon="✅", color_code="38;5;40"))
                    print(ui.block_line("Status", f"Agent '{agent_name}' updated successfully", box_color="38;5;40"))
                    print(ui.block_line("Location", f"{agents_dir_path}/{agent_name}", box_color="38;5;40"))
                    print(ui.block_footer())
                    
                    # Force refresh of agent completer so the updated agent shows up immediately in @ completions
                    if hasattr(self.cli, 'agent_completer'):
                        self.cli.agent_completer._refresh_agents()
                else:
                    print(ui.block_header("Agent Update Warning", icon="⚠️", color_code="38;5;214"))
                    print(ui.block_line("Status", "No response from agent-manager", box_color="38;5;214"))
                    print(ui.block_line("Action", "Please check agent directory for results", box_color="38;5;214"))
                    print(ui.block_footer())
                
                input("\nPress Enter to continue...")
                return True
                
            except Exception as e:
                logger.error(f"Error updating agent: {e}")
                print(ui.block_header("Update Error", icon="❌", color_code="38;5;196"))
                print(ui.block_line("Error", str(e), box_color="38;5;196"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True
        
        return True
            
    def _create_new_agent(self):
        """Handle creation of a new agent."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        print(f"\n{ui.color('╭── ', '38;5;81')}➕ Create New Agent {ui.color('────────────────────────', '38;5;81')}")
        
        print("\nEnter agent details:")
        agent_name = input("Agent name: ").strip()
        if not agent_name:
            print("❌ Agent Name cannot be empty.")
            input("Press Enter to continue...")
            return
            
        agent_description = input("Agent Prompt: ").strip()
        if not agent_description:
            print("❌ Agent Prompt cannot be empty.")
            input("Press Enter to continue...")
            return
            
        # Call the updated method with the collected parameters
        self._create_or_update_agent(agent_name=agent_name, agent_description=agent_description)
        return True

        
    def _update_existing_agent(self):
        """Handle updating an existing agent."""
        print("\033[2J\033[H", end="")  # Clear screen
        
        print(f"\n{ui.color('╭── ', '38;5;81')}🔄 Update Existing Agent {ui.color('────────────────────', '38;5;81')}")
        
        # List available agents for selection
        agents = self.agent_manager.filter_agents_list(attribute="command") # Filter only subagents with command = True
        
        if not agents:
            print("\n🔍 No agents available to update.")
            input("Press Enter to continue...")
            return
            
        print("\nAvailable agents:")
        for i, agent_name in enumerate(agents, 1):
            print(f"  \033[1;36m{i}.\033[0m {agent_name}")
            
        print(f"  \033[1;33m{len(agents) + 1}.\033[0m Cancel")
        
        try:
            choice = input(f"\nSelect agent to update (1-{len(agents) + 1}): ").strip()
            choice_num = int(choice)
            
            if choice_num == len(agents) + 1:
                return
                
            if 1 <= choice_num <= len(agents):
                agent_name = agents[choice_num - 1]
                changes = input(f"Enter changes for agent '{agent_name}': ").strip()
                
                if not changes:
                    print("❌ Changes cannot be empty.")
                    input("Press Enter to continue...")
                    return
                    
                # Call the updated method with the collected parameters
                self._create_or_update_agent(agent_name=agent_name, agent_changes=changes)
                return True
            else:
                print("Invalid selection.")
                input("Press Enter to continue...")
        except ValueError:
            print("Invalid input. Please enter a number.")
            input("Press Enter to continue...")

            
    def _handle_list_command(self) -> bool:
        """Handle the 'list' subcommand to display local and remote agents."""
        try:
            print("\033[2J\033[H", end="")  # Clear screen

            print(ui.block_header("Available Agents", icon="🤖", color_code="38;5;81"))

            agent_manager = self.cli.agent_manager
            agent_manager.initialize_default_agents()

            local_agents = agent_manager.list_agents()

            geai_configured = are_geai_credentials_available()
            remote_agents = agent_manager.list_remote_agents_cached()

            total_count = len(local_agents) + len(remote_agents)
            if total_count == 0:
                print(ui.block_line("Status", "No agents available in the system", box_color="38;5;81"))
                if not geai_configured:
                    print(ui.block_line("Note", "Configure CODA_GEAI_BASE_URL and CODA_GEAI_API_KEY for remote agents", box_color="38;5;81"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True

            print(ui.block_line("Local", f"{len(local_agents)} agents", box_color="38;5;81"))
            print(ui.block_line("Remote", f"{len(remote_agents)} GEAI agents", box_color="38;5;81"))
            print(ui.block_footer())

            if local_agents:
                grouped_agents = {}
                for agent_name in local_agents:
                    agent_def = agent_manager.load_agent_metadata(agent_name)
                    if agent_def:
                        group = getattr(agent_def.metadata, 'category', None) or "General"
                        grouped_agents.setdefault(group, []).append((agent_name, agent_def))

                for group_name, group_members in grouped_agents.items():
                    print(f"\n\033[1;35m{group_name} Agents:\033[0m")
                    for index, (agent_name, agent_def) in enumerate(group_members, 1):
                        description = agent_def.metadata.description
                        command_enabled = "✅" if agent_def.metadata.command else "❌"
                        discoverable = "✅" if agent_def.metadata.discoverable else "❌"
                        model = agent_def.metadata.model
                        tools = agent_def.metadata.tools

                        print(f"  \033[1;36m{index}.\033[0m \033[1m{agent_name}\033[0m")
                        print(f"     \033[90mDescription: {description}\033[0m")
                        print(f"     \033[90mCommand: {command_enabled}  Discoverable: {discoverable}\033[0m")
                        print(f"     \033[90mModel: {model}  Tools: {tools}\033[0m")
                        print()

            if remote_agents:
                print(f"\n\033[1;34mRemote GEAI Agents ☁️:\033[0m")
                for index, agent in enumerate(remote_agents, 1):
                    description = agent.description or "No description"
                    status_icon = "🟢" if agent.status == "active" else "🔴"
                    print(f"  \033[1;36m{index}.\033[0m \033[1m{agent.name}\033[0m {status_icon}")
                    print(f"     \033[90mDescription: {description}\033[0m")
                    print(f"     \033[90mStatus: {agent.status}  ID: {agent.id}\033[0m")
                    if getattr(agent, 'version', None):
                        print(f"     \033[90mVersion: {agent.version}  Revision: {getattr(agent, 'revision', 'N/A')}\033[0m")
                    print()

            if not geai_configured:
                print(f"\n\033[90mNote: Configure CODA_GEAI_BASE_URL and CODA_GEAI_API_KEY to access remote GEAI agents\033[0m")

            input("\nPress Enter to continue...")
            return True

        except Exception as exc:
            logger.error(f"Error listing agents: {exc}")
            print(ui.block_header("List Error", icon="❌", color_code="38;5;196"))
            print(ui.block_line("Error", str(exc), box_color="38;5;196"))
            print(ui.block_footer())
            input("\nPress Enter to continue...")
            return True
    
    def _handle_delete_command(self, args: str) -> bool:
        """
        Handle the 'delete' subcommand to delete an existing agent.
        
        Args:
            args: Command arguments containing "delete" and agent name
            
        Returns:
            bool: True to continue CLI execution, False to exit
        """
        try:
            # Clear screen
            print("\033[2J\033[H", end="")  # Clear screen
            
            print(f"\n{ui.color('╭── ', '38;5;81')}🗑️ Delete Agent {ui.color('──────────────────────────────', '38;5;81')}")
            
            agent_manager = self.cli.agent_manager
            agent_manager.initialize_default_agents()
            agents = agent_manager.filter_agents_list(attribute="command")  # Filter only subagents with command
            
            if not agents:
                print("\n🔍 No agents configured to delete.")
                input("Press Enter to continue...")
                return True
                
            print("\nAvailable agents:")
            
            for i, agent_name in enumerate(agents, 1):
                print(f"  \033[1;36m{i}.\033[0m {agent_name}")
            
            print()
            print("  \033[1;33mq.\033[0m Return to agents menu")
            
            choice = input(f"\nSelect agent to delete (1-{len(agents)}) or q to quit: ").strip()
            
            try:
                if choice.lower() == 'q':
                    return True
                    
                choice_num = int(choice)
                    
                if 1 <= choice_num <= len(agents):
                    agent_name = agents[choice_num - 1]
                    
                    # Confirm deletion
                    if get_yes_no_input(f"Remove agent '{agent_name}'?", default="no"):
                        # Delete the agent
                        success = agent_manager.delete_agent(agent_name)
                        
                        if success:
                            print(f"\n✅ Agent '{agent_name}' removed successfully!")
                            
                            # Force refresh of agent completer so the deleted agent is immediately removed from @ completions
                            if hasattr(self.cli, 'agent_completer'):
                                self.cli.agent_completer._refresh_agents()
                        else:
                            print(f"\n❌ Failed to remove agent '{agent_name}'.")
                    else:
                        print("Deletion cancelled.")
                else:
                    print("Invalid selection.")
                    
            except ValueError:
                print("Invalid input. Please enter a number.")
                
        except Exception as e:
            logger.error(f"Error deleting agent: {e}")
            print(ui.block_header("Deletion Error", icon="❌", color_code="38;5;196"))
            print(ui.block_line("Error", str(e), box_color="38;5;196"))
            print(ui.block_footer())
            
        input("\nPress Enter to continue...")
        return True

    def _show_help(self) -> bool:
        """Display help for the agents command."""
        try:
            # Clear screen
            print("\033[2J\033[H", end="")  # Clear screen
            
            print(ui.block_header("CODA Agents Quick Start", icon="❓", color_code="38;5;81"))
            print("  Work faster with local and remote agents.\n  Call them inline with @, or manage them from /agents.")

            # Using @
            print("\n🚀 Using @")
            print("  \033[1;36m•\033[0m Type \033[1;36m@\033[0m for autocompletion of available agents")
            print("  \033[1;36m•\033[0m Local agents always appear in @ suggestions")
            print("  \033[1;36m•\033[0m Remote agents in @ depend on visibility mode: \033[1mnone\033[0m | \033[1mfavorites\033[0m | \033[1mall\033[0m")
            print("  \033[1;36m•\033[0m Change mode in: /agents → Remote Agents visibility")
            print("  \033[1;36m•\033[0m Control context per call with: @agent --context full|recent|none")

            # Popular local agents
            print("\n✨ Popular local agents")
            print(f"  \033[1;36m•\033[0m @{DIAGNOSE_AGENT} [issue-description]")
            print(f"  \033[1;36m•\033[0m @{FIX_AGENT} [issue-description]")
            print(f"  \033[1;36m•\033[0m @{EXPLAIN_AGENT} [path-to-ticket-folder]")

            # Chaining
            print("\n🔄 Chain agents")
            print("  Example: \033[1;36m@diagnose ./bug-report.txt @fix\033[0m")

            # Remote agents section
            print("\n☁️  Remote GEAI Agents")
            print("  \033[1;36m•\033[0m Run any remote explicitly:")
            print("     /agents run-remote Code Fixer [input]")
            print("  \033[1;36m•\033[0m Find them with: /agents list (shows Local and Remote counts)")
            print("  \033[1;36m•\033[0m Favorites: pick them in /agents → Remote Agents visibility (affects @)")
            print("  \033[1;36m•\033[0m Connects with your GEAI credentials: CODA_GEAI_BASE_URL, CODA_GEAI_API_KEY")

            # Low-level interface
            print("\n🔍 Low-level interface")
            print("  \033[1;36m•\033[0m /agents list                        - List all available agents")
            print("  \033[1;36m•\033[0m /agents delete                      - Delete an existing agent")
            print("  \033[1;36m•\033[0m /agents create                      - Opens create agent menu")
            print("  \033[1;36m•\033[0m /agents update                      - Opens update agent menu")
            print("  \033[1;36m•\033[0m /agents create [name] [description] - Create a new agent without the menu")
            print("  \033[1;36m•\033[0m /agents update [name] [changes]     - Update an existing agent without the menu")
            print("  \033[1;36m•\033[0m /agents [agent-name] [input]        - Run a specific \033[1mlocal\033[0m agent")

            print("\n📚 Resources:")
            ui.print_hyperlink("\033[1;36m•\033[0m Check our FAQ", FAQ_URL)
            ui.print_hyperlink(
                "\033[1;36m•\033[0m Agents Dashboard – Create agents in The Lab, then use them in CODA CLI",
                "https://docs.globant.ai/en/wiki?1033,Agents+Dashboard",
            )
            ui.print_hyperlink(f"\033[1;36m•\033[0m Slack: {SLACK_CHANNEL_NAME}", SLACK_CHANNEL_URL)

            # Add navigation instruction and wait for user input
            print("\n\033[1;33mPress Enter to return to the main menu...\033[0m")
            input("")
            return True
        except Exception as e:
            logger.error(f"Error displaying help: {e}")
            print(f"\n❌ Error displaying help: {e}")
            print("\nPress Enter to return to the main menu...")
            input("")
            return True
