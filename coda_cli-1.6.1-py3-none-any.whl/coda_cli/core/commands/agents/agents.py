from typing import List
from loguru import logger
from coda_cli.core import ui
from coda_core.config.utils import are_geai_credentials_available

from coda_core.core.agents.constants import AGENT_CONTEXT_DEFAULT_MODE, AGENT_CONTEXT_VALID_MODES
from coda_core.core.agents.utils import extract_remote_agent_command, parse_agent_invocation, build_agent_prompt
from coda_cli.core.commands.base import Command
from coda_cli.core.commands.agents.ui import CLIAgentsManager, show_context_error, show_geai_not_configured

class AgentsCommand(Command):
    """Implementation of the /agents command to manage and use AI subagents."""
    
    def aliases(self) -> List[str]:
        """Return command aliases."""
        return ["/agents"]
    
    def description(self) -> str:
        """Return command description."""
        return "Manage and use AI subagents"
    
    def arguments(self) -> List[str]:
        """Return command arguments."""
        return ["list", "create", "delete", "update", "run-remote", "[subagent-name]", "[input]"]
    
    def execute(self, args) -> bool:
        """
        Handles the '/agents' command to manage and use AI subagents.

        Args:
            args (str): The arguments provided with the '/agents' command.

        Returns:
            bool: True to continue CLI execution, False to exit.
        """
        try:
            # Initialize agent manager (guarded to avoid redundant work)
            self.cli.agent_manager.initialize_default_agents()
            
            if not args:
                # Run the interactive agents manager interface
                agents_ui = CLIAgentsManager(cli=self.cli)
                agents_ui.run_interactive_session()
                return True
                
            # Parse arguments
            arg_parts = args.strip().split(maxsplit=1)

            # after /agents comes the "first argument"
            first_arg = arg_parts[0].lower() if arg_parts else ""
            
            # Handle REPL subcommands
            if first_arg == "list":
                # List available agents
                return self._handle_list_command()
            elif first_arg in ["help", "-h"]:
                return self._handle_help_command()
            elif first_arg == "create":
                return self._handle_create_command(args)
            elif first_arg == "update":
                return self._handle_update_command(args)
            elif first_arg == "delete":
                return self._handle_delete_command(args)
            elif first_arg == "run-remote":
                return self._handle_run_remote_command(args)
            else:
                # Try to call an agent by name
                return self._handle_agent_call(args)
                
        except Exception as e:
            logger.error(f"Error in agents command: {e}")
            print(ui.block_header("Agent Error", icon="❌", color_code="38;5;196"))
            print(ui.block_line("Error", "Error accessing subagents", box_color="38;5;196"))
            print(ui.block_line("Details", str(e), box_color="38;5;196"))
            print(ui.block_footer())
            return True

    def _handle_help_command(self) -> bool:
        """Handle the 'help' subcommand to show help for the agents command"""
        agents_ui = CLIAgentsManager(cli=self.cli)
        return agents_ui._show_help()
                
    def _handle_list_command(self) -> bool:
        """Handle the 'list' subcommand to display local and remote agents."""
        agents_ui = CLIAgentsManager(cli=self.cli)
        return agents_ui._handle_list_command()

    def _handle_create_command(self, args: str) -> bool:
        """
        Handle the 'create' subcommand to create a new agent.
        
        Args:
            args: Command arguments containing "create", agent name, and description
            
        Returns:
            bool: True to continue CLI execution, False to exit
        """
        try:
            # Parse arguments
            # Format: /agents create [agent-name] [agent-description]
            arg_parts = args.strip().split(maxsplit=2)
            
            # Create an AgentsUI instance to handle the UI interactions
            agents_ui = CLIAgentsManager(cli=self.cli)
            
            if len(arg_parts) < 3:
                # If no arguments provided or incomplete, delegate to the interactive manager
                if len(arg_parts) == 1:  # Only "create" provided
                    return agents_ui._create_new_agent()
                
                print(ui.block_header("Invalid Command", icon="⚠️", color_code="38;5;214"))
                print(ui.block_line("Usage", "/agents create [agent-name] [agent-description]", box_color="38;5;214"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True
            
            # Extract agent name and description from arguments
            _, agent_name, agent_description = arg_parts
            
            # Delegate to the UI manager
            return agents_ui._create_or_update_agent(
                agent_name=agent_name, 
                agent_description=agent_description
            )
            
        except Exception as e:
            logger.error(f"Error creating agent: {e}")
            print(ui.block_header("Creation Error", icon="❌", color_code="38;5;196"))
            print(ui.block_line("Error", str(e), box_color="38;5;196"))
            print(ui.block_footer())
            input("\nPress Enter to continue...")
            return True
            
    def _handle_update_command(self, args: str) -> bool:
        """
        Handle the 'update' subcommand to update an existing agent.
        
        Args:
            args: Command arguments containing "update", agent name, and changes
            
        Returns:
            bool: True to continue CLI execution, False to exit
        """
        try:
            # Parse arguments
            # Format: /agents update [agent-name] [agent-changes]
            arg_parts = args.strip().split(maxsplit=2)
            
            # Create an AgentsUI instance to handle the UI interactions
            agents_ui = CLIAgentsManager(cli=self.cli)
            
            if len(arg_parts) < 3:
                # If only "update" provided, delegate to the interactive manager
                if len(arg_parts) == 1:
                    return agents_ui._update_existing_agent()
                
                print(ui.block_header("Invalid Command", icon="⚠️", color_code="38;5;214"))
                print(ui.block_line("Usage", "/agents update [agent-name] [agent-changes]", box_color="38;5;214"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True
                
            _, agent_name, agent_changes = arg_parts
            
            # Validate agent exists
            agent_manager = self.cli.agent_manager
            agent_def = agent_manager.load_agent_metadata(agent_name)
            if not agent_def:
                print(ui.block_header("Agent Not Found", icon="❌", color_code="38;5;196"))
                print(ui.block_line("Agent", agent_name, box_color="38;5;196"))
                print(ui.block_line("Error", "The requested agent does not exist", box_color="38;5;196"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True
            
            # Delegate to the UI manager
            return agents_ui._create_or_update_agent(
                agent_name=agent_name, 
                agent_changes=agent_changes
            )
            
        except Exception as e:
            logger.error(f"Error updating agent: {e}")
            print(ui.block_header("Update Error", icon="❌", color_code="38;5;196"))
            print(ui.block_line("Error", str(e), box_color="38;5;196"))
            print(ui.block_footer())
            input("\nPress Enter to continue...")
            return True
            
    def _handle_delete_command(self, args: str) -> bool:
        """
        Handle the 'delete' subcommand to delete an existing agent.
        
        Args:
            args: Command arguments containing "delete" and agent name
            
        Returns:
            bool: True to continue CLI execution, False to exit
        """
        # Create an AgentsUI instance to handle the UI interactions
        agents_ui = CLIAgentsManager(cli=self.cli)
        return agents_ui._handle_delete_command(args)

    def _handle_run_remote_command(self, args: str) -> bool:
        """Handle executing a remote GEAI agent via the CLI.

        Supports multi-word agent names (e.g., "Code Fixer").
        Parsing strategy:
        - Strip the leading 'run-remote' token
        - If the next segment is quoted, treat the quoted string as the name
        - Otherwise, match the longest remote agent name that prefixes the rest
        - Fallback to first-token-as-name if no match found
        """
        try:
            # Expect: "/agents run-remote [agent-name] [input]"
            tokens = args.strip().split(maxsplit=1)
            if len(tokens) < 2:
                print(ui.block_header("Invalid Command", icon="⚠️", color_code="38;5;214"))
                print(ui.block_line("Usage", "/agents run-remote [agent-name] [input]", box_color="38;5;214"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True

            rest = tokens[1].strip()

            # Early GEAI configuration check
            if not are_geai_credentials_available():
                show_geai_not_configured()
                return True

            # Ensure main agent initialization (perf parity with local agents)
            if not self.cli.wait_for_agent_initialization(with_animations=False):
                return False

            # Load remote agents to enable accurate name parsing
            agent_manager = self.cli.agent_manager
            remote_agents = agent_manager.list_remote_agents_cached()
            remote_names = [a.name for a in remote_agents]
            # Parse rest into agent_name and agent_input
            agent_name, agent_input = extract_remote_agent_command(rest, remote_names)

            try:
                invocation = parse_agent_invocation(agent_input, default_mode=AGENT_CONTEXT_DEFAULT_MODE, valid_modes=AGENT_CONTEXT_VALID_MODES)
            except ValueError as exc:
                show_context_error(str(exc))
                return True

            processed_input = invocation.prompt
            display_input = processed_input[:40] + "..." if len(processed_input) > 40 else (processed_input or "No input")
            print(ui.block_header(f"Remote GEAI Agent: {agent_name}", icon="☁️", color_code="38;5;81"))
            print(ui.block_line("Processing", display_input, box_color="38;5;81"))
            print(ui.block_line("Context", invocation.context_mode, box_color="38;5;81"))
            print(ui.block_footer())

            try:
                agent = agent_manager.create_remote_geai_agent(name_or_id=agent_name)
            except Exception as exc:
                print(ui.block_header("Agent Configuration Failed", icon="⚠️", color_code="38;5;214"))
                print(ui.block_line("Agent", agent_name, box_color="38;5;214"))
                print(ui.block_line("Error", str(exc), box_color="38;5;214"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True

            if not agent:
                print(ui.block_header("Agent Configuration Failed", icon="⚠️", color_code="38;5;214"))
                print(ui.block_line("Agent", agent_name, box_color="38;5;214"))
                print(ui.block_line("Error", "Failed to configure the remote GEAI agent", box_color="38;5;214"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True

            try:
                messages_for_agent = build_agent_prompt(self.cli.shared_state, processed_input, invocation.context_mode)
                agent_result = self.cli.agent_handler.handle_interaction_with_agent(
                    user_message=messages_for_agent,
                    agent=agent
                )

                # Record interaction in shared state (centralizes memory updates in core)
                try:
                    self.cli.shared_state.record_agent_interaction(
                        agent_name=agent_name,
                        user_input=processed_input,
                        result=agent_result,
                        remote=True,
                    )
                except Exception as exc:
                    logger.debug(f"Failed to record remote agent interaction: {exc}")

                return True

            except Exception as exc:
                error_str = str(exc)
                if "422" in error_str and "parameter" in error_str.lower():
                    print(ui.block_header("Tool Configuration Error", icon="🔧", color_code="38;5;214"))
                    print(ui.block_line("Error", "Agent tools may need credentials", box_color="38;5;214"))
                    print(ui.block_line("Suggestion", "Configure tool credentials (e.g., web_search.apiKey)", box_color="38;5;214"))
                elif "500" in error_str and "not fully awake" in error_str.lower():
                    print(ui.block_header("Agent Runtime Error", icon="😴", color_code="38;5;214"))
                    print(ui.block_line("Error", "Tool-less agents may not work on this host", box_color="38;5;214"))
                    print(ui.block_line("Suggestion", "Try adding tools or using beta host", box_color="38;5;214"))
                else:
                    print(ui.block_header("Remote Agent Error", icon="❌", color_code="38;5;196"))
                    print(ui.block_line("Error", error_str, box_color="38;5;196"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True

        except Exception as exc:
            logger.error(f"Error running remote agent: {exc}")
            print(ui.block_header("Remote Agent Error", icon="❌", color_code="38;5;196"))
            print(ui.block_line("Error", str(exc), box_color="38;5;196"))
            print(ui.block_footer())
            input("\nPress Enter to continue...")
            return True

    def _handle_agent_call(self, args: str) -> bool:
        """
        Handle calling an subagent by name with optional input.

        Args:
            args: Command arguments containing subagent name and optional input

        Returns:
            bool: True to continue CLI execution, False to exit
        """
        # If no arguments or empty, delegate to the interactive agent runner
        if not args.strip():
            agents_ui = CLIAgentsManager(cli=self.cli)
            agents_ui.run_interactive_session()
            return True

        try:
            # Parse agent name and input
            arg_parts = args.strip().split(maxsplit=1)
            agent_name = arg_parts[0]
            agent_input_raw = arg_parts[1] if len(arg_parts) > 1 else ""

            try:
                invocation = parse_agent_invocation(agent_input_raw)
            except ValueError as exc:
                show_context_error(str(exc))
                return True

            agent_input = invocation.prompt
            context_mode = invocation.context_mode

            # Block until the main agent is initialized with its dependencies such as:
            #   - memories from the SharedState
            #   - MCPService/MCPClient singletons which run async tasks
            if not self.cli.wait_for_agent_initialization(with_animations=False):
                return False

            agent_manager = self.cli.agent_manager
            agent_def = agent_manager.load_agent_metadata(agent_name)

            if not agent_def:
                remote_agents = agent_manager.list_remote_agents_cached()
                remote_names = {agent.name for agent in remote_agents}
                if agent_name in remote_names:
                    parts = ["run-remote", agent_name]
                    if context_mode != AGENT_CONTEXT_DEFAULT_MODE:
                        parts.extend(["--context", context_mode])
                    if agent_input:
                        parts.append(agent_input)
                    run_remote_args = " ".join(parts)
                    return self._handle_run_remote_command(run_remote_args)

                print(ui.block_header("Agent Not Found", icon="❌", color_code="38;5;196"))
                print(ui.block_line("Agent", agent_name, box_color="38;5;196"))
                print(ui.block_line("Error", "The requested agent does not exist", box_color="38;5;196"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True

            # Build the messages for the subagent, including context if requested
            messages_for_subagent = build_agent_prompt(self.cli.shared_state, agent_input, context_mode)

            # Use a new memory for the agent
            memory = None

            # Print agent header
            ui.print_agent_header(agent_name, status="Starting...")

            # Create the agent using the AgentManager
            agent = agent_manager.create_agent(
                agent_name=agent_name,
                memory=memory,
                file_editor=self.cli.agent_handler.file_editor,
                user_defined_rules=self.cli.shared_state.user_defined_rules,
            )

            if not agent:
                print(ui.block_header("Agent Configuration Failed", icon="⚠️", color_code="38;5;214"))
                print(ui.block_line("Agent", agent_name, box_color="38;5;214"))
                print(ui.block_line("Error", "Failed to configure the requested agent", box_color="38;5;214"))
                print(ui.block_footer())
                input("\nPress Enter to continue...")
                return True

            # Process the request
            subagent_result = self.cli.agent_handler.handle_interaction_with_agent(
                user_message=messages_for_subagent,
                agent=agent,
            )

            # Record interaction in shared state (centralizes memory updates in core)
            try:
                self.cli.shared_state.record_agent_interaction(
                    agent_name=agent_name,
                    user_input=agent_input,
                    result=subagent_result,
                    remote=False,
                )
            except Exception as exc:
                logger.debug(f"Failed to record subagent interaction: {exc}")

            return True

        except Exception as e:
            logger.error(f"Error calling agent: {e}")
            print(ui.block_header("Agent Error", icon="❌", color_code="38;5;196"))
            print(ui.block_line("Error", str(e), box_color="38;5;196"))
            print(ui.block_footer())
            return True
