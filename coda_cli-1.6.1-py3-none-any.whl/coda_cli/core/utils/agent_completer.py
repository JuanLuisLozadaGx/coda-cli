import time
from typing import Iterable, List, Dict, Any
from prompt_toolkit.completion import Completer, Completion
from loguru import logger
from prompt_toolkit.document import Document
from coda_core.core.agents.manager import AgentManager


class AgentCompleter(Completer):
    """
    Custom completer that provides agent suggestions when the user types '@' or '/agents'.
    Supports both '@agent' format and '/agents' command with its subcommands.
    """
    
    def __init__(self, agent_manager=None):
        """
        Initialize the AgentCompleter.
        
        Args:
            agent_manager: Optional AgentManager instance to use. If None, a new one is created.
        
        Loads available agents from the AgentManager.
        """
        if agent_manager:
            self.agent_manager = agent_manager
        else:
            self.agent_manager = AgentManager()
            self.agent_manager.initialize_default_agents()

        self.agents: List[Dict[str, str]] = []
        self.last_refresh_time = 0
        # Keep both full remote list and filtered names for '@' suggestions
        self._all_remote_agents: List[Any] = []
        self._filtered_remote_agent_names: List[str] = []
        self._refresh_agents()

        self.subcommands = {
            "list": "List all available subagents",
            "create": "Create a new agent",
            "update": "Update an existing agent",
            "delete": "Delete an existing agent",
            "run-remote": "Run a remote GEAI agent",
        }
        
    def _refresh_agents(self) -> None:
        """Refresh the list of available agents (local + remote when configured)."""
        self.agents = []
        agent_names = self.agent_manager.filter_agents_list(attribute="command")

        for agent_name in agent_names:
            agent_def = self.agent_manager.load_agent_metadata(agent_name)
            if agent_def and agent_def.metadata.command:
                self.agents.append(
                    {
                        "name": agent_name,
                        "description": agent_def.metadata.description,
                        "source": "local",
                    }
                )

        try:
            # Preserve the full remote list for run-remote completions
            self._all_remote_agents = list(self.agent_manager.list_remote_agents_cached())

            # Filter for @ mentions using shared prefs (handled inside manager)
            filtered = list(self.agent_manager.list_visible_remote_agents())
            self._filtered_remote_agent_names = [a.name for a in filtered]

            # Add only filtered remote agents to '@' suggestions
            local_names = {agent["name"] for agent in self.agents}
            for agent in filtered:
                if agent.name not in local_names:
                    self.agents.append(
                        {
                            "name": agent.name,
                            "description": getattr(agent, "description", ""),
                            "source": "remote",
                        }
                    )
        except Exception as exc:
            # Ignore remote fetch errors to keep completions responsive, but log for diagnostics
            logger.debug(f"AgentCompleter remote refresh failed: {exc}")

        try:
            self.agents.sort(key=lambda entry: (entry.get("source") != "local", entry.get("name", "").lower()))
        except Exception as exc:
            logger.debug(f"AgentCompleter sort failed: {exc}")

        self.last_refresh_time = time.time()
        
    def refresh_if_needed(self):
        """Refresh agents list if it's been more than 60 seconds since last refresh."""
        current_time = time.time()
        if current_time - self.last_refresh_time > 60:  # Refresh every 60 seconds
            self._refresh_agents()
        
    def refresh(self):
        """Force an immediate refresh of the agent list."""
        self._refresh_agents()

    def get_completions(self, document: Document, complete_event) -> Iterable[Completion]:
        """
        Generate completions based on the current input.
        
        Args:
            document: Current document state
            complete_event: Completion event
            
        Yields:
            Completion objects for matching agents or agent subcommands
        """
        # Refresh agents list if needed
        self.refresh_if_needed()
        
        text = document.text_before_cursor
        
        # Handle @agent format (existing behavior)
        if text.startswith('@'):
            word = text.lstrip('@')
            
            for agent in self.agents:
                agent_name = agent["name"]
                if agent_name.startswith(word):
                    display_text = f"{agent_name}"
                    if agent["description"]:
                        display_text += f" - {agent['description']}"
                    source = agent.get("source", "local")
                    
                    # We need to replace the entire text (including @) with @agent_name
                    # so it's properly detected by the command handler
                    yield Completion(
                        f"@{agent_name}",
                        start_position=-len(text),
                        display=display_text,
                        style=f"class:completion.agent.{source}"
                    )
        
        # Handle /agents command and subcommands
        elif text.startswith('/agents '):
            parts = text.split()
            
            # Handle base '/agents' command with no additional text
            if text.startswith('/agents') and len(parts) == 1 and text.endswith(' '):
                # Offer all subcommands when user has typed '/agents '
                for subcommand, description in self.subcommands.items():
                    yield Completion(
                        subcommand,
                        start_position=0,
                        display=f"{subcommand} - {description}",
                        style="class:completion.command"
                    )
            
            # Handle '/agents ' followed by partial subcommand
            elif text.startswith('/agents') and len(parts) == 2 and not text.endswith(' '):
                # User is typing a subcommand or agent name after '/agents'
                prefix = text[8:].strip()  # Get what's after '/agents'
                
                # Offer matching subcommands
                for subcommand, description in self.subcommands.items():
                    if subcommand.startswith(prefix):
                        yield Completion(
                            subcommand,
                            start_position=-len(prefix),
                            display=f"{subcommand} - {description}",
                            style="class:completion.command"
                        )
            
            # Handle '/agents update' or '/agents delete' followed by agent name
            elif len(parts) == 2 and parts[1] in {'update', 'delete'} and text.endswith(' '):
                for agent in self.agents:
                    if agent.get('source', 'local') != 'local':
                        continue
                    agent_name = agent["name"]
                    description = agent["description"] or ""
                    yield Completion(
                        agent_name,
                        start_position=0,
                        display=f"{agent_name} - {description}",
                        style="class:completion.agent.local"
                    )

            elif len(parts) >= 2:
                if parts[1] == 'run-remote':
                    all_agents = [{"name": a.name, "description": getattr(a, "description", "")}
                                  for a in (self._all_remote_agents or [])]
                    style = "class:completion.agent.remote"
                elif parts[1] in {'update', 'delete'}:
                    all_agents = [agent for agent in self.agents if agent.get('source', 'local') == 'local']
                    style = "class:completion.agent.local"
                else:
                    return

                start_position = 0 if text.endswith(' ') else -len(parts[-1])
                prefix = parts[-1] if not text.endswith(' ') else ''
                for agent in all_agents:
                    name = agent["name"]
                    if prefix and not name.startswith(prefix):
                        continue
                    description = agent["description"] or ""
                    yield Completion(
                        name,
                        start_position=start_position,
                        display=f"{name} - {description}",
                        style=style
                    )
