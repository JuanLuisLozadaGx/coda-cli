"""Autocomplete support for /skill-name invocations."""

import time
from typing import Iterable, List
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document
from loguru import logger


class SkillCompleter(Completer):
    """Autocomplete for /skill-name invocations.
    
    Provides intelligent autocomplete suggestions when users type "/" followed
    by skill names. Integrates with the skill loader to discover available skills
    and refreshes the list periodically to stay up-to-date.
    
    Features:
    - Auto-refresh every 60 seconds
    - Styled completions (project vs system skills)
    - Description previews in autocomplete menu
    - Smart caching to avoid performance issues
    """
    
    def __init__(self, skill_loader=None):
        """Initialize the skill completer.
        
        Args:
            skill_loader: Optional SkillLoader instance for discovering skills
        """
        self.skill_loader = skill_loader
        self.skills: List[dict] = []
        self.last_refresh_time = 0
        self._refresh_skills()
    
    def _refresh_skills(self) -> None:
        """Refresh the list of available skills from the skill loader."""
        self.skills = []
        
        if not self.skill_loader:
            logger.debug("SkillCompleter: No skill loader available")
            return
        
        try:
            # Force refresh to bypass cache and get current enabled state from disabled_skills.json
            skill_infos = self.skill_loader.discover_skills(force_refresh=True)
            
            for skill_info in skill_infos:
                if skill_info.enabled:
                    self.skills.append({
                        'name': skill_info.name,
                        'description': skill_info.description or '',
                        'source': skill_info.source
                    })
            
            # Sort: project skills first, then alphabetically by name
            self.skills.sort(
                key=lambda s: (s.get('source') != 'project', s.get('name', '').lower())
            )
            
            logger.debug(f"SkillCompleter: Refreshed {len(self.skills)} skills")
            
        except Exception as e:
            logger.debug(f"SkillCompleter refresh failed: {e}")
        
        self.last_refresh_time = time.time()
    
    def refresh_if_needed(self):
        """Refresh skills list if stale (>60 seconds since last refresh)."""
        if time.time() - self.last_refresh_time > 60:
            logger.debug("SkillCompleter: Auto-refreshing (60s elapsed)")
            self._refresh_skills()
    
    def refresh(self):
        """Force an immediate refresh of the skills list."""
        logger.debug("SkillCompleter: Force refresh requested")
        self._refresh_skills()
    
    def get_completions(self, document: Document, complete_event) -> Iterable[Completion]:
        """Generate skill completions for the current input.
        
        Args:
            document: The current prompt_toolkit document
            complete_event: The completion event (unused)
            
        Yields:
            Completion objects for matching skills
        """
        self.refresh_if_needed()
        
        text = document.text_before_cursor
        
        # Only handle /skill-name (not / commands with spaces or other prefixes)
        if not text.startswith('/'):
            return
        
        # Don't suggest skills if user has typed a space after /
        # (they're likely entering a task description)
        if ' ' in text[1:]:
            return
        
        word = text[1:]  # Remove leading /
        
        for skill in self.skills:
            skill_name = skill['name']
            
            # Only suggest skills that start with the typed text
            if skill_name.startswith(word):
                # Build the display text with description
                display_text = f"/{skill_name}"
                if skill['description']:
                    # Truncate long descriptions
                    desc = skill['description']
                    if len(desc) > 60:
                        desc = desc[:57] + "..."
                    display_text += f" - {desc}"
                
                # Determine the styling based on skill source
                source = skill.get('source', 'project')
                # Normalize to known style buckets; any non-(project|system) becomes project
                if source not in ("project", "system"):
                    source = "project"
                
                yield Completion(
                    f"/{skill_name} ",  # Add trailing space for convenience
                    start_position=-len(text),
                    display=display_text,
                    style=f"class:completion.skill.{source}"
                )
