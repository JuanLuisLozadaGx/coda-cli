"""Smart completer that prioritizes command vs skill completions based on user input."""

from typing import Iterable
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document


class SmartCompleter(Completer):
    """
    Smart completer that dynamically orders completions based on input context.
    
    This completer wraps command and skill completers and intelligently decides
    which one should have priority based on what the user is typing:
    
    - Default behavior: Show command completions first, then skill completions
    - Smart behavior: If the user input closely matches a skill name (better than
      any command), prioritize skill completions first
    
    This ensures that default commands are always visible first in the autocomplete
    menu, unless the user is specifically typing a skill name.
    """
    
    def __init__(self, command_completer: Completer, skill_completer: Completer):
        """
        Initialize the smart completer.
        
        Args:
            command_completer: Completer for default commands
            skill_completer: Completer for skills
        """
        self.command_completer = command_completer
        self.skill_completer = skill_completer
    
    def _is_skill_match_better(self, text: str, command_matches: list, skill_matches: list) -> bool:
        """
        Determine if skill matches are more relevant than command matches.
        
        Args:
            text: The user's input text (without leading /)
            command_matches: List of command completion texts
            skill_matches: List of skill completion texts
            
        Returns:
            True if skills should be prioritized, False otherwise
        """
        if not text:
            # No input yet, show commands first
            return False
        
        if not skill_matches:
            # No skill matches, show commands first
            return False
        
        if not command_matches:
            # No command matches, show skills first
            return True
        
        # Find the best match from each category
        best_command_match = min(command_matches, key=lambda c: len(c)) if command_matches else None
        best_skill_match = min(skill_matches, key=lambda c: len(c)) if skill_matches else None
        
        if best_skill_match and best_command_match:
            # Calculate match quality (lower is better)
            # Exact match = 0, prefix match = length difference
            skill_match_quality = len(best_skill_match) - len(text)
            command_match_quality = len(best_command_match) - len(text)
            
            # If skill match is significantly better (shorter completion needed), prioritize it
            # We use a threshold to avoid flipping back and forth
            if skill_match_quality < command_match_quality - 1:
                return True
        
        # Check if user input exactly matches start of a skill but not a command
        exact_skill_prefix = any(s.startswith(text) for s in skill_matches)
        exact_command_prefix = any(c.startswith(text) for c in command_matches)
        
        if exact_skill_prefix and not exact_command_prefix:
            return True
        
        # Default: show commands first
        return False
    
    def get_completions(self, document: Document, complete_event) -> Iterable[Completion]:
        """
        Generate completions with smart ordering.
        
        Args:
            document: Current document state
            complete_event: Completion event
            
        Yields:
            Completion objects, ordered intelligently
        """
        text = document.text_before_cursor
        
        # Only handle slash commands
        if not text.startswith('/'):
            return
        
        # Get completions from both completers
        command_completions = list(self.command_completer.get_completions(document, complete_event))
        skill_completions = list(self.skill_completer.get_completions(document, complete_event))
        
        # Extract completion texts for comparison
        word = text.lstrip('/')
        command_texts = [c.text.lstrip('/').strip() for c in command_completions]
        skill_texts = [c.text.lstrip('/').strip() for c in skill_completions]
        
        # Decide ordering based on match quality
        if self._is_skill_match_better(word, command_texts, skill_texts):
            # Skills first, then commands
            yield from skill_completions
            yield from command_completions
        else:
            # Commands first (default), then skills
            yield from command_completions
            yield from skill_completions
