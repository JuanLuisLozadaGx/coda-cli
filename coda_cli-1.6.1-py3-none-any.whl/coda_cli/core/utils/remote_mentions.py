"""Shared helpers for remote agent mention preferences."""

from typing import Set, Tuple

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig


def _read_mode_value() -> str:
    return SETTINGS.get_env_var(EnvConfig.CODA_REMOTE_MENTIONS_MODE) or "favorites"


def _read_allowlist_value() -> str:
    return SETTINGS.get_env_var(EnvConfig.CODA_REMOTE_MENTIONS_ALLOWLIST) or ""


def get_remote_mentions_preferences() -> Tuple[str, str, Set[str]]:
    """Return (mode, allowlist_csv, parsed_allowlist) with graceful fallbacks."""
    mode = _read_mode_value().strip().lower()
    allowlist_raw = _read_allowlist_value()
    allowlist = {item.strip() for item in allowlist_raw.split(',') if item.strip()}
    return mode, allowlist_raw, allowlist


def set_remote_mentions_mode(value: str) -> None:
    """Persist the remote mentions mode (shared across clients)."""
    normalized = (value or "").strip().lower()
    SETTINGS.set_env_var(EnvConfig.CODA_REMOTE_MENTIONS_MODE, normalized)


def set_remote_mentions_allowlist(csv_value: str) -> None:
    """Persist the remote agent allowlist (shared across clients)."""
    sanitized = (csv_value or "").strip()
    SETTINGS.set_env_var(EnvConfig.CODA_REMOTE_MENTIONS_ALLOWLIST, sanitized)
