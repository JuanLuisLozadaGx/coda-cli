import time
import subprocess
from typing import Callable, List, Dict, Tuple

from loguru import logger
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit import print_formatted_text
from detect_secrets.core.scan import scan_line
from detect_secrets.settings import get_settings

from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_core.config.utils import check_required_env_variables
from coda_core.core.filesystem_ops.utils import read_file
from coda_core.core.models.providers.geai_client import GEAIClient
from coda_core.core.session.states.shared_state import SharedState
from coda_core.core.agents.manager import AgentManager
from coda_core.core.utils.skill_loader import SkillLoader

from coda_cli.core.agent.agent_handler import AgentHandler
from coda_cli.core.session.states.cli_client_state import CLIClientState
from coda_cli.core.ui import clear_screen, print_invalid_geai_credentials
from coda_cli.core.utils.agent_completer import AgentCompleter


def execute_bash_command(command_str: str) -> bool:
    """
    Execute a bash command and return the results.
    
    Runs the provided bash command in a subprocess and displays the output.
    Handles errors and provides appropriate feedback on command execution status.
    
    Args:
        command_str (str): The command string to execute (without the leading !)
        
    Returns:
        bool: Always returns True to continue CLI execution
    """
    if not command_str:
        print_formatted_text(HTML("<ansiyellow>Usage: !&lt;command&gt; (e.g. !ls -a)</ansiyellow>"))
        return True
        
    try:
        result = subprocess.run(command_str, shell=True, capture_output=True, text=True)
        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print_formatted_text(HTML(f'<ansired>Error: {result.stderr}</ansired>'))
        if result.returncode != 0:
            print_formatted_text(HTML(f'<ansiyellow>Command exited with status: {result.returncode}</ansiyellow>'))
    except Exception as e:
        print_formatted_text(HTML(f'<ansired>Error executing command: {e}</ansired>'))
        
    return True


def display_rules_warnings(warnings: List[str]) -> None:
    """Display user-defined rules warnings in the CLI output.

    Args:
        warnings: List of warning strings emitted during rules loading.

    Returns:
        None.
    """
    if not isinstance(warnings, list):
        return

    for warning in warnings:
        if not isinstance(warning, str) or not warning:
            continue
        print_formatted_text(HTML(f'<ansiyellow>{warning}</ansiyellow>'))


def read_files_content(file_paths: List[str]) -> List[dict]:
    """
    Read the content of multiple files and format them as a list of dictionaries.
    
    Args:
        file_paths (List[str]): List of file paths to read
        
    Returns:
        List[dict]: List of dictionaries containing file path, content, and error (if any)
    """
    files_content = []
    for file_path in file_paths:
        file_data = {"file_path": file_path, "content": None, "error": None}
        try:
            content = read_file(file_path)
            file_data["content"] = content
        except Exception as e:
            file_data["error"] = str(e)
        files_content.append(file_data)
    
    return files_content


def prepare_user_message(file_paths: List[str], query: str) -> str:
    """
    Prepare a complete user message for the LLM that includes file contents and the user's query.
    
    This function reads the content of all provided files, formats them in a structured way,
    and combines them with the user's query to create a comprehensive message for the LLM.
    
    Args:
        file_paths (List[str]): List of file paths to include in the message
        query (str): The user's question or request
        
    Returns:
        str: A formatted message containing file contents and the user's query
    """
    # Read the content of all files
    files_data = read_files_content(file_paths)
    
    # Start building the message
    message_parts = ["Here are the files to analyze:"]
    
    # Add each file with its content
    for file_data in files_data:
        file_path = file_data["file_path"]

        # Check if the file content is None or empty
        if file_data["error"]:
            # If there was an error reading the file, include the error message
            message_parts.append(f"\nFile: {file_data['file_path']}\nError: {file_data['error']}")
            continue
        
        # Get the content of the file
        content = file_data["content"]
        
        # Format with file path and content in a code block with proper syntax highlighting
        file_ext = file_path.split('.')[-1] if '.' in file_path else ''
        message_parts.append(f"\nFile: {file_path}\n```{file_ext}\n{content}\n```")
    
    # Add the user's query at the end
    message_parts.append(f"\nUser query: {query}")
    
    # Join all parts into a single message
    return "\n".join(message_parts)


def _mask_sensitive_value(value: str, visible_chars: int = 8) -> str:
    """
    Mask a sensitive value by showing only the first few characters.
    
    Args:
        value: The value to mask
        visible_chars: Number of characters to show (default: 8)
        
    Returns:
        str: Masked string with visible characters + asterisks
    """
    if not value:
        return value
    
    visible = min(visible_chars, len(value))
    return f"{value[:visible]}{'*' * (len(value) - visible)}"


def _configure_detect_secrets_plugins(enable_value_scanning: bool = False, enable_keyword_detector: bool = True) -> None:
    """
    Configure detect-secrets plugins for secret scanning.

    Args:
        enable_value_scanning (bool):
            If True, enables scanning for sensitive values.
        enable_keyword_detector (bool):
            If True, enables the KeywordDetector plugin for keyword-based detection.

    Returns:
        None
    """
    if not (enable_value_scanning or enable_keyword_detector):
        return
    
    plugins = []
    if enable_keyword_detector:
        plugins.append({'name': 'KeywordDetector'})
    if enable_value_scanning:
        plugins.extend([
            {'name': 'Base64HighEntropyString'},
            {'name': 'HexHighEntropyString'},
        ])

    current_settings = get_settings()
    current_settings.configure_plugins(plugins)

def _check_sensitive_data(var_enum, value: str | None = None) -> tuple[bool, bool]:
    """
    Check if a variable name or value contains sensitive information using detect-secrets.
    
    Uses detect-secrets to perform both keyword detection (variable name) and pattern
    detection (value content) in a single scan for efficiency.
    
    Args:
        var_enum: Environment variable enum to check
        value: Optional value to check. If None, uses a placeholder value.
        
    Returns:
        tuple[bool, bool]: (is_sensitive_name, has_sensitive_value)
            - is_sensitive_name: True if variable name matches sensitive keywords
            - has_sensitive_value: True if value contains sensitive patterns (only when value provided)
    """

    var_name = var_enum.value if hasattr(var_enum, 'value') else str(var_enum)

    enable_value_scanning = bool(value and value.strip())

    _configure_detect_secrets_plugins(
        enable_value_scanning=enable_value_scanning
    )

    # Use placeholder if no value provided, otherwise use the actual value
    actual_value = value if value and value.strip() else "placeholder"
    line = f"{var_name}={actual_value}"
    secrets = list(scan_line(line))

    # If no secrets detected, nothing is sensitive
    if not secrets:
        return False, False

    is_sensitive_name = any(
        secret.type == 'Secret Keyword' or 'Keyword' in secret.type
        for secret in secrets
    )

    # If no value was provided, we only checked the name
    if not value or not value.strip():
        return is_sensitive_name, False

    # Value is sensitive if secrets were detected beyond just the keyword
    has_sensitive_value = len(secrets) > (1 if is_sensitive_name else 0)

    return is_sensitive_name, has_sensitive_value


def collect_configuration(missing_vars: List[Tuple[EnvConfig, str]]) -> Dict[EnvConfig, str]:
    """
    Collect configuration for missing environment variables through user input.
    
    Uses detect-secrets to validate both variable names (keyword detection) and values
    (pattern detection for secrets like high-entropy strings, keys, tokens).
    
    Args:
        missing_vars (List[Tuple[EnvConfig, str]]): A list of tuples (var_enum, description) for missing variables
        
    Returns:
        (Dict[EnvConfig, str]): Dictionary mapping environment variable enums to their values
    """
    credentials = {}
    
    # Get current values for variables being configured
    current_values = {}
    for var_enum, _ in missing_vars:
        current_values[var_enum] = SETTINGS.get_env_var(var_enum) or ""
    
    # Simple instruction
    print("\033[33m(Press Enter to keep existing values)\033[0m\n")
    
    # Collect each variable
    for var_enum, desc in missing_vars:
        current = current_values[var_enum]
        
        # Check if variable name is sensitive (for display masking)
        is_sensitive_name, _ = _check_sensitive_data(var_enum)
        
        # Display current value with masking for sensitive data
        if current:
            display_text = _mask_sensitive_value(current) if is_sensitive_name else current
            print(f"\033[1;36m{desc}\033[0m [current: \033[33m{display_text}\033[0m]")
        else:
            print(f"\033[1;36m{desc}\033[0m")
        
        # Get new value
        value = input(f"> ").strip()
        
        # Process input
        if not value and current:
            final_value = current
        else:
            final_value = value

        if not is_sensitive_name:
            _, has_sensitive_value = _check_sensitive_data(var_enum, final_value)

            # Warn if a non-sensitive variable receives a value that appears sensitive
            if has_sensitive_value:
                logger.warning(f"The value for '{var_enum.value}' appears to contain sensitive information")
        
        credentials[var_enum] = final_value
        
        # Add some spacing
        print()
    
    return credentials


def save_configuration(credentials: Dict[EnvConfig, str]) -> None:
    """
    Save configuration values to persistent storage.
    
    Args:
        credentials (Dict[EnvConfig, str]): Dictionary mapping environment variable enums to their values.
    
    Raises:
        ValueError: If GEAI credentials are invalid or cannot be verified.
    """
    # If set, validate GEAI credentials
    if EnvConfig.CODA_GEAI_BASE_URL in credentials and EnvConfig.CODA_GEAI_API_KEY in credentials:
        GEAIClient.validate_credentials(
            base_url=credentials[EnvConfig.CODA_GEAI_BASE_URL],
            api_key=credentials[EnvConfig.CODA_GEAI_API_KEY]
        )

    # Minimal feedback
    print("\033[36mSaving...\033[0m")
    for var_enum, value in credentials.items():
        # Skip empty values
        if not value:
            continue
        
        try:
            # Save to environment
            SETTINGS.set_env_var(var_enum, value)
        except Exception as e:
            print(f"\033[31m✗ Error saving {var_enum.value}: {str(e)}\033[0m")


def setup_configuration(reconfigure: bool = False, print_banner: Callable = None) -> bool:
    """
    Set up the application by checking and configuring required environment variables.
    
    Handles both initial configuration and reconfiguration of environment variables.
    Provides a streamlined interface for entering API credentials.
    
    Args:
        reconfigure: Whether to force reconfiguration of environment variables.
        print_banner: Function to print the application banner.
        
    Returns:
        bool: True if configuration was updated or no configuration was needed, False otherwise.
    """
    last_error_msg = ""
    max_tries = 3
    while max_tries > 0:
        clear_screen()
        # Show the banner first (if provided)
        if print_banner:
            print_banner()
        
        # Check if environment variables are set
        missing_vars = check_required_env_variables()
        # If environment variables are missing or reconfiguration is requested
        if missing_vars or reconfigure:
            # Create the boxed title for GEAI Configuration
            box_color = "\033[1;36m"  # Bright cyan for the box
            reset_color = "\033[0m"
            title_text = "Configure your API Keys for Globant Enterprise AI"
            box_width = len(title_text) + 4  # Add padding for the box edges
            
            print()
            print(f"{box_color}╭{'─' * (box_width - 2)}╮{reset_color}")
            print(f"{box_color}│ {reset_color}{title_text}{' ' * (box_width - len(title_text) - 3)}{box_color}│{reset_color}")
            print(f"{box_color}╰{'─' * (box_width - 2)}╯{reset_color}")
            print()
            
            if last_error_msg:
                print_formatted_text(HTML(f"<ansibrightred>{last_error_msg}</ansibrightred>"))
                print()

            # Determine which variables to collect
            if reconfigure:
                vars_to_collect = [
                    (EnvConfig.CODA_GEAI_BASE_URL, "GEAI Base URL"),
                    (EnvConfig.CODA_GEAI_API_KEY, "GEAI API Key"),
                    (EnvConfig.CODA_PYPI_REPO_TOKEN, "Azure Access Token")
                ]
            else:
                vars_to_collect = missing_vars
            
            # Show minimal quick reference for URL formats - one line only
            if any("BASE_URL" in var[0].value for var in vars_to_collect):
                print_formatted_text(HTML('\n<ansiyellow>Valid URL examples:</ansiyellow> <ansiblue>https://api.clients.geai.globant.com, https://api.corp.geai.globant.com</ansiblue>\n'))
            
            # Directly collect the configuration - minimal UI
            credentials = collect_configuration(vars_to_collect)
            try:
                save_configuration(credentials)
                # Simple success message
                print()
                print_formatted_text(HTML('<ansibrightgreen>✓ Configuration complete!</ansibrightgreen>'))
                time.sleep(1)
                return True
            except Exception as e:
                last_error_msg = str(e)
                max_tries -= 1
        else:
            # Nothing to update
            return True
    
    print_invalid_geai_credentials()
    
    return False


def load_session_and_update_ui(cli, session_id: str) -> bool:
    """
    Load a session and update UI components.
    
    This function:
    1. Loads the specified session
    2. Updates shared state and client state
    3. Updates UI components (command history)
    
    Args:
        cli: The CLI instance
        session_id (str): ID of the session to load
        
    Returns:
        bool: True if session was loaded successfully, False otherwise
    """
    try:
        # Load the session
        session = cli.session_manager.load_session(session_id)
        
        # Initialize states from loaded session
        shared_state_dict = session.shared_state
        
        # Get client state type - handle case where cli_state doesn't exist yet
        client_type = cli.cli_state.CLIENT_TYPE if hasattr(cli, 'cli_state') else 'cli'
        client_state_dict = session.get_client_state(client_type)
        
        # Update shared state
        if shared_state_dict:
            cli.shared_state = SharedState.from_dict(shared_state_dict)
            
            # Log the status of user-defined rules when loading a session
            if cli.shared_state.user_defined_rules:
                rules = cli.shared_state.user_defined_rules
                status = rules.get('status')
                paths = rules.get('paths') or []
                path = rules.get('path')

                if paths:
                    path_info = paths[-1] if len(paths) == 1 else f"{len(paths)} files (latest: {paths[-1]})"
                else:
                    path_info = path

                if status == 'success':
                    logger.info(f"Session loaded with user-defined rules from {path_info} ({rules.get('char_count', 0)} characters)")
                elif status == 'truncated':
                    logger.warning(f"Session loaded with truncated user-defined rules from {path_info} ({rules.get('char_count', 0)} characters)")
                elif status == 'empty':
                    logger.info(f"Session loaded with empty rules file at {path_info}")
                elif status == 'not_found':
                    missing_info = f"not found at {path_info}" if path_info else "path not specified"
                    logger.info(f"Session loaded without user-defined rules ({missing_info})")
                elif status == 'error':
                    logger.error(f"Session loaded with error in rules from {path_info}: {rules.get('error', 'Unknown error')}")

                for warning in rules.get('warnings', []):
                    logger.warning(f"Rules warning while loading session: {warning}")
                display_rules_warnings(rules.get('warnings', []))

        else:
            cli.shared_state = SharedState()
        
        # Update client state
        if client_state_dict:
            cli.cli_state = CLIClientState.from_dict(client_state_dict)
        else:
            cli.cli_state = CLIClientState()

        # Initialize SkillLoader with the loaded session's ID
        cli.skill_loader = SkillLoader(session_id=session_id)
        logger.debug(f"SkillLoader initialized for loaded session: {session_id}")

        # Initialize the AgentManager and AgentHandler once all the properties are loaded
        cli.agent_manager = AgentManager(cli.shared_state)
        cli.agent_manager.initialize_default_agents()
        cli.agent_handler = AgentHandler(cli=cli)

        # Ensure agent completer reflects latest agent metadata
        if hasattr(cli, "agent_completer") and cli.agent_completer is not None:
            cli.agent_completer.agent_manager = cli.agent_manager
            try:
                if hasattr(cli.agent_completer, "refresh"):
                    cli.agent_completer.refresh()
                else:
                    cli.agent_completer.refresh_if_needed()
            except Exception as e:
                logger.warning(f"Agent completer refresh failed during session load: {e}")
        else:
            cli.agent_completer = AgentCompleter(agent_manager=cli.agent_manager)

        # Refresh the prompt session to keep the user messages history accessible
        cli._setup_ui()

        # Display success message
        print_formatted_text(HTML(f'<ansibrightgreen>Loaded session: {session.name}</ansibrightgreen>'))
        return True

    except Exception as e:
        logger.error(f"Unexpected error creating prompt session: {e}")
        print(f"\033[1;31mUnexpected error loading existing session. Loading a new session.\033[0m")
        return True


def get_yes_no_input(prompt: str, default: str = None) -> bool:
    """
    Get a yes/no input from the user, accepting various forms of yes and no.
    
    Args:
        prompt: The prompt to display to the user
        default: The default value if the user just presses Enter ('yes', 'no', or None)
    
    Returns:
        bool: True for yes, False for no
    """
    yes_responses = ['y', 'yes', 'yeah', 'yep', 'sure', 'ok', 'true', '1']
    no_responses = ['n', 'no', 'nope', 'nah', 'false', '0']
    
    # Add default indicator to prompt if provided
    if default is not None:
        if default.lower() in yes_responses:
            prompt += " [Y/n]: "
        elif default.lower() in no_responses:
            prompt += " [y/N]: "
        else:
            prompt += " [y/n]: "
    else:
        prompt += " [y/n]: "
    
    while True:
        response = input(prompt).strip().lower()
        
        # Handle empty response with default
        if not response and default is not None:
            return default.lower() in yes_responses
        
        # Check for valid responses
        if response in yes_responses:
            return True
        elif response in no_responses:
            return False
        else:
            print("Please answer with 'yes' or 'no' (or y/n).")


def input_file_path_cleanup(path: str) -> str:
    """
    Remove surrounding quotes from a file path if they match.
    
    Handles both single and double quotes, only removes them if they
    appear at both the beginning and end of the string.
    
    Args:
        path (str): The file path that may have surrounding quotes
        
    Returns:
        str: The path with surrounding quotes removed if they were present
        
    Examples:
        >>> input_file_path_cleanup('"my file.txt"')
        'my file.txt'
        >>> input_file_path_cleanup("'my file.txt'")
        'my file.txt'
        >>> input_file_path_cleanup('my "quoted" file.txt')
        'my "quoted" file.txt'
        >>> input_file_path_cleanup('"mismatched\'')
        '"mismatched\''
    """
    path = path.strip()
    
    # Check if path has at least 2 characters and matching quotes
    if len(path) >= 2:
        first_char = path[0]
        last_char = path[-1]
        
        # Remove quotes only if they match at start and end
        if (first_char == '"' and last_char == '"') or \
           (first_char == "'" and last_char == "'"):
            return path[1:-1]
    
    return path
