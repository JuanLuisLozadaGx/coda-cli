"""
Reasoning effort utilities for CLI.

Provides normalization and validation helpers for model reasoning effort configuration.
"""


def normalize_reasoning_effort(effort: str | None) -> str | None:
    """
    Normalize reasoning effort with a local compatibility fallback.

    Args:
        effort: Raw reasoning effort value.

    Returns:
        Normalized value when supported, otherwise ``None``.
    """
    if not isinstance(effort, str):
        return None

    normalized = effort.strip().lower()
    if normalized in {"none", "minimal", "low", "medium", "high"}:
        return normalized
    return None
