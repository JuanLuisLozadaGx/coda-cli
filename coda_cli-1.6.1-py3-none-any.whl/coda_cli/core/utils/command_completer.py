from typing import Iterable
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document


class CommandCompleter(Completer):
    """
    Custom completer that provides command completion and recipe suggestions.
    """
    
    def __init__(self, commands_dict: dict):
        """
        Initialize the CommandCompleter.
        
        Args:
            commands_dict: Dictionary of available commands
        """
        self.commands_dict = commands_dict
        
        skip_commands = ['/reindex', '/cancel-indexing', '/ask']

        # Get the first alias as the primary command
        self.commands = []
        self.command_aliases_map = {}
        for command_aliases in commands_dict.keys():
            if command_aliases[0] in skip_commands:
                continue
            if isinstance(command_aliases, tuple):
                self.commands.append(command_aliases[0])
                self.command_aliases_map[command_aliases[0]] = command_aliases
            
    def get_completions(self, document: Document, complete_event) -> Iterable[Completion]:
        """
        Generate completions based on the current input.
        
        Args:
            document: Current document state
            complete_event: Completion event
            
        Yields:
            Completion objects for matching commands or recipes
        """
        text = document.text_before_cursor
        
        # If text starts with /, show command completions
        if text.startswith('/'):      
            # Always show command completions for partial matches
            word = text.lstrip('/')
            for command in self.commands:
                command_name = command.lstrip('/')
                if command_name.startswith(word):
                    # Get command description if available
                    description = ""
                    for cmd_aliases, cmd_info in self.commands_dict.items():
                        if command in (cmd_aliases if isinstance(cmd_aliases, tuple) else (cmd_aliases,)):
                            description = cmd_info.get('description', '')
                            break
                    
                    # Format display text with all aliases only for /approve
                    aliases = self.command_aliases_map.get(command, (command,))
                    if command == "/approve" and len(aliases) > 1:
                        display_text = " or ".join(aliases)
                    else:
                        display_text = command
                    
                    if description:
                        display_text += f" - {description}"
                    
                    yield Completion(
                        command,
                        start_position=-len(text),
                        display=display_text,
                        style="class:completion.command"
                    )