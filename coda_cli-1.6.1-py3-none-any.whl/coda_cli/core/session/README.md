# Session Module

The Session module manages the state and persistence of Coda-CLI sessions, allowing users to save their working context and restore it in future sessions.

## Overview

The session module extends the CODA Core session framework with CLI-specific functionality, providing:
- Management of selected files
- Tracking of current working directory
- Indexing status management
- Command history tracking
- Session persistence and restoration

## Architecture

```mermaid
flowchart TD
    subgraph "Session Module"
        CLIState[CLIClientState]
        CLIState --> SharedState[CODA Core SharedState]
        CLIState --> SessionManager[CODA Core SessionManager]
        CLIState --> Persistence[Session Persistence]
    end
    
    subgraph "State Components"
        Files[Selected Files]
        Directory[Working Directory]
        Indexing[Indexing Status]
        History[Command History]
        Preferences[CLI Preferences]
    end
    
    CLIState --> Files & Directory & Indexing & History & Preferences
    
    User(User Interactions) --> |Updates| CLIState
    SessionManager --> |Save/Load| Persistence
    CLIState --> |Serialization| Persistence
```

## Key Components

### CLIClientState

The `CLIClientState` class (`states/cli_client_state.py`) is the primary component of the session module, representing CLI-specific state. It inherits from the CODA Core base `ClientState` class and adds CLI-specific functionality such as:

- **File Management**: Tracking files selected for context
- **Directory Tracking**: Storing the current working directory
- **Indexing Status**: Monitoring code indexing progress
- **Command History**: Tracking a unique ID for command history
- **Preferences**: Storing CLI-specific preferences

### State Management

The CLIClientState class provides methods for:

- **File Management**: Adding files to context, clearing files, and retrieving file information
- **State Serialization**: Converting state to and from serializable dictionaries
- **Command History**: Tracking and managing command history

## Integration with CODA Core

The CLIClientState class integrates with the CODA Core session management framework while adding CLI-specific functionality. This integration allows Coda-CLI to leverage CODA's session persistence capabilities while maintaining its own state requirements.

## Usage Flow

1. The main CLI instance initializes the session module
2. Session state is loaded from persistent storage or created new
3. CLI operations update the state as needed (adding files, changing preferences, etc.)
4. State is periodically saved to persistent storage
5. On exit, final state is saved

The Session module is central to the Coda-CLI experience, enabling context persistence across sessions and providing a foundation for file-aware interactions with the AI agent.