import os
from typing import List, Dict, Any
import uuid

from coda_core.core.session.states.client_state import ClientState
from coda_core.config.settings import SETTINGS
from coda_core.config.env_config import EnvConfig
from coda_cli.config.constants import CLIENT_NAME


class CLIClientState(ClientState):
    """
    Represents CLI-specific state.
    
    This includes selected files and other
    CLI-specific preferences and state.
    
    Attributes:
        selected_files: List of files currently selected for context
        current_directory: The current working directory
        cli_preferences: Dictionary of CLI-specific preferences
    """
    
    CLIENT_TYPE = CLIENT_NAME
    
    def __init__(self):
        """
        Initialize CLI state with default values.
        """
        # Files currently selected for context
        self.selected_files = []
        
        # Current working directory
        self.current_directory = os.getcwd()

        # Session ID
        self.command_history_id = str(uuid.uuid4())
        
        # CLI-specific preferences
        self.cli_preferences = {}
    

    @property
    def command_history_path(self) -> str:
        """
        Get the command history path for this CLI state.
        
        Returns:
            str: Path to the command history file
        """
        return os.path.join(SETTINGS.get_env_var(EnvConfig.CODA_COMMAND_HISTORY_DIR), f"{self.command_history_id}_command-history")


    def add_file(self, filepath: str) -> bool:
        """
        Add a file to the selected files if it exists.
        
        Args:
            filepath (str): Path to the file to add
            
        Returns:
            bool: True if file was added or already exists, False if not found
        """
        # Normalize the path to handle spaces and other path issues correctly
        normalized_filepath = os.path.normpath(filepath)
        
        if os.path.exists(normalized_filepath):
            if normalized_filepath not in self.selected_files:
                self.selected_files.append(normalized_filepath)
            return True
        return False
    

    def clear_files(self) -> None:
        """Clear all selected files."""
        self.selected_files.clear()
    

    def get_file_basenames(self) -> List[str]:
        """
        Get the basenames of all selected files.
        
        Returns:
            List of file basenames
        """
        return [os.path.basename(f) for f in self.selected_files]
    

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize to dictionary.
        
        Returns:
            Dict containing all CLI state data
        """
        return {
            "selected_files": self.selected_files,
            "current_directory": self.current_directory,
            "cli_preferences": self.cli_preferences,
            "command_history_id": self.command_history_id
        }
    
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CLIClientState":
        """
        Create from dictionary.
        
        Args:
            data: Dictionary containing CLI state data
            
        Returns:
            New CLIClientState instance
        """
        state = cls()
        
        # Restore selected files
        state.selected_files = data.get("selected_files", [])
        
        # Restore directory
        state.current_directory = data.get("current_directory", os.getcwd())
        
        # Restore CLI preferences
        state.cli_preferences = data.get("cli_preferences", {})
        
        # Restore history ID (or keep the new one if not present)
        if "command_history_id" in data:
            state.command_history_id = data["command_history_id"]
        
        return state