import re

from typing import Optional
from coda_core.config.env_config import EnvConfig
from coda_core.config.settings import SETTINGS
from coda_core.core.models.providers.geai_client import GEAIClient

from coda_cli.core.ui import print_invalid_geai_credentials, print_model_not_available


def post_init_checks() -> bool:
    """
    Perform post-initialization checks for the CODA CLI application.

    Returns:
        bool: True if all checks pass, False otherwise.
    """
    no_errors = _check_invalid_credentials()
    return no_errors


def _check_invalid_credentials() -> bool:
    """
    Check if the GEAI credentials are invalid.

    Returns:
        bool: True if the credentials are invalid, False otherwise.
    """
    # Validate GEAI Credentials
    geai_url = SETTINGS.get_env_var(EnvConfig.CODA_GEAI_BASE_URL)
    geai_key = SETTINGS.get_env_var(EnvConfig.CODA_GEAI_API_KEY)
    if geai_url and geai_key:
        try:
            GEAIClient.validate_credentials(geai_url, geai_key)
        except ValueError:
            print_invalid_geai_credentials()
            return False

    return True


def check_model_not_available(received_exception: Optional[Exception] = None) -> bool:
    """
    Check if the model is not available.

    Args:
        received_error_message: The error message from init to check if model is not available.

    Returns:
        bool: False if errors related to model not available, True otherwise.
    """
    if received_exception is not None:
        # Check for error message matching the unavailable model pattern
        pattern = r"Model '.+' from provider '.+' is not available on client '.+'"
        if match_obj := re.search(pattern, str(received_exception)):
            print_model_not_available(match_obj.group(0))
            return False

    return True  # No errors found related to model not available.
