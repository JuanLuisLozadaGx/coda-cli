from typing import Any, Optional
import traceback


def get_app_with_checks() -> Optional[Any]:
    """
    Perform pre-initialization checks for the CODA CLI application and
    return it if all checks pass.

    Returns:
        Optional[Any]: The CODA CLI application instance or None if checks fail.
    """
    try:
        # Attempt to import the CODA CLI application
        from coda_cli.core.cli import app
        return app
    except Exception as e:
        # Reference the import names that will be used in the finally block
        print_hyperlink = None
        try:
            # Attempt to import ui utils for better messaging formatting
            from coda_cli.core.ui.core import print_hyperlink
            # Handle specific exceptions for detailed error reporting
            import pydantic

            print("\n==================== CODA Startup Error ====================\n")
            print(f"Error: {e}\n")
            print(traceback.format_exc())

            print("--------------- Possible Solutions (Known Issues) ---------------\n")
            if isinstance(e, pydantic.ValidationError):
                print("• Detected a configuration validation error (Pydantic).")
                print("  → There are cases where .env files in the root directory can cause issues. If your .env has a LOG_LEVEL variable, make sure it has one of the following values:") # Issue #335
                print("    - DEBUG")
                print("    - INFO")
                print("    - WARNING")
                print("    - ERROR")
                print("    - CRITICAL")
                print("  → Check your configuration files for any field or environment variable that could be related to the error.")
            elif isinstance(e, ImportError):
                print(f"• Missing dependency: {getattr(e, 'name', 'Unknown')}")
                print("  → If a pip suggestion is provided, try installing it with: pip install <suggested-package>. e.g: pip install fast-autocomplete[pylev]")
                print("  → If the error is related to git ensure you have it installed and available in your PATH.") # Issue #334
            else:
                print("• No known solution. Please review the error above or contact support.")
        finally:
            print("\n---------------------- Need Help? ----------------------\n")
            # FAQ, Quick Guide, Slack, and Email links are provided for user assistance
            if not print_hyperlink:
                print_hyperlink = print

            print_hyperlink("- Check our FAQ", "https://docs.google.com/document/d/16EZHUO4l4tKBn7rJd6JlpkE8e3JkiW4hC8EOFtzs_us")
            print_hyperlink("- CODA's quick guide", "https://docs.google.com/document/d/1yIDTa8kHBQUJK_xw5tf5T2W-TenU3t7fFNMOP9qK59U")
            print_hyperlink("- Slack: #g-coda-for-coding", "https://globant.slack.com/archives/C07LDG3HJFR" )
            print_hyperlink("- Email: coda-tech-support@globant.com", "mailto:coda-tech-support@globant.com")

            print("\nFor a faster solution, take a screenshot of the terminal or copy the error and share it with us.\n")

            return None
