# Import config setup to ensure CLI configuration is registered with coda-core settings module
# This runs when the package is imported, ensuring config is always available
import coda_cli.config.setup  # noqa: F401